# NEBUSTION — Étape 8 : Pass de saison

Accès : barre du bas → **Pass**.

- 30 niveaux, piste **Gratuit** + piste **Premium** (ressources, Prismes, fragments, héros vedette, skins).
- Saisons de 28 jours (local, minuit), 4 thèmes qui tournent ; ancre = lundi 14/09/2026 (saison 1).
- XP de Pass gagnée via missions quotidiennes (3) et hebdomadaires (3), à réclamer manuellement.
- Progression dans `Resources.state.pass` (sauvegarde existante, version inchangée, anciennes sauvegardes OK).
- Récompenses non réclamées perdues en fin de saison ; ressources refusées si stockage plein (réclamables ensuite).

## Achats intégrés Android — NON implémentés
`js/systems/PassBilling.js` : fournisseur par défaut « none » (indisponible, aucun paiement, aucun Premium).
Pour Google Play : `NEBUSTION.PassBilling.registerProvider({ id, isAvailable, getProduct, purchase, restore })`.
SKU par saison : `nebustion_pass_premium_s<N>`. Le Premium n'est activé que par `PassManager.grantPremium()`,
appelée par PassBilling après confirmation du fournisseur. Valider les jetons côté serveur (le jeu est hors ligne :
sans serveur, la sauvegarde locale reste modifiable). En `?debug=1`, un bouton « TEST » bascule le Premium (pas un paiement).

Tests : `node tests/pass.test.js` ; `NODE_PATH=$(npm root -g) node tests/browser-pass.js` (faux Phaser).

## Paiement provisoire en ressources (ajout étape 10)
En attendant Google Play, la fenêtre Premium propose **« Payer avec des ressources »** (ce n'est PAS un paiement réel) :
8 000 cristaux · 6 000 métal · 3 000 énergie · 60 noyaux · 15 000 poussière, pour le Premium de la saison en cours.
Débit atomique (tout ou rien), impossible si déjà Premium. Code : `NEBUSTION.PassBilling.payWithResources()` ; prix modifiable via `RESOURCE_PRICE`
dans `js/systems/PassBilling.js`. Le Premium reste marqué `premiumSource: 'resources'`. Le fournisseur Google Play, lui, reste indisponible.
