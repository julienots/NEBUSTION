# NEBUSTION — Bâtiments vus de dessus (vue 3D réaliste)

## Ce qui est voulu
Quand tu passes juste au-dessus d'un bâtiment, tu vois son TOIT (comme dans la vraie vie) ; sur les côtés de la planète
tu vois ses murs. Le bâtiment reste posé sur le sol, orienté avec le terrain (est/nord).

## Comment
- `js/scenes/PlanetScene.js` :
  - `NEBUSTION.PlanetLayout.foot` : volume 3D simplifié de chacun des 8 bâtiments (empreinte, hauteur, toit plat ou en pointe).
  - `_drawBuilding3D` : dessine ce volume (murs éclairés par le soleil fixe + toit) projeté avec la rotation de la planète.
  - `_basis` : repère du sol (est/nord/normale) à l'endroit du bâtiment.
  - Fondu `roofT` (0 → dessin de profil habituel, 1 → vue de dessus) selon la position sur le disque : `_projectVec`,
    zone réglable `(zb - 0.80) / 0.16`.
  - Le dessin de profil est rangé dans `box.art` (fondu + léger écrasement en approchant du centre).
- Inclinaison au sol (v2) conservée : `MAX_TILT = 1.15`.
- Constructions posées par le joueur (`struct`) : inchangées pour l'instant (dessin de profil seulement).
- Cache PWA : `nebustion-v56-vue-dessus-batiments`.

## Non testé sur téléphone
Vérifié sous Node : 0 valeur invalide sur toutes les rotations testées. Rendu à valider en jeu.
