# NEBUSTION - Galaxie : refonte visuelle
- Nouveau fichier : js/utils/GalaxyBackdrop.js (textures Canvas procédurales : fond, disque galactique spiral)
- Modifiés : js/scenes/GalaxyScene.js (_buildMap, update), index.html, sw.js (cache v28)
- Carte : disque spiral incliné qui tourne lentement (2 couches), noyau incandescent qui pulse, nébuleuses, étoiles qui scintillent,
  étoile filante, routes lumineuses avec particules d'énergie, halos de planètes, anneau orbital de Nexus-01.
- Logique de jeu, sauvegardes et interactions inchangées.
