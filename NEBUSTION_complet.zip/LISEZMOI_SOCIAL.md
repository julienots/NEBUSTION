# NEBUSTION — Social : vrais joueurs, bots uniques, clans (v3.4.0)

Nouvel écran **Social** (menu latéral de l'accueil → « Social ») avec 4 onglets : **Chat**, **Joueurs**, **Clan**, **Amis**.

## Ce que tu vois
| | Vrais joueurs (compte connecté) | Faux joueurs (bots) |
|---|---|---|
| Joueurs | Profil public publié toutes les ~45 s (pseudo, niveau, puissance, clan). « En ligne » = vu < 2 min | **160 bots uniques** : pseudo, bio, avatar, archétype (Guerrier, Bâtisseur, Marchand…), horaires de connexion réalistes, niveau/puissance qui évoluent avec les jours |
| Chat général | Messages réels en temps réel (Firestore) | Les bots en ligne discutent (≈140 phrases distinctes, jamais deux fois de suite la même) et **répondent** à ce que tu écris (salut, aide, clan, duel, cadeau…) |
| Clans | Création (2000 💎), tag unique, 30 membres max, chat privé, XP par dons | **14 clans de bots uniques** (nom, tag, devise, emblème, 8-26 membres, niveau) avec leur propre discussion |
| Interactions | Ajouter en ami, **cadeau** (100 💎 → transféré au joueur), **duel amical** (basé sur la puissance, 5/jour), don au clan, **coffre quotidien** du clan | Idem ; un bot peut te renvoyer un cadeau (70 💎) quelques minutes plus tard |

Sans compte / sans réseau : tout marche avec les bots seuls, l'écran indique simplement qu'il faut se connecter pour voir les vrais joueurs.

## ⚠️ À faire UNE fois pour activer les vrais joueurs
Firebase → **Firestore Database → Règles** → coller le contenu de **`FIRESTORE_RULES_SOCIAL.txt`** → **Publier**.
Sans ça, les vrais joueurs/clans sont refusés par Firestore (l'écran affiche « Règles Firestore non publiées ») et seuls les bots restent.

## Bots : transparence
Par défaut les bots ne portent pas de badge. Pour afficher « BOT » dans les listes : `SHOW_BOT_TAG = true` en haut de `js/data/Social.js`.
(Certaines boutiques d'applications demandent de ne pas présenter des bots comme de vrais joueurs : garde ça en tête avant publication.)

## Limites honnêtes
- Puissance, niveau et XP de clan sont **déclarés par le client** : suffisant pour du fun, pas pour un classement compétitif sans serveur (Cloud Functions).
- Les vrais joueurs « en ligne » = ceux dont le jeu est ouvert et connecté ; la liste montre les 60 plus récents.
- Le duel est une simulation basée sur la puissance (pas un combat en direct entre deux appareils).
- Testé ici avec un faux Phaser et un faux Firestore (pas de vrai Phaser/Firebase dans mon environnement) : l'aspect visuel et les règles sont à valider sur ton appareil.

## Fichiers
`js/data/Social.js` (bots, clans, chat, duel — pur), `js/systems/SocialManager.js` (état + Firebase), `js/scenes/SocialScene.js` (écran),
`CloudSave.getDb()`, sauvegarde `social` (rétrocompatible), `index.html`, `main.js`, `sw.js` (cache v69), `MainMenuScene` (entrée + icône).
Tests : `node tests/social.test.js` (416), `node tests/social-manager.test.js` (52), `node tests/social-scene-smoke.js` (31).
