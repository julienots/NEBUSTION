# NEBUSTION - Améliorations des troupes : 10 rangs par branche (au lieu de 5)

- Modifiés : js/data/Troops.js, js/systems/TroopManager.js, tests/troopUpgrades.test.js, sw.js (cache v34)
- Les 3 branches d'amélioration (Caserne › toucher une troupe) passent de 5 à **10 rangs** chacune :
  - ⚔️ Assaut : +7 % DPS par rang → jusqu'à **+70 %** au rang 10 (au lieu de +35 %).
  - 🛡️ Blindage : +8 % PV par rang → jusqu'à **+80 %** au rang 10 (au lieu de +40 %).
  - ⚡ Propulsion : +6 % vitesse / +0,05 portée par rang → jusqu'à **+60 % vitesse / +0,5 portée** (au lieu de +30 %/+0,25).
- Coût : les 5 nouveaux rangs (6 à 10) restent chers et demandent de plus en plus de Noyaux antiques
  (le coût en Noyaux continue de grimper à chaque rang au-delà du 3e, au lieu de s'arrêter au rang 5).
  Les rangs 1 à 5 coûtent exactement comme avant.
- Aucun changement d'écran nécessaire : la Caserne (`TroopsScene.js`) et le combat lisent déjà le
  plafond et le coût dynamiquement (`UPGRADE_BRANCHES[...].max`, `TroopManager.upgradeCost`) — rien à
  toucher côté affichage.
- Sauvegardes existantes : compatibles telles quelles (les niveaux déjà atteints, ≤5, restent valides ;
  rien n'est réinitialisé).

## Tests
`node tests/troopUpgrades.test.js` (10 vérifications, mis à jour) · suite complète rejouée : aucune
régression liée à ce changement (les échecs préexistants et sans rapport — stages de boss, un visuel
« outsiderz », un numéro de version de sauvegarde codé en dur dans un test — ne sont pas touchés ici).
