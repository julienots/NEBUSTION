> **Nouveau : Caisses & Clés + Forge d'Éclats + skins refaits** — voir `LISEZMOI_29_CAISSES_CLES.md`.

> **Nouveau : APK Android via GitHub** — construire et installer le jeu en `.apk` sur ton téléphone, voir `TUTORIEL_APK_GITHUB.md`.

> **Nouveau : Mode Atelier (compte Admin)** — accès rapide aux outils de création depuis le jeu, voir `LISEZMOI_MODE_ATELIER_ADMIN.md`.

> **Comptes fiables (v21)** : restauration corrigée, protection multi-appareils — voir `LISEZMOI_COMPTE_CLOUDSAVE.md` (fin du fichier).

> **Correctif 10b** : bâtiments, extracteurs et Stockage sont maintenant améliorables — voir `LISEZMOI_10B_AMELIORATIONS.md`.

# NEBUSTION — État du projet : étape 10/10 (Expéditions, Événements, Renaissance, Succès)

Ce ZIP contient le jeu complet (étapes 1 à 10). **Lire `LISEZMOI_10_EXPEDITIONS_EVENEMENTS_PRESTIGE.md`** pour les 4 derniers systèmes et
leurs limites. Lancer les tests : `for f in tests/*.test.js; do node $f | tail -1; done` puis
`NODE_PATH=$(npm root -g) node tests/browser-progress.js` (faux Phaser, pas de WebGL). Les autres `LISEZMOI_*.md` décrivent chaque étape.
Le reste de ce fichier est le README d'origine de l'étape 2 (économie), toujours valable pour le fonctionnement de base.

---

# NEBUSTION — Étape 2/10 : Ressources et farm spatial

Jeu mobile 2D/2.5D de farm spatial en **Phaser 3 + JavaScript vanilla**.
Cette étape ajoute une **vraie économie** sur la base de l'étape 1 (design, menus, navigation et bâtiments conservés).

## ⚠️ À lire d'abord (honnêteté sur les tests)

**Testé ici :**
- La **logique économique** (production, plafonds, dépenses, récolte, hors-ligne, sauvegarde, sauvegardes corrompues, multi-onglets) :
  `node tests/economy.test.js` → **1 763 vérifications, toutes OK**.
- Le **chargement complet dans un vrai Chromium** (index.html, ordre des scripts, dessin réel des textures Canvas 2D,
  création des scènes, HUD, gisements, drones, récolte, caisse, `localStorage`, rechargement, retour hors ligne) :
  `NODE_PATH=$(npm root -g) node tests/browser-smoke.js` → **37 vérifications, toutes OK, 0 erreur JS**.

**Non testé ici (limite de mon environnement) :** le rendu avec le **vrai moteur Phaser**. Mon environnement n'a pas accès
à Internet, je n'ai donc pas pu télécharger Phaser : le test de fumée utilise un *faux* Phaser strict
(`tests/mock-phaser.js`) qui détecte les méthodes inexistantes et les valeurs NaN, mais **ne simule ni WebGL, ni le rendu réel,
ni le vrai moteur de tweens/particules**. L'aspect visuel (positions, animations, lisibilité sur votre téléphone) est donc à
valider par vous. Si la console du navigateur affiche la moindre erreur, envoyez-la-moi : je corrige à l'étape suivante.

**Phaser n'est pas inclus dans le ZIP** (comme à l'étape 1, il est chargé depuis un CDN). Le jeu essaie dans l'ordre :
1. `js/vendor/phaser.min.js` (local → **jeu 100 % hors ligne**),
2. jsDelivr, puis cdnjs.

Pour un ZIP réellement autonome : `node tools/get-phaser.js` (une seule fois, avec Internet), ou téléchargez
`https://cdn.jsdelivr.net/npm/phaser@3.70.0/dist/phaser.min.js` et placez-le dans `js/vendor/phaser.min.js`.

## Lancer

**PC** : double-clic sur `index.html` (en principe suffisant : le jeu ne charge aucune image ni requête XHR), ou, plus sûr :
```bash
python3 -m http.server 8080      # dans ce dossier, puis http://localhost:8080
```
**Android** : lancez le serveur ci-dessus sur le PC et ouvrez `http://<IP-du-PC>:8080` dans Chrome (même Wi-Fi).
Servi en http(s), le jeu enregistre un service worker + manifest : menu Chrome ⋮ → **« Ajouter à l'écran d'accueil »**
donne un jeu plein écran qui redémarre même sans réseau (si `phaser.min.js` local est présent).
La sauvegarde est stockée dans le navigateur (`localStorage`), par adresse : changer d'adresse = nouvelle partie.

## Ce que fait cette étape

| Fonction | Comment |
|---|---|
| 5 ressources | Cristaux stellaires, Métal galactique, Énergie quantique, Noyaux antiques, Poussière cosmique |
| HUD permanent | 5 cellules (icône, stock, gain/s, jauge de stockage) sur **toutes** les scènes. « PLEIN » + jauge rouge au plafond |
| Gains /s et /min | Tap sur le HUD → panneau **Production** : stock/capacité, `+x /s`, `+y /min`, gain réel des 60 dernières secondes |
| Extraction temps réel | Production passive à chaque frame, calculée avec l'horloge réelle (indépendante des FPS) |
| Drones miniers | 5 drones animés sur Nexus-01 : décollage, vol, laser + étincelles, jauge de cargaison, dépôt au Commandement |
| Récolte au tap | Tap sur un gisement : gain + **10 % de critique ×3**. Réserve de 8 charges (1 charge / 3 s) → pas de spam infini |
| Caisse de ravitaillement | Tombe du ciel toutes les 75–130 s, reste 25 s, tap = 2 ressources (≈ 50–90 s de production) |
| Hors ligne | Au retour : production × **60 %**, plafonnée à **8 h**, fenêtre « Bon retour » avec les gains |
| Notifications | Gains flottants avec icône, particules par ressource, éclairs, toasts, vibration Android |
| Sauvegarde | Auto toutes les 5 s + à la mise en veille / fermeture / changement d'onglet |

## Économie (départ, niveau 1)

| Ressource | Extracteur | + 1 drone | **Total /s** | /min | Tap | Stockage | Départ |
|---|---|---|---|---|---|---|---|
| Cristaux | 0,50 | 0,20 | **0,72** | 43 | 3 | 15 000 | 100 |
| Métal | 0,40 | 0,15 | **0,57** | 34 | 2 | 12 000 | 60 |
| Énergie | 0,20 | 0,08 | **0,29** | 17 | 1,2 | 6 000 | 30 |
| Noyaux | 0,010 | 0,004 | **0,014** | 0,9 | 0,04 | 300 | 0 |
| Poussière | 1,00 | 0,40 | **1,45** | 87 | 5 | 30 000 | 150 |

(Le Hangar Nv.2 ajoute +12 % au rendement des drones.)
Résultats simulés : 10 min passives ≈ 534 cristaux ; **joueur actif ≈ ×2,1** (1 tap/3 s/gisement) ;
8 h hors ligne ≈ 12,6K cristaux / 9,9K métal / 5K énergie / 250 noyaux / 25K poussière (sous les plafonds, à dessein).
Première amélioration prévue (extracteur de cristaux : 150 métal + 300 poussière) ≈ 2 min 39 s d'attente passive.

**Évolutivité** (tout dans `js/data/Economy.js`) : production ×1,22 par niveau d'extracteur, tap ×1,12, stockage ×1,5,
coût d'amélioration ×1,55 par niveau, niveau max 50, jusqu'à 12 drones par ressource.

## Garanties anti-bugs

- Stock **jamais négatif / NaN / au-dessus du plafond** ; montants négatifs ou NaN refusés.
- Dépenses **atomiques** (tout ou rien).
- Hors ligne crédité **une seule fois** : l'instant « vu pour la dernière fois » est enregistré immédiatement, la fenêtre
  n'est remise qu'à un seul appelant, un rechargement immédiat (F5) ne donne rien de gratuit.
- Horloge reculée : aucun gain, aucune perte. Absence > 8 h : tronquée à 8 h.
- Les drones **n'ajoutent rien** au stock : ils illustrent la production (cargaison affichée = production du drone × durée du trajet).
- Sauvegarde : somme de contrôle, copie de secours, copie corrompue conservée (`nebustion_save_v2_corrupt`), valeurs
  réparées au chargement, 2 onglets ouverts → l'état le plus récent est adopté (pas de duplication).
- Écouteurs d'événements retirés à chaque changement de scène (pas de doublons).

## Tester rapidement le hors ligne

Ouvrez le jeu avec `?debug=1` (ex. `http://localhost:8080/?debug=1`) : le panneau Production affiche **« TEST : +1 h hors ligne »**
(simule une heure d'absence, fenêtre « Bon retour » incluse). Le bouton **Réinitialiser la partie** (double confirmation)
est toujours disponible. Console navigateur : `NEBUSTION.Resources.debugAway(7200)`.

## Prêt pour l'étape 3 (bâtiments améliorables)

Déjà en place : niveaux persistés pour les 10 bâtiments (Commandement, Hangar, Laboratoire, Défense, Stockage, 5 extracteurs),
`Economy.upgradeCost(id, niveau)`, `Resources.upgradeBuilding(id)` (paiement atomique + effet immédiat sur production/stockage),
`Resources.addDrone(id)`. Le bouton « Améliorer » de l'interface reste volontairement **désactivé** (« Bientôt disponible »).

## Structure

```
index.html            chargeur (Phaser local → CDN) puis scripts du jeu
manifest.webmanifest, sw.js, icons/    installation Android + cache hors ligne
js/data/Economy.js            taux, plafonds, coûts, formats (JS pur)
js/systems/SaveManager.js     sauvegarde robuste (JS pur)
js/systems/ResourceManager.js économie : temps réel, tap, caisses, hors ligne (JS pur)
js/utils/EconomyTextures.js   icônes, gisements, portiques, drone, caisse (Canvas 2D)
js/ui/ResourceHUD.js, FX.js, OfflineModal.js
js/entities/ResourceNode.js, MiningDrone.js, SupplyPod.js
js/scenes/…                   scènes de l'étape 1 (Planet, MainMenu et Placeholder adaptées)
tests/, tools/get-phaser.js
```
