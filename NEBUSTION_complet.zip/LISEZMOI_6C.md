# NEBUSTION — Étape 6, 3e volet : Personnalisation (skins)

Suite du ZIP « 6B vaisseaux ». Rien n'est recréé : le module s'ajoute à Héros, Vaisseaux, Planète et Combat.
Les skins sont **purement visuels** (aucun effet sur les stats — test à l'appui).

## Fichiers
| Fichier | Statut | Rôle |
|---|---|---|
| `js/data/Skins.js` | nouveau | 21 skins (7 héros, 7 vaisseaux, 7 bâtiments), 4 raretés, prix, état de sauvegarde. Pur (sans Phaser). |
| `js/systems/SkinManager.js` | nouveau | Inventaire de cosmétiques, achat, équipement/retrait, collection. |
| `js/ui/SkinFX.js` | nouveau | Teinte + aura + effets animés (onde, étincelles, flammes, orbites) ; vaisseaux/bâtiments dessinés en vectoriel pour l'aperçu. |
| `js/scenes/SkinsScene.js` | nouveau | Écran Personnalisation : onglets, sélecteur ‹ ›, **aperçu animé avant achat**, cartes Possédé/Équipé/prix, filtre Tout/Possédés, compteur de collection, effet à l'équipement. |
| `js/systems/SaveManager.js` | étendu | Sauvegarde v5 (champ `skins`) ; v2/v3/v4 migrées sans perte. |
| `HeroesScene`, `ShipsScene`, `PlanetScene`, `CombatScene` | branchés | Fiche héros (bouton « Skins », portrait skinné), hangar (icône de vaisseau skinnée, lien « Skins ›»), planète (aura + balise recolorée, lien « Skins ›» dans la fiche bâtiment), combat (teinte + aura légère, teinte restaurée après le flash d'impact). |
| `index.html`, `js/main.js`, `sw.js` | branchés | Chargement + cache hors ligne (le cache couvre maintenant aussi Équipement et Vaisseaux, absents avant). |

## Utilisation
Fiche héros → **Skins** · Flotte → **Skins ›** · Planète → toucher un bâtiment → **Skins ›**. Toucher une carte = aperçu (rien n'est acheté ni équipé) ; puis ACHETER → ÉQUIPER. Un skin acheté s'équipe sur n'importe quelle cible de son type.

## Correctifs au passage
- Les boutons « ‹ Retour » de la Flotte et de l'Équipement étaient à y=96, sous la zone tactile du HUD (y 10–106) : ils sont déplacés à y=126.
- Un skin ne peut plus être identifié par un nom hérité d'Object (`constructor`, `toString`…) : trouvé par les tests, corrigé.

## Tests
`node tests/skins.test.js` (120) · `skinManager.test.js` (33 : achat, équipement, stats inchangées, sauvegarde v4→v5, données corrompues)
`NODE_PATH=$(npm root -g) node tests/browser-skins.js` (46, Chromium + faux Phaser) · toute la suite existante repasse (Node : 13 fichiers + 5 tests navigateur, 0 régression).

## Limites connues
- Phaser réel non testé (pas de réseau ici) : faux Phaser seulement. Teintes, halos additifs, orbites et lisibilité sur téléphone sont à valider en jeu.
- Aperçu des vaisseaux/bâtiments = dessin vectoriel stylisé (le jeu n'a pas d'image de vaisseau) ; sur la planète, les bâtiments gardent leur dessin et reçoivent aura, balise et effets.
- Pas de skin par héros/vaisseau unique : ce sont des thèmes réutilisables. Les skins ne se gagnent qu'à l'achat (pas de drop).
- Équilibrage des prix à confirmer en jeu (légendaire : 12 000 poussière, 4 000 cristaux, 1 500 énergie, 20 noyaux).
