# NEBUSTION - Accueil : vraie galaxie spirale
- Modifiés : js/utils/SceneBackground.js (bloc withPlanet : galaxie riche), js/utils/GalaxyBackdrop.js (ensureHome, _makeDisk avec taille/densité), sw.js (cache v30)
- L'écran d'accueil (Nexus-01 + « ENTRER SUR NEXUS-01 ») a une galaxie à 4 bras : disque incliné en rotation lente, seconde couche fantôme en contre-rotation, noyau incandescent qui pulse derrière la planète, halo de nébuleuse, étoiles brillantes qui scintillent.
- Repli automatique sur les anciens bras si GalaxyBackdrop est absent. Autres scènes inchangées.
