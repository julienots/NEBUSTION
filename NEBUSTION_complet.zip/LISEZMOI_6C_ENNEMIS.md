# NEBUSTION — Illustrations d'ennemis (découpes nettoyées)

Les 13 ennemis et boss ont maintenant leur vraie illustration, découpée depuis la planche fournie.

## Ce qui est livré
- `assets/enemies/*.png` — 13 PNG carrés transparents (256–512 px), chaque sujet isolé de ses voisins.
- `js/utils/EnemyTextures.js` — `loadImages()` charge `assets/enemies/<id>.png` et le dessine dans la texture
  existante de l'ennemi (200x200 / boss 340x340), centré, proportions conservées. Fichier absent = silhouette d'origine.
- `js/scenes/PreloadScene.js` — chargement des illustrations avant celui des portraits de héros.
- `sw.js` — les 13 images sont mises en cache hors ligne (cache `nebustion-v6c-ennemis`).
- `tools/decouper_ennemis.py` — script de découpe reproductible (séparation par composantes connexes sur l'alpha :
  un voisin qui touche ou dont la boîte déborde n'est jamais inclus).
- `tests/browser-enemy-images.js` — test Chromium (fichiers présents, carrés, transparents, mise en forme).

## Correctif « boss coupé »
Les boss apparaissaient agrandis et coupés à droite/en bas : leur texture gardait le `ctx.scale(1.7)` du dessin procédural, appliqué aussi à l'image. `_applyImage` repart maintenant d'une matrice neutre. Seul fichier de jeu modifié : `js/utils/EnemyTextures.js`. Test de non-régression ajouté (les 13 textures réellement générées reçoivent l'image entière).

## Correspondance choisie
Les 5 grands portraits : vorath (démon rouge), nexus_prime (golem bleu), omega_krell (seigneur violet),
nexus_architect (prêtresse dorée), spore_swarm (créature verte) — appariés par couleur avec `Enemies.js`.
Golems/spectres : corvex_juggernaut (orange), cinder_bomber (imp rouge), glacial_specter (cristal de glace),
umbra_sniper (spectre violet), steel_golem (golem de glace bleu blindé).
**stellar_vampire = ange ailé** et **voltaic_hunter = grand vaisseau bleu** : choix par défaut (aucun sprite rose
sur la planche). Pour changer : éditer `SEEDS` dans le script, ou remplacer le PNG du même nom.

## Limites connues
- `drone_sentinel` est très petit dans la planche (67x52 px) : agrandi à 256 px, il est un peu flou.
- Le sprite « golem de lave rouge » de la planche et les unités des rangées d'infanterie/créatures ne sont pas utilisés.
- Phaser réel non testé (faux Phaser seulement) : rendu et netteté à valider sur téléphone.
