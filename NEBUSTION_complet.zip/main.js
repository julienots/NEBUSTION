/**
 * NEBUSTION - main.js
 * Point d'entrée : initialise l'économie (chargement de la sauvegarde + production hors ligne),
 * configure Phaser et démarre le jeu. Résolution de référence 720x1280 (portrait mobile),
 * redimensionnée pour remplir l'écran (Scale.FIT).
 */
(function () {
  'use strict';

  if (typeof Phaser === 'undefined') {
    console.error('NEBUSTION: Phaser n\'a pas pu être chargé.');
    return;
  }

  // Mode test : ajouter ?debug=1 à l'adresse pour afficher les outils de test dans le panneau de production
  NEBUSTION.DEBUG = /[?&]debug=1/.test(window.location.search);

  // --- Économie : une seule instance globale, indépendante des scènes ---
  NEBUSTION.Resources = new NEBUSTION.ResourceManager();
  NEBUSTION.Resources.init(Date.now());        // charge la sauvegarde, crédite la production hors ligne
  NEBUSTION.Resources.installLifecycle(window, document);   // sauvegarde à la mise en veille / fermeture

  // --- IA des 5 empires (hors ligne, sans serveur) : réactions aux conquêtes + évolution dans le temps (rattrapage 24 h max) ---
  try {
    if (NEBUSTION.EmpireAIManager && NEBUSTION.EmpireEvolutionManager) {
      NEBUSTION.EmpireAIManager.wire();
      NEBUSTION.EmpireEvolutionManager.start();
    }
  } catch (err) { console.error('NEBUSTION: évolution des empires indisponible', err); }

  // --- Raids ennemis contre le QG (étape 12, hors ligne, sans serveur) : lit l'élan des empires ci-dessus, ne les modifie jamais ---
  try { if (NEBUSTION.QGRaidManager) NEBUSTION.QGRaidManager.start(); } catch (err) { console.error('NEBUSTION: raids du QG indisponibles', err); }

  // --- Pass de saison : missions branchées sur les événements du jeu (aucun autre système modifié) ---
  try { if (NEBUSTION.PassManager) NEBUSTION.PassManager.wire(); } catch (err) { console.error('NEBUSTION: Pass de saison indisponible', err); }

  // --- Événements temporaires : missions branchées sur les événements du jeu + boss + boutique (étape 10) ---
  try { if (NEBUSTION.EventManager) NEBUSTION.EventManager.wire(); } catch (err) { console.error('NEBUSTION: événements indisponibles', err); }

  var config = {
    type: Phaser.AUTO,
    parent: 'game-container',
    backgroundColor: '#05070f',
    scale: {
      mode: Phaser.Scale.FIT,
      autoCenter: Phaser.Scale.CENTER_BOTH,
      width: 720,
      height: 1280
    },
    render: {
      antialias: true,
      pixelArt: false,
      transparent: false
    },
    input: {
      activePointers: 2
    },
    scene: [
      NEBUSTION.BootScene,
      NEBUSTION.PreloadScene,
      NEBUSTION.SplashScene,
      NEBUSTION.MainMenuScene,
      NEBUSTION.PlanetScene,
      NEBUSTION.HeroesScene,
      NEBUSTION.EquipmentScene,
      NEBUSTION.ShipsScene,
      NEBUSTION.SkinsScene,
      NEBUSTION.ShopScene,
      NEBUSTION.PassScene,
      NEBUSTION.ExpeditionScene,
      NEBUSTION.EventScene,
      NEBUSTION.PrestigeScene,
      NEBUSTION.AchievementsScene,
      NEBUSTION.CombatPrepScene,
      NEBUSTION.CombatScene,
      NEBUSTION.GalaxyScene,
      NEBUSTION.QGScene,
      NEBUSTION.SymbioteScene,
      NEBUSTION.PlaceholderScene
    ]
  };

  try {
    window.__NEBUSTION_GAME__ = new Phaser.Game(config);
    var boot = document.getElementById('boot-status');
    if (boot) boot.style.display = 'none';

    // La production passive avance à CHAQUE frame, quelle que soit la scène affichée.
    var lastGalaxyTick = 0;
    window.__NEBUSTION_GAME__.events.on('step', function () {
      var t = Date.now();
      NEBUSTION.Resources.tick(t);
      // Galaxie (module 5C) : termine les scans et verse les revenus des planètes conquises, même hors de l'écran Galaxie.
      if (t - lastGalaxyTick >= 5000 && NEBUSTION.GalaxyManager) {
        lastGalaxyTick = t;
        try { NEBUSTION.GalaxyManager.update(t); NEBUSTION.GalaxyManager.collectColonies(t); } catch (err) { console.error('NEBUSTION: galaxie', err); }
      }
    });

    // Empêche le "double tap zoom" et le scroll accidentel sur mobile
    document.addEventListener('touchmove', function (e) {
      e.preventDefault();
    }, { passive: false });

    window.addEventListener('resize', function () {
      if (window.__NEBUSTION_GAME__ && window.__NEBUSTION_GAME__.scale) {
        window.__NEBUSTION_GAME__.scale.refresh();
      }
    });
  } catch (err) {
    console.error('NEBUSTION: erreur au lancement du jeu', err);
    var fallback = document.getElementById('fallback-error');
    if (fallback) fallback.classList.add('visible');
  }
})();
