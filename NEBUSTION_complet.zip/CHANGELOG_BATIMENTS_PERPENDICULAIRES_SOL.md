# NEBUSTION — Bâtiments de Nexus-01 : vraiment posés sur le sol, même sur les côtés

## Ce qui est voulu
Un bâtiment (ou gisement) est planté PERPENDICULAIREMENT à la surface de la planète : droit au
centre du globe, couché vers l'extérieur sur les côtés, et à l'envers sur la moitié basse (comme
sur une vraie sphère vue de face). Il ne flotte plus « debout » à côté de la planète.

## Correctif
- `js/scenes/PlanetScene.js`, `_projectVec` : inclinaison = direction de la normale du sol à l'écran
  (`rot`, `ux`, `uy`). Près du centre du disque (normale vers la caméra) le bâtiment est remis droit
  par un mélange progressif de vecteurs (pas de sursaut). Plus d'écrasement vertical.
- `_applyBox` : rotation `p.rot`, dalle enfoncée dans le sol le long de la normale, badge de niveau
  toujours lisible.
- Gisements : portique incliné comme les bâtiments ; l'étiquette (niveau, ▲, charges) reste à
  l'endroit mais se place du côté opposé au portique (et sa zone tactile ▲ la suit).
- Drones : altitude le long de la normale du sol (retour à `_projectSphere`).
- La version « toujours droit » du zip précédent est annulée.

## Réglages
Zone où le bâtiment redevient droit au centre : `(len - 0.10) / 0.30` dans `_projectVec`.
Position de l'étiquette des gisements : `hox` / `hoy` dans `_applySphereTransform`.

## Non testé
Vérifié sous Node : inclinaison = direction radiale exacte sur 738 cas, aucun sursaut notable en
faisant tourner la planète (4 petits sursauts seulement à pitch extrême 0,85, près du centre du
disque). Rendu Phaser/téléphone à valider en jeu. Cache : `nebustion-v51-batiments-perpendiculaires-au-sol`.
