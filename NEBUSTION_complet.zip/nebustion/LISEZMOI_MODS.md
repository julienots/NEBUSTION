# NEBUSTION — Système de mods/plugins

Permet d'ajouter du contenu ou du comportement au jeu **sans toucher aux fichiers du jeu**
(`js/data/`, `js/systems/`, `js/scenes/`...). Un mod est un fichier `.js` posé dans `mods/` et
déclaré dans `mods/manifest.js`.

## Activer / désactiver un mod
Éditez `mods/manifest.js` :
```js
window.NEBUSTION_MODS_MANIFEST = [
  'mods/exemple_mod.js',
  // 'mods/mon_autre_mod.js',
];
```
Ajoutez une ligne pour activer un mod, retirez-la (ou mettez `//` devant) pour le désactiver.
Un mod absent ou dont le fichier lève une erreur est **signalé dans la console du navigateur**
mais ne bloque jamais le démarrage du jeu — ni les autres mods.

## Écrire un mod
Un mod s'enregistre avec `NEBUSTION.Mods.register({ ... })` :

```js
NEBUSTION.Mods.register({
  id: 'mon_mod',              // identifiant unique (obligatoire)
  name: 'Mon mod',            // nom affiché
  version: '1.0.0',

  init: function (NEB) {
    // Appelé immédiatement au chargement du fichier, AVANT le démarrage de Phaser.
    // Toutes les données du jeu existent déjà : NEB.Shop, NEB.Heroes, NEB.Economy,
    // NEB.Equipment, NEB.Ships, NEB.Codex, etc.
  },

  onGameReady: function (game, NEB) {
    // Appelé une fois Phaser.Game créé (game = window.__NEBUSTION_GAME__).
  },

  onTick: function (t, NEB) {
    // Optionnel : appelé en continu, quelle que soit la scène affichée (même rythme que
    // les autres managers hors-écran — voir js/main.js). t = Date.now().
  },

  scenes: [
    // Optionnel : classes de scène Phaser à ajouter au jeu (ex. new Phaser.Scene(...) / class).
  ]
});
```
Seul `id` est obligatoire ; tout le reste est optionnel selon ce que fait le mod.

**Ordre de chargement** (voir `index.html`) : Phaser → toutes les données et tous les managers du
jeu → tous les mods du manifeste, dans l'ordre → `js/main.js` (qui démarre Phaser.Game). Un mod
peut donc lire/modifier n'importe quelle donnée du jeu dans `init()`, et le jeu n'a pas encore
démarré à ce moment-là.

## Modifier des données existantes
Les modules de données exposent leurs tableaux/objets par référence (ex.
`NEBUSTION.Shop.DAILY_POOL`, `NEBUSTION.Shop.DAILY_INDEX`). Un mod peut donc les compléter
directement dans `init()` :
```js
NEB.Shop.DAILY_POOL.push({ id: 'mod_xxx', kind: 'resource', label: '...', res: { dust: 500 }, cost: { crystal: 50 } });
NEB.Shop.DAILY_INDEX['mod_xxx'] = NEB.Shop.DAILY_POOL[NEB.Shop.DAILY_POOL.length - 1];
```
**Préfixez toujours vos identifiants** (`mod_...`) pour ne jamais entrer en collision avec un id
du jeu ou d'un autre mod — `register()` refuse un `id` de mod déjà pris, mais rien n'empêche deux
mods d'écraser la même clé dans une donnée du jeu si vous ne préfixez pas.

## Mods fournis (activés par défaut)
| Fichier | Ce qu'il fait |
|---|---|
| `mods/exemple_mod.js` | Modèle de base : ajoute une offre à la boutique quotidienne, lit le stock de cristaux, affiche un badge (haut-droite) listant les mods actifs pendant 5 s. |
| `mods/hud_fps.js` | Compteur FPS en haut à gauche (branché sur `game.loop.actualFps`). Toucher le badge le masque/l'affiche. |
| `mods/temps_de_jeu.js` | Badge en bas à gauche : temps de jeu total (cumulé entre sessions, stocké à part en `localStorage`, indépendant de la sauvegarde du jeu) + temps de la session en cours. |
| `mods/outils_debug.js` | Panneau en bas à droite, **visible uniquement avec `?debug=1` dans l'URL** (même convention que le reste du jeu) : boutons « +1000 de chaque ressource », « Sauvegarder maintenant », « Logger l'état des ressources », « Lister les mods actifs ». |

Copiez n'importe lequel pour démarrer votre propre mod — `exemple_mod.js` est le plus commenté.

## Limites à connaître
- Un mod tourne dans le **même contexte global** que le jeu (pas de bac à sable) : il peut donc
  aussi bien enrichir une donnée que la corrompre s'il est mal écrit. Testez vos mods un par un.
- `NEBUSTION.Mods.list()` et `NEBUSTION.Mods.errors()` (console du navigateur) donnent à tout
  moment la liste des mods chargés et les erreurs rencontrées.
- Ce système ne fournit pas de mise à jour à chaud : un mod modifié n'est repris qu'au rechargement
  de la page (F5 / relance de l'appli).
