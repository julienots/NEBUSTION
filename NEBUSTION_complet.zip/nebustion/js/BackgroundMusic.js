// NEBUSTION - musique de fond spatiale, générée en code (Web Audio API).
// Nappes synthétiques douces en boucle + petites notes scintillantes éparses.
// Aucun fichier externe : pas de dépendance réseau, pas de droits d'auteur.
(function () {
  'use strict';

  var ctx = null, master = null, delayNode = null, feedback = null, started = false;
  var chordTimer = null, twinkleTimer = null;
  var VOLUME = 0.045; // "pas fort" : très discret, sous les bruitages/l'intro

  // Progression d'accords façon nappe spatiale (La mineur -> Fa -> Do -> Sol), en Hz.
  var CHORDS = [
    [110.00, 164.81, 220.00, 261.63],  // Am  (A2 E3 A3 C4)
    [87.31,  130.81, 174.61, 220.00],  // Fmaj(F2 C3 F3 A3)
    [130.81, 196.00, 261.63, 329.63],  // Cmaj(C3 G3 C4 E4)
    [98.00,  146.83, 196.00, 246.94]   // Gmaj(G2 D3 G3 B3)
  ];
  var TWINKLE_NOTES = [440.00, 523.25, 587.33, 659.25, 783.99, 880.00]; // pentatonique aiguë

  function ensureContext() {
    if (ctx) return;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    ctx = new AC();

    master = ctx.createGain();
    var initial = (window.NEBUSTION && NEBUSTION.Settings) ? NEBUSTION.Settings.get() : null;
    VOLUME = initial ? (initial.musicOn ? initial.musicVolume : 0) : VOLUME;
    master.gain.value = VOLUME;
    master.connect(ctx.destination);

    // Petit écho spatial pour les notes scintillantes.
    delayNode = ctx.createDelay(2.0);
    delayNode.delayTime.value = 0.55;
    feedback = ctx.createGain();
    feedback.gain.value = 0.32;
    var delayFilter = ctx.createBiquadFilter();
    delayFilter.type = 'lowpass';
    delayFilter.frequency.value = 2200;
    delayNode.connect(feedback);
    feedback.connect(delayFilter);
    delayFilter.connect(delayNode);
    delayNode.connect(master);
  }

  function playChord(freqs, duration) {
    var now = ctx.currentTime;
    var attack = 3.0, release = 3.5;
    var chordGain = ctx.createGain();
    chordGain.gain.setValueAtTime(0, now);
    chordGain.gain.linearRampToValueAtTime(1, now + attack);
    chordGain.gain.setValueAtTime(1, now + duration - release);
    chordGain.gain.linearRampToValueAtTime(0, now + duration);
    chordGain.connect(master);

    var filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 1100;
    filter.Q.value = 0.4;
    filter.connect(chordGain);

    freqs.forEach(function (f, i) {
      var osc = ctx.createOscillator();
      osc.type = i === 0 ? 'triangle' : 'sine';
      osc.frequency.value = f;
      var detune = ctx.createOscillator();
      detune.type = osc.type;
      detune.frequency.value = f;
      detune.detune.value = 6; // léger chorus pour une texture "nappe"

      var mix = ctx.createGain();
      mix.gain.value = 0.22;
      osc.connect(mix); detune.connect(mix);
      mix.connect(filter);

      osc.start(now); detune.start(now);
      osc.stop(now + duration + 0.1);
      detune.stop(now + duration + 0.1);
    });
  }

  function scheduleChords() {
    var i = 0;
    var CHORD_DURATION = 10.5; // secondes, avec fondu enchaîné
    function next() {
      if (!ctx) return;
      playChord(CHORDS[i % CHORDS.length], CHORD_DURATION);
      i++;
      chordTimer = setTimeout(next, (CHORD_DURATION - 3.2) * 1000);
    }
    next();
  }

  function playTwinkle() {
    if (!ctx) return;
    var now = ctx.currentTime;
    var freq = TWINKLE_NOTES[Math.floor(Math.random() * TWINKLE_NOTES.length)];
    var osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.value = freq;

    var g = ctx.createGain();
    g.gain.setValueAtTime(0, now);
    g.gain.linearRampToValueAtTime(0.16, now + 0.05);
    g.gain.exponentialRampToValueAtTime(0.0001, now + 1.4);

    var pan = (ctx.createStereoPanner ? ctx.createStereoPanner() : null);
    osc.connect(g);
    if (pan) {
      pan.pan.value = (Math.random() * 1.6) - 0.8;
      g.connect(pan);
      pan.connect(master);
      pan.connect(delayNode);
    } else {
      g.connect(master);
      g.connect(delayNode);
    }
    osc.start(now);
    osc.stop(now + 1.5);
  }

  function scheduleTwinkles() {
    function next() {
      playTwinkle();
      var delay = 3200 + Math.random() * 5200; // toutes les 3,2 à 8,4s
      twinkleTimer = setTimeout(next, delay);
    }
    twinkleTimer = setTimeout(next, 4000);
  }

  function beginScheduling() {
    if (started) return;
    started = true;
    scheduleChords();
    scheduleTwinkles();
  }

  function start() {
    if (window.NEBUSTION && NEBUSTION.Settings && !NEBUSTION.Settings.get().musicOn) return; // désactivée dans les Paramètres
    ensureContext();
    if (!ctx) return;
    // Important : on ne programme les accords/scintillements qu'une fois le
    // contexte réellement "running" (sinon, tant qu'il est suspendu, son
    // horloge interne est gelée et tout s'accumulerait pour partir d'un coup
    // au réveil). On attend donc la confirmation avant de lancer la boucle.
    if (ctx.state === 'running') { beginScheduling(); return; }
    try {
      var p = ctx.resume();
      if (p && p.then) p.then(function () { if (ctx.state === 'running') beginScheduling(); }).catch(function () {});
    } catch (_) {}
    if (!ctx._nebuStateListener) {
      ctx._nebuStateListener = true;
      ctx.addEventListener('statechange', function () {
        if (ctx.state === 'running') beginScheduling();
      });
    }
  }

  function setVolume(v) {
    if (master) master.gain.setTargetAtTime(v, ctx.currentTime, 0.5);
    VOLUME = v;
  }

  function stop() {
    if (chordTimer) clearTimeout(chordTimer);
    if (twinkleTimer) clearTimeout(twinkleTimer);
    if (master && ctx) master.gain.setTargetAtTime(0, ctx.currentTime, 0.6);
  }

  function applySettings(st) {
    if (!st) return;
    if (!master) { VOLUME = st.musicOn ? st.musicVolume : 0; return; }
    setVolume(st.musicOn ? st.musicVolume : 0);
  }

  // Économie de batterie : coupe le contexte audio quand l'onglet est masqué.
  document.addEventListener('visibilitychange', function () {
    if (!ctx) return;
    try { if (document.hidden) ctx.suspend(); else if (started) ctx.resume(); } catch (_) {}
  });

  window.nebustionBgMusic = { start: start, stop: stop, setVolume: setVolume };

  // Réagit aux changements faits depuis le menu Paramètres : ajuste le volume
  // à la volée, ou démarre/arrête la musique si on/off est basculé.
  if (window.NEBUSTION && NEBUSTION.Settings && NEBUSTION.Settings.onChange) {
    NEBUSTION.Settings.onChange(function (st) {
      if (st.musicOn) { applySettings(st); start(); }
      else { setVolume(0); }
    });
  }

  // Comme pour l'intro : on tente de démarrer tout de suite, et on relance
  // au premier geste utilisateur si le navigateur a bloqué l'audio.
  try { start(); } catch (_) {}
  document.addEventListener('pointerdown', start, { capture: true, once: true });
  document.addEventListener('touchstart', start, { capture: true, once: true });
  document.addEventListener('keydown', start, { capture: true, once: true });
})();
