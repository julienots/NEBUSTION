/**
 * NEBUSTION - PlanetScene
 * Base spatiale Nexus-01 : plateforme, bâtiments (Commandement, Hangar, Laboratoire, Défense),
 * 5 gisements avec portiques d'extraction animés, drones miniers, récolte au tap,
 * caisses de ravitaillement, HUD de ressources permanent.
 * Amélioration : tap sur un bâtiment (ou sur le niveau / la flèche ▲ d'un extracteur) → panneau avec coût, effet et bouton AMÉLIORER.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.PlanetScene = class PlanetScene extends Phaser.Scene {
  constructor() {
    super('PlanetScene');
  }

  create() {
    var w = this.scale.width, h = this.scale.height;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(300, 5, 7, 15);

    this.nodes = {}; this.drones = []; this.pod = null; this._podTimer = 0; this._ambient = 0;
    this._buildingBoxes = {}; this._buildingDefs = {};
    this._infoPanelKey = null; this._panelOpen = false; this._upAcc = 0;

    NEBUSTION.SceneBackground.build(this, { withPlanet: false });
    this._buildGuardianHero();
    this.fx = new NEBUSTION.FX(this);

    // Premier vrai passage "en jeu" : on coupe l'intro et on lance la musique
    // de fond spatiale (une seule fois, pas à chaque retour sur la planète).
    if (!window.__nebustionGameEntered) {
      window.__nebustionGameEntered = true;
      try { if (window.nebustionExtraAudio) window.nebustionExtraAudio.stopIntro(); } catch (_) {}
      try { if (window.nebustionBgMusic) window.nebustionBgMusic.start(); } catch (_) {}
    }

    this._buildPlatform();
    this._buildBuildings();
    this._buildNodes();
    this._buildDrones();
    this._buildHeader();
    this._buildInfoPanel();

    this.beamGfx = this.add.graphics().setDepth(1049);
    this.hud = NEBUSTION.HUD.attach(this);
    new NEBUSTION.BottomNav(this, 'planet');

    this._schedulePod();
    this.events.once('shutdown', () => {
      if (this.pod) this.pod.destroy(); this.pod = null;
      if (this._guardianFadeMask) { this._guardianFadeMask.destroy(); this._guardianFadeMask = null; }
    });
  }

  /**
   * Héros gardien : le meilleur héros de l'équipe (le plus puissant) veille sur Nexus-01,
   * immense et en transparence tout au fond du décor, comme une divinité qui observe la
   * base depuis l'espace. Rendu en mode additif à faible opacité : les étoiles et nébuleuses
   * restent toujours visibles à travers lui, aucune surface opaque n'est jamais ajoutée.
   */
  _buildGuardianHero() {
    var w = this.scale.width, h = this.scale.height;
    var H = NEBUSTION.Heroes, C = NEBUSTION.Combat;
    if (!H || !C) return;

    var heroId = null;
    try {
      var team = C.getTeam() || [];
      if (!team.length && C.defaultTeam) team = C.defaultTeam();
      var bestPower = -1;
      team.forEach(function (id) {
        var def = H.get(id);
        if (!def) return;
        var lvl = C.heroLevel ? C.heroLevel(id) : 1;
        var power = H.statsAtLevel(def, lvl).power;
        if (power > bestPower) { bestPower = power; heroId = id; }
      });
    } catch (e) { heroId = null; }
    if (!heroId) return;

    var key = H.portraitKey(heroId);
    if (!this.textures.exists(key)) return;

    var cx = w / 2, topY = 190;
    var portraitH = (NEBUSTION.HeroTextures && NEBUSTION.HeroTextures.PORTRAIT_H) || 380;
    var scale = (h * 0.6) / portraitH;

    // Aura douce derrière le héros, pour renforcer la présence divine sans jamais masquer le fond.
    var halo = this.add.image(cx, topY + h * 0.24, 'tex_glow_cyan')
      .setScale(3.6).setAlpha(0.15).setBlendMode(Phaser.BlendModes.ADD).setDepth(-56).setTint(0x8fd8ff);
    this.tweens.add({ targets: halo, alpha: 0.24, scale: 3.9, duration: 3600, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });

    var guardian = this.add.image(cx, topY, key)
      .setOrigin(0.5, 0)
      .setScale(scale)
      .setAlpha(0.17)
      .setBlendMode(Phaser.BlendModes.ADD)
      .setTint(0xcfe9ff)
      .setDepth(-55);

    // Le portrait est une image rectangulaire pleine (fond opaque) : sans masque, ses bords
    // tranchent net contre les étoiles. On applique un fondu doux sur les 4 côtés pour que
    // le héros se dissolve progressivement dans le décor, sans aucun contour visible.
    var maskKey = this._ensureGuardianFadeMask();
    var maskImg = this.make.image({ x: cx, y: topY, key: maskKey, add: false }).setOrigin(0.5, 0).setScale(scale);
    guardian.setMask(maskImg.createBitmapMask());
    this._guardianFadeMask = maskImg;

    // Dérive lente et respiration discrète : le gardien est vivant, jamais figé, jamais envahissant.
    this.tweens.add({ targets: guardian, y: topY - 16, duration: 5400, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    this.tweens.add({ targets: guardian, alpha: 0.23, duration: 3200, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });

    this._guardianHero = guardian;
    this._guardianHalo = halo;
  }

  /**
   * Génère (une seule fois, mise en cache par clé de texture) un masque de fondu doux :
   * blanc opaque au centre, transparent sur les 4 bords. Utilisé pour dissoudre les bords
   * rectangulaires nets des portraits de héros (PNG à fond plein) quand ils sont affichés
   * en grand format et en transparence, comme le héros gardien.
   */
  _ensureGuardianFadeMask() {
    var key = 'tex_guardian_fade';
    if (this.textures.exists(key)) return key;
    var w = (NEBUSTION.HeroTextures && NEBUSTION.HeroTextures.PORTRAIT_W) || 300;
    var h = (NEBUSTION.HeroTextures && NEBUSTION.HeroTextures.PORTRAIT_H) || 380;
    var tex = this.textures.createCanvas(key, w, h);
    var ctx = tex.context;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, h);
    ctx.globalCompositeOperation = 'destination-in';

    // Fondu vertical : marge fine en haut (la tête se détache déjà sur le ciel), large en bas
    // (c'est le bord qui tranchait le plus net contre la plateforme/l'espace).
    var topF = h * 0.12, botF = h * 0.32;
    var vGrad = ctx.createLinearGradient(0, 0, 0, h);
    vGrad.addColorStop(0, 'rgba(0,0,0,0)');
    vGrad.addColorStop(topF / h, 'rgba(0,0,0,1)');
    vGrad.addColorStop(1 - botF / h, 'rgba(0,0,0,1)');
    vGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = vGrad;
    ctx.fillRect(0, 0, w, h);

    // Fondu horizontal : mêmes marges à gauche et à droite.
    var sideF = w * 0.28;
    var hGrad = ctx.createLinearGradient(0, 0, w, 0);
    hGrad.addColorStop(0, 'rgba(0,0,0,0)');
    hGrad.addColorStop(sideF / w, 'rgba(0,0,0,1)');
    hGrad.addColorStop(1 - sideF / w, 'rgba(0,0,0,1)');
    hGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = hGrad;
    ctx.fillRect(0, 0, w, h);

    ctx.globalCompositeOperation = 'source-over';
    tex.refresh();
    return key;
  }

  _buildHeader() {
    var w = this.scale.width;

    // Retour explicite vers le menu central : Nexus ne doit jamais être une impasse.
    // Placé en haut à gauche, hors de la zone des bâtiments et du HUD.
    var back = new NEBUSTION.Button(this, 92, 92, {
      width: 150, height: 46, label: '← MENU CENTRAL',
      accentColor: 0x394869, fontSize: '14px',
      onClick: () => {
        try { if (this.fx) this.fx.vibrate(15); } catch (_) {}
        this.scene.start('MainMenuScene');
      }
    });
    back.setDepth(1200);

    this.add.text(w / 2, 138, 'NEXUS-01', {
      fontFamily: 'Arial, sans-serif', fontSize: '28px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(50).setShadow(0, 0, '#00e5ff', 10, true, true);

    this.add.text(w / 2, 170, 'Touchez un gisement pour récolter', {
      fontFamily: 'Arial, sans-serif', fontSize: '19px', color: '#8ea0c8'
    }).setOrigin(0.5).setDepth(50);
  }

  _buildPlatform() {
    var w = this.scale.width, h = this.scale.height;
    var g = this.add.graphics().setDepth(-10);
    var cx = w / 2, cy = h * 0.62;

    // Plateforme agrandie (module 27B) : davantage de champ libre autour des bâtiments et gisements.
    var pw = w * 0.99, ph = h * 0.465;
    g.fillStyle(0x0e1730, 1);
    g.fillEllipse(cx, cy, pw, ph);
    g.lineStyle(2, 0x2e9eff, 0.5);
    g.strokeEllipse(cx, cy, pw, ph);

    for (var i = 1; i <= 3; i++) {
      g.lineStyle(1, 0x00e5ff, 0.12 * i);
      g.strokeEllipse(cx, cy, pw * (i / 3.6), ph * (i / 3.6));
    }
    g.lineStyle(1, 0x2e9eff, 0.25);
    for (var a = 0; a < 6; a++) {
      var ang = (a / 6) * Math.PI * 2;
      g.lineBetween(cx, cy, cx + Math.cos(ang) * pw * 0.455, cy + Math.sin(ang) * ph * 0.475);
    }
  }

  _buildBuildings() {
    var w = this.scale.width, h = this.scale.height;
    var cx = w / 2, cy = h * 0.62;
    var R = NEBUSTION.Resources, E = NEBUSTION.Economy;

    // Le SYMTOR est volontairement placé en hauteur et beaucoup plus visible :
    // c'est le bâtiment spécial de la base, il doit être immédiatement identifiable.
    var buildings = [
      // Vaisseau-cargo de stockage : posé à l'écart sur le côté, en vol stationnaire au-dessus
      // de la plateforme (dans la seule zone encore libre, au-dessus de l'extracteur de cristaux,
      // sans jamais toucher sa zone tactile). Bâtiment déjà géré par l'économie (capacité ×1,5/niveau)
      // mais qui n'avait jamais de représentation sur la planète.
      { key: 'storage', x: cx - 205, y: cy - 380, color: 0x2dd4bf, scale: 0.9 },
      // Amplificateur quantique (module 27B) : en miroir du Ravitailleur, dans la zone haute
      // symétrique restée vide. Nouveau bâtiment : booste la production totale de toutes les ressources.
      { key: 'amplifier', x: cx + 205, y: cy - 380, color: 0xffa63d, scale: 0.9 },
      { key: 'symtor', x: cx, y: cy - 145, color: 0xd77cff, scale: 1.18 },
      { key: 'qg', x: cx, y: cy + 20, color: 0x5fd97a, scale: 0.92 },
      // Le Centre de commandement est placé juste à côté de l'extracteur de cristaux,
      // en miroir du Laboratoire (côté droit), pour rester sur la même grille que les autres bâtiments.
      // Écarts légèrement augmentés (plateforme agrandie) pour laisser plus de champ entre les bâtiments.
      { key: 'command', x: cx - 152, y: cy - 8, color: 0x00e5ff, scale: 1.02 },
      { key: 'lab', x: cx + 152, y: cy - 8, color: 0x6c3ce9, scale: 0.92 },
      { key: 'hangar', x: cx - 162, y: cy + 122, color: 0xffd166, scale: 0.88 },
      { key: 'defense', x: cx + 162, y: cy + 122, color: 0xff4d6d, scale: 0.82 }
    ];

    buildings.forEach((b) => {
      b.label = b.key === 'symtor' ? 'Symtor' : E.BUILDINGS[b.key].name;
      var container = this.add.container(b.x, b.y).setScale(b.scale).setDepth(Math.round(b.y));
      this._drawBuilding(container, b);
      this._buildingBoxes[b.key] = { container: container, scale: b.scale, y: b.y };
      this._buildingDefs[b.key] = b;

      var hit = this.add.zone(0, -20, 120, 140).setOrigin(0.5).setInteractive({ useHandCursor: true });
      container.add(hit);

      hit.on('pointerover', () => this.tweens.add({ targets: container, scale: b.scale * 1.06, duration: 120 }));
      hit.on('pointerout', () => this.tweens.add({ targets: container, scale: b.scale, duration: 120 }));
      hit.on('pointerdown', () => {
        this.tweens.add({ targets: container, scale: b.scale * 0.96, duration: 60, yoyo: true });
        this._showInfoPanel(b);
      });

      var beacon = this.add.circle(0, b.key === 'storage' ? -62 : (b.topY || -110), 4, b.color, 1).setBlendMode(Phaser.BlendModes.ADD);
      container.add(beacon);
      this.tweens.add({ targets: beacon, alpha: 0.2, duration: 700 + Math.random() * 500, yoyo: true, repeat: -1 });
      // Skin de bâtiment équipé (module Personnalisation) : balise recolorée + aura et effet animé.
      var bSkin = NEBUSTION.SkinManager && NEBUSTION.SkinManager.equippedSkin('building', b.key);
      if (bSkin) {
        if (beacon.setFillStyle) beacon.setFillStyle(bSkin.aura, 1);
        NEBUSTION.SkinFX.attach(this, container, null, bSkin, 120, 150, { x: 0, y: -50 });
      }

      var badgeLevel = b.key === 'symtor' ? (NEBUSTION.SymbioteManager.state().built ? 'SYMBIOTE • BIO' : 'SYMTOR • À CONSTRUIRE') : ('Nv.' + R.level(b.key));
      var badgeY = b.key === 'symtor' ? -184 : (b.key === 'storage' ? -70 : (b.topY ? b.topY - 18 : -128));
      var badge = this.add.text(0, badgeY, badgeLevel, {
        fontFamily: 'Arial, sans-serif', fontSize: b.key === 'symtor' ? '15px' : '14px', fontStyle: 'bold',
        color: b.key === 'symtor' ? '#ffffff' : '#0b1224',
        backgroundColor: b.key === 'symtor' ? '#6f20a8' : '#eaf2ff', padding: { x: 8, y: 3 },
        stroke: b.key === 'symtor' ? '#d77cff' : undefined, strokeThickness: b.key === 'symtor' ? 2 : 0
      }).setOrigin(0.5);
      container.add(badge);
      this._buildingBoxes[b.key].badge = badge;
    });

    // Point de dépôt des drones : sommet du Commandement
    this.depotBase = { x: cx, y: cy - 120 };
  }

  _drawBuilding(container, b) {
    var g = this.add.graphics();
    var color = b.color;

    // Vaisseau-cargo dédié au Stockage : une silhouette de vaisseau en vol stationnaire,
    // pas un immeuble — coque allongée, conteneurs de fret sur le dos, réacteurs pulsants.
    if (b.key === 'storage') {
      // Traînée d'énergie et ombre au sol, sous la coque en vol stationnaire.
      g.fillStyle(0x000000, 0.3);
      g.fillEllipse(-5, 46, 150, 20);
      g.fillStyle(color, 0.16);
      g.fillEllipse(-5, 6, 170, 34);

      // Ailerons arrière.
      g.fillStyle(0x0e2f31, 1);
      g.fillTriangle(-70, -34, -98, -8, -70, -4);
      g.fillTriangle(-70, 0, -98, 28, -70, 24);
      g.lineStyle(2, color, 0.6);
      g.strokeTriangle(-70, -34, -98, -8, -70, -4);
      g.strokeTriangle(-70, 0, -98, 28, -70, 24);

      // Coque principale, effilée vers l'avant (à droite).
      g.fillGradientStyle(0x123c40, 0x1c5a5c, 0x08181a, 0x08181a, 1);
      g.fillRoundedRect(-76, -32, 148, 38, 17);
      g.lineStyle(2.5, color, 0.9);
      g.strokeRoundedRect(-76, -32, 148, 38, 17);

      // Nez effilé.
      g.fillStyle(0x1c5a5c, 1);
      g.beginPath();
      g.moveTo(70, -28); g.lineTo(98, -12); g.lineTo(70, 4); g.closePath();
      g.fillPath();
      g.lineStyle(2.5, color, 0.9);
      g.beginPath();
      g.moveTo(70, -28); g.lineTo(98, -12); g.lineTo(70, 4); g.closePath();
      g.strokePath();

      // Verrière du cockpit, lumineuse.
      g.fillStyle(0xcdfff5, 0.9);
      g.fillEllipse(54, -12, 22, 12);

      // Conteneurs de fret arrimés sur le dos — le « stockage » lui-même, bien visible.
      var crateColors = [0xffd166, 0xff6ec7, 0xc9d4ea];
      for (var i = 0; i < 3; i++) {
        g.fillStyle(crateColors[i], 0.92);
        g.fillRoundedRect(-58 + i * 39, -54, 32, 22, 5);
        g.lineStyle(1.5, 0x0a1224, 0.55);
        g.strokeRoundedRect(-58 + i * 39, -54, 32, 22, 5);
      }

      // Sabords lumineux le long de la coque.
      g.fillStyle(0x9ffff0, 0.85);
      for (var p = 0; p < 4; p++) g.fillCircle(-46 + p * 26, -13, 3);

      container.add(g);

      var label = this.add.text(0, -12, 'RAVITAILLEUR', {
        fontFamily: 'Arial, sans-serif', fontSize: '11px', fontStyle: '900', color: '#eaf2ff',
        stroke: '#08181a', strokeThickness: 3
      }).setOrigin(0.5);
      container.add(label);

      // Réacteurs arrière : lueur additive pulsante.
      var jet1 = this.add.circle(-84, -18, 7, color, 0.85).setBlendMode(Phaser.BlendModes.ADD);
      var jet2 = this.add.circle(-84, -2, 7, color, 0.85).setBlendMode(Phaser.BlendModes.ADD);
      container.add([jet1, jet2]);
      this.tweens.add({ targets: [jet1, jet2], alpha: 0.35, scale: 1.5, duration: 480 + Math.random() * 200, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });

      // Vol stationnaire : légère oscillation verticale, jamais posé au sol.
      this.tweens.add({ targets: container, y: b.y - 12, duration: 2600, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
      return;
    }

    // Design organique dédié au SYMTOR : silhouette plus haute, capsule centrale,
    // tentacules et noyau vivant violet. Les autres bâtiments gardent leur design techno.
    if (b.key === 'symtor') {
      g.fillStyle(0x000000, 0.42);
      g.fillEllipse(0, 8, 150, 34);

      // Aura extérieure.
      g.fillStyle(0x6b21a8, 0.16);
      g.fillCircle(0, -72, 92);
      g.lineStyle(4, 0xf0a6ff, 0.8);
      g.strokeCircle(0, -72, 72);
      g.lineStyle(2, 0x7b2cff, 0.55);
      g.strokeCircle(0, -72, 88);

      // Base bio-mécanique.
      g.fillGradientStyle(0x35115f, 0x5e1d88, 0x0a1024, 0x120b25, 1);
      g.fillRoundedRect(-62, -18, 124, 28, 12);
      g.lineStyle(3, color, 0.95);
      g.strokeRoundedRect(-62, -18, 124, 28, 12);

      // Capsule vivante.
      g.fillGradientStyle(0x8c2be8, 0xd65cff, 0x240b42, 0x0c0719, 1);
      g.fillRoundedRect(-38, -128, 76, 116, 30);
      g.lineStyle(3, 0xf0a6ff, 0.95);
      g.strokeRoundedRect(-38, -128, 76, 116, 30);
      g.fillStyle(0xeaa7ff, 0.72);
      g.fillEllipse(0, -73, 25, 60);
      g.fillStyle(0xffffff, 0.95);
      g.fillCircle(-8, -84, 5);

      // Tentacules asymétriques.
      g.lineStyle(9, 0x4d146f, 0.95);
      g.beginPath(); g.moveTo(-38, -36); g.lineTo(-68, -4); g.lineTo(-82, -34); g.strokePath();
      g.beginPath(); g.moveTo(38, -38); g.lineTo(68, -6); g.lineTo(84, -38); g.strokePath();
      g.lineStyle(5, 0xd77cff, 0.85);
      g.beginPath(); g.moveTo(-30, -24); g.lineTo(-45, 8); g.lineTo(-58, -6); g.strokePath();
      g.beginPath(); g.moveTo(30, -24); g.lineTo(48, 7); g.lineTo(60, -10); g.strokePath();

      // Couronne / énergie au sommet.
      g.lineStyle(4, 0xd77cff, 0.9);
      g.lineBetween(0, -128, 0, -154);
      g.fillStyle(0xffffff, 1);
      g.fillCircle(0, -157, 7);
      g.fillStyle(0xd77cff, 0.3);
      g.fillCircle(0, -157, 18);

      // Plaque nominative intégrée au bâtiment.
      g.fillStyle(0x090617, 0.95);
      g.fillRoundedRect(-58, -5, 116, 22, 7);
      g.lineStyle(2, 0xd77cff, 0.9);
      g.strokeRoundedRect(-58, -5, 116, 22, 7);
      container.add(g);

      var label = this.add.text(0, -73, 'SYMTOR', {
        fontFamily: 'Arial, sans-serif', fontSize: '16px', fontStyle: '900', color: '#ffffff',
        stroke: '#5d1a86', strokeThickness: 5
      }).setOrigin(0.5);
      container.add(label);

      // Pulsation permanente du noyau et des tentacules.
      var pulse = this.add.circle(0, -73, 20, 0xf0a6ff, 0.16).setBlendMode(Phaser.BlendModes.ADD);
      container.add(pulse);
      this.tweens.add({ targets: pulse, scale: 1.55, alpha: 0.02, duration: 950, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
      return;
    }

    this._drawIsoBuilding(container, g, b);
  }

  // ---- Teintes utilitaires (multiplication / mélange de couleurs 0xRRGGBB) ----
  _shade(c, f) {
    var r = Math.min(255, Math.round(((c >> 16) & 255) * f)), gg = Math.min(255, Math.round(((c >> 8) & 255) * f)), bb = Math.min(255, Math.round((c & 255) * f));
    return (r << 16) | (gg << 8) | bb;
  }
  _mixColor(a, b, t) {
    var r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t), gg = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t), bb = Math.round((a & 255) * (1 - t) + (b & 255) * t);
    return (r << 16) | (gg << 8) | bb;
  }

  /**
   * Bâtiments 3D (vue isométrique) : chaque bâtiment est fait de volumes à 3 faces (gauche sombre, droite
   * moyenne, toit clair), fenêtres allumées en perspective, arêtes néon, dalle lumineuse, ombre portée,
   * et un couronnement propre à sa fonction (QG à étages, radar, dôme de labo, hangar, tourelle).
   * Renseigne b.topY (sommet visible) pour placer la balise et le badge de niveau.
   */
  _drawIsoBuilding(container, g, b) {
    var self = this, color = b.color, key = b.key, ADD = Phaser.BlendModes.ADD;
    var seed = key.charCodeAt(0) * 17 + key.length * 31 + 3;
    function rnd() { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; }
    function P(A, B, u, v, h) { return { x: A.x + (B.x - A.x) * u, y: A.y + (B.y - A.y) * u - v * h }; }
    function poly(pts, fill, a) { g.fillStyle(fill, a); g.fillPoints(pts, true); }
    function fq(A, B, h, u0, u1, v0, v1, fill, a) { poly([P(A, B, u0, v0, h), P(A, B, u1, v0, h), P(A, B, u1, v1, h), P(A, B, u0, v1, h)], fill, a); }
    function face(A, B, h, fill) {
      poly([A, B, { x: B.x, y: B.y - h }, { x: A.x, y: A.y - h }], fill, 1);
      fq(A, B, h, 0, 1, 0, 0.22, 0x000000, 0.30);      // ombrage : plus sombre au pied
      fq(A, B, h, 0, 1, 0.22, 0.5, 0x000000, 0.12);
      fq(A, B, h, 0, 1, 0.9, 1, 0xffffff, 0.07);       // léger reflet en haut
    }
    function windows(A, B, h, cols, rows, alpha) {
      var cw = 0.76 / cols, ch = 0.74 / rows;
      for (var r = 0; r < rows; r++) for (var c = 0; c < cols; c++) {
        var u0 = 0.12 + c * cw + cw * 0.16, u1 = 0.12 + (c + 1) * cw - cw * 0.16, v0 = 0.12 + r * ch + ch * 0.2, v1 = 0.12 + (r + 1) * ch - ch * 0.2;
        var lit = rnd() > 0.22;
        fq(A, B, h, u0, u1, v0, v1, lit ? self._mixColor(color, 0xffffff, 0.35) : 0x0a1224, lit ? alpha : 0.85);
      }
    }
    function box(cx, by, hw, h, base, wc, wr) {
      var dy = hw * 0.5;
      var L = { x: cx - hw, y: by }, F = { x: cx, y: by + dy }, Rr = { x: cx + hw, y: by }, Bk = { x: cx, y: by - dy };
      face(L, F, h, self._shade(base, 0.5));
      face(F, Rr, h, self._shade(base, 0.8));
      var T = [{ x: L.x, y: L.y - h }, { x: F.x, y: F.y - h }, { x: Rr.x, y: Rr.y - h }, { x: Bk.x, y: Bk.y - h }];
      poly(T, self._shade(base, 1.3), 1);
      if (wc) { windows(L, F, h, wc, wr, 0.6); windows(F, Rr, h, wc, wr, 0.95); }
      g.lineStyle(2, color, 0.95); g.strokePoints(T, true);
      g.lineStyle(2.5, color, 0.9); g.lineBetween(F.x, F.y, F.x, F.y - h);
      g.lineStyle(1.5, color, 0.45); g.lineBetween(L.x, L.y, L.x, L.y - h); g.lineBetween(Rr.x, Rr.y, Rr.x, Rr.y - h);
      g.lineStyle(1.5, color, 0.5); g.lineBetween(L.x, L.y, F.x, F.y); g.lineBetween(F.x, F.y, Rr.x, Rr.y);
      return { L: L, F: F, R: Rr, Bk: Bk, h: h, hw: hw, dy: dy, top: { x: cx, y: by - h } };
    }

    // halo néon derrière le bâtiment
    container.add(this.add.image(0, -36, 'tex_glow_white').setTint(color).setDisplaySize(200, 150).setAlpha(0.2).setBlendMode(ADD));

    // ombre portée + dalle de fondation lumineuse
    g.fillStyle(0x000000, 0.42); g.fillEllipse(8, 24, 156, 48);
    var slab = box(0, 4, 64, 9, 0x1a2745, 0, 0);
    var ins = [{ x: slab.top.x - 52, y: slab.top.y }, { x: slab.top.x, y: slab.top.y + 26 }, { x: slab.top.x + 52, y: slab.top.y }, { x: slab.top.x, y: slab.top.y - 26 }];
    g.lineStyle(1.5, color, 0.5); g.strokePoints(ins, true);

    var by = -5, tip = -108, dish = null, orb = null, dishY = 0;
    var base = self._mixColor(0x2a3d66, color, 0.22);

    if (key === 'qg') {
      // Quartier général : trois étages en gradins + mât d'antenne
      var q1 = box(0, by, 48, 40, base, 3, 3);
      var q2 = box(0, by - 40, 34, 30, self._shade(base, 1.1), 2, 2);
      poly([{ x: -18, y: q2.top.y }, { x: 0, y: q2.top.y + 9 }, { x: 18, y: q2.top.y }, { x: 0, y: q2.top.y - 9 }], color, 0.5);
      g.lineStyle(3, color, 0.95); g.lineBetween(0, q2.top.y, 0, q2.top.y - 32);
      g.fillStyle(color, 1); g.fillCircle(0, q2.top.y - 34, 4);
      g.lineStyle(2, 0xffffff, 0.8); g.lineBetween(-9, q2.top.y - 22, 9, q2.top.y - 22);
      tip = q2.top.y - 34;
    } else if (key === 'command') {
      // Centre de commandement : haute tour + radar rotatif
      box(0, by, 42, 24, base, 3, 1);
      var c2 = box(0, by - 24, 30, 54, self._shade(base, 1.1), 2, 4);
      g.lineStyle(3, color, 0.9); g.lineBetween(16, c2.top.y + 2, 16, c2.top.y - 20);
      g.fillStyle(0xff6a78, 1); g.fillCircle(16, c2.top.y - 21, 3);
      dishY = c2.top.y - 2; tip = c2.top.y - 32;
    } else if (key === 'lab') {
      // Laboratoire : bloc vitré + dôme énergétique
      var l1 = box(0, by, 44, 46, base, 3, 3);
      var ty = l1.top.y;
      g.fillStyle(0x0a1224, 0.9); g.fillEllipse(0, ty, 54, 27);
      g.lineStyle(2.5, color, 0.95); g.strokeEllipse(0, ty, 54, 27);
      g.fillStyle(self._mixColor(color, 0xffffff, 0.35), 0.28); g.fillEllipse(0, ty - 15, 48, 46);
      g.lineStyle(2, self._mixColor(color, 0xffffff, 0.5), 0.9); g.strokeEllipse(0, ty - 15, 48, 46);
      g.fillStyle(0xffffff, 0.35); g.fillEllipse(-10, ty - 26, 10, 16);
      g.lineStyle(3, color, 0.9); g.lineBetween(0, ty - 38, 0, ty - 54);
      g.fillStyle(0xffffff, 1); g.fillCircle(0, ty - 55, 3.5);
      orb = { x: 0, y: ty - 14 }; tip = ty - 56;
    } else if (key === 'hangar') {
      // Hangar : long volume bas, grande porte à chevrons, toit à nervure
      var h1 = box(0, by, 54, 38, base, 0, 0);
      windows(h1.L, h1.F, h1.h, 3, 1, 0.6);
      // porte sur la face droite
      fq(h1.F, h1.R, h1.h, 0.16, 0.84, 0, 0.66, 0x070c18, 1);
      for (var s = 0; s < 6; s++) fq(h1.F, h1.R, h1.h, 0.16 + s * 0.113, 0.16 + s * 0.113 + 0.056, 0, 0.66, color, 0.55);
      fq(h1.F, h1.R, h1.h, 0.16, 0.84, 0.66, 0.72, color, 0.95);
      var h2 = box(0, by - 38, 38, 10, self._shade(base, 1.15), 0, 0);
      g.lineStyle(3, color, 0.9); g.lineBetween(-24, h2.top.y - 2, -24, h2.top.y - 26); g.lineBetween(26, h2.top.y - 2, 26, h2.top.y - 18);
      g.fillStyle(color, 1); g.fillCircle(-24, h2.top.y - 27, 3.5); g.fillCircle(26, h2.top.y - 19, 3);
      tip = h2.top.y - 28;
    } else if (key === 'amplifier') {
      // Amplificateur quantique : pylône fin surmonté d'anneaux d'énergie concentriques pulsants
      // et d'un noyau lumineux — silhouette bien distincte des autres bâtiments techno.
      var am1 = box(0, by, 34, 30, base, 2, 2);
      var pylonTopY = am1.top.y - 66;
      g.lineStyle(4, color, 0.95); g.lineBetween(0, am1.top.y, 0, pylonTopY);
      for (var ri = 0; ri < 3; ri++) {
        g.lineStyle(3 - ri * 0.6, color, 0.85 - ri * 0.2);
        g.strokeEllipse(0, pylonTopY - ri * 13, 46 - ri * 7, 17 - ri * 3);
      }
      g.fillStyle(0xffffff, 1); g.fillCircle(0, pylonTopY - 30, 5);
      g.fillStyle(color, 0.32); g.fillCircle(0, pylonTopY - 30, 17);
      orb = { x: 0, y: pylonTopY - 30 }; tip = pylonTopY - 34;
    } else {
      // Défense : bunker blindé + tourelle jumelée
      var d1 = box(0, by, 46, 34, self._mixColor(0x2a2f45, color, 0.2), 2, 2);
      var ty2 = d1.top.y;
      g.fillStyle(0x000000, 0.35); g.fillEllipse(0, ty2, 44, 22);
      g.fillStyle(0x2b3350, 1); g.fillRect(-19, ty2 - 16, 38, 16); g.fillEllipse(0, ty2, 38, 19);
      g.fillStyle(0x3e4a70, 1); g.fillEllipse(0, ty2 - 16, 38, 19);
      g.lineStyle(2, color, 0.95); g.strokeEllipse(0, ty2 - 16, 38, 19);
      g.lineStyle(8, 0x1d2238, 1); g.lineBetween(4, ty2 - 19, 32, ty2 - 33); g.lineBetween(-2, ty2 - 12, 26, ty2 - 26);
      g.lineStyle(3, color, 0.95); g.lineBetween(4, ty2 - 19, 32, ty2 - 33); g.lineBetween(-2, ty2 - 12, 26, ty2 - 26);
      g.fillStyle(0xffffff, 0.9); g.fillCircle(32, ty2 - 33, 3);
      // pointes de blindage aux angles
      poly([{ x: -46, y: by }, { x: -54, y: by - 22 }, { x: -40, y: by - 6 }], color, 0.85);
      poly([{ x: 46, y: by }, { x: 54, y: by - 22 }, { x: 40, y: by - 6 }], color, 0.85);
      tip = ty2 - 36;
    }

    container.add(g);
    b.topY = Math.max(-118, tip);

    if (dishY) {   // radar : la parabole « tourne » (écrasement horizontal en boucle)
      var dg = this.add.graphics();
      dg.lineStyle(3, color, 0.9); dg.lineBetween(0, 0, 0, -8);
      dg.fillStyle(this._mixColor(color, 0xffffff, 0.5), 0.95); dg.fillEllipse(0, -12, 38, 15);
      dg.lineStyle(2, color, 1); dg.strokeEllipse(0, -12, 38, 15);
      dg.fillStyle(0xffffff, 1); dg.fillCircle(0, -14, 2.5);
      dg.setPosition(0, dishY);
      container.add(dg);
      this.tweens.add({ targets: dg, scaleX: 0.25, duration: 1500, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    }
    if (orb) {     // labo : noyau énergétique qui pulse dans le dôme
      var core = this.add.image(orb.x, orb.y, 'tex_glow_white').setTint(color).setDisplaySize(40, 40).setBlendMode(ADD).setAlpha(0.9);
      var spark = this.add.circle(orb.x, orb.y, 6, 0xffffff, 0.95).setBlendMode(ADD);
      container.add([core, spark]);
      this.tweens.add({ targets: core, scale: core.scale * 1.5, alpha: 0.35, duration: 900 + Math.random() * 300, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
      this.tweens.add({ targets: spark, alpha: 0.4, duration: 600, yoyo: true, repeat: -1 });
    }
  }

  /** Éclair sur le Commandement quand un drone y dépose sa cargaison. */
  flashTower(color) {
    var box = this._buildingBoxes.command;
    if (!box || box.flashing) return;
    box.flashing = true;
    var f = this.add.image(box.container.x, box.container.y - 90, 'tex_glow_crystal').setScale(3.2).setAlpha(0.55).setBlendMode(Phaser.BlendModes.ADD).setDepth(1045).setTint(color);
    this.tweens.add({ targets: f, alpha: 0, duration: 420, onComplete: () => { f.destroy(); box.flashing = false; } });
  }

  // ---------- Gisements & drones ----------
  _buildNodes() {
    var E = NEBUSTION.Economy;
    var spots = {
      crystal: { x: 92, y: 652 },
      metal: { x: 628, y: 652 },
      energy: { x: 80, y: 858 },
      core: { x: 640, y: 858 },
      dust: { x: 360, y: 995 }
    };
    E.ORDER.forEach((id) => {
      this.nodes[id] = new NEBUSTION.ResourceNode(this, this.fx, id, spots[id].x, spots[id].y);
    });
  }

  _buildDrones() {
    var R = NEBUSTION.Resources, E = NEBUSTION.Economy;
    E.ORDER.forEach((id, i) => {
      var visible = Math.min(R.droneCount(id), 3);   // 3 drones animés max par gisement (performances)
      for (var k = 0; k < visible; k++) {
        var depot = { x: this.depotBase.x + (i - 2) * 34 + k * 10, y: this.depotBase.y + Math.abs(i - 2) * 10 - k * 8 };
        this.drones.push(new NEBUSTION.MiningDrone(this, this.fx, this.nodes[id], depot, i + k * 5));
      }
    });
  }

  // ---------- Récolte ----------
  harvest(node, pointer) {
    var R = NEBUSTION.Resources, E = NEBUSTION.Economy, fx = this.fx;
    var res = R.tap(node.id, Date.now());
    var px = node.x, py = node.y - 96;
    if (res.ok) {
      node.pulse();
      fx.burst(node.id, node.topX, node.topY, res.crit ? 26 : 9);
      fx.gain(node.id, res.amount, px, py, res.crit);
      if (res.crit) {
        fx.ring(node.topX, node.topY, node.def.color, 1.5);
        fx.text(px, py - 46, 'CRITIQUE !', '#ffffff', 26, 40);
        fx.shake(110, 0.003);
        fx.vibrate(25);
      } else {
        fx.vibrate(8);
      }
    } else if (res.reason === 'full') {
      node.shakeDenied();
      fx.text(px, py, 'Stockage plein', '#ff8fa3', 24, 50);
    } else if (res.reason === 'empty') {
      node.shakeDenied();
      fx.text(px, py, 'Recharge… ' + Math.ceil(res.wait) + ' s', '#9fb0d6', 22, 40);
    }
  }

  // ---------- Caisses de ravitaillement ----------
  _schedulePod() {
    var E = NEBUSTION.Economy, st = NEBUSTION.Resources.state.stats;
    var interval = Phaser.Math.Between(E.CFG.POD_MIN_SEC, E.CFG.POD_MAX_SEC) * 1000;
    this._podAt = Math.max(Date.now() + 4000, st.lastPod + interval);
  }

  _spawnPod() {
    var panelOpen = this._infoPanel && this._infoPanel.y < this.scale.height + 100;
    var slots = [{ x: 245, y: 640 }, { x: 475, y: 640 }];
    if (!panelOpen) slots.push({ x: 240, y: 950 }, { x: 480, y: 950 });
    var s = Phaser.Utils.Array.GetRandom(slots);
    this.pod = new NEBUSTION.SupplyPod(this, this.fx, s.x, s.y, (claimed) => {
      this.pod = null;
      this._schedulePod();
    });
  }

  // ---------- Boucle ----------
  update(time, delta) {
    var id;
    for (id in this.nodes) this.nodes[id].update(delta);

    this.beamGfx.clear();
    for (var i = 0; i < this.drones.length; i++) {
      this.drones[i].update(time, delta);
      this.drones[i].drawBeam(this.beamGfx, time);
    }

    // Poussière/vapeur d'énergie ambiante sur les gisements
    this._ambient -= delta;
    if (this._ambient <= 0) {
      this._ambient = 380;
      for (id in this.nodes) {
        var n = this.nodes[id];
        this.fx.sparkle(id, n.x + (Math.random() - 0.5) * 60, n.y - 70 + Math.random() * 30);
      }
    }

    if (this.pod) this.pod.update();
    else if (Date.now() >= this._podAt) this._spawnPod();

    // Panneau d'amélioration ouvert : coûts / disponibilité rafraîchis en direct (les ressources montent en continu)
    if (this._panelOpen) {
      this._upAcc += delta;
      if (this._upAcc >= 150) { this._upAcc = 0; this._refreshUpgrade(); }
    }
  }

  // ---------- Panneau d'info + amélioration (bâtiments ET extracteurs) ----------
  _buildInfoPanel() {
    var w = this.scale.width, h = this.scale.height;
    var panel = this.add.container(w / 2, h + 260).setDepth(1100);
    var TOP = -150, PH = 230;   // le fond va de y=-150 à y=+80 (le bas reste collé à la barre de navigation)

    var bg = this.add.graphics();
    bg.fillGradientStyle(0x101a33, 0x101a33, 0x0a1020, 0x0a1020, 0.98);
    bg.fillRoundedRect(-w * 0.42, TOP, w * 0.84, PH, 20);
    bg.lineStyle(2, 0x2e9eff, 0.6);
    bg.strokeRoundedRect(-w * 0.42, TOP, w * 0.84, PH, 20);
    panel.add(bg);
    panel.add(this.add.rectangle(0, TOP + PH / 2, w * 0.84, PH, 0x000000, 0.001).setInteractive());   // bloque les taps vers les gisements

    var title = this.add.text(-w * 0.36, -124, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '26px', fontStyle: 'bold', color: '#eaf2ff'
    }).setOrigin(0, 0.5);
    var level = this.add.text(-w * 0.36, -92, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '19px', color: '#8ea0c8'
    }).setOrigin(0, 0.5);
    var info = this.add.text(-w * 0.36, -62, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '17px', color: '#c8d4f0', wordWrap: { width: w * 0.72 }
    }).setOrigin(0, 0.5);
    var effect = this.add.text(-w * 0.36, -34, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '18px', fontStyle: 'bold', color: '#7dffb0', wordWrap: { width: w * 0.72 }
    }).setOrigin(0, 0.5);
    panel.add([title, level, info, effect]);

    // Coût : jusqu'à 3 ressources (icône + montant), rouge quand il en manque
    this._costSlots = [];
    for (var k = 0; k < 3; k++) {
      var ci = this.add.image(0, -3, 'tex_icon_crystal').setDisplaySize(28, 28).setVisible(false);
      var ct = this.add.text(0, -3, '', { fontFamily: 'Arial, sans-serif', fontSize: '21px', fontStyle: 'bold', color: '#eaf2ff' }).setOrigin(0, 0.5).setVisible(false);
      panel.add([ci, ct]);
      this._costSlots.push({ icon: ci, text: ct });
    }

    // Accès aux skins du bâtiment sélectionné (module Personnalisation).
    var skinsLink = this.add.text(w * 0.36, -92, 'Skins ›', {
      fontFamily: 'Arial, sans-serif', fontSize: '19px', fontStyle: 'bold', color: '#b47bff'
    }).setOrigin(1, 0.5).setInteractive({ useHandCursor: true });
    skinsLink.on('pointerdown', () => {
      if (this._infoPanelKey && this._buildingDefs[this._infoPanelKey]) this.scene.start('SkinsScene', { tab: 'building', targetId: this._infoPanelKey, from: 'PlanetScene' });
    });
    panel.add(skinsLink);

    // Accès à l'intérieur du QG (Sécurité de zone) ou au vol libre depuis le Hangar : uniquement
    // visible sur ces deux bâtiments, placé juste à gauche du lien Skins (qui reste accessible aussi).
    var enterLink = this.add.text(w * 0.36, -92, 'Entrer ›', {
      fontFamily: 'Arial, sans-serif', fontSize: '19px', fontStyle: 'bold', color: '#5fd97a'
    }).setOrigin(1, 0.5).setInteractive({ useHandCursor: true }).setVisible(false);
    enterLink.on('pointerdown', () => {
      if (this._infoPanelKey === 'symtor') { this.scene.start('SymbioteScene'); return; }
      if (this._infoPanelKey === 'hangar') {
        if (NEBUSTION.FlightZoneManager && NEBUSTION.FlightZoneManager.hasShip()) { this.scene.start('ShipFlightScene'); }
        else { this.fx.toast('Aucun vaisseau', 'Acquiers un vaisseau au Hangar avant de pouvoir piloter.'); }
        return;
      }
      this.scene.start('QGScene');
    });
    panel.add(enterLink);
    this._infoPanelEnter = enterLink;

    var closeBtn = this.add.text(w * 0.36, -124, '✕', {
      fontFamily: 'Arial, sans-serif', fontSize: '30px', color: '#a9b8dc'
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });
    closeBtn.on('pointerdown', () => this._hideInfoPanel());
    panel.add(closeBtn);

    var upgradeBtn = new NEBUSTION.Button(this, 0, 44, {
      width: w * 0.7, height: 54, label: 'AMÉLIORER', accentColor: 0x7dffb0, fontSize: '19px',
      onClick: () => this._doUpgrade()
    });
    panel.add(upgradeBtn);

    this._infoPanel = panel;
    this._infoPanelTitle = title;
    this._infoPanelLevel = level;
    this._infoPanelInfo = info;
    this._infoPanelEffect = effect;
    this._infoPanelSkins = skinsLink;
    this._upgradeBtn = upgradeBtn;
    this._panelClosedY = h + 260;
    this._panelOpenY = h - 210;
  }

  /** Ouvre le panneau d'amélioration d'un extracteur (appelé par ResourceNode : tap sur son niveau / la flèche ▲). */
  openUpgrade(key) {
    var E = NEBUSTION.Economy, def = E.BUILDINGS[key];
    if (!def) return;
    this._showInfoPanel({ key: key, label: def.name });
  }

  _showInfoPanel(building) {
    var E = NEBUSTION.Economy, def = E.BUILDINGS[building.key];
    this._infoPanelKey = building.key;
    this._infoPanelTitle.setText(building.label);
    if (building.key === 'symtor') {
      var ss = NEBUSTION.SymbioteManager.state();
      var cost = NEBUSTION.SymbioteManager.buildingCost();
      this._infoPanelInfo.setText(ss.built ? (ss.capsuleOpened ? 'Le symbiote vit dans le bâtiment. Nourris-le et fais-le évoluer.' : 'Une capsule organique attend son ouverture.') : 'Nouveau bâtiment vivant : construit le Symtor pour héberger une créature symbiote.');
      this._infoPanelSkins.setVisible(false);
      this._infoPanelEnter.setVisible(ss.built);
      this._infoPanelEnter.setText('Entrer ›');
      this._infoPanelEnter.setX(this._infoPanelSkins.x);
      this._panelOpen = true;
      this._lastUp = {};
      this._refreshUpgrade();
      this.tweens.add({ targets: this._infoPanel, y: this._panelOpenY, duration: 320, ease: 'Back.easeOut' });
      return;
    }
    var info = def.info || '';
    if (def.resource) {
      var n = NEBUSTION.Resources.droneCount(def.resource);
      info = E.RES[def.resource].name + '  •  ' + n + ' drone' + (n > 1 ? 's' : '') + ' minier' + (n > 1 ? 's' : '');
    }
    this._infoPanelInfo.setText(info);
    this._infoPanelSkins.setVisible(!!this._buildingDefs[building.key]);
    var isQG = building.key === 'qg';
    var isHangar = building.key === 'hangar';
    this._infoPanelEnter.setVisible(isQG || isHangar);
    this._infoPanelEnter.setText(isHangar ? 'Piloter ›' : 'Entrer ›');
    if (isQG || isHangar) {
      // Se place juste à gauche du lien Skins s'il est visible, sinon prend sa place.
      var gap = 18;
      var skinsX = this._infoPanelSkins.visible ? (this._infoPanelSkins.x - this._infoPanelSkins.width - gap) : this._infoPanelSkins.x;
      this._infoPanelEnter.setX(skinsX);
    }
    this._panelOpen = true;
    this._lastUp = {};
    this._refreshUpgrade();
    this.tweens.add({ targets: this._infoPanel, y: this._panelOpenY, duration: 320, ease: 'Back.easeOut' });
  }

  _hideInfoPanel() {
    this._panelOpen = false;
    this.tweens.add({ targets: this._infoPanel, y: this._panelClosedY, duration: 250, ease: 'Sine.easeIn' });
  }

  /** Met à jour un texte seulement s'il a changé (évite de redessiner le canvas du texte 7 fois par seconde). */
  _setText(obj, str, key) {
    if (this._lastUp[key] === str) return;
    this._lastUp[key] = str;
    obj.setText(str);
  }

  /** Niveau, effet, coût et état du bouton — appelé à l'ouverture, après chaque amélioration, puis toutes les 150 ms. */
  _refreshUpgrade() {
    var key = this._infoPanelKey;
    if (!key) return;
    var R = NEBUSTION.Resources, E = NEBUSTION.Economy;
    if (key === 'symtor') {
      var ss = NEBUSTION.SymbioteManager.state(), c = NEBUSTION.SymbioteManager.buildingCost();
      this._setText(this._infoPanelLevel, ss.built ? 'Bâtiment construit' : 'Construction requise', 'lvl');
      this._setText(this._infoPanelEffect, ss.built ? ('Défense symbiote +' + NEBUSTION.SymbioteManager.defense()) : 'Héberge une créature évolutive', 'eff');
      this._costSlots.forEach(function(slot){ slot.icon.setVisible(false); slot.text.setVisible(false); });
      var keys2 = Object.keys(c), total2=0, gap2=22, i2;
      for(i2=0;i2<keys2.length;i2++){ var id2=keys2[i2], slot2=this._costSlots[i2]; slot2.icon.setTexture('tex_icon_'+id2).setDisplaySize(28,28); this._setText(slot2.text,E.fmt(c[id2],0),'symct'+i2); slot2.text.setColor(R.get(id2)>=c[id2]?'#eaf2ff':'#ff8fa3'); slot2.icon.setVisible(!ss.built); slot2.text.setVisible(!ss.built); total2 += 28+6+slot2.text.width+(i2?gap2:0); }
      var x2=-total2/2; for(i2=0;i2<keys2.length;i2++){var sl2=this._costSlots[i2];sl2.icon.x=x2+14;sl2.text.x=x2+34;x2+=28+6+sl2.text.width+gap2;}
      var canBuy=!ss.built && R.canAfford(c);
      this._setText(this._upgradeBtn.labelText, ss.built ? 'OUVRIR LE SYMTOR  →' : (canBuy?'CONSTRUIRE LE SYMTOR':'CONSTRUIRE (ressources insuffisantes)'), 'btn');
      this._upgradeBtn.setLook(ss.built?0xd77cff:(canBuy?0x7dffb0:0x394869), '#eaf2ff');
      this._upgradeBtn.setDisabled(false);
      return;
    }
    var lvl = R.level(key), max = lvl >= E.CFG.MAX_LEVEL;
    var cost = max ? null : E.upgradeCost(key, lvl);
    var afford = !!cost && R.canAfford(cost);

    this._setText(this._infoPanelLevel, 'Niveau ' + lvl + (max ? '  •  MAXIMUM' : '  •  Statut : Opérationnel'), 'lvl');

    var eff = E.effectText(key, lvl);
    if (key === 'command' && !max && NEBUSTION.PrestigeManager && NEBUSTION.PrestigeManager.canPrestige) {
      try { var pc = NEBUSTION.PrestigeManager.canPrestige(); eff = 'Renaissance : Commandement niv. ' + pc.needCommandLevel + ' requis (actuel : ' + lvl + ')'; } catch (e) { /* texte par défaut */ }
    }
    this._setText(this._infoPanelEffect, eff, 'eff');

    // Coûts (icône + montant), centrés
    var keys = cost ? Object.keys(cost) : [], gap = 22, total = 0, i, slot, id;
    for (i = 0; i < this._costSlots.length; i++) {
      slot = this._costSlots[i];
      if (i < keys.length) {
        id = keys[i];
        slot.icon.setTexture('tex_icon_' + id);
        slot.icon.setDisplaySize(28, 28);
        this._setText(slot.text, E.fmt(cost[id], 0), 'ct' + i);
        var ok = R.get(id) + 1e-9 >= cost[id], col = ok ? '#eaf2ff' : '#ff8fa3';
        if (this._lastUp['cc' + i] !== col) { this._lastUp['cc' + i] = col; slot.text.setColor(col); }
        slot.icon.setVisible(true); slot.text.setVisible(true);
        total += 28 + 6 + slot.text.width + (i > 0 ? gap : 0);
      } else { slot.icon.setVisible(false); slot.text.setVisible(false); }
    }
    var x = -total / 2;
    for (i = 0; i < keys.length; i++) {
      slot = this._costSlots[i];
      slot.icon.x = x + 14; slot.text.x = x + 34;
      x += 28 + 6 + slot.text.width + gap;
    }

    // Bouton : vert et actif si on peut payer, sinon grisé (un tap explique ce qui manque)
    var label = max ? 'NIVEAU MAXIMUM' : (afford ? 'AMÉLIORER  →  Nv.' + (lvl + 1) : 'AMÉLIORER (ressources insuffisantes)');
    this._setText(this._upgradeBtn.labelText, label, 'btn');
    var look = max ? 'm' : (afford ? 'y' : 'n');
    if (this._lastUp.look !== look) {
      this._lastUp.look = look;
      if (look === 'y') this._upgradeBtn.setLook(0x7dffb0, '#eaf2ff');
      else this._upgradeBtn.setLook(0x394869, look === 'm' ? '#7dffb0' : '#9fb0d6');
    }
  }

  /** Tap sur AMÉLIORER : paie (tout ou rien), applique, puis effets visuels. Sinon explique ce qui manque. */
  _doUpgrade() {
    var key = this._infoPanelKey;
    if (!key || !this._panelOpen) return;
    var R = NEBUSTION.Resources, E = NEBUSTION.Economy, fx = this.fx;
    if (key === 'symtor') {
      var ss = NEBUSTION.SymbioteManager.state();
      if (!ss.built) { var br = NEBUSTION.SymbioteManager.buy(); if (br.ok) { fx.toast('SYMTOR CONSTRUIT','Entre pour ouvrir la capsule.'); this._refreshUpgrade(); return; } fx.toast('Ressources insuffisantes','Le Symtor demande 900 cristaux, 1200 métal et 700 énergie.'); return; }
      this.scene.start('SymbioteScene'); return;
    }
    var def = E.BUILDINGS[key];
    var res = R.upgradeBuilding(key);

    if (res.ok) {
      var box = this._buildingBoxes[key], bdef = this._buildingDefs[key];
      var node = def.resource ? this.nodes[def.resource] : null;
      var px, py, color;
      if (box) {
        box.badge.setText('Nv.' + res.level);
        px = box.container.x; py = box.container.y - 100; color = bdef.color;
        this.tweens.add({ targets: box.container, scale: box.scale * 1.12, duration: 150, yoyo: true, ease: 'Sine.easeOut' });
      } else if (node) {
        px = node.x; py = node.topY; color = node.def.color;
        node.pulse();
        fx.burst(node.id, node.topX, node.topY, 34);
      }
      fx.ring(px, py, color, 2.4);
      fx.text(px, py - 20, 'NIVEAU ' + res.level, '#7dffb0', 32, 80);
      fx.shake(120, 0.003);
      fx.vibrate(30);
      fx.toast(def.name + ' amélioré', 'Niveau ' + res.level, def.resource || null);
      this._lastUp = {};
      this._refreshUpgrade();
      return;
    }

    if (res.reason === 'cost') {
      var missing = [];
      Object.keys(res.cost).forEach(function (id) {
        var need = res.cost[id] - R.get(id);
        if (need > 1e-9) missing.push({ id: id, need: need });
      });
      var shown = missing.slice(0, 2).map(function (m) { return E.fmt(Math.ceil(m.need), 0) + ' ' + E.RES[m.id].short; }).join('  •  ');
      if (missing.length > 2) shown += '  •  +' + (missing.length - 2);
      fx.toast('Ressources insuffisantes', 'Il manque : ' + shown, missing.length ? missing[0].id : null);
      this.tweens.add({ targets: this._upgradeBtn, x: 8, duration: 45, yoyo: true, repeat: 2, onComplete: () => { this._upgradeBtn.x = 0; } });
      fx.vibrate(15);
    } else if (res.reason === 'max') {
      fx.toast('Niveau maximum atteint', def.name, null);
    }
    this._refreshUpgrade();
  }
};
