# CHANGELOG — NEBUSTION Symtor

## Version 2 — Rendu hybride 2D/2.5D du Symbiote
- Amélioration uniquement de `js/scenes/SymbioteScene.js`.
- Ajout d'une profondeur visuelle : extrusion sombre, ombre portée, éclairage, reflet spéculaire et pseudo-rotation.
- Le Symbiote reste procédural et animé ; aucune mécanique Symtor, sauvegarde ou ressource n'a été supprimée ou modifiée.
- Aucun moteur 3D externe n'a été ajouté : le rendu 3D est simulé dans Phaser pour conserver le jeu hors ligne.

## 2026-09-24 — 5 cartes cosmiques branchées
- Ajout des 5 héros/cartes : Auraxis, Ravnor, Kythar, Glacivor et Nymora.
- Les 5 sont intégrés au catalogue Héros, à la Boutique, à la collection et au combat.
- Les illustrations de la planche fournie sont conservées comme portraits 300×380 dans `assets/heroes/`.
- Chaque carte possède une rareté, un rôle, des statistiques, 3 compétences et un kit CombatEngine dédié.
- Cache hors-ligne (`sw.js`) mis à jour pour les 5 nouveaux portraits.
- Aucun fichier, asset, son ou système existant supprimé.


## Jetons Xon
- Nouvelle monnaie ultra-rare persistante : `Jetons Xon` (`shop.xon`), à 0 au démarrage.
- Badge Xon avec emblème octogonal/X directement dessiné dans la Boutique, avec animation légère.
- Les prix acceptent désormais `xon` en plus des Prismes et ressources classiques.
- Auraxis, Ravnor, Kythar, Glacivor et Nymora demandent aussi des Jetons Xon.
- Les contenus les plus rares peuvent en donner : expéditions Abyssal/Mythique (chance très faible) et derniers paliers de deux objectifs long terme.
- Aucune ressource, musique, carte ou mécanique existante n'est supprimée.

## Correctif QG — défrichage des parcelles
- Empêche les actions simultanées sur « Défricher » pendant le rafraîchissement du panneau.
- Corrige la disposition des 12 cartes de bâtiments (4 colonnes × 3 rangées) : auparavant la grille était dimensionnée pour 10 cartes, et la dernière rangée dépassait du panneau, pouvant intercepter des interactions.
- Agrandit et repositionne le panneau du QG pour que toutes les cartes restent dans ses limites.
- Ne modifie ni les coûts, ni les sauvegardes, ni les ressources, ni les autres scènes.
- Tests Node QGGrid : 39/39. Vérification syntaxique : OK. Test visuel sur téléphone non exécuté.


## Correctif équipement — boutons « Équiper »
- Correction de la zone de défilement de l'inventaire : elle était au-dessus des lignes d'équipement et interceptait les clics.
- La zone de défilement reste interactive mais passe sous les lignes, afin que les boutons « Équiper », « Améliorer », « Fusionner » et « Démanteler » reçoivent correctement les touch/pointerdown.
- Aucun équipement, héros, ressource ou fonctionnalité existante supprimé.


## Module combat avancé — 25 septembre 2026

Ajout de mécaniques interactives directement dans `CombatEngine.js` et `CombatScene.js`, sans supprimer les mécaniques existantes :
- **Cible verrouillée** : toucher un ennemi pendant le combat force les attaques/compétences à privilégier cette cible tant qu’elle est vivante.
- **Combo d’équipe** : les impacts successifs des héros construisent un combo jusqu’à ×1,20 dégâts ; le combo retombe après 4 secondes sans impact joueur.
- **Jauge de rupture** : les compétences et ultimes font baisser la garde des ennemis. À 0, l’ennemi est brisé/étourdi et devient plus vulnérable pendant 3 secondes.
- **Réactions élémentaires** : brûlure + poison = Combustion, poison + saignement = Corrosion, ralentissement + étourdissement = Choc thermique.
- Affichage en combat : cible verrouillée, combo, jauges de rupture et effets de réaction.
- Aucun asset, héros, équipement, ressource ou système existant supprimé.
