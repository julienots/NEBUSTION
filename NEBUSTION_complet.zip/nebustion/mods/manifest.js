/**
 * NEBUSTION - Manifeste des mods
 * Liste les fichiers mod à charger, DANS L'ORDRE, à chaque lancement du jeu.
 *
 * Pour activer un mod : ajoutez son chemin (relatif à la racine du jeu) dans le tableau
 * ci-dessous, par exemple 'mods/mon_mod.js'.
 * Pour le désactiver : retirez la ligne (ou mettez-la en commentaire avec //).
 *
 * Un mod absent ou en erreur est ignoré sans bloquer le jeu (voir la console du navigateur).
 */
window.NEBUSTION_MODS_MANIFEST = [
  'mods/exemple_mod.js',
  'mods/hud_fps.js',
  'mods/temps_de_jeu.js',
  'mods/outils_debug.js'
];
