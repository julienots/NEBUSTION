# NEBUSTION — 5 bâtiments utiles sur Nexus-01

Menu CONSTRUIRE de la planète Nexus-01 : 5 nouveaux bâtiments **avec un vrai effet** (comme la Tour de relais). Cumulables jusqu'au maximum,
les effets sont pris en compte immédiatement, et retirés si on recycle le bâtiment (50 % remboursés).

| Bâtiment | Effet (par exemplaire) | Max | Effet max | Coût de base |
|---|---|---|---|---|
| 📦 Entrepôt blindé | +10 % de capacité de stockage (toutes ressources) | 4 | +40 % | 180 métal + 150 poussière |
| ⛏️ Foreuse de gisements | +8 % à chaque récolte manuelle | 4 | +32 % | 160 métal + 90 énergie |
| ⏳ Chronodôme | +8 points de rendement hors ligne (plafonné à 100 %) | 3 | +24 pts (60 % → 84 %) | 260 cristaux + 200 énergie |
| 🏭 Raffinerie | +8 % de production de métal et de poussière | 4 | +32 % | 140 cristaux + 110 énergie |
| 🔮 Condenseur quantique | +8 % de production d'énergie et de cristaux | 4 | +32 % | 170 métal + 130 poussière |

Le coût augmente à chaque exemplaire posé (×1,38 à ×1,5). Limite totale de constructions : 30 → 36. Le catalogue passe à 4 rangées (14 bâtiments).

## Branchements (code)
- `js/data/PlanetBuild.js` : nouvelles entrées `CATALOG` + `effectSum(state, clé)` et `resBonus(state, ressource)`. Équilibrage : champs `base`, `growth`, `maxCount`, `effect`.
- `js/systems/ResourceManager.js` : `cap()` (stockage), `rates()` (production par ressource, s'additionne à la Tour de relais, Labo, etc.), `tap()` (récolte), `_applyOffline()` (hors ligne).
- `js/scenes/PlanetBuildUI.js` : dessin animé de chaque bâtiment (hangar à voyant, foreuse qui perce, dôme à anneaux temporels, raffinerie qui fume, sphère d'énergie avec arcs) + message d'activation.
- `sw.js` (cache v62). Sauvegardes existantes compatibles (nouveaux types simplement absents).

## Tests
`node tests/buildings-useful.test.js` (31 vérifications : chaque effet chiffré, maximum, recyclage, sauvegarde) ; `tests/tower-ui-smoke.js` mis à jour (14 cartes, animations).
Faux Phaser seulement : l'aspect des dessins et la lisibilité du catalogue à 4 rangées sont à valider sur téléphone.
