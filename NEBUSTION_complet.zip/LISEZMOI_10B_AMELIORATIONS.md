# NEBUSTION — Correctif 10b : les améliorations fonctionnent

Avant : le bouton « AMÉLIORER — Bientôt disponible » du panneau bâtiment était grisé (l'API `Resources.upgradeBuilding` existait depuis l'étape 2 mais aucune interface ne l'appelait).

## Ce qui est possible maintenant
| Quoi | Où | Coût / effet |
|---|---|---|
| **Commandement, Hangar, Laboratoire, Défense** | Toucher le bâtiment → panneau → **AMÉLIORER** | Coût de `Economy.BUILDINGS[id].base` × 1,55 par niveau. Hangar : +12 % de rendement des drones par niveau. Commandement : niveau exigé pour la Renaissance. Laboratoire / Défense : aucun bonus pour l'instant (indiqué dans le panneau) |
| **5 extracteurs** | Toucher le niveau « Nv.x +y/s » sous un gisement, ou la flèche **▲** à côté (verte = vous pouvez payer) | Production ×1,22 et récolte ×1,12 par niveau |
| **Stockage** | Toucher la barre de ressources → panneau Production → ligne **STOCKAGE** | Capacité ×1,5 par niveau. Indispensable : au-delà du Commandement niv. ~9, le coût dépasse la capacité de départ (15 000 cristaux) |

- Le panneau affiche : niveau, effet (avant → après), coût par ressource (**rouge** si elle manque), bouton vert si payable.
- Trop pauvre : le bouton reste grisé, un tap affiche ce qu'il manque (toast) et ne débite rien.
- Paiement atomique (tout ou rien), badge/étiquette mis à jour, effets (anneau, particules, « NIVEAU n »), niveau maximum 50.
- Les missions du Pass « Améliorer un bâtiment » (événement `upgrade`) progressent désormais.

## Fichiers modifiés
`js/scenes/PlanetScene.js` (panneau), `js/entities/ResourceNode.js` (▲ + zone tactile), `js/ui/ResourceHUD.js` (ligne Stockage),
`js/ui/Button.js` (`setLook`), `js/data/Economy.js` (`effectText`, pure), `sw.js` (nom du cache). Aucun nouveau fichier de jeu, sauvegarde inchangée.

## Tests
`node tests/economy.test.js` (inchangé, OK) — `NODE_PATH=$(npm root -g) node tests/browser-upgrade.js` (42 vérifications, faux Phaser) :
refus sans débit, coût exact, badge, extracteur, Stockage, niveau max, persistance, 0 erreur JS.
**Non testé** : le vrai Phaser/WebGL sur téléphone (mise en page vérifiée sur captures du faux moteur).
