/*
 * Test navigateur du PASS DE SAISON (Chromium/Playwright + FAUX Phaser : mise en page/logique/entrées, PAS de WebGL).
 * Parcours réel : menu → barre « Pass » → cartes → réclamation + animation → fenêtre Premium (aucun paiement) →
 * missions → « Tout réclamer » → changement de saison → rechargement (sauvegarde).
 * NODE_PATH=$(npm root -g) node tests/browser-pass.js [dossier_captures]
 */
const http = require('http'), fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const root = path.join(__dirname, '..'), out = process.argv[2] || '/tmp/shots_pass';
fs.mkdirSync(out, { recursive: true });
const mock = fs.readFileSync(path.join(__dirname, 'mock-phaser.js'), 'utf8');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]);
  if (u === '/js/vendor/phaser.min.js') { res.writeHead(200, { 'Content-Type': 'text/javascript' }); return res.end(mock); }
  const f = path.join(root, u === '/' ? 'index.html' : u);
  if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('nf'); }
  res.writeHead(200, { 'Content-Type': mime[path.extname(f)] || 'application/octet-stream' }); res.end(fs.readFileSync(f));
});
let passed = 0, failed = 0;
const ok = (c, m) => { if (c) passed++; else { failed++; console.log('  ✗ ' + m); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  await new Promise(r => server.listen(8772, r));
  const browser = await chromium.launch();
  const page = await (await browser.newContext({ viewport: { width: 390, height: 780 } })).newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console.error: ' + m.text()); });
  const R = e => page.evaluate(e);
  const S = 'window.__NEBUSTION_GAME__.scenes.PassScene';
  async function waitScene(key, ms) {
    const t0 = Date.now();
    while (Date.now() - t0 < (ms || 15000)) { if (await R(`!!__NEBUSTION_GAME__.scene.isActive('${key}')`)) return true; await sleep(100); }
    return false;
  }
  async function shot(name) {
    const data = await R(`(() => { const c = document.createElement('canvas'); c.width = 720; c.height = 1280; Phaser._render(${S}, c.getContext('2d'), 720, 1280); return c.toDataURL('image/png'); })()`);
    fs.writeFileSync(path.join(out, name + '.png'), Buffer.from(data.split(',')[1], 'base64'));
  }
  const navTap = (scene, idx) => R(`(() => { const sc = __NEBUSTION_GAME__.scenes.${scene}; const nav = sc._display.find(o => o.activeKey !== undefined); nav.list.filter(o => o._interactive)[${idx}].emit('pointerdown', {}); })()`);
  const zoneTap = (x, y) => R(`(() => { const s = ${S}; const z = s._display.find(o => o._interactive && o.depth === 41); z.emit('pointerdown', {x:${x},y:${y}}); z.emit('pointerup', {x:${x},y:${y}}); })()`);
  // Place la carte (niveau, piste) au milieu de la liste, puis la touche via la vraie zone de liste.
  const cardTap = (level, track) => R(`(() => { const s = ${S}; const cx = ${track === 'free' ? 158 : 562};
    const rows = s._hits.filter(h => h.x + h.w / 2 === cx).sort((a, b) => a.y - b.y); const h = rows[${level - 1}];
    const view = s.listBottom - s.listTop; s.scrollY = Math.max(0, Math.min(s.maxScroll, h.y + h.h / 2 - view / 2)); s.listContainer.y = s.listTop - s.scrollY;
    const x = h.x + h.w / 2, y = s.listContainer.y + h.y + h.h / 2;
    const z = s._display.find(o => o._interactive && o.depth === 41); z.emit('pointerdown', {x, y}); z.emit('pointerup', {x, y}); return { x, y }; })()`);
  const closeOverlay = () => R(`(() => { const s = ${S}; const z = s._overlay.c.list.find(o => o._interactive); z.emit('pointerup', {x: 100, y: 100}); })()`);
  const overlayOpen = () => R(`!!${S}._overlay`);
  const headerZone = () => R(`(() => { const s = ${S}; const zs = s.hdr.list.filter(o => o._interactive); zs[zs.length - 1].emit('pointerup', {}); })()`);
  const tabTap = i => R(`(() => { const s = ${S}; s.tabsBar.list.filter(o => o._interactive)[${i}].emit('pointerup', {}); })()`);
  const PMs = 'NEBUSTION.PassManager';

  console.log('# Enregistrement + navigation réelle');
  await page.goto('http://localhost:8772/index.html?debug=1');
  ok(await waitScene('MainMenuScene'), 'MainMenuScene atteinte');
  ok(await R(`!!__NEBUSTION_GAME__.scenes.PassScene`), 'PassScene est enregistrée dans main.js');
  ok(await R(`NEBUSTION.NAV_ITEMS.find(i => i.key === 'pass').scene === 'PassScene'`), 'la barre de navigation « Pass » pointe vers PassScene');
  await R(`(() => { const R = NEBUSTION.Resources; ['metal','crystal','energy','dust'].forEach(id => R.add(id, 3000, 'test')); ${PMs}.debugAddXp(NEBUSTION.Pass.totalXpForLevel(5) + 20); })()`);
  await navTap('MainMenuScene', 5);
  ok(await waitScene('PassScene', 4000), 'tap sur « Pass » ouvre PassScene');
  await sleep(700);
  ok(errors.length === 0, 'aucune erreur à l\'ouverture : ' + errors.join(' | '));
  ok(await R(`${S}._hits.length`) === 60, '60 cartes de récompense (30 niveaux × 2 pistes)');
  ok(/Saison 1/.test(await R(`${S}.hdr.list.filter(o => o.text).map(o => o.text).join('|')`)), 'bannière : « Saison 1 »');
  ok(await R(`${S}.scrollY > 0`), 'la liste s\'ouvre sur le niveau en cours');
  const cd0 = await R(`${S}._cdText.text`);
  ok(/^\d+j \d\dh \d\dm$/.test(cd0), 'compte à rebours affiché : ' + cd0);
  await shot('1_recompenses');

  console.log('# Réclamation + animation');
  const dust0 = await R(`NEBUSTION.Resources.get('dust')`);
  await cardTap(1, 'free'); await sleep(150);
  ok(await overlayOpen(), 'l\'animation de déblocage s\'ouvre');
  ok(await R(`${PMs}.status(1, 'free')`) === 'claimed', 'niveau 1 gratuit réclamé');
  ok(await R(`NEBUSTION.Resources.get('dust')`) > dust0 + 700, 'ressources créditées');
  await sleep(1200); await shot('2_deblocage');
  await closeOverlay(); await sleep(400);
  ok(!(await overlayOpen()), 'l\'animation se ferme au tap');
  await cardTap(1, 'free'); await sleep(100);
  ok(!(await overlayOpen()), 'carte déjà réclamée : pas de nouvelle animation');
  await cardTap(9, 'free'); await sleep(100);
  ok(!(await overlayOpen()), 'carte verrouillée : pas d\'animation, pas de réclamation');
  ok(await R(`${PMs}.status(9, 'free')`) === 'locked', 'niveau 9 toujours verrouillé');

  console.log('# Premium : aucune simulation de paiement');
  await cardTap(1, 'premium'); await sleep(400);
  ok(await overlayOpen(), 'carte Premium verrouillée : ouvre la fenêtre Premium');
  const modalTxt = await R(`${S}._overlay.c.list.filter(o => o.text).map(o => o.text).join(' | ')`);
  ok(/pas encore activés/.test(modalTxt) && /Prix en ressources/.test(modalTxt), 'la fenêtre indique que les achats intégrés ne sont pas activés et propose le prix en ressources');
  ok(!/Acheter le Pass/.test(modalTxt) && /Payer avec des ressources/.test(modalTxt), 'pas de bouton Google Play sans fournisseur ; bouton « Payer avec des ressources » présent');
  await sleep(300); await shot('3_premium');
  const tapOv = y => page.evaluate(yy => { const s = window.__NEBUSTION_GAME__.scenes.PassScene; s._overlay.c.list.find(o => o._interactive).emit('pointerup', { x: 360, y: yy }); }, y);
  await R(`(() => { const R = NEBUSTION.Resources; ['crystal','metal','energy','core','dust'].forEach(id => R.spend(id, R.get(id))); })()`);
  await tapOv(840); await sleep(250);
  ok(await overlayOpen() && !(await R(`${PMs}.isPremium()`)), 'paiement en ressources sans ressources suffisantes : refusé, Premium inactif, fenêtre ouverte');
  await tapOv(912); await sleep(200);
  ok(!(await overlayOpen()) && !(await R(`${PMs}.isPremium()`)), '« Fermer » ferme la fenêtre ; Premium toujours inactif');
  await cardTap(1, 'premium'); await sleep(300);
  await R(`(() => { const R = NEBUSTION.Resources, P = NEBUSTION.PassBilling.resourcePrice(); Object.keys(P).forEach(id => R.add(id, P[id], 'test')); return Object.keys(P).map(id => R.get(id)).join(); })()`);
  await tapOv(840); await sleep(400);
  ok(!(await overlayOpen()) && await R(`${PMs}.isPremium() && ${PMs}.state().premiumSource === 'resources'`), 'paiement en ressources : Premium activé (source « resources »), fenêtre fermée');
  ok(await R(`Object.keys(NEBUSTION.PassBilling.resourcePrice()).every(id => NEBUSTION.Resources.get(id) < 60)`), 'les ressources du prix ont été débitées (reste seulement la production des dernières secondes)');
  await R(`${PMs}.debugSetPremium(false)`);
  ok(await R(`${PMs}.claim(1, 'premium').reason`) === 'premium', 'réclamation Premium refusée sans Premium');
  // Outil de test debug (explicitement étiqueté TEST)
  await cardTap(1, 'premium'); await sleep(300);
  ok(/TEST/.test(await R(`${S}._overlay.c.list.filter(o => o.text).map(o => o.text).join(' | ')`)), 'en ?debug=1 : bouton « TEST » distinct');
  await page.evaluate(() => { const s = window.__NEBUSTION_GAME__.scenes.PassScene; s._overlay.c.list.find(o => o._interactive).emit('pointerup', { x: 360, y: 974 }); });
  await sleep(300);
  ok(await R(`${PMs}.isPremium()`), 'bouton TEST (debug) : Premium activé pour les essais');
  await cardTap(2, 'premium'); await sleep(200);
  ok(await overlayOpen() && await R(`${PMs}.status(2, 'premium')`) === 'claimed', 'carte Premium réclamable une fois le Premium actif');
  await sleep(800); await shot('4_premium_reclame'); await closeOverlay(); await sleep(300);

  console.log('# Missions');
  await tabTap(1); await sleep(400);
  ok(await R(`${S}.tab`) === 'missions', 'onglet Missions');
  ok(await R(`${S}._hits.length === ${PMs}.readyMissionCount()`), 'zones de réclamation = missions prêtes (la connexion du jour peut déjà compter)');
  const txt = await R(`${S}.listContainer.list.flatMap(c => (c.list && c.list.length) ? c.list : [c]).filter(o => o.text).map(o => o.text).join(' | ')`);
  ok(/Missions quotidiennes/.test(txt) && /Missions hebdomadaires/.test(txt), 'sections quotidiennes et hebdomadaires');
  ok(/Quotidiennes : \d\d:\d\d:\d\d/.test(await R(`${S}._stripTimers.d.text`)), 'compte à rebours de renouvellement quotidien');
  await shot('5_missions');
  await R(`['login','tap','pod','upgrade','battle','win','purchase','gift'].forEach(k => ${PMs}.track(k, 1000))`);
  await R(`${S}._render(false)`); await sleep(200);
  const nReady = await R(`${S}._hits.length`);
  ok(nReady === 6, '6 missions prêtes (' + nReady + ')');
  await shot('6_missions_pretes');
  const xp0 = await R(`${PMs}.state().xp`);
  const h0 = await R(`(() => { const s = ${S}; const h = s._hits[0]; return { x: h.x + h.w / 2, y: s.listContainer.y + h.y + h.h / 2 }; })()`);
  await zoneTap(h0.x, h0.y); await sleep(200);
  ok(await R(`${PMs}.state().xp`) > xp0, 'tap sur une mission prête : XP Pass ajoutée');
  ok(await R(`${S}._hits.length`) === 5, 'la mission réclamée n\'est plus réclamable');
  await headerZone(); await sleep(300);
  ok(await R(`${PMs}.readyMissionCount()`) === 0, '« Tout réclamer » (missions) : toutes réclamées');
  ok(errors.length === 0, 'aucune erreur : ' + errors.join(' | '));

  console.log('# Tout réclamer (récompenses)');
  await tabTap(0); await sleep(400);
  const claimable = await R(`${PMs}.claimableList().length`);
  ok(claimable > 0, 'des récompenses sont disponibles (' + claimable + ')');
  await headerZone(); await sleep(300);
  ok(await overlayOpen(), 'animation de synthèse');
  ok(await R(`${PMs}.claimableList().length`) === 0, 'toutes les récompenses disponibles réclamées');
  await sleep(900); await shot('7_tout_reclamer'); await closeOverlay(); await sleep(300);
  ok(errors.length === 0, 'aucune erreur : ' + errors.join(' | '));

  console.log('# Niveau maximum (tous effets de rareté)');
  await R(`${PMs}.debugAddXp(1e9); ${S}._render(false); ${S}._buildHeader()`); await sleep(300);
  await R(`(() => { const s = ${S}; s.scrollY = s.maxScroll; s.listContainer.y = s.listTop - s.scrollY; })()`);
  await sleep(500); await shot('8_niveau_30');
  await R(`(() => { const s = ${S}; s.scrollY = 0; s.listContainer.y = s.listTop; })()`); await sleep(300); await shot('9_niveau_1');
  ok(await R(`${PMs}.level().maxed`), 'niveau 30 atteint');
  ok(errors.length === 0, 'aucune erreur : ' + errors.join(' | '));

  console.log('# Changement de saison (horloge avancée de 28 jours)');
  const num0 = await R(`${PMs}.season().number`);
  await R(`(() => { const real = Date.now.bind(Date); window.__real = real; Date.now = () => real() + 28 * 86400000; })()`);
  await sleep(1400);
  ok(await waitScene('PassScene', 3000), 'PassScene relancée automatiquement');
  ok(await R(`${PMs}.season().number`) === num0 + 1, 'saison suivante : ' + (num0 + 1));
  ok(await R(`${PMs}.level().level`) === 0 && !(await R(`${PMs}.isPremium()`)), 'progression et Premium remis à zéro');
  ok(await R(`${PMs}.state().history.length`) === 1, 'saison précédente archivée');
  ok(await R(`${S}.hdr.list.filter(o => o.text).some(o => /Saison 2/.test(o.text))`), 'bannière : « Saison 2 »');
  ok(await R(`${PMs}.levels()[19].premium.label`) !== 'Zyra', 'récompenses de la nouvelle saison (autre héros vedette)');
  await shot('10_saison_2');
  ok(errors.length === 0, 'aucune erreur : ' + errors.join(' | '));

  console.log('# Sauvegarde : rechargement');
  await R(`Date.now = window.__real; ${PMs}.debugAddXp(300); NEBUSTION.Resources.saveNow(Date.now());`);
  const before = await R(`({ xp: ${PMs}.state().xp, season: ${PMs}.state().season })`);
  await page.reload();
  ok(await waitScene('MainMenuScene'), 'jeu relancé');
  const after = await R(`({ xp: ${PMs}.state().xp, season: ${PMs}.state().season, real: NEBUSTION.Pass.seasonIndex(Date.now()) })`);
  ok(after.season === Math.max(before.season, after.real) && (after.season === before.season ? after.xp === before.xp : true), 'après rechargement : saison et XP restaurées (' + JSON.stringify(after) + ')');
  ok(errors.length === 0, 'aucune erreur finale : ' + errors.join(' | '));

  await browser.close(); server.close();
  console.log(`\nRésultat : ${passed} OK, ${failed} échec(s). Captures : ${out}`);
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error('Test interrompu :', e); process.exit(2); });
