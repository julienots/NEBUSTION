/*
 * Test de fumée du MODULE INVASIONS / CONQUÊTES (5C) dans un vrai Chromium (Playwright) avec le FAUX Phaser
 * (tests/mock-phaser.js) : scène Galaxie (onglets, secteur verrouillé, carte, scan, invasion), combat d'invasion
 * (vagues, victoire, défaite, abandon, garde-fous), conquête, réaction des empires, revenus des colonies,
 * sauvegarde et rechargement. Le rendu WebGL réel n'est PAS simulé (voir README).
 *   NODE_PATH=$(npm root -g) node tests/browser-invasion.js        (SHOTS=/dossier pour enregistrer des captures de mise en page)
 */
const http = require('http'), fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const root = path.join(__dirname, '..');
const mock = fs.readFileSync(path.join(__dirname, 'mock-phaser.js'), 'utf8');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]);
  if (u === '/js/vendor/phaser.min.js') { res.writeHead(200, { 'Content-Type': 'text/javascript' }); return res.end(mock); }
  const f = path.join(root, u === '/' ? 'index.html' : u);
  if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('nf'); }
  res.writeHead(200, { 'Content-Type': mime[path.extname(f)] || 'application/octet-stream' }); res.end(fs.readFileSync(f));
});
let passed = 0, failed = 0;
const ok = (c, m) => { if (c) passed++; else { failed++; console.log('  ✗ ' + m); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const SHOTS = process.env.SHOTS;

(async () => {
  await new Promise(r => server.listen(8769, r));
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 720, height: 1280 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console.error: ' + m.text()); });
  const R = expr => page.evaluate(expr);
  const S = '__NEBUSTION_GAME__.scenes.';
  async function waitScene(key, ms) {
    const t0 = Date.now();
    while (Date.now() - t0 < (ms || 15000)) {
      if (await R(`!!(window.__NEBUSTION_GAME__ && window.__NEBUSTION_GAME__.scene.isActive('${key}'))`)) return true;
      await sleep(100);
    }
    return false;
  }
  async function waitCond(expr, ms) {
    const t0 = Date.now();
    while (Date.now() - t0 < (ms || 30000)) { if (await R(expr)) return true; await sleep(150); }
    return false;
  }
  async function shot(scene, name) {
    if (!SHOTS) return;
    fs.mkdirSync(SHOTS, { recursive: true });
    const data = await R(`(() => { const c = document.createElement('canvas'); c.width = 720; c.height = 1280; Phaser._render(${S}${scene}, c.getContext('2d'), 720, 1280); return c.toDataURL('image/png'); })()`);
    fs.writeFileSync(path.join(SHOTS, name + '.png'), Buffer.from(data.split(',')[1], 'base64'));
  }
  const active = () => R(`Object.keys(__NEBUSTION_GAME__.active)[0]`);
  async function go(scene, data) { await R(`${S}${await active()}.scene.start('${scene}', ${JSON.stringify(data || {})})`); return waitScene(scene); }
  const galaxy = () => R(`(() => { const s = ${S}GalaxyScene, GM = NEBUSTION.GalaxyManager; return { sector: s.sectorId, sel: s.selPid }; })()`);
  // héros surpuissants / ultra-fragiles pour finir un combat vite et de façon déterministe
  const godMode = () => R(`(() => { const s = ${S}CombatScene; s.engine.player.forEach(u => { u.atk = 3000; u.hp = u.maxHp = 99999; u.def = 999; }); s._cycleSpeed(); s._cycleSpeed(); })()`);
  const fragileMode = () => R(`(() => { const s = ${S}CombatScene; s.engine.player.forEach(u => { u.hp = 1; u.maxHp = 5; }); s.engine.enemy.forEach(u => { u.atk = 9999; u.spd = 400; }); s._cycleSpeed(); s._cycleSpeed(); })()`);
  // prépare un monde attaquable : secteur débloqué, scan valide
  const prep = (pid, conqNeighbor) => R(`(() => { const GM = NEBUSTION.GalaxyManager, G = NEBUSTION.Galaxy, p = G.planet('${pid}'); GM.state().unlocked[p.sector] = true;
    ${conqNeighbor ? `GM.setConquered('${conqNeighbor}', true, Date.now() - 3 * 86400000);` : ''} GM.state().scans['${pid}'] = { at: Date.now() }; })()`);

  console.log('# Chargement, modules, textures');
  await page.goto('http://localhost:8769/index.html?debug=1');
  ok(await waitScene('MainMenuScene'), 'MainMenuScene atteinte');
  ok(errors.length === 0, 'aucune erreur au chargement : ' + errors.join(' | '));
  ok(await R(`['GalaxyScene', 'CombatScene'].every(k => !!__NEBUSTION_GAME__.scenes[k]) && !!NEBUSTION.GalaxyTextures`), 'GalaxyScene enregistrée, GalaxyTextures chargé');
  ok(await R(`NEBUSTION.NAV_ITEMS.find(n => n.key === 'galaxy').scene`) === 'GalaxyScene', 'la barre de navigation « Galaxie » mène à GalaxyScene');
  const tex = await R(`(() => { const m = __NEBUSTION_GAME__.textures._map, G = NEBUSTION.Galaxy;
    return { planets: Object.keys(G.PLANET_TYPES).filter(t => m['tex_gplanet_' + t]).length, types: Object.keys(G.PLANET_TYPES).length,
      units: G.EMPIRE_ORDER.reduce((n, e) => n + G.EMPIRES[e].units.filter(u => m['tex_enemy_' + u.id]).length, 0) }; })()`);
  ok(tex.planets === tex.types && tex.types === 10, 'une texture par type de planète (' + tex.planets + '/' + tex.types + ')');
  ok(tex.units === 25, 'textures des 25 unités d\'empire générées (' + tex.units + ')');

  console.log('# Scène Galaxie : onglets, carte, liste');
  ok(await go('GalaxyScene', { navKey: 'galaxy', title: 'Galaxie' }), 'GalaxyScene démarrée');
  await sleep(300);
  let g = await galaxy();
  ok(g.sector === 's1' && g.sel === 'halo7', 'secteur Origine, planète de frontière proposée : ' + JSON.stringify(g));
  let ui = await R(`(() => { const s = ${S}GalaxyScene; return { pos: Object.keys(s._pos).length, pulses: s._pulses.length, zones: s.mapLayer.list.filter(o => o._interactive).length, chips: s.chipLayer.list.filter(o => o._interactive).length,
    tabs: s.tabLayer.list.filter(o => o._interactive).length }; })()`);
  ok(ui.pos === 4 && ui.zones === 4 && ui.chips === 4 && ui.tabs === 6, 'carte de 4 mondes, 4 fiches, 6 onglets : ' + JSON.stringify(ui));
  ok(ui.pulses === 3, 'les 3 mondes reliés à Nexus-01 sont à la frontière (anneau pulsant)');
  await shot('GalaxyScene', 'i1_galaxie_origine');

  console.log('# Secteur verrouillé et déblocage');
  await R(`${S}GalaxyScene._selectSector('s2')`);
  let lk = await R(`(() => { const s = ${S}GalaxyScene, st = NEBUSTION.GalaxyManager.sectorStatus('s2', Date.now()); return { locked: !NEBUSTION.GalaxyManager.isSectorUnlocked('s2'), reqs: st.reqs.length, cost: st.cost.length, can: st.canUnlock, dis: s._lockBtn && s._lockBtn.disabled, sel: s.selPid }; })()`);
  ok(lk.locked && lk.reqs === 2 && lk.cost === 2 && !lk.can && lk.dis && lk.sel === null, 'Ceinture de Vexor verrouillée : conditions + coût, bouton désactivé : ' + JSON.stringify(lk));
  await shot('GalaxyScene', 'i2_secteur_verrouille');
  const r0 = await R(`${S}GalaxyScene._doUnlock('s2')`);
  ok(r0.ok === false && r0.reason === 'requirements' && !(await R(`NEBUSTION.GalaxyManager.isSectorUnlocked('s2')`)), 'déblocage refusé sans les conditions');
  await R(`(() => { const R = NEBUSTION.Resources; R.state.combat.stageStars.stage_01 = 3; R.state.combat.stageStars.stage_02 = 3; R.state.res.crystal = 5000; R.state.res.energy = 2000;
    const GM = NEBUSTION.GalaxyManager; GM.state().scans.halo7 = { at: Date.now() }; GM.state().scans.cendre2 = { at: Date.now() }; })()`);
  await R(`${S}GalaxyScene._refresh()`);
  ok(await R(`NEBUSTION.GalaxyManager.sectorStatus('s2', Date.now()).canUnlock`), 'conditions remplies (2 stages, 2 scans, ressources) → déblocage possible');
  const cBefore = await R(`NEBUSTION.Resources.get('crystal')`);
  const r1 = await R(`${S}GalaxyScene._doUnlock('s2')`);
  ok(r1.ok && await R(`NEBUSTION.GalaxyManager.isSectorUnlocked('s2')`), 'secteur débloqué');
  ok(cBefore - await R(`NEBUSTION.Resources.get('crystal')`) >= 249, 'coût dépensé (une seule fois)');
  ok((await R(`NEBUSTION.GalaxyManager.unlockSector('s2')`)).reason === 'already', 'pas de second débit');
  ok(await R(`(() => { const s = ${S}GalaxyScene; return s.sectorId === 's2' && !!s.selPid && s.mapLayer.list.length > 0; })()`), 'le secteur débloqué s\'affiche (carte + fiche)');
  await R(`${S}GalaxyScene._selectSector('s1')`);

  console.log('# Scan');
  await R(`${S}GalaxyScene._selectPlanet('cendre2')`); await R(`${S}GalaxyScene._selectPlanet('halo7')`);
  await R(`(() => { const GM = NEBUSTION.GalaxyManager; delete GM.state().scans.halo7; delete GM.state().scans.cendre2; NEBUSTION.Resources.state.res.energy = 500; ${S}GalaxyScene._refresh(); })()`);
  ok(!(await R(`NEBUSTION.GalaxyManager.isScanned('halo7', Date.now())`)), 'halo7 non scannée : invasion impossible');
  ok(await R(`${S}GalaxyScene._doInvade('halo7')`) === false, 'invasion refusée sans scan');
  await sleep(700);
  ok(!(await R(`__NEBUSTION_GAME__.scene.isActive('CombatScene')`)), 'aucun combat lancé sans scan');
  const eBefore = await R(`NEBUSTION.Resources.get('energy')`);
  const sc = await R(`${S}GalaxyScene._doScan('halo7')`);
  ok(sc.ok, 'scan lancé');
  ok(eBefore - await R(`NEBUSTION.Resources.get('energy')`) >= 13, 'énergie dépensée pour le scan');
  ok((await R(`${S}GalaxyScene._doScan('cendre2')`)).reason === 'busy', 'un seul scan à la fois');
  ok(await R(`NEBUSTION.GalaxyManager.scanState('halo7', Date.now()).status`) === 'scanning', 'scan en cours (job persistant)');
  await R(`(() => { NEBUSTION.GalaxyManager.state().jobs.halo7.end = Date.now() - 1; })()`);   // la durée est écoulée
  ok(await waitCond(`NEBUSTION.GalaxyManager.isScanned('halo7', Date.now())`, 4000), 'le scan se termine tout seul (tick de la scène)');
  await sleep(200);
  const det = await R(`(() => { const s = ${S}GalaxyScene; return { txt: s.detailLayer.list.filter(o => o.text).map(o => o.text).join(' | '), imgs: s.detailLayer.list.filter(o => o.textureKey && /tex_enemy_/.test(o.textureKey)).length,
    btn: s.detailLayer.list.filter(o => o.labelText).map(o => o.labelText.text) }; })()`);
  ok(/Scan valide/.test(det.txt) && /Bouclier/.test(det.txt) && /Niveau conseillé/.test(det.txt) && /BUTIN/.test(det.txt), 'rapport de scan : bouclier, niveau conseillé, butin : ' + det.txt.slice(0, 160));
  ok(det.imgs >= 1 && det.btn.includes('⚔ ENVAHIR'), 'flotte révélée + bouton ENVAHIR : ' + JSON.stringify(det.btn));
  await shot('GalaxyScene', 'i3_scan_valide');

  console.log('# Invasion : monde libre Halo-7 (victoire)');
  const before = await R(`JSON.stringify({ res: NEBUSTION.Resources.state.res, won: NEBUSTION.Resources.state.combat.battlesWon, xp: NEBUSTION.Resources.state.combat.playerXP })`);
  ok(await R(`${S}GalaxyScene._doInvade('halo7')`) === true, 'invasion lancée');
  ok(await waitScene('CombatScene', 8000), 'CombatScene (invasion) démarrée');
  await sleep(500);
  const inv = await R(`(() => { const s = ${S}CombatScene; return { inv: s.isInvasion, pid: s.planetId, heroes: s.heroViews.length, enemies: s.enemyViews.length, waves: s.battle.waveCount, name: s.stageDef.name,
    shield: s.engine.enemy.map(u => u.shield), wtxt: s.diffOrWaveText.text }; })()`);
  ok(inv.inv && inv.pid === 'halo7' && inv.heroes === 5 && inv.enemies >= 1 && inv.waves === 1 && /Halo-7/.test(inv.name), 'arène : 5 héros de l\'équipe existante vs défense de la planète : ' + JSON.stringify(inv));
  ok(inv.shield.every(x => x >= 0) && /Vague 1 \/ 1/.test(inv.wtxt), 'compteur de vagues affiché');
  await godMode();
  ok(await waitCond(`!!${S}CombatScene.resultLayer`, 40000), 'écran de résultat affiché');
  let res = await R(`(() => { const s = ${S}CombatScene, r = s.engine.getResult(), gr = s._granted; return { win: r.win, conquered: gr.conquered, stars: gr.stars, rewards: gr.rewards,
    txt: s.resultLayer.list.filter(o => o.text).map(o => o.text), btn: s.resultLayer.list.filter(o => o.labelText).map(o => o.labelText.text),
    conq: NEBUSTION.GalaxyManager.isConquered('halo7'), won: NEBUSTION.Resources.state.combat.battlesWon }; })()`);
  ok(res.win && res.conquered && res.conq, 'victoire → Halo-7 conquise : ' + JSON.stringify({ win: res.win, c: res.conquered }));
  ok(res.txt.includes('PLANÈTE CONQUISE !') && res.txt.some(t => /rejoint votre empire/.test(t)), 'écran : « planète conquise », intégrée à l\'empire');
  ok(res.btn.includes('RETOUR À LA GALAXIE') && res.btn.includes('HÉROS'), 'boutons d\'invasion : ' + res.btn.join(','));
  const after = JSON.parse(await R(`JSON.stringify({ res: NEBUSTION.Resources.state.res, won: NEBUSTION.Resources.state.combat.battlesWon, xp: NEBUSTION.Resources.state.combat.playerXP })`));
  const b = JSON.parse(before);
  ok(after.res.metal > b.res.metal && after.res.dust > b.res.dust && after.xp > b.xp && after.won === b.won + 1, 'ressources + XP crédités, victoire comptée');
  ok(await R(`Object.keys(NEBUSTION.Resources.state.combat.fragments).length`) === 5, 'fragments crédités aux 5 héros');
  await shot('CombatScene', 'i4_resultat_conquete');
  await sleep(1500);
  ok(await R(`NEBUSTION.Resources.state.combat.battlesWon`) === b.won + 1, 'récompenses créditées UNE seule fois');
  const rr = await R(`NEBUSTION.GalaxyManager.colonyRates()`);
  ok(rr.dust > 0 && rr.metal > 0, 'la planète conquise produit des revenus : ' + JSON.stringify(rr));
  await R(`${S}CombatScene.resultLayer.list.filter(o => o.labelText && /GALAXIE/.test(o.labelText.text))[0].onClick()`);
  ok(await waitScene('GalaxyScene', 8000), 'retour à la Galaxie');
  await sleep(300);
  g = await galaxy();
  ok(g.sel === 'halo7', 'la planète attaquée est sélectionnée au retour');
  const cq = await R(`(() => { const s = ${S}GalaxyScene, mv = NEBUSTION.EmpireEvolutionManager.mapView(Date.now()), p = mv.planets.find(x => x.id === 'halo7');
    return { conq: p.conquered, txt: s.detailLayer.list.filter(o => o.text).map(o => o.text).join(' | '), invLyr: NEBUSTION.GalaxyManager.canInvade('lyr', Date.now()).reason }; })()`);
  ok(cq.conq && /Conquise/.test(cq.txt) && /COLONIE/.test(cq.txt), 'carte et fiche mises à jour (colonie, revenus)');
  await shot('GalaxyScene', 'i5_planete_conquise');

  console.log('# Portée : progression par la frontière');
  ok(await R(`NEBUSTION.EmpireEvolutionManager.isReachable('vx3')`) === false, 'Fonderie Ossature : hors de portée');
  await prep('vx3');
  ok(await R(`NEBUSTION.GalaxyManager.canInvade('vx3', Date.now()).ok`) === true, 'vx3 : scan valide et secteur ouvert…');
  await R(`(() => { ${S}GalaxyScene._selectSector('s2'); ${S}GalaxyScene._selectPlanet('vx3'); })()`);
  ok(await R(`${S}GalaxyScene._doInvade('vx3')`) === false, '… mais l\'invasion est refusée : hors de portée');
  await sleep(600);
  ok(!(await R(`__NEBUSTION_GAME__.scene.isActive('CombatScene')`)), 'aucun combat lancé hors de portée');
  ok(/Hors de portée/.test(await R(`${S}GalaxyScene.detailLayer.list.filter(o => o.text).map(o => o.text).join(' | ')`)), 'la fiche l\'indique');
  await shot('GalaxyScene', 'i6_hors_de_portee');
  // garde-fou côté combat : lancer directement un combat sur une cible invalide renvoie à la Galaxie sans rien créditer
  const wonG = await R(`NEBUSTION.Resources.state.combat.battlesWon + NEBUSTION.Resources.state.combat.battlesLost`);
  await go('CombatScene', { planetId: 'vx3' });
  ok(await waitScene('GalaxyScene', 5000), 'combat direct sur cible hors de portée : retour à la Galaxie');
  ok(await R(`NEBUSTION.Resources.state.combat.battlesWon + NEBUSTION.Resources.state.combat.battlesLost`) === wonG, 'aucun résultat compté');
  await go('CombatScene', { planetId: 'vx2' });
  ok(await waitScene('GalaxyScene', 5000), 'combat direct sur cible non scannée : retour à la Galaxie');

  console.log('# Défaite, empire qui tient, réessayer, abandon');
  await prep('vx1', 'lyr');    // lyr conquis → vx1 atteignable (route hyperspatiale)
  ok(await R(`NEBUSTION.EmpireEvolutionManager.isReachable('vx1')`), 'vx1 atteignable après la conquête de l\'Épave de Lyr');
  const held0 = await R(`NEBUSTION.Resources.state.empires.e.vexor.held`), lost0 = await R(`NEBUSTION.Resources.state.combat.battlesLost`);
  await go('CombatScene', { planetId: 'vx1' });
  await sleep(400);
  await fragileMode();
  ok(await waitCond(`!!${S}CombatScene.resultLayer`, 40000), 'écran de défaite affiché');
  res = await R(`(() => { const s = ${S}CombatScene, gr = s._granted; return { win: s.engine.getResult().win, conquered: gr.conquered, stars: gr.stars, lost: NEBUSTION.Resources.state.combat.battlesLost, conq: NEBUSTION.GalaxyManager.isConquered('vx1'),
    held: NEBUSTION.Resources.state.empires.e.vexor.held, mom: NEBUSTION.Resources.state.empires.e.vexor.mom, txt: s.resultLayer.list.filter(o => o.text).map(o => o.text), btn: s.resultLayer.list.filter(o => o.labelText).map(o => o.labelText.text) }; })()`);
  ok(!res.win && !res.conquered && res.stars === 0 && !res.conq && res.lost === lost0 + 1, 'défaite : pas de conquête, défaite comptée');
  ok(res.held === held0 + 1 && res.mom > 0, 'VEXOR « a tenu » : élan et compteur de défenses tenues (IA d\'évolution) : held=' + res.held + ' mom=' + res.mom);
  ok(res.txt.includes('DÉFAITE') && res.txt.some(t => /VEXOR se renforce/.test(t)) && res.btn.includes('RÉESSAYER') && res.btn.includes('GALAXIE'), 'écran de défaite : réaction de l\'empire + Réessayer / Galaxie');
  await shot('CombatScene', 'i7_defaite');
  await R(`${S}CombatScene.resultLayer.list.filter(o => o.labelText && /RÉESSAYER/.test(o.labelText.text))[0].onClick()`);
  ok(await waitCond(`__NEBUSTION_GAME__.scene.isActive('CombatScene') && ${S}CombatScene.isInvasion && ${S}CombatScene.engine.time < 1 && !${S}CombatScene.resultLayer`, 8000), 'Réessayer relance la même invasion');
  await sleep(300);
  const l1 = await R(`NEBUSTION.Resources.state.combat.battlesWon + NEBUSTION.Resources.state.combat.battlesLost`);
  await R(`${S}CombatScene._setPaused(true)`); await R(`${S}CombatScene._abandon()`);
  ok(await waitScene('GalaxyScene', 6000), 'abandon → retour à la Galaxie');
  ok((await galaxy()).sel === 'vx1', 'la planète abandonnée reste sélectionnée');
  ok(await R(`NEBUSTION.Resources.state.combat.battlesWon + NEBUSTION.Resources.state.combat.battlesLost`) === l1 && !(await R(`NEBUSTION.GalaxyManager.isConquered('vx1')`)), 'abandonner ne compte rien et ne conquiert rien');

  console.log('# Défense adaptée : plusieurs vagues (KAEL-9, capitale)');
  await prep('k95', 'k93');
  ok(await R(`NEBUSTION.EmpireEvolutionManager.isReachable('k95')`), 'Capitole Kael-9 atteignable (Base Méridian conquise)');
  const lostK0 = await R(`NEBUSTION.Resources.state.empires.e.kael9.lost`);
  await go('CombatScene', { planetId: 'k95' });
  await sleep(400);
  const w1 = await R(`(() => { const s = ${S}CombatScene; return { waves: s.battle.waveCount, n: s.enemyViews.length, sh: s.engine.enemy.map(u => u.shield), scale: s.battle.spec.scale }; })()`);
  ok(w1.waves === 2 && w1.n === 3 && w1.sh.every(x => x > 0), 'capitale : 2 vagues de 3 défenseurs avec bouclier d\'orbite : ' + JSON.stringify(w1));
  const uidsBefore = await R(`${S}CombatScene.engine.enemy.map(u => u.uid).join(',')`);
  await godMode();
  ok(await waitCond(`${S}CombatScene.battle.waveIndex === 1`, 40000), 'vague 2 déclenchée sans écran de résultat');
  await sleep(1500);
  const w2 = await R(`(() => { const s = ${S}CombatScene; return { uids: s.engine.enemy.map(u => u.uid).join(','), n: s.enemyViews.length, txt: s.diffOrWaveText.text, res: !!s.resultLayer, heroes: s.heroViews.length, alive: s.engine.player.filter(u => u.alive).length,
    mode: s.engine.mode, t: s.engine.time }; })()`);
  ok(w2.uids !== uidsBefore && w2.n === 3 && /Vague 2 \/ 2/.test(w2.txt) && w2.heroes === 5, 'nouveaux défenseurs, mêmes héros : ' + JSON.stringify(w2));
  ok(await waitCond(`!!${S}CombatScene.resultLayer`, 40000), 'résultat final après la dernière vague');
  res = await R(`(() => { const s = ${S}CombatScene, gr = s._granted; return { win: s.engine.getResult().win, conquered: gr.conquered, conq: NEBUSTION.GalaxyManager.isConquered('k95'), core: gr.rewards.core || 0,
    kL: NEBUSTION.Resources.state.empires.e.kael9.lost, hurt: NEBUSTION.Resources.state.empires.e.kael9.hurt, first: gr.rewards.core }; })()`);
  ok(res.win && res.conquered && res.conq, 'capitale conquise');
  ok(res.kL === lostK0 + 1 && res.hurt > 0, 'KAEL-9 enregistre la perte (traumatisme) : lost=' + res.kL + ' hurt=' + res.hurt);
  const st0 = await R(`(() => { const e = NEBUSTION.EmpireEvolutionManager.empireStatus('kael9', Date.now()); return { alert: e.alert, owned: e.owned, total: e.total }; })()`);
  ok(st0.owned === 3 && st0.total === 5 && st0.alert >= 1, 'bilan de l\'empire mis à jour : ' + JSON.stringify(st0));

  console.log('# Revenus des colonies (hors ligne inclus)');
  const rates = await R(`NEBUSTION.GalaxyManager.colonyRates()`);
  await R(`(() => { const R = NEBUSTION.Resources; R.state.res.crystal = 0; R.state.res.metal = 0; R.state.res.dust = 0; R.state.res.energy = 0; R.state.res.core = 0; NEBUSTION.GalaxyManager.state().colonyAt = Date.now() - 2 * 3600000; })()`);
  const gains = await R(`NEBUSTION.GalaxyManager.collectColonies(Date.now())`);
  const m2 = await R(`NEBUSTION.Resources.get('metal')`);
  ok(gains && Math.abs(m2 - rates.metal * 2) < rates.metal * 0.1 + 1, '2 h d\'absence → ≈ 2 h de revenus (métal ' + Math.round(m2) + ' / ' + Math.round(rates.metal * 2) + ')');
  await R(`(() => { NEBUSTION.Resources.state.res.metal = 0; NEBUSTION.GalaxyManager.state().colonyAt = Date.now() - 30 * 3600000; })()`);
  await R(`NEBUSTION.GalaxyManager.collectColonies(Date.now())`);
  const m12 = await R(`NEBUSTION.Resources.get('metal')`);
  ok(Math.abs(m12 - rates.metal * 12) < rates.metal * 0.1 + 1 || m12 >= await R(`NEBUSTION.Resources.cap('metal') - 1`), '30 h d\'absence → plafonné à 12 h (métal ' + Math.round(m12) + ' / ' + Math.round(rates.metal * 12) + ')');
  ok(await R(`NEBUSTION.GalaxyManager.collectColonies(Date.now())`) === null, 'aucun double versement immédiat');
  const cNow = await R(`NEBUSTION.Resources.get('crystal')`);
  await R(`NEBUSTION.GalaxyManager.setConquered('cendre2', true, Date.now())`);
  ok(await R(`NEBUSTION.Resources.get('crystal')`) >= cNow && (await R(`NEBUSTION.GalaxyManager.colonyRates().dust`)) > rates.dust, 'une nouvelle conquête ajoute un revenu sans effet rétroactif');

  console.log('# Sauvegarde et rechargement');
  const snap = `JSON.stringify({ conq: Object.keys(NEBUSTION.GalaxyManager.state().conquered).sort(), un: NEBUSTION.GalaxyManager.state().unlocked, lostK: NEBUSTION.Resources.state.empires.e.kael9.lost, heldV: NEBUSTION.Resources.state.empires.e.vexor.held,
    won: NEBUSTION.Resources.state.combat.battlesWon, lost: NEBUSTION.Resources.state.combat.battlesLost, colony: NEBUSTION.GalaxyManager.state().colonyAt > 0, visited: Object.keys(NEBUSTION.GalaxyManager.state().visited).sort() })`;
  const saved = await R(snap);
  await R(`NEBUSTION.Resources.saveNow(Date.now())`);
  await page.reload();
  ok(await waitScene('MainMenuScene'), 'redémarrage OK');
  const restored = await R(snap);
  ok(restored === saved, 'conquêtes, secteurs, états des empires et combats restaurés : ' + restored.slice(0, 140));
  ok(await R(`NEBUSTION.GalaxyManager.isConquered('halo7') && NEBUSTION.GalaxyManager.isConquered('k95') && NEBUSTION.EmpireEvolutionManager.isReachable('k94')`), 'la carte reflète les conquêtes après rechargement');
  await go('GalaxyScene', { navKey: 'galaxy', title: 'Galaxie' });
  await sleep(300);
  ok((await galaxy()).sector === 's3', 'la Galaxie ouvre le secteur le plus avancé débloqué');
  await shot('GalaxyScene', 'i8_apres_rechargement');
  ok(await R(`${S}GalaxyScene.chipLayer.list.filter(o => o._interactive).length`) === 5, '5 fiches pour un secteur d\'empire');

  console.log('# Navigation');
  await R(`${S}GalaxyScene._selectPlanet('lyr'); ${S}GalaxyScene._selectSector('s1'); ${S}GalaxyScene._selectPlanet('nexus_01')`);
  ok(/Planète-mère/.test(await R(`${S}GalaxyScene.detailLayer.list.filter(o => o.text).map(o => o.text).join(' | ')`)), 'fiche de Nexus-01 (planète-mère, revenus des colonies)');
  await shot('GalaxyScene', 'i9_planete_mere');
  await R(`${S}GalaxyScene.detailLayer.list.filter(o => o.labelText && /ENTRER/.test(o.labelText.text))[0].onClick()`);
  ok(await waitScene('PlanetScene', 5000), 'Entrer sur Nexus-01 → PlanetScene');
  await R(`NEBUSTION.NAV_ITEMS.find(n => n.key === 'galaxy')`);
  ok(errors.length === 0, 'aucune erreur JS pendant toute la session : ' + errors.slice(0, 3).join(' | '));
  await browser.close(); server.close();
  console.log('\n' + (failed === 0 ? '✔ TEST NAVIGATEUR INVASIONS 5C OK' : '✘ ' + failed + ' échec(s)') + ' (' + passed + ' vérifications)');
  process.exit(failed === 0 ? 0 : 1);
})().catch(async e => { console.error('ERREUR TEST :', e); process.exit(2); });
