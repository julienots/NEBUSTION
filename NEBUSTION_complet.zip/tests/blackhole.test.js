/* Tests de l'exploration du Trou Noir (NEBUSTION.BlackHole + BlackHoleManager), Node, sans Phaser.
 * Lancer : node tests/blackhole.test.js */
'use strict';
const E = require('./progress-env');
require('../js/data/BlackHole.js');
require('../js/systems/BlackHoleManager.js');
const t = E.makeCounter(), ok = t.ok, section = t.section;
const BH = NEBUSTION.BlackHole, BM = NEBUSTION.BlackHoleManager;
const HOUR = 3600000;

section('Zones et formules');
{
  ok(BH.zoneForDepth(1).id === 'horizon' && BH.zoneForDepth(4).id === 'horizon', 'profondeurs 1-4 = Horizon des Événements');
  ok(BH.zoneForDepth(5).id === 'anneau' && BH.zoneForDepth(9).id === 'anneau', 'profondeurs 5-9 = Anneau de Feu');
  ok(BH.zoneForDepth(25).id === 'singularite' && BH.zoneForDepth(999).id === 'singularite', 'profondeur 25+ = Singularité (zone finale, sans limite)');
  ok(BH.zoneMultAt(1) < BH.zoneMultAt(4), 'le multiplicateur croît À L\'INTÉRIEUR d\'une zone');
  ok(BH.zoneMultAt(4) < BH.zoneMultAt(5), 'le multiplicateur croît aussi entre deux zones');
  ok(BH.requiredPower(1) < BH.requiredPower(10) && BH.requiredPower(10) < BH.requiredPower(30), 'puissance requise strictement croissante avec la profondeur');
  ok(BH.requiredPower(1) === Math.round(BH.requiredPower(1)) && BH.requiredPower(1) > 0, 'puissance requise : entier positif');
}

section('Améliorations permanentes (talents)');
{
  const t0 = { hull: 0, prod: 0, luck: 0 };
  ok(BH.maxIntegrity(t0) === 100, 'intégrité max de base = 100');
  ok(BH.maxIntegrity({ hull: 3 }) === 130, '+10 intégrité par niveau de Coque renforcée');
  ok(BH.prodBonus({ prod: 2 }) > 0.11 && BH.prodBonus({ prod: 2 }) < 0.13, '+6 % par niveau de Résonance productive (×2 ≈ +12 %)');
  ok(BH.talentCost('hull', 0) > 0 && BH.talentCost('hull', 4) > BH.talentCost('hull', 0), 'coût croissant avec le niveau');
  ok(BH.talentCost('hull', 5) === null, 'niveau max (5) : plus d\'amélioration possible');
  ok(BH.talentCost('inconnu', 0) === null, 'talent inconnu → null (pas de crash)');
}

section('choiceOptions : déterminisme et structure');
{
  const a = BH.choiceOptions(42, 3), b = BH.choiceOptions(42, 3), c = BH.choiceOptions(43, 3);
  ok(JSON.stringify(a) === JSON.stringify(b), 'mêmes (seed, depth) → mêmes options (pur, déterministe)');
  ok(JSON.stringify(a) !== JSON.stringify(c), 'une seed différente change les options');
  ok(a.length === 3 && a.every(o => o.danger >= 1 && o.danger <= 3), '3 options, danger 1..3');
  ok(a.every(o => !o.forced || o.forced === 'abime'), 'forced est soit absent/null, soit "abime"');

  let sawForcedAt5 = false, sawForcedAtNon5 = false;
  for (let seed = 0; seed < 200; seed++) {
    if (BH.choiceOptions(seed, 5).some(o => o.forced === 'abime')) sawForcedAt5 = true;
    if (BH.choiceOptions(seed, 6).some(o => o.forced === 'abime')) sawForcedAtNon5 = true;
  }
  ok(sawForcedAt5, 'profondeur multiple de 5 : un Seuil (abime) est TOUJOURS forcé parmi les options');
  ok(!sawForcedAtNon5, 'profondeur non multiple de 5 : jamais de Seuil forcé');
}

section('resolveChoice : cohérence et absence de perte sèche');
{
  const rates = { crystal: 1, metal: 1, energy: 1, core: 0.02, dust: 1 };
  const talents = { hull: 0, prod: 0, luck: 0 };
  const opt1 = { idx: 0, danger: 1, forced: null };

  const r1 = BH.resolveChoice({ seed: 1, depth: 1, option: opt1, teamPower: 0, rates, talents });
  const r2 = BH.resolveChoice({ seed: 1, depth: 1, option: opt1, teamPower: 0, rates, talents });
  ok(JSON.stringify(r1) === JSON.stringify(r2), 'resolveChoice est pur : mêmes entrées → même résultat');
  ok(BH.KIND_META[r1.kind] && typeof r1.title === 'string' && typeof r1.body === 'string', 'kind connu, titre et texte narratif présents');
  ok(typeof r1.integrityDelta === 'number' && isFinite(r1.integrityDelta), 'integrityDelta est un nombre fini');

  // Beaucoup de tirages : aucune ressource négative, aucun NaN, fragments/gems ≥ 0.
  let bad = 0, sawEcho = false, sawCache = false, sawNegAnomaly = false;
  for (let d = 1; d <= 40; d++) {
    for (let i = 0; i < 3; i++) {
      const o = { idx: i, danger: 1 + (i % 3), forced: null };
      const r = BH.resolveChoice({ seed: d * 7 + i, depth: d, option: o, teamPower: 500 + d * 30, rates, talents });
      if (r.kind === 'echo') sawEcho = true;
      if (r.kind === 'cache') sawCache = true;
      if (r.kind === 'anomalie_negative') sawNegAnomaly = true;
      Object.keys(r.resources).forEach(id => { if (!(r.resources[id] > 0) || !isFinite(r.resources[id])) bad++; });
      if (!isFinite(r.fragments) || r.fragments < 0) bad++;
      if (!isFinite(r.gems) || r.gems < 0) bad++;
    }
  }
  ok(bad === 0, 'aucune ressource/fragment/gemme invalide sur un grand échantillon');
  ok(sawEcho && sawCache && sawNegAnomaly, 'les principaux types de rencontre apparaissent bien sur un échantillon large');

  // Puissance d'équipe : plus de puissance → meilleur taux de succès sur les Échos.
  const echoOpt = { idx: 0, danger: 3, forced: null };
  let successWeak = 0, successStrong = 0, N = 300;
  for (let s = 0; s < N; s++) {
    const rw = BH.resolveChoice({ seed: s, depth: 10, option: echoOpt, teamPower: 50, rates, talents });
    const rs = BH.resolveChoice({ seed: s, depth: 10, option: echoOpt, teamPower: 100000, rates, talents });
    if (rw.kind === 'echo' && rw.success) successWeak++;
    if (rs.kind === 'echo' && rs.success) successStrong++;
  }
  ok(successStrong > successWeak, 'une équipe beaucoup plus puissante réussit davantage de rencontres hostiles');

  // Seuil (abime) : plus dur qu'un Écho normal à puissance égale (ABIME_POWER_MULT > 1).
  const abimeOpt = { idx: 0, danger: 3, forced: 'abime' };
  const ratioEcho = BH.resolveChoice({ seed: 5, depth: 10, option: echoOpt, teamPower: 1000, rates, talents }).ratio;
  const ratioAbime = BH.resolveChoice({ seed: 5, depth: 10, option: abimeOpt, teamPower: 1000, rates, talents }).ratio;
  ok(ratioAbime < ratioEcho, 'un Seuil (checkpoint) exige plus de puissance qu\'un Écho normal, à profondeur égale');

  // La Résonance productive et le Détecteur amélioré ont un effet mesurable.
  const noBonus = BH.resolveChoice({ seed: 9, depth: 3, option: { idx: 0, danger: 1, forced: null }, teamPower: 0, rates, talents: { hull: 0, prod: 0, luck: 0 } });
  const withProd = BH.resolveChoice({ seed: 9, depth: 3, option: { idx: 0, danger: 1, forced: null }, teamPower: 0, rates, talents: { hull: 0, prod: 5, luck: 0 } });
  if (noBonus.kind === 'cache' && withProd.kind === 'cache') {
    const idA = Object.keys(noBonus.resources)[0];
    ok(withProd.resources[idA] > noBonus.resources[idA], 'Résonance productive au niveau max augmente le butin d\'une même rencontre');
  } else { ok(true, '(cas cache non tiré pour cette graine — ignoré)'); }
}

section('BlackHoleManager : état par défaut et normalisation');
{
  E.freshGame();
  const s0 = BM.defaultState(1000);
  ok(s0.fragments === 0 && s0.maxDepth === 0 && s0.dive === null, 'état neuf : 0 fragment, profondeur 0, aucune plongée');
  ok(s0.charge.ch === BH.CFG.MAX_CHARGES, 'charges pleines au départ');

  ok(BM.normalizeState(null, 1000).fragments === 0, 'normalizeState(null) → état par défaut valide');
  ok(BM.normalizeState({ fragments: -50, talents: { hull: 99 } }, 1000).fragments === 0, 'fragments négatifs rejetés → 0');
  ok(BM.normalizeState({ fragments: -50, talents: { hull: 99 } }, 1000).talents.hull === 5, 'niveau de talent hors bornes ramené au max (5)');
  ok(BM.normalizeState({ dive: { seed: 'texte', depth: 3 } }, 1000).dive === null, 'plongée avec seed invalide (NaN) → ignorée, pas de crash');
  const withDive = BM.normalizeState({ dive: { seed: 5, depth: 3, integrity: 99999 } }, 1000).dive;
  ok(withDive && withDive.integrity === BH.maxIntegrity({ hull: 0 }), 'intégrité sauvegardée hors bornes → plafonnée à l\'intégrité max');
}

section('BlackHoleManager : cycle de plongée complet');
{
  const g = E.freshGame();
  E.setNow(10 * HOUR);
  ok(BM.chargesAvailable() === BH.CFG.MAX_CHARGES, 'toutes les charges disponibles en partie neuve');

  const start = BM.startOrResumeDive();
  ok(start.ok && start.resumed === false && start.dive.depth === 0, 'première plongée : démarrage frais, profondeur 0');
  ok(BM.chargesAvailable() === BH.CFG.MAX_CHARGES - 1, 'démarrer une plongée consomme 1 charge');
  ok(BM.hasActiveDive(), 'une plongée est bien active');

  const resume = BM.startOrResumeDive();
  ok(resume.ok && resume.resumed === true, 'relancer alors qu\'une plongée est active → reprise, pas de nouvelle plongée');
  ok(BM.chargesAvailable() === BH.CFG.MAX_CHARGES - 1, 'reprendre une plongée ne consomme AUCUNE charge supplémentaire');

  const opts = BM.currentOptions();
  ok(opts.length === 3 && opts.every(o => o.label && o.hex), 'options annotées d\'un libellé et d\'une couleur pour l\'écran');

  const before = { crystal: g.R.get('crystal'), metal: g.R.get('metal'), energy: g.R.get('energy'), dust: g.R.get('dust'), core: g.R.get('core') };
  const res = BM.chooseNode(opts[0].idx);
  ok(res.ok && res.depth === 1, 'chooseNode fait progresser la profondeur à 1');
  ok(BM.maxDepthReached() === 1, 'la profondeur record est mise à jour immédiatement');
  const gained = Object.keys(before).some(id => g.R.get(id) > before[id] + 1e-9);
  const gainedFrag = BM.fragments() > 0;
  ok(gained || gainedFrag || res.outcome.kind === 'anomalie_negative' || res.outcome.kind === 'anomalie_positive' || res.outcome.kind === 'sanctuaire', 'la résolution accorde quelque chose de cohérent avec le type de rencontre');

  ok(BM.chooseNode(99).ok === false, 'chooseNode avec un index d\'option inexistant est refusé proprement');

  const snap = BM.diveSnapshot();
  ok(snap.depth === 1 && snap.integrity <= snap.maxIntegrity, 'l\'instantané de plongée reflète l\'état courant');

  const r = BM.retreat();
  ok(r.ok && r.depth === 1, 'remonter volontairement termine la plongée à la profondeur atteinte');
  ok(!BM.hasActiveDive(), 'plus aucune plongée active après remontée');
  ok(BM.maxDepthReached() === 1, 'la profondeur record est conservée après la remontée (aucune perte)');
}

section('BlackHoleManager : intégrité, fin forcée et absence de perte définitive');
{
  E.freshGame();
  E.setNow(20 * HOUR);
  BM.startOrResumeDive();
  const fragBefore = BM.fragments();
  let forced = false, guard = 0, lastGoodDepth = 0;
  while (!forced && guard < 500) {
    guard++;
    const opts = BM.currentOptions();
    const res = BM.chooseNode(opts[0].idx);
    if (!res.ok) break;
    lastGoodDepth = res.depth;
    if (res.forcedEnd) forced = true;
  }
  ok(forced, 'une descente assez longue finit par épuiser l\'intégrité (fin forcée)');
  ok(!BM.hasActiveDive(), 'fin forcée → la plongée est bien terminée côté état');
  ok(BM.fragments() >= fragBefore, 'aucun Fragment déjà gagné n\'est retiré lors d\'une fin forcée (pas de perte définitive)');
  ok(BM.maxDepthReached() >= lastGoodDepth, 'la profondeur record reflète la meilleure profondeur atteinte');
}

section('BlackHoleManager : charges (régénération dans le temps)');
{
  E.freshGame();
  E.setNow(0);
  for (let i = 0; i < BH.CFG.MAX_CHARGES; i++) BM.startOrResumeDive() && BM.retreat();
  ok(BM.chargesAvailable() === 0, 'toutes les charges consommées → 0 disponible');
  ok(BM.startOrResumeDive().ok === false, 'plus de charge → impossible de démarrer une plongée');
  ok(BM.msToNextCharge() > 0, 'un délai avant la prochaine charge est bien annoncé');
  E.setNow(BH.CFG.CHARGE_REGEN_MS);
  ok(BM.chargesAvailable() === 1, 'une charge régénérée après le délai complet');
  E.setNow(BH.CFG.CHARGE_REGEN_MS * BH.CFG.MAX_CHARGES + 1000);
  ok(BM.chargesAvailable() === BH.CFG.MAX_CHARGES, 'les charges se régénèrent jusqu\'au plafond, jamais au-delà');
}

section('BlackHoleManager : améliorations permanentes (achat)');
{
  E.freshGame();
  ok(BM.buyTalent('hull').ok === false, 'achat refusé sans assez de Fragments');
  NEBUSTION.Resources.state.blackhole.fragments = 10000;
  const before = BM.maxIntegrity();
  const buy = BM.buyTalent('hull');
  ok(buy.ok && buy.level === 1, 'achat réussi avec assez de Fragments');
  ok(BM.maxIntegrity() > before, 'l\'intégrité maximale augmente immédiatement après achat');
  ok(BM.fragments() < 10000, 'le coût est bien déduit des Fragments');
  for (let i = 0; i < 10; i++) BM.buyTalent('hull');
  ok(BM.talentLevel('hull') === 5, 'le niveau ne dépasse jamais le maximum (5), même en insistant');
}

section('BlackHoleManager : Comptoir de l\'Abîme');
{
  E.freshGame();
  E.setNow(5 * HOUR);
  NEBUSTION.Resources.state.blackhole.fragments = 1000;
  const offers = BM.exchangeOffers();
  ok(offers.length === BH.EXCHANGE_OFFERS.length && offers.every(o => o.amount >= 0), 'toutes les offres du Comptoir sont listées avec un montant valide');

  const crystalBefore = NEBUSTION.Resources.get('crystal');
  const buy = BM.buyExchange('ex_crystal');
  ok(buy.ok && NEBUSTION.Resources.get('crystal') > crystalBefore, 'échanger des Fragments crédite bien la ressource choisie');
  ok(BM.fragments() === 1000 - BH.exchangeOffer('ex_crystal').cost, 'le coût en Fragments est correctement déduit');

  ok(BM.buyExchange('inconnu').ok === false, 'offre inconnue → refus propre, pas de crash');
  NEBUSTION.Resources.state.blackhole.fragments = 5;
  ok(BM.buyExchange('ex_crystal').ok === false, 'achat refusé si les Fragments sont insuffisants');

  // Limite quotidienne des Prismes (gemmes)
  NEBUSTION.Resources.state.blackhole.fragments = 100000;
  let gemBuys = 0;
  for (let i = 0; i < 5; i++) { if (BM.buyExchange('ex_gem').ok) gemBuys++; }
  ok(gemBuys === 3, 'le Comptoir limite les Prismes à 3 achats par jour');
  E.setNow(5 * HOUR + 25 * HOUR);
  ok(BM.buyExchange('ex_gem').ok === true, 'la limite quotidienne se réinitialise le jour suivant');
}

section('Intégration SaveManager (persistance réelle)');
{
  const g = E.freshGame();
  BM.startOrResumeDive();
  BM.chooseNode(BM.currentOptions()[0].idx);
  const depthBefore = NEBUSTION.Resources.state.blackhole.maxDepth;
  const fragBefore = NEBUSTION.Resources.state.blackhole.fragments;
  g.R.saveNow(Date.now());
  const loaded = NEBUSTION.Save.load();
  ok(loaded.state && loaded.state.blackhole, 'le module Trou Noir fait bien partie de la sauvegarde écrite sur disque');
  const renorm = NEBUSTION.Save.normalize(loaded.state, Date.now());
  ok(renorm.blackhole.maxDepth === depthBefore && renorm.blackhole.fragments === fragBefore, 'recharger la sauvegarde restitue exactement la progression du Trou Noir');

  // Compatibilité ascendante : une sauvegarde d'avant ce module ne doit jamais planter.
  const oldSave = JSON.parse(JSON.stringify(loaded.state));
  delete oldSave.blackhole;
  const migrated = NEBUSTION.Save.normalize(oldSave, Date.now());
  ok(migrated.blackhole && migrated.blackhole.fragments === 0 && migrated.blackhole.dive === null, 'sauvegarde ancienne (sans module Trou Noir) → module neuf par défaut, sans erreur');
}

t.done('TESTS TROU NOIR');
