/* NEBUSTION — Jetons Xon : monnaie ultra-rare, sauvegarde, coûts et récompenses rares. */
'use strict';
global.window = global;
const fs = require('fs'), path = require('path');
['data/Economy','data/Heroes','data/Galaxy','data/EmpireAI','data/EmpireDoctrine','data/EmpireEvolution','data/Equipment','data/Ships','data/Skins','data/Shop','data/Expeditions','data/Achievements',
 'systems/SaveManager','systems/ResourceManager','systems/CombatEngine','systems/CombatManager','systems/EquipmentManager','systems/ShipManager','systems/SkinManager','systems/ShopManager'].forEach(f => require('../js/' + f + '.js'));
let passed=0, failed=0; const ok=(c,m)=>c?passed++:(failed++,console.log('  ✗ ECHEC : '+m)); const section=t=>console.log('\n# '+t);
const store={_m:{},getItem(k){return this._m[k]||null;},setItem(k,v){this._m[k]=v;},removeItem(k){delete this._m[k];}};
NEBUSTION.Save._useStorage(store);
NEBUSTION.Resources=new NEBUSTION.ResourceManager(); NEBUSTION.Resources.init(Date.now());
const R=NEBUSTION.Resources, S=NEBUSTION.Shop, SM=NEBUSTION.ShopManager;

section('Monnaie Xon');
ok(S.XON.id==='xon' && S.XON.name==='Jetons Xon' && S.XON.color===0x62f4ff,'définition Xon valide');
ok(R.state.shop.xon===0,'nouvelle partie : 0 Xon');
SM.addXon(3); ok(SM.xon()===3,'gain de 3 Xon');
SM.addXon(-50); ok(SM.xon()===3,'gain négatif ignoré');
const normalized=S.normalizeState({gems:12,xon:7},Date.now()); ok(normalized.xon===7 && normalized.gems===12,'ancienne sauvegarde compatible');

section('Coûts');
const hids=['auraxis','ravnor','kythar','glacivor','nymora'];
const expected={auraxis:2,ravnor:3,kythar:1,glacivor:2,nymora:3};
hids.forEach(id=>ok(NEBUSTION.Heroes.get(id).shop.cost.xon===expected[id],id+' demande le bon nombre de Xon'));
R.state.shop.gems=10000; R.state.shop.xon=0;
const beforeG=R.state.shop.gems; const locked=SM.buyHero('kythar');
ok(!locked.ok && locked.reason==='ressources' && R.state.shop.gems===beforeG,'achat sans Xon refusé sans débit');
R.state.shop.xon=1;
ok(SM.buyHero('kythar').ok && R.state.shop.xon===0,'Kythar consomme 1 Xon');

section('Récompenses rares');
const ex=NEBUSTION.Expeditions;
const abyss=ex.DIFFICULTIES.abyssal, myth=ex.DIFFICULTIES.mythique;
ok(abyss.xon===1 && abyss.xonChance===0.015,'Abyssal : chance Xon très faible');
ok(myth.xon===1 && myth.xonChance===0.04,'Mythique : chance Xon très faible');
const a=NEBUSTION.Achievements.get('lt_prestige'), r=NEBUSTION.Achievements.get('lt_relics');
ok(a.rewards[2].xon===1 && r.rewards[2].xon===1,'deux derniers paliers long terme donnent 1 Xon');

section('Sauvegarde');
R.state.shop.xon=4; R.saveNow(Date.now());
const R2=new NEBUSTION.ResourceManager(); R2.init(Date.now());
ok(R2.state.shop.xon===4,'4 Xon conservés après rechargement');

section('Interface');
const shopScene=fs.readFileSync(path.join(__dirname,'..','js/scenes/ShopScene.js'),'utf8');
ok(shopScene.includes('_drawXon') && shopScene.includes('_buildXonBadge') && shopScene.includes("id === 'xon'"),'emblème Xon et affichage des prix branchés');

console.log('\n'+passed+' réussis, '+failed+' échoués');
process.exit(failed?1:0);
