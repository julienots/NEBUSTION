/*
 * Test navigateur des 8 héros exclusifs Boutique (faux Phaser : mise en page/logique/entrées, PAS de WebGL).
 * Collection (héros verrouillés) → tap → Boutique sur le bon héros → recrutement avec confirmation →
 * équipe de combat → sauvegarde/rechargement.
 * NODE_PATH=$(npm root -g) node tests/browser-heroshop.js [dossier_captures]
 */
const http = require('http'), fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const root = path.join(__dirname, '..'), out = process.argv[2] || '/tmp/shots_heroshop';
fs.mkdirSync(out, { recursive: true });
const mock = fs.readFileSync(path.join(__dirname, 'mock-phaser.js'), 'utf8');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]);
  if (u === '/js/vendor/phaser.min.js') { res.writeHead(200, { 'Content-Type': 'text/javascript' }); return res.end(mock); }
  const f = path.join(root, u === '/' ? 'index.html' : u);
  if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('nf'); }
  res.writeHead(200, { 'Content-Type': mime[path.extname(f)] || 'application/octet-stream' }); res.end(fs.readFileSync(f));
});
let passed = 0, failed = 0;
const ok = (c, m) => { if (c) passed++; else { failed++; console.log('  ✗ ' + m); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  await new Promise(r => server.listen(8773, r));
  const browser = await chromium.launch();
  const page = await (await browser.newContext({ viewport: { width: 390, height: 780 } })).newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console.error: ' + m.text()); });
  const R = e => page.evaluate(e);
  const G = '__NEBUSTION_GAME__';
  async function waitScene(key, ms) {
    const t0 = Date.now();
    while (Date.now() - t0 < (ms || 15000)) { if (await R(`!!${G}.scene.isActive('${key}')`)) return true; await sleep(100); }
    return false;
  }
  async function shot(scene, name) {
    const data = await R(`(() => { const c = document.createElement('canvas'); c.width = 720; c.height = 1280; Phaser._render(${G}.scenes.${scene}, c.getContext('2d'), 720, 1280); return c.toDataURL('image/png'); })()`);
    fs.writeFileSync(path.join(out, name + '.png'), Buffer.from(data.split(',')[1], 'base64'));
  }
  const navTap = (scene, idx) => R(`(() => { const sc = ${G}.scenes.${scene}; const nav = sc._display.find(o => o.activeKey !== undefined); nav.list.filter(o => o._interactive)[${idx}].emit('pointerdown', {}); })()`);
  const S = `${G}.scenes.ShopScene`, HS = `${G}.scenes.HeroesScene`;
  const zoneTap = (sc, x, y) => R(`(() => { const s = ${sc}; const z = s._display.find(o => o._interactive && o.depth === 41); z.emit('pointerdown', {x:${x},y:${y}}); z.emit('pointerup', {x:${x},y:${y}}); })()`);
  const cardBtn = (n, hi) => R(`(() => { const s = ${S}; const c = s._cards[${n}]; const h = c._hits[${hi || 0}];
    const view = s.listBottom - s.listTop; s.scrollY = Math.max(0, Math.min(s.maxScroll, c.y + h.y - view / 2)); s.listContainer.y = s.listTop - s.scrollY;
    return { x: 12 + h.x + h.w / 2, y: s.listContainer.y + c.y + h.y + h.h / 2 }; })()`);
  const tapModal = idx => R(`(() => { const s = ${S}; const h = s._modal.hits[${idx}]; s._modal.dim.emit('pointerup', {x: h.x + h.w/2, y: h.y + h.h/2}); })()`);
  const modalOpen = () => R(`!!${S}._modal`);
  const NEW = ['velmora', 'zephyrax', 'drakathor', 'selenia', 'krakenis', 'nythera', 'arcanis', 'vulkar'];

  console.log('# Chargement des portraits');
  await page.goto('http://localhost:8773/index.html?debug=1');
  ok(await waitScene('MainMenuScene'), 'MainMenuScene atteinte');
  const tex = await R(`NEBUSTION.Heroes.all().map(h => ({ id: h.id, real: ${G}.textures.exists(NEBUSTION.Heroes.portraitKey(h.id)) }))`);
  ok(tex.length === 25 && tex.every(t => t.real), '25 portraits chargés (dont les 9 nouveaux) : ' + tex.filter(t => !t.real).map(t => t.id).join(','));
  ok(errors.length === 0, 'aucune erreur au démarrage : ' + errors.join(' | '));

  console.log('# Collection : héros verrouillés');
  await R(`NEBUSTION.Resources.state.shop.gems = 3000`);
  await navTap('MainMenuScene', 2);
  ok(await waitScene('HeroesScene', 4000), 'Collection ouverte');
  await sleep(500);
  ok(await R(`${HS}._currentList.length`) === 25, '25 héros listés dans la Collection');
  await R(`(() => { const s = ${HS}; const idx = s._currentList.findIndex(h => h.id === 'krakenis'); const grid = s._rowGrid; s.scrollY = Math.min(s.maxScroll, idx * grid - 100); s.listContainer.y = s.listTop - s.scrollY; })()`);
  await sleep(200); await shot('HeroesScene', '1_collection_verrouillee');
  const rowTxt = await R(`${HS}.listContainer.list.flatMap(r => (r.list && r.list.length) ? r.list : []).filter(o => o.text).map(o => o.text)`);
  ok(rowTxt.filter(t => t === 'BOUTIQUE').length === 8, '8 héros marqués « BOUTIQUE » dans la Collection (' + rowTxt.filter(t => t === 'BOUTIQUE').length + ')');
  ok(rowTxt.some(t => /Recrutement en Boutique · 380 Prismes/.test(t)) && rowTxt.some(t => /560 Prismes/.test(t)) && rowTxt.some(t => /220 Prismes/.test(t)), 'prix affichés (220 / 380 / 560)');
  // Tap sur Krakenis (verrouillé) → ouvre la Boutique sur Krakenis
  const ty = await R(`(() => { const s = ${HS}; const idx = s._currentList.findIndex(h => h.id === 'krakenis'); return s.listTop + idx * s._rowGrid - s.scrollY + 40; })()`);
  await R(`(() => { const s = ${HS}; s._handleListTap(${ty}); })()`);
  ok(await waitScene('ShopScene', 4000), 'tap sur un héros verrouillé → Boutique');
  await sleep(500);
  ok(await R(`NEBUSTION.Heroes.all()[${S}.heroIndex].id`) === 'krakenis' && await R(`${S}.tab`) === 'heroes', 'Boutique ouverte sur l\'onglet Héros, héros Krakenis');

  console.log('# Boutique : recrutement');
  const cards = await R(`${S}._cards.length`);
  ok(cards === 2, 'sélecteur + carte de recrutement (aucun paquet de fragments) : ' + cards);
  const txt = await R(`(() => { const out = []; const walk = o => { if (o.text) out.push(o.text); (o.list || []).forEach(walk); }; walk(${S}.listContainer); return out.join(' | '); })()`);
  ok(/À recruter/.test(txt) && /Recruter Krakenis/.test(txt) && /NOUVEAU HÉROS/.test(txt) && /380/.test(txt), 'textes : À recruter / Recruter Krakenis / NOUVEAU HÉROS / 380');
  await shot('ShopScene', '2_boutique_recrutement');
  // Sans fonds : confirmation ouverte mais achat bloqué
  await R(`NEBUSTION.Resources.state.shop.gems = 100`);
  let p = await cardBtn(1); await zoneTap(S, p.x, p.y); await sleep(250);
  ok(await modalOpen(), 'confirmation ouverte');
  await tapModal(1); await sleep(300);
  ok(await modalOpen() && !(await R(`NEBUSTION.Combat.isUnlocked('krakenis')`)) && await R(`NEBUSTION.ShopManager.gems()`) === 100, 'sans Prismes suffisants : rien n\'est acheté ni débité');
  await tapModal(0); await sleep(300);
  // Avec fonds
  await R(`NEBUSTION.Resources.state.shop.gems = 1000`);
  p = await cardBtn(1); await zoneTap(S, p.x, p.y); await sleep(250);
  await tapModal(1); await sleep(450);
  ok(!(await modalOpen()), 'confirmation fermée');
  ok(await R(`NEBUSTION.Combat.isUnlocked('krakenis')`) && await R(`NEBUSTION.ShopManager.gems()`) === 620, 'Krakenis recruté, 380 Prismes débités');
  ok(await R(`${S}._cards.length`) === 4, 'après recrutement : les 3 paquets de fragments apparaissent');
  ok(errors.length === 0, 'aucune erreur : ' + errors.join(' | '));
  await shot('ShopScene', '3_apres_recrutement');

  console.log('# Équipe de combat');
  await R(`NEBUSTION.Combat.setTeam(['zyra', 'krakenis', 'lumina', 'velmora'])`);
  ok(JSON.stringify(await R(`NEBUSTION.Combat.getTeam()`)) === JSON.stringify(['zyra', 'krakenis', 'lumina']), 'équipe : Krakenis accepté, Velmora (non recruté) refusé');
  await R(`${S}.scene.start('CombatPrepScene', {})`); await sleep(700);
  ok(await waitScene('CombatPrepScene', 4000), 'préparation de combat ouverte');
  const pick = await R(`${G}.scenes.CombatPrepScene._pickList.map(e => e.id)`);
  ok(pick.length === 17 && pick.indexOf('krakenis') >= 0 && pick.indexOf('velmora') < 0, 'liste de sélection : 16 héros d\'origine + Krakenis, sans les héros non recrutés (' + pick.length + ')');
  await shot('CombatPrepScene', '4_preparation');
  ok(errors.length === 0, 'aucune erreur : ' + errors.join(' | '));

  console.log('# Sauvegarde : rechargement');
  await R(`NEBUSTION.Resources.saveNow(Date.now())`);
  await page.reload();
  ok(await waitScene('MainMenuScene'), 'jeu relancé');
  ok(await R(`NEBUSTION.Combat.isUnlocked('krakenis') && !NEBUSTION.Combat.isUnlocked('velmora')`), 'recrutement conservé après rechargement');
  ok(errors.length === 0, 'aucune erreur finale : ' + errors.join(' | '));

  await browser.close(); server.close();
  console.log(`\nRésultat : ${passed} OK, ${failed} échec(s). Captures : ${out}`);
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error('Test interrompu :', e); process.exit(2); });
