const fs=require('fs'), vm=require('vm'), assert=require('assert');
const store={}; const ctx={window:{},localStorage:{getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=v},console}; ctx.window.window=ctx.window; vm.createContext(ctx); vm.runInContext(fs.readFileSync('js/data/Settings.js','utf8'),ctx); const S=ctx.window.NEBUSTION.Settings;
let s=S.get(); assert.strictEqual(s.vibrationOn,true); assert.strictEqual(s.reducedFX,false); assert.strictEqual(s.batterySaver,false); assert.strictEqual(s.sfxVolume,0.16);
S.set({sfxVolume:0.3,vibrationOn:false,reducedFX:true,batterySaver:true}); s=S.get(); assert.strictEqual(s.sfxVolume,0.3); assert.strictEqual(s.vibrationOn,false); assert.strictEqual(s.reducedFX,true); assert.strictEqual(s.batterySaver,true); assert.ok(store.nebustion_settings_v1);
S.reset(); s=S.get(); assert.strictEqual(s.sfxVolume,0.16); assert.strictEqual(s.vibrationOn,true); assert.strictEqual(s.reducedFX,false); assert.strictEqual(s.batterySaver,false);
console.log('settings-plus: OK');
