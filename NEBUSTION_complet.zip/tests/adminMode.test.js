/* Tests du Mode Atelier (NEBUSTION.AdminMode — déverrouillage local Admin/Admin), Node, sans Phaser.
 * Lancer : node tests/adminMode.test.js */
'use strict';
global.window = global;

// Mock minimal de localStorage (Node n'en fournit pas).
var _store = {};
global.window.localStorage = {
  getItem: function (k) { return Object.prototype.hasOwnProperty.call(_store, k) ? _store[k] : null; },
  setItem: function (k, v) { _store[k] = String(v); },
  removeItem: function (k) { delete _store[k]; }
};

require('../js/data/AdminMode.js');
const t = { passed: 0, failed: 0 };
const ok = (cond, msg) => { if (cond) t.passed++; else { t.failed++; console.log('  ✗ ECHEC : ' + msg); } };
const section = s => console.log('\n# ' + s);
const A = NEBUSTION.AdminMode;

section('Identifiants');
{
  ok(A.checkCredentials('Admin', 'Admin') === true, '« Admin » / « Admin » exact → accepté');
  ok(A.checkCredentials('admin', 'Admin') === true, 'connexion insensible à la casse pour le login');
  ok(A.checkCredentials('ADMIN', 'Admin') === true, 'login tout en majuscules accepté');
  ok(A.checkCredentials('  admin  ', 'Admin') === true, 'espaces autour du login ignorés');
  ok(A.checkCredentials('Admin', 'admin') === true, 'mot de passe insensible à la casse : accepté aussi');
  ok(A.checkCredentials('Admin', 'AdminX') === false, 'mauvais mot de passe refusé');
  ok(A.checkCredentials('quelqu.un@mail.com', 'motdepasse123') === false, 'un vrai compte joueur n\'active jamais le mode Atelier');
  ok(A.checkCredentials('', '') === false, 'champs vides refusés');
  ok(A.checkCredentials(null, null) === false, 'valeurs nulles refusées sans exception');
}

section('Activation / persistance locale');
{
  ok(A.isActive() === false, 'inactif par défaut (aucune activation encore faite)');
  A.setActive(true);
  ok(A.isActive() === true, 'setActive(true) → isActive() vrai');
  A.setActive(false);
  ok(A.isActive() === false, 'setActive(false) → isActive() faux');
}

section('Notification des changements (onChange)');
{
  var seen = [];
  var off = A.onChange(function (state) { seen.push(state); });
  A.setActive(true);
  A.setActive(false);
  ok(seen.length === 2 && seen[0] === true && seen[1] === false, 'onChange reçoit bien true puis false');
  off();
  A.setActive(true);
  ok(seen.length === 2, 'après désinscription (off()), plus aucune notification reçue');
  A.setActive(false); // remise à zéro pour ne pas polluer d'autres tests éventuels
}

console.log('\n' + (t.failed ? '✘ ' : '✔ ') + 'Mode Atelier (AdminMode) : ' + t.passed + ' réussis, ' + t.failed + ' échoués');
process.exit(t.failed ? 1 : 0);
