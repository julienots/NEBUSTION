/* NEBUSTION - test de fumée Node de BlackHoleScene « planète 3D » (faux Phaser, pas de navigateur).
 * Vérifie : création du rendu en direct, arrivée en vol, glisser (orbite + inertie), pincer, boutons/molette de zoom,
 * tap = plonger, plongée → intérieur → retour en orbite, résolution adaptative, repli sans canvas, icône de l'Univers. */
global.window = global; global.NEBUSTION = {};
var fails = 0, n = 0;
function ok(c, m) { n++; if (!c) { fails++; console.error('ECHEC: ' + m); } }
function near(a, b, t) { return Math.abs(a - b) <= t; }

// ---------- Faux Phaser ----------
var simNow = 0, timers = [];
function stub(log) {
  var st = { active: true, scaleX: 1, scaleY: 1, alpha: 1, rotation: 0, x: 0, y: 0, text: '', visible: true, texKey: null, handlers: {}, calls: {} };
  var p = new Proxy(function () {}, {
    get: function (t, k) {
      if (typeof k === 'symbol' || k === 'then') return undefined;
      if (k === '_st') return st;
      if (k in st) return st[k];
      st.calls[k] = (st.calls[k] || 0) + 1;
      if (k === 'on' || k === 'once') return function (ev, fn) { st.handlers[ev] = fn; return p; };
      if (k === 'setPosition') return function (x, y) { st.x = x; st.y = y; return p; };
      if (k === 'setText') return function (v) { st.text = v; return p; };
      if (k === 'setAlpha') return function (v) { st.alpha = v; return p; };
      if (k === 'setVisible') return function (v) { st.visible = v; return p; };
      if (k === 'setTexture') return function (key) { st.texKey = key; return p; };
      if (k === 'setScale') return function (sx, sy) { st.scaleX = sx; st.scaleY = sy === undefined ? sx : sy; return p; };
      if (k === 'destroy') return function () { st.active = false; };
      return function () { return p; };
    },
    set: function (t, k, v) { st[k] = v; return true; }
  });
  return p;
}
function fakeCtx() {
  return {
    createImageData: function (w, h) { return { data: new Uint8ClampedArray(w * h * 4), width: w, height: h }; },
    putImageData: function () { this.puts = (this.puts || 0) + 1; }
  };
}
global.Phaser = {
  BlendModes: { ADD: 1 },
  Scene: class { constructor(key) { this.key = key; } },
  Geom: { Circle: function () {}, Rectangle: function () {} }
};
function makeScene(opts) {
  opts = opts || {};
  var sc = new NEBUSTION.BlackHoleScene(), keys = {}, canvases = [], zone = null, handlers = {};
  sc.scale = { width: 720, height: 1280 };
  sc.cameras = { main: stub() };
  sc.textures = {
    exists: function (k) { return !!keys[k]; },
    get: function (k) { return keys[k]; },
    createCanvas: function (k, w, h) {
      if (opts.noCanvas) return null;
      var t = { key: k, width: w, height: h, context: fakeCtx(), refreshes: 0, refresh: function () { this.refreshes++; } };
      keys[k] = t; canvases.push(t); return t;
    }
  };
  sc.add = new Proxy({}, { get: function (t, k) { return function () { var s = stub(); if (k === 'zone') zone = s; return s; }; } });
  sc.tweens = { add: function (cfg) { if (cfg && cfg.onComplete) timers.push({ at: simNow + (cfg.duration || 0), cb: cfg.onComplete }); return stub(); } };
  sc.time = {
    delayedCall: function (ms, cb) { timers.push({ at: simNow + ms, cb: cb }); },
    addEvent: function (cfg) {
      var ev = { at: simNow + cfg.delay, cb: cfg.callback, loop: !!cfg.loop, delay: cfg.delay, removed: false, remove: function () { ev.removed = true; } };
      timers.push(ev); return ev;
    }
  };
  var ptr1 = { id: 1, x: 0, y: 0, isDown: false }, ptr2 = { id: 2, x: 0, y: 0, isDown: false };
  sc.input = { pointer1: ptr1, pointer2: ptr2, addPointer: function () {}, on: function (ev, cb) { handlers[ev] = cb; } };
  sc._h = handlers; sc._canvases = canvases; sc._zone = function () { return zone; }; sc._ptr1 = ptr1; sc._ptr2 = ptr2;
  return sc;
}
function fireDue() {
  for (var i = timers.length - 1; i >= 0; i--) {
    var t = timers[i];
    if (!t) continue;
    if (t.removed) { timers.splice(i, 1); continue; }
    if (t.at <= simNow) { if (t.loop) { t.at += t.delay; t.cb(); } else { timers.splice(i, 1); t.cb(); } }
  }
}
function frames(sc, ms) { for (var t = 0; t < ms; t += 16) { simNow += 16; sc.update(simNow, 16); fireDue(); } }

// ---------- Environnement NEBUSTION minimal ----------
NEBUSTION.SceneBackground = { build: function () {} };
NEBUSTION.FX = function () { this.toasts = []; this.toast = function (a, b) { this.toasts.push(a); }; this.shake = function () {}; this.vibrate = function () {}; };
NEBUSTION.HUD = { attach: function () { return stub(); } };
NEBUSTION.Button = function (scene, x, y, cfg) { var s = stub(); s._cfg = cfg; s._st.labelText = stub(); NEBUSTION.Button.all.push(s); return s; };
NEBUSTION.Button.all = [];
NEBUSTION.BottomNav = function () {};
NEBUSTION.Settings = { get: function () { return {}; } };
var diveCalls = 0, diveResult = { ok: false, reason: 'no_charge', msLeft: 60000 };
NEBUSTION.BlackHoleManager = {
  fragments: function () { return 12; }, chargesAvailable: function () { return 2; }, bestZone: function () { return null; }, maxDepthReached: function () { return 0; },
  hasActiveDive: function () { return false; }, msToNextCharge: function () { return 0; },
  startOrResumeDive: function () { diveCalls++; return diveResult; }, diveSnapshot: function () { return null; }, retreat: function () { return { ok: true, bonus: 0 }; }
};
NEBUSTION.BlackHole = { CFG: { MAX_CHARGES: 3 } };
NEBUSTION.BlackHoleTextures = { ensureCloseup: function () { return 'tex_bh_closeup'; }, ensureIcon: function () { return 'tex_bh_icon'; } };
require('../js/utils/BlackHoleRender.js');
require('../js/scenes/BlackHoleScene.js');
require('../js/scenes/UniverseScene.js');

function pointerAt(sc, x, y, down, id) { var p = id === 2 ? sc._ptr2 : sc._ptr1; p.x = x; p.y = y; p.isDown = down; p.id = id || 1; return p; }

// =====================================================================
// 1. Création : rendu en direct + textures + arrivée en vol
// =====================================================================
var sc = makeScene();
sc.init({ from: 'UniverseScene' }); sc.create();
ok(sc._live && sc._live.key === 'tex_bh_live_224', 'rendu en direct créé à la résolution de repos (' + (sc._live && sc._live.key) + ')');
ok(sc._canvases.length === 2 && sc._canvases[0].width === 224 && sc._canvases[1].width === 56, 'deux textures : image 224 px + lueur 56 px (' + sc._canvases.map(function (c) { return c.width; }) + ')');
ok(sc.bhImg._st.calls.setDisplaySize >= 1 && sc.bhBloom, 'image du trou noir + calque de lueur ADD');
ok(near(sc._cam.W, 48, 0.001) && sc._intro, 'arrivée en vol : la caméra part de loin (W = ' + sc._cam.W + ')');
ok(NEBUSTION.Button.all.filter(function (b) { return b._cfg && (b._cfg.label === '+' || b._cfg.label === '\u2212'); }).length === 2, 'boutons de zoom + / \u2212 créés');
ok(sc._zone() && typeof sc._zone()._st.handlers.pointerdown === 'function', 'zone tactile d\u2019orbite en place');
frames(sc, 320);
ok(sc._live.frames > 5, 'le rendu tourne (' + sc._live.frames + ' images)');
ok(sc._cam.W < 48 && sc._cam.W > 19, 'pendant l\u2019arrivée la caméra se rapproche (W = ' + sc._cam.W.toFixed(1) + ')');
frames(sc, 2800);
ok(!sc._intro && near(sc._cam.W, 19, 0.05) && near(sc._cam.incl, 1.28, 0.01) && near(sc._cam.roll, -0.42, 0.01), 'fin de l\u2019arrivée : caméra en orbite (W ' + sc._cam.W.toFixed(2) + ', incl ' + sc._cam.incl.toFixed(2) + ')');
frames(sc, 1000);
var totRef = 0, totPut = 0; sc._canvases.forEach(function (c) { totRef += c.refreshes; totPut += c.context.puts || 0; });
ok(totRef > 20 && totPut > 20, 'les textures sont rafraîchies à chaque image (' + totRef + ' refresh)');
ok(sc._canvases.some(function (c) { return c.width === 224 && c.refreshes > 3; }) && sc._canvases.some(function (c) { return c.width < 224 && c.width > 56 && c.refreshes > 3; }), 'résolution de mouvement pendant l\u2019arrivée, pleine résolution au repos');
ok(isFinite(sc._cam.W) && isFinite(sc._cam.incl) && isFinite(sc._cam.roll), 'caméra finie');

// =====================================================================
// 2. Glisser : orbite + inertie
// =====================================================================
var z = sc._zone()._st.handlers, incl0 = sc._cam.incl, roll0 = sc._cam.roll;
z.pointerdown(pointerAt(sc, 360, 660, true));
ok(sc._drag && !sc._drag.active, 'pointerdown : glissé armé, pas encore actif');
sc._h.pointermove(pointerAt(sc, 364, 662, true));
ok(!sc._drag.active, 'sous 10 px : c\u2019est encore un tap');
for (var k = 1; k <= 8; k++) { simNow += 16; sc._h.pointermove(pointerAt(sc, 360 + k * 14, 660 - k * 9, true)); sc.update(simNow, 16); }
ok(sc._drag.active, 'glissé actif');
ok(sc._cam.roll > roll0 + 0.3, 'glisser vers la droite fait rouler la caméra (' + (sc._cam.roll - roll0).toFixed(2) + ' rad)');
ok(sc._cam.incl > incl0 || sc._cam.incl === sc.INCL_MAX, 'glisser vers le haut redresse le disque vers la vue de dessus');
var rollRel;
sc._h.pointerup(pointerAt(sc, 472, 588, false)); rollRel = sc._cam.roll;
ok(sc._drag === null, 'relâché : plus de glissé');
ok(Math.abs(sc._camV.roll) > 0.3, 'inertie : vitesse résiduelle au lâcher (' + sc._camV.roll.toFixed(2) + ' rad/s)');
frames(sc, 200);
ok(sc._cam.roll > rollRel + 0.02, 'l\u2019inertie continue de faire tourner la vue');
frames(sc, 3000);
ok(sc._camV.roll === 0 && sc._camV.incl === 0, 'l\u2019inertie s\u2019éteint');
// bornes d'inclinaison
for (k = 1; k <= 40; k++) { z.pointerdown && 0; }
z.pointerdown(pointerAt(sc, 360, 900, true));
for (k = 1; k <= 60; k++) { simNow += 16; sc._h.pointermove(pointerAt(sc, 360, 900 + k * 12, true)); sc.update(simNow, 16); }
sc._h.pointerup(pointerAt(sc, 360, 1620, false));
ok(sc._cam.incl >= sc.INCL_MIN - 1e-9 && sc._cam.incl <= sc.INCL_MAX + 1e-9, 'inclinaison bornée (' + sc._cam.incl.toFixed(2) + ')');
frames(sc, 1500);
z.pointerdown(pointerAt(sc, 360, 900, true));
for (k = 1; k <= 60; k++) { simNow += 16; sc._h.pointermove(pointerAt(sc, 360, 900 - k * 12, true)); sc.update(simNow, 16); }
sc._h.pointerup(pointerAt(sc, 360, 180, false));
ok(sc._cam.incl <= sc.INCL_MAX + 1e-9, 'inclinaison bornée en haut (' + sc._cam.incl.toFixed(2) + ')');
frames(sc, 1500);

// =====================================================================
// 3. Zoom : boutons, molette, pincement
// =====================================================================
var W0 = sc._Wt;
sc._zoomBy(0.78); ok(near(sc._Wt, W0 * 0.78, 1e-6), 'bouton + : s\u2019approche (W cible ' + sc._Wt.toFixed(2) + ')');
frames(sc, 1200); ok(near(sc._cam.W, sc._Wt, 0.05), 'le zoom est lissé jusqu\u2019à la cible');
for (k = 0; k < 20; k++) sc._zoomBy(0.78);
ok(near(sc._Wt, sc.WMIN, 1e-9), 'zoom borné au plus près (W = ' + sc._Wt + ')');
for (k = 0; k < 30; k++) sc._zoomBy(1.28);
ok(near(sc._Wt, sc.WMAX, 1e-9), 'zoom borné au plus loin (W = ' + sc._Wt + ')');
sc._h.wheel({}, [], 0, -100); ok(sc._Wt < sc.WMAX, 'molette vers le haut : s\u2019approche');
sc._Wt = 19;
// pincement : deux doigts qui s'écartent → on s'approche
z.pointerdown(pointerAt(sc, 300, 660, true, 1));
pointerAt(sc, 420, 660, true, 2);
sc._h.pointermove(pointerAt(sc, 300, 660, true, 1));
ok(sc._pinch && sc._drag === null, 'pincement détecté (le glissé est annulé)');
var pinchStart = sc._Wt;
pointerAt(sc, 500, 660, true, 2); sc._h.pointermove(pointerAt(sc, 220, 660, true, 1));
ok(sc._Wt < pinchStart - 2, 'doigts qui s\u2019écartent : on s\u2019approche (W ' + pinchStart.toFixed(1) + ' → ' + sc._Wt.toFixed(1) + ')');
pointerAt(sc, 320, 660, true, 2); sc._h.pointermove(pointerAt(sc, 300, 660, true, 1));
ok(sc._Wt > pinchStart, 'doigts qui se rapprochent : on s\u2019éloigne');
sc._ptr1.isDown = false; sc._ptr2.isDown = false; sc._h.pointerup(sc._ptr1);
ok(!sc._pinch, 'fin du pincement');
sc._Wt = 19; frames(sc, 1500);

// =====================================================================
// 4. Tap = plonger ; tap trop long / hors du trou noir = rien
// =====================================================================
var before = diveCalls;
z.pointerdown(pointerAt(sc, 360, 660, true)); simNow += 100; sc._bhClock += 0.1; sc._h.pointerup(pointerAt(sc, 360, 662, false));
ok(diveCalls === before + 1, 'tap franc sur le trou noir : tente de plonger');
z.pointerdown(pointerAt(sc, 30, 400, true)); sc._h.pointerup(pointerAt(sc, 30, 400, false));
ok(diveCalls === before + 1, 'tap loin du trou noir : rien');
z.pointerdown(pointerAt(sc, 360, 660, true)); sc._bhClock += 0.9; sc._h.pointerup(pointerAt(sc, 360, 660, false));
ok(diveCalls === before + 1, 'appui long : rien (ce n\u2019est pas un tap)');
ok(sc.fx.toasts.length >= 1, 'sans charge : message affiché');

// =====================================================================
// 5. Résolution adaptative
// =====================================================================
sc._tierPenalty = 0; sc._slow = 0;
sc._live.avgMs = 60; for (k = 0; k < 30; k++) sc._adaptQuality(false);
ok(sc._tierPenalty === 1, 'appareil lent : la résolution de repos recule d\u2019un cran');
sc._applyTier(false); ok(sc._live.res === 192, 'résolution appliquée : 192 (' + sc._live.res + ')');
sc._live.avgMs = 60; for (k = 0; k < 200; k++) sc._adaptQuality(false);
ok(sc._tierPenalty <= 4, 'le recul est borné (' + sc._tierPenalty + ')');
sc._live.avgMs = 2; sc._tierPenalty = 2; for (k = 0; k < 300; k++) sc._adaptQuality(false);
ok(sc._tierPenalty === 1, 'appareil rapide : la qualité remonte');
sc._tierPenalty = 0; sc._applyTier(false); sc._live.avgMs = 3;
sc._applyTier(true); ok(sc._live.res < sc._RES[sc._restTier], 'pendant un mouvement : résolution réduite (' + sc._live.res + ')');
sc._applyTier(false); ok(sc._live.res === 224, 'au repos : pleine résolution');

// =====================================================================
// 6. Plongée → intérieur → retour en orbite
// =====================================================================
diveResult = { ok: true };
var fr = sc._live.frames;
sc._onDiveButton();
ok(sc._busy && sc._Wt === 5.4 && sc._tierLocked, 'plongée : la caméra fonce vers l\u2019horizon, résolution verrouillée');
frames(sc, 800);
ok(sc._live.frames > fr + 5, 'la chute est rendue en continu (' + (sc._live.frames - fr) + ' images)');
ok(sc._cam.W < 12, 'la caméra s\u2019est rapprochée (W = ' + sc._cam.W.toFixed(1) + ')');
frames(sc, 3000);
ok(sc._mode === 'interior' && sc.closeLayer._st.visible === false, 'on arrive à l\u2019intérieur (gros plan masqué)');
var frIn = sc._live.frames; frames(sc, 500);
ok(sc._live.frames === frIn, 'à l\u2019intérieur : plus aucun rendu du trou noir (économie de batterie)');
ok(NEBUSTION.Button.all.filter(function (b) { return b._cfg && b._cfg.label === '+'; })[0]._st.visible === false, 'boutons de zoom masqués pendant la plongée');
sc._busy = false;
sc._exitInterior();
frames(sc, 2500);
ok(sc._mode === 'closeup' && !sc._busy, 'retour au mode gros plan');
ok(!sc._tierLocked && sc._intro, 'retour : résolution déverrouillée, nouvelle arrivée en vol');
frames(sc, 3200);
ok(near(sc._cam.W, 19, 0.1), 'de retour en orbite (W = ' + sc._cam.W.toFixed(2) + ')');
ok(NEBUSTION.Button.all.filter(function (b) { return b._cfg && b._cfg.label === '+'; })[0]._st.visible === true, 'boutons de zoom de nouveau visibles');
ok(sc.bhImg._st.alpha === 1, 'image du trou noir de nouveau opaque');

// =====================================================================
// 7. Économie de batterie
// =====================================================================
NEBUSTION.Settings.get = function () { return { batterySaver: true }; };
var sb = makeScene(); sb.init({}); sb.create();
ok(sb._live.key === 'tex_bh_live_160', 'économie de batterie : résolution de repos 160 (' + sb._live.key + ')');
NEBUSTION.Settings.get = function () { return {}; };

// =====================================================================
// 8. Repli si le canvas est indisponible
// =====================================================================
var sf = makeScene({ noCanvas: true }); sf.init({}); sf.create();
ok(sf._live === null, 'sans canvas : pas de rendu en direct');
ok(sf.bhImg._st.calls.setDisplaySize >= 1, 'sans canvas : repli sur l\u2019image statique');
ok(!sf._intro && (sf._camBtns || []).length === 0, 'sans canvas : ni arrivée en vol ni boutons de zoom');
frames(sf, 500); ok(sf._diskAngle > 0.01, 'sans canvas : le disque statique tourne comme avant');
sf._orbitDown({ id: 1, x: 360, y: 660 }); sf._orbitMove({ id: 1, x: 400, y: 600, isDown: true });
ok(true, 'sans canvas : les gestes ne plantent pas');
sf._dive(); frames(sf, 4000);
ok(sf._mode === 'interior', 'sans canvas : la plongée fonctionne comme avant');

// =====================================================================
// 9. Icône vivante sur la carte Univers
// =====================================================================
var us = makeScene();
us.tweens = { add: function () { return stub(); } };
var cbs = [];
us.time = { addEvent: function (cfg) { cbs.push(cfg); return stub(); }, delayedCall: function () {} };
NEBUSTION.UniverseScene.prototype._buildBlackHoleNode.call(us, 100, 100, 130);
var iconCv = us._canvases.filter(function (c) { return /tex_bh_icon_live_96$/.test(c.key); })[0];
ok(iconCv && iconCv.refreshes >= 1, 'Univers : icône rendue une première fois (96 px)');
ok(cbs.length === 1, 'Univers : une seule minuterie d\u2019animation');
var r0 = iconCv.refreshes; cbs[0].callback(); cbs[0].callback();
ok(iconCv.refreshes === r0 + 2, 'Univers : chaque tic redessine la rotation du disque');
NEBUSTION.Settings.get = function () { return { reducedFX: true }; };
var us2 = makeScene(); us2.tweens = { add: function () { return stub(); } }; var cbs2 = [];
us2.time = { addEvent: function (cfg) { cbs2.push(cfg); return stub(); }, delayedCall: function () {} };
NEBUSTION.UniverseScene.prototype._buildBlackHoleNode.call(us2, 0, 0, 130);
ok(cbs2.length === 0, 'Univers : effets réduits → image figée, aucune minuterie');
var us3 = makeScene({ noCanvas: true }); us3.tweens = { add: function () { return stub(); } };
us3.time = { addEvent: function () { return stub(); }, delayedCall: function () {} };
NEBUSTION.Settings.get = function () { return {}; };
NEBUSTION.UniverseScene.prototype._buildBlackHoleNode.call(us3, 0, 0, 130);
ok(true, 'Univers : sans canvas, l\u2019ancienne icône est utilisée (pas d\u2019erreur)');

console.log(n + ' vérifications, ' + fails + ' échec(s)');
process.exit(fails ? 1 : 0);
