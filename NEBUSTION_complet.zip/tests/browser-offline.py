"""Test navigateur : le jeu redémarre-t-il HORS LIGNE (service worker) ? + taps réels sur les parcelles du QG.
Lancer : python3 tests/browser-offline.py   (playwright pour Python ; CHROME=/chemin/chrome optionnel)"""
import http.server, socketserver, threading, os, sys, time
from playwright.sync_api import sync_playwright
root = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
mock = open(os.path.join(root, 'tests', 'mock-phaser.js'), 'rb').read()
class H(http.server.SimpleHTTPRequestHandler):
    def __init__(s, *a, **k): super().__init__(*a, directory=root, **k)
    def do_GET(s):
        if s.path.split('?')[0] == '/js/vendor/phaser.min.js':
            s.send_response(200); s.send_header('Content-Type', 'text/javascript'); s.end_headers(); s.wfile.write(mock); return
        super().do_GET()
    def log_message(s, *a): pass
socketserver.TCPServer.allow_reuse_address = True
srv = socketserver.TCPServer(('127.0.0.1', 8774), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
passed = failed = 0
def ok(c, m):
    global passed, failed
    if c: passed += 1; print('  ✓ ' + m)
    else: failed += 1; print('  ✗ ' + m)
with sync_playwright() as p:
    kw = {'args': ['--no-sandbox']}
    if os.environ.get('CHROME'): kw['executable_path'] = os.environ['CHROME']
    b = p.chromium.launch(**kw)
    ctx = b.new_context(viewport={'width': 390, 'height': 780}, service_workers='allow')
    pg = ctx.new_page(); R = pg.evaluate
    errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)))
    def wait_scene(k, ms=20000):
        t0 = time.time()
        while time.time() - t0 < ms / 1000:
            try:
                if R("k => !!(window.__NEBUSTION_GAME__ && window.__NEBUSTION_GAME__.scene.isActive(k))", k): return True
            except Exception: pass
            time.sleep(0.2)
        return False
    pg.goto('http://127.0.0.1:8774/index.html?debug=1')
    ok(wait_scene('MainMenuScene'), 'en ligne : menu atteint')
    # attendre la fin du pré-cache
    t0 = time.time(); n = 0
    while time.time() - t0 < 60:
        n = R("caches.keys().then(ks => Promise.all(ks.map(k => caches.open(k).then(c => c.keys())))).then(a => a.reduce((s, x) => s + x.length, 0))")
        if n > 120: break
        time.sleep(1)
    ok(n > 120, 'pré-cache rempli (%d entrées)' % n)
    ok(R("navigator.serviceWorker.getRegistration().then(r => !!(r && r.active))"), 'service worker actif')
    ctx.set_offline(True)
    pg.reload()
    ok(wait_scene('MainMenuScene', 30000), 'HORS LIGNE : le jeu redémarre jusqu\'au menu')
    ok(R("!!NEBUSTION.QGScene && !!NEBUSTION.TroopManager"), 'HORS LIGNE : scripts du jeu chargés')
    # retour au QG hors ligne + taps réels
    R("(() => { const r = NEBUSTION.Resources; ['crystal','metal','energy','dust'].forEach(id => { r.state.res[id] = 5000; }); const st = r.state.qgGrid || (r.state.qgGrid = NEBUSTION.QGGrid.defaultState()); for (let x = 0; x < 6; x++) for (let y = 0; y < 6; y++) st.unlocked[x + ',' + y] = true; })()")
    R("(() => { const g = __NEBUSTION_GAME__; const k = Object.keys(g.scenes).find(n => g.scene.isActive(n)); g.scenes[k].scene.start('QGScene'); })()")
    ok(wait_scene('QGScene'), 'HORS LIGNE : QG ouvert'); time.sleep(0.5)
    S = '__NEBUSTION_GAME__.scenes.QGScene'
    # taps directs sur la logique _handleTap : parcelle (2,2) puis parcelle derrière une tour posée en (3,3)
    R(f"{S}._openPanel(3,3)"); R(f"{S}._doBuild('radar')")
    def tap_tile(c, r, dy=0):
        return R(f"(() => {{ const s = {S}; const p = s._tilePos({c},{r}); s._handleTap(p.x + s.gridLayer.x, p.y + s.gridLayer.y + {dy}); return s._panelCell ? [s._panelCell.col, s._panelCell.row, s._panelMode] : null; }})()")
    ok(tap_tile(3, 3) == [3, 3, 'built'], 'tap sur la structure posée → panneau structure')
    ok(tap_tile(4, 3) == [4, 3, 'build'], 'tap au centre de la parcelle libre voisine → panneau construire : %s' % tap_tile(4, 3))
    ok(tap_tile(3, 4) == [3, 4, 'build'], 'tap au centre de l\'autre voisine → panneau construire')
    ok(tap_tile(2, 2, -20) [:2] in ([2, 2], [3, 3]), 'tap derrière la structure : parcelle ou structure (jamais rien)')
    # échec de construction : ressources insuffisantes → toast (pas de plantage)
    R("(() => { NEBUSTION.Resources.state.res.metal = 0; })()")
    R(f"{S}._openPanel(0,0)"); R(f"{S}._doBuild('barracks')")
    ok(R(f"{S}.fx.toasts.length") >= 1, 'ressources insuffisantes → message affiché')
    ok(R(f"NEBUSTION.QGGridManager.structureAt(0,0)") is None, 'rien n\'a été construit')
    errs = [e for e in errs if 'Failed to load' not in e]
    ok(not errs, 'aucune erreur JS : ' + '; '.join(errs[:3]))
    b.close()
srv.shutdown()
print(('\n✔ ' if not failed else '\n✘ ') + 'Hors ligne + placement : %d réussis, %d échoués' % (passed, failed))
sys.exit(1 if failed else 0)
