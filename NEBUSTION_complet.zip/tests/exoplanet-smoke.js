/* NEBUSTION - test de fumée des planètes du système solaire (faux Phaser, aucun réseau).  node tests/exoplanet-smoke.js */
global.window = global;
var path = require('path'), root = path.join(__dirname, '..'), fails = 0, checks = 0, calls = {};
function ok(c, msg) { checks++; if (!c) { fails++; console.log('ÉCHEC : ' + msg); } }

// Faux objet Phaser « caméléon » : toute méthode existe, renvoie l'objet (chaînage) et est comptée.
function mk(tag) {
  var store = {};
  var p = new Proxy(function () {}, {
    get: function (t, k) {
      if (k === 'then') return undefined;
      if (k === Symbol.toPrimitive) return function () { return 0; };
      if (k in store) return store[k];
      return function () { calls[k] = (calls[k] || 0) + 1; return p; };
    },
    set: function (t, k, v) { store[k] = v; return true; },
    apply: function () { return p; }
  });
  return p;
}
global.Phaser = {
  Scene: class { constructor(key) { this.sys = { settings: { key: key } }; this.add = mk(); this.tweens = mk(); this.time = mk(); this.events = mk(); this.cameras = { main: mk() };
    this.scale = { width: 720, height: 1280 }; this.registry = mk(); this.sound = mk(); this.game = mk();
    this._handlers = {}; var self = this; this.input = { on: function (e, f) { (self._handlers[e] = self._handlers[e] || []).push(f); }, enabled: true };
    this._started = null; this.scene = { start: function (k, d) { self._started = { key: k, data: d }; } };
    this.textures = { exists: function () { return false; }, createCanvas: function () { return { context: { createImageData: function (w, h) { return { data: new Uint8ClampedArray(w * h * 4) }; }, putImageData: function () {} }, refresh: function () {} }; } }; } },
  BlendModes: { ADD: 1 },
  Math: { Clamp: function (v, a, b) { return v < a ? a : (v > b ? b : v); }, RandomDataGenerator: function () { var s = 1; this.frac = function () { s = (s * 9301 + 49297) % 233280; return s / 233280; }; } },
  Display: { Color: { GetColor: function (r, g, b) { return (r << 16) | (g << 8) | b; } } }
};
global.NEBUSTION = {
  SceneBackground: { build: function () {} }, HUD: { attach: function () { return mk(); } }, BottomNav: function () { return mk(); },
  Button: function () { return mk(); }, Settings: { get: function () { return {}; } },
  SolarTextures: { ensurePlanet: function () { return 'k'; }, ensureShade: function () { return 's'; }, ensureGlow: function () { return 'g'; }, ensureCorona: function () { return 'c'; }, ensureSun: function () { return 'u'; }, ensureRing: function () { return ['r1', 'r2']; } }
};
NEBUSTION.FX = function () { return mk(); };
var wallet = { crystal: 1e6, metal: 1e6, energy: 1e6, core: 100, dust: 1e6 };
NEBUSTION.Resources = { state: {}, saveNow: function () {}, canAfford: function (c) { return Object.keys(c).every(function (k) { return wallet[k] >= c[k]; }); },
  spendMany: function (c) { Object.keys(c).forEach(function (k) { wallet[k] -= c[k]; }); return true; }, add: function (id, a) { wallet[id] += a; return a; } };
['js/data/Economy.js', 'js/data/Colonies.js', 'js/systems/ColonyManager.js'].forEach(function (f) { require(path.join(root, f)); });
['js/utils/PlanetRender.js', 'js/scenes/PlanetScene.js', 'js/scenes/ExoPlanetScene.js', 'js/scenes/SolarSystemScene.js'].forEach(function (f) { require(path.join(root, f)); });
var N = NEBUSTION;

// ---- 1. chaque monde s'ouvre, tourne, réagit au glissé, sans valeur invalide ----
var ids = N.ExoPlanets.list.map(function (p) { return p.id; });
ok(ids.join() === 'pyros,aqualis,rubea,goliath,saturnia,glacia', '6 fiches de mondes, mêmes id que le système solaire');
var defs = new N.SolarSystemScene()._planetDefs();
ok(defs.every(function (d) { return N.ExoPlanets.get(d.id); }), 'chaque planète du système solaire a une fiche 3D');

ids.forEach(function (id) {
  calls = {};
  var s = new N.ExoPlanetScene();
  s.init({ planetId: id, from: 'SolarSystemScene' });
  var err = null;
  try { s.create(); } catch (e) { err = e; }
  ok(!err, id + ' : create() sans erreur' + (err ? ' → ' + err.stack.split('\n').slice(0, 3).join(' | ') : ''));
  if (err) return;
  ok(!!s._sphereR, id + ' : rendu par pixel actif (biome ' + s._biome + ')');
  ok(s._sphereR && s._sphereR.key.indexOf(s._biome) >= 0, id + ' : texture propre au biome (' + (s._sphereR && s._sphereR.key) + ')');
  // glissé simulé puis 90 images
  var down = s._handlers.pointerdown[0], move = s._handlers.pointermove[0], up = s._handlers.pointerup[0];
  down({ x: 300, y: 500 }); move({ x: 380, y: 540, isDown: true }); up({ x: 380, y: 540 });
  var y0 = s._rotYaw;
  for (var f = 0; f < 90; f++) { try { s.update(f * 16, 16); } catch (e) { err = e; break; } }
  ok(!err, id + ' : 90 images sans erreur' + (err ? ' → ' + err.stack.split('\n').slice(0, 3).join(' | ') : ''));
  ok(isFinite(s._rotYaw) && isFinite(s._rotPitch) && s._rotYaw !== y0, id + ' : la planète tourne au doigt (yaw ' + y0.toFixed(2) + ' → ' + s._rotYaw.toFixed(2) + ')');
  if (id === 'saturnia') ok((calls.strokePoints || 0) > 100, 'saturnia : anneaux dessinés (' + (calls.strokePoints || 0) + ' tracés)');
  if (id === 'aqualis') ok(!!s._moon, 'aqualis : lune en orbite');
  // colonie : panneau avant fondation, fondation, panneau actif, récolte, amélioration, fermeture
  var e3 = null;
  try {
    s._openColony(); ok(!!s._colonyC, id + ' : panneau colonie ouvert');
    var cm = N.ColonyManager; ok(!cm.isColonized(id), id + ' : pas encore colonisée');
    var r = cm.colonize(id, Date.now() - 3600000); ok(r.ok, id + ' : colonisation');
    s._renderColony(); s._tickColony();
    ok(cm.pendingTotal(id, Date.now()) > 0, id + ' : production en attente après 1 h');
    ok(cm.collect(id, Date.now()).ok, id + ' : récolte');
    ok(cm.upgrade(id, N.Colonies.get(id).inst[0].id, Date.now()).ok, id + ' : amélioration');
    s._renderColony(); s._closeColony(); ok(!s._colonyC, id + ' : panneau fermé');
  } catch (e) { e3 = e; }
  ok(!e3, id + ' : colonie sans erreur' + (e3 ? ' → ' + e3.stack.split('\n').slice(0, 3).join(' | ') : ''));
  // retour
  s._goBack(); s.cameras.main._fired = true;
});

// ---- 2. le système solaire : chaque planète est touchable et ouvre la bonne scène ----
calls = {};
var ss = new N.SolarSystemScene(); ss.init({ from: 'UniverseScene' });
var e2 = null; try { ss.create(); } catch (e) { e2 = e; }
ok(!e2, 'SolarSystemScene.create() sans erreur' + (e2 ? ' → ' + e2.stack.split('\n').slice(0, 3).join(' | ') : ''));
if (!e2) {
  ok(ss._planets.length === 6 && ss._planets.every(function (p) { return !!p.zone; }), '6 planètes avec zone de toucher');
  var went = [];
  ss._goTo = function (k, d) { went.push(k + ':' + d.planetId); };
  ss._planets.forEach(function (p) { ss._openPlanet(p.def, p.box); });
  ok(went.join() === ids.map(function (i) { return 'ExoPlanetScene:' + i; }).join(), 'toucher une planète ouvre ExoPlanetScene avec le bon monde');
  for (var g = 0; g < 30; g++) ss.update(g * 16, 16);
}

console.log(checks + ' vérifications, ' + fails + ' échec(s)');
process.exit(fails ? 1 : 0);
