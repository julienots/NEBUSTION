/* Tests du Pass de saison (NEBUSTION.Pass + PassManager + PassBilling), Node, sans Phaser.
 * Lancer : node tests/pass.test.js */
'use strict';
global.window = global;
['data/Economy', 'data/Heroes', 'data/Enemies', 'data/Galaxy', 'data/EmpireAI', 'data/EmpireDoctrine', 'data/EmpireEvolution', 'data/Equipment', 'data/Ships', 'data/Skins', 'data/Shop', 'data/Pass',
  'systems/SaveManager', 'systems/ResourceManager', 'systems/CombatEngine', 'systems/CombatManager', 'systems/EquipmentManager', 'systems/ShipManager', 'systems/SkinManager', 'systems/ShopManager',
  'systems/PassBilling', 'systems/PassManager'].forEach(f => require('../js/' + f + '.js'));

let passed = 0, failed = 0;
function ok(cond, msg) { if (cond) passed++; else { failed++; console.log('  ✗ ECHEC : ' + msg); } }
function section(t) { console.log('\n# ' + t); }

const P = NEBUSTION.Pass, PM = NEBUSTION.PassManager, B = NEBUSTION.PassBilling;
const store = { _m: {}, getItem(k) { return this._m[k] || null; }, setItem(k, v) { this._m[k] = v; }, removeItem(k) { delete this._m[k]; } };
NEBUSTION.Save._useStorage(store);
NEBUSTION.Resources = new NEBUSTION.ResourceManager();
NEBUSTION.Resources.init(Date.now());
const R = NEBUSTION.Resources;
const DAY = 86400000, T0 = Date.UTC(2026, 8, 14, 12, 0, 0);   // 14 sept. 2026 (début saison 1) — l'heure locale de test = TZ du processus

section('Saisons');
{
  const s1 = P.seasonInfo(T0), s2 = P.seasonInfo(T0 + 28 * DAY), s5 = P.seasonInfo(T0 + 4 * 28 * DAY);
  ok(s1.number === 1 && s2.number === 2 && s5.number === 5, 'numéros de saison 1, 2, 5 (' + s1.number + ',' + s2.number + ',' + s5.number + ')');
  ok(s1.theme.key !== s2.theme.key, 'le thème change à chaque saison');
  ok(s1.theme.key === s5.theme.key, 'les 4 thèmes tournent (saison 5 = thème de la saison 1)');
  ok(s1.msLeft > 0 && s1.msLeft <= 28 * DAY, 'compte à rebours dans (0, 28 j]');
  const last = P.seasonInfo(s1.endMs - 4 * 3600000);
  ok(last.number === 1 && last.msLeft < 6 * 3600000 && last.msLeft > 2 * 3600000, 'à 4 h de la fin de la saison 1 : encore saison 1, reste ≈ 4 h');
  ok(P.seasonInfo(s1.endMs + 1000).number === 2, '1 s après la fin : saison 2');
  ok(P.seasonInfo(T0 - 100 * DAY).number === 1, 'avant le point d\'ancrage : saison 1 (jamais négatif)');
}

section('Niveaux et XP Pass');
{
  ok(P.MAX_LEVEL === 30, '30 niveaux');
  let sum = 0; for (let n = 1; n <= 30; n++) sum += P.xpForLevel(n);
  ok(sum === P.MAX_XP && P.totalXpForLevel(30) === sum, 'XP cumulée cohérente (' + sum + ')');
  ok(P.levelFromXp(0).level === 0, 'niveau 0 à 0 XP');
  ok(P.levelFromXp(P.xpForLevel(1) - 1).level === 0 && P.levelFromXp(P.xpForLevel(1)).level === 1, 'passage du niveau 1 exactement au seuil');
  ok(P.levelFromXp(P.MAX_XP).level === 30 && P.levelFromXp(P.MAX_XP).maxed, 'niveau 30 = max');
  ok(P.levelFromXp(1e12).level === 30 && P.levelFromXp(-5).level === 0 && P.levelFromXp(NaN).level === 0, 'valeurs aberrantes bornées');
  const mid = P.levelFromXp(P.totalXpForLevel(7) + 10);
  ok(mid.level === 7 && mid.into === 10 && mid.need === P.xpForLevel(8), 'progression dans le niveau');
  // Équilibrage : les missions d'une saison peuvent amener au niveau 30 mais pas trivialement
  const dMax = 3 * 60, wMax = 3 * 300;
  ok(28 * dMax + 4 * wMax > P.MAX_XP && 28 * 100 + 4 * 500 < P.MAX_XP * 1.2, 'ordre de grandeur des missions vs XP totale');
}

section('Récompenses (30 niveaux × 2 pistes × 4 saisons)');
{
  const skins = NEBUSTION.Skins, kinds = {};
  for (let season = 0; season < 4; season++) {
    const L = P.levelsFor(season);
    ok(L.length === 30 && L.every((x, i) => x.level === i + 1), 'saison ' + season + ' : 30 niveaux ordonnés');
    ok(L.every(x => x.free && x.premium && x.free.rarity && x.premium.rarity && P.RARITIES[x.free.rarity] && P.RARITIES[x.premium.rarity]), 'saison ' + season + ' : raretés valides');
    L.forEach(x => ['free', 'premium'].forEach(t => {
      const r = x[t]; kinds[r.kind] = true;
      if (r.kind === 'skin') ok(!!skins.get(r.skinId), 'skin ' + r.skinId + ' existe');
      if (r.kind === 'frag' || r.kind === 'hero') ok(!!NEBUSTION.Heroes.get(r.heroId) && r.amount > 0, 'héros ' + r.heroId + ' existe');
      if (r.kind === 'res') ok(!!NEBUSTION.Economy.RES[r.res] && r.amount > 0, 'ressource ' + r.res);
      if (r.kind === 'res') ok(r.amount <= NEBUSTION.Economy.PROD[r.res].cap * 0.6, 'montant ' + r.res + ' ' + r.amount + ' tient dans le stockage de base');
    }));
  }
  ok(kinds.res && kinds.gems && kinds.frag && kinds.hero && kinds.skin, 'toutes les catégories présentes : ressources, Prismes, fragments, héros, skins');
  const L0 = P.levelsFor(0);
  ok(L0[29].premium.kind === 'skin' && L0[29].premium.rarity === 'legendaire', 'niveau 30 Premium = skin légendaire');
  ok(L0[19].premium.kind === 'hero', 'niveau 20 Premium = héros vedette');
  ok(P.levelsFor(0)[19].premium.heroId !== P.levelsFor(1)[19].premium.heroId, 'le héros vedette change d\'une saison à l\'autre');
  const gems = ['free', 'premium'].map(t => L0.filter(x => x[t].kind === 'gems').reduce((a, x) => a + x[t].amount, 0));
  ok(gems[0] + gems[1] <= 400, 'Prismes distribués raisonnables sur la saison (' + (gems[0] + gems[1]) + ')');
  ok(P.reward(0, 5, 'premium').kind === L0[4].premium.kind && P.reward(0, 0, 'free') === null && P.reward(0, 31, 'free') === null, 'reward() : bornes');
}

section('Missions');
{
  const a = P.pickMissions('daily', 100), b = P.pickMissions('daily', 100), c = P.pickMissions('daily', 101);
  ok(a.length === 3 && JSON.stringify(a) === JSON.stringify(b), '3 missions quotidiennes, tirage déterministe');
  ok(new Set(a.map(m => m.id)).size === 3, 'missions distinctes');
  ok(JSON.stringify(a) !== JSON.stringify(c) || P.pickMissions('daily', 102).map(m => m.id).join() !== a.map(m => m.id).join(), 'le tirage varie selon le jour');
  ok(P.pickMissions('weekly', 7).length === 3 && P.pickMissions('weekly', 7).every(m => P.mission(m.id).kind === 'weekly'), '3 missions hebdomadaires');
  const seen = new Set(); for (let d = 0; d < 60; d++) P.pickMissions('daily', d).forEach(m => seen.add(m.id));
  ok(seen.size === P.DAILY_POOL.length, 'toutes les missions quotidiennes sortent un jour ou l\'autre');
  ok(P.mission('__proto__') === null && P.mission('constructor') === null, 'identifiants piégés refusés');
}

section('Sauvegarde : normalisation et changements de période');
{
  const now = T0;
  const d = P.defaultState(now);
  ok(d.season === 0 && d.xp === 0 && d.premium === false && d.daily.list.length === 3 && d.weekly.list.length === 3, 'état par défaut');
  ok(JSON.stringify(P.normalizeState(JSON.parse(JSON.stringify(d)), now)) === JSON.stringify(d), 'aller-retour JSON identique');
  [null, undefined, 5, 'x', [], { season: 'a', xp: 'b', claimed: 7, daily: 3 }, { xp: -50, premium: 'oui' }].forEach((raw, i) => {
    const s = P.normalizeState(raw, now);
    ok(s.xp >= 0 && s.premium === false && s.daily.list.length === 3, 'entrée aberrante #' + i + ' nettoyée');
  });
  const mid = P.normalizeState({ season: 0, xp: 500, premium: true, premiumSource: 'test', claimed: { free: { 1: true, 99: true, x: true }, premium: { 2: true } },
    daily: { day: P.dayIndex(now), list: [{ id: P.pickMissions('daily', P.dayIndex(now))[0].id, p: 9999, c: true }, { id: 'inconnue', p: 1 }] } }, now);
  ok(mid.xp === 500 && mid.premium && mid.claimed.free[1] && !mid.claimed.free[99] && mid.claimed.premium[2], 'progression conservée, niveaux invalides ignorés');
  ok(mid.daily.list.length === 1 && mid.daily.list[0].p === P.mission(mid.daily.list[0].id).target && mid.daily.list[0].c, 'mission : progression bornée, id inconnu retiré');
  const tomorrow = P.normalizeState(mid, now + DAY);
  ok(tomorrow.xp === 500 && tomorrow.daily.day === P.dayIndex(now) + 1 && tomorrow.daily.list.every(m => m.p === 0 && !m.c), 'nouveau jour : missions quotidiennes remises à zéro, XP conservée');
  const nextSeason = P.normalizeState(mid, now + 28 * DAY);
  ok(nextSeason.season === 1 && nextSeason.xp === 0 && !nextSeason.premium && Object.keys(nextSeason.claimed.free).length === 0, 'nouvelle saison : progression et Premium remis à zéro');
  ok(nextSeason.history.length === 1 && nextSeason.history[0].season === 0 && nextSeason.history[0].level >= 1 && nextSeason.history[0].premium === true, 'saison précédente archivée');
  const back = P.normalizeState(nextSeason, now);
  ok(back.season === 1, 'horloge revenue en arrière : la progression n\'est jamais effacée');
  ok(P.normalizeState(mid, now + 29 * DAY).weekly.week === P.weekIndex(now + 29 * DAY), 'semaine mise à jour');
}

section('Intégration : état dans la sauvegarde du jeu');
{
  ok(R.state.pass != null, 'state.pass créé par SaveManager.defaultState');
  ok(PM.state() === R.state.pass || JSON.stringify(PM.state()).length > 10, 'PassManager lit l\'état de la sauvegarde');
  PM.state().xp = 321; R.saveNow(Date.now());
  const R2 = new NEBUSTION.ResourceManager(); R2.init(Date.now());
  ok(R2.state.pass && R2.state.pass.xp === 321, 'l\'XP Pass survit à un rechargement (sauvegarde/chargement)');
  PM.state().xp = 0;
  const old = JSON.parse(JSON.stringify(R.state)); delete old.pass; NEBUSTION.Save.write(old, Date.now());   // sauvegarde « d'avant le Pass »
  const R3 = new NEBUSTION.ResourceManager(); R3.init(Date.now());
  ok(R3.state.pass && R3.state.pass.xp === 0 && R3.state.pass.daily.list.length === 3, 'ancienne sauvegarde sans Pass : chargée sans erreur');
}

section('PassManager : XP, missions, réclamation');
{
  NEBUSTION.DEBUG = false;
  ok(PM.level().level === 0 && !PM.isPremium(), 'départ : niveau 0, gratuit');
  ok(PM.status(1, 'free') === 'locked', 'niveau 1 verrouillé à 0 XP');
  ok(PM.claim(1, 'free').reason === 'verrouille', 'réclamation refusée si niveau non atteint');
  const dm = PM.missions('daily'), wm = PM.missions('weekly');
  ok(dm.length === 3 && wm.length === 3 && dm.every(m => m.status === 'progress' || m.status === 'ready'), 'missions présentes');
  // Complète toutes les missions quotidiennes via track()
  ['login', 'tap', 'pod', 'upgrade', 'battle', 'win', 'purchase', 'gift'].forEach(k => PM.track(k, 1000));
  ok(PM.missions('daily').every(m => m.status === 'ready' && m.p === m.target), 'track() complète les missions et borne la progression');
  const before = PM.state().xp, m0 = PM.missions('daily')[0];
  const cr = PM.claimMission('daily', m0.id);
  ok(cr.ok && PM.state().xp === before + m0.xp, 'réclamer une mission ajoute son XP');
  ok(PM.claimMission('daily', m0.id).reason === 'deja', 'une mission ne se réclame qu\'une fois');
  ok(PM.claimMission('daily', 'inconnue').ok === false && PM.claimMission('weekly', m0.id).ok === false, 'mission inconnue / mauvaise liste refusée');
  const all = PM.claimAllMissions();
  ok(all.ok && all.count >= 2, 'tout réclamer (missions)');
  ok(PM.readyMissionCount() === 0, 'plus aucune mission prête');

  PM.state().xp = P.totalXpForLevel(3);   // niveau 3 pile
  ok(PM.level().level === 3, 'niveau 3 atteint');
  ok(PM.status(3, 'free') === 'available' && PM.status(4, 'free') === 'locked', 'statuts free');
  ok(PM.status(1, 'premium') === 'premium_locked', 'piste Premium verrouillée sans Premium (même niveau atteint)');
  ok(PM.claim(1, 'premium').reason === 'premium', 'réclamation Premium refusée sans Premium');

  const dust0 = R.get('dust');
  const c1 = PM.claim(1, 'free');
  ok(c1.ok && c1.reward.kind === 'res' && R.get('dust') >= dust0 + 799, 'niveau 1 gratuit : ressources créditées');
  ok(PM.claim(1, 'free').reason === 'deja', 'pas de double réclamation');
  ok(PM.status(1, 'free') === 'claimed', 'statut réclamé');
  const f = PM.claimAll();
  ok(f.ok && f.claimed.length === 2 && PM.claimableList().length === 0, 'tout réclamer (niveaux 2 et 3)');
  R.saveNow(Date.now());
  const R4 = new NEBUSTION.ResourceManager(); R4.init(Date.now());
  ok(R4.state.pass.claimed.free[1] && R4.state.pass.claimed.free[3], 'réclamations sauvegardées');
}

section('Réclamation : Prismes, fragments, skins, stockage');
{
  const SM = NEBUSTION.ShopManager, Cb = NEBUSTION.Combat, SK = NEBUSTION.SkinManager;
  PM.addXp(1e9);
  ok(PM.level().level === 30, 'niveau 30 (XP plafonnée)');
  const g0 = SM.gems();
  // Prismes (niveau 5 gratuit)
  const rg = PM.claim(5, 'free');
  ok(rg.ok && rg.reward.kind === 'gems' && SM.gems() === g0 + rg.reward.amount, 'Prismes crédités');
  // Fragments (niveau 4 gratuit)
  const fr = PM.levels()[3].free, fb = (Cb.state ? 0 : 0);
  const fbefore = R.state.combat ? (R.state.combat.fragments[fr.heroId] || 0) : 0;
  const rf = PM.claim(4, 'free');
  ok(rf.ok && (R.state.combat.fragments[fr.heroId] || 0) === fbefore + fr.amount, 'fragments crédités au héros de la saison');
  // Skin gratuit niveau 10 + doublon
  const sk = PM.levels()[9].free;
  ok(!SK.isOwned(sk.skinId), 'skin pas encore possédé');
  const rs = PM.claim(10, 'free');
  ok(rs.ok && SK.isOwned(sk.skinId) && !rs.dup, 'skin débloqué dans la collection');
  // Doublon (Premium niveau 5 = autre skin ; on force un doublon en possédant déjà le skin)
  PM.debugSetPremium(true);   // DEBUG désactivé : ne doit rien faire
  ok(!PM.isPremium(), 'debugSetPremium sans ?debug=1 : refusé');
  ok(PM.grantPremium({ source: 'test' }) === true && PM.isPremium(), 'grantPremium (chemin réservé à PassBilling) active le Premium');
  const p1 = PM.levels()[4].premium; SK.grant(p1.skinId);
  const gb = SM.gems(), rd = PM.claim(5, 'premium');
  ok(rd.ok && rd.dup === true && rd.convertedGems > 0 && SM.gems() === gb + rd.convertedGems, 'skin déjà possédé : converti en Prismes');
  // Héros vedette + piste Premium niveau 30
  const rh = PM.claim(20, 'premium');
  ok(rh.ok && rh.reward.kind === 'hero', 'héros vedette réclamé');
  // Stockage plein : refus sans perte
  R.state.res.dust = R.cap('dust');
  const full = PM.claim(6, 'free');   // 1500 poussière
  ok(full.ok === false && full.reason === 'stockage' && PM.status(6, 'free') === 'available', 'stockage plein : réclamation refusée, récompense conservée');
  const ca = PM.claimAll();
  ok(ca.blocked.some(b => b.reason === 'stockage'), 'tout réclamer signale les récompenses bloquées');
  R.state.res.dust = 0;
  ok(PM.claim(6, 'free').ok, 'après avoir libéré du stockage, la réclamation réussit');
  const rest = PM.claimAll();
  ok(PM.claimableList().length === 0 || rest.blocked.length > 0, 'tout le reste se réclame');
  ok(PM.claim(30, 'premium').status === undefined && PM.status(30, 'premium') === 'claimed', 'niveau 30 Premium réclamé');
}

section('Branchement sur le jeu (wire)');
{
  PM._reset();
  R.state.pass = P.defaultState(Date.now());
  PM.wire(); PM.wire();   // idempotent
  const prog = k => PM.missions('daily').concat(PM.missions('weekly')).filter(m => m.metric === k);
  // Force des listes connues pour vérifier chaque métrique
  const st = PM.state();
  st.daily.list = [{ id: 'd_tap', p: 0, c: false }, { id: 'd_win', p: 0, c: false }, { id: 'd_upgrade', p: 0, c: false }];
  st.weekly.list = [{ id: 'w_battle15', p: 0, c: false }, { id: 'w_shop3', p: 0, c: false }, { id: 'w_pod5', p: 0, c: false }];
  const get = id => PM.missions('daily').concat(PM.missions('weekly')).find(m => m.id === id).p;
  R.tap('dust', Date.now());
  ok(get('d_tap') === 1, 'un tap d\'extraction fait avancer la mission « Extraire »');
  R.claimPod(Date.now());
  ok(get('w_pod5') === 1, 'une caisse réclamée fait avancer la mission « caisses »');
  const stage = NEBUSTION.Enemies.STAGES ? NEBUSTION.Enemies.STAGES[0] : null;
  if (stage) {
    NEBUSTION.Combat.grantRewards(stage, 'normal', { win: true, stars: 3, time: 10 });
    ok(get('d_win') === 1 && get('w_battle15') === 1, 'une victoire de combat fait avancer « Remporter » et « Livrer »');
    NEBUSTION.Combat.grantRewards(stage, 'normal', { win: false });
    ok(get('d_win') === 1 && get('w_battle15') === 2, 'une défaite compte comme combat livré mais pas comme victoire');
  } else console.log('  (combat non testé : NEBUSTION.Enemies.STAGES absent)');
  ['metal', 'crystal', 'energy', 'core', 'dust'].forEach(id => R.add(id, 1e6, 'test'));
  const up = R.upgradeBuilding('storage');
  if (up.ok) ok(get('d_upgrade') === 1, 'amélioration de bâtiment comptée'); else console.log('  (upgrade non testé : ' + up.reason + ')');
  R.state.shop.gems += 1000;
  const skinToBuy = NEBUSTION.Skins.SKINS.find(s => s.rarity === 'commun' && !NEBUSTION.SkinManager.isOwned(s.id));
  const sb = NEBUSTION.SkinManager.buy(skinToBuy.id);
  ok(sb.ok && get('w_shop3') === 1, 'achat de skin compté comme achat boutique');
  const gift = NEBUSTION.ShopManager.claimDailyGift();
  ok(gift.ok || gift.reason === 'deja', 'le cadeau quotidien reste fonctionnel après wrapping');
  ok(NEBUSTION.ShopManager.buyDaily('inexistante').ok === false && get('w_shop3') === 1, 'achat échoué = pas de progression');
}

section('Paiement provisoire en ressources (pas un paiement réel)');
{
  PM._reset(); R.state.pass = P.defaultState(Date.now());
  const price = B.resourcePrice(), ids = Object.keys(price), E0 = NEBUSTION.Economy;
  ok(ids.length === 5 && ids.every(id => E0.RES[id] && price[id] > 0 && price[id] <= E0.PROD[id].cap), 'prix défini pour les 5 ressources, chacun ≤ stockage de base');
  price.crystal = 1; ok(B.resourcePrice().crystal !== 1, 'resourcePrice() renvoie une copie (non modifiable de l\'extérieur)');
  ids.forEach(id => R.spend(id, R.get(id)));
  ok(!B.canPayWithResources() && !PM.isPremium(), 'sans ressources : paiement impossible');
  const r0 = B.payWithResources();
  ok(r0.ok === false && r0.reason === 'ressources' && !PM.isPremium(), 'sans ressources : refus, Premium NON activé');
  const p2 = B.resourcePrice();
  ids.forEach(id => R.add(id, p2[id], 'test')); R.spend('dust', 1);          // il manque 1 poussière
  ok(!B.canPayWithResources() && B.payWithResources().reason === 'ressources' && !PM.isPremium(), 'il manque une seule ressource : refus');
  ok(ids.every(id => Math.abs(R.get(id) - (id === 'dust' ? p2[id] - 1 : p2[id])) < 1e-6), 'refus atomique : rien n\'est débité');
  R.add('dust', 1, 'test');
  const before = {}; ids.forEach(id => before[id] = R.get(id));
  ok(B.canPayWithResources(), 'ressources suffisantes : paiement possible');
  const r1 = B.payWithResources();
  ok(r1.ok === true && PM.isPremium() && PM.state().premiumSource === 'resources', 'paiement : Premium activé, source « resources »');
  ok(ids.every(id => Math.abs(before[id] - R.get(id) - p2[id]) < 1e-6), 'ressources débitées exactement du prix');
  ids.forEach(id => R.add(id, p2[id], 'test')); const b2 = {}; ids.forEach(id => b2[id] = R.get(id));
  const r2 = B.payWithResources();
  ok(r2.ok === false && r2.reason === 'deja' && ids.every(id => Math.abs(R.get(id) - b2[id]) < 1e-6), 'déjà Premium : refus, aucune ressource perdue (pas de double paiement)');
  ok(B.providerId() === 'none' && B.isAvailable() === false, 'le fournisseur Google Play reste indisponible (rien de simulé côté facturation)');
}

section('Achats intégrés : aucune simulation');
{
  PM._reset(); R.state.pass = P.defaultState(Date.now());
  ok(B.providerId() === 'none' && B.isAvailable() === false, 'fournisseur par défaut : indisponible');
  ok(B.skuForSeason(3) === 'nebustion_pass_premium_s3', 'SKU par saison');
  let done = false;
  B.purchasePremium().then(r => {
    ok(r.ok === false && r.reason === 'billing_unavailable' && !PM.isPremium(), 'purchasePremium() sans fournisseur : refus, Premium NON activé');
    return B.restore();
  }).then(r => {
    ok(r.ok === false && !PM.isPremium(), 'restore() sans fournisseur : rien activé');
    ok(B.registerProvider({ id: 'x' }) === false && B.providerId() === 'none', 'fournisseur incomplet refusé');
    ok(B.registerProvider({ id: 'faux', isAvailable: () => true, getProduct: () => Promise.resolve(null), purchase: () => Promise.resolve({ ok: false, reason: 'annule' }), restore: () => Promise.resolve({ ok: false }) }), 'fournisseur valide enregistré');
    return B.purchasePremium();
  }).then(r => {
    ok(r.ok === false && r.reason === 'annule' && !PM.isPremium(), 'achat annulé par le fournisseur : Premium NON activé');
    B.registerProvider({ id: 'faux2', isAvailable: () => true, getProduct: () => Promise.resolve(null), purchase: () => Promise.reject(new Error('boom')), restore: () => Promise.resolve({ ok: false }) });
    return B.purchasePremium();
  }).then(r => {
    ok(r.ok === false && !PM.isPremium(), 'erreur du fournisseur : Premium NON activé');
    B.registerProvider({ id: 'test_ok', isAvailable: () => true, getProduct: () => Promise.resolve(null), purchase: sku => Promise.resolve({ ok: true, token: 't-' + sku }), restore: () => Promise.resolve({ ok: false }) });
    return B.purchasePremium();
  }).then(r => {
    ok(r.ok === true && PM.isPremium() && PM.state().premiumSource === 'test_ok', 'achat confirmé PAR le fournisseur : Premium activé (fournisseur de test local, pas un vrai paiement)');
    B.resetProvider(); done = true;
  }).catch(e => { failed++; console.log('  ✗ ECHEC : exception ' + e.message); }).then(() => {
    ok(done, 'scénarios de facturation terminés');
    console.log('\n' + passed + ' réussis, ' + failed + ' échoués');
    process.exit(failed ? 1 : 0);
  });
}
