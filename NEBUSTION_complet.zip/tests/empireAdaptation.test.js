/* Tests de finalisation du module IA : adaptation, doctrines, unités entraînées, revendications, carte/invasion, sauvegarde, bornes.
   Node, sans dépendance. Lancer : node tests/empireAdaptation.test.js */
'use strict';
global.window = global;
require('../js/data/Economy.js'); require('../js/data/Heroes.js'); require('../js/data/Enemies.js'); require('../js/data/Galaxy.js');
require('../js/data/EmpireAI.js'); require('../js/data/EmpireDoctrine.js'); require('../js/data/EmpireEvolution.js');
require('../js/systems/SaveManager.js'); require('../js/systems/ResourceManager.js'); require('../js/systems/CombatEngine.js');
require('../js/systems/CombatManager.js'); require('../js/systems/GalaxyManager.js'); require('../js/systems/EmpireAIManager.js'); require('../js/systems/EmpireEvolutionManager.js');

const G = NEBUSTION.Galaxy, GM = NEBUSTION.GalaxyManager, AIM = NEBUSTION.EmpireAIManager, AI = NEBUSTION.EmpireAI, EE = NEBUSTION.EmpireEvolution,
  DR = NEBUSTION.EmpireDoctrine, EM = NEBUSTION.EmpireEvolutionManager, Save = NEBUSTION.Save;
let passed = 0, failed = 0;
function ok(c, m) { if (c) passed++; else { failed++; console.log('  ✗ ECHEC : ' + m); } }
function section(t) { console.log('\n# ' + t); }
function memStorage() { const m = {}; return { data: m, getItem: k => (k in m ? m[k] : null), setItem: (k, v) => { m[k] = String(v); }, removeItem: k => { delete m[k]; } }; }
const T0 = 1_800_000_000_000, H = 3600 * 1000, DAY = 24 * H;
const realTeam = GM.teamLevel;
const galaxySnapshot = JSON.stringify(G.PLANETS.map(p => [p.id, p.defense, p.power, p.recLevel, p.scale, p.rewards]));
const unitSnapshot = JSON.stringify(G.EMPIRE_ORDER.map(e => G.empire(e).units));
let storage;
function fresh(team, diff) {
  storage = memStorage(); Save._useStorage(storage);
  NEBUSTION.Resources = new NEBUSTION.ResourceManager(); NEBUSTION.Resources.init(T0);
  NEBUSTION.Resources.state.empires.seed = 12345;
  G.SECTORS.forEach(s => { GM.state().unlocked[s.id] = true; });
  GM.teamLevel = () => (team == null ? 45 : team);
  NEBUSTION.Resources.state.combat.difficulty = diff || 'normal';
  AIM.invalidate(); EM.stop();
  return NEBUSTION.Resources;
}
function run(days, from) { let t = from || T0; for (let i = 0; i < days * 4; i++) { t += 6 * H; EM.update(t); } return t; }
function sum(eid, kind) { const d = EM.state().e[eid].def; return Object.keys(d).reduce((s, k) => s + d[k][kind], 0); }
function scan(pid, at) { GM.state().scans[pid] = { at: at }; }
const IDS = G.EMPIRE_ORDER;

section('Doctrine : styles, capacités, adaptation, unités entraînées (fonctions pures)');
{
  ok(IDS.every(e => DR.STYLE[e] && DR.CAPS[e].length === 3 && DR.CRISIS[e]), '6 empires : style, 3 capacités, 1 capacité de crise');
  ok(IDS.every(e => ['sh', 'tu', 'fl'].every(k => DR.styleMax(e, k, 9) >= 1 && DR.styleMax(e, k, 9) <= (k === 'sh' ? EE.SH_MAX : k === 'tu' ? EE.TU_MAX : 2))), 'plafonds propres à chaque empire ≤ plafonds globaux');
  ok(new Set(IDS.map(e => JSON.stringify(DR.STYLE[e].max))).size === 6, 'chaque empire a un profil de plafonds différent');
  ok(DR.STYLE.elyra.max.sh > DR.STYLE.morvak.max.sh && DR.STYLE.morvak.max.tu > DR.STYLE.elyra.max.tu, 'ELYRA = boucliers, MORVAK = tourelles/offensive');
  ok(IDS.every(e => DR.capabilities(e, 0, 0).list.length === 0), 'evo 0 : aucune capacité');
  IDS.forEach(e => {
    const n = ev => DR.capabilities(e, ev, 0).list.length;
    ok(n(1) === 0 && n(2) === 1 && n(4) === 2 && n(6) === 3 && n(8) === 3, e + ' : capacités déverrouillées à evo 2/4/6');
    const b = DR.capabilities(e, 8, 0).bonus;
    ok(Object.keys(b).every(k => b[k] <= DR.LIMITS[k] + 1e-9 && b[k] > 0), e + ' : bonus plafonnés');
  });
  ok(new Set(IDS.map(e => JSON.stringify(DR.capabilities(e, 8, 0).bonus))).size === 6, 'les 6 empires ont des bonus de combat tous différents');
  const c0 = DR.capabilities('morvak', 4, 0), c1 = DR.capabilities('morvak', 4, 1), c5 = DR.capabilities('morvak', 4, 0.5);
  ok(!c0.list.some(c => c.crisis) && c1.list.some(c => c.crisis) && c1.bonus.atkBonus > c5.bonus.atkBonus && c5.bonus.atkBonus > c0.bonus.atkBonus, 'capacité de crise : absente au calme, proportionnelle au traumatisme');
  ok(DR.capabilities('zzz', 5, 0).list.length === 0 && DR.capabilities('vexor', NaN, NaN).list.length === 0, 'entrées invalides tolérées');
  const a0 = DR.adaptation({}), aL = DR.adaptation({ lossRatio: 0.6, hurt: 0.3, pressure: 0.5 }), aL2 = DR.adaptation({ lossRatio: 1, hurt: 1, pressure: 1, capitalLost: 1 });
  ok(Object.keys(a0.mult).every(k => a0.mult[k] === 1) && a0.actions === 3 && a0.focus === 'growth', 'situation calme : aucun changement');
  ok(aL.mult.sh > 1 && aL.mult.tu > 1 && aL.mult.evo < 1 && aL2.mult.sh > aL.mult.sh && aL2.mult.evo < aL.mult.evo, 'pertes : plus de défense, moins de développement (croissant avec les pertes)');
  ok(aL2.focus === 'shield', 'empire très blessé : priorité boucliers');
  ok(DR.adaptation({ capitalLost: 1 }).mult.fl > 1 && DR.adaptation({ momentum: 1 }).mult.ut > 1, 'capitale perdue → reconstruction de flotte ; élan → entraînement');
  ok(DR.adaptation({ stockRatio: 0.9 }).actions === 4 && DR.adaptation({ stockRatio: 0.5 }).actions === 3, 'stock plein : 1 action de plus (bornée à 4)');
  ok(Object.values(DR.adaptation({ lossRatio: 9, hurt: 9, pressure: 9, capitalLost: 1, momentum: 9, stockRatio: 9 }).mult).every(x => x >= 0.5 && x <= 2), 'multiplicateurs bornés [0.5, 2] même avec des entrées absurdes');
  ok(DR.adaptation({ lossRatio: NaN, hurt: 'x', pressure: undefined }).mult.sh === 1, 'NaN/undefined tolérés');
  const u = G.unitDef('mo_imp'), u3 = DR.rankedDef(u, 3);
  ok(DR.rankedDef(u, 0) === u && DR.rankedDef(null, 2) === null, 'rang 0 = définition d\'origine ; null toléré');
  ok(u3.id === u.id && u3.base.hp === Math.round(u.base.hp * (1 + 3 * DR.RANK_STEP)) && u3.base.atk > u.base.atk && u3.base.def === u.base.def && u3.name.indexOf('★★★') > 0 && u3.rank === 3, 'rang 3 : hp/atk augmentés, id conservé, nom étoilé');
  ok(DR.rankedDef(u, 99).rank === DR.RANK_MAX && DR.rankedDef(u, -4) === u, 'rang borné [0..3]');
  ok(JSON.stringify(G.unitDef('mo_imp')) === JSON.stringify(u) && JSON.stringify(G.EMPIRE_ORDER.map(e => G.empire(e).units)) === unitSnapshot, 'la définition d\'origine n\'est jamais modifiée');
  ok(DR.rankMax(0) === 0 && DR.rankMax(2) === 1 && DR.rankMax(4) === 2 && DR.rankMax(8) === 3 && DR.rankMax(99) === 3, 'rang maximal lié au développement');
}

section('État sauvegardé v2 : validation, compatibilité v1');
{
  const n = EE.normalizeState(null, T0);
  ok(n.v === 2 && IDS.every(e => n.e[e].hurt === 0 && n.e[e].mom === 0 && n.e[e].lost === 0 && Object.keys(n.e[e].rank).length === 0 && Object.keys(n.e[e].claims).length === 0), 'état neuf v2 complet');
  const v1 = { v: 1, lastAt: T0, n: 5, seed: 9, e: { morvak: { evo: 3, res: { metal: 100 }, def: { mo1: { sh: 2, tu: 1, fl: 0 } }, lastRec: 0, rec: 1, spent: 500, ups: 4 } } };
  const m = EE.normalizeState(v1, T0 + 1);
  ok(m.e.morvak.evo === 3 && m.e.morvak.def.mo1.sh === 2 && m.e.morvak.hurt === 0 && m.e.morvak.claims && m.e.morvak.rank && m.e.vexor.lostAt, 'ancien état v1 : conservé + champs v2 par défaut');
  const bad = EE.normalizeState({ lastAt: T0, e: {
    vexor: { evo: 4, rank: { vx_scrapper: 99, vx_piston: -3, k9_trooper: 2, zzz: 1 }, hurt: 9, mom: -4, lost: -2, held: 'x',
      lostAt: { vx1: T0 - 5, k91: T0, nope: 1 }, claims: { lyr: T0, halo7: T0, cendre2: T0, vx1: T0, nope: T0 } },
    kael9: { evo: 4, claims: { lyr: T0, halo7: T0 } }, elyra: { evo: 0, rank: { el_acolyte: 3 } }
  } }, T0);
  const v = bad.e.vexor;
  ok(v.rank.vx_scrapper === DR.rankMax(4) && v.rank.vx_piston === undefined && v.rank.k9_trooper === undefined && v.rank.zzz === undefined, 'rangs : borné par evo, unités étrangères rejetées');
  ok(v.hurt === 1 && v.mom === 0 && v.lost === 0 && v.held === 0, 'hurt/mom/lost/held bornés et réparés');
  ok(v.lostAt.vx1 !== undefined && v.lostAt.k91 === undefined && v.lostAt.nope === undefined, 'planètes perdues : seulement celles de l\'empire');
  ok(Object.keys(v.claims).length === EE.CLAIM.maxPerEmpire && v.claims.vx1 === undefined && v.claims.nope === undefined, 'revendications : neutres seulement, max ' + EE.CLAIM.maxPerEmpire);
  ok(!Object.keys(bad.e.kael9.claims).some(p => v.claims[p] !== undefined), 'un monde ne peut avoir qu\'un seul revendicateur');
  ok(bad.e.elyra.rank.el_acolyte === undefined, 'evo 0 : aucun rang possible');
  ok(EE.normalizeState('nimportequoi', T0).v === 2 && EE.normalizeState({ e: 5 }, T0).e.vexor.evo === 0, 'entrées absurdes → état neuf');
}

section('Adaptation aux pertes (conquêtes du joueur) et mémoire');
{
  // Deux mondes identiques ; dans l'un, le joueur conquiert 2 planètes d'ELYRA
  const ctl = () => { fresh(45); run(1); return run(3, T0 + DAY); };
  ctl(); const c = { hurt: EM.state().e.elyra.hurt, sh: sum('elyra', 'sh'), evo: EM.state().e.elyra.evo, owned: 5 };
  fresh(45); run(1);
  const el = G.planetsOfEmpire('elyra'); el[3].id; GM.setConquered(el[0].id, true, T0 + DAY); GM.setConquered(el[1].id, true, T0 + DAY);
  const e0 = EM.state().e.elyra;
  EM.update(T0 + DAY + 1000);
  ok(e0.lost === 2 && e0.hurt >= 0.5 && Object.keys(e0.lostAt).length === 2, 'pertes détectées à la prochaine mise à jour : compteur, traumatisme, mémoire des planètes');
  const h1 = e0.hurt; EM.reconcile(T0 + DAY + 2000); EM.reconcile(T0 + DAY + 3000); EM.update(T0 + DAY + 4000);
  ok(e0.lost === 2 && e0.hurt <= h1 && Object.keys(e0.lostAt).length === 2, 'idempotent : mêmes pertes jamais recomptées');
  const st = EM.empireStatus('elyra', T0 + DAY + 5000);
  ok(st.alert >= 1 && st.alert <= 3 && st.hurt >= 0.5 && st.lost === 2, 'bilan : alerte élevée, traumatisme, pertes');
  ok(st.posture === 'defensive' && st.focus === 'shield', 'ELYRA blessée : posture défensive et priorité boucliers (adaptation)');
  ok(st.capabilities.length >= 0 && DR.capabilities('elyra', st.evo, st.hurt).list.some(c => c.crisis), 'capacité de crise active après les pertes');
  const t1 = run(3, T0 + DAY);
  const e1 = EM.state().e.elyra, owned = 3;
  ok(e1.hurt < 0.1, 'le traumatisme s\'estompe avec le temps (' + e1.hurt + ')');
  ok(e1.evo <= c.evo, 'un empire blessé investit moins dans son développement (' + e1.evo + ' ≤ ' + c.evo + ')');
  const perPlanetSh = sum('elyra', 'sh') / owned, perCtl = c.sh / 5;
  ok(perPlanetSh >= perCtl * 0.95, 'boucliers par planète restante ≥ témoin (' + perPlanetSh.toFixed(2) + ' vs ' + perCtl.toFixed(2) + ')');
  ok(EM.state().e.vexor.lost === 0 && EM.state().e.vexor.hurt === 0, 'les autres empires ne sont pas touchés');

  // Conquête ancienne (> 24 h) : comptée mais aucun traumatisme
  fresh(45); run(3);
  GM.setConquered(G.planetsOfEmpire('nyrah')[0].id, true, T0 - 5 * DAY + 0); EM.update(T0 + 3 * DAY + 6 * H);
  ok(EM.state().e.nyrah.lost === 1 && EM.state().e.nyrah.hurt === 0, 'conquête ancienne : comptée sans traumatisme rétroactif');
  // Planète reprise → oubliée
  fresh(45); const k = G.planetsOfEmpire('kael9')[0]; GM.setConquered(k.id, true, T0); EM.update(T0 + 1000);
  ok(EM.state().e.kael9.lostAt[k.id] !== undefined, 'planète conquise mémorisée');
  GM.setConquered(k.id, false, T0 + 2000); EM.reconcile(T0 + 3000);
  ok(EM.state().e.kael9.lostAt[k.id] === undefined && EM.state().e.kael9.lost === 1, 'planète reprise : oubliée (compteur historique conservé)');
  // Réaction immédiate par événement, un seul abonnement
  fresh(45); EM.start(); EM.start(); EM.stop();
  const m = G.planetsOfEmpire('morvak')[0]; GM.setConquered(m.id, true, Date.now());
  ok(EM.state().e.morvak.lost === 1 && EM.state().e.morvak.hurt > 0, 'événement « conquest » : réaction immédiate, une seule fois malgré 2 start()');
  // Mémoire → stratégie (EmpireAI)
  let flips = 0, flipsOff = 0;
  ['vexor', 'kael9', 'elyra', 'nyrah'].forEach(e => {
    let f = false;
    for (let p = 0; p <= 1 && !f; p += 0.05) for (let l = 0; l <= 1 && !f; l += 0.05) for (let d = 0; d <= 1 && !f; d += 0.1) {
      const s = { pressure: p, lossRatio: l, dominance: d, capitalLost: 0 };
      if (AI.chooseStrategy(e, Object.assign({ hurt: 0 }, s), 'normal').posture !== 'defensive' && AI.chooseStrategy(e, Object.assign({ hurt: 1 }, s), 'normal').posture === 'defensive') f = true;
    }
    if (f) flips++;
  });
  ['vexor', 'kael9', 'elyra', 'morvak', 'nyrah'].forEach(e => {
    let f = false;
    for (let p = 0; p <= 1 && !f; p += 0.05) for (let l = 0; l <= 1 && !f; l += 0.05) for (let d = 0; d <= 1 && !f; d += 0.1) {
      const s = { pressure: p, lossRatio: l, dominance: d, capitalLost: 0 };
      if (AI.chooseStrategy(e, Object.assign({ momentum: 0 }, s), 'normal').posture !== 'offensive' && AI.chooseStrategy(e, Object.assign({ momentum: 1 }, s), 'normal').posture === 'offensive') f = true;
    }
    if (f) flipsOff++;
  });
  ok(flips >= 3, 'un empire récemment blessé bascule en défensif là où il ne l\'aurait pas fait (' + flips + '/4 empires)');
  ok(flipsOff >= 2, 'un empire qui vient de tenir bascule en offensif (' + flipsOff + '/5 empires)');
  ok(AI.chooseStrategy('vexor', { pressure: 0, lossRatio: 0, dominance: 0, capitalLost: 0 }, 'normal').strategy === AI.chooseStrategy('vexor', { pressure: 0, lossRatio: 0, dominance: 0, capitalLost: 0, hurt: 0, momentum: 0 }, 'normal').strategy, 'sans mémoire : décision identique à avant (compatibilité)');
  fresh(45); GM.setConquered(G.planetsOfEmpire('vexor')[1].id, true, T0); EM.update(T0 + 1000);
  ok(AIM.assess('vexor', T0 + 1000).hurt > 0 && AIM.assess('nyrah', T0 + 1000).hurt === 0, 'EmpireAIManager.assess() expose la mémoire de l\'empire');
}

section('Comportements distincts et équilibrés (14 jours, joueur niveau 45)');
{
  fresh(45); run(14);
  const S = {}; IDS.forEach(e => { S[e] = EM.empireStatus(e, T0 + 14 * DAY); });
  ok(sum('elyra', 'sh') > sum('morvak', 'sh') && sum('nyrah', 'sh') > sum('morvak', 'sh'), 'ELYRA/NYR\'AH investissent plus en boucliers que MORVAK');
  ok(sum('morvak', 'tu') > sum('elyra', 'tu') && sum('nyrah', 'tu') > sum('elyra', 'tu'), 'MORVAK/NYR\'AH investissent plus en tourelles qu\'ELYRA');
  ok(sum('morvak', 'fl') > sum('elyra', 'fl') && sum('morvak', 'fl') > sum('nyrah', 'fl'), 'MORVAK aligne plus de renforts qu\'ELYRA/NYR\'AH');
  IDS.forEach(e => {
    const d = EM.state().e[e].def; let bad = false;
    Object.keys(d).forEach(pid => { const p = G.planet(pid); if (d[pid].sh > EE.shMax(8, e) || d[pid].tu > EE.tuMax(8, e) || d[pid].fl > EE.flMax(8, p.tier, e)) bad = true; });
    ok(!bad, e + ' : plafonds propres respectés');
  });
  ok(IDS.every(e => S[e].growth >= 1.2 && S[e].growth <= 1.8), 'puissance finale de chaque empire ×1,2..×1,8 : ' + IDS.map(e => e + ' x' + S[e].growth).join(' '));
  const abs = IDS.map(e => S[e].power);
  ok(abs[0] < abs[1] && abs[1] < abs[2] && abs[2] < abs[3] && abs[3] < abs[4], 'la hiérarchie de puissance VEXOR < KAEL-9 < ELYRA < MORVAK < NYR\'AH est conservée');
  ok(new Set(IDS.map(e => S[e].capabilities.join())).size === 6, 'capacités actives différentes pour chaque empire');
  // Coordination : KAEL-9 répartit ses niveaux entre planètes plus uniformément que MORVAK
  const spread = (e, k) => { const v = G.planetsOfEmpire(e).map(p => (EM.state().e[e].def[p.id] || { sh: 0, tu: 0, fl: 0 })[k]); return Math.max.apply(null, v) - Math.min.apply(null, v); };
  fresh(45); run(4);
  const spK = spread('kael9', 'sh') + spread('kael9', 'tu'), spM = spread('morvak', 'sh') + spread('morvak', 'tu');
  ok(spK <= spM, 'KAEL-9 (coordination) répartit ses défenses plus uniformément que MORVAK (' + spK + ' ≤ ' + spM + ')');
  // Entraînement : rôles favoris entraînés en premier
  fresh(45); run(5);
  let pref = 0;
  IDS.forEach(e => {
    const rk = EM.state().e[e].rank, fo = DR.STYLE[e].focus, us = G.empire(e).units;
    const avg = l => l.length ? l.reduce((a, u) => a + (rk[u.id] || 0), 0) / l.length : 0;
    if (avg(us.filter(u => fo.indexOf(u.role) >= 0)) >= avg(us.filter(u => fo.indexOf(u.role) < 0))) pref++;
  });
  ok(pref >= 4, 'chaque empire entraîne d\'abord ses unités de prédilection (' + pref + '/5)');
  ok(IDS.every(e => Object.keys(EM.state().e[e].rank).every(u => G.unitDef(u) && G.unitDef(u).empire === e)), 'rangs uniquement sur les unités de l\'empire');
}

section('Unités et défenses évoluées dans battleSpec');
{
  fresh(45); run(14);
  const base = G.battleSpec('mo4'), ev = EM.battleSpec('mo4', T0 + 14 * DAY);
  const flat = w => [].concat.apply([], w);
  ok(flat(ev.waves).length >= flat(base.waves).length && ev.shield >= base.shield && ev.turrets >= base.turrets && ev.scale > base.scale, 'défense évoluée ≥ défense d\'origine (unités, bouclier, tourelles, échelle)');
  ok(flat(ev.waves).every(u => u.rank >= 1) && flat(ev.waves).every(u => G.unitDef(u.id) && u.base.hp > G.unitDef(u.id).base.hp), 'unités entraînées : stats supérieures, id inchangé');
  ok(ev.waves.every(w => w.length >= 1 && w.length <= 3), 'vagues de 1 à 3 unités (format du module Combat)');
  ok(ev.capabilities.length === 3 && ev.bonus.atkBonus > 0 && ev.evo === 8 && ev.posture && ev.strategy && ev.alert >= 0, 'spec : capacités, bonus, développement, posture, stratégie, alerte');
  ok(['empire', 'planetId', 'rewards', 'trait', 'recLevel'].every(k => k in ev) && ev.rewards.first === base.rewards.first, 'spec : champs d\'origine conservés (compatible module Combat)');
  const cap = G.planetsOfEmpire('vexor').filter(p => p.isCapital)[0], v = EM.planetInfo(cap.id, T0 + 14 * DAY);
  const scr = v.fleet.filter(g => g.unit === 'vx_scrapper')[0], b0 = cap.defense.fleet.filter(g => g.unit === 'vx_scrapper');
  ok(scr && scr.count >= (b0.length ? b0[0].count : 0) + 1, 'VEXOR : « production de masse » ajoute un Ferrailleur à la capitale');
  ok(JSON.stringify(G.PLANETS.map(p => [p.id, p.defense, p.power, p.recLevel, p.scale, p.rewards])) === galaxySnapshot && JSON.stringify(G.EMPIRE_ORDER.map(e => G.empire(e).units)) === unitSnapshot, 'Galaxy.js jamais modifié par l\'évolution');
  ok(EM.battleSpec('nexus_01', T0 + 14 * DAY) === null || EM.battleSpec('nexus_01', T0 + 14 * DAY) === undefined, 'planète-mère : pas de spec');
  const mid = EM.battleSpec('cendre2', T0 + 14 * DAY), o = G.battleSpec('cendre2');
  ok(JSON.stringify(mid) === JSON.stringify(o), 'monde libre non revendiqué : spec d\'origine intacte');
}

section('Expansion : revendication de mondes neutres');
{
  fresh(45); run(30);
  const cl = IDS.map(e => [e, Object.keys(EM.state().e[e].claims)]).filter(x => x[1].length);
  ok(cl.length >= 1 && cl.every(x => x[0] === 'vexor'), 'seul VEXOR (relié au monde neutre par une route) étend son influence : ' + JSON.stringify(cl));
  ok(cl.every(x => x[1].length <= EE.CLAIM.maxPerEmpire && x[1].every(p => G.planet(p).kind === 'neutral')), 'max ' + EE.CLAIM.maxPerEmpire + ' revendications, mondes neutres uniquement');
  const pid = cl[0][1][0], info = EM.planetInfo(pid, T0 + 30 * DAY), spec = EM.battleSpec(pid, T0 + 30 * DAY), o = G.battleSpec(pid);
  ok(info && info.claimedBy === 'vexor' && spec.claimedBy === 'vexor', 'monde revendiqué : signalé dans la vue et la spec');
  ok([].concat.apply([], spec.waves).length > [].concat.apply([], o.waves).length && spec.waves.some(w => w.some(u => u.id === 'vx_scrapper')), 'monde revendiqué : garnison VEXOR ajoutée');
  ok(spec.rewards.crystal >= o.rewards.crystal && spec.rewards.first === o.rewards.first, 'monde revendiqué : récompenses ≥ d\'origine');
  const free = G.PLANETS.filter(p => p.kind === 'neutral' && !EM.claimedBy(p.id))[0];
  ok(!free || EM.planetInfo(free.id, T0 + 30 * DAY) === null, 'monde libre : pas de vue d\'empire');
  ok(EM.mapView(T0 + 30 * DAY).empires.vexor.claims.indexOf(pid) >= 0, 'la carte signale les revendications');
  // Le joueur conquiert le monde revendiqué → revendication retirée
  scan(pid, T0 + 30 * DAY); GM.setConquered(pid, true, T0 + 30 * DAY); EM.reconcile(T0 + 30 * DAY + 1000);
  ok(EM.claimedBy(pid) === null, 'monde conquis par le joueur : revendication retirée');
  // Perte de l'ancrage : VEXOR perd les planètes proches → plus de revendication
  fresh(45); run(30);
  const cl2 = Object.keys(EM.state().e.vexor.claims);
  ['vx1', 'vx2', 'vx3', 'vx4'].forEach(p => GM.setConquered(p, true, T0 + 30 * DAY)); EM.reconcile(T0 + 30 * DAY + 1000);
  ok(cl2.length > 0 && Object.keys(EM.state().e.vexor.claims).length === 0, 'plus aucune planète à portée : les revendications tombent');
  // Posture défensive : jamais de nouvelle revendication ; borne sur un an
  fresh(99, 'cauchemar'); run(365);
  ok(Object.keys(EM.state().e.vexor.claims).length <= EE.CLAIM.maxPerEmpire, 'un an de simulation : jamais plus de ' + EE.CLAIM.maxPerEmpire + ' revendications');
}

section('Carte galactique et invasions (API pour le futur module d\'invasion)');
{
  fresh(45); run(2);
  const mv = EM.mapView(T0 + 2 * DAY);
  ok(mv.planets.length === G.PLANETS.length - 1 && mv.planets.every(p => p.id !== 'nexus_01'), 'carte : toutes les planètes sauf Nexus-01 (' + mv.planets.length + ')');
  ok(mv.planets.every(p => ['id', 'name', 'sector', 'kind', 'empire', 'conquered', 'reachable', 'frontier', 'canInvade', 'power', 'recLevel', 'shield', 'turrets', 'alert', 'posture'].every(k => k in p)), 'carte : tous les champs nécessaires à la scène');
  ok(IDS.every(e => mv.empires[e] && mv.empires[e].posture && mv.empires[e].strategy && mv.empires[e].alert >= 0 && mv.empires[e].alert <= 3 && mv.empires[e].total === 5), 'carte : bilan de chacun des 5 empires');
  const fr = mv.planets.filter(p => p.frontier).map(p => p.id).sort();
  ok(JSON.stringify(fr) === JSON.stringify(['cendre2', 'halo7', 'lyr']), 'frontière initiale : les 3 mondes reliés à Nexus-01 (' + fr + ')');
  ok(!EM.isReachable('vx1') && !EM.isReachable('nexus_01') && !EM.isReachable('nope'), 'vx1 hors de portée tant que Épave de Lyr n\'est pas conquise');
  ok(mv.planets.filter(p => p.canInvade).length === 0, 'aucune invasion possible sans scan');
  const p0 = EM.invasionPlan('lyr', T0 + 2 * DAY);
  ok(p0 && p0.canInvade === false && p0.reason === 'scan' && p0.frontier && p0.spec && ['deconseille', 'risque', 'equilibre', 'favorable'].indexOf(p0.verdict) >= 0 && typeof p0.ratio === 'number', 'plan d\'invasion : refusé sans scan, avec verdict et ratio');
  ok(EM.invasionPlan('nexus_01') === null && EM.invasionPlan('nope') === null, 'plan d\'invasion : planète-mère/inconnue → null');
  ok(EM.resolveInvasion('lyr', true, T0 + 2 * DAY).reason === 'scan' && !GM.isConquered('lyr'), 'victoire sans scan valide : refusée, rien de conquis');
  scan('lyr', T0 + 2 * DAY); scan('vx1', T0 + 2 * DAY);
  ok(EM.invasionPlan('lyr', T0 + 2 * DAY + 1000).canInvade === true, 'plan d\'invasion : possible avec scan valide');
  const r = EM.resolveInvasion('lyr', true, T0 + 2 * DAY + 2000);
  ok(r.ok && r.conquered && GM.isConquered('lyr') && EM.isReachable('vx1'), 'victoire : conquête enregistrée, la route vers VEXOR s\'ouvre');
  ok(EM.resolveInvasion('lyr', true, T0 + 2 * DAY + 3000).reason === 'conquered', 'victoire rejouée : refusée (pas de double comptage)');
  const r2 = EM.resolveInvasion('vx1', true, T0 + 2 * DAY + 4000), es = EM.state().e.vexor;
  ok(r2.ok && r2.empire === 'vexor' && es.lost === 1 && es.hurt > 0 && es.lostAt.vx1 !== undefined, 'victoire sur une planète d\'empire : traumatisme et mémoire de la perte');
  ok(EM.mapView(T0 + 2 * DAY + 5000).empires.vexor.alert >= 1 && EM.mapView(T0 + 2 * DAY + 5000).planets.filter(p => p.id === 'vx1')[0].conquered, 'carte : alerte montée, planète marquée conquise');
  // Défaite du joueur : l'empire « tient »
  const h0 = EM.state().e.kael9.held, d1 = EM.resolveInvasion('k92', false, T0 + 2 * DAY + 6000), ke = EM.state().e.kael9;
  ok(d1.ok && !d1.conquered && ke.held === h0 + 1 && ke.mom > 0 && !GM.isConquered('k92'), 'défaite du joueur : l\'empire gagne de l\'élan, rien n\'est conquis');
  for (let i = 0; i < 30; i++) EM.resolveInvasion('k92', false, T0 + 2 * DAY + 7000 + i);
  ok(ke.mom <= 1 && ke.held === 31 && ke.hurt === 0, 'élan borné à 1 même après 30 défaites');
  ok(EM.resolveInvasion('halo7', false, T0 + 2 * DAY + 9000).empire === null && EM.resolveInvasion('nexus_01', true).reason === 'invalid', 'monde libre / planète-mère gérés');
}

section('Sauvegarde et rechargement (mémoire, rangs, revendications)');
{
  const R = fresh(45); run(12);
  GM.setConquered(G.planetsOfEmpire('morvak')[0].id, true, T0 + 12 * DAY); EM.update(T0 + 12 * DAY + 1000);
  EM.resolveInvasion('k93', false, T0 + 12 * DAY + 2000);
  R.saveNow(T0 + 12 * DAY + 3000);
  const before = JSON.stringify(R.state.empires);
  const R2 = new NEBUSTION.ResourceManager(); R2.init(T0 + 12 * DAY + 4000); NEBUSTION.Resources = R2;
  const a = R2.state.empires, b = JSON.parse(before);
  ok(JSON.stringify(a.e.vexor.rank) === JSON.stringify(b.e.vexor.rank) && JSON.stringify(a.e.vexor.claims) === JSON.stringify(b.e.vexor.claims), 'rechargement : rangs et revendications identiques');
  ok(a.e.morvak.lost === b.e.morvak.lost && Math.abs(a.e.morvak.hurt - b.e.morvak.hurt) < 1e-9 && JSON.stringify(a.e.morvak.lostAt) === JSON.stringify(b.e.morvak.lostAt) && a.e.kael9.held === 1, 'rechargement : pertes, traumatisme, victoires défensives conservés');
  ok(JSON.stringify(a.e) === JSON.stringify(b.e), 'rechargement : état des empires identique à l\'octet près');
  // Continuité : sauvegarder/recharger au milieu n'a aucun effet sur la suite
  const t = run(4, T0 + 12 * DAY + 4000); const cont = JSON.stringify(EM.state().e);
  fresh(45); run(12); GM.setConquered(G.planetsOfEmpire('morvak')[0].id, true, T0 + 12 * DAY); EM.update(T0 + 12 * DAY + 1000); EM.resolveInvasion('k93', false, T0 + 12 * DAY + 2000);
  run(4, T0 + 12 * DAY + 4000);
  ok(cont === JSON.stringify(EM.state().e), 'recharger au milieu ne change pas la suite (aucune perte, aucun double gain)');
  // Ancienne sauvegarde (empires v1 sans mémoire) : chargée sans erreur, évolue normalement
  const R3 = fresh(45);
  R3.state.empires = { v: 1, lastAt: T0, n: 0, seed: 5, e: { vexor: { evo: 2, res: { metal: 1000, energy: 1000 }, def: {}, lastRec: 0, rec: 0, spent: 0, ups: 0 } } };
  R3.saveNow(T0 + 1000);
  const R4 = new NEBUSTION.ResourceManager(); R4.init(T0 + 2000); NEBUSTION.Resources = R4;
  ok(R4.state.empires.v === 2 && R4.state.empires.e.vexor.evo === 2 && R4.state.empires.e.vexor.claims && R4.state.empires.e.morvak.hurt === 0, 'ancienne sauvegarde v1 migrée sans perte');
  run(2, T0 + 2000); ok(EM.state().e.vexor.evo >= 2 && EM.state().e.vexor.ups >= 0, 'ancienne sauvegarde : l\'évolution reprend');
  // Sauvegarde corrompue → repli sain
  const R5 = fresh(45); R5.state.empires.e.morvak.hurt = 'abc'; R5.state.empires.e.morvak.claims = 12; R5.saveNow(T0 + 500);
  const R6 = new NEBUSTION.ResourceManager(); R6.init(T0 + 600); NEBUSTION.Resources = R6;
  ok(R6.state.empires.e.morvak.hurt === 0 && Object.keys(R6.state.empires.e.morvak.claims).length === 0, 'sauvegarde abîmée : champs réparés');
}

section('Aucune progression infinie, hors ligne, horloge');
{
  fresh(99, 'cauchemar'); run(200);
  const s200 = IDS.map(e => EM.state().e[e].ups), len200 = JSON.stringify(EM.state()).length;
  run(200, T0 + 200 * DAY);
  const s400 = IDS.map(e => EM.state().e[e].ups), len400 = JSON.stringify(EM.state()).length;
  const bound = 5 * (EE.SH_MAX + EE.TU_MAX + 2) + EE.MAX_EVO + 5 * DR.RANK_MAX;
  ok(JSON.stringify(s200) === JSON.stringify(s400), 'saturation : plus aucune amélioration entre 200 et 400 jours (' + s400 + ')');
  ok(s400.every(u => u <= bound), 'améliorations totales ≤ ' + bound);
  ok(IDS.every(e => { const x = EM.state().e[e]; return x.evo <= EE.MAX_EVO && Object.keys(x.rank).every(u => x.rank[u] <= DR.RANK_MAX) && Object.keys(x.res).every(r => x.res[r] <= EE.capRes(r)); }), 'evo, rangs et stocks bornés');
  ok(len400 - len200 < 40, 'taille de l\'état stable (' + len200 + ' → ' + len400 + ' octets)');
  ok(len400 < 12000, 'état des empires compact (' + len400 + ' octets)');
  // Joueur faible : les empires restent faibles
  fresh(1); run(60);
  ok(IDS.every(e => EM.state().e[e].evo <= 1) && IDS.every(e => EM.empireStatus(e, T0 + 60 * DAY).growth < 1.15), 'joueur niveau 1 : aucun empire ne s\'emballe');
  // Cycle conquête / reprise répété : compteurs cohérents et bornés
  fresh(30, 'cauchemar'); let t = run(10); let conq = 0;
  const mo = G.planetsOfEmpire('morvak').filter(p => !p.isCapital && p.tier === 2)[0];
  EM.on('recapture', () => {});
  for (let i = 0; i < 40; i++) { if (!GM.isConquered(mo.id)) { GM.setConquered(mo.id, true, t); conq++; } t += DAY; EM.update(t); }
  const me = EM.state().e.morvak;
  ok(me.rec <= 40 && me.rec <= conq && me.lost === conq && me.rec >= 0, 'cycle conquêtes/reprises : ' + conq + ' conquêtes, ' + me.lost + ' pertes, ' + me.rec + ' reprises (cohérent)');
  ok(me.spent < 1e15 && isFinite(me.spent), 'dépenses finies');
  // Hors ligne : 30 jours d'absence = au plus 24 h de progression
  fresh(45); run(2);
  const t2 = T0 + 2 * DAY, e0 = JSON.stringify(EM.state().e);
  const out = EM.update(t2 + 30 * DAY);
  ok(out.truncated && out.steps === EE.MAX_CATCHUP_STEPS, '30 jours d\'absence : rattrapage limité à 24 h (' + out.steps + ' pas)');
  fresh(45); run(2); EM.update(t2 + 1 * DAY);
  const a = EM.state().e; const b = JSON.parse(JSON.stringify(a));
  fresh(45); run(2); EM.update(t2 + 30 * DAY);
  ok(JSON.stringify(EM.state().e) === JSON.stringify(b), '30 jours d\'absence = exactement 24 h de progression');
  ok(EM.update(t2 + 30 * DAY).steps === 0 && EM.update(t2 + 29 * DAY).steps === 0, 'même instant / horloge reculée : rien rejoué');
  const snap = JSON.stringify(EM.state()); EM.update(t2 + 30 * DAY); EM.reconcile(t2 + 30 * DAY); EM.reconcile(t2 + 30 * DAY);
  ok(snap === JSON.stringify(EM.state()), 'update/reconcile répétés au même instant : état inchangé');
  // Déterminisme
  fresh(45); run(9); const x = JSON.stringify(EM.state().e); fresh(45); run(9);
  ok(x === JSON.stringify(EM.state().e), 'simulation déterministe (même seed → même résultat)');
}

section('Fuzz : séquences aléatoires (conquêtes, défaites, horloge, rechargements) — invariants');
{
  let seed = 424242; const rnd = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; };
  const pl = G.PLANETS.filter(p => p.kind !== 'home').map(p => p.id);
  let bad = 0, t = T0, R = fresh(60, 'difficile'), last = '';
  for (let i = 0; i < 400; i++) {
    const op = rnd();
    if (op < 0.30) { t += Math.floor(rnd() * 20 * H); EM.update(t); }
    else if (op < 0.45) { const pid = pl[Math.floor(rnd() * pl.length)]; scan(pid, t); EM.resolveInvasion(pid, true, t); }
    else if (op < 0.55) { EM.resolveInvasion(pl[Math.floor(rnd() * pl.length)], false, t); }
    else if (op < 0.65) { GM.setConquered(pl[Math.floor(rnd() * pl.length)], rnd() < 0.5, t); EM.reconcile(t); }
    else if (op < 0.72) { EM.update(t - Math.floor(rnd() * 5 * DAY)); }              // horloge reculée
    else if (op < 0.80) { EM.update(t + Math.floor(rnd() * 90 * DAY)); t += 0; }        // saut d'horloge en avant
    else if (op < 0.88) { R.saveNow(t); const R2 = new NEBUSTION.ResourceManager(); R2.init(Math.max(t, EM.state().lastAt)); NEBUSTION.Resources = R2; R = R2; }
    else if (op < 0.94) { GM.teamLevel = () => 1 + Math.floor(rnd() * 70); AIM.invalidate(); }
    else { EM.mapView(t); EM.invasionPlan(pl[Math.floor(rnd() * pl.length)], t); }
    const st = EM.state(), js = JSON.stringify(st);
    const re = EE.normalizeState(JSON.parse(js), Math.max(t, st.lastAt) + 1);
    if (JSON.stringify(re.e) !== JSON.stringify(st.e)) { bad++; if (bad < 3) console.log('   état non canonique à l\'étape', i, 'op', op.toFixed(2)); }
    if (/null|NaN|Infinity/.test(js)) { bad++; if (bad < 3) console.log('   valeur invalide à l\'étape', i); }
    IDS.forEach(e => { const x = st.e[e]; if (x.hurt < 0 || x.hurt > 1 || x.mom < 0 || x.mom > 1 || x.evo > 8 || Object.keys(x.claims).length > 2) bad++; });
    const owners = {}; IDS.forEach(e => Object.keys(st.e[e].claims).forEach(p => { owners[p] = (owners[p] || 0) + 1; })); if (Object.values(owners).some(c => c > 1)) bad++;
  }
  console.log('  stats fuzz : ' + IDS.map(e => e + ' evo' + EM.state().e[e].evo + ' lost' + EM.state().e[e].lost + ' held' + EM.state().e[e].held + ' rec' + EM.state().e[e].rec).join(' | '));
  ok(bad === 0, 'fuzz 400 opérations : état toujours valide, canonique, borné, sans NaN, sans revendication en double (' + bad + ' anomalies ; ' + IDS.reduce((a, e) => a + EM.state().e[e].lost, 0) + ' pertes, ' + IDS.reduce((a, e) => a + EM.state().e[e].held, 0) + ' défenses tenues, ' + IDS.reduce((a, e) => a + EM.state().e[e].rec, 0) + ' reprises, n=' + EM.state().n + ')');
  GM.teamLevel = () => 45;
}

section('Non-régression : API existante et câblage du jeu');
{
  ['update', 'start', 'stop', 'isRunning', 'planetInfo', 'battleSpec', 'empireStatus', 'state', 'on', 'off'].forEach(f => ok(typeof EM[f] === 'function', 'EmpireEvolutionManager.' + f + ' conservé'));
  ['reconcile', 'wire', 'mapView', 'invasionPlan', 'resolveInvasion', 'isReachable', 'alertOf', 'claimedBy'].forEach(f => ok(typeof EM[f] === 'function', 'EmpireEvolutionManager.' + f + ' ajouté'));
  ['decide', 'decideAll', 'intents', 'assess', 'wire', 'invalidate', 'difficultyId', 'lastSituation'].forEach(f => ok(typeof AIM[f] === 'function', 'EmpireAIManager.' + f + ' conservé'));
  ['stepEmpire', 'planetView', 'normalizeState', 'defaultState', 'evoCost', 'upgradeCost', 'ceilingFor', 'pay', 'wealth', 'rand01'].forEach(f => ok(typeof EE[f] === 'function', 'EmpireEvolution.' + f + ' conservé'));
  ['recFromPower', 'battleSpec', 'planetsOfEmpire', 'normalizeState'].forEach(f => ok(typeof G[f] === 'function', 'Galaxy.' + f + ' conservé'));
  const fs = require('fs'), path = require('path'), root = path.join(__dirname, '..');
  const idx = fs.readFileSync(path.join(root, 'index.html'), 'utf8'), sw = fs.readFileSync(path.join(root, 'sw.js'), 'utf8'), main = fs.readFileSync(path.join(root, 'js/main.js'), 'utf8');
  const need = ['Galaxy.js', 'EmpireAI.js', 'EmpireDoctrine.js', 'EmpireEvolution.js', 'GalaxyManager.js', 'EmpireAIManager.js', 'EmpireEvolutionManager.js'];
  ok(need.every(f => idx.indexOf(f) > 0), 'index.html charge les 7 fichiers galaxie/IA');
  ok(need.every(f => sw.indexOf(f) > 0), 'sw.js met en cache les 7 fichiers galaxie/IA (jeu hors ligne)');
  const order = need.map(f => idx.indexOf(f));
  ok(order[0] < order[1] && order[1] < order[2] && order[2] < order[3] && order[3] < order[4] && order[4] < order[5] && order[5] < order[6], 'ordre : Galaxy → EmpireAI → EmpireDoctrine → EmpireEvolution → GalaxyManager → EmpireAIManager → EmpireEvolutionManager');
  ok(/EmpireEvolutionManager\.start\(\)/.test(main) && /EmpireAIManager\.wire\(\)/.test(main), 'main.js démarre l\'évolution des empires et branche l\'IA');
  ok(JSON.stringify(G.PLANETS.map(p => [p.id, p.defense, p.power, p.recLevel, p.scale, p.rewards])) === galaxySnapshot, 'données de la galaxie inchangées');
}

GM.teamLevel = realTeam;
console.log('\n' + (failed === 0 ? '✔ TESTS ADAPTATION DES EMPIRES OK  (' + passed + ' vérifications)' : '✗ ' + failed + ' ÉCHEC(S) sur ' + (passed + failed)));
process.exit(failed === 0 ? 0 : 1);
