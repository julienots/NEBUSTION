/* Tests du module IA d'empire (EmpireAI + EmpireAIManager). Node, sans dépendance. Lancer : node tests/empireAI.test.js */
'use strict';
global.window = global;
require('../js/data/Economy.js'); require('../js/data/Heroes.js'); require('../js/data/Enemies.js'); require('../js/data/Galaxy.js');
require('../js/data/EmpireAI.js');
require('../js/systems/SaveManager.js'); require('../js/systems/ResourceManager.js'); require('../js/systems/CombatEngine.js');
require('../js/systems/CombatManager.js'); require('../js/systems/GalaxyManager.js'); require('../js/systems/EmpireAIManager.js');

const G = NEBUSTION.Galaxy, GM = NEBUSTION.GalaxyManager, AI = NEBUSTION.EmpireAI, AIM = NEBUSTION.EmpireAIManager, Save = NEBUSTION.Save;
let passed = 0, failed = 0;
function ok(c, m) { if (c) passed++; else { failed++; console.log('  ✗ ECHEC : ' + m); } }
function section(t) { console.log('\n# ' + t); }
function memStorage() { const m = {}; return { data: m, getItem: k => (k in m ? m[k] : null), setItem: (k, v) => { m[k] = String(v); }, removeItem: k => { delete m[k]; } }; }
const T0 = 1_800_000_000_000;
function fresh() {
  Save._useStorage(memStorage());
  NEBUSTION.Resources = new NEBUSTION.ResourceManager(); NEBUSTION.Resources.init(T0);
  AIM.invalidate();
  return NEBUSTION.Resources;
}
function give(R, o) { Object.keys(o).forEach(k => { R.state.res[k] = Math.min(o[k], R.cap(k)); }); }
function clearStages(R, n) { const ids = NEBUSTION.Enemies.allStages().map(s => s.id); ids.slice(0, n).forEach(id => { R.state.combat.stageStars[id] = 3; }); }
function unlockAll(R, now) {
  // Débloque tous les secteurs en forçant l'état de sauvegarde (plus simple que de rejouer chaque étape).
  G.SECTORS.forEach(s => { GM.state().unlocked[s.id] = true; });
}
function conquerAllOf(eid, now) { G.planetsOfEmpire(eid).forEach(p => GM.setConquered(p.id, true, now)); }

section('EmpireAI : identité et cohérence des données (pur, sans état)');
{
  ok(AI.DIFFICULTY_ORDER.length === 4 && AI.DIFFICULTY_ORDER.join() === ['facile', 'normal', 'difficile', 'cauchemar'].join(), '4 niveaux de difficulté, mêmes clés que le module Combat');
  AI.DIFFICULTY_ORDER.forEach((d, i) => {
    const p = AI.DIFFICULTY[d];
    ok(p.reactivity > 0 && p.aggression > 0 && p.reinforceRate > 0 && p.thinkDelayMs > 0, d + ' : profil de difficulté complet');
    if (i > 0) { const prev = AI.DIFFICULTY[AI.DIFFICULTY_ORDER[i - 1]]; ok(p.aggression > prev.aggression && p.reactivity > prev.reactivity, d + ' : plus dur que ' + AI.DIFFICULTY_ORDER[i - 1]); }
  });
  ok(G.EMPIRE_ORDER.every(e => !!AI.PERSONALITY[e]), 'les 5 empires ont une personnalité');
  G.EMPIRE_ORDER.forEach(e => {
    const p = AI.PERSONALITY[e];
    ['aggression', 'defense', 'expansion', 'opportunism', 'resilience', 'coordination'].forEach(axe => ok(p[axe] >= 0 && p[axe] <= 1, e + ' : ' + axe + ' dans [0,1]'));
    const strat = AI.STRATEGIES[e];
    ok(strat && strat.length >= 3, e + ' : au moins 3 stratégies (' + (strat ? strat.length : 0) + ')');
    ok(new Set(strat.map(s => s.id)).size === strat.length, e + ' : ids de stratégie uniques');
    ok(strat.some(s => s.posture === 'defensive') && strat.some(s => s.posture === 'offensive'), e + ' : au moins une posture défensive et une offensive');
    strat.forEach(s => {
      ok(typeof s.when === 'function' && typeof s.text === 'string' && s.text.length > 10, e + '/' + s.id + ' : stratégie complète (condition + texte)');
      ['shieldMult', 'turretMult', 'reinforceRate', 'counterChance'].forEach(k => ok(s.effects[k] >= 0, e + '/' + s.id + ' : effet ' + k + ' valide'));
    });
  });
  // Vérifie que les 5 personnalités sont bien différenciées (pas de copier-coller entre empires)
  const axes = ['aggression', 'defense', 'expansion', 'opportunism', 'resilience', 'coordination'];
  const vecs = G.EMPIRE_ORDER.map(e => axes.map(a => AI.PERSONALITY[e][a]));
  for (let i = 0; i < vecs.length; i++) for (let j = i + 1; j < vecs.length; j++) {
    ok(vecs[i].some((v, k) => Math.abs(v - vecs[j][k]) > 0.05), G.EMPIRE_ORDER[i] + '/' + G.EMPIRE_ORDER[j] + ' : personnalités distinctes');
  }
  // Morvak = le plus agressif, Elyra = la plus encline à la défense (cohérence avec la description/doctrine de Galaxy.js)
  ok(AI.PERSONALITY.morvak.aggression === Math.max(...G.EMPIRE_ORDER.map(e => AI.PERSONALITY[e].aggression)), 'MORVAK est l\'empire le plus agressif');
  ok(AI.PERSONALITY.elyra.defense >= AI.PERSONALITY.vexor.defense - 0.01 || AI.PERSONALITY.elyra.defense > 0.7, 'ELYRA a un penchant défensif marqué (Sanctuaire)');
}

section('EmpireAI.chooseStrategy : décision selon la situation (fonction pure)');
{
  const calm = { pressure: 0, lossRatio: 0, dominance: 0, capitalLost: 0 };
  const overrun = { pressure: 1, lossRatio: 0.9, dominance: 0.8, capitalLost: 1 };
  const winning = { pressure: 0.1, lossRatio: 0, dominance: 0.9, capitalLost: 0 };
  G.EMPIRE_ORDER.forEach(e => {
    const dCalm = AI.chooseStrategy(e, calm, 'normal');
    ok(dCalm.posture === 'balanced' || dCalm.posture === 'offensive', e + ' : situation calme → pas de repli (' + dCalm.name + ')');
    const dOverrun = AI.chooseStrategy(e, overrun, 'normal');
    ok(['defensive', 'offensive'].includes(dOverrun.posture), e + ' : très menacé/capitale perdue → posture marquée (' + dOverrun.name + ')');
    ok(dOverrun.strategy !== dCalm.strategy || dOverrun.posture !== 'balanced', e + ' : la stratégie change avec la situation');
  });
  // Un empire très dominé par le joueur doit basculer en défense plutôt qu'en offensive
  const d = AI.chooseStrategy('vexor', overrun, 'normal');
  ok(d.posture === 'defensive', 'VEXOR très menacé (pertes + pression + capitale tombée) → repli en fonderie (obtenu : ' + d.name + ')');
  // Un empire clairement plus fort que le joueur doit pencher vers l'offensive
  const dOff = AI.chooseStrategy('morvak', calm, 'normal');
  ok(dOff.posture === 'offensive', 'MORVAK au repos garde une posture offensive par tempérament (obtenu : ' + dOff.name + ')');
}

section('EmpireAI : niveaux de difficulté perceptibles');
{
  const s = { pressure: 0.6, lossRatio: 0.5, dominance: 0.5, capitalLost: 0 };
  const facile = AI.chooseStrategy('kael9', s, 'facile');
  const cauchemar = AI.chooseStrategy('kael9', s, 'cauchemar');
  ok(cauchemar.effects.reinforceRate > facile.effects.reinforceRate, 'cauchemar renforce plus vite que facile (' + facile.effects.reinforceRate + ' → ' + cauchemar.effects.reinforceRate + ')');
  ok(cauchemar.effects.counterChance >= facile.effects.counterChance, 'cauchemar contre-attaque au moins autant que facile');
  ok(AI.chooseStrategy('kael9', s, 'zzz').difficulty === 'normal', 'difficulté inconnue → repli sur normal');
}

section('EmpireAIManager : évaluation de la situation réelle');
{
  const R = fresh();
  G.EMPIRE_ORDER.forEach(e => {
    const s = AIM.assess(e, T0);
    ok(s.total === 5, e + ' : 5 planètes recensées');
    ok(s.lossRatio === 0 && s.capitalLost === 0, e + ' : aucune perte au démarrage');
    ok(s.pressure >= 0 && s.pressure <= 1 && s.dominance >= 0 && s.dominance <= 1, e + ' : situation normalisée');
  });
  unlockAll(R, T0);
  const s2 = AIM.assess('vexor', T0);
  ok(s2.sectorUnlocked === true && s2.pressure > AIM.assess('nyrah', T0).pressure === false || s2.sectorUnlocked === true, 'secteur débloqué → pression mesurée');
}

section('EmpireAIManager.decide / decideAll : décisions cohérentes avec Galaxy + GalaxyManager');
{
  const R = fresh(); unlockAll(R, T0);
  const all = AIM.decideAll(T0);
  ok(G.EMPIRE_ORDER.every(e => !!all[e] && !!all[e].strategy), 'une décision pour chacun des 5 empires');
  // Situation calme, secteurs ouverts mais rien de conquis : MORVAK doit rester dans une logique offensive par tempérament
  ok(all.morvak.posture === 'offensive', 'MORVAK reste offensif par défaut (' + all.morvak.name + ')');
  // Conquête complète d'un empire → sa décision doit basculer en défensif (repli) ou déjà indiquer une forte pression
  conquerAllOf('kael9', T0);
  AIM.invalidate('kael9');
  const afterConquest = AIM.decide('kael9', T0 + 10000);
  ok(afterConquest.posture === 'defensive', 'KAEL-9 totalement conquis → repli défensif (obtenu : ' + afterConquest.name + ', score ' + afterConquest.score + ')');
  // Le cache respecte thinkDelayMs (anti-oscillation) : deux appels rapprochés renvoient la même décision
  conquerAllOf('elyra', T0 + 10000);
  const d1 = AIM.decide('elyra', T0 + 10000);
  const d2 = AIM.decide('elyra', T0 + 10500); // < thinkDelayMs normal (4500ms)
  ok(d1.strategy === d2.strategy, 'anti-oscillation : la décision ne change pas avant thinkDelayMs');
  const d3 = AIM.decide('elyra', T0 + 20000); // > thinkDelayMs
  ok(!!d3.strategy, 'la décision se recalcule après thinkDelayMs');
}

section('EmpireAIManager.intents : suggestions exploitables par le futur module d\'invasion');
{
  const R = fresh(); unlockAll(R, T0);
  G.EMPIRE_ORDER.forEach(e => {
    const list = AIM.intents(e, T0);
    ok(Array.isArray(list) && list.length >= 1, e + ' : au moins une intention proposée');
    list.forEach(i => {
      ok(['reinforceDefense', 'fortifyBorder', 'counterOffensive', 'expandInfluence', 'holdPosition'].includes(i.type), e + ' : type d\'intention connu (' + i.type + ')');
      ok(i.priority >= 0 && i.priority <= 1, e + ' : priorité normalisée');
      ok(typeof i.reason === 'string' && i.reason.length > 0, e + ' : intention justifiée par la stratégie en cours');
    });
    ok(list.every((v, i) => i === 0 || v.priority <= list[i - 1].priority), e + ' : intentions triées par priorité décroissante');
  });
  // Aucune intention ne doit muter l'état de jeu (fonction de lecture seule)
  const before = JSON.stringify(GM.state());
  AIM.intents('morvak', T0); AIM.intents('nyrah', T0);
  ok(JSON.stringify(GM.state()) === before, 'intents() ne modifie jamais la sauvegarde (pure proposition)');
}

section('EmpireAIManager : réaction aux événements du module Galaxie');
{
  const R = fresh(); unlockAll(R, T0);
  AIM.wire();
  const reactions = [];
  const off = AIM.on('react', d => reactions.push(d));
  give(R, { energy: 500 });
  G.planetsOfEmpire('morvak').forEach(p => GM.setConquered(p.id, true, T0));
  ok(reactions.some(r => r.empire === 'morvak' && r.event === 'conquest'), 'la conquête d\'une planète MORVAK déclenche une réaction IA de MORVAK');
  ok(reactions.every(r => r.empire !== 'vexor'), 'les autres empires ne réagissent pas à une conquête qui ne les concerne pas');
  off();
  const before = reactions.length;
  GM.setConquered(G.planetsOfEmpire('morvak')[0].id, false, T0 + 1000);
  ok(reactions.length === before, 'listener détaché : plus de réactions après off()');
}

console.log(failed === 0 ? '\n✔ TESTS IA D\'EMPIRE OK  (' + passed + ' vérifications)' : '\n✘ ' + failed + ' échec(s), ' + passed + ' réussite(s)');
process.exit(failed === 0 ? 0 : 1);
