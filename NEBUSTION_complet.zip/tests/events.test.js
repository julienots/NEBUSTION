/* Tests des événements temporaires (NEBUSTION.Events + EventManager), Node, sans Phaser.
 * L'horloge est pilotée (Date.now figé) : cycle de 14 jours dont 5 actifs, ancrage lundi 14/09/2026 (heure locale).
 * Lancer : node tests/events.test.js */
'use strict';
const E = require('./progress-env');
const t = E.makeCounter(), ok = t.ok, section = t.section;
const EV = NEBUSTION.Events, EM = NEBUSTION.EventManager, XM = NEBUSTION.ExpeditionManager, C = NEBUSTION.Combat;
const D = (d, h) => E.local(2026, 8, d, h);          // d = jour de septembre 2026
const DAY = 86400000;

section('Cycle : actif / inactif');
{
  ok(EV.cycleIndex(D(14, 8)) === 0 && EV.dayIndex(D(14, 8)) === 0, 'lundi 14/09 = jour 0 du cycle 0');
  ok(EV.currentEvent(D(14, 8)).active && EV.currentEvent(D(18, 23)).active, 'jours 0 à 4 : événement actif');
  ok(!EV.currentEvent(D(19, 1)).active && !EV.currentEvent(D(27, 23)).active, 'jours 5 à 13 : inactif');
  ok(EV.currentEvent(D(28, 1)).active && EV.cycleIndex(D(28, 1)) === 1, 'lundi 28/09 : nouveau cycle actif');
  ok(!EV.currentEvent(D(21, 12)).active, 'le 21/09/2026 : inactif (prochain cycle le 28/09)');
  const a = EV.currentEvent(D(16, 12)), i = EV.currentEvent(D(22, 12));
  ok(a.msLeft > 0 && a.msLeft <= 5 * DAY, 'actif : temps restant ≤ 5 jours');
  ok(i.msLeft > 0 && i.msLeft <= 9 * DAY && i.msLeft > 5 * DAY, 'inactif : temps restant jusqu\'au prochain événement (≤ 9 jours)');
  ok(EV.cycleIndex(D(14, 8) - 100 * DAY) === 0, 'avant l\'ancrage : cycle 0 (jamais négatif)');
  ok(EV.dayInCycle(D(14, 8) - 3 * DAY) >= 0 && EV.dayInCycle(D(14, 8) - 3 * DAY) < 14, 'dayInCycle toujours dans [0,14[');
  ok(EV.msUntilNextDay(D(15, 12)) > 0 && EV.msUntilNextDay(D(15, 12)) <= DAY, 'msUntilNextDay ∈ ]0, 24 h]');
}

section('Thèmes, boss, tentatives');
{
  ok(EV.THEMES.length === 3 && new Set(EV.THEMES.map(x => x.key)).size === 3, '3 thèmes distincts');
  ok(EV.theme(0).key === EV.theme(3).key && EV.theme(0).key !== EV.theme(1).key, 'les thèmes tournent (cycle 3 = cycle 0)');
  ok(EV.THEMES.every(x => x.boss.name && x.boss.baseHp > 0 && x.currency.name && x.color && x.hex), 'thèmes complets (boss, monnaie, couleur)');
  const c0 = EV.currentEvent(D(15, 12), 0), c1 = EV.currentEvent(D(29, 12), 0), c1p = EV.currentEvent(D(29, 12), 2);
  ok(c1.bossMaxHp !== c0.bossMaxHp && c1.cycleIndex === 1, 'les PV du boss dépendent du cycle');
  ok(c1p.bossMaxHp > c1.bossMaxHp, 'les boss gagnent en PV avec les Renaissances (+15 % chacune)');
  ok(EV.maxAttempts(0) === 5 && EV.maxAttempts(1) === 6 && EV.maxAttempts(5) === 10 && EV.maxAttempts(50) === 10, 'tentatives : 5 de base, +1 par Renaissance, 10 maximum');
  const a1 = EV.resolveAttack(1000, 42), a2 = EV.resolveAttack(1000, 42), a3 = EV.resolveAttack(1000, 43);
  ok(a1.damage === a2.damage && a1.crit === a2.crit, 'resolveAttack déterministe');
  ok(a1.damage > 0 && a3.damage > 0 && EV.resolveAttack(0, 1).damage >= 1, 'dégâts toujours ≥ 1');
  ok(EV.resolveAttack(100000, 42).damage > EV.resolveAttack(1000, 42).damage * 50, 'dégâts proportionnels à la puissance');
  let crits = 0; for (let s = 1; s <= 400; s++) if (EV.resolveAttack(1000, s * 7919).crit) crits++;
  ok(crits > 30 && crits < 110, 'taux de critique ≈ 16 % (' + crits + '/400)');
  ok(EV.convertLeftover(100) === 20 && EV.convertLeftover(0) === 0 && EV.convertLeftover(-5) === 0 && EV.convertLeftover(4) === 0, 'conversion de la monnaie restante = 20 % (arrondi bas)');
  ok(EV.shopItem('ev_res') && EV.shopItem('xx') === null && EV.SHOP_ITEMS.every(i => i.cost > 0 && i.limit > 0), 'boutique : articles valides');
  ok(EV.MISSION_POOL.length === 5 && EV.missionDef('e_login') && EV.missionDef('zz') === null, '5 missions d\'événement');
  const rw = EV.bossDefeatReward(EV.theme(0), 3);
  ok(rw.gems > 0 && rw.currency > 0 && rw.res.dust > EV.bossDefeatReward(EV.theme(0), 0).res.dust, 'récompense de boss croissante avec le cycle');
}

// ---------- Partie simulée ----------
E.setNow(D(15, 12));
const g = E.freshGame(), R = g.R, SM = NEBUSTION.ShopManager;
const H = E.freeHeroes();
H.slice(0, 5).forEach(id => E.setLevel(id, 1));
C.setTeam(H.slice(0, 5));

section('Événement actif : état initial');
{
  ok(EM.isActive() && EM.info().theme.key === 'invasion' && EM.info().cycleIndex === 0, 'actif, thème Invasion Voidique, cycle 0');
  const b = EM.bossStatus();
  ok(b.hp === b.maxHp && b.maxHp === EV.currentEvent(D(15, 12), 0).bossMaxHp && !b.defeated && b.name, 'boss à PV pleins');
  ok(EM.attemptsLeft() === 5 && EM.currency() === 0 && EM.missions().length === 5, '5 tentatives, 0 monnaie, 5 missions');
  ok(EM.teamPower() > 0, 'puissance d\'équipe > 0');
}

section('Attaque du boss, tentatives, missions');
{
  const hp0 = EM.bossStatus().hp;
  const r = EM.attackBoss(D(15, 12));
  ok(r.ok && r.damage > 0 && r.hp === hp0 - r.damage && !r.defeated, 'attaque : dégâts retirés des PV');
  ok(EM.attemptsLeft() === 4, 'tentative consommée');
  const m = k => EM.missions().find(x => x.id === k);
  ok(m('e_attack').p === 1 && m('e_dmg').p === Math.min(5000, r.damage), 'missions « attaques » et « dégâts » avancent');
  EM.attackBoss(D(15, 12) + 1); EM.attackBoss(D(15, 12) + 2);
  ok(m('e_attack').status === 'ready' && EM.claimableCount() >= 1, 'mission prête après 3 attaques');
  ok(EM.claimMission('e_login').reason === 'incomplete', 'mission incomplète non réclamable');
  const c = EM.claimMission('e_attack');
  ok(c.ok && c.currency === 30 && EM.currency() === 30, 'réclamation : +30 monnaie');
  ok(EM.claimMission('e_attack').reason === 'deja', 'pas de double réclamation');
  ok(EM.claimMission('zzz').reason === 'invalide', 'mission inconnue refusée');
  EM.attackBoss(D(15, 12) + 3); EM.attackBoss(D(15, 12) + 4);
  ok(EM.attemptsLeft() === 0 && EM.attackBoss(D(15, 12) + 5).reason === 'tentatives', '6e attaque refusée (plus de tentative)');
  E.setNow(D(16, 12));
  ok(EM.attemptsLeft() === 5, 'les tentatives se rechargent le jour suivant');
  ok(EM.bossStatus().hp < hp0, 'les PV du boss persistent d\'un jour à l\'autre (même cycle)');
  EM.touch(); EM.touch();
  ok(EM.missions().find(x => x.id === 'e_login').p === 1, 'connexion quotidienne comptée une seule fois par jour');
}

section('Victoire sur le boss + récompense');
{
  const gems0 = SM.gems(), frag0 = R.state.combat.fragments[H[0]] || 0, cur0 = EM.currency(), dust0 = R.state.res.dust, kills0 = R.state.events.stats.bossKills;
  R.state.events.boss.hp = 1;
  const r = EM.attackBoss(D(16, 12));
  ok(r.ok && r.defeated && r.hp === 0 && r.reward, 'boss vaincu');
  ok(SM.gems() === gems0 + 20, '+20 Prismes');
  ok((R.state.combat.fragments[H[0]] || 0) > frag0, 'fragments versés à l\'équipe');
  ok(EM.currency() === cur0 + 60 && R.state.events.stats.bossKills === kills0 + 1, '+60 monnaie, compteur de boss vaincus +1');
  ok(R.state.res.dust > dust0, 'ressources versées');
  ok(EM.attackBoss(D(16, 12) + 1).reason === 'vaincu', 'boss déjà vaincu : plus d\'attaque');
  ok(EM.bossStatus().defeated && EM.bossStatus().hp === 0, 'état « vaincu » persistant');
}

section('Boutique événementielle');
{
  R.state.events.currency = 0;
  ok(EM.buyShopItem('ev_res').reason === 'monnaie', 'achat refusé sans monnaie');
  ok(EM.buyShopItem('zzz').reason === 'invalide', 'article inconnu refusé');
  R.state.events.currency = 1000;
  const c0 = R.state.res.crystal, g0 = SM.gems();
  const b1 = EM.buyShopItem('ev_res');
  ok(b1.ok && EM.currency() === 960 && R.state.res.crystal > c0, 'ev_res : -40 monnaie, ressources reçues');
  const b2 = EM.buyShopItem('ev_gems');
  ok(b2.ok && SM.gems() === g0 + 25 && EM.currency() === 870, 'ev_gems : +25 Prismes, -90 monnaie');
  const f0 = R.state.combat.fragments[H[0]] || 0, b3 = EM.buyShopItem('ev_frag');
  ok(b3.ok && b3.granted.heroId === H[0] && (R.state.combat.fragments[H[0]] || 0) === f0 + 12, 'ev_frag : +12 fragments au chef d\'équipe');
  ok(EM.buyShopItem('ev_core').ok && EM.buyShopItem('ev_core').ok && EM.buyShopItem('ev_core').reason === 'limite', 'limite d\'achats respectée (2 noyaux max.)');
  const st = EM.shopStatus().find(x => x.id === 'ev_core');
  ok(st.owned === 2 && st.left === 0, 'shopStatus : possédés / restants');
  ok(EM.currency() === 870 - 70 - 240 || EM.currency() >= 0, 'la monnaie ne devient jamais négative');
}

section('Cycle inactif');
{
  E.setNow(D(21, 12));
  ok(!EM.isActive() && EM.info().cycleIndex === 0, 'le 21/09 : inactif');
  ok(EM.attackBoss().reason === 'inactif' && EM.claimMission('e_win').reason === 'inactif' && EM.buyShopItem('ev_res').reason === 'inactif', 'attaque / mission / boutique refusées hors événement');
  ok(EM.track('win', 1) === false && EM.claimableCount() === 0, 'aucune progression hors événement');
}

section('Nouveau cycle : conversion de la monnaie, reset');
{
  R.state.events.currency = 155;
  const gems0 = SM.gems();
  E.setNow(D(28, 12));
  const cur = EM.currency();
  ok(EM.isActive() && EM.info().cycleIndex === 1 && EM.info().theme.key === 'ruee', 'cycle 1, thème Ruée de Cristaux');
  ok(cur === 0 && SM.gems() === gems0 + 31, 'monnaie remise à 0, 20 % converti en Prismes (155 → 31)');
  ok(EM.bossStatus().hp === EM.bossStatus().maxHp && !EM.bossStatus().defeated && EM.attemptsLeft() === 5, 'boss neuf, tentatives pleines');
  ok(R.state.events.stats.bossKills === 1 && R.state.events.stats.attacks >= 6, 'statistiques cumulées conservées');
  ok(EM.missions().every(x => x.p === 0 && x.status === 'progress'), 'missions remises à zéro');
  ok(EM.shopStatus().every(x => x.owned === 0), 'limites de la boutique remises à zéro');
}

section('Horloge reculée (anti-triche)');
{
  const before = EM.attemptsLeft();
  EM.attackBoss(D(28, 12)); EM.attackBoss(D(28, 12) + 1);
  const used = before - EM.attemptsLeft();
  E.setNow(D(15, 12));              // le joueur recule sa date de 13 jours
  ok(EM.info().cycleIndex === 1, 'l\'événement ne revient pas au cycle précédent');
  ok(EM.attemptsLeft() === before - used, 'les tentatives ne sont pas regagnées en reculant l\'horloge');
  E.setNow(D(28, 12) + 3600000);
  ok(EM.info().cycleIndex === 1 && EM.attemptsLeft() === before - used, 'retour à l\'heure normale : état inchangé');
  E.setNow(D(15, 12) + 400 * DAY);   // date très lointaine pendant la session
  ok(EM.info().cycleIndex > 1, 'une date lointaine fait avancer le cycle');
  E.setNow(D(28, 12) + 7200000);     // puis retour à l'heure normale (dans la même session : le plancher tient)
  ok(EM.info().cycleIndex > 1, 'dans la même session, le plancher d\'horloge tient (pas de retour en arrière)');
  const reloaded = EM.normalizeState({ cycleIndex: 40, clockFloor: D(15, 12) + 400 * DAY, currency: 10 }, D(28, 12) + 7200000);
  ok(reloaded.clockFloor <= D(28, 12) + 7200000 + 2 * DAY, 'au rechargement, un plancher trop lointain est ramené à ≤ 2 jours d\'avance (jeu jamais bloqué)');
  ok(EV.cycleIndex(reloaded.clockFloor) <= 2, 'le cycle reste cohérent avec l\'heure réelle après rechargement');
}

section('Robustesse de normalizeState');
{
  const now = D(29, 12), cur = EV.cycleIndex(now);
  ok(EM.normalizeState(null, now).cycleIndex === cur && EM.normalizeState('x', now).currency === 0 && EM.normalizeState([], now).boss.hp > 0, 'entrées absurdes → état neuf valide');
  const max = EV.currentEvent(now, 0).bossMaxHp;
  const s = EM.normalizeState({ cycleIndex: cur, currency: -50, pendingGems: 'a', attemptsUsed: 999, attemptsUsedDay: EV.dayIndex(now), boss: { hp: 1e15, max: 1e15 }, missions: [{ id: 'e_attack', p: 1e9, c: true }, { id: 'zz', p: 5 }, null], purchased: { ev_res: 3, zzz: 9 }, stats: { attacks: -1, bossKills: 2 } }, now);
  ok(s.currency === 0 && s.pendingGems === 0 && s.attemptsUsed === 999, 'monnaie / Prismes en attente bornés à 0');
  ok(s.boss.max <= max * 3 && s.boss.hp <= s.boss.max, 'PV du boss plafonnés (max ≤ 3 × PV du cycle)');
  ok(s.missions.length === 5 && s.missions.find(m => m.id === 'e_attack').p === 3 && s.missions.find(m => m.id === 'e_attack').c === true, 'progression de mission bornée à sa cible');
  ok(s.purchased.ev_res === 3 && !('zzz' in s.purchased), 'achats : article inconnu écarté');
  ok(s.stats.attacks === 0 && s.stats.bossKills === 2, 'statistiques bornées');
  const d = EM.normalizeState({ cycleIndex: cur, attemptsUsed: 4, attemptsUsedDay: EV.dayIndex(now) - 1, boss: { hp: 5, max: max, defeated: true } }, now);
  ok(d.attemptsUsed === 0 && d.boss.defeated && d.boss.hp === 0, 'tentatives remises à zéro un autre jour, boss vaincu → PV 0');
  const old = EM.normalizeState({ cycleIndex: cur - 1, currency: 100, stats: { bossKills: 4 } }, now);
  ok(old.pendingGems === 20 && old.currency === 0 && old.stats.bossKills === 4, 'ancien cycle : monnaie convertie en Prismes en attente');
  const future = EM.normalizeState({ cycleIndex: cur + 5, currency: 900, stats: { bossKills: 1 } }, now);
  ok(future.currency === 0 && future.pendingGems === 0 && future.stats.bossKills === 1, 'cycle futur (horloge reculée avant chargement) : état neuf, pas de conversion');
}

section('Sauvegarde aller-retour');
{
  R.state.events.currency = 77;
  R.saveNow(D(28, 12) + 7200000);
  const loaded = NEBUSTION.Save.load().state;
  ok(loaded && loaded.events && loaded.events.currency === 77 && loaded.events.cycleIndex === 1, 'l\'état d\'événement est sauvegardé');
  const back = NEBUSTION.Save.normalize(JSON.parse(JSON.stringify(loaded)), D(28, 12) + 7300000);
  ok(back.events.currency === 77 && back.events.cycleIndex === 1, 'rechargement : monnaie et cycle conservés');
}

section('Branchements (wire) : victoires de combat et expéditions');
{
  E.setNow(D(30, 12));
  E.freshGame();
  const R2 = NEBUSTION.Resources;
  E.giveStars(25); H.slice(0, 8).forEach(id => E.setLevel(id, 60));
  const orig = { g: C.grantRewards, i: C.grantInvasionRewards };
  C.grantRewards = function () { return 'stub'; }; C.grantInvasionRewards = function () { return 'stub'; };
  EM._reset(); EM.wire();
  const win = id => EM.missions().find(m => m.id === id).p;
  C.grantRewards({}, 'normal', { win: true }); C.grantRewards({}, 'normal', { win: false }); C.grantInvasionRewards({}, { win: true }, 'p1');
  ok(win('e_win') === 2, 'victoires (étape + invasion) comptées, défaites ignorées');
  ok(C.grantRewards({}, 'normal', { win: true }) === 'stub', 'la valeur de retour d\'origine est conservée');
  const before = win('e_expedition');
  XM.launch('m_eclair_facile', [H[0]], D(30, 12));
  ok(win('e_expedition') === before + 1, 'expédition réclamée comptée pour l\'événement');
  EM.wire();
  XM.launch('m_eclair_normal', [H[0]], D(30, 12));
  ok(win('e_expedition') === before + 2, 'wire() appelé deux fois ne double pas le comptage');
  C.grantRewards = orig.g; C.grantInvasionRewards = orig.i;
}

E.setNow(null);
t.done('TESTS ÉVÉNEMENTS');
