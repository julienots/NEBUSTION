/*
 * Test navigateur du MODULE PERSONNALISATION / SKINS (étape 6, 3e volet) dans un vrai Chromium (Playwright)
 * avec le FAUX Phaser (tests/mock-phaser.js) : scène Skins (3 onglets, sélecteur, aperçu, cartes, filtre, achat,
 * équipement, retrait), rendu des skins dans Héros / Vaisseaux / Planète / Combat, sauvegarde et rechargement.
 * Le rendu WebGL réel n'est PAS simulé (voir README).
 *   NODE_PATH=$(npm root -g) node tests/browser-skins.js        (SHOTS=/dossier pour enregistrer des captures de mise en page)
 */
const http = require('http'), fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const root = path.join(__dirname, '..');
const mock = fs.readFileSync(path.join(__dirname, 'mock-phaser.js'), 'utf8');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]);
  if (u === '/js/vendor/phaser.min.js') { res.writeHead(200, { 'Content-Type': 'text/javascript' }); return res.end(mock); }
  const f = path.join(root, u === '/' ? 'index.html' : u);
  if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('nf'); }
  res.writeHead(200, { 'Content-Type': mime[path.extname(f)] || 'application/octet-stream' }); res.end(fs.readFileSync(f));
});
let passed = 0, failed = 0;
const ok = (c, m) => { if (c) passed++; else { failed++; console.log('  ✗ ' + m); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const SHOTS = process.env.SHOTS;

(async () => {
  await new Promise(r => server.listen(8771, r));
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 720, height: 1280 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console.error: ' + m.text()); });
  const R = expr => page.evaluate(expr);
  const S = '__NEBUSTION_GAME__.scenes.';
  async function waitScene(key, ms) {
    const t0 = Date.now();
    while (Date.now() - t0 < (ms || 15000)) {
      if (await R(`!!(window.__NEBUSTION_GAME__ && window.__NEBUSTION_GAME__.scene.isActive('${key}'))`)) return true;
      await sleep(100);
    }
    return false;
  }
  async function shot(scene, name) {
    if (!SHOTS) return;
    fs.mkdirSync(SHOTS, { recursive: true });
    const data = await R(`(() => { const c = document.createElement('canvas'); c.width = 720; c.height = 1280; Phaser._render(${S}${scene}, c.getContext('2d'), 720, 1280); return c.toDataURL('image/png'); })()`);
    fs.writeFileSync(path.join(SHOTS, name + '.png'), Buffer.from(data.split(',')[1], 'base64'));
  }
  const active = () => R(`Object.keys(__NEBUSTION_GAME__.active)[0]`);
  async function go(scene, data) { await R(`${S}${await active()}.scene.start('${scene}', ${JSON.stringify(data || {})})`); return waitScene(scene); }
  const WALK = `const walk = (c, out) => { (c.list || []).forEach(o => { out.push(o); if (o.list) walk(o, out); }); return out; };`;
  const texts = scene => R(`(() => { ${WALK} return walk(${S}${scene}.dyn, []).map(o => o.text !== undefined ? o.text : (o.labelText ? o.labelText.text : null)).filter(x => x !== null).join(' | '); })()`);
  const richen = () => R(`(() => { const st = NEBUSTION.Resources.state; ['crystal','energy','dust','core'].forEach(k => { st.res[k] = 14000; }); st.res.core = 200; })()`);

  console.log('# Chargement, modules');
  await page.goto('http://localhost:8771/index.html?debug=1');
  ok(await waitScene('MainMenuScene'), 'MainMenuScene atteinte');
  ok(await R(`!!NEBUSTION.Skins && !!NEBUSTION.SkinManager && !!NEBUSTION.SkinFX && !!__NEBUSTION_GAME__.scenes.SkinsScene`), 'Skins, SkinManager, SkinFX chargés ; SkinsScene enregistrée');
  ok(await R(`NEBUSTION.Resources.state.skins && Object.keys(NEBUSTION.Resources.state.skins.owned).length === 0`), 'nouvelle partie : état skins vide dans la sauvegarde');
  ok(errors.length === 0, 'aucune erreur au chargement : ' + errors.join(' | '));
  await richen();

  console.log('# Scène Skins : onglets, sélecteur, aperçu');
  ok(await go('SkinsScene', { tab: 'hero', targetId: 'kael', from: 'MainMenuScene' }), 'SkinsScene ouverte (héros Kael)');
  let t = await texts('SkinsScene');
  ok(/Kael/.test(t) && /Héros\s+0\/7/.test(t) && /Vaisseaux\s+0\/7/.test(t) && /Bâtiments\s+0\/7/.test(t), 'onglets avec compteurs de collection et cible Kael');
  ok(/Standard/.test(t) && /Néon Cyan/.test(t) && /Spectre Émeraude/.test(t), 'cartes : Standard + 7 skins de héros');
  ok(await R(`${S}SkinsScene.tIndex === ${S}SkinsScene.targets.findIndex(x => x.id === 'kael')`), 'targetId présélectionné');
  await shot('SkinsScene', 's1_heros_standard');

  // aperçu d'un skin non possédé : rien acheté, rien équipé
  await R(`${S}SkinsScene.sel = 'h_gold'; ${S}SkinsScene._render()`);
  t = await texts('SkinsScene');
  ok(/Or Solaire/.test(t) && /ACHETER/.test(t) && /Épique/.test(t), 'aperçu Or Solaire : fiche + bouton ACHETER');
  ok(await R(`!NEBUSTION.SkinManager.isOwned('h_gold') && NEBUSTION.SkinManager.equippedCount() === 0`), 'aperçu = ni achat ni équipement');
  ok(await R(`!!${S}SkinsScene.previewFx && ${S}SkinsScene.previewFx.targets.length > 0`), 'effet animé (aura + orbites) actif dans l\'aperçu');
  await shot('SkinsScene', 's2_apercu_or_solaire');

  console.log('# Achat, équipement, retrait');
  const before = await R(`NEBUSTION.Resources.state.res.dust`);
  await R(`${S}SkinsScene._act('buy', ${S}SkinsScene.targets[${S}SkinsScene.tIndex], NEBUSTION.Skins.get('h_gold'))`);
  const afterDust = await R(`NEBUSTION.Resources.state.res.dust`);
  ok(await R(`NEBUSTION.SkinManager.isOwned('h_gold')`) && Math.abs(afterDust - (before - 5000)) < 60, 'achat : possédé, 5000 poussière débitées (production passive tolérée) : ' + (before - afterDust));
  t = await texts('SkinsScene');
  ok(/ÉQUIPER/.test(t) && /Héros\s+1\/7/.test(t), 'après achat : bouton ÉQUIPER, collection 1/7');
  await R(`${S}SkinsScene._act('equip', ${S}SkinsScene.targets[${S}SkinsScene.tIndex], NEBUSTION.Skins.get('h_gold'))`);
  ok(await R(`NEBUSTION.SkinManager.equippedId('hero', 'kael')`) === 'h_gold', 'Or Solaire équipé sur Kael');
  t = await texts('SkinsScene');
  ok(/ÉQUIPÉ/.test(t) && /✓ ÉQUIPÉ/.test(t), 'bouton ÉQUIPÉ · RETIRER et carte « ✓ ÉQUIPÉ »');
  await shot('SkinsScene', 's3_equipe');

  // achat impossible : ressources insuffisantes
  await R(`NEBUSTION.Resources.state.res.core = 0; ${S}SkinsScene.sel = 'h_spectre'; ${S}SkinsScene._render()`);
  await R(`${S}SkinsScene._act('buy', ${S}SkinsScene.targets[${S}SkinsScene.tIndex], NEBUSTION.Skins.get('h_spectre'))`);
  ok(await R(`!NEBUSTION.SkinManager.isOwned('h_spectre')`), 'légendaire refusé sans noyaux');
  ok(await R(`${S}SkinsScene._display.some(o => o.text && /insuffisantes/.test(o.text))`), 'toast « Ressources insuffisantes »');
  await R(`NEBUSTION.Resources.state.res.core = 200`);

  // sélecteur ‹ › et filtre
  await R(`${S}SkinsScene.sel = null; ${S}SkinsScene._render()`);
  const idx0 = await R(`${S}SkinsScene.tIndex`);
  await R(`(() => { const s = ${S}SkinsScene; const arrows = s.dyn.list.filter(o => o.text === '›'); arrows[0].emit('pointerdown'); })()`);
  ok(await R(`${S}SkinsScene.tIndex`) === idx0 + 1, 'flèche › : héros suivant');
  ok(await R(`NEBUSTION.SkinManager.equippedId('hero', ${S}SkinsScene.targets[${S}SkinsScene.tIndex].id)`) === null, 'le héros suivant n\'a pas de skin');
  await R(`(() => { const s = ${S}SkinsScene; s.dyn.list.filter(o => o.text && /Afficher/.test(o.text))[0].emit('pointerdown'); })()`);
  t = await texts('SkinsScene');
  ok(/Possédés/.test(t) && /Standard/.test(t) && /Or Solaire/.test(t) && !/Néon Cyan/.test(t), 'filtre « Possédés » : Standard + skins possédés seulement');
  await R(`(() => { const s = ${S}SkinsScene; s.dyn.list.filter(o => o.text && /Afficher/.test(o.text))[0].emit('pointerdown'); })()`);

  console.log('# Onglet Vaisseaux (hangar vide puis vaisseau)');
  await R(`${S}SkinsScene._switchTab('ship')`);
  ok(await R(`${S}SkinsScene.tab`) === 'ship', 'onglet Vaisseaux');
  ok(/Aucun vaisseau/.test(await texts('SkinsScene')), 'hangar vide : message clair, pas d\'erreur');
  const uid = await R(`NEBUSTION.ShipManager.acquire('cuirasse', 'rare').ship.uid`);
  await R(`NEBUSTION.ShipManager.acquire('corvette', 'commun'); NEBUSTION.ShipManager.toggleFleet('${uid}')`);
  await go('SkinsScene', { tab: 'ship', targetId: uid, from: 'ShipsScene' });
  t = await texts('SkinsScene');
  ok(/Rare — Cuirassé/.test(t) && /Éclipse Solaire/.test(t), 'vaisseau possédé listé avec les 7 skins de vaisseaux');
  ok(await R(`(() => { ${WALK} return walk(${S}SkinsScene.dyn, []).some(o => o.fxTargets && o.fxTargets.length === 2); })()`), 'aperçu : cuirassé dessiné (2 réacteurs animés)');
  await R(`NEBUSTION.SkinManager.buy('s_solar'); ${S}SkinsScene.sel = 's_solar'; ${S}SkinsScene._render()`);
  await R(`${S}SkinsScene._act('equip', ${S}SkinsScene.targets[${S}SkinsScene.tIndex], NEBUSTION.Skins.get('s_solar'))`);
  ok(await R(`NEBUSTION.SkinManager.equippedId('ship', '${uid}')`) === 's_solar', 'skin équipé sur le vaisseau');
  await shot('SkinsScene', 's4_vaisseau');

  console.log('# Onglet Bâtiments');
  await go('SkinsScene', { tab: 'building', targetId: 'hangar', from: 'PlanetScene' });
  t = await texts('SkinsScene');
  ok(/Hangar/.test(t) && /Fournaise/.test(t) && /Forge Stellaire/.test(t), 'bâtiment Hangar + 7 skins de bâtiments');
  await R(`NEBUSTION.SkinManager.buy('b_plasma'); NEBUSTION.SkinManager.equip('building', 'hangar', 'b_plasma'); NEBUSTION.SkinManager.equip('building', 'command', 'b_plasma'); ${S}SkinsScene.sel = 'b_plasma'; ${S}SkinsScene._render()`);
  await shot('SkinsScene', 's5_batiment');
  await richen();
  ok(await R(`NEBUSTION.SkinManager.buy('h_spectre').ok`), 'achat du légendaire Spectre Émeraude (noyaux, cristaux, énergie, poussière)');
  await R(`NEBUSTION.SkinManager.equip('hero', 'zyra', 'h_spectre')`);

  console.log('# Rendu des skins dans les autres scènes');
  ok(await go('HeroesScene'), 'HeroesScene');
  await R(`(() => { const s = ${S}HeroesScene; s._openDetail(NEBUSTION.Heroes.get('kael')); })()`);
  const det = await R(`(() => { ${WALK} const all = walk(${S}HeroesScene.detailLayer, []);
    const portrait = all.find(o => o.textureKey === 'hero_portrait_kael');
    const btns = all.filter(o => o.labelText).map(o => o.labelText.text);
    return { tinted: portrait ? portrait.tint : null, btns }; })()`);
  ok(det.tinted === 0xffe9a3, 'fiche héros : portrait de Kael teinté par Or Solaire (' + det.tinted + ')');
  ok(det.btns.includes('Équipement') && det.btns.includes('Skins'), 'fiche héros : boutons Équipement et Skins');
  await shot('HeroesScene', 's6_fiche_heros');
  await R(`(() => { ${WALK} walk(${S}HeroesScene.detailLayer, []).find(o => o.labelText && o.labelText.text === 'Skins').onClick(); })()`);
  ok(await waitScene('SkinsScene', 5000) && await R(`${S}SkinsScene.tab === 'hero' && ${S}SkinsScene.targets[${S}SkinsScene.tIndex].id === 'kael' && ${S}SkinsScene.from === 'HeroesScene'`), 'bouton Skins → SkinsScene sur Kael, retour prévu vers HeroesScene');

  ok(await go('ShipsScene'), 'ShipsScene');
  const ships = await R(`(() => { ${WALK} const all = walk(${S}ShipsScene.listContainer, []);
    return { icons: all.filter(o => o.fxTargets).length, texts: all.filter(o => o.text).map(o => o.text) }; })()`);
  ok(ships.icons === 2, 'hangar : une icône vectorielle par vaisseau (2)');
  ok(ships.texts.some(t => /Rare — Cuirassé/.test(t)), 'hangar : lignes de vaisseaux toujours affichées');
  ok(await R(`${S}ShipsScene._display.some(o => o.text === 'Skins ›')`), 'ShipsScene : lien « Skins ›»');
  await shot('ShipsScene', 's7_hangar');

  ok(await go('PlanetScene'), 'PlanetScene');
  const pl = await R(`(() => { ${WALK} const s = ${S}PlanetScene, b = s._buildingBoxes; const glow = k => walk(b[k].container, []).filter(o => o.textureKey === 'tex_glow_white').length;
    return { hangar: glow('hangar'), command: glow('command'), lab: glow('lab') }; })()`);
  ok(pl.hangar === 1 && pl.command === 1 && pl.lab === 0, 'planète : aura sur Hangar et Commandement (skin), aucune sur le Laboratoire : ' + JSON.stringify(pl));
  await R(`${S}PlanetScene._showInfoPanel({ key: 'hangar', label: 'Hangar' })`);
  await R(`(() => { const s = ${S}PlanetScene; s._infoPanel.list.find(o => o.text === 'Skins ›').emit('pointerdown'); })()`);
  ok(await waitScene('SkinsScene', 5000) && await R(`${S}SkinsScene.tab === 'building' && ${S}SkinsScene.targets[${S}SkinsScene.tIndex].id === 'hangar'`), 'fiche bâtiment → Skins sur le Hangar');

  console.log('# Combat : skins des héros (visuel seulement)');
  await R(`NEBUSTION.SkinManager.equip('hero', 'kael', 'h_gold')`);
  const team = await R(`NEBUSTION.Combat.getTeam()`);
  const skinnedInTeam = team.filter(id => id === 'kael' || id === 'zyra');
  await go('CombatScene', { stageId: 'stage_01', difficulty: 'normal' });
  const cv = await R(`(() => { const s = ${S}CombatScene; return s.heroViews.map(v => ({ id: v.unit.heroId, tint: v.sprite.tint, skinTint: v.skinTint === undefined ? null : v.skinTint, atk: v.unit.atk })); })()`);
  ok(cv.length === 5, '5 héros en combat');
  const kv = cv.find(v => v.id === 'kael'), zv = cv.find(v => v.id === 'zyra'), other = cv.find(v => v.id !== 'kael' && v.id !== 'zyra');
  ok(!skinnedInTeam.includes('kael') || (kv && kv.tint === 0xffe9a3), 'Kael (dans l\'équipe) teinté par son skin en combat');
  ok(!skinnedInTeam.includes('zyra') || (zv && zv.tint === 0xc9ffe0), 'Zyra (dans l\'équipe) teintée par son skin en combat');
  ok(other && other.skinTint === null, 'héros sans skin : aucune teinte ajoutée');
  await R(`(() => { const s = ${S}CombatScene; s.heroViews.forEach(v => v.flash()); })()`);
  await sleep(200);
  ok(await R(`(() => { const s = ${S}CombatScene; return s.heroViews.filter(v => v.skinTint !== undefined && v.skinTint !== null).every(v => v.sprite.tint === v.skinTint); })()`), 'après le flash d\'impact, la teinte du skin est restaurée');
  await shot('CombatScene', 's8_combat');

  console.log('# Sauvegarde et rechargement');
  await R(`NEBUSTION.Resources.saveNow(Date.now())`);
  await page.reload();
  ok(await waitScene('MainMenuScene'), 'rechargement');
  const kept = await R(`(() => { const M = NEBUSTION.SkinManager; return { gold: M.equippedId('hero', 'kael'), spectre: M.isOwned('h_spectre'), ship: M.equippedId('ship', ${JSON.stringify(uid)}), hangar: M.equippedId('building', 'hangar'), col: M.collection().owned }; })()`);
  ok(kept.gold === 'h_gold' && kept.spectre && kept.ship === 's_solar' && kept.hangar === 'b_plasma' && kept.col === 4, 'skins possédés et équipés conservés après rechargement : ' + JSON.stringify(kept));

  ok(errors.length === 0, 'aucune erreur JS pendant toute la session : ' + errors.slice(0, 3).join(' | '));
  await browser.close(); server.close();
  console.log('\n' + (failed === 0 ? '✔ TEST NAVIGATEUR SKINS OK' : '✘ ' + failed + ' échec(s)') + ' (' + passed + ' vérifications)');
  process.exit(failed === 0 ? 0 : 1);
})().catch(async e => { console.error('ERREUR TEST :', e); process.exit(2); });
