/* Progression des troupes : 3 branches + intégration combat/sauvegarde. */
'use strict';
const { makeCounter, freshGame } = require('./progress-env');
const c = makeCounter(), ok = c.ok, section = c.section;
const T = NEBUSTION.Troops, TM = NEBUSTION.TroopManager, QB = NEBUSTION.QGBattle;

section('Catalogue amélioration');
ok(T.UPGRADE_ORDER.length === 3, '3 branches');
ok(T.UPGRADE_ORDER.every(id => T.UPGRADE_BRANCHES[id].max === 10), '10 rangs par branche');
ok(T.normalizeUpgrades({assault:15, armor:-2, mobility:2}).assault === 10, 'normalisation bornée (plafond)');
ok(T.normalizeUpgrades({assault:15, armor:-2, mobility:2}).armor === 0, 'normalisation bornée (plancher)');

section('Amélioration + économie');
{
  const {R} = freshGame();
  R.state.res.crystal=99999; R.state.res.metal=99999; R.state.res.energy=99999; R.state.res.dust=99999; R.state.res.core=999;
  const before = TM.stats('marine');
  const a = TM.upgrade('marine','assault');
  ok(a.ok && TM.level('marine') === 2 && TM.branchLevel('marine','assault') === 1, 'rang Assaut acheté');
  ok(TM.stats('marine').dps > before.dps && TM.stats('marine').hp === before.hp, 'Assaut augmente les dégâts seulement');
  const h = TM.upgrade('marine','armor');
  ok(h.ok && TM.stats('marine').hp > before.hp, 'Blindage augmente les PV');
  const m = TM.upgrade('marine','mobility');
  ok(m.ok && TM.stats('marine').speed > before.speed && TM.stats('marine').range > before.range, 'Propulsion augmente vitesse + portée');
}

section('Sauvegarde');
{
  const {R} = freshGame();
  R.state.res.crystal=99999; R.state.res.metal=99999; R.state.res.energy=99999; R.state.res.dust=99999; R.state.res.core=999;
  TM.upgrade('titan','assault');
  const raw = JSON.parse(JSON.stringify(R.state));
  const restored = NEBUSTION.Save.normalize(raw, Date.now());
  ok(restored.troops.upgrades.titan.assault === 1, 'branche conservée dans la sauvegarde');
}

section('Combat utilise les stats améliorées');
{
  const {R} = freshGame();
  R.state.res.crystal=99999; R.state.res.metal=99999; R.state.res.energy=99999; R.state.res.dust=99999; R.state.res.core=999;
  const base = QB.buildBase({cells:{'2,2':'turret'}} , {scale:0.4});
  const normal = QB.create(base, {marine:1});
  normal.deploy('marine', -1, 2.5);
  for(let i=0;i<100;i++) normal.step(0.05);
  const d1 = base.buildings.find(b=>b.kind==='turret').maxHp - base.buildings.find(b=>b.kind==='turret').hp;
  TM.upgrade('marine','assault');
  const base2 = QB.buildBase({cells:{'2,2':'turret'}} , {scale:0.4});
  const boosted = QB.create(base2, {marine:1});
  boosted.deploy('marine', -1, 2.5);
  for(let i=0;i<100;i++) boosted.step(0.05);
  const d2 = base2.buildings.find(b=>b.kind==='turret').maxHp - base2.buildings.find(b=>b.kind==='turret').hp;
  ok(d2 > d1, 'combat applique le bonus Assaut');
}

c.done('Améliorations des troupes');
