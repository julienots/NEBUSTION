/* Nouvelles mécaniques de combat : verrouillage de cible, combo, rupture et réactions. */
'use strict';
global.window = global;
require('../js/data/Economy.js');
require('../js/data/Heroes.js');
require('../js/data/Enemies.js');
require('../js/systems/SaveManager.js');
require('../js/systems/CombatEngine.js');
const H = NEBUSTION.Heroes, EN = NEBUSTION.Enemies, CE = NEBUSTION.CombatEngine;
let passed = 0, failed = 0;
function ok(c,m){ if(c) passed++; else { failed++; console.log('  ✗ ECHEC : '+m); } }
function section(t){ console.log('\n# '+t); }

section('Verrouillage de cible');
{
  const hero = CE.makeHeroUnit(H.get('zyra'), 20, 'zyra');
  const a = CE.makeEnemyUnit(EN.get('steel_golem'), 'normal', 0);
  const b = CE.makeEnemyUnit(EN.get('drone_sentinel'), 'normal', 1);
  a.hp = a.maxHp = 100000; b.hp = b.maxHp = 100000;
  const e = new CE.CombatEngine([hero], [a,b], {mode:'manual'});
  e.setFocusTarget(b.uid);
  ok(e.focusTargetUid === b.uid, 'la cible est verrouillée');
  hero.gauge = 100; e.update(0.01);
  const ev = e.consumeEvents();
  ok(ev.some(x => x.type === 'attack' && x.targetUid === b.uid), 'l\'attaque automatique suit la cible verrouillée');
  e.clearFocusTarget();
  ok(e.focusTargetUid === null, 'la cible peut être libérée');
}

section('Combo d\'équipe');
{
  const hero = CE.makeHeroUnit(H.get('zyra'), 20, 'zyra');
  const enemy = CE.makeEnemyUnit(EN.get('steel_golem'), 'normal', 0);
  enemy.hp = enemy.maxHp = 1000000;
  const e = new CE.CombatEngine([hero], [enemy], {mode:'manual'});
  e.applyDamage(hero, enemy, 0.01, {noCrit:true});
  e.consumeEvents();
  e.applyDamage(hero, enemy, 0.01, {noCrit:true});
  const ev = e.consumeEvents();
  ok(e.combo === 2, 'deux impacts créent un combo de 2');
  ok(Math.abs(e.comboMultiplier() - 1.04) < 1e-9, 'le combo ajoute +2 % par impact supplémentaire');
  for(let i=0;i<12;i++) e.applyDamage(hero, enemy, 0.01, {noCrit:true});
  ok(e.combo === 10 && e.comboMultiplier() === 1.20, 'le combo est plafonné à +20 %');
  e.time = e.comboUntil + 0.1; e.update(0.01); const ev2=e.consumeEvents();
  ok(e.combo === 0 && ev2.some(x=>x.type==='comboReset'), 'le combo se rompt après la fenêtre');
}

section('Rupture de garde');
{
  const hero = CE.makeHeroUnit(H.get('necravion'), 20, 'necravion');
  const enemy = CE.makeEnemyUnit(EN.get('steel_golem'), 'normal', 0);
  enemy.hp = enemy.maxHp = 1000000; enemy.breakGauge = 100;
  const e = new CE.CombatEngine([hero], [enemy], {mode:'manual'});
  e.applyDamage(hero, enemy, 0.01, {noCrit:true, skill:true});
  e.consumeEvents();
  ok(enemy.breakGauge < 100, 'une compétence réduit la jauge de rupture');
  for(let i=0;i<6;i++) e.applyDamage(hero, enemy, 0.01, {noCrit:true, skill:true});
  const ev=e.consumeEvents();
  ok(enemy.breakUntil > e.time, 'la rupture déclenche une fenêtre de vulnérabilité');
  ok(enemy.stunTime > 0, 'la rupture étourdit la cible');
  ok(ev.some(x=>x.type==='break' && x.broken), 'un événement BRISÉ est émis');
}

section('Réactions élémentaires');
{
  const hero = CE.makeHeroUnit(H.get('ravnor'), 20, 'ravnor');
  const enemy = CE.makeEnemyUnit(EN.get('steel_golem'), 'normal', 0);
  enemy.hp = enemy.maxHp = 1000000;
  const e = new CE.CombatEngine([hero], [enemy], {mode:'manual'});
  enemy.dots.push({kind:'poison', src:hero, power:0.2, until:e.time+10, next:e.time+1});
  e._runOp(hero, {op:'dot', tgt:'primary', kind:'burn', power:0.2, dur:3}, {primary:enemy}, false);
  const ev=e.consumeEvents();
  ok(ev.some(x=>x.type==='reaction' && x.kind==='combustion'), 'poison + brûlure déclenche Combustion');
  ok(ev.some(x=>x.type==='damage'), 'la réaction inflige des dégâts');
}

console.log(`\nRésultat : ${passed} réussis, ${failed} échecs`);
process.exitCode = failed ? 1 : 0;
