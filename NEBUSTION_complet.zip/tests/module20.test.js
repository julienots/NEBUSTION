/* Tests du MODULE 20 : nouvelles troupes, bâtiments utiles du QG (Caserne, Atelier, Bio-labo, Radar, Raffinerie)
 * et améliorations du Symtor (stades, sécrétion, couvée, bonus de production). Node, sans Phaser.
 * Lancer : node tests/module20.test.js */
'use strict';
const { makeCounter, freshGame } = require('./progress-env');
['data/EmpireAI', 'data/EmpireDoctrine', 'data/QGRaid', 'data/QGAttack', 'data/Symbiote'].forEach(f => require('../js/' + f + '.js'));
['GalaxyManager', 'EmpireAIManager', 'EmpireEvolutionManager', 'QGRaidManager', 'QGAttackManager', 'SymbioteManager'].forEach(f => require('../js/systems/' + f + '.js'));
const c = makeCounter(), ok = c.ok, section = c.section;
const T = NEBUSTION.Troops, TM = NEBUSTION.TroopManager, G = NEBUSTION.QGGrid, GM = NEBUSTION.QGGridManager, S = NEBUSTION.Symbiote, SY = NEBUSTION.SymbioteManager, QB = NEBUSTION.QGBattle;

function giveAll(R) { ['crystal', 'metal', 'energy', 'dust', 'core'].forEach(id => { R.state.res[id] = 1e7; }); }
function place(R, sid, n) {   // pose n structures de type sid sur des parcelles libres
  const st = GM ? R.state.qgGrid : null; let put = 0;
  for (let x = 0; x < 6 && put < n; x++) for (let y = 0; y < 6 && put < n; y++) {
    const k = G.key(x, y); if (!R.state.qgGrid.unlocked[k]) R.state.qgGrid.unlocked[k] = true;
    if (!R.state.qgGrid.cells[k]) { R.state.qgGrid.cells[k] = sid; put++; }
  }
  R._rates = null; return put;
}

section('Nouvelles troupes : catalogue');
{
  ['swarm', 'artillery', 'pyro', 'sapper', 'gunship', 'dreadnought', 'spawn'].forEach(id => {
    const t = T.get(id);
    ok(!!t && t.hp > 0 && t.space > 0 && Object.keys(t.cost).every(r => NEBUSTION.Economy.RES[r]), id + ' : stats et coûts valides');
    ok(['any', 'wall', 'turret', 'eco', 'core'].indexOf(t.pref) >= 0 && typeof t.fly === 'boolean' && /^#[0-9a-f]{6}$/.test(t.hex), id + ' : cible/vol/couleur valides');
  });
  ok(T.ORDER.length === 27 && new Set(T.ORDER).size === 27, '27 troupes, identifiants uniques');
  ok(T.get('swarm').fly && T.get('gunship').fly && T.get('dreadnought').fly, 'les 3 nouveaux volants volent');
  ok(T.get('sapper').blast > T.get('breacher').blast, 'le Saboteur explose plus fort que le Casseur');
  ok(T.cost('marine', 3, 0.1).crystal === 108 && T.cost('marine', 3).crystal === 120, 'remise appliquée au coût (arrondi vers le haut)');
  ok(T.cost('marine', 1, 9).crystal === 20, 'remise plafonnée à 50 %');
  ok(T.capacity(0, 8) === 20 && T.capacity(2) === 20, 'capacité : bonus de Casernes en plus');
}

section('Nouveaux bâtiments : catalogue');
{
  const news = ['barracks', 'workshop', 'lab', 'radar', 'refinery'];
  ok(G.STRUCTURE_ORDER.length === 16 && news.every(id => G.STRUCTURE_ORDER.indexOf(id) >= 0), '16 structures (12 + 4 du module 28) dont les 5 du module 20');
  news.forEach(id => {
    const d = G.STRUCTURES[id];
    ok(d.maxCount >= 5 && d.effect.perUnit > 0 && typeof d.desc(2) === 'string' && Object.keys(d.base).every(r => NEBUSTION.Economy.RES[r]), id + ' : définition valide');
    ok(G.buildCost(id, 3).metal === undefined || G.buildCost(id, 3).metal > G.buildCost(id, 0).metal, id + ' : coût croissant');
  });
  ok(new Set(G.STRUCTURE_ORDER.map(id => G.STRUCTURES[id].color)).size === 16, 'couleurs toutes distinctes');
  const st = G.defaultState(); st.cells['2,2'] = 'barracks'; st.cells['3,2'] = 'radar'; st.cells['2,3'] = 'radar';
  ok(G.bonusValue('army', st) === 4 && Math.abs(G.bonusValue('attackCooldown', st) - 0.12) < 1e-9, 'bonusValue par type d\'effet');
  ok(G.normalizeState(st).cells['2,2'] === 'barracks', 'normalizeState garde les nouvelles structures');
  const over = G.defaultState(); for (let i = 0; i < 4; i++) over.cells[G.key([2, 3, 2, 3][i], [2, 2, 3, 3][i])] = 'barracks';
  ok(Object.keys(G.normalizeState(over).cells).length === 4, 'sous le plafond : tout est conservé');
}

section('Bâtiments : effets réels');
{
  const { R } = freshGame(); giveAll(R);
  ok(TM.capacity() === 20 && TM.armyBonus() === 0 && TM.discount() === 0, 'sans bâtiment : aucun bonus');
  const b0 = GM.build(2, 2, 'barracks'); ok(b0.ok, 'construction d\'une Caserne');
  ok(TM.armyBonus() === 4 && TM.capacity() === 24, 'Caserne : +4 places d\'armée');
  place(R, 'workshop', 4); ok(Math.abs(TM.discount() - 0.12) < 1e-9, '4 Ateliers : −12 % (' + TM.discount() + ')');
  ok(TM.cost('marine', 10).crystal === Math.ceil(40 * 10 * 0.88), 'TroopManager.cost applique la remise');
  const before = R.state.res.crystal, b = TM.buy('marine', 10);
  ok(b.ok && before - R.state.res.crystal === TM.cost('marine', 10).crystal, 'achat débité au prix remisé');
  ok(NEBUSTION.ShopManager.troopCost('marine', 10).crystal === TM.cost('marine', 10).crystal, 'la Boutique affiche le même prix');
  R.state.res.crystal = 1e7;
  const sb = NEBUSTION.ShopManager.buyTroop('sapper', 2); ok(sb.ok || sb.reason === 'capacite', 'achat en boutique cohérent (' + (sb.reason || 'ok') + ')');
  const sold = GM.sell(2, 2); ok(sold.ok && TM.armyBonus() === 0, 'vendre la Caserne retire le bonus');
  const AM = NEBUSTION.QGAttackManager;
  ok(AM.cooldownMs() === 3 * 3600 * 1000 && AM.lootMult() === 1, 'sans Radar/Raffinerie : recharge 3 h, butin ×1');
  place(R, 'radar', 5); place(R, 'refinery', 5);
  ok(AM.cooldownMs() === Math.round(3 * 3600 * 1000 * 0.7), '5 Radars : −30 % de recharge');
  ok(Math.abs(AM.lootMult() - 1.25) < 1e-9, '5 Raffineries : +25 % de butin');
  ok(AM.cooldownRemaining('ferrox', Date.now()) === 0 && AM.cooldownRemaining('ferrox', Date.now()) <= AM.cooldownMs(), 'cooldownRemaining reste valide');
  const saved = NEBUSTION.Save.normalize(JSON.parse(JSON.stringify(R.state)), Date.now());
  ok(Object.values(saved.qgGrid.cells).filter(v => v === 'radar').length === 5, 'sauvegarde/normalisation conserve les Radars');
}

section('Nouvelles troupes en combat');
{
  const { R } = freshGame();
  const base = QB.botBase('vexor', 4, 0);
  ['swarm', 'artillery', 'pyro', 'sapper', 'gunship', 'dreadnought', 'spawn'].forEach(id => {
    const sim = QB.create(base, { [id]: 4 });
    let dep = { ok: true }, placed = 0; for (let i = 0; i < 4 && dep.ok; i++) { dep = sim.deploy(id, -0.6, 1.5 + i * 0.6); if (dep.ok) placed++; }
    let n = 0; while (!sim.over && n++ < 20 * 90) sim.step(0.05);
    const bad = sim.troops.some(u => !isFinite(u.x) || !isFinite(u.y) || !isFinite(u.hp));
    const dmg = sim.buildings.some(b => b.hp < b.maxHp || !b.alive);
    ok(placed === 4 && !bad && dmg, id + ' : 4 déployés, simulation stable, la base subit des dégâts (' + n + ' pas)');
  });
  const s2 = QB.create(base, { dreadnought: 1 });
  ok(s2.deploy('dreadnought', -0.6, 2).ok, 'Dreadnought déployable');
}

section('Symtor : données pures');
{
  ok(S.stageOf(1).name === 'Larve' && S.stageOf(9).name === 'Juvénile' && S.stageOf(20).name === 'Alpha' && S.stageOf(50).name === 'Primordial', 'stades d\'évolution');
  ok(S.productionBonus(1) === 0 && Math.abs(S.productionBonus(11) - 0.02) < 1e-9 && S.productionBonus(50) === 0.098 && S.productionBonus(999) === 0.10, 'bonus de production : +0,2 %/niv., max 10 %');
  ok(S.hatchCount(2) === 0 && S.hatchCount(3) === 1 && S.hatchCount(8) === 2 && S.hatchCount(50) === 6, 'nombre de Rejetons par couvée');
  const r1 = S.secretionPerHour(1), r30 = S.secretionPerHour(30);
  ok(Object.keys(r1).every(k => r30[k] > r1[k] && r1[k] > 0), 'sécrétion croissante avec le niveau');
  ok(S.rewardMult(1) === 1 && S.rewardMult(11) === 1.3, 'récompenses de combat ×(1+3 %/niv.)');
  const d = S.defaultState(); ok(d.lastCollectAt === 0 && d.lastHatchAt === 0, 'horloges à 0 par défaut');
  const n = S.normalizeState({ built: true, capsuleOpened: true, level: 5, lastCollectAt: '123', lastHatchAt: -4 });
  ok(n.lastCollectAt === 123 && n.lastHatchAt === 0, 'normalizeState : horloges nettoyées');
  ok(S.normalizeState({ level: 7 }).level === 7 && S.normalizeState(null).lastCollectAt === 0, 'anciennes sauvegardes acceptées');
}

section('Symtor : sécrétion, couvée, bonus');
{
  const { R } = freshGame(); giveAll(R);
  const H = 3600 * 1000, t0 = 1.7e12;
  ok(SY.bonus('production') === 0 && !SY.pending(t0).any, 'capsule fermée : aucun bonus, rien à collecter');
  ok(SY.collect(t0).reason === 'capsule' && SY.hatch(t0).reason === 'capsule', 'collecte/couvée refusées capsule fermée');
  SY.state().built = true; ok(SY.openCapsule().ok, 'capsule ouverte');
  const s = SY.state(); s.level = 10; s.lastCollectAt = t0; s.lastHatchAt = t0;
  ok(!SY.pending(t0).any && SY.collect(t0).reason === 'empty', 'juste après l\'ouverture : rien à collecter');
  const p2 = SY.pending(t0 + 2 * H), rate = S.secretionPerHour(10);
  ok(p2.any && p2.res.crystal === rate.crystal * 2 && Math.abs(p2.hours - 2) < 1e-9, 'après 2 h : 2 × la sécrétion horaire');
  const p99 = SY.pending(t0 + 99 * H); ok(p99.hours === 8 && p99.full && p99.res.dust === rate.dust * 8, 'plafonnée à 8 h');
  const before = R.state.res.crystal; R.state.res.crystal = 0;
  const col = SY.collect(t0 + 2 * H); ok(col.ok && R.state.res.crystal === rate.crystal * 2, 'collecte : ressources créditées (' + R.state.res.crystal + ')');
  ok(SY.state().lastCollectAt === t0 + 2 * H && !SY.pending(t0 + 2 * H).any, 'horloge remise à zéro après collecte');
  ok(Math.abs(SY.bonus('production') - 0.018) < 1e-9, 'bonus de production niv.10 = +1,8 %');
  // le bonus entre bien dans le taux de production réel
  const st = SY.state(); st.level = 1; R._rates = null; const r1 = R.rate('crystal'); st.level = 50; R._rates = null; const r50 = R.rate('crystal');
  ok(Math.abs(r50 / r1 - 1.098) < 1e-6, 'taux de production ×1,098 au niveau 50 (' + (r50 / r1).toFixed(4) + ')');
  st.level = 10;
  ok(SY.hatch(t0 + 5 * H).reason === 'wait' && SY.hatchRemaining(t0 + 5 * H) === H, 'couvée pas prête avant 6 h');
  const stock0 = TM.count('spawn'); const h = SY.hatch(t0 + 6 * H);
  ok(h.ok && h.count === 2 && TM.count('spawn') === stock0 + 2, 'couvée : +2 Rejetons (niv. 10)');
  ok(SY.hatch(t0 + 6 * H + 1).reason === 'wait', 'la couvée repart en recharge');
  st.level = 2; st.lastHatchAt = t0; ok(SY.hatch(t0 + 9 * H).reason === 'level', 'couvée impossible sous le niv. 3');
  st.level = 10;
  // Bio-labo : +8 % d'XP par labo
  const xp0 = () => SY.state().xp + 0;
  st.xp = 0; st.level = 1; R.state.res.energy = 1e6; const f0 = SY.feed('energy'); const base = f0.xp;
  place(R, 'lab', 5); st.xp = 0; st.level = 1; const f1 = SY.feed('energy');
  ok(base === 24 && f1.xp === Math.round(24 * 1.4), 'Bio-labo ×5 : +40 % d\'XP (' + f1.xp + ')');
  // récompenses de combat proportionnelles au niveau
  st.level = 31; let seen = 0; for (let i = 0; i < 40 && !seen; i++) { const b = SY.battle('galaxy'); if (b.ok && b.win) seen = b.reward.crystal; }
  ok(seen === Math.round(120 * 1.9) || seen === 0, 'récompense de victoire ×1,9 au niveau 31 (' + seen + ')');
  // ancienne sauvegarde : capsule déjà ouverte sans horloges → démarre sans cadeau rétroactif
  st.lastCollectAt = 0; st.lastHatchAt = 0; const now = t0 + 50 * H;
  ok(!SY.pending(now).any && st.lastCollectAt === now, 'ancienne sauvegarde : pas de gain rétroactif');
  const sv = NEBUSTION.Save.normalize(JSON.parse(JSON.stringify(R.state)), Date.now());
  ok(sv.symbiote && sv.symbiote.lastCollectAt === now && sv.symbiote.capsuleOpened === true, 'sauvegarde conserve les horloges du Symtor');
}

c.done('Module 20 : troupes, bâtiments utiles, Symtor');
