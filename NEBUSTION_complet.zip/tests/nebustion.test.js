/* Tests du module Nebustion (NEBUSTION.Nebustion + NebustionManager), Node, sans Phaser.
 * Lancer : node tests/nebustion.test.js */
'use strict';
const E = require('./progress-env');
const t = E.makeCounter(), ok = t.ok, section = t.section;
const D = NEBUSTION.Nebustion;

section('Formules (données pures)');
{
  const s = D.defaultState(1000);
  ok(s.pct === 0 && s.sanctuaryLevel === 0 && s.shards === 0 && s.resonance === 0 && !s.unlocked, 'état par défaut : tout à zéro, non débloqué');
  ok(D.normalizeState(null, 1000).pct === 0, 'normalizeState tolère une sauvegarde absente');
  ok(D.normalizeState({ pct: 500, sanctuaryLevel: 99, resonance: -5 }, 1000).pct === 100, 'jauge bornée à 100');
  ok(D.normalizeState({ pct: 500, sanctuaryLevel: 99 }, 1000).sanctuaryLevel === D.CFG.SANCTUARY_MAX_LEVEL, 'niveau de Sanctuaire borné au max');
  ok(D.normalizeState({ resonance: -5 }, 1000).resonance === 0, 'résonance bornée à 0 minimum');

  ok(D.ratePerHour(D.defaultState(0)) === D.CFG.BASE_RATE_PER_HOUR, 'vitesse de base sans Sanctuaire');
  const withSanct = D.defaultState(0); withSanct.sanctuaryLevel = 10;
  ok(Math.abs(D.ratePerHour(withSanct) - D.CFG.BASE_RATE_PER_HOUR * (1 - 0.35)) < 1e-9, 'Sanctuaire niveau 10 : -35% de vitesse');
  const corrupted = D.defaultState(0); corrupted.symtorCorrupted = true;
  ok(D.ratePerHour(corrupted) === D.CFG.BASE_RATE_PER_HOUR + D.CFG.CORRUPTED_SYMTOR_EXTRA_RATE_PER_HOUR, 'Symtor corrompu : vitesse accrue');

  const c0 = D.sanctuaryCost(0), c1 = D.sanctuaryCost(1);
  ok(c0.crystal === D.CFG.SANCTUARY_BASE_COST.crystal, 'coût du Sanctuaire niveau 0 = coût de base');
  ok(c1.crystal > c0.crystal, 'le coût du Sanctuaire croît avec le niveau');
  ok(D.sanctuaryDecayPct(0) === 0 && D.sanctuaryDecayPct(20) === 70, 'réduction de vitesse : 0% niveau 0, 70% niveau max');
  ok(D.outpostScaleBonus(0) === 1 && Math.abs(D.outpostScaleBonus(100) - 1.6) < 1e-9, 'bonus de difficulté des avant-postes : x1 à x1,6');
}

section('Jauge : tick et purification');
{
  // NB : defaultState(0)/tick(s, 0) retombent sur Date.now() (0 est traité comme "non fourni"
  // dans tout le code du jeu, comme les autres modules à pas de temps) : on part donc d'un instant non nul.
  const s = D.defaultState(1000);
  const delta1 = D.tick(s, 1000 + 3600000); // +1h
  ok(Math.abs(delta1 - D.CFG.BASE_RATE_PER_HOUR) < 1e-9 && Math.abs(s.pct - D.CFG.BASE_RATE_PER_HOUR) < 1e-9, 'tick de 1h fait monter la jauge de la vitesse de base');
  ok(D.tick(s, 1000 + 3600000) === 0, 'un second tick au même instant (ou avant) n\'ajoute rien');
  const long = D.defaultState(1000);
  D.tick(long, 1000 + 3600000 * 24 * 365); // 1 an, doit être borné à MAX_CATCHUP_HOURS
  ok(long.pct <= 100 && long.pct > 0, 'rattrapage hors ligne borné, jauge toujours valide');

  const p = D.defaultState(1000); p.pct = 40;
  const applied = D.purify(p, 15);
  ok(applied === 15 && p.pct === 25, 'purify() réduit la jauge du montant demandé');
  ok(D.purify(p, 1000) === 25 && p.pct === 0, 'purify() ne descend jamais sous 0');
}

section('Sanctuaire : activation et cooldown');
{
  const s = D.defaultState(0);
  ok(!D.canActivateSanctuary(s, 0), 'pas de Sanctuaire construit => pas d\'activation possible');
  s.sanctuaryLevel = 1;
  ok(D.canActivateSanctuary(s, 0), 'Sanctuaire construit, jamais activé => activable');
  s.sanctuaryUsedAt = 0;
  ok(!D.canActivateSanctuary(s, D.CFG.SANCTUARY_ACTIVATE_COOLDOWN_MS - 1), 'juste avant la fin du cooldown : refusé');
  ok(D.canActivateSanctuary(s, D.CFG.SANCTUARY_ACTIVATE_COOLDOWN_MS), 'cooldown écoulé : de nouveau activable');
  ok(D.sanctuaryCooldownRemainingMs(s, 1000) === D.CFG.SANCTUARY_ACTIVATE_COOLDOWN_MS - 1000, 'temps restant calculé correctement');
}

section('Dilemme du Symtor');
{
  const s = D.defaultState(0);
  ok(D.feedTainted(s).ok === false, 'nourrir sans Éclat Souillé : refusé');
  s.shards = D.CFG.SHARDS_PER_FEED * 10;
  let last;
  for (let i = 0; i < 8; i++) last = D.feedTainted(s);
  ok(s.shards === D.CFG.SHARDS_PER_FEED * 2 && s.symtorFeeds === 8, 'chaque nourrissage consomme des Éclats et compte');
  ok(s.resonance === 100 && s.symtorCorrupted === true, '8 nourrissages (14%/coup, borné à 100) suffisent à corrompre le Symtor');
  ok(last.justCorrupted === true, 'le nourrissage qui fait basculer la résonance à 100 le signale');
  ok(D.feedTainted(s).justCorrupted === false, 'nourrir un Symtor déjà corrompu ne re-signale pas la bascule');
  ok(D.purifySymtor(s) === true && !s.symtorCorrupted && s.resonance === 0, 'la Larme de Purification lève la corruption');
  ok(D.purifySymtor(s) === false, 'purifier un Symtor déjà sain : sans effet');
}

// ---------- Partie simulée (via NebustionManager) ----------
const g = E.freshGame(), R = g.R;
const NM = NEBUSTION.NebustionManager;

section('Déblocage');
{
  ok(!NM.isUnlocked() && NM.pct() === 0, 'module verrouillé tant qu\'OMEGA-KRELL n\'est pas vaincu');
  ok(NM.tick(Date.now() + 3600000) === 0, 'tick() ne fait rien tant que le module est verrouillé');
  R.state.combat.stageStars['boss_omega_krell'] = 3;
  ok(NM.isUnlocked() === true, 'la victoire sur OMEGA-KRELL débloque le module');
}

section('Sanctuaire via le Manager');
{
  ok(NM.sanctuaryLevel() === 0, 'Sanctuaire pas encore construit');
  const before = NM.upgradeSanctuary();
  ok(before.reason === 'cost', 'achat refusé sans ressources');
  Object.keys(NM.sanctuaryCost()).forEach(id => R.add(id, 999999, 'test'));
  const up = NM.upgradeSanctuary();
  ok(up.ok && NM.sanctuaryLevel() === 1, 'achat réussi avec assez de ressources');
  ok(NM.canActivateSanctuary(), 'Sanctuaire construit, jamais activé => activable immédiatement');
  const act = NM.activateSanctuary();
  ok(act.ok === true, 'activation réussie');
  ok(!NM.canActivateSanctuary(), 'juste après activation : cooldown entamé => refusé');
}

section('Avant-postes et boss (récompenses)');
{
  const shardsBefore = NM.shards();
  const p1 = NM.rewardOutpostVictory();
  ok(NM.shards() === shardsBefore + D.CFG.OUTPOST_SHARD_REWARD, 'victoire d\'avant-poste : Éclat Souillé crédité');
  ok(p1 >= 0, 'victoire d\'avant-poste : purification appliquée (>= 0)');
  ok(!NM.bossDefeated(), 'boss non vaincu au départ');
  NM.rewardBossVictory();
  ok(NM.shards() === shardsBefore + D.CFG.OUTPOST_SHARD_REWARD + D.CFG.BOSS_SHARD_REWARD, 'victoire du boss : grosse récompense d\'Éclat Souillé');
}

section('Symtor via le Manager');
{
  ok(NM.resonance() === 0 && !NM.symtorCorrupted(), 'résonance à zéro au départ');
  NM.addShards(1000);
  let res;
  for (let i = 0; i < 8; i++) res = NM.feedTaintedToSymtor();
  ok(NM.symtorCorrupted() === true, 'nourrissages répétés corrompent le Symtor');
  ok(NM.purifySymtor() === true && !NM.symtorCorrupted(), 'purification du Symtor via le Manager');
}

t.done('Nebustion');
