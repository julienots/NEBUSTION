/* NEBUSTION - tests Node de la logique des épreuves jouables du Trou Noir (aucune dépendance à Phaser).
 * Usage : node tests/blackhole_arena.test.js [chemin/vers/ancien/BlackHole.js]  (le 2e argument active la comparaison de non-régression) */
global.window = global; global.NEBUSTION = {};
var assert = require('assert'), fails = 0, n = 0;
function ok(c, m) { n++; if (!c) { fails++; console.error('ECHEC: ' + m); } }
var BH = require('../js/data/BlackHole.js');
var rates = { crystal: 3, metal: 2.5, energy: 2, dust: 3, core: 0.3 }, talents = { hull: 0, prod: 0, luck: 0 };

// 1) previewKind = exactement le type que resolveChoice produira (avec ou sans perf)
var mism = 0, total = 0;
for (var seed = 1; seed <= 300; seed++) for (var depth = 1; depth <= 30; depth += 1) {
  BH.choiceOptions(seed * 7919, depth).forEach(function (o) {
    var k = BH.previewKind(seed * 7919, depth, o, talents);
    var r = BH.resolveChoice({ seed: seed * 7919, depth: depth, option: o, teamPower: 500, rates: rates, talents: talents });
    total++; if (k !== r.kind) mism++;
  });
}
ok(mism === 0, 'previewKind cohérent avec resolveChoice (' + mism + '/' + total + ' écarts)');

// 2) modes
ok(BH.modeOf('cache') === 'collect' && BH.modeOf('relique') === 'collect', 'cache/relique = collect');
ok(BH.modeOf('anomalie_negative') === 'dodge', 'choc de marée = dodge');
ok(BH.modeOf('echo') === 'fight' && BH.modeOf('abime') === 'fight', 'écho/seuil = fight');
ok(BH.modeOf('sanctuaire') === null && BH.modeOf('anomalie_positive') === null, 'repos non jouables');
ok(BH.arenaParams('sanctuaire', 3, 100, 42, 0) === null, 'arenaParams null pour un repos');

// 3) arenaParams : déterminisme, bornes, boss, puissance
var a = BH.arenaParams('echo', 7, 900, 12345, 1), b = BH.arenaParams('echo', 7, 900, 12345, 1);
ok(JSON.stringify(a) === JSON.stringify(b), 'arenaParams déterministe');
ok(a.mode === 'fight' && a.enemyHp === 100 && a.duration === 20 && !a.boss, 'paramètres écho');
ok(/^[a-z_]+$/.test(a.enemyId) && a.playerDps > 0, 'ennemi + dps définis');
var boss = BH.arenaParams('abime', 10, 900, 1, 0);
ok(boss.boss && boss.duration === 28 && ['vorath','nexus_prime','omega_krell','nebustion_primordiale'].indexOf(boss.enemyId) >= 0, 'Seuil = boss');
var weak = BH.arenaParams('echo', 10, 10, 1, 0), strong = BH.arenaParams('echo', 10, 1e7, 1, 0);
ok(strong.playerDps > weak.playerDps, 'plus de puissance d\u2019équipe = plus de dégâts');
ok(Math.abs(strong.playerDps / weak.playerDps - 2.2 / 0.4) < 1e-9, 'dps borné entre x0,4 et x2,2');
ok(BH.hitDamage(1) < BH.hitDamage(25), 'les impacts font plus mal en profondeur');
var col = BH.arenaParams('cache', 3, 0, 5, 0);
ok(col.mode === 'collect' && col.total === 14 && ['crystal','metal','energy','dust','core'].indexOf(col.resId) >= 0, 'collecte : total + ressource');

// 4) resolveChoice avec perf
function R(kind, depth, perf) {
  var opt = { idx: 0, danger: 2, forced: kind === 'abime' ? 'abime' : null };
  // on cherche un seed dont l'option produit le type voulu
  for (var s = 1; s < 5000; s++) { if (BH.previewKind(s, depth, opt, talents) === kind) return BH.resolveChoice({ seed: s, depth: depth, option: opt, teamPower: 1e6, rates: rates, talents: talents, perf: perf }); }
  throw new Error('pas de seed pour ' + kind);
}
var full = R('cache', 8, { score: 1, win: true, damage: 0, resId: 'metal' }), half = R('cache', 8, { score: 0.5, win: true, damage: 0, resId: 'metal' }), none = R('cache', 8, { score: 0, win: false, damage: 0, resId: 'metal' });
ok(full.played && full.resources.metal > half.resources.metal && half.resources.metal > none.resources.metal, 'cache : gain croissant avec la récolte');
ok(full.integrityDelta === 0, 'cache sans impact : intégrité intacte');
var hit = R('cache', 8, { score: 1, win: true, damage: 17, resId: 'metal' });
ok(hit.integrityDelta === -17, 'l\u2019intégrité perdue = dégâts subis dans l\u2019arène');
var rel1 = R('relique', 12, { score: 1, win: true, damage: 0 }), rel0 = R('relique', 12, { score: 0.1, win: true, damage: 0 });
ok(rel1.fragments > rel0.fragments, 'relique : plus de fragments si mieux captés');
var tide0 = R('anomalie_negative', 6, { score: 1, win: true, damage: 0 }), tide1 = R('anomalie_negative', 6, { score: 0, win: true, damage: 12 });
ok(tide0.fragments > 0 && tide0.integrityDelta === 0, 'marée : esquive parfaite = bonus');
ok(tide1.fragments === 0 && tide1.integrityDelta === -12, 'marée : impacts = perte');
var win = R('echo', 9, { score: 1, win: true, damage: 10, resId: 'crystal' }), lose = R('echo', 9, { score: 0.6, win: false, damage: 30, resId: 'crystal' });
ok(win.success === true && lose.success === false, 'écho : succès/échec selon le combat');
ok((win.resources.crystal || 0) > (lose.resources.crystal || 0) && win.fragments >= lose.fragments, 'victoire mieux payée que défaite');
var bw = R('abime', 10, { score: 1, win: true, damage: 5 }), bl = R('abime', 10, { score: 0.2, win: false, damage: 40 });
ok(Object.keys(bw.resources).length >= 1 && bw.fragments > bl.fragments, 'Seuil : victoire >> échec');
var junk = R('cache', 8, { score: 99, win: true, damage: -50, resId: 'nimportequoi' });
ok(junk.integrityDelta === 0 && Object.keys(junk.resources).length === 1, 'entrées absurdes bornées');
ok(JSON.stringify(R('echo', 9, { score: .5, win: false, damage: 20, resId: 'dust' })) === JSON.stringify(R('echo', 9, { score: .5, win: false, damage: 20, resId: 'dust' })), 'résolution déterministe');

// 5) Non-régression : sans perf, le résultat est identique à l'ancienne version du fichier
if (process.argv[2]) {
  var oldPath = require('path').resolve(process.argv[2]);
  var saved = global.NEBUSTION; global.NEBUSTION = {};
  delete require.cache[oldPath];
  var OLD = require(oldPath); global.NEBUSTION = saved;
  var diff = 0, cnt = 0;
  for (var sd = 1; sd <= 200; sd++) for (var dp = 1; dp <= 26; dp++) {
    BH.choiceOptions(sd * 31, dp).forEach(function (o) {
      [0, 300, 5000].forEach(function (tp) {
        var inp = { seed: sd * 31, depth: dp, option: o, teamPower: tp, rates: rates, talents: { hull: 1, prod: 2, luck: 3 } };
        cnt++; if (JSON.stringify(BH.resolveChoice(inp)) !== JSON.stringify(OLD.resolveChoice(inp))) diff++;
      });
    });
  }
  ok(diff === 0, 'non-régression sans perf : ' + diff + '/' + cnt + ' écarts');
}
console.log(n + ' vérifications, ' + fails + ' échec(s)');
process.exit(fails ? 1 : 0);
