"""Test navigateur (Chromium + FAUX Phaser) du MODULE 20 : 9 structures dans le QG (dessin + panneau), Caserne à 20 troupes,
combat avec les nouvelles troupes, Symtor (sécrétion / couvée / nourrissage ×N).
Lancer : python3 tests/browser-module20.py   (playwright pour Python ; CHROME=/chemin/chrome optionnel)"""
import http.server, socketserver, threading, os, sys, json, time
from playwright.sync_api import sync_playwright
root = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
mock = open(os.path.join(root, 'tests', 'mock-phaser.js'), 'rb').read()
class H(http.server.SimpleHTTPRequestHandler):
    def __init__(s, *a, **k): super().__init__(*a, directory=root, **k)
    def do_GET(s):
        if s.path.split('?')[0] == '/js/vendor/phaser.min.js':
            s.send_response(200); s.send_header('Content-Type', 'text/javascript'); s.end_headers(); s.wfile.write(mock); return
        super().do_GET()
    def log_message(s, *a): pass
socketserver.TCPServer.allow_reuse_address = True
srv = socketserver.TCPServer(('127.0.0.1', 8772), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
passed = failed = 0
def ok(c, m):
    global passed, failed
    if c: passed += 1
    else: failed += 1; print('  ✗ ' + m)
with sync_playwright() as p:
    kw = {'args': ['--no-sandbox']}
    if os.environ.get('CHROME'): kw['executable_path'] = os.environ['CHROME']
    b = p.chromium.launch(**kw); pg = b.new_page(viewport={'width': 390, 'height': 780})
    errs = []
    pg.on('pageerror', lambda e: errs.append('pageerror: ' + str(e)))
    pg.on('console', lambda m: errs.append('console.error: ' + m.text) if m.type == 'error' else None)
    R = pg.evaluate
    def wait_scene(k, ms=15000):
        t0 = time.time()
        while time.time() - t0 < ms / 1000:
            if R("k => !!(window.__NEBUSTION_GAME__ && window.__NEBUSTION_GAME__.scene.isActive(k))", k): return True
            time.sleep(0.1)
        return False
    def go(scene, data='{}'):
        R(f"(() => {{ const g = __NEBUSTION_GAME__; const k = Object.keys(g.scenes).find(n => g.scene.isActive(n)) || 'MainMenuScene'; g.scenes[k].scene.start('{scene}', {data}); }})()")
        return wait_scene(scene)
    pg.goto('http://127.0.0.1:8772/index.html?debug=1')
    ok(wait_scene('MainMenuScene'), 'menu atteint')
    R("(() => { const r = NEBUSTION.Resources; ['crystal','metal','energy','dust','core'].forEach(id => { r.state.res[id] = Math.min(r.cap(id), 900000); }); })()")

    # ---- QG : 9 structures ----
    ok(go('QGScene'), 'QGScene'); time.sleep(0.5)
    S = '__NEBUSTION_GAME__.scenes.QGScene'
    NEW = ['barracks', 'workshop', 'lab', 'radar', 'refinery']
    ok(R(f"{NEW}.every(k => {S}.textures.exists('qgiso_b_' + k) && {S}.textures.exists('qgiso_pad_' + k))"), '10 textures (pad + volume) générées pour les 5 nouveaux bâtiments')
    ok(R(f"{S}._buildCards.length") == 9, '9 cartes de construction')
    R("(() => { const st = NEBUSTION.Resources.state.qgGrid; for (let x = 0; x < 6; x++) for (let y = 0; y < 6; y++) st.unlocked[x + ',' + y] = true; })()")
    R(f"{S}._openPanel(0,0)")
    names = R(f"{S}._buildCards.map(c => c.name.text)")
    ok(all(v for v in names) and 'Caserne (0/5)' in names and 'Raffinerie (0/5)' in names, 'cartes nommées : ' + ', '.join(names))
    ok(R(f"{S}._buildCards.every(c => c.container.visible)"), 'toutes les cartes visibles en mode construction')
    pos = R(f"{S}._buildCards.map(c => [Math.round(c.container.x), Math.round(c.container.y)])")
    ok(len(set(map(tuple, pos))) == 9 and len(set(y for _, y in pos)) == 2, '9 positions distinctes sur 2 rangées : ' + str(pos))
    for i, sid in enumerate(NEW):
        col, row = 0, i
        R(f"{S}._openPanel({col},{row})")
        R(f"{S}._doBuild('{sid}')"); time.sleep(0.15)
        ok(R(f"NEBUSTION.QGGridManager.structureAt({col},{row})") == sid, f'{sid} construit')
    time.sleep(0.6)
    R(f"{S}._openPanel(0,2)")   # structure posée → panneau « built »
    ok(R(f"{S}._panelMode") == 'built' and 'Bio-labo' in R(f"{S}._panelTitle.text") and 'XP' in R(f"{S}._panelSub.text"), 'panneau structure posée : ' + R(f"{S}._panelSub.text"))
    ok(R("NEBUSTION.TroopManager.armyBonus()") == 4 and R("NEBUSTION.TroopManager.capacity()") == 24, 'Caserne : capacité 24')
    ok(R("Math.round(NEBUSTION.TroopManager.discount() * 100)") == 3, 'Atelier : remise 3 %')

    # ---- Caserne (20 troupes) ----
    ok(go('TroopsScene'), 'TroopsScene'); time.sleep(0.4)
    T = '__NEBUSTION_GAME__.scenes.TroopsScene'
    ok(R(f"{T}._cards.length") == 20, '20 cartes de troupes')
    ymax = R(f"Math.max(...{T}._cards.map(c => c.y))")
    ok(ymax + 41 < 1130, 'les cartes tiennent au-dessus du bouton boutique (dernière carte y=%d)' % ymax)
    bt = R(f"{T}._bonusText ? {T}._bonusText.text : ''")
    ok('Casernes +4' in bt and 'Ateliers' in bt, 'bonus de Caserne/Atelier affiché : ' + bt)

    # ---- Boutique : onglet Troupes ----
    ok(go('ShopScene', "{tab: 'troops'}"), 'ShopScene'); time.sleep(0.5)

    # ---- Combat : nouvelles troupes ----
    R("['swarm','artillery','pyro','sapper','gunship','dreadnought','spawn'].forEach(id => NEBUSTION.TroopManager.grant(id, 2))")
    ok(go('QGBattleScene', "{eid: 'vexor'}"), 'QGBattleScene'); time.sleep(0.6)
    B = '__NEBUSTION_GAME__.scenes.QGBattleScene'
    ok(R(f"['swarm','artillery','pyro','sapper','gunship','dreadnought','spawn'].every(id => {B}.textures.exists('qgtr_' + id + '_0') && {B}.textures.exists('qgtr_' + id + '_1'))"), 'sprites (2 images de marche) des 7 nouvelles troupes')
    ok(R(f"{B}._cards.length") == 9, 'réserve : 9 cartes (marine, berserker + 7 nouvelles) : %d' % R(f"{B}._cards.length"))
    R(f"{B}._select('dreadnought')")
    dep = R(f"{B}.sim.deploy('dreadnought', -0.6, 2).ok")
    ok(dep, 'Dreadnought déployé dans l\'arène')
    time.sleep(0.5)

    # ---- Symtor ----
    R("(() => { const s = NEBUSTION.SymbioteManager.state(); s.built = true; s.capsuleOpened = true; s.level = 12; s.lastCollectAt = Date.now() - 3 * 3600 * 1000; s.lastHatchAt = Date.now() - 7 * 3600 * 1000; NEBUSTION.Resources.state.res.energy = 500000; })()")
    ok(go('SymbioteScene'), 'SymbioteScene'); time.sleep(0.7)
    Y = '__NEBUSTION_GAME__.scenes.SymbioteScene'
    ok(R(f"{Y}._collectBtn.visible && {Y}._hatchBtn.visible && {Y}._qtyBtn.visible") and not R(f"{Y}._capsuleBtn.visible"), 'capsule ouverte : Collecter/Couvée/×N visibles, bouton capsule masqué')
    st = R(f"{Y}._stageTxt.text"); info = R(f"{Y}._infoTxt.text")
    ok('Prédateur' in st and '%' in st, 'stade + bonus affichés : ' + st)
    ok('Sécrétion' in info and 'Couvée prête' in info, 'sécrétion + couvée : ' + info)
    ok(R(f"{Y}._collectBtn.disabled") is False and R(f"{Y}._hatchBtn.disabled") is False, 'boutons actifs')
    ok('COUVÉE ×2' in R(f"{Y}._hatchBtn.labelText.text"), 'libellé de couvée : ' + R(f"{Y}._hatchBtn.labelText.text"))
    c0 = R("NEBUSTION.Resources.state.res.dust")
    R(f"{Y}._collect()"); time.sleep(0.2)
    ok(R("NEBUSTION.Resources.state.res.dust") > c0, 'collecte : ressources créditées')
    ok(R(f"{Y}._collectBtn.disabled") is True, 'après collecte : bouton grisé')
    s0 = R("NEBUSTION.TroopManager.count('spawn')")
    R(f"{Y}._hatch()"); time.sleep(0.2)
    ok(R("NEBUSTION.TroopManager.count('spawn')") == s0 + 2, 'couvée : +2 Rejetons')
    ok('🧬' in R(f"{Y}._hatchBtn.labelText.text") and R(f"{Y}._hatchBtn.disabled") is True, 'couvée en recharge : ' + R(f"{Y}._hatchBtn.labelText.text"))
    R(f"{Y}._cycleQty()"); R(f"{Y}._cycleQty()")
    ok(R(f"{Y}._qty") == 10 and R(f"{Y}._qtyBtn.labelText.text") == 'NOURRIR ×10', 'quantité ×10')
    t0 = R("NEBUSTION.SymbioteManager.state().totalFed")
    R(f"{Y}._feed('energy', 0xffd166)"); time.sleep(0.2)
    ok(R("NEBUSTION.SymbioteManager.state().totalFed") == t0 + 10, 'nourrissage ×10 : 10 repas')
    R(f"{Y}._cycleQty()")
    ok(R(f"{Y}._qty") == 1, 'quantité revient à ×1')
    # capsule fermée : UI d'origine
    R("(() => { const s = NEBUSTION.SymbioteManager.state(); s.capsuleOpened = false; })()")
    time.sleep(0.5)
    ok(R(f"{Y}._capsuleBtn.visible") and not R(f"{Y}._collectBtn.visible"), 'capsule fermée : bouton d\'ouverture affiché')
    R("(() => { NEBUSTION.SymbioteManager.state().capsuleOpened = true; })()")
    R(f"{Y}.scene.start('QGScene')")
    ok(wait_scene('QGScene'), 'retour au QG'); time.sleep(0.3)

    errs = [e for e in errs if 'Failed to load resource' not in e and 'favicon' not in e]
    ok(not errs, 'aucune erreur JS : ' + '; '.join(errs[:5]))
    b.close()
srv.shutdown()
print(('\n✔ ' if not failed else '\n✘ ') + 'Module 20 (navigateur) : %d réussis, %d échoués' % (passed, failed))
sys.exit(1 if failed else 0)
