/*
 * Test de fumée dans un vrai Chromium (Playwright) avec un FAUX Phaser (tests/mock-phaser.js).
 * Vérifie : chargeur index.html, ordre des scripts, dessin réel des textures (Canvas 2D), création des scènes,
 * HUD, gisements, drones, récolte, caisse, sauvegarde localStorage, rechargement, production hors ligne.
 *   NODE_PATH=$(npm root -g) node tests/browser-smoke.js
 */
const http = require('http'), fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const root = path.join(__dirname, '..');
const mock = fs.readFileSync(path.join(__dirname, 'mock-phaser.js'), 'utf8');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };

const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]);
  if (u === '/js/vendor/phaser.min.js') { res.writeHead(200, { 'Content-Type': 'text/javascript' }); return res.end(mock); }
  const f = path.join(root, u === '/' ? 'index.html' : u);
  if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('nf'); }
  res.writeHead(200, { 'Content-Type': mime[path.extname(f)] || 'application/octet-stream' }); res.end(fs.readFileSync(f));
});

let passed = 0, failed = 0;
const ok = (c, m) => { if (c) passed++; else { failed++; console.log('  ✗ ' + m); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  await new Promise(r => server.listen(8765, r));
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 780 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console.error: ' + m.text()); });
  const url = 'http://localhost:8765/index.html?debug=1';

  async function waitScene(key, ms) {
    const t0 = Date.now();
    while (Date.now() - t0 < (ms || 15000)) {
      if (await page.evaluate(k => !!(window.__NEBUSTION_GAME__ && window.__NEBUSTION_GAME__.scene.isActive(k)), key)) return true;
      await sleep(100);
    }
    return false;
  }
  const R = expr => page.evaluate(expr);

  console.log('# Chargement');
  await page.goto(url);
  ok(await waitScene('MainMenuScene'), 'MainMenuScene atteinte (Boot → Preload → Splash → Menu)');
  ok(errors.length === 0, 'aucune erreur au chargement : ' + errors.join(' | '));
  ok(await R('typeof NEBUSTION.Resources.get("crystal")') === 'number', 'économie initialisée');
  ok(await R('NEBUSTION.Resources.isNewGame') === true, 'nouvelle partie');
  ok(await R('Object.keys(__NEBUSTION_GAME__.textures._map).length') > 30, 'textures générées (Canvas 2D réel)');

  console.log('# HUD & production temps réel');
  const c0 = await R('NEBUSTION.Resources.get("crystal")');
  await sleep(2100);
  const c1 = await R('NEBUSTION.Resources.get("crystal")');
  const rate = await R('NEBUSTION.Resources.rate("crystal")');
  ok(Math.abs((c1 - c0) - rate * 2.1) < rate * 0.5, `cristaux +${(c1 - c0).toFixed(2)} en ~2.1 s (attendu ≈ ${(rate * 2.1).toFixed(2)})`);
  const hudTexts = await R(`(() => { const s = __NEBUSTION_GAME__.scenes.MainMenuScene; return Object.values(s.hud.cells).map(c => c.val.text + ' | ' + c.rate.text); })()`);
  ok(hudTexts.length === 5 && hudTexts.every(t => /^\d/.test(t) && /\/s|PLEIN/.test(t)), 'HUD affiche 5 ressources avec taux : ' + JSON.stringify(hudTexts));
  await R(`__NEBUSTION_GAME__.scenes.MainMenuScene.hud.togglePanel(true)`);
  await sleep(400);
  const panelTxt = await R(`(() => { const h = __NEBUSTION_GAME__.scenes.MainMenuScene.hud; return Object.values(h.rows).map(r => r.ps.text + ' ' + r.pm.text); })()`);
  ok(panelTxt.every(t => /\/s/.test(t) && /\/min/.test(t)), 'panneau : gains /s et /min : ' + JSON.stringify(panelTxt));
  await R(`__NEBUSTION_GAME__.scenes.MainMenuScene.hud.togglePanel(false)`);

  console.log('# Scène Nexus-01');
  await R(`__NEBUSTION_GAME__.scenes.MainMenuScene.scene.start('PlanetScene', {})`);
  ok(await waitScene('PlanetScene'), 'PlanetScene démarrée');
  await sleep(600);
  const info = await R(`(() => { const s = __NEBUSTION_GAME__.scenes.PlanetScene; return { nodes: Object.keys(s.nodes).length, drones: s.drones.length, hud: !!s.hud }; })()`);
  ok(info.nodes === 5 && info.drones === 5 && info.hud, 'gisements, drones et HUD créés : ' + JSON.stringify(info));

  // récolte via un vrai événement pointerdown sur la zone du gisement
  const before = await R('NEBUSTION.Resources.get("metal")');
  const gained = await R(`(() => { const s = __NEBUSTION_GAME__.scenes.PlanetScene; const n = s.nodes.metal; const b = NEBUSTION.Resources.get('metal');
    const created0 = Phaser._registry.created; n.zone.emit('pointerdown', {}); return { d: NEBUSTION.Resources.get('metal') - b, objs: Phaser._registry.created - created0 }; })()`);
  ok(gained.d >= 1.99, 'tap gisement de métal : +' + gained.d.toFixed(2));
  ok(gained.objs > 0, 'effets visuels créés à la récolte (' + gained.objs + ' objets)');
  const charges = await R('NEBUSTION.Resources.charges("metal", Date.now())');
  ok(charges < 7.2 && charges > 6.5, 'charge consommée : ' + charges.toFixed(2));
  for (let i = 0; i < 10; i++) await R(`__NEBUSTION_GAME__.scenes.PlanetScene.nodes.metal.zone.emit('pointerdown', {})`);
  ok(await R('NEBUSTION.Resources.charges("metal", Date.now())') < 1, 'réserve épuisée après spam');
  const okAfter = await R('NEBUSTION.Resources.get("metal") >= 0');
  ok(okAfter, 'stock jamais négatif');

  // drones : laisser vivre un cycle complet (≈ 10 s), vérifier livraison + laser + pas d'erreur
  console.log('# Drones (cycle complet ≈ 14 s)');
  await sleep(14500);
  const deliv = await R(`__NEBUSTION_GAME__.scenes.PlanetScene.drones.map(d => d.deliveries)`);
  ok(deliv.every(n => n >= 1), 'chaque drone a livré au moins une cargaison : ' + deliv.join(','));
  const dr = await R(`__NEBUSTION_GAME__.scenes.PlanetScene.drones.map(d => d.state)`);
  ok(dr.length === 5, 'drones toujours 5 (aucun doublon) : ' + dr.join(','));
  const emitted = await R(`Object.values(__NEBUSTION_GAME__.scenes.PlanetScene.fx.emitters).reduce((a, e) => a + e.emitted, 0)`);
  ok(emitted > 20, 'particules émises : ' + emitted);

  console.log('# Caisse de ravitaillement');
  await R(`NEBUSTION.Resources.state.stats.lastPod = 0; __NEBUSTION_GAME__.scenes.PlanetScene._podAt = 0;`);
  await sleep(2200);
  ok(await R('!!__NEBUSTION_GAME__.scenes.PlanetScene.pod'), 'caisse apparue');
  const podPending = await R(`(() => { const p = __NEBUSTION_GAME__.scenes.PlanetScene.pod; return p && p.landed; })()`);
  ok(podPending, 'caisse posée, cliquable');
  const snap = await R(`JSON.stringify(NEBUSTION.Resources.state.res)`);
  await R(`__NEBUSTION_GAME__.scenes.PlanetScene.pod.zone.emit('pointerdown', {})`);
  ok(await R('NEBUSTION.Resources.state.stats.pods') === 1, 'caisse réclamée une fois');
  await R(`(() => { const p = __NEBUSTION_GAME__.scenes.PlanetScene.pod; })()`);
  ok(await R('__NEBUSTION_GAME__.scenes.PlanetScene.pod') === null, 'caisse retirée après réclamation');
  await sleep(600);
  await R(`NEBUSTION.Resources.saveNow(Date.now())`);

  // expiration d'une caisse non réclamée
  await R(`NEBUSTION.Resources.state.stats.lastPod = 0; __NEBUSTION_GAME__.scenes.PlanetScene._podAt = 0;`);
  await sleep(2200);
  await R(`__NEBUSTION_GAME__.scenes.PlanetScene.pod.expireAt = Date.now() - 1;`);
  await sleep(300);
  ok(await R('__NEBUSTION_GAME__.scenes.PlanetScene.pod') === null && await R('NEBUSTION.Resources.state.stats.pods') === 1, 'caisse expirée : retirée sans récompense');

  console.log('# Sauvegarde / rechargement');
  const saved = await R('NEBUSTION.Resources.state.res.crystal');
  ok(await R('localStorage.getItem("nebustion_save_v2") !== null'), 'sauvegarde présente dans localStorage');
  await page.reload();
  ok(await waitScene('MainMenuScene'), 'redémarrage OK');
  const r2 = await R('({ crystal: NEBUSTION.Resources.get("crystal"), isNew: NEBUSTION.Resources.isNewGame, pods: NEBUSTION.Resources.state.stats.pods, sessions: NEBUSTION.Resources.state.stats.sessions })');
  ok(!r2.isNew && r2.crystal >= saved && r2.crystal < saved + 60 && r2.pods === 1 && r2.sessions === 2, 'progression restaurée : ' + JSON.stringify(r2) + ' (avant : ' + saved.toFixed(1) + ')');

  console.log('# Veille (visibilitychange) et hors ligne');
  await R(`Object.defineProperty(document, 'hidden', { value: true, configurable: true }); document.dispatchEvent(new Event('visibilitychange'));`);
  const seen = await R('JSON.parse(JSON.parse(localStorage.getItem("nebustion_save_v2")).d).lastSeen');
  ok(Math.abs(Date.now() - seen) < 3000, 'lastSeen enregistré à la mise en veille');
  await R(`Object.defineProperty(document, 'hidden', { value: false, configurable: true });`);

  // absence réelle de 2 h : on réécrit la sauvegarde avec lastSeen = maintenant - 2 h (avec somme de contrôle valide), puis on recharge
  await R(`(() => { const st = JSON.parse(JSON.stringify(NEBUSTION.Resources.state)); st.lastSeen = Date.now() - 7200000; NEBUSTION.Save.write(st, Date.now()); window.__before = st.res; })()`);
  const expectBefore = await R('window.__before');
  await page.evaluate(() => { window.removeEventListener('beforeunload', () => {}); });
  // empêche le flush de beforeunload d'écraser lastSeen : on neutralise saveNow avant de recharger
  await R('NEBUSTION.Resources.saveNow = function () { return true; }; NEBUSTION.Resources.tick = function () {};');
  await page.reload();
  ok(await waitScene('MainMenuScene'), 'redémarrage après « 2 h d\'absence »');
  await sleep(900);
  const off = await R(`(() => { const R = NEBUSTION.Resources; const s = __NEBUSTION_GAME__.scenes.MainMenuScene; return { pending: R.pendingReport, modal: s._display.filter(o => o.text && /BON RETOUR/.test(o.text)).length, crystal: R.get('crystal'), rate: R.rate('crystal'), stats: R.state.stats.offlineSec }; })()`);
  const expected = Math.min(expectBefore.crystal + off.rate * 7200 * 0.6, 15000);
  ok(off.pending === null && off.modal === 1, 'fenêtre « Bon retour » affichée une seule fois (' + off.modal + ')');
  ok(Math.abs(off.crystal - expected) < off.rate * 15 + 1, `cristaux après 2 h : ${off.crystal.toFixed(0)} (attendu ≈ ${expected.toFixed(0)})`);
  ok(Math.abs(off.stats - 7200) < 30, 'temps hors ligne cumulé ≈ 7200 s : ' + off.stats);
  await R(`(() => { const s = __NEBUSTION_GAME__.scenes.MainMenuScene; const b = s._display.filter(o => o.labelText && /CONTINUER/.test(o.labelText.text))[0]; b.onClick(); })()`);
  await sleep(500);
  ok(await R(`__NEBUSTION_GAME__.scenes.MainMenuScene._display.filter(o => o.text && /BON RETOUR/.test(o.text)).length`) === 0, 'fenêtre fermée');

  console.log('# Outil de test ?debug=1 et navigation');
  await R(`__NEBUSTION_GAME__.scenes.MainMenuScene.scene.start('PlaceholderScene', { navKey: 'galaxy', title: 'Galaxie' })`);
  ok(await waitScene('PlaceholderScene'), 'Galaxie (placeholder) OK');
  ok(await R(`!!__NEBUSTION_GAME__.scenes.PlaceholderScene.hud`), 'HUD présent sur toutes les scènes');
  await R(`__NEBUSTION_GAME__.scenes.PlaceholderScene.scene.start('PlanetScene', {})`);
  await waitScene('PlanetScene'); await sleep(300);
  await R(`__NEBUSTION_GAME__.scenes.PlanetScene.scene.start('MainMenuScene', {})`);
  await waitScene('MainMenuScene'); await sleep(300);
  const listeners = await R(`Object.values(NEBUSTION.Resources.listeners).map(l => l.length)`);
  ok(listeners.every(n => n <= 3), 'pas de fuite d\'écouteurs après plusieurs changements de scène : ' + JSON.stringify(listeners));
  const drones2 = await R(`(() => { __NEBUSTION_GAME__.scenes.MainMenuScene.scene.start('PlanetScene', {}); return 1; })()`);
  await waitScene('PlanetScene'); await sleep(300);
  ok(await R('__NEBUSTION_GAME__.scenes.PlanetScene.drones.length') === 5, 'retour sur la planète : toujours 5 drones');

  ok(errors.length === 0, 'aucune erreur JS pendant toute la session : ' + errors.join(' | '));
  await browser.close(); server.close();
  console.log('\n' + (failed === 0 ? '✔ TEST DE FUMÉE OK' : '✘ ' + failed + ' échec(s)') + ' (' + passed + ' vérifications)');
  process.exit(failed === 0 ? 0 : 1);
})().catch(async e => { console.error('ERREUR TEST :', e); process.exit(2); });
