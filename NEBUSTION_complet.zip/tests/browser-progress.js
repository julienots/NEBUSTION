/*
 * Test navigateur de l'ÉTAPE 10 : Expéditions, Événement, Prestige, Succès (Chromium/Playwright + FAUX Phaser, donc mise en page /
 * logique / entrées, PAS de WebGL). Vrai chemin joueur : menu → raccourci → scène → onglets → glisser → taps → confirmations → actions.
 * L'horloge du navigateur est décalée au 29/09/2026 midi (cycle d'événement ACTIF).
 * Lancer : NODE_PATH=$(npm root -g) node tests/browser-progress.js [dossier_captures]
 */
const http = require('http'), fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const root = path.join(__dirname, '..'), out = process.argv[2] || '/tmp/shots_progress';
fs.mkdirSync(out, { recursive: true });
const mock = fs.readFileSync(path.join(__dirname, 'mock-phaser.js'), 'utf8');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]);
  if (u === '/js/vendor/phaser.min.js') { res.writeHead(200, { 'Content-Type': 'text/javascript' }); return res.end(mock); }
  const f = path.join(root, u === '/' ? 'index.html' : u);
  if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('nf'); }
  res.writeHead(200, { 'Content-Type': mime[path.extname(f)] || 'application/octet-stream' }); res.end(fs.readFileSync(f));
});
let passed = 0, failed = 0;
const ok = (c, m) => { if (c) passed++; else { failed++; console.log('  ✗ ' + m); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const FAKE_NOW = new Date(2026, 8, 29, 12, 0, 0).getTime();

(async () => {
  await new Promise(r => server.listen(8772, r));
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 780 } });
  await ctx.addInitScript(`(() => { const o = Date.now.bind(Date), off = ${FAKE_NOW} - o(); Date.now = () => o() + off; })();`);
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console.error: ' + m.text()); });
  const R = e => page.evaluate(e);
  const S = k => `window.__NEBUSTION_GAME__.scenes.${k}`;
  async function waitScene(key, ms) {
    const t0 = Date.now();
    while (Date.now() - t0 < (ms || 15000)) { if (await R(`!!__NEBUSTION_GAME__.scene.isActive('${key}')`)) return true; await sleep(100); }
    return false;
  }
  async function shot(K, name) {
    const data = await R(`(() => { const c = document.createElement('canvas'); c.width = 720; c.height = 1280; Phaser._render(${S(K)}, c.getContext('2d'), 720, 1280); return c.toDataURL('image/png'); })()`);
    fs.writeFileSync(path.join(out, name + '.png'), Buffer.from(data.split(',')[1], 'base64'));
  }
  const zoneTap = (K, x, y) => R(`(() => { const s = ${S(K)}; const z = s._display.find(o => o._interactive && o.depth === 41); z.emit('pointerdown', {x:${x},y:${y}}); z.emit('pointerup', {x:${x},y:${y}}); })()`);
  const drag = (K, x, y0, y1) => R(`(() => { const s = ${S(K)}; const z = s._display.find(o => o._interactive && o.depth === 41); z.emit('pointerdown', {x:${x},y:${y0}}); s.input.emit('pointermove', {x:${x},y:${y1}}); z.emit('pointerup', {x:${x},y:${y1}}); s.input.emit('pointerup', {x:${x},y:${y1}}); })()`);
  const tapModal = (K, idx) => R(`(() => { const s = ${S(K)}; const h = s._modal.hits[${idx}]; s._modal.dim.emit('pointerup', {x: h.x + h.w/2, y: h.y + h.h/2}); })()`);
  const modalOpen = K => R(`!!${S(K)}._modal`);
  const closeModals = async K => { for (let i = 0; i < 4 && await modalOpen(K); i++) { await tapModal(K, 0); await sleep(500); } };
  const cardBtn = (K, n, hi) => R(`(() => { const s = ${S(K)}; const c = s._cards[${n}]; const h = c._hits[${hi || 0}];
    const view = s.listBottom - s.listTop; s.scrollY = Math.max(0, Math.min(s.maxScroll, c.y + h.y - view / 2)); s.listContainer.y = s.listTop - s.scrollY;
    return { x: 12 + h.x + h.w / 2, y: s.listContainer.y + c.y + h.y + h.h / 2 }; })()`);
  const tapCard = async (K, n, hi) => { const p = await cardBtn(K, n, hi); await zoneTap(K, p.x, p.y); await sleep(350); };
  const tabTap = (K, id) => R(`(() => { const s = ${S(K)}; const idx = s._tabDraw.findIndex(t => t.id === '${id}'); const zones = s.tabsBar.list.filter(o => o._interactive); zones[idx].emit('pointerup', {}); })()`);
  const nCards = K => R(`${S(K)}._cards.length`);
  const hubTo = async (from, to) => {
    await R(`(() => { const s = ${S(from)}; const idx = NEBUSTION.PROGRESS_HUB.findIndex(i => i.scene === '${to}'); s.hubC.list.filter(o => o._interactive)[idx].emit('pointerup', {}); })()`);
    return waitScene(to, 5000);
  };
  const noErr = m => ok(errors.length === 0, m + (errors.length ? ' : ' + errors.slice(0, 3).join(' | ') : ''));

  console.log('# Chargement + enregistrement des 4 scènes');
  await page.goto('http://localhost:8772/index.html?debug=1');
  ok(await waitScene('MainMenuScene'), 'MainMenuScene atteinte');
  for (const k of ['ExpeditionScene', 'EventScene', 'PrestigeScene', 'AchievementsScene']) ok(await R(`!!__NEBUSTION_GAME__.scenes.${k}`), k + ' enregistrée dans main.js (régression écran noir)');
  ok(await R(`NEBUSTION.EventManager.isActive() && NEBUSTION.EventManager.info().cycleIndex === 1`), 'horloge de test : événement actif (cycle 1)');
  await R(`(() => { const R = NEBUSTION.Resources, C = NEBUSTION.Combat;
    ['metal','core','crystal','energy','dust'].forEach(id => R.add(id, 8000, 'test'));
    const ss = {}; for (let i = 0; i < 9; i++) ss['t' + i] = 3; R.state.combat.stageStars = ss;
    NEBUSTION.Heroes.all().filter(h => !h.shop).slice(0, 8).forEach(h => { R.state.combat.fragments[h.id] = 8 * 39; });
    C.setTeam(NEBUSTION.Heroes.all().filter(h => !h.shop).slice(0, 5).map(h => h.id));
    R.state.buildings.command.level = 12; })()`);
  await sleep(300);
  noErr('aucune erreur au démarrage');

  console.log('# Menu principal : 2e rangée de raccourcis');
  const btns = await R(`(() => { const sc = __NEBUSTION_GAME__.scenes.MainMenuScene; return sc._display.filter(o => o instanceof NEBUSTION.Button).map(b => ({ x: Math.round(b.x), y: Math.round(b.y), c: b.accentColor })); })()`);
  const row2 = btns.filter(b => b.y > 1050).sort((a, b) => a.x - b.x), row1 = btns.filter(b => b.y > 900 && b.y <= 1050);
  ok(row2.length === 4 && row1.length === 4, 'deux rangées de 4 raccourcis (' + row1.length + ' + ' + row2.length + ')');
  ok(new Set(row2.map(b => b.x)).size === 4 && row2.every(b => b.y <= 1280 - 116), 'rangée 2 dans l\'écran, hors barre de navigation');
  const tapShortcut = idx => R(`(() => { const sc = __NEBUSTION_GAME__.scenes.MainMenuScene; const bs = sc._display.filter(o => o instanceof NEBUSTION.Button && o.y > 1050).sort((a, b) => a.x - b.x); bs[${idx}].emit('pointerdown', {}); bs[${idx}].emit('pointerup', {}); })()`);
  await tapShortcut(0);
  ok(await waitScene('ExpeditionScene', 6000), 'raccourci « Expéditions » ouvre ExpeditionScene');
  await sleep(500);
  noErr('aucune erreur à l\'ouverture d\'Expéditions');

  console.log('# EXPÉDITIONS');
  ok(await R(`${S('ExpeditionScene')}.tab`) === 'active' && (await nCards('ExpeditionScene')) >= 1, 'onglet « En cours » : carte d\'état vide affichée');
  await shot('ExpeditionScene', '1_exp_encours');
  await tabTap('ExpeditionScene', 'missions'); await sleep(450);
  ok(await R(`${S('ExpeditionScene')}.tab`) === 'missions' && (await nCards('ExpeditionScene')) >= 20, 'onglet « Missions » : ' + await nCards('ExpeditionScene') + ' cartes');
  await shot('ExpeditionScene', '2_exp_missions');
  await R(`(() => { const s = ${S('ExpeditionScene')}; s.scrollY = 0; s.listContainer.y = s.listTop; })()`);
  await drag('ExpeditionScene', 360, 700, 350);
  ok(await R(`${S('ExpeditionScene')}.scrollY`) > 200, 'le glissement fait défiler la liste');
  ok(!(await modalOpen('ExpeditionScene')) && await R(`!${S('ExpeditionScene')}.prep`), 'un glissement ne lance rien (ni prépa, ni fenêtre)');
  await R(`(() => { const s = ${S('ExpeditionScene')}; s.scrollY = 0; s.listContainer.y = s.listTop; })()`);
  await tapCard('ExpeditionScene', 0, 1);   // puce « Facile »
  ok(await R(`${S('ExpeditionScene')}.missionFilter`) === 'facile' && (await nCards('ExpeditionScene')) === 5, 'filtre « Facile » : 1 filtre + 4 missions');
  await tapCard('ExpeditionScene', 1, 0);   // Éclair facile → PRÉPARER
  ok(await R(`!!${S('ExpeditionScene')}.prep && ${S('ExpeditionScene')}.prep.missionId === 'm_eclair_facile'`), 'PRÉPARER ouvre l\'écran de préparation de la mission Éclair');
  await shot('ExpeditionScene', '3_exp_preparation');
  const bar = () => R(`${S('ExpeditionScene')}._prepBar.list.filter(o => o._interactive).length`);
  ok(await bar() === 2, 'barre d\'action : AUTO + LANCER');
  await R(`${S('ExpeditionScene')}._prepBar.list.filter(o => o._interactive)[1].emit('pointerup', {})`); await sleep(300);
  ok(await R(`!!${S('ExpeditionScene')}.prep`) && await R(`NEBUSTION.ExpeditionManager.usedSlots() === 0 && Object.keys(NEBUSTION.Resources.state.expeditions.cooldowns).length === 0`), 'LANCER sans héros : rien n\'est envoyé');
  await R(`${S('ExpeditionScene')}._prepBar.list.filter(o => o._interactive)[0].emit('pointerup', {})`); await sleep(300);
  ok(await R(`${S('ExpeditionScene')}.prep.heroIds.length === 1`), 'AUTO choisit 1 héros pour l\'Éclair');
  const cry0 = await R(`NEBUSTION.Resources.state.res.crystal`);
  await R(`${S('ExpeditionScene')}._prepBar.list.filter(o => o._interactive)[1].emit('pointerup', {})`); await sleep(600);
  ok(await R(`${S('ExpeditionScene')}.prep === null`), 'LANCER quitte la préparation');
  ok(await modalOpen('ExpeditionScene'), 'Éclair : fenêtre de récompense affichée tout de suite');
  await shot('ExpeditionScene', '4_exp_eclair_recompense');
  await closeModals('ExpeditionScene');
  ok(!(await modalOpen('ExpeditionScene')) && (await R(`NEBUSTION.Resources.state.res.crystal`)) > cry0 - 1, 'récompense Éclair créditée, fenêtre fermée');
  ok(await R(`NEBUSTION.ExpeditionManager.cooldownLeft('m_eclair_facile') > 0`), 'la recharge de l\'Éclair est enclenchée');
  await tabTap('ExpeditionScene', 'missions'); await sleep(400);
  await R(`(() => { const s = ${S('ExpeditionScene')}; s.missionFilter = 'facile'; s._render(false); })()`); await sleep(300);
  await tapCard('ExpeditionScene', 2, 0);   // Courte facile → PRÉPARER
  ok(await R(`!!${S('ExpeditionScene')}.prep && ${S('ExpeditionScene')}.prep.missionId === 'm_courte_facile'`), 'préparation de la mission Courte');
  await R(`${S('ExpeditionScene')}._prepBar.list.filter(o => o._interactive)[0].emit('pointerup', {})`); await sleep(300);
  await R(`${S('ExpeditionScene')}._prepBar.list.filter(o => o._interactive)[1].emit('pointerup', {})`); await sleep(600);
  ok(await R(`NEBUSTION.ExpeditionManager.usedSlots() === 1`) && await R(`${S('ExpeditionScene')}.tab`) === 'active', 'expédition envoyée : 1 emplacement, retour sur « En cours »');
  const busy = await R(`Object.keys(NEBUSTION.ExpeditionManager.busyHeroIds()).length`);
  ok(busy >= 1, 'héros envoyés marqués occupés (' + busy + ')');
  await shot('ExpeditionScene', '5_exp_en_cours_carte');
  await closeModals('ExpeditionScene');
  // Terminer l'expédition (dates absolues) puis « Tout réclamer »
  await R(`(() => { const a = NEBUSTION.Resources.state.expeditions.active[0]; a.endsAt = Date.now() - 1000; ${S('ExpeditionScene')}._refreshAll(false); })()`); await sleep(400);
  ok(await R(`NEBUSTION.ExpeditionManager.readyCount() === 1`), 'expédition terminée (prête à être réclamée)');
  await tapCard('ExpeditionScene', 0, 0); await sleep(300);   // carte « Tout réclamer » en tête (piège du footer)
  ok(await R(`NEBUSTION.ExpeditionManager.usedSlots() === 0 && NEBUSTION.ExpeditionManager.stats().completed >= 2`), '« Tout réclamer » (carte cliquable) libère l\'emplacement');
  await closeModals('ExpeditionScene');
  noErr('aucune erreur (Expéditions)');

  console.log('# ÉVÉNEMENT');
  ok(await hubTo('ExpeditionScene', 'EventScene'), 'barre des 4 sections : Expéditions → Événement');
  await sleep(500);
  ok(await R(`${S('EventScene')}.tab`) === 'boss' && (await nCards('EventScene')) >= 2, 'onglet Boss : cartes affichées');
  await shot('EventScene', '6_event_boss');
  const hp0 = await R(`NEBUSTION.EventManager.bossStatus().hp`), att0 = await R(`NEBUSTION.EventManager.attemptsLeft()`);
  await tapCard('EventScene', 1, 0); await sleep(300);
  ok((await R(`NEBUSTION.EventManager.bossStatus().hp`)) < hp0 && (await R(`NEBUSTION.EventManager.attemptsLeft()`)) === att0 - 1, 'ATTAQUER : PV du boss en baisse, tentative consommée');
  await closeModals('EventScene');
  await tabTap('EventScene', 'missions'); await sleep(450);
  ok(await R(`${S('EventScene')}.tab`) === 'missions' && (await nCards('EventScene')) >= 5, 'onglet Missions : ' + await nCards('EventScene') + ' cartes');
  await shot('EventScene', '7_event_missions');
  await R(`(() => { const s = ${S('EventScene')}; s.scrollY = 0; s.listContainer.y = s.listTop; })()`);
  await tabTap('EventScene', 'shop'); await sleep(450);
  ok(await R(`${S('EventScene')}.tab`) === 'shop' && (await nCards('EventScene')) >= 5, 'onglet Boutique : ' + await nCards('EventScene') + ' cartes');
  await R(`NEBUSTION.Resources.state.events.currency = 500; ${S('EventScene')}._refreshAll(false)`); await sleep(400);
  const gems0 = await R(`NEBUSTION.ShopManager.gems()`);
  await tapCard('EventScene', 1, 0); await sleep(250);
  ok(await modalOpen('EventScene'), 'ACHETER ouvre la confirmation');
  ok(await R(`NEBUSTION.EventManager.currency()`) === 500, 'rien n\'est débité avant confirmation');
  await tapModal('EventScene', 0); await sleep(300);
  ok(!(await modalOpen('EventScene')) && await R(`NEBUSTION.EventManager.currency()`) === 500, 'Annuler : aucun achat');
  await tapCard('EventScene', 1, 0); await sleep(250); await tapModal('EventScene', 1); await sleep(500);
  ok(await R(`NEBUSTION.EventManager.currency()`) < 500, 'Confirmer : monnaie débitée, article reçu');
  await closeModals('EventScene');
  await shot('EventScene', '8_event_boutique');
  noErr('aucune erreur (Événement)');

  console.log('# PRESTIGE');
  ok(await hubTo('EventScene', 'PrestigeScene'), 'barre des 4 sections : Événement → Prestige');
  await sleep(500);
  ok(await R(`${S('PrestigeScene')}.tab`) === 'rebirth' && (await nCards('PrestigeScene')) >= 3, 'onglet Renaissance : cartes affichées');
  ok(await R(`NEBUSTION.PrestigeManager.canPrestige().ok`), 'objectifs de Renaissance atteints (Commandement 12, 27 étoiles)');
  await shot('PrestigeScene', '9_prestige_renaissance');
  const last = (await nCards('PrestigeScene')) - 1;
  await tapCard('PrestigeScene', last, 0); await sleep(300);
  ok(await modalOpen('PrestigeScene'), 'RENAÎTRE MAINTENANT ouvre la confirmation forte');
  await shot('PrestigeScene', '10_prestige_confirmation');
  ok(await R(`NEBUSTION.PrestigeManager.count() === 0`), 'rien n\'est réinitialisé avant confirmation');
  await tapModal('PrestigeScene', 0); await sleep(300);
  ok(!(await modalOpen('PrestigeScene')) && await R(`NEBUSTION.PrestigeManager.count() === 0 && NEBUSTION.Resources.state.buildings.command.level === 12`), 'Annuler : rien ne change');
  await tapCard('PrestigeScene', last, 0); await sleep(300); await tapModal('PrestigeScene', 1); await sleep(700);
  ok(await R(`NEBUSTION.PrestigeManager.count() === 1 && NEBUSTION.PrestigeManager.relics() >= 1`), 'Confirmer : Renaissance accomplie, reliques créditées');
  ok(await R(`NEBUSTION.Resources.state.buildings.command.level < 12 && NEBUSTION.ExpeditionManager.totalStars() === 0`), 'bâtiments et étoiles réinitialisés');
  ok(await R(`NEBUSTION.Combat.heroLevel(NEBUSTION.Heroes.all().filter(h => !h.shop)[0].id) === 40`), 'niveaux de héros conservés');
  await shot('PrestigeScene', '11_prestige_resultat');
  await closeModals('PrestigeScene');
  await tabTap('PrestigeScene', 'tree'); await sleep(450);
  ok(await R(`${S('PrestigeScene')}.tab`) === 'tree' && (await nCards('PrestigeScene')) >= 6, 'onglet Arbre : en-tête + 5 nœuds (' + await nCards('PrestigeScene') + ')');
  await R(`NEBUSTION.Resources.state.prestige.relics += 50; ${S('PrestigeScene')}._refreshAll(false)`); await sleep(400);
  const rel0 = await R(`NEBUSTION.PrestigeManager.relics()`);
  await tapCard('PrestigeScene', 1, 0); await sleep(400);
  ok(await R(`NEBUSTION.PrestigeManager.nodeLevel('production') === 1 && NEBUSTION.PrestigeManager.relics() < ${rel0}`), 'achat d\'un nœud de l\'arbre : niveau +1, reliques dépensées');
  await closeModals('PrestigeScene');
  await shot('PrestigeScene', '12_prestige_arbre');
  await tabTap('PrestigeScene', 'tiers'); await sleep(450);
  ok(await R(`${S('PrestigeScene')}.tab`) === 'tiers' && (await nCards('PrestigeScene')) >= 1, 'onglet Paliers affiché');
  await shot('PrestigeScene', '13_prestige_paliers');
  noErr('aucune erreur (Prestige)');

  console.log('# SUCCÈS');
  ok(await hubTo('PrestigeScene', 'AchievementsScene'), 'barre des 4 sections : Prestige → Succès');
  await sleep(500);
  ok(await R(`${S('AchievementsScene')}.tab`) === 'daily' && (await nCards('AchievementsScene')) >= 2, 'onglet Quotidien : en-tête + calendrier');
  await shot('AchievementsScene', '14_succes_quotidien');
  const g1 = await R(`NEBUSTION.ShopManager.gems()`), dust1 = await R(`NEBUSTION.Resources.state.res.dust`);
  await tapCard('AchievementsScene', 0, 0); await sleep(500);
  ok(await R(`NEBUSTION.AchievementsManager.dailyStatus().streak === 1 && !NEBUSTION.AchievementsManager.dailyStatus().available`), 'RÉCLAMER : série = 1, récompense du jour prise');
  ok(await modalOpen('AchievementsScene'), 'fenêtre de récompense quotidienne');
  await closeModals('AchievementsScene');
  ok(await R(`NEBUSTION.Resources.state.res.dust`) >= dust1, 'poussière créditée (jour 1)');
  await tabTap('AchievementsScene', 'achv'); await sleep(450);
  ok(await R(`${S('AchievementsScene')}.tab`) === 'achv' && (await nCards('AchievementsScene')) >= 5, 'onglet Succès : ' + await nCards('AchievementsScene') + ' cartes');
  await R(`NEBUSTION.Resources.state.combat.battlesWon = 60; ${S('AchievementsScene')}._refreshAll(false)`); await sleep(400);
  const claimedBefore = await R(`Object.keys(NEBUSTION.Resources.state.achievements.claimed).length`);
  const idx = await R(`${S('AchievementsScene')}._cards.findIndex(c => c._hits && c._hits.length && c._hits[0].fn && c._hits[0].btn && c._hits[0].btn.enabled !== false)`);
  const target = idx >= 0 ? idx : 1;
  const claimable = await R(`NEBUSTION.AchievementsManager.claimableCount()`);
  ok(claimable >= 1, 'au moins un succès réclamable (' + claimable + ')');
  await R(`(() => { const s = ${S('AchievementsScene')}; const first = NEBUSTION.AchievementsManager.list('succes').findIndex(a => a.claimable); s.__firstClaimable = first; })()`);
  const ci = await R(`${S('AchievementsScene')}.__firstClaimable`);
  await tapCard('AchievementsScene', ci, 0); await sleep(500);
  ok((await R(`Object.keys(NEBUSTION.Resources.state.achievements.claimed).length`)) >= claimedBefore + 1 || await R(`NEBUSTION.AchievementsManager.list('succes').some(a => a.claimed >= 1)`), 'réclamation d\'un palier de succès');
  await closeModals('AchievementsScene');
  await shot('AchievementsScene', '15_succes_liste');
  await tabTap('AchievementsScene', 'goals'); await sleep(450);
  ok(await R(`${S('AchievementsScene')}.tab`) === 'goals' && (await nCards('AchievementsScene')) >= 4, 'onglet Long terme : ' + await nCards('AchievementsScene') + ' cartes');
  await shot('AchievementsScene', '16_succes_longterme');
  noErr('aucune erreur (Succès)');

  console.log('# Interdictions : héros en expédition indisponibles pour le Combat');
  await R(`(() => { const R = NEBUSTION.Resources; const ids = NEBUSTION.Combat.getTeam(); R.state.combat.stageStars = {}; for (let i = 0; i < 9; i++) R.state.combat.stageStars['t' + i] = 3; NEBUSTION.ExpeditionManager.launch('m_courte_facile', [ids[0]], Date.now()); })()`);
  ok(await R(`NEBUSTION.ExpeditionManager.busyTeamMembers().length === 1`), 'un membre de l\'équipe est en expédition');
  await R(`__NEBUSTION_GAME__.scenes.AchievementsScene.scene.start('CombatPrepScene', { navKey: 'combat', title: 'Combat' })`);
  ok(await waitScene('CombatPrepScene', 6000), 'CombatPrepScene s\'ouvre');
  await sleep(600);
  ok(await R(`(() => { const s = ${S('CombatPrepScene')}; return typeof s._canLaunch === 'function' ? !s._canLaunch() : true; })()`), 'lancement du combat refusé tant qu\'un membre de l\'équipe est occupé');
  noErr('aucune erreur (Combat / héros occupés)');

  await browser.close(); server.close();
  console.log('\n' + (failed ? '✘ ' : '✔ ') + 'TEST NAVIGATEUR ÉTAPE 10 : ' + passed + ' réussis, ' + failed + ' échoués — captures dans ' + out);
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
