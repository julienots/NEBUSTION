/* Tests du CHANTIER de construction (module 28 : Observatoire, Balise, Arsenal, Citadelle), Node, sans Phaser.
 * Lancer : node tests/qgGridConstruction.test.js */
'use strict';
const E = require('./progress-env');
const t = E.makeCounter(), ok = t.ok, section = t.section;
const G = NEBUSTION.QGGrid, GM = NEBUSTION.QGGridManager;

const NEW_IDS = ['observatory', 'beacon', 'arsenal', 'citadel'];

section('Catalogue (données pures)');
{
  NEW_IDS.forEach((sid) => {
    const def = G.STRUCTURES[sid];
    ok(!!def, sid + ' existe dans le catalogue');
    ok(def.buildTimeSec > 0, sid + ' a un temps de construction > 0');
    ok(typeof def.desc(2) === 'string' && def.desc(2).length > 0, sid + ' a un texte d\'effet');
  });
  ok(G.STRUCTURE_ORDER.indexOf('citadel') === G.STRUCTURE_ORDER.length - 1, 'les nouveaux bâtiments sont ajoutés à la fin de STRUCTURE_ORDER');
  // Les 12 bâtiments d'origine restent SANS buildTimeSec (rétrocompatibilité : pose instantanée inchangée).
  ['generator', 'silo', 'turret', 'wall', 'barracks', 'workshop', 'lab', 'radar', 'refinery', 'vault', 'commandpost', 'blackmarket'].forEach((sid) => {
    ok(!G.STRUCTURES[sid].buildTimeSec, sid + ' reste instantané (pas de buildTimeSec)');
  });
}

section('build() sur un bâtiment à chantier : pas de pose instantanée');
{
  const g = E.freshGame(), R = g.R;
  const cost = GM.buildCost('observatory');
  Object.keys(cost).forEach((id) => { R.state.res[id] = cost[id] + 1000; });
  const before = {}; Object.keys(cost).forEach((id) => { before[id] = R.get(id); });

  const res = GM.build(2, 2, 'observatory');
  ok(res.ok && res.buildTimeSec === G.STRUCTURES.observatory.buildTimeSec, 'build() accepte le chantier et renvoie sa durée');
  ok(!GM.structureAt(2, 2), 'la structure n\'est PAS active immédiatement');
  ok(GM.isPending(2, 2), 'la parcelle est bien en chantier');
  ok(GM.bonusValue('offlineEff') === 0, 'aucun bonus tant que le chantier n\'est pas terminé');
  Object.keys(cost).forEach((id) => { ok(R.get(id) === before[id] - cost[id], 'le coût est payé immédiatement pour ' + id); });

  ok(!GM.canBuild(2, 2, 'beacon'), 'impossible de construire sur une parcelle déjà en chantier');
  const again = GM.build(2, 2, 'beacon');
  ok(!again.ok && again.reason === 'occupied', 'build() refuse une 2e structure sur une parcelle en chantier');
}

section('tick() : la structure devient active une fois le temps écoulé');
{
  const g = E.freshGame(), R = g.R;
  const t0 = E.local(2026, 0, 1, 10);
  E.setNow(t0);
  const cost = GM.buildCost('beacon');
  Object.keys(cost).forEach((id) => { R.state.res[id] = cost[id] + 1000; });
  GM.build(3, 3, 'beacon');

  ok(GM.tick().length === 0, 'tick() ne fait rien avant la fin du chantier');
  ok(GM.remainingMs(3, 3) > 0, 'il reste du temps avant la fin');

  E.setNow(t0 + (G.STRUCTURES.beacon.buildTimeSec - 1) * 1000);
  ok(GM.tick().length === 0, 'tick() ne fait toujours rien juste avant la fin');

  E.setNow(t0 + G.STRUCTURES.beacon.buildTimeSec * 1000 + 500);
  const done = GM.tick();
  ok(done.length === 1 && done[0].id === 'beacon', 'tick() termine le chantier au bon moment');
  ok(GM.structureAt(3, 3) === 'beacon', 'la Balise est maintenant active');
  ok(!GM.isPending(3, 3), 'la parcelle n\'est plus en chantier');
  ok(GM.bonusValue('podRate') > 0, 'le bonus de la Balise est bien compté une fois active');

  E.setNow(null);
}

section('Annulation de chantier : remboursement à 50 %');
{
  const g = E.freshGame(), R = g.R;
  const cost = GM.buildCost('arsenal');
  Object.keys(cost).forEach((id) => { R.state.res[id] = cost[id] + 1000; });
  const afterPay = {}; 
  GM.build(2, 3, 'arsenal');
  Object.keys(cost).forEach((id) => { afterPay[id] = R.get(id); });

  ok(GM.isPending(2, 3), 'chantier en cours avant annulation');
  const res = GM.cancelBuild(2, 3);
  ok(res.ok, 'annulation acceptée');
  ok(!GM.isPending(2, 3) && !GM.structureAt(2, 3), 'la parcelle redevient libre après annulation');
  Object.keys(res.refund).forEach((id) => {
    ok(R.get(id) === afterPay[id] + res.refund[id], 'remboursement crédité exactement pour ' + id);
    ok(res.refund[id] === Math.floor(cost[id] * 0.5), 'remboursement = 50 % du coût payé pour ' + id);
  });

  const empty = GM.cancelBuild(2, 3);
  ok(!empty.ok && empty.reason === 'empty', 'annuler une parcelle déjà libre échoue proprement');
}

section('Plafond (maxCount) : compte les chantiers ET les structures actives');
{
  const g = E.freshGame(), R = g.R;
  const def = G.STRUCTURES.citadel;
  const cells = ['2,2', '3,2', '2,3', '3,3'];
  let built = 0;
  cells.forEach((k, i) => {
    if (i >= def.maxCount) return;
    const p = G.parseKey(k);
    const cost = GM.buildCost('citadel');
    Object.keys(cost).forEach((id) => { R.state.res[id] = cost[id] + 1000; });
    const r = GM.build(p.x, p.y, 'citadel');
    if (r.ok) built++;
  });
  ok(built === Math.min(def.maxCount, cells.length), 'tous les chantiers autorisés par maxCount ont pu être lancés');
  ok((GM.counts().citadel || 0) + (GM.countsPending().citadel || 0) <= def.maxCount, 'chantiers + actifs ne dépassent jamais maxCount');
}

section('Sauvegarde (SaveManager.normalize) : chantiers valides conservés, corrompus rejetés');
{
  const now = E.local(2026, 0, 1, 10);
  const valid = {
    qgGrid: {
      unlocked: { '2,2': true },
      cells: {},
      building: { '2,2': { id: 'observatory', start: now - 60000, end: now + 60000 } }
    }
  };
  const norm = NEBUSTION.Save.normalize(valid, now);
  ok(!!norm.qgGrid.building['2,2'], 'normalize() conserve un chantier valide (start/end cohérents)');
  ok(norm.qgGrid.building['2,2'].id === 'observatory', 'normalize() conserve le bon type de structure');

  const bogusCases = {
    qgGrid: {
      unlocked: { '2,2': true, '3,2': true, '2,3': true },
      cells: {},
      building: {
        '2,2': { id: 'not_a_structure', start: now - 1000, end: now + 60000 },     // structure inconnue
        '3,2': { id: 'observatory', start: now + 999999, end: now + 1999999 },      // démarre dans le futur
        '2,3': { id: 'observatory', start: now, end: now + 999 * 3600 * 1000 }      // durée absurde (garde-fou MAX_BUILD_MS)
      }
    }
  };
  const normBogus = NEBUSTION.Save.normalize(bogusCases, now);
  ok(Object.keys(normBogus.qgGrid.building).length === 0, 'normalize() rejette tous les chantiers corrompus/manipulés');

  const noBuildingField = NEBUSTION.Save.normalize({ qgGrid: { unlocked: {}, cells: {} } }, now);
  ok(typeof noBuildingField.qgGrid.building === 'object', 'sauvegarde sans champ `building` → objet vide (rétrocompatible)');
  ok(Object.keys(noBuildingField.qgGrid.building).length === 0, 'objet `building` vide par défaut');

  // Un chantier ET une structure active ne peuvent pas coexister sur la même parcelle après normalisation.
  const clash = {
    qgGrid: {
      unlocked: { '2,2': true },
      cells: { '2,2': 'generator' },
      building: { '2,2': { id: 'observatory', start: now - 1000, end: now + 60000 } }
    }
  };
  const normClash = NEBUSTION.Save.normalize(clash, now);
  ok(normClash.qgGrid.cells['2,2'] === 'generator' && !normClash.qgGrid.building['2,2'], 'la structure active est prioritaire, le chantier fantôme est ignoré');
}

t.done('Chantiers de construction du QG (module 28)');
