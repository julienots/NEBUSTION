/*
 * Test de fumée Chromium : illustrations d'ennemis optionnelles (assets/enemies/<id>.png).
 * Vérifie la mise en forme (réduction à la texture, centrage, proportions conservées), le repli sans image,
 * et que le démarrage du jeu n'est pas bloqué quand les fichiers sont absents.
 *   NODE_PATH=$(npm root -g) node tests/browser-enemy-images.js
 */
const http = require('http'), fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const root = path.join(__dirname, '..');
const mock = fs.readFileSync(path.join(__dirname, 'mock-phaser.js'), 'utf8');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]);
  if (u === '/js/vendor/phaser.min.js') { res.writeHead(200, { 'Content-Type': 'text/javascript' }); return res.end(mock); }
  const f = path.join(root, u === '/' ? 'index.html' : u);
  if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('nf'); }
  res.writeHead(200, { 'Content-Type': mime[path.extname(f)] || 'application/octet-stream' }); res.end(fs.readFileSync(f));
});
let passed = 0, failed = 0;
const ok = (c, m) => { if (c) passed++; else { failed++; console.log('  ✗ ' + m); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  await new Promise(r => server.listen(8768, r));
  const browser = await chromium.launch();
  const page = await (await browser.newContext({ viewport: { width: 390, height: 780 } })).newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  await page.goto('http://localhost:8768/');
  await page.waitForFunction(() => window.__NEBUSTION_GAME__ && window.__NEBUSTION_GAME__.scene && window.__NEBUSTION_GAME__.scene.isActive('MainMenuScene'), null, { timeout: 15000 }).catch(() => {});
  await sleep(300);

  ok(await page.evaluate(() => window.__NEBUSTION_GAME__.scene.isActive('MainMenuScene') || window.__NEBUSTION_GAME__.scene.isActive('SplashScene')), 'le jeu démarre malgré l\'absence de assets/enemies/*.png');
  const files = await page.evaluate(() => NEBUSTION.EnemyTextures.imageIds().map(id => NEBUSTION.EnemyTextures.imageFile(id)));
  ok(files.length === 13 && files.indexOf('assets/enemies/drone_sentinel.png') >= 0 && files.indexOf('assets/enemies/omega_krell.png') >= 0, '13 fichiers attendus (10 ennemis + 3 boss)');

  const r = await page.evaluate(() => {
    const ET = NEBUSTION.EnemyTextures, out = {};
    // Fausse scène : textures canvas réelles + image source 400x200 (non carrée) unie rouge
    const map = {};
    const scene = { textures: {
      exists: k => !!map[k], remove: k => { delete map[k]; },
      get: k => map[k],
      createCanvas: (k, w, h) => { const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
        map[k] = { width: w, height: h, context: cv.getContext('2d'), canvas: cv, refresh() { this.refreshed = true; }, getSourceImage() { return cv; } }; return map[k]; }
    } };
    const mk = (id, size) => { const t = scene.textures.createCanvas('tex_enemy_' + id, size, size); t.context.fillStyle = '#00ff00'; t.context.fillRect(0, 0, size, size); return t; };
    const srcTex = scene.textures.createCanvas('img_enemy_x', 400, 200); srcTex.context.fillStyle = '#ff0000'; srcTex.context.fillRect(0, 0, 400, 200);
    const t = mk('x', 200), b = mk('bx', 340);
    ET._applyImage(scene, 'x', 'img_enemy_x'); ET._applyImage(scene, 'bx', 'img_enemy_x');
    const px = (tex, x, y) => Array.from(tex.context.getImageData(x, y, 1, 1).data);
    out.tSize = [t.width, t.height]; out.bSize = [b.width, b.height];
    out.tCenter = px(t, 100, 100); out.tTopBand = px(t, 100, 10); out.tBotBand = px(t, 100, 190);   // bandes transparentes (image 2:1 dans un carré)
    out.tCornerL = px(t, 2, 100); out.tRefreshed = !!t.refreshed;
    out.bCenter = px(b, 170, 170); out.bTop = px(b, 170, 20);
    // Aucune image chargée : loadImages appelle onDone et ne touche à rien
    let done = 0; const s2 = { textures: { exists: () => false, remove() {}, get() {} }, load: { image() {}, on() {}, off() {}, once(e, f) { this._c = f; }, start() { setTimeout(() => { this._c && this._c(); }, 0); } }, time: { delayedCall() {} } };
    ET.loadImages(s2, () => done++);
    return new Promise(res => setTimeout(() => { out.done = done; res(out); }, 50));
  });
  ok(r.tSize[0] === 200 && r.tSize[1] === 200 && r.bSize[0] === 340, 'la texture garde sa taille (200 ennemi / 340 boss)');
  ok(r.tCenter[0] === 255 && r.tCenter[1] === 0 && r.tCenter[3] === 255, 'image dessinée au centre (rouge)');
  ok(r.tTopBand[3] === 0 && r.tBotBand[3] === 0, 'proportions conservées : bandes transparentes haut/bas (pas de déformation)');
  ok(r.tCornerL[0] === 255 && r.tCornerL[3] === 255, 'image pleine largeur, redimensionnée à la résolution de la texture');
  ok(r.tRefreshed, 'texture rafraîchie');
  ok(r.bCenter[0] === 255 && r.bTop[3] === 0, 'boss : même mise en forme à 340x340');
  ok(r.done === 1, 'loadImages appelle onDone exactement une fois');


  // Vraies images livrées : présentes, carrées, ≤ 512, coins transparents, sujet non vide, et mise en forme sur la vraie image
  const real = await page.evaluate(async () => {
    const ET = NEBUSTION.EnemyTextures, out = [];
    for (const id of ET.imageIds()) {
      const img = new Image(); img.src = ET.imageFile(id);
      try { await img.decode(); } catch (e) { out.push({ id, err: true }); continue; }
      const cv = document.createElement('canvas'); cv.width = img.naturalWidth; cv.height = img.naturalHeight;
      const c = cv.getContext('2d'); c.drawImage(img, 0, 0);
      const w = cv.width, h = cv.height, d = c.getImageData(0, 0, w, h).data;
      let opaque = 0; for (let i = 3; i < d.length; i += 4) if (d[i] > 128) opaque++;
      const corner = [d[3], d[(w - 1) * 4 + 3], d[((h - 1) * w) * 4 + 3], d[((h * w) - 1) * 4 + 3]];
      // mise en forme dans une texture 200x200
      const tex = document.createElement('canvas'); tex.width = 200; tex.height = 200;
      const scene = { textures: { get: k => k === 'tex_enemy_' + id ? { width: 200, context: tex.getContext('2d'), getSourceImage() { return tex; }, refresh() {} } : { getSourceImage() { return img; } } } };
      ET._applyImage(scene, id, 'img_' + id);
      const td = tex.getContext('2d').getImageData(0, 0, 200, 200).data; let tOpaque = 0; for (let i = 3; i < td.length; i += 4) if (td[i] > 128) tOpaque++;
      out.push({ id, w, h, opaque: opaque / (w * h), corner, tOpaque: tOpaque / 40000 });
    }
    return out;
  });
  ok(real.length === 13, '13 illustrations chargées');
  real.forEach(r => {
    ok(!r.err, r.id + ' : image lisible');
    if (r.err) return;
    ok(r.w === r.h && r.w >= 256 && r.w <= 512, r.id + ' : carrée 256-512 (' + r.w + 'x' + r.h + ')');
    ok(r.corner.every(a => a === 0), r.id + ' : coins transparents (aucun fond ni voisin)');
    ok(r.opaque > 0.1 && r.tOpaque > 0.1, r.id + ' : sujet visible après mise en forme (' + Math.round(r.tOpaque * 100) + '%)');
  });


  // Régression « boss coupé » : les textures réellement générées par le jeu (boss = contexte déjà mis à l'échelle x1,7)
  // doivent recevoir l'image ENTIÈRE : anneau de 2 px au bord entièrement transparent, pour les 13 images.
  const full = await page.evaluate(async () => {
    const ET = NEBUSTION.EnemyTextures, T = window.__NEBUSTION_GAME__.textures, out = [];
    for (const id of ET.imageIds()) {
      const t = T._map['tex_enemy_' + id];
      const img = new Image(); img.src = ET.imageFile(id); await img.decode();
      const scene = { textures: { get: k => k === 'tex_enemy_' + id ? Object.assign(t, { getSourceImage() { return t.canvas; } }) : { getSourceImage() { return img; } } } };
      ET._applyImage(scene, id, 'img_' + id);
      const w = t.canvas.width, d = t.context.getImageData(0, 0, w, w).data; let edge = 0, inner = 0;
      for (let y = 0; y < w; y++) for (let x = 0; x < w; x++) { const a = d[(y * w + x) * 4 + 3]; if (x < 2 || y < 2 || x >= w - 2 || y >= w - 2) { if (a > 20) edge++; } else if (a > 128) inner++; }
      // le sujet doit occuper l'essentiel de la largeur/hauteur (pas un coin agrandi)
      let minX = w, maxX = 0, minY = w, maxY = 0;
      for (let y = 0; y < w; y++) for (let x = 0; x < w; x++) if (d[(y * w + x) * 4 + 3] > 128) { if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y; }
      out.push({ id, w, edge, inner: inner / (w * w), spanX: (maxX - minX) / w, spanY: (maxY - minY) / w });
    }
    return out;
  });
  full.forEach(r => {
    ok(r.edge === 0, r.id + ' : image entière, rien de coupé sur les bords de la texture ' + r.w + ' (' + r.edge + ' px)');
    ok(Math.max(r.spanX, r.spanY) > 0.85 && Math.max(r.spanX, r.spanY) <= 1, r.id + ' : sujet centré à pleine taille (' + Math.round(Math.max(r.spanX, r.spanY) * 100) + '%)');
  });

  ok(errors.length === 0, 'aucune erreur JS : ' + errors.join(' | '));
  await browser.close(); server.close();
  console.log(`browser-enemy-images : ${passed} OK, ${failed} échec(s)`);
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
