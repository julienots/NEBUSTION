/* Tests du module Galaxie (données + GalaxyManager + sauvegarde). Node, sans dépendance. Lancer : node tests/galaxy.test.js */
'use strict';
global.window = global;
require('../js/data/Economy.js'); require('../js/data/Heroes.js'); require('../js/data/Enemies.js'); require('../js/data/Galaxy.js');
require('../js/systems/SaveManager.js'); require('../js/systems/ResourceManager.js'); require('../js/systems/CombatEngine.js');
require('../js/systems/CombatManager.js'); require('../js/systems/GalaxyManager.js');

const G = NEBUSTION.Galaxy, GM = NEBUSTION.GalaxyManager, Save = NEBUSTION.Save, E = NEBUSTION.Economy;
let passed = 0, failed = 0;
function ok(c, m) { if (c) passed++; else { failed++; console.log('  ✗ ECHEC : ' + m); } }
function section(t) { console.log('\n# ' + t); }
function memStorage() { const m = {}; return { data: m, getItem: k => (k in m ? m[k] : null), setItem: (k, v) => { m[k] = String(v); }, removeItem: k => { delete m[k]; } }; }
const T0 = 1_800_000_000_000;
function fresh(t0) {
  Save._useStorage(memStorage());
  NEBUSTION.Resources = new NEBUSTION.ResourceManager(); NEBUSTION.Resources.init(t0 || T0);
  return NEBUSTION.Resources;
}
function give(R, o) { Object.keys(o).forEach(k => { R.state.res[k] = Math.min(o[k], R.cap(k)); }); }
function clearStages(R, n) { const ids = NEBUSTION.Enemies.allStages().map(s => s.id); ids.slice(0, n).forEach(id => { R.state.combat.stageStars[id] = 3; }); }

section('Empires : identité complète');
{
  ok(G.EMPIRE_ORDER.length === 6, '6 empires');
  const names = G.EMPIRE_ORDER.map(e => G.EMPIRES[e].name);
  ok(['VEXOR', "NYR'AH", 'KAEL-9', 'MORVAK', 'ELYRA', 'PARASITE'].every(n => names.includes(n)), 'les 6 noms demandés : ' + names.join(', '));
  const sub = { vexor: 'mécanique', nyrah: 'Néant', kael9: 'stellaire', morvak: 'infernale', elyra: 'céleste', parasite: 'Essaim' };
  G.EMPIRE_ORDER.forEach(id => {
    const e = G.EMPIRES[id];
    ok(e.subtitle.includes(sub[id]), id + ' : identité « ' + e.subtitle + ' »');
    ok(e.units.length === 5, id + ' : 5 unités propres');
    ok(e.resources.length >= 2 && e.resources.every(r => E.RES[r]), id + ' : ressources valides');
    ok(e.powerLevel >= 1 && e.powerLevel <= 6, id + ' : niveau de puissance');
    ok(!!e.trait && !!e.defenseStyle && !!e.description && !!e.doctrine, id + ' : défenses/doctrine/trait');
    ok(G.planetsOfEmpire(id).length === 5, id + ' : 5 planètes');
    ok(G.sector(e.sector).empire === id, id + ' : possède son secteur');
    ok(G.planetsOfEmpire(id).some(p => p.isCapital), id + ' : une capitale');
    e.units.forEach(u => {
      ok(u.base.hp > 0 && u.base.atk > 0 && u.base.def >= 0 && u.base.spd > 0, u.id + ' : stats valides');
      ok(!!u.visual.shape && !!u.visual.color, u.id + ' : identité visuelle');
      if (u.skill) ok(['singleDamage', 'aoeDamage', 'stun', 'drain', 'selfShield', 'selfBuff', 'singleHeal', 'aoeHeal'].includes(u.skill.kind) && u.skill.cooldown > 0, u.id + ' : compétence gérée par CombatEngine');
    });
  });
  const powers = G.EMPIRE_ORDER.map(e => G.empirePower(e));
  ok(powers.every((p, i) => i === 0 || p > powers[i - 1]), 'puissance totale strictement croissante : ' + powers.join(' < '));
  const allIds = G.EMPIRE_ORDER.flatMap(e => G.EMPIRES[e].units.map(u => u.id));
  ok(new Set(allIds).size === 30, '30 unités d\'empire uniques');
  ok(allIds.every(id => !NEBUSTION.Enemies.get(id)), 'aucune collision avec les ennemis du module Combat');
}

section('Compatibilité moteur de combat');
{
  const CE = NEBUSTION.CombatEngine;
  G.EMPIRE_ORDER.forEach(eid => G.planetsOfEmpire(eid).forEach(p => {
    const spec = G.battleSpec(p.id);
    ok(spec.waves.length >= 1 && spec.waves.every(w => w.length >= 1 && w.length <= 3), p.id + ' : vagues de 1 à 3 ennemis');
    const units = spec.waves[0].map((d, i) => CE.makeEnemyUnit(d, 'normal', i, spec.scale));
    ok(units.every(u => u.maxHp > 0 && u.atk > 0), p.id + ' : unités construites par makeEnemyUnit');
  }));
  const spec = G.battleSpec('halo7');
  ok(spec.waves[0].length === 2 && spec.waves[0][0].id === 'drone_sentinel', 'avant-poste neutre : ennemis du module Combat réutilisés');
  ok(G.battleSpec('nexus_01') === null, 'pas de bataille sur la planète-mère');
}

section('Cartes : planètes, secteurs, routes');
{
  ok(G.SECTORS.length === 7 && G.PLANETS.length === 34, '7 secteurs, 34 planètes (' + G.PLANETS.length + ')');
  const ids = G.PLANETS.map(p => p.id);
  ok(new Set(ids).size === ids.length, 'identifiants de planètes uniques');
  G.PLANETS.forEach(p => {
    ok(p.x > 80 && p.x < G.WORLD.w - 80 && p.y > 80 && p.y < G.WORLD.h - 80, p.id + ' : dans la carte');
    ok(!!G.PLANET_TYPES[p.type], p.id + ' : type connu');
    ok(!!G.sector(p.sector), p.id + ' : secteur connu');
    if (p.kind !== 'home') {
      ok(p.scan.cost.energy > 0 && p.scan.durationMs >= 3000, p.id + ' : coût/durée de scan');
      ok(p.defense.shield > 0 && p.defense.turrets > 0 && p.defense.fleet.length > 0 && p.defense.fleet.every(g => !!G.unitDef(g.unit)), p.id + ' : défenses valides');
      ok(Object.keys(p.deposits).length >= 1 && Object.keys(p.deposits).every(r => E.RES[r] && p.deposits[r] > 0), p.id + ' : ressources valides');
      ok(p.rewards.xp > 0 && p.rewards.fragments > 0 && p.rewards.crystal > 0, p.id + ' : récompenses valides');
      ok(p.recLevel >= 1 && p.recLevel <= 68 && p.power > 0, p.id + ' : niveau conseillé/puissance');
    }
  });
  for (let i = 0; i < G.PLANETS.length; i++) for (let j = i + 1; j < G.PLANETS.length; j++) {
    const a = G.PLANETS[i], b = G.PLANETS[j];
    ok(Math.hypot(a.x - b.x, a.y - b.y) >= 130, a.id + '/' + b.id + ' : assez espacées pour le tactile');
  }
  G.LANES.forEach(l => { ok(!!G.planet(l.a) && !!G.planet(l.b), l.a + '–' + l.b + ' : route valide'); });
  // graphe connexe depuis Nexus-01
  const seen = new Set(['nexus_01']), q = ['nexus_01'];
  while (q.length) { const c = q.pop(); G.neighbors(c).forEach(n => { if (!seen.has(n)) { seen.add(n); q.push(n); } }); }
  ok(seen.size === G.PLANETS.length, 'toutes les planètes sont reliées par des routes à Nexus-01');
  // niveau conseillé croissant secteur par secteur
  const caps = G.EMPIRE_ORDER.map(e => G.planetsOfEmpire(e).find(p => p.isCapital).recLevel);
  ok(caps.every((v, i) => i === 0 || v > caps[i - 1]), 'capitales de plus en plus dures : ' + caps.join(' < '));
  G.EMPIRE_ORDER.forEach(e => { const r = G.planetsOfEmpire(e).map(p => p.recLevel); ok(r.every((v, i) => i === 0 || v > r[i - 1]), e + ' : difficulté croissante ' + r.join(',')); });
  ok(G.recFromPower(G.powerForRec(20)) === 20, 'courbe puissance ↔ niveau réversible');
}

section('Déblocage progressif des secteurs');
{
  const R = fresh();
  ok(GM.isSectorUnlocked('s1') && !GM.isSectorUnlocked('s2') && !GM.isSectorUnlocked('s6'), 'départ : seul le secteur Origine est ouvert');
  let st = GM.sectorStatus('s2');
  ok(st.reqs.length === 2 && !st.allMet && !st.canUnlock, 'secteur 2 : conditions non remplies');
  ok(GM.unlockSector('s2').reason === 'requirements', 'déblocage refusé sans conditions');
  clearStages(R, 2); give(R, { crystal: 5000, energy: 3000, metal: 5000, core: 100 });
  ok(!GM.sectorStatus('s2').allMet, 'stages OK mais pas de scans → toujours verrouillé');
  GM.startScan('halo7', T0); GM.update(T0 + 60000); GM.startScan('cendre2', T0 + 60000); GM.update(T0 + 120000);
  st = GM.sectorStatus('s2', T0 + 120000);
  ok(st.allMet && st.canAfford && st.canUnlock, 'toutes les conditions remplies');
  const before = R.get('crystal');
  ok(GM.unlockSector('s2', T0 + 120000).ok, 'secteur 2 débloqué');
  ok(Math.abs(before - R.get('crystal') - 250) < 1e-6, 'coût exact prélevé (250 cristaux)');
  ok(GM.isSectorUnlocked('s2') && GM.unlockSector('s2').reason === 'already', 'pas de double déblocage / double dépense');
  ok(!GM.isSectorUnlocked('s3') && !GM.sectorStatus('s3').allMet, 'le secteur 3 reste verrouillé (ordre progressif)');
  // ressources insuffisantes : rien n'est dépensé
  const R2 = fresh(); clearStages(R2, 2); GM.startScan('halo7', T0); GM.update(T0 + 1e5); GM.startScan('cendre2', T0 + 1e5); GM.update(T0 + 2e5);
  R2.state.res.crystal = 100; const snap = JSON.stringify(R2.state.res);
  ok(GM.unlockSector('s2', T0 + 2e5).reason === 'cost' && JSON.stringify(R2.state.res) === snap && !GM.isSectorUnlocked('s2'), 'ressources insuffisantes : refus atomique, rien de dépensé');
  // Tous les secteurs : coûts atteignables avec les plafonds de stockage niveau 1
  G.SECTORS.filter(s => s.unlock).forEach(s => Object.keys(s.unlock.cost).forEach(r => ok(s.unlock.cost[r] <= E.storageCap(r, 1), s.id + ' : coût ' + r + ' sous le plafond de stockage')));
  // fournisseur de conditions externe (modules suivants)
  GM.addRequirementProvider('s3', () => ({ id: 'x', label: 'test', cur: 0, need: 1, ok: false }));
  ok(GM.sectorStatus('s3').reqs.some(r => r.id === 'x') && !GM.sectorStatus('s3').allMet, 'condition ajoutée par un autre module prise en compte');
}

section('Scan des planètes');
{
  const R = fresh(); const pid = 'halo7';
  ok(GM.scanState(pid, T0).status === 'none' && !GM.isScanned(pid, T0), 'planète non scannée au départ');
  ok(GM.canInvade(pid, T0).reason === 'scan', 'invasion impossible sans scan');
  ok(GM.canScan('vx1', T0).reason === 'locked' && GM.startScan('vx1', T0).reason === 'locked', 'scan refusé dans un secteur verrouillé');
  ok(GM.canScan('nexus_01', T0).reason === 'home', 'pas de scan de la planète-mère');
  R.state.res.energy = 0;
  ok(GM.startScan(pid, T0).reason === 'cost', 'scan refusé sans énergie');
  give(R, { energy: 500 });
  const e0 = R.get('energy'), cost = GM.scanCost(pid).energy;
  const r = GM.startScan(pid, T0);
  ok(r.ok && Math.abs(e0 - R.get('energy') - cost) < 1e-9, 'énergie prélevée (' + cost + ')');
  ok(GM.scanState(pid, T0 + 1000).status === 'scanning' && GM.scanState(pid, T0 + 1000).progress > 0 && GM.scanState(pid, T0 + 1000).progress < 1, 'progression en cours');
  ok(GM.startScan(pid, T0 + 100).reason === 'scanning', 'pas de double scan');
  ok(GM.startScan('cendre2', T0 + 100).reason === 'busy', 'un seul scan à la fois');
  ok(GM.canInvade(pid, T0 + 1000).reason === 'scan', 'invasion refusée pendant le scan');
  const events = []; const off = GM.on('scanDone', e => events.push(e.planet));
  ok(GM.update(T0 + 500).length === 0, 'pas terminé trop tôt');
  ok(GM.update(T0 + GM.scanDuration(pid) + 5).join() === pid && events.join() === pid, 'scan terminé + événement émis');
  ok(GM.update(T0 + 1e6).length === 0 && events.length === 1, 'terminé une seule fois');
  off();
  ok(GM.isScanned(pid, T0 + 1e6) && GM.canInvade(pid, T0 + 1e6).ok, 'scan valide → invasion autorisée');
  ok(GM.state().stats.scans === 1, 'statistique de scans');
  ok(GM.canScan(pid, T0 + 1e6).reason === 'scanned', 'pas de re-scan inutile');
  ok(GM.scanState(pid, T0 + 1e6).validMs > 0, 'durée de validité restante affichée');
  ok(GM.scanState(pid, T0 + 13 * 3600e3).status === 'expired' && !GM.canInvade(pid, T0 + 13 * 3600e3).ok, 'le scan expire après 12 h → nouvelle analyse requise');
  ok(GM.canScan(pid, T0 + 13 * 3600e3).ok || GM.canScan(pid, T0 + 13 * 3600e3).reason === 'cost', 'un scan expiré peut être relancé');
  // sauvegarde + rechargement pendant un scan (job persistant, terminé hors ligne)
  const R3 = fresh(); give(R3, { energy: 500 }); GM.startScan('lyr', T0); R3.saveNow(T0 + 500);
  const st = Save._useStorage; // même stockage
  const R4 = new NEBUSTION.ResourceManager(); NEBUSTION.Resources = R4; R4.init(T0 + 3600e3);
  ok(!!GM.state().jobs.lyr, 'scan en cours conservé après rechargement');
  ok(GM.update(T0 + 3600e3).join() === 'lyr' && GM.isScanned('lyr', T0 + 3600e3), 'scan terminé pendant l\'absence');
  // conquête / visite
  ok(GM.visit('halo7', T0) === true && GM.visit('halo7', T0) === false && GM.isVisited('halo7'), 'visite enregistrée une fois');
  ok(GM.visit('vx1', T0) === false, 'planète d\'un secteur verrouillé non visitable');
  GM.setConquered('halo7', true, T0); ok(GM.canInvade('halo7', T0).reason === 'conquered', 'planète conquise non ré-envahissable');
}

section('Sauvegarde : rétrocompatibilité et robustesse');
{
  // sauvegarde d'étape 4 (sans champ galaxy)
  Save._useStorage(memStorage());
  const old = Save.defaultState(T0); delete old.galaxy;
  const n = Save.normalize(old, T0);
  ok(n.galaxy && n.galaxy.unlocked.s1 === true && Object.keys(n.galaxy.scans).length === 0, 'ancienne sauvegarde : galaxy créé par défaut');
  ok(n.combat && n.res && n.buildings, 'les systèmes précédents sont conservés');
  // données absurdes
  const bad = Save.defaultState(T0);
  bad.galaxy = { unlocked: { s6: true, zzz: true, s3: 'oui' }, scans: { halo7: { at: 'x' }, fake: { at: 1 }, nexus_01: { at: 1 } }, jobs: { lyr: { start: NaN, end: 5 }, halo7: { start: T0, end: T0 + 5000 }, cendre2: { start: T0, end: T0 + 1e9 } }, visited: { halo7: -5 }, view: { x: 'a', y: 1, z: 2 }, stats: { scans: -3, unlocks: 'x' } };
  const g = Save.normalize(bad, T0).galaxy;
  ok(g.unlocked.s6 === true && !g.unlocked.zzz && !g.unlocked.s3, 'secteurs : ids inconnus / valeurs non booléennes ignorés');
  ok(g.scans.halo7 && !g.scans.fake && !g.scans.nexus_01, 'scans : planètes inconnues ou planète-mère ignorées');
  ok(g.jobs.halo7 && !g.jobs.lyr && !g.jobs.cendre2, 'jobs de scan : valeurs incohérentes rejetées');
  ok(g.view === null && g.stats.scans === 0 && g.stats.unlocks === 0, 'vue/stats invalides remplacées');
  ok(Save.normalize(null, T0).galaxy.unlocked.s1 === true, 'null → état par défaut');
  const s0 = Save.normalize({ galaxy: { unlocked: { s1: false } } }, T0).galaxy;
  ok(s0.unlocked.s1 === true, 's1 toujours débloqué');
  // aller-retour d'enregistrement
  const R = fresh(); give(R, { energy: 500 }); GM.startScan('halo7', T0); GM.update(T0 + 1e5); GM.visit('halo7', T0); GM.saveView({ x: 900, y: 2400, z: 0.8 }); R.saveNow(T0 + 2e5);
  const R2 = new NEBUSTION.ResourceManager(); R2.init(T0 + 3e5); NEBUSTION.Resources = R2;
  ok(GM.state().scans.halo7 && GM.state().visited.halo7 && GM.getView().z === 0.8, 'scans, visites et vue restaurés');
  // reset complet
  R2.reset(T0 + 4e5); ok(Object.keys(GM.state().scans).length === 0 && GM.isSectorUnlocked('s1'), 'réinitialisation de la partie remet la galaxie à zéro');
}

section('Aides');
{
  const R = fresh();
  ok(GM.teamLevel() >= 1, 'niveau moyen d\'équipe calculé');
  ok(GM.currentSector() === 's1', 'secteur courant');
  ok(GM.totalStages() === 13 && GM.stagesCleared() === 0, 'lecture des stages du module Combat');
  clearStages(R, 4); ok(GM.stagesCleared() === 4, 'stages terminés comptés');
}

console.log(failed === 0 ? '\n✔ TESTS GALAXIE OK  (' + passed + ' vérifications)' : '\n✘ ' + failed + ' échec(s), ' + passed + ' réussite(s)');
process.exit(failed === 0 ? 0 : 1);
