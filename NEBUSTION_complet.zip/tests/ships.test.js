/* Tests du module de données NEBUSTION.Ships (Node, sans dépendance). Lancer : node tests/ships.test.js */
'use strict';
global.window = global;
require('../js/data/Ships.js');

const S = NEBUSTION.Ships;
let passed = 0, failed = 0;
function ok(cond, msg) { if (cond) { passed++; } else { failed++; console.log('  ✗ ECHEC : ' + msg); } }
function section(t) { console.log('\n# ' + t); }

section('Structure générale');
{
  ok(S.CLASS_ORDER.length === 4, '4 classes de vaisseaux définies');
  ok(S.FLEET_MAX === 3, 'flotte limitée à 3 vaisseaux');
  S.CLASS_ORDER.forEach(id => ok(!!S.CLASS_INDEX[id], 'classe présente : ' + id));
  S.RARITY_ORDER.forEach(r => ok(!!S.RARITIES[r], 'rareté présente : ' + r));
}

section('bonusFor : croissance avec la rareté et le niveau, une seule statistique par classe');
{
  const b1 = S.bonusFor('intercepteur', 'commun', 1);
  ok(Object.keys(b1).length === 1 && b1.atk > 0, 'intercepteur ne bonifie que atk (' + JSON.stringify(b1) + ')');
  const rare = S.bonusFor('intercepteur', 'rare', 1);
  ok(rare.atk > b1.atk, 'une rareté supérieure donne un bonus plus élevé');
  const lvl5 = S.bonusFor('intercepteur', 'commun', 5);
  ok(lvl5.atk > b1.atk, 'un niveau supérieur donne un bonus plus élevé');
  const capped = S.bonusFor('intercepteur', 'commun', 999);
  const maxLvl = S.bonusFor('intercepteur', 'commun', S.MAX_LEVEL);
  ok(capped.atk === maxLvl.atk, 'le niveau est plafonné à MAX_LEVEL');

  ok(S.bonusFor('cuirasse', 'commun', 1).def > 0, 'cuirassé bonifie def');
  ok(S.bonusFor('corvette', 'commun', 1).spd > 0, 'corvette bonifie spd');
  ok(S.bonusFor('porte_vaisseaux', 'commun', 1).hp > 0, 'porte-vaisseaux bonifie hp');
}

section('Coûts cohérents');
{
  const c1 = S.acquireCost('commun');
  const c2 = S.acquireCost('legendaire');
  ok(c2.crystal > c1.crystal, 'un vaisseau légendaire coûte plus cher qu\'un commun');
  const u1 = S.upgradeCost('rare', 1);
  const u5 = S.upgradeCost('rare', 5);
  ok(u5.crystal > u1.crystal, 'améliorer coûte plus cher à mesure que le niveau augmente');
}

section('normalizeState : robustesse');
{
  const empty = S.normalizeState(null);
  ok(Object.keys(empty.ships).length === 0 && empty.fleet.length === 0, 'état vide par défaut sans données');

  const raw = {
    nextSeq: 3,
    ships: {
      sh1: { classId: 'intercepteur', rarity: 'rare', level: 4 },
      sh2: { classId: 'inconnue', rarity: 'rare', level: 1 },     // classe invalide -> ignorée
      sh3: { classId: 'cuirasse', rarity: 'oops', level: 1 },     // rareté invalide -> ignorée
      sh4: { classId: 'corvette', rarity: 'commun', level: 9999 } // niveau hors bornes -> plafonné
    },
    fleet: ['sh1', 'sh_absent', 'sh4', 'sh1', 'sh4', 'sh4'] // doublons + référence invalide -> nettoyés, max 3
  };
  const s = S.normalizeState(raw);
  ok(Object.keys(s.ships).length === 2, 'seuls les vaisseaux valides sont conservés (' + Object.keys(s.ships).length + ')');
  ok(s.ships.sh4.level === S.MAX_LEVEL, 'niveau plafonné à MAX_LEVEL');
  ok(s.fleet.length === 2 && s.fleet.indexOf('sh1') >= 0 && s.fleet.indexOf('sh4') >= 0, 'flotte nettoyée sans doublon ni référence invalide (' + JSON.stringify(s.fleet) + ')');
  ok(s.nextSeq === 3, 'nextSeq conservé');
}

console.log('\n' + (failed === 0 ? '✓ TOUS LES TESTS SONT PASSÉS' : '✗ ÉCHECS DÉTECTÉS') + ' — ' + passed + ' réussis, ' + failed + ' échoués');
process.exit(failed === 0 ? 0 : 1);
