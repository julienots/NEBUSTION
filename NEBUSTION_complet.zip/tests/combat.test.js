/* Tests du moteur de combat NEBUSTION.CombatEngine + NEBUSTION.Combat (Node).
 * Lancer : node tests/combat.test.js */
'use strict';
global.window = global;
require('../js/data/Economy.js');
require('../js/data/Heroes.js');
require('../js/data/Enemies.js');
require('../js/systems/SaveManager.js');
require('../js/systems/CombatEngine.js');
require('../js/systems/CombatManager.js');

const H = NEBUSTION.Heroes, EN = NEBUSTION.Enemies, CE = NEBUSTION.CombatEngine;
let passed = 0, failed = 0;
function ok(cond, msg) { if (cond) { passed++; } else { failed++; console.log('  ✗ ECHEC : ' + msg); } }
function section(t) { console.log('\n# ' + t); }

function makeTeam(level) {
  return ['zyra', 'korvax', 'lumina', 'drakor', 'selene'].map(id => CE.makeHeroUnit(H.get(id), level || 10, id));
}
function makeEnemies(stageId, difficulty) {
  return EN.stage(stageId).enemies.map((id, i) => CE.makeEnemyUnit(EN.get(id), difficulty || 'normal', i));
}
function run(engine, maxSeconds) {
  var steps = 0, max = (maxSeconds || 400) / 0.1, allEvents = [];
  while (!engine.isOver() && steps < max) {
    engine.update(0.1);
    allEvents = allEvents.concat(engine.consumeEvents());
    steps++;
  }
  return allEvents;
}

section('Fabrique d\'unités');
{
  var hero = CE.makeHeroUnit(H.get('zyra'), 10, 'zyra');
  var expectedStats = H.statsAtLevel(H.get('zyra'), 10);
  ok(hero.hp === expectedStats.hp && hero.maxHp === expectedStats.hp, 'PV du héros = statsAtLevel');
  ok(hero.atk === expectedStats.atk, 'ATQ du héros = statsAtLevel');
  ok(hero.side === 'player', 'côté joueur correct');

  var enemy = CE.makeEnemyUnit(EN.get('corvex_juggernaut'), 'difficile', 0);
  var expectedEnemy = EN.statsForEnemy(EN.get('corvex_juggernaut'), 'difficile');
  ok(enemy.hp === expectedEnemy.hp, 'PV ennemi = statsForEnemy (difficulté appliquée)');
  ok(enemy.side === 'enemy', 'côté ennemi correct');
}

section('Attaque de base : dégâts réels, jamais négatifs/NaN');
{
  var team = makeTeam(20);
  var enemies = makeEnemies('stage_01', 'normal');
  var engine = new CE.CombatEngine(team, enemies, { mode: 'auto' });
  var totalHpBefore = enemies.reduce((s, u) => s + u.hp, 0);
  var events = run(engine, 5);
  var dmgEvents = events.filter(e => e.type === 'damage');
  ok(dmgEvents.length > 0, 'des événements de dégâts sont produits');
  dmgEvents.forEach(e => {
    ok(typeof e.amount === 'number' && isFinite(e.amount) && e.amount >= 1, 'dégâts valides (>=1, fini)');
  });
  var allUnits = team.concat(enemies);
  allUnits.forEach(u => ok(u.hp >= 0 && u.hp <= u.maxHp, u.name + ' : PV dans les bornes [0, maxHp]'));
}

section('Combat gagnable et perdable, victoire/défaite détectées');
{
  var teamStrong = makeTeam(30);
  var weakEnemies = makeEnemies('stage_01', 'facile');
  var e1 = new CE.CombatEngine(teamStrong, weakEnemies, { mode: 'auto' });
  var ev1 = run(e1, 60);
  ok(e1.isOver(), 'le combat facile se termine');
  ok(e1.getResult().win === true, 'une équipe forte bat un stage facile');
  ok(ev1.some(e => e.type === 'victory'), 'un événement victory est émis');

  var teamWeak = makeTeam(1);
  var bossHard = [CE.makeEnemyUnit(EN.get('omega_krell'), 'cauchemar', 0)];
  var e2 = new CE.CombatEngine(teamWeak, bossHard, { mode: 'auto' });
  var ev2 = run(e2, 300);
  ok(e2.isOver(), 'le combat difficile se termine');
  ok(e2.getResult().win === false, 'une équipe faible niveau 1 perd contre le boss final en cauchemar');
  ok(ev2.some(e => e.type === 'defeat'), 'un événement defeat est émis');
}

section('Boss : phases, bonus et attaque spéciale de transition (nova)');
{
  var team = makeTeam(45);
  var boss = [CE.makeEnemyUnit(EN.get('nexus_prime'), 'normal', 0)];
  var bossUnit = boss[0];
  var initialAtk = bossUnit.atk, initialCd = bossUnit.skillCooldownMax;
  var engine = new CE.CombatEngine(team, boss, { mode: 'auto' });
  var events = run(engine, 60);
  var phaseEvents = events.filter(e => e.type === 'phase');
  ok(phaseEvents.length >= 1, 'au moins une transition de phase a eu lieu');
  ok(bossUnit.atk > initialAtk, 'l\'attaque du boss augmente après une phase');
  ok(bossUnit.skillCooldownMax < initialCd, 'le temps de recharge du boss diminue après une phase (plus agressif)');
  ok(events.some(e => e.type === 'bossNova'), 'une attaque spéciale de transition (nova) est déclenchée');
}

section('Mode manuel : les compétences attendent un ordre du joueur');
{
  var team = [CE.makeHeroUnit(H.get('zyra'), 15, 'zyra')];
  var enemies = [CE.makeEnemyUnit(EN.get('drone_sentinel'), 'normal', 0)];
  var engine = new CE.CombatEngine(team, enemies, { mode: 'manual' });
  var sawSkill = false, sawBasic = false;
  for (var i = 0; i < 80 && !engine.isOver(); i++) {
    engine.update(0.1);
    engine.consumeEvents().forEach(e => {
      if (e.uid === team[0].uid && e.type === 'skill') sawSkill = true;
      if (e.uid === team[0].uid && e.type === 'attack') sawBasic = true;
    });
  }
  ok(sawBasic, 'les attaques de base restent automatiques en mode manuel');
  ok(!sawSkill, 'la compétence active NE se déclenche PAS sans ordre du joueur en mode manuel');

  // Nouvelle tentative avec une demande explicite
  var team2 = [CE.makeHeroUnit(H.get('zyra'), 15, 'zyra')];
  var enemies2 = [CE.makeEnemyUnit(EN.get('steel_golem'), 'normal', 0)];
  var engine2 = new CE.CombatEngine(team2, enemies2, { mode: 'manual' });
  engine2.requestSkill(team2[0].uid);
  var sawSkill2 = false;
  for (var j = 0; j < 40 && !engine2.isOver(); j++) {
    engine2.update(0.1);
    engine2.consumeEvents().forEach(e => { if (e.uid === team2[0].uid && e.type === 'skill') sawSkill2 = true; });
  }
  ok(sawSkill2, 'la compétence se déclenche une fois demandée explicitement (requestSkill)');
}

section('Ultime : se charge puis se déclenche, remet l\'énergie à zéro');
{
  // Test déterministe (plutôt que d'attendre une charge naturelle dont la durée dépend
  // de l'issue aléatoire du combat) : on amène l'énergie à 100 directement, puis on
  // vérifie qu'UNE frappe de jauge suffit à déclencher l'ultime et à la remettre à zéro.
  var team = [CE.makeHeroUnit(H.get('vortex'), 25, 'vortex')];
  var enemies = [CE.makeEnemyUnit(EN.get('steel_golem'), 'normal', 0)];
  var engine = new CE.CombatEngine(team, enemies, { mode: 'auto' });
  team[0].energy = 100;
  var sawUltimate = false;
  for (var i = 0; i < 5 && !engine.isOver(); i++) {
    engine.update(0.1);
    engine.consumeEvents().forEach(e => { if (e.type === 'ultimate' && e.uid === team[0].uid) sawUltimate = true; });
    if (sawUltimate) break;
  }
  ok(sawUltimate, 'l\'ultime se déclenche automatiquement une fois chargé (mode auto)');
  ok(team[0].energy < CE.ENERGY_MAX, 'l\'énergie retombe après le déclenchement de l\'ultime');

  // Vérifie aussi qu'un combat complet PEUT charger un ultime quand il dure assez longtemps
  // (adversaire plus résistant relativement à l'équipe, sur plusieurs tirages).
  var sawInFullFight = false;
  for (var attempt = 0; attempt < 10 && !sawInFullFight; attempt++) {
    var team2 = [CE.makeHeroUnit(H.get('vortex'), 8, 'vortex')];
    var enemies2 = [CE.makeEnemyUnit(EN.get('omega_krell'), 'facile', 0)];
    var engine2 = new CE.CombatEngine(team2, enemies2, { mode: 'auto' });
    for (var k = 0; k < 500 && !engine2.isOver(); k++) {
      engine2.update(0.1);
      engine2.consumeEvents().forEach(e => { if (e.type === 'ultimate' && e.uid === team2[0].uid) sawInFullFight = true; });
    }
  }
  ok(sawInFullFight, 'dans un combat suffisamment long, l\'ultime se charge naturellement en jouant');
}

section('CombatManager : équipe, difficulté, progression, récompenses');
{
  var now = Date.now();
  NEBUSTION.Resources = {
    state: NEBUSTION.Save.defaultState(now),
    add: function (id, amount) { this.state.res[id] = (this.state.res[id] || 0) + amount; return amount; },
    saveNow: function () { return true; }
  };
  var C = NEBUSTION.Combat;

  ok(C.getTeam().length === 5, 'équipe par défaut de 5 héros');
  var setResult = C.setTeam(['zyra', 'korvax', 'lumina', 'drakor', 'selene', 'vortex', 'nyx']);
  ok(setResult.length === 5, 'setTeam plafonne à 5 héros (' + setResult.length + ')');
  ok(C.getDifficulty() === 'normal', 'difficulté par défaut = normal');
  C.setDifficulty('difficile');
  ok(C.getDifficulty() === 'difficile', 'la difficulté persiste après setDifficulty');

  ok(C.isStageUnlocked(EN.firstStageId()), 'le premier stage est toujours débloqué');
  ok(!C.isStageUnlocked('boss_omega_krell'), 'le dernier stage est verrouillé avant progression');

  var battle = C.buildBattle('stage_01', 'facile', 'auto');
  var events = run(battle.engine, 60);
  var result = battle.engine.getResult();
  ok(!!result && result.win === true, 'stage 1 en facile avec équipe niveau 1 : victoire attendue');
  var before = JSON.parse(JSON.stringify(NEBUSTION.Resources.state.res));
  var grant = C.grantRewards(battle.stageDef, 'facile', result);
  ok(grant.stars >= 1, 'au moins 1 étoile gagnée sur une victoire');
  ok(NEBUSTION.Resources.state.res.crystal > before.crystal, 'les ressources augmentent après la récompense');
  ok(NEBUSTION.Resources.state.combat.stageStars.stage_01 === grant.stars, 'la progression du stage est enregistrée');
  ok(C.isStageUnlocked('stage_02'), 'le stage suivant se débloque après une victoire');
  if (grant.fragmentHero) {
    ok(NEBUSTION.Resources.state.combat.fragments[grant.fragmentHero] > 0, 'des fragments sont accordés à un héros de l\'équipe');
  }

  var prevStars = NEBUSTION.Resources.state.combat.stageStars.stage_01;
  var battle2 = C.buildBattle('stage_01', 'facile', 'auto');
  var result2 = battle2.engine.getResult ? null : null;
  run(battle2.engine, 60);
  var grant2 = C.grantRewards(battle2.stageDef, 'facile', battle2.engine.getResult());
  ok(NEBUSTION.Resources.state.combat.stageStars.stage_01 >= prevStars, 'les étoiles ne régressent jamais (meilleur score conservé)');
}


// ============================================================================
// Kits de compétences par héros (moteur v2) : chaque héros utilise SES compétences
// ============================================================================
function duel(heroId, enemyIds, opts) {
  opts = opts || {};
  var hero = CE.makeHeroUnit(H.get(heroId), opts.level || 20, heroId);
  var allies = (opts.allies || []).map(id => CE.makeHeroUnit(H.get(id), opts.level || 20, id));
  var foes = (enemyIds || ['steel_golem', 'steel_golem', 'umbra_sniper']).map((id, i) => CE.makeEnemyUnit(EN.get(id), opts.diff || 'normal', i));
  foes.forEach(f => { f.gauge = 0; f.skillCooldown = 999; if (!opts.realHp) { f.maxHp = f.hp = 1e9; } }); // ennemis passifs et increvables : on isole l'effet testé
  var team = [hero].concat(allies);
  team.forEach(t => { t.gauge = 0; });
  var eng = new CE.CombatEngine(team, foes, { mode: opts.mode || 'auto' });
  return { eng: eng, hero: hero, allies: allies, foes: foes, team: team };
}
function step(eng, seconds, dt) {
  var ev = [], n = Math.round(seconds / (dt || 0.05));
  for (var i = 0; i < n && !eng.isOver(); i++) { eng.update(dt || 0.05); ev = ev.concat(eng.consumeEvents()); }
  return ev;
}
function fireSkill(d, ult) {
  if (ult) { d.hero.energy = 100; d.eng.requestUltimate(d.hero.uid); }
  else { d.hero.skillCooldown = 0; d.eng.requestSkill(d.hero.uid); }
}

section('Kits : les 16 héros ont un kit dédié et l\'utilisent sans erreur');
{
  H.all().forEach(function (h) {
    ok(!!CE.HERO_KIT[h.id], h.name + ' : kit de compétences défini');
    ['active', 'ultimate'].forEach(function (slot) {
      var d = duel(h.id, null, { allies: ['lumina', 'zyra'], mode: 'manual' });
      var hpBefore = d.foes.map(f => f.hp);
      fireSkill(d, slot === 'ultimate');
      var ev = step(d.eng, 6);
      var cast = ev.filter(e => e.type === (slot === 'ultimate' ? 'ultimate' : 'skill') && e.uid === d.hero.uid);
      ok(cast.length === 1, h.name + ' : ' + slot + ' lancé exactement une fois sur ordre');
      ev.forEach(e => { if (typeof e.amount === 'number') ok(isFinite(e.amount) && e.amount >= 0, h.name + ' ' + slot + ' : montant valide'); });
      d.eng.all.forEach(u => ok(isFinite(u.hp) && u.hp >= 0 && u.hp <= u.maxHp, h.name + ' ' + slot + ' : PV de ' + u.name + ' dans les bornes'));
      var offensive = ev.some(e => e.type === 'damage' && e.uid === d.hero.uid);
      var support = ev.some(e => ['heal', 'shield', 'buff', 'taunt', 'extra', 'cleanse'].indexOf(e.type) >= 0 && e.uid === d.hero.uid);
      ok(offensive || support, h.name + ' ' + slot + ' : produit un effet réel (dégâts ou soutien)');
    });
  });
}

section('Kits : effets fidèles aux descriptions');
{
  // Zyra — Danse des ombres : 3 coups rapides sur la même cible
  var d = duel('zyra', ['steel_golem', 'steel_golem'], { mode: 'manual' });
  fireSkill(d, false);
  var ev = step(d.eng, 2);
  var hits = ev.filter(e => e.type === 'damage' && e.uid === d.hero.uid && e.skill);
  ok(hits.length === 3, 'Zyra : la compétence porte 3 coups (' + hits.length + ')');
  ok(new Set(hits.map(h => h.targetUid)).size === 1, 'Zyra : les 3 coups visent la même cible');

  // Zyra — Éclipse totale : touche tous les ennemis, critiques garantis
  d = duel('zyra', ['steel_golem', 'nexus_architect', 'umbra_sniper'], { mode: 'manual' });
  fireSkill(d, true);
  ev = step(d.eng, 1);
  var ultHits = ev.filter(e => e.type === 'damage' && e.uid === d.hero.uid && e.skill);
  ok(ultHits.length === 3 && ultHits.every(h => h.crit), 'Zyra ultime : 3 ennemis touchés, tous en critique');

  // Korvax — Impact sismique : étourdit tous les ennemis et se soigne
  d = duel('korvax', ['steel_golem', 'nexus_architect', 'umbra_sniper'], { mode: 'manual' });
  d.hero.hp = Math.round(d.hero.maxHp * 0.5);
  fireSkill(d, true);
  ev = step(d.eng, 0.5);
  ok(ev.filter(e => e.type === 'stun').length === 3, 'Korvax ultime : les 3 ennemis sont étourdis');
  ok(ev.some(e => e.type === 'heal' && e.targetUid === d.hero.uid), 'Korvax ultime : se soigne');
  ok(d.hero.hp >= Math.round(d.hero.maxHp * 0.7) - 1, 'Korvax ultime : regagne 20 % de ses PV max');

  // Korvax — Mur d'énergie : bouclier + provocation (les ennemis ne visent que lui)
  d = duel('korvax', ['umbra_sniper', 'umbra_sniper'], { allies: ['lumina', 'zyra'], mode: 'manual' });
  d.foes.forEach(f => { f.skillCooldown = 999; f.gauge = 0; });
  fireSkill(d, false);
  step(d.eng, 0.1);
  ok(d.hero.shield > 0, 'Korvax : le Mur d\'énergie donne un bouclier');
  d.foes.forEach(f => { f.spd = 400; });
  var atk = step(d.eng, 3.5).filter(e => e.type === 'attack' && d.foes.some(f => f.uid === e.uid));
  ok(atk.length >= 3 && atk.every(a => a.targetUid === d.hero.uid), 'Provocation : ' + atk.length + ' attaques ennemies, toutes sur Korvax');

  // Bouclier temporaire : expire
  step(d.eng, 5);
  ok(d.hero.shield === 0, 'le bouclier temporaire expire (4 s)');

  // Lumina — Sanctuaire : soigne toute l'équipe et purge
  d = duel('lumina', null, { allies: ['zyra', 'korvax'], mode: 'manual' });
  d.team.forEach(u => { u.hp = Math.round(u.maxHp * 0.3); });
  d.allies[0].stunTime = 3;
  var hpsBefore = d.team.map(u => u.hp);
  fireSkill(d, true);
  ev = step(d.eng, 0.2);
  ok(d.team.every((u, i) => u.hp > hpsBefore[i]), 'Lumina ultime : toute l\'équipe est soignée');
  ok(d.allies[0].stunTime === 0, 'Lumina ultime : purge l\'étourdissement');

  // Drakor — Écailles ardentes : renvoie des dégâts à l'attaquant
  d = duel('drakor', ['steel_golem'], { mode: 'manual' });
  var golem = d.foes[0];
  var before = golem.hp;
  d.eng.applyDamage(golem, d.hero, 1.0, { noCrit: true });
  ev = d.eng.consumeEvents();
  ok(ev.some(e => e.reflect && e.targetUid === golem.uid), 'Drakor : renvoie une partie des dégâts (événement reflect)');
  ok(golem.hp < before, 'Drakor : l\'attaquant perd des PV');

  // Drakor — Griffe draconique : saignement (dégâts sur la durée)
  d = duel('drakor', ['steel_golem'], { mode: 'manual' });
  fireSkill(d, false);
  ev = step(d.eng, 4);
  ok(ev.filter(e => e.dot).length >= 2, 'Drakor : le saignement inflige des dégâts sur la durée');

  // Soraya — brûlure sur tous les ennemis
  d = duel('soraya', ['steel_golem', 'nexus_architect'], { mode: 'manual' });
  fireSkill(d, false);
  ev = step(d.eng, 4);
  ok(new Set(ev.filter(e => e.dot).map(e => e.targetUid)).size === 2, 'Soraya : la brûlure touche les 2 ennemis');

  // Selene — Pluie stellaire : 3 salves sur tous les ennemis
  d = duel('selene', ['steel_golem', 'nexus_architect'], { mode: 'manual' });
  fireSkill(d, true);
  ev = step(d.eng, 4);
  ok(ev.filter(e => e.type === 'damage' && e.uid === d.hero.uid && e.skill).length === 6, 'Selene ultime : 3 salves x 2 ennemis');

  // Selene — Tir perforant : la cible ET l'ennemi derrière
  d = duel('selene', ['steel_golem', 'nexus_architect'], { mode: 'manual' });
  fireSkill(d, false);
  ev = step(d.eng, 0.3);
  ok(new Set(ev.filter(e => e.type === 'damage').map(e => e.targetUid)).size === 2, 'Selene : le tir perforant touche 2 ennemis distincts');

  // Kael — Rafale ciblée : 5 tirs
  d = duel('kael', ['steel_golem'], { mode: 'manual' });
  fireSkill(d, false);
  ev = step(d.eng, 2);
  ok(ev.filter(e => e.type === 'damage' && e.uid === d.hero.uid && e.skill).length === 5, 'Kael : rafale de 5 tirs');

  // Nyx — Piège spectral : étourdit + dégâts ; Nuit sans fin : les ennemis ratent leurs coups
  d = duel('nyx', ['umbra_sniper'], { mode: 'manual' });
  fireSkill(d, false);
  ev = step(d.eng, 0.3);
  ok(ev.some(e => e.type === 'stun') && ev.some(e => e.type === 'damage'), 'Nyx : piège spectral = étourdissement + dégâts');
  d = duel('nyx', ['steel_golem', 'steel_golem'], { mode: 'manual' });
  fireSkill(d, true);
  step(d.eng, 0.2);
  d.foes.forEach(f => { f.spd = 500; f.gauge = 0; f.stunTime = 0; f.hp = f.maxHp; });
  var misses = 0;
  for (var k = 0; k < 20; k++) { d.foes.forEach(f => { f.gauge = 100; }); d.eng.update(0.05); d.eng.consumeEvents().forEach(e => { if (e.type === 'miss') misses++; }); d.eng.time = Math.min(d.eng.time, 3); }
  ok(misses > 0, 'Nyx ultime : les ennemis ratent des attaques (' + misses + ' ratés sur 40)');

  // Vortex — Rupture temporelle : vitesse x2 et attaque x2 ; Surcharge : vitesse cumulée
  d = duel('vortex', ['steel_golem'], { mode: 'manual' });
  var spd0 = d.eng._effSpeed(d.hero);
  fireSkill(d, true); step(d.eng, 0.1);
  ok(Math.abs(d.eng._effSpeed(d.hero) / spd0 - 2) < 0.01, 'Vortex ultime : vitesse doublée');
  step(d.eng, 5);
  ok(Math.abs(d.eng._effSpeed(d.hero) / spd0 - 1) < 0.5 && d.eng._m(d.hero, 'spd') === 1, 'Vortex ultime : l\'effet expire au bout de 4 s');
  d = duel('vortex', ['steel_golem'], { mode: 'auto' });
  d.hero.skillCooldown = 999;
  var s0 = d.eng._effSpeed(d.hero);
  for (var q = 0; q < 8; q++) { d.hero.gauge = 100; d.eng.update(0.01); }
  ok(d.hero.surge === 5 && Math.abs(d.eng._effSpeed(d.hero) / s0 - 1.15) < 0.001, 'Vortex Surcharge : +3 % par attaque, plafonné à 5 cumuls (+15 %)');

  // Vega — Optimisation : +4 % de vitesse à toute l'équipe ; Réseau tactique : action immédiate
  d = duel('vega', ['steel_golem'], { allies: ['zyra', 'korvax'], mode: 'manual' });
  ok(d.team.every(u => Math.abs(u.permSpd - 1.04) < 1e-9), 'Vega : +4 % de vitesse pour toute l\'équipe');
  fireSkill(d, true);
  ev = step(d.eng, 0.2);
  ok(ev.filter(e => e.type === 'extra').length === 3, 'Vega ultime : action supplémentaire pour les 3 alliés');
  ok(ev.filter(e => e.type === 'attack').length >= 2, 'Vega ultime : les alliés agissent immédiatement');

  // Xanor — Halo protecteur : -5 % de dégâts subis
  d = duel('xanor', ['steel_golem'], { allies: ['zyra'], mode: 'manual' });
  ok(d.team.every(u => Math.abs(u.teamShieldMult - 0.95) < 1e-9), 'Xanor : -5 % de dégâts subis pour toute l\'équipe');

  // Aeon — Éternité : réanimation unique
  d = duel('aeon', ['steel_golem'], { allies: ['zyra', 'korvax'], mode: 'manual' });
  var victim = d.allies[0];
  victim.hp = 1; victim.shield = 0;
  d.eng.applyDamage(d.foes[0], victim, 3.0, { noCrit: true });
  ev = d.eng.consumeEvents();
  ok(victim.alive && ev.some(e => e.type === 'revive') && !ev.some(e => e.type === 'death'), 'Aeon : ramène un allié tombé au combat');
  ok(victim.hp >= Math.round(victim.maxHp * 0.3) - 1, 'Aeon : l\'allié revient avec 30 % de ses PV');
  victim.hp = 1;
  d.eng.applyDamage(d.foes[0], victim, 3.0, { noCrit: true });
  ok(!victim.alive, 'Aeon : la réanimation ne fonctionne qu\'une fois par combat');

  // Targon — Rempart : insensible à l'étourdissement au-dessus de 30 % de PV
  d = duel('targon', ['steel_golem'], { mode: 'manual' });
  d.eng._stun(d.foes[0], d.hero, 2);
  ok(d.hero.stunTime === 0, 'Targon : immunisé à l\'étourdissement (PV > 30 %)');
  d.hero.hp = Math.round(d.hero.maxHp * 0.2);
  d.eng._stun(d.foes[0], d.hero, 2);
  ok(d.hero.stunTime > 0, 'Targon : étourdissable sous 30 % de PV');

  // Targon — Coup de masse : gros dégâts + étourdissement
  d = duel('targon', ['steel_golem'], { mode: 'manual' });
  fireSkill(d, true);
  ev = step(d.eng, 0.3);
  ok(ev.some(e => e.type === 'stun') && ev.some(e => e.type === 'damage'), 'Targon ultime : dégâts + étourdissement');

  // Elys — premier coup toujours critique ; Lame de givre ralentit
  d = duel('elys', ['steel_golem'], { mode: 'auto' });
  d.hero.gauge = 100; d.hero.skillCooldown = 999;
  d.eng.update(0.01);
  var firstHit = d.eng.consumeEvents().filter(e => e.type === 'damage')[0];
  ok(firstHit && firstHit.crit, 'Elys : le premier coup est toujours critique');
  d = duel('elys', ['steel_golem'], { mode: 'manual' });
  var golemSpd = d.eng._effSpeed(d.foes[0]);
  fireSkill(d, false); step(d.eng, 0.2);
  ok(d.eng._effSpeed(d.foes[0]) < golemSpd * 0.9, 'Elys : Lame de givre ralentit la cible');

  // Rexar / Lumina — régénération passive à chaque tour
  d = duel('lumina', ['steel_golem'], { allies: ['korvax'], mode: 'auto' });
  d.hero.skillCooldown = 999; d.allies[0].hp = Math.round(d.allies[0].maxHp * 0.5);
  var hp0 = d.allies[0].hp;
  d.hero.gauge = 100; d.eng.update(0.01);
  ok(d.allies[0].hp > hp0, 'Lumina : Aura bienveillante régénère les alliés à chaque tour');

  // Kael — bonus par ennemi ; Orion — ignore la défense ; Selene — cibles isolées
  d = duel('kael', ['steel_golem', 'steel_golem', 'steel_golem'], { mode: 'auto' });
  var dmgMany = 0, dmgOne = 0;
  var target = d.foes[0];
  for (var z = 0; z < 200; z++) { var r = d.eng.applyDamage(d.hero, target, 1, { noCrit: true }); target.hp = target.maxHp; target.alive = true; dmgMany += r.amount; }
  d.foes[1].alive = false; d.foes[2].alive = false;
  for (var y = 0; y < 200; y++) { var r2 = d.eng.applyDamage(d.hero, target, 1, { noCrit: true }); target.hp = target.maxHp; target.alive = true; dmgOne += r2.amount; }
  ok(dmgMany > dmgOne, 'Kael : plus de dégâts quand plus d\'ennemis sont en vie (' + dmgMany + ' > ' + dmgOne + ')');
}

section('Ordres du joueur : compétence immédiate en AUTO comme en MANUEL');
{
  var d = duel('zyra', ['steel_golem'], { mode: 'auto' });
  d.hero.skillCooldown = 0;
  d.eng.requestSkill(d.hero.uid);
  d.eng.update(0.02);
  ok(d.eng.consumeEvents().some(e => e.type === 'skill' && e.uid === d.hero.uid), 'AUTO : un appui sur la compétence la lance aussitôt');
  d.eng.requestSkill(d.hero.uid);
  d.eng.update(0.02);
  ok(!d.eng.consumeEvents().some(e => e.type === 'skill'), 'la compétence en recharge ne se relance pas');
  ok(d.hero.skillCooldown > 0 && !d.eng.skillReady(d.hero), 'temps de recharge appliqué');
  ok(d.eng.skillReady(d.foes[0]) === true || d.eng.skillReady(d.foes[0]) === false, 'skillReady est toujours un booléen');
}

section('Rage des ennemis (évite les combats sans fin) et statuts');
{
  var d = duel('korvax', ['steel_golem'], {});
  ok(d.eng.enrageMult() === 1 && !d.eng.isEnraged(), 'pas de rage au début du combat');
  d.eng.time = 250;
  ok(d.eng.enrageMult() > 2 && d.eng.isEnraged(), 'la rage croît au fil du temps (x' + d.eng.enrageMult().toFixed(2) + ' à 250 s)');

  // Combats longs : toujours terminés avant 600 s
  var longTeam = ['zyra', 'korvax', 'lumina', 'drakor', 'selene'].map(id => CE.makeHeroUnit(H.get(id), 1, id));
  var boss = [CE.makeEnemyUnit(EN.get('omega_krell'), 'normal', 0)];
  var eL = new CE.CombatEngine(longTeam, boss, { mode: 'auto' });
  var guard = 0; while (!eL.isOver() && guard++ < 12000) eL.update(0.05);
  ok(eL.isOver(), 'un combat désespéré se termine toujours (rage) : ' + Math.round(eL.time) + ' s');

  // Un ennemi étourdi ne joue pas ; sa jauge est gelée
  var d2 = duel('zyra', ['steel_golem'], {});
  d2.foes[0].stunTime = 2; d2.foes[0].gauge = 50;
  step(d2.eng, 1);
  ok(d2.foes[0].gauge === 50, 'jauge gelée pendant un étourdissement');
}

section('Fragments : tous les héros de l\'équipe en reçoivent, niveaux dérivés');
{
  NEBUSTION.Resources = { state: NEBUSTION.Save.defaultState(Date.now()), add: function () { return 0; }, saveNow: function () { return true; } };
  var C = NEBUSTION.Combat;
  C.setTeam(['zyra', 'korvax', 'lumina', 'drakor', 'selene']);
  var stageDef = EN.stage('boss_vorath');
  var g = C.grantRewards(stageDef, 'normal', { win: true, survivors: 5, totalPlayers: 5, timeSec: 50 });
  ok(g.fragmentHeroes.length === 5, 'les 5 héros reçoivent des fragments');
  ok(g.fragmentHeroes.every(id => NEBUSTION.Resources.state.combat.fragments[id] === g.rewards.fragments), 'chacun reçoit la quantité annoncée (' + g.rewards.fragments + ')');
  ok(C.heroLevel('zyra') === 1 + Math.floor(g.rewards.fragments / C.FRAGMENTS_PER_LEVEL), 'niveau dérivé des fragments');
  ok(Array.isArray(g.levelUps), 'la liste des montées de niveau est fournie');
}

section('CombatManager : échelle de stage appliquée aux ennemis, statistiques réelles des héros');
{
  NEBUSTION.Resources = { state: NEBUSTION.Save.defaultState(Date.now()), add: function (id, a) { return a; }, saveNow: function () { return true; } };
  var C = NEBUSTION.Combat;
  C.setTeam(['zyra', 'korvax', 'lumina', 'drakor', 'selene']);
  NEBUSTION.Resources.state.combat.fragments.zyra = 80; // niveau 11
  var b = C.buildBattle('stage_10', 'difficile', 'auto');
  var st10 = EN.stage('stage_10');
  b.enemyUnits.forEach(function (u, i) {
    var expected = EN.statsForEnemy(EN.get(st10.enemies[i]), 'difficile', st10.scale);
    ok(u.maxHp === expected.hp && u.atk === expected.atk && u.def === expected.def, u.name + ' : stats = difficulté x échelle du stage');
  });
  var zyraUnit = b.playerUnits[0];
  var exp = H.statsAtLevel(H.get('zyra'), 11);
  ok(zyraUnit.level === 11 && zyraUnit.maxHp === exp.hp && zyraUnit.atk === exp.atk && zyraUnit.def === exp.def && zyraUnit.spd === exp.spd, 'Zyra niveau 11 : PV/ATQ/DÉF/VIT = statsAtLevel');
  ok(b.playerUnits.every(u => u.activeName && u.ultimateName && u.hasKit), 'chaque héros porte le nom de ses vraies compétences et un kit');
  var g = C.grantRewards(EN.stage('stage_01'), 'normal', { win: true, survivors: 5, totalPlayers: 5, timeSec: 12 });
  ok(g.granted && g.granted.crystal > 0 && g.xp === g.rewards.xp, 'grantRewards renvoie les quantités réellement créditées');
}

console.log('\n' + (failed === 0 ? '✔ TESTS COMBAT OK' : '✘ ÉCHECS DÉTECTÉS') + '  (' + passed + ' vérifications' + (failed ? ', ' + failed + ' échecs' : '') + ')');
process.exitCode = failed === 0 ? 0 : 1;
