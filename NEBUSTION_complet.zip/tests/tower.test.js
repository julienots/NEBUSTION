/* NEBUSTION - test de la Tour de relais (bonus de production réel).  Lancer : node tests/tower.test.js */
global.window = global;
global.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} };
var path = require('path'), root = path.join(__dirname, '..');
['js/data/Economy.js', 'js/data/PlanetBuild.js', 'js/systems/SaveManager.js', 'js/systems/ResourceManager.js'].forEach(function (f) {
  try { require(path.join(root, f)); } catch (e) { console.log('chargement ' + f + ' : ' + e.message); process.exit(2); }
});
var N = NEBUSTION, PB = N.PlanetBuild, fails = 0, checks = 0;
function ok(c, msg) { checks++; if (!c) { fails++; console.log('ÉCHEC : ' + msg); } }

var R = new N.ResourceManager({ Economy: N.Economy, Save: N.Save });
R.state = N.Save.normalize(null, Date.now());
R.state.planetBuild = PB.defaultState();
R.saveNow = function () {};
['crystal', 'metal', 'energy', 'dust'].forEach(function (id) { R.state.res[id] = 0; });

var def = PB.CATALOG.tower;
ok(!!def && PB.ORDER.indexOf('tower') >= 0, 'la tour est dans le catalogue');
ok(Object.keys(def.base).length <= 2, 'la tour n\'affiche que 2 ressources de coût (limite de la carte du catalogue)');

var base = R.rates().metal;
ok(base > 0, 'production de base > 0');
ok(PB.productionBonus(R.state.planetBuild) === 0, 'aucun bonus sans tour');

var r = PB.place(R, 'tower', 0, 0, []);
ok(!r.ok && r.reason === 'cost', 'refusée sans ressources');

R.state.res.metal = 1e5; R.state.res.energy = 1e5;
R.rates();   // remplit le cache : la pose doit l'invalider
r = PB.place(R, 'tower', 10, 10, []);
ok(r.ok, 'posée avec les ressources');
ok(R._rates === null, 'cache de production invalidé à la pose');
var after = R.rates().metal;
var mult0 = 1 + 0; // le multiplicateur de base est le même avant/après ; on compare le rapport
ok(Math.abs(after / base - 1.03) < 1e-6, 'production augmentée après la pose (' + base.toFixed(4) + ' → ' + after.toFixed(4) + ')');

for (var i = 1; i < 4; i++) { var rr = PB.place(R, 'tower', 10 + i * 40, 10, []); ok(rr.ok, 'tour ' + (i + 1) + ' posée'); }
ok(PB.count(R.state.planetBuild, 'tower') === 4, '4 tours posées');
ok(Math.abs(PB.productionBonus(R.state.planetBuild) - 0.12) < 1e-9, 'bonus = +12 % avec 4 tours');
var r5 = PB.place(R, 'tower', -120, 10, []);
ok(!r5.ok && r5.reason === 'max', '5e tour refusée (maximum 4)');
var full = R.rates().metal;
ok(full > after, 'plus de tours = plus de production');

var c1 = PB.cost('tower', 0), c2 = PB.cost('tower', 1);
ok(c2.metal > c1.metal, 'le coût augmente à chaque exemplaire');

var id = R.state.planetBuild.items[R.state.planetBuild.items.length - 1].id;
R.rates(); var rc = PB.recycle(R, id);
ok(rc.ok && R._rates === null, 'recyclage invalide le cache');
ok(Math.abs(PB.productionBonus(R.state.planetBuild) - 0.09) < 1e-9, 'bonus = +9 % après recyclage');

// sauvegarde corrompue : 6 tours → 4 gardées ; type inconnu écarté
var raw = { items: [] };
for (i = 0; i < 6; i++) raw.items.push({ id: 't' + i, type: 'tower', lon: i * 30, lat: 0 });
raw.items.push({ id: 'x', type: 'inconnu', lon: 0, lat: 0 });
var n = PB.normalizeState(raw);
ok(PB.count(n, 'tower') === 4 && n.items.length === 4, 'sauvegarde normalisée : max 4 tours, type inconnu retiré');
ok(PB.productionBonus(null) === 0 && PB.productionBonus({}) === 0, 'productionBonus tolère un état absent');

console.log(checks + ' vérifications, ' + fails + ' échec(s)');
process.exit(fails ? 1 : 0);
