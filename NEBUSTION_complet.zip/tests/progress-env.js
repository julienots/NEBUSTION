/* Environnement commun des tests de l'étape 10 (expéditions, événements, Renaissance, succès), Node, sans Phaser.
 * Charge les fichiers dans l'ordre d'index.html, branche un stockage mémoire et une horloge pilotable. */
'use strict';
global.window = global;
const FILES = ['data/Economy', 'data/Heroes', 'data/Enemies', 'data/CombatItems', 'data/Galaxy', 'data/EmpireAI', 'data/EmpireDoctrine', 'data/EmpireEvolution', 'data/Equipment', 'data/Ships', 'data/Skins', 'data/Shop', 'data/Pass',
  'data/Expeditions', 'data/Events', 'data/Prestige', 'data/Achievements', 'data/Security', 'data/QGGrid', 'data/BotBases', 'data/Troops', 'data/QGBattle',
  'data/Nebustion',
  'systems/SaveManager', 'systems/ResourceManager', 'systems/CombatEngine', 'systems/CombatManager', 'systems/EquipmentManager', 'systems/ShipManager', 'systems/SkinManager', 'systems/ShopManager',
  'systems/PassBilling', 'systems/PassManager', 'systems/ExpeditionManager', 'systems/EventManager', 'systems/PrestigeManager', 'systems/AchievementsManager', 'systems/SecurityManager', 'systems/QGGridManager', 'systems/TroopManager',
  'systems/NebustionManager'];
FILES.forEach(f => require('../js/' + f + '.js'));

const realNow = Date.now.bind(Date);
let fake = null;
Date.now = () => (fake === null ? realNow() : fake);

function makeCounter() {
  const c = { passed: 0, failed: 0 };
  c.ok = (cond, msg) => { if (cond) c.passed++; else { c.failed++; console.log('  ✗ ECHEC : ' + msg); } };
  c.section = t => console.log('\n# ' + t);
  c.done = label => {
    console.log('\n' + (c.failed ? '✘ ' : '✔ ') + label + ' : ' + c.passed + ' réussis, ' + c.failed + ' échoués');
    process.exit(c.failed ? 1 : 0);
  };
  return c;
}

/** Nouvelle partie propre (stockage vide). */
function freshGame() {
  const store = { _m: {}, getItem(k) { return this._m[k] || null; }, setItem(k, v) { this._m[k] = v; }, removeItem(k) { delete this._m[k]; } };
  NEBUSTION.Save._useStorage(store);
  NEBUSTION.EventManager._reset();
  NEBUSTION.Resources = new NEBUSTION.ResourceManager();
  NEBUSTION.Resources.init(Date.now());
  return { store, R: NEBUSTION.Resources };
}
/** Donne `n` étoiles de Combat (3 par étape fictive). */
function giveStars(n) {
  const ss = {}; let left = n, i = 0;
  while (left > 0) { const v = Math.min(3, left); ss['t' + (i++)] = v; left -= v; }
  NEBUSTION.Resources.state.combat.stageStars = ss;
}
/** Fixe le niveau d'un héros (1 niveau / 8 fragments). */
function setLevel(id, lvl) { NEBUSTION.Resources.state.combat.fragments[id] = NEBUSTION.Combat.FRAGMENTS_PER_LEVEL * (lvl - 1); }
/** Identifiants de héros utilisables d'emblée (hors exclusivités Boutique). */
function freeHeroes() { return NEBUSTION.Heroes.all().filter(h => !h.shop).map(h => h.id); }
/** Horloge : local(y, m0, d, h) → timestamp ; setNow(t) fige Date.now, setNow(null) le libère. */
const local = (y, m, d, h) => new Date(y, m, d, h === undefined ? 12 : h, 0, 0).getTime();
const setNow = t => { fake = t; };

module.exports = { makeCounter, freshGame, giveStars, setLevel, freeHeroes, local, setNow, realNow };
