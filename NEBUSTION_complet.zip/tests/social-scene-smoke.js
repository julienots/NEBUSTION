/* NEBUSTION - test de fumée de SocialScene (faux Phaser, sans réseau).  node tests/social-scene-smoke.js */
global.window = global; global.NEBUSTION = {};
var fails = 0, checks = 0; function ok(c, m) { checks++; if (!c) { fails++; console.log('ÉCHEC : ' + m); } }
var texts = [], buttons = [], doms = [];
function obj(extra) {
  var store = Object.assign({ height: 22, width: 120, x: 0, y: 0, visible: true, list: [], input: { hitArea: {} } }, extra || {});
  var p = new Proxy(function () {}, {
    get: function (t, k) { if (k === 'then') return undefined; if (k === Symbol.toPrimitive) return function () { return 0; }; if (k in store) return store[k]; return function () { return p; }; },
    set: function (t, k, v) { store[k] = v; return true; }, apply: function () { return p; }
  });
  return p;
}
global.Phaser = { Scene: class { constructor(key) { this.sys = { settings: { key: key }, game: { canvas: { getBoundingClientRect: function () { return { left: 0, top: 0, width: 720, height: 1280 }; } } } }; } },
  Display: { Color: { HSLToColor: function () { return { color: 0x55aa88 }; } } }, Geom: { Rectangle: { Contains: function () { return true; } } }, GameObjects: {} };
global.document = { createElement: function () { var el = { style: {}, value: '', addEventListener: function () {}, parentNode: null }; doms.push(el); return el; }, body: { appendChild: function (e) { e.parentNode = { removeChild: function () { e.gone = true; } }; } } };
NEBUSTION.Button = function (scene, x, y, cfg) { var o = obj({ labelText: obj(), cfg: cfg }); buttons.push({ cfg: cfg, o: o }); return o; };
NEBUSTION.HUD = { attach: function () { return obj(); } }; NEBUSTION.FX = function () { return { toast: function (t, s) { NEBUSTION.__toasts.push(t + '|' + s); } }; }; NEBUSTION.__toasts = [];
NEBUSTION.SceneBackground = { build: function () {} };
// jeu réel : données + manager
var res = { crystal: 6000, metal: 500, energy: 500, dust: 50, core: 0 };
NEBUSTION.Resources = { state: {}, level: function () { return 5; }, canAfford: function (c) { return Object.keys(c).every(function (k) { return res[k] >= c[k]; }); }, spend: function (k, n) { res[k] -= n; return true; }, add: function (k, n) { res[k] += n; return n; }, isFull: function () { return false; }, _dirtyNow: function () {} };
NEBUSTION.ShipManager = { fleetPower: function () { return 3000; } };
require('../js/data/Social.js'); require('../js/systems/SocialManager.js'); require('../js/scenes/SocialScene.js');
var sc = new NEBUSTION.SocialScene(); sc.scale = { width: 720, height: 1280, on: function () {}, off: function () {} };
sc.add = { text: function (x, y, s) { texts.push(String(s)); return obj({ text: s }); }, graphics: function () { return obj(); }, container: function () { return obj(); }, zone: function () { return obj(); }, rectangle: function () { return obj(); }, existing: function () {} };
sc.make = { graphics: function () { return obj(); } }; sc.cameras = { main: obj() }; sc.input = { on: function (ev, fn) { (sc._ev = sc._ev || {})[ev] = fn; } }; sc.tweens = obj(); sc.time = obj();
sc.events = { once: function () {} }; sc.scene = { start: function (k) { sc._started = k; } };
function tick() { return new Promise(function (r) { setTimeout(r, 15); }); }
function has(s) { return texts.some(function (t) { return t.indexOf(s) >= 0; }); }
function btn(label) { for (var i = buttons.length - 1; i >= 0; i--) if (buttons[i].cfg.label && buttons[i].cfg.label.indexOf(label) >= 0) return buttons[i]; return null; }
(async function () {
  sc.init({ returnTo: 'MainMenuScene' }); sc.create(); await tick();
  ok(has('SOCIAL') && sc.tab === 'chat', 'scène créée, onglet Chat'); ok(sc.chat, 'chat démarré'); ok(sc.contentH > 100, 'messages du chat dessinés (hauteur ' + sc.contentH + ')'); ok(sc.regions.length > 3, 'noms cliquables');
  ['players', 'clan', 'friends', 'chat'].forEach(function () {});
  texts.length = 0; sc._setTab('players'); await tick(); ok(sc.regions.length >= 100 && has('en ligne'), 'onglet Joueurs : ' + sc.regions.length + ' lignes');
  sc.filter = 'online'; sc._render(); await tick(); var nOn = sc.regions.length; ok(nOn > 5 && nOn < 160, 'filtre en ligne (' + nOn + ')');
  // tap sur le premier joueur → fiche
  sc.filter = 'all'; sc._render(); await tick(); var r0 = sc.regions[0]; sc._tap(300, r0.y0 + 10); await tick(); ok(sc.modal, 'fiche joueur ouverte'); ok(btn('Ajouter en ami') && btn('Cadeau') && btn('Duel amical'), 'boutons de la fiche');
  btn('Ajouter en ami').cfg.onClick(); ok(NEBUSTION.SocialManager.state().friends.length === 1, 'ami ajouté via l\'interface');
  var c0 = res.crystal; btn('Cadeau').cfg.onClick(); await tick(); ok(res.crystal === c0 - 100, 'cadeau via l\'interface');
  btn('Duel amical').cfg.onClick(); ok(NEBUSTION.SocialManager.state().duels.n === 1, 'duel via l\'interface'); btn('Fermer').cfg.onClick(); ok(!sc.modal, 'fiche fermée');
  // Amis
  sc._setTab('friends'); await tick(); ok(has('MES AMIS (1)'), 'onglet Amis'); 
  // Clan : liste, détail, rejoindre
  sc._setTab('clan'); await tick(); ok(sc.regions.length === 14 && btn('Créer un clan'), '14 clans listés + bouton créer'); sc._tap(300, sc.regions[0].y0 + 10); await tick(); ok(sc.modal && btn('Rejoindre'), 'détail du clan');
  btn('Rejoindre').cfg.onClick(); await tick(); await tick(); ok(NEBUSTION.SocialManager.myClan(), 'clan rejoint via l\'interface'); ok(!sc.modal, 'modale fermée après adhésion');
  ok(btn('Coffre du jour') && btn('Donner') && btn('Quitter'), 'vue « mon clan »'); ok(sc.regions.length >= 3, 'membres listés (' + sc.regions.length + ')');
  var cb = btn('Coffre du jour').cfg; var c1 = res.crystal; cb.onClick(); ok(res.crystal > c1, 'coffre du clan réclamé');
  sc.clanSub = 'chat'; sc._render(); await tick(); await tick(); ok(sc.chat && sc.contentH > 60, 'discussion du clan (' + sc.contentH + ')');
  sc.dom.chat.value = 'salut le clan'; sc._sendChat(); await tick(); ok(sc.dom.chat.value === '', 'message de clan envoyé');
  btn('Quitter').cfg.onClick(); ok(sc.modal, 'confirmation avant de quitter'); btn('Rester').cfg.onClick(); ok(NEBUSTION.SocialManager.myClan(), 'toujours dans le clan');
  btn('Quitter').cfg.onClick(); btn('Quitter').cfg.onClick && 0; var q = buttons.filter(function (b) { return b.cfg.label === 'Quitter'; }).pop(); q.cfg.onClick(); await tick(); await tick(); ok(!NEBUSTION.SocialManager.myClan(), 'clan quitté');
  // Création de clan hors compte → message
  sc.clanSub = 'members'; sc._render(); await tick(); btn('Créer un clan').cfg.onClick(); ok(sc.modal, 'fenêtre de création'); ok(sc._domY.name !== undefined && sc._domY.tag !== undefined, 'champs nom/tag affichés');
  sc.dom.name.value = 'Mon Clan'; sc.dom.tag.value = 'mc'; btn('Créer').cfg.onClick(); await tick(); ok(sc.modal && !NEBUSTION.SocialManager.myClan(), 'création refusée hors compte'); btn('Annuler').cfg.onClick(); ok(!sc.modal && sc._domY.name === undefined, 'annulation : champs masqués');
  // fermeture
  sc._close(); ok(sc._domY.chat === undefined, 'champs masqués à la fermeture'); sc._onShutdown(); ok(sc.chat === null && doms.every(function (d) { return d.gone; }), 'nettoyage : champs DOM retirés + chat arrêté');
  console.log(checks + ' vérifications, ' + fails + ' échec(s)'); process.exit(fails ? 1 : 0);
})().catch(function (e) { console.log('EXCEPTION', e && e.stack || e); process.exit(2); });
