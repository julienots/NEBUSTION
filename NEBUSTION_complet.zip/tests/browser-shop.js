/*
 * Test navigateur de la BOUTIQUE (Chromium/Playwright + FAUX Phaser, donc mise en page/logique/entrées, PAS de WebGL).
 * Parcourt le vrai chemin joueur : menu → barre de navigation « Boutique » → 5 onglets → glisser → tap → confirmation → achat.
 * Régression visée : ShopScene non enregistrée dans main.js (écran noir). NODE_PATH=$(npm root -g) node tests/browser-shop.js [dossier_captures]
 */
const http = require('http'), fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const root = path.join(__dirname, '..'), out = process.argv[2] || '/tmp/shots_shop';
fs.mkdirSync(out, { recursive: true });
const mock = fs.readFileSync(path.join(__dirname, 'mock-phaser.js'), 'utf8');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]);
  if (u === '/js/vendor/phaser.min.js') { res.writeHead(200, { 'Content-Type': 'text/javascript' }); return res.end(mock); }
  const f = path.join(root, u === '/' ? 'index.html' : u);
  if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('nf'); }
  res.writeHead(200, { 'Content-Type': mime[path.extname(f)] || 'application/octet-stream' }); res.end(fs.readFileSync(f));
});
let passed = 0, failed = 0;
const ok = (c, m) => { if (c) passed++; else { failed++; console.log('  ✗ ' + m); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  await new Promise(r => server.listen(8771, r));
  const browser = await chromium.launch();
  const page = await (await browser.newContext({ viewport: { width: 390, height: 780 } })).newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console.error: ' + m.text()); });
  const R = e => page.evaluate(e);
  const S = 'window.__NEBUSTION_GAME__.scenes.ShopScene';
  async function waitScene(key, ms) {
    const t0 = Date.now();
    while (Date.now() - t0 < (ms || 15000)) { if (await R(`!!__NEBUSTION_GAME__.scene.isActive('${key}')`)) return true; await sleep(100); }
    return false;
  }
  async function shot(name) {
    const data = await R(`(() => { const c = document.createElement('canvas'); c.width = 720; c.height = 1280; Phaser._render(${S}, c.getContext('2d'), 720, 1280); return c.toDataURL('image/png'); })()`);
    fs.writeFileSync(path.join(out, name + '.png'), Buffer.from(data.split(',')[1], 'base64'));
  }
  // Toucher via la vraie zone de liste (depth 41) : pointerdown → (pointermove) → pointerup.
  const zoneTap = (x, y) => R(`(() => { const s = ${S}; const z = s._display.find(o => o._interactive && o.depth === 41); z.emit('pointerdown', {x:${x},y:${y}}); z.emit('pointerup', {x:${x},y:${y}}); })()`);
  const drag = (x, y0, y1) => R(`(() => { const s = ${S}; const z = s._display.find(o => o._interactive && o.depth === 41); z.emit('pointerdown', {x:${x},y:${y0}}); s.input.emit('pointermove', {x:${x},y:${y1}}); z.emit('pointerup', {x:${x},y:${y1}}); s.input.emit('pointerup', {x:${x},y:${y1}}); })()`);
  const tapModal = idx => R(`(() => { const s = ${S}; const h = s._modal.hits[${idx}]; const dim = s._modal.dim; dim.emit('pointerup', {x: h.x + h.w/2, y: h.y + h.h/2}); })()`);
  const modalOpen = () => R(`!!${S}._modal`);
  // Amène la carte n au centre de la liste puis renvoie les coordonnées de son 1er bouton.
  const cardBtn = (n, hi) => R(`(() => { const s = ${S}; const c = s._cards[${n}]; const h = c._hits[${hi || 0}];
    const view = s.listBottom - s.listTop; s.scrollY = Math.max(0, Math.min(s.maxScroll, c.y + h.y - view / 2)); s.listContainer.y = s.listTop - s.scrollY;
    return { x: 12 + h.x + h.w / 2, y: s.listContainer.y + c.y + h.y + h.h / 2 }; })()`);
  const tabTap = id => R(`(() => { const s = ${S}; const idx = s._tabDraw.findIndex(t => t.id === '${id}'); const zones = s.tabsBar.list.filter(o => o._interactive); zones[idx].emit('pointerup', {}); })()`);
  const state = () => R(`(() => { const R = NEBUSTION.Resources, SM = NEBUSTION.ShopManager; return { gems: SM.gems(), dust: R.state.res ? 0 : 0, tab: ${S}.tab }; })()`);

  console.log('# Enregistrement + navigation réelle');
  await page.goto('http://localhost:8771/index.html?debug=1');
  ok(await waitScene('MainMenuScene'), 'MainMenuScene atteinte');
  ok(await R(`!!__NEBUSTION_GAME__.scenes.ShopScene`), 'ShopScene est enregistrée dans main.js (régression écran noir)');
  await R(`(() => { const R = NEBUSTION.Resources; ['metal','core','crystal','energy','dust'].forEach(id => R.add(id, 200000, 'test')); NEBUSTION.ShopManager.gems(); })()`);
  await R(`(() => { const sc = __NEBUSTION_GAME__.scenes[Object.keys(__NEBUSTION_GAME__.active)[0]]; const nav = sc._display.find(o => o.activeKey !== undefined); const zones = nav.list.filter(o => o._interactive); zones[4].emit('pointerdown', {}); })()`);
  ok(await waitScene('ShopScene', 4000), 'tap sur « Boutique » de la barre de navigation ouvre ShopScene');
  await sleep(500);
  ok(errors.length === 0, 'aucune erreur à l\'ouverture : ' + errors.join(' | '));
  const nCards = await R(`${S}._cards.length`);
  ok(nCards >= 4, 'onglet Quotidien : cartes affichées (' + nCards + ')');
  await shot('1_quotidien');

  console.log('# 5 onglets');
  for (const [id, min] of [['heroes', 2], ['equipment', 6], ['skins', 1], ['event', 1], ['daily', 4]]) {
    await tabTap(id); await sleep(450);
    ok(await R(`${S}.tab`) === id, 'onglet ' + id + ' actif');
    ok(await R(`${S}._cards.length`) >= min, 'onglet ' + id + ' : cartes (' + await R(`${S}._cards.length`) + ')');
    ok(errors.length === 0, 'aucune erreur sur ' + id + ' : ' + errors.join(' | '));
    if (id !== 'daily') await shot('2_' + id);
  }

  console.log('# Glisser (scroll) ne déclenche PAS d\'achat');
  await tabTap('skins'); await sleep(400);
  await R(`${S}.scrollY = 0; ${S}.listContainer.y = ${S}.listTop`);
  await drag(360, 700, 400);
  ok(await R(`${S}.scrollY`) > 200, 'le glissement fait défiler la liste (scrollY=' + await R(`${S}.scrollY`) + ')');
  ok(!(await modalOpen()), 'un glissement n\'ouvre pas de confirmation');
  await drag(360, 400, 900);
  ok(await R(`${S}.scrollY`) === 0, 'retour en haut de liste');
  await tabTap('daily'); await sleep(400);

  console.log('# Quotidien : cadeau gratuit puis achat avec confirmation');
  let g0 = await R(`NEBUSTION.ShopManager.gems()`);
  let p = await cardBtn(0); await zoneTap(p.x, p.y);
  ok((await R(`NEBUSTION.ShopManager.gems()`)) === g0 + 12, 'cadeau quotidien : +12 Prismes');
  ok(await R(`!NEBUSTION.ShopManager.giftAvailable()`), 'cadeau marqué réclamé');
  // Offre suivante (index 1) — payable avec les ressources de test.
  const before = await R(`JSON.stringify(NEBUSTION.Resources.state.shop.purchasedToday)`);
  p = await cardBtn(1); await zoneTap(p.x, p.y); await sleep(250);
  ok(await modalOpen(), 'tap « Acheter » ouvre la confirmation');
  ok(await R(`JSON.stringify(NEBUSTION.Resources.state.shop.purchasedToday)`) === before, 'rien n\'est acheté avant confirmation');
  await shot('3_confirmation');
  await tapModal(0); await sleep(300);
  ok(!(await modalOpen()), 'Annuler ferme la confirmation');
  ok(await R(`JSON.stringify(NEBUSTION.Resources.state.shop.purchasedToday)`) === before, 'Annuler n\'achète rien');
  p = await cardBtn(1); await zoneTap(p.x, p.y); await sleep(250);
  const gemsBefore = await R(`NEBUSTION.ShopManager.gems()`);
  await tapModal(1); await sleep(400);
  ok(!(await modalOpen()), 'Confirmer ferme la confirmation');
  ok(await R(`Object.keys(NEBUSTION.Resources.state.shop.purchasedToday).length`) === 1, 'Confirmer achète l\'offre');
  ok(errors.length === 0, 'aucune erreur après achat : ' + errors.join(' | '));
  await shot('4_apres_achat');

  console.log('# Fonds insuffisants : confirmation bloquée, rien n\'est débité');
  await R(`(() => { const R = NEBUSTION.Resources; ['metal','core','crystal','energy','dust'].forEach(id => { const v = R.get(id); if (v > 0) R.spend(id, v); }); NEBUSTION.Resources.state.shop.gems = 0; })()`);
  await tabTap('skins'); await sleep(400);
  const own0 = await R(`NEBUSTION.Skins.SKINS.filter(s => NEBUSTION.SkinManager.isOwned(s.id)).length`);
  p = await cardBtn(0); await zoneTap(p.x, p.y); await sleep(250);
  ok(await modalOpen(), 'confirmation ouverte même sans fonds (le joueur voit le prix)');
  await tapModal(1); await sleep(300);
  ok(await modalOpen(), 'Confirmer est sans effet sans fonds (la fenêtre reste ouverte)');
  ok((await R(`NEBUSTION.Skins.SKINS.filter(s => NEBUSTION.SkinManager.isOwned(s.id)).length`)) === own0, 'aucun skin acheté sans fonds');
  await tapModal(0); await sleep(300);
  ok(!(await modalOpen()), 'Annuler ferme la fenêtre');

  console.log('# Héros / Équipement / Skins / Événement : achats');
  await R(`(() => { const R = NEBUSTION.Resources; ['metal','core','crystal','energy','dust'].forEach(id => R.add(id, 500000, 'test')); NEBUSTION.Resources.state.shop.gems = 5000; })()`);
  await tabTap('heroes'); await sleep(400);
  await R(`(() => { ${S}.heroIndex = 0; ${S}._render(false); })()`); await sleep(200);   // héros d'origine (débloqué) : paquets de fragments
  const idx0 = await R(`${S}.heroIndex`);
  p = await cardBtn(0, 1); await zoneTap(p.x, p.y); await sleep(200);
  ok(await R(`${S}.heroIndex`) !== idx0, 'flèche › change de héros');
  const heroId = await R(`NEBUSTION.Heroes.all()[${S}.heroIndex].id`);
  const lvl0 = await R(`NEBUSTION.Combat.heroLevel('${heroId}')`);
  p = await cardBtn(3); await zoneTap(p.x, p.y); await sleep(250); await tapModal(1); await sleep(400);
  ok((await R(`NEBUSTION.Combat.heroLevel('${heroId}')`)) >= lvl0, 'paquet de fragments acheté');
  ok(errors.length === 0, 'aucune erreur (héros) : ' + errors.join(' | '));

  await tabTap('equipment'); await sleep(400);
  const eq0 = await R(`NEBUSTION.EquipmentManager.list().length`);
  p = await cardBtn(0, 1); await zoneTap(p.x, p.y); await sleep(200);
  ok(await R(`${S}.equipRarity`) === 'epique', 'puce Épique sélectionnée');
  p = await cardBtn(2); await zoneTap(p.x, p.y); await sleep(250); await tapModal(1); await sleep(400);
  ok((await R(`NEBUSTION.EquipmentManager.list().length`)) === eq0 + 1, 'équipement acheté (inventaire +1)');
  await shot('5_equipement');

  await tabTap('skins'); await sleep(400);
  const skinsOwnedBefore = await R(`NEBUSTION.Skins.SKINS.filter(s => NEBUSTION.SkinManager.isOwned(s.id)).length`);
  p = await cardBtn(0); await zoneTap(p.x, p.y); await sleep(250); await tapModal(1); await sleep(400);
  ok((await R(`NEBUSTION.Skins.SKINS.filter(s => NEBUSTION.SkinManager.isOwned(s.id)).length`)) === skinsOwnedBefore + 1, 'skin acheté');
  await shot('6_skins');

  await tabTap('event'); await sleep(400);
  ok(await R(`!NEBUSTION.ShopManager.isEventBought()`), 'offre événement non achetée au départ');
  p = await cardBtn(0); await zoneTap(p.x, p.y); await sleep(250); await tapModal(1); await sleep(400);
  ok(await R(`NEBUSTION.ShopManager.isEventBought()`), 'offre événementielle achetée');
  await sleep(400); await shot('7_evenement_achete');
  ok(errors.length === 0, 'aucune erreur finale : ' + errors.join(' | '));

  console.log('# Retour menu puis Boutique (pas de fuite / d\'écran noir)');
  await R(`(() => { const sc = ${S}; const nav = sc._display.find(o => o.activeKey !== undefined); const zones = nav.list.filter(o => o._interactive); zones[0].emit('pointerdown', {}); })()`);
  ok(await waitScene('PlanetScene', 4000), 'navigation vers Planète');
  await R(`(() => { const sc = __NEBUSTION_GAME__.scenes.PlanetScene; const nav = sc._display.find(o => o.activeKey !== undefined); const zones = nav.list.filter(o => o._interactive); zones[4].emit('pointerdown', {}); })()`);
  ok(await waitScene('ShopScene', 4000), 'retour dans la Boutique depuis Planète');
  await sleep(400);
  ok(errors.length === 0, 'aucune erreur au retour : ' + errors.join(' | '));

  await browser.close(); server.close();
  console.log(`\nRésultat : ${passed} OK, ${failed} échec(s). Captures : ${out}`);
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error('Test interrompu :', e); process.exit(2); });
