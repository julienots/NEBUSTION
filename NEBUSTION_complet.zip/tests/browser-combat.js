/*
 * Test de fumée du MODULE COMBAT dans un vrai Chromium (Playwright) avec le FAUX Phaser (tests/mock-phaser.js) :
 * chargeur index.html, textures ennemies (Canvas 2D réel), écran de préparation, lancement, combat complet
 * (attaques, compétences, ultimes, boss/phases), victoire, défaite, abandon, pause, récompenses, sauvegarde,
 * rechargement. Le rendu WebGL réel n'est PAS simulé (voir README).
 *   NODE_PATH=$(npm root -g) node tests/browser-combat.js
 */
const http = require('http'), fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const root = path.join(__dirname, '..');
const mock = fs.readFileSync(path.join(__dirname, 'mock-phaser.js'), 'utf8');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]);
  if (u === '/js/vendor/phaser.min.js') { res.writeHead(200, { 'Content-Type': 'text/javascript' }); return res.end(mock); }
  const f = path.join(root, u === '/' ? 'index.html' : u);
  if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('nf'); }
  res.writeHead(200, { 'Content-Type': mime[path.extname(f)] || 'application/octet-stream' }); res.end(fs.readFileSync(f));
});
let passed = 0, failed = 0;
const ok = (c, m) => { if (c) passed++; else { failed++; console.log('  ✗ ' + m); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  await new Promise(r => server.listen(8766, r));
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 780 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console.error: ' + m.text()); });
  const R = expr => page.evaluate(expr);
  const G = '__NEBUSTION_GAME__.scenes.';
  async function waitScene(key, ms) {
    const t0 = Date.now();
    while (Date.now() - t0 < (ms || 15000)) {
      if (await R(`!!(window.__NEBUSTION_GAME__ && window.__NEBUSTION_GAME__.scene.isActive('${key}'))`)) return true;
      await sleep(100);
    }
    return false;
  }
  async function waitCond(expr, ms) {
    const t0 = Date.now();
    while (Date.now() - t0 < (ms || 30000)) { if (await R(expr)) return true; await sleep(150); }
    return false;
  }
  async function startCombat(stageId, difficulty) {
    await R(`${G}PlaceholderScene && 0; (function(){ var g = __NEBUSTION_GAME__; var cur = Object.keys(g.active)[0]; g.scenes[cur].scene.start('CombatScene', { stageId: '${stageId}', difficulty: '${difficulty || 'normal'}' }); })()`);
    return waitScene('CombatScene');
  }

  console.log('# Chargement & textures');
  await page.goto('http://localhost:8766/index.html?debug=1');
  ok(await waitScene('MainMenuScene'), 'MainMenuScene atteinte');
  ok(errors.length === 0, 'aucune erreur au chargement : ' + errors.join(' | '));
  const texInfo = await R(`(() => { const m = __NEBUSTION_GAME__.textures._map, EN = NEBUSTION.Enemies;
    return { enemies: EN.allEnemies().concat(EN.allBosses()).filter(d => m['tex_enemy_' + d.id]).length,
      fx: ['tex_proj','tex_spark','tex_slash','tex_arena_floor','tex_asteroid_a','tex_asteroid_b','tex_shield_bubble','tex_glow_red','tex_glow_green','tex_glow_orange','tex_glow_ice'].filter(k => m[k]).length,
      boss: m['tex_enemy_vorath'].width }; })()`);
  ok(texInfo.enemies === 13, '13 textures d\'ennemis/boss générées (' + texInfo.enemies + ')');
  ok(texInfo.fx === 11, 'textures d\'effets générées (' + texInfo.fx + '/11)');
  ok(texInfo.boss === 340, 'les boss ont une texture plus grande');
  ok(await R(`NEBUSTION.NAV_ITEMS.find(n => n.key === 'combat').scene`) === 'CombatPrepScene', 'la barre de navigation « Combat » mène à CombatPrepScene');

  console.log('# Écran de préparation');
  await R(`${G}MainMenuScene.scene.start('CombatPrepScene', {})`);
  ok(await waitScene('CombatPrepScene'), 'CombatPrepScene démarrée');
  await sleep(300);
  let prep = await R(`(() => { const s = ${G}CombatPrepScene; return { team: s.team.length, stage: s._stage().id, can: s._canLaunch(), hero: s._pickList.length }; })()`);
  ok(prep.team === 5 && prep.stage === 'stage_01' && prep.can, 'équipe par défaut de 5, stage 1, lancement possible : ' + JSON.stringify(prep));
  ok(prep.hero === 16, 'les 16 héros sont proposés');
  await R(`${G}CombatPrepScene._toggleHero(${G}CombatPrepScene.team[0])`);
  prep = await R(`(() => { const s = ${G}CombatPrepScene; return { team: s.team.length, can: s._canLaunch(), hint: s.hintText.text }; })()`);
  ok(prep.team === 4 && !prep.can && /1 héros/.test(prep.hint), 'retirer un héros bloque le lancement : ' + JSON.stringify(prep));
  await R(`(() => { const s = ${G}CombatPrepScene; s._launch(); })()`);
  await sleep(600);
  ok(!(await R(`__NEBUSTION_GAME__.scene.isActive('CombatScene')`)), 'lancement refusé avec 4 héros');
  await R(`${G}CombatPrepScene._autoTeam()`);
  prep = await R(`(() => { const s = ${G}CombatPrepScene; return { team: s.team, can: s._canLaunch() }; })()`);
  ok(prep.team.length === 5 && new Set(prep.team).size === 5 && prep.can, 'équipe auto : 5 héros distincts');
  ok(await R(`NEBUSTION.Combat.getTeam().length === 5`), 'équipe sauvegardée');
  await R(`${G}CombatPrepScene._moveStage(-1)`);   // dernier stage : verrouillé
  prep = await R(`(() => { const s = ${G}CombatPrepScene; return { id: s._stage().id, can: s._canLaunch(), hint: s.hintText.text }; })()`);
  ok(prep.id === 'boss_omega_krell' && !prep.can && /verrouill/i.test(prep.hint), 'stage suivant verrouillé, lancement refusé : ' + JSON.stringify(prep));
  await R(`${G}CombatPrepScene._launch()`);
  await sleep(500);
  ok(!(await R(`__NEBUSTION_GAME__.scene.isActive('CombatScene')`)), 'un stage verrouillé ne se lance pas');
  await R(`${G}CombatPrepScene._moveStage(1)`);
  await R(`(() => { const s = ${G}CombatPrepScene; s.diffChips.find(c => c.id === 'cauchemar'); })()`);
  await R(`(() => { NEBUSTION.Combat.setDifficulty('difficile'); ${G}CombatPrepScene.difficulty = 'difficile'; ${G}CombatPrepScene._refreshAll(); })()`);
  ok(await R(`NEBUSTION.Combat.getDifficulty()`) === 'difficile', 'difficulté enregistrée');
  await R(`(() => { NEBUSTION.Combat.setDifficulty('normal'); ${G}CombatPrepScene.difficulty = 'normal'; ${G}CombatPrepScene._refreshAll(); })()`);

  console.log('# Combat : stage 1 (victoire)');
  const resBefore = await R(`JSON.stringify(NEBUSTION.Resources.state.res)`);
  await R(`${G}CombatPrepScene._launch()`);
  ok(await waitScene('CombatScene'), 'CombatScene démarrée depuis la préparation');
  await sleep(500);
  const info = await R(`(() => { const s = ${G}CombatScene; return { heroes: s.heroViews.length, enemies: s.enemyViews.length, cards: s.cards.length, floats: s.floats.length,
    mode: s.mode, stage: s.stageId, hpMatch: s.heroViews.every((v, i) => v.unit.hp === s.battle.playerUnits[i].hp) }; })()`);
  ok(info.heroes === 5 && info.enemies === 2 && info.cards === 5 && info.floats === 12 && info.mode === 'auto' && info.stage === 'stage_01', 'arène : 5 héros, 2 ennemis, 5 cartes, réserve de 12 textes : ' + JSON.stringify(info));
  const dispA = await R(`${G}CombatScene._display.length`);
  await R(`${G}CombatScene._cycleSpeed()`); await R(`${G}CombatScene._cycleSpeed()`);
  ok(await R(`${G}CombatScene.speed`) === 3 && await R(`${G}CombatScene.tweens.timeScale`) === 3, 'vitesse ×3 appliquée au moteur et aux animations');
  await sleep(2500);
  const dispB = await R(`${G}CombatScene._display.length`);
  ok(dispB < dispA + 120, 'pas de fuite d\'objets pendant le combat (' + dispA + ' → ' + dispB + ')');
  ok(await R(`${G}CombatScene.engine.time`) > 3, 'le moteur avance');
  ok(await waitCond(`!!${G}CombatScene.resultLayer`, 40000), 'écran de résultat affiché');
  let res = await R(`(() => { const s = ${G}CombatScene, r = s.engine.getResult(); return { win: r.win, stars: s._granted.stars, granted: s._granted.granted, xp: s._granted.rewards.xp,
    won: NEBUSTION.Resources.state.combat.battlesWon, st: NEBUSTION.Resources.state.combat.stageStars.stage_01,
    btn: s.resultLayer.list.filter(o => o.labelText).map(o => o.labelText.text) }; })()`);
  ok(res.win && res.stars >= 1 && res.won === 1 && res.st === res.stars, 'victoire enregistrée : ' + JSON.stringify(res));
  ok(res.btn.includes('REJOUER') && res.btn.includes('STAGE SUIVANT') && res.btn.includes('PRÉPARATION'), 'boutons Rejouer / Stage suivant / Préparation : ' + res.btn.join(','));
  const resAfter = await R(`JSON.stringify(NEBUSTION.Resources.state.res)`);
  ok(JSON.parse(resAfter).crystal > JSON.parse(resBefore).crystal, 'les ressources ont augmenté');
  ok(await R(`NEBUSTION.Resources.state.combat.playerXP`) > 0, 'XP joueur créditée');
  ok(await R(`Object.keys(NEBUSTION.Resources.state.combat.fragments).length`) === 5, 'fragments crédités aux 5 héros');
  await sleep(1500);
  ok(await R(`NEBUSTION.Resources.state.combat.battlesWon`) === 1, 'récompenses créditées UNE seule fois');
  ok(await R(`localStorage.getItem('nebustion_save_v2') !== null`), 'sauvegarde présente');

  console.log('# Stage suivant, mode MANUEL, compétences et ultimes');
  await R(`${G}CombatScene.resultLayer.list.filter(o => o.labelText && /STAGE SUIVANT/.test(o.labelText.text))[0].onClick()`);
  ok(await waitCond(`__NEBUSTION_GAME__.scene.isActive('CombatScene') && ${G}CombatScene.stageId === 'stage_02' && ${G}CombatScene.engine.time < 1`, 8000), 'enchaînement sur le stage 2');
  await sleep(300);
  await R(`${G}CombatScene._toggleMode()`);
  ok(await R(`${G}CombatScene.engine.mode`) === 'manual', 'mode MANUEL activé');
  await R(`(() => { const s = ${G}CombatScene; s.engine.player.forEach(u => { u.skillCooldown = 0; u.energy = 0; u.gauge = 0; }); s.engine.enemy.forEach(u => { u.maxHp = u.hp = 1e7; u.gauge = 0; u.skillCooldown = 999; }); })()`);
  await sleep(400);
  const skillsBefore = await R(`${G}CombatScene.engine.player.map(u => u.skillCooldown)`);
  ok(skillsBefore.every(c => c === 0), 'MANUEL : les compétences prêtes ne partent pas seules');
  await R(`${G}CombatScene._tapSkill(0)`);
  await sleep(300);
  ok(await R(`${G}CombatScene.engine.player[0].skillCooldown`) > 0, 'toucher la compétence la lance (temps de recharge appliqué)');
  await R(`(() => { const s = ${G}CombatScene; s.engine.player[1].energy = 100; })()`);
  await R(`${G}CombatScene._tapUlt(1)`);
  await sleep(500);
  ok(await R(`${G}CombatScene.engine.player[1].energy`) < 100, 'toucher l\'ultime chargé le lance');
  ok(await R(`${G}CombatScene.cards[1].ultTxt`) !== undefined, 'cartes mises à jour');
  await R(`${G}CombatScene._tapUlt(2)`);   // non chargé : sans effet
  // pause
  await R(`${G}CombatScene._setPaused(true)`);
  const t0 = await R(`${G}CombatScene.engine.time`); await sleep(600);
  ok(Math.abs(await R(`${G}CombatScene.engine.time`) - t0) < 1e-6, 'pause : le moteur est figé');
  await R(`${G}CombatScene._setPaused(false)`); await sleep(500);
  ok(await R(`${G}CombatScene.engine.time`) > t0, 'reprise : le moteur repart');
  ok(await R(`${G}CombatScene.floats.filter(f => f._inUse).length`) <= 12, 'réserve de chiffres jamais dépassée');

  console.log('# Abandon (aucune récompense)');
  const wonBefore = await R(`NEBUSTION.Resources.state.combat.battlesWon + NEBUSTION.Resources.state.combat.battlesLost`);
  await R(`${G}CombatScene._abandon()`);
  ok(await waitScene('CombatPrepScene'), 'retour à la préparation');
  ok(await R(`NEBUSTION.Resources.state.combat.battlesWon + NEBUSTION.Resources.state.combat.battlesLost`) === wonBefore, 'abandonner ne compte ni victoire ni défaite');

  console.log('# Boss : phases, barre de boss, victoire');
  ok(await startCombat('boss_vorath', 'facile'), 'CombatScene (boss) démarrée');
  await sleep(500);
  const boss = await R(`(() => { const s = ${G}CombatScene; return { has: !!s.bossView, bar: !!s.bossBarGfx, size: s.bossView && s.bossView.size, phaseTxt: s.bossPhaseText.text }; })()`);
  ok(boss.has && boss.bar && boss.size === 300 && /PHASE 1/.test(boss.phaseTxt), 'boss + barre de boss + phase : ' + JSON.stringify(boss));
  await R(`(() => { const s = ${G}CombatScene, b = s.bossView.unit; s.engine.player.forEach(u => { u.atk = 400; u.hp = u.maxHp = 9999; }); s._cycleSpeed(); s._cycleSpeed(); })()`);
  ok(await waitCond(`${G}CombatScene.bossView.unit.phase >= 1`, 40000), 'le boss entre en phase 2');
  ok(/PHASE 2/.test(await R(`${G}CombatScene.bossPhaseText.text`)), 'l\'indicateur de phase est mis à jour');
  ok(await waitCond(`!!${G}CombatScene.resultLayer`, 90000), 'victoire contre le boss : écran de résultat');
  res = await R(`(() => { const s = ${G}CombatScene; return { win: s.engine.getResult().win, bossDead: s.bossView.dead, frag: s._granted.rewards.fragments, core: s._granted.rewards.core || 0 }; })()`);
  ok(res.win && res.bossDead && res.frag > 0 && res.core > 0, 'boss vaincu, récompenses spéciales (noyaux, fragments) : ' + JSON.stringify(res));

  console.log('# Défaite');
  ok(await startCombat('stage_10', 'cauchemar'), 'CombatScene (stage 10 cauchemar)');
  await sleep(400);
  await R(`(() => { const s = ${G}CombatScene; s.engine.player.forEach(u => { u.hp = 1; u.maxHp = 5; }); s.engine.enemy.forEach(u => { u.atk = 9999; u.spd = 400; }); s._cycleSpeed(); s._cycleSpeed(); })()`);
  const lostBefore = await R(`NEBUSTION.Resources.state.combat.battlesLost`);
  ok(await waitCond(`!!${G}CombatScene.resultLayer`, 40000), 'écran de défaite affiché');
  res = await R(`(() => { const s = ${G}CombatScene; return { win: s.engine.getResult().win, stars: s._granted.stars, lost: NEBUSTION.Resources.state.combat.battlesLost, stageStars: NEBUSTION.Resources.state.combat.stageStars.stage_10 || 0,
    title: s.resultLayer.list.filter(o => o.text && /DÉFAITE/.test(o.text)).length }; })()`);
  ok(!res.win && res.stars === 0 && res.lost === lostBefore + 1 && res.stageStars === 0 && res.title === 1, 'défaite comptée, aucune étoile, stage non validé : ' + JSON.stringify(res));

  console.log('# Rechargement (sauvegarde)');
  const saved = await R(`JSON.stringify({ won: NEBUSTION.Resources.state.combat.battlesWon, lost: NEBUSTION.Resources.state.combat.battlesLost, s1: NEBUSTION.Resources.state.combat.stageStars.stage_01, team: NEBUSTION.Combat.getTeam(), frag: NEBUSTION.Resources.state.combat.fragments })`);
  await R(`NEBUSTION.Resources.saveNow(Date.now())`);
  await page.reload();
  ok(await waitScene('MainMenuScene'), 'redémarrage OK');
  const after = await R(`JSON.stringify({ won: NEBUSTION.Resources.state.combat.battlesWon, lost: NEBUSTION.Resources.state.combat.battlesLost, s1: NEBUSTION.Resources.state.combat.stageStars.stage_01, team: NEBUSTION.Combat.getTeam(), frag: NEBUSTION.Resources.state.combat.fragments })`);
  ok(after === saved, 'progression de combat restaurée après rechargement');

  ok(errors.length === 0, 'aucune erreur JS pendant toute la session : ' + errors.slice(0, 3).join(' | '));
  await browser.close(); server.close();
  console.log('\n' + (failed === 0 ? '✔ TEST DE FUMÉE COMBAT OK' : '✘ ' + failed + ' échec(s)') + ' (' + passed + ' vérifications)');
  process.exit(failed === 0 ? 0 : 1);
})().catch(async e => { console.error('ERREUR TEST :', e); process.exit(2); });
