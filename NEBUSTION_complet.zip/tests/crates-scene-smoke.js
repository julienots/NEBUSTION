global.window = global;
var fs = require('fs'), vm = require('vm');
function load(f) { vm.runInThisContext(fs.readFileSync(require('path').join(__dirname, '..', f), 'utf8'), { filename: f }); }
// --- faux Phaser chaînable (détecte les erreurs de LOGIQUE dans nos scènes ; ne simule ni rendu ni API réelle) ---
function chain() { var f = function () { return p; }; var p = new Proxy(f, { get: function (t, k) { if (k === 'then') return undefined; if (k === Symbol.toPrimitive) return function () { return 0; }; if (k === 'width' || k === 'height' || k === 'x' || k === 'y' || k === 'scaleX' || k === 'scaleY' || k === 'displayWidth') return 10; if (k === 'add' ) return p; return p; }, set: function () { return true; }, apply: function () { return p; } }); return p; }
var calls = { tw: 0 };
global.Phaser = { Scene: class { constructor(k) { this.key = k; var self = this;
  this.add = chain(); this.make = chain(); this.input = chain(); this.cameras = { main: chain() };
  this.scale = { width: 720, height: 1280 };
  this.textures = { exists: function () { return true; } };
  this.tweens = { add: function (c) { calls.tw++; return { stop: function () {}, remove: function () {} }; }, killTweensOf: function () {} };
  this.time = { addEvent: function () { return { remove: function () {} }; }, delayedCall: function (ms, fn) { (self._delayed = self._delayed || []).push(fn); return {}; } };
  this.scene = { start: function (k) { self.started = k; } }; } },
  BlendModes: { ADD: 1 }, Math: { Clamp: function (v, a, b) { return Math.max(a, Math.min(b, v)); } } };
['js/data/Economy.js','js/data/Heroes.js','js/data/Equipment.js','js/data/Ships.js','js/data/Skins.js','js/data/Crates.js','js/data/Shop.js'].forEach(load);
var wallet = { dust: 1e6, crystal: 1e6, energy: 1e6, metal: 1e6, core: 100 };
NEBUSTION.Resources = { state: {}, saveNow: function () {}, canAfford: function (c) { return Object.keys(c).every(function (k) { return (wallet[k] || 0) >= c[k]; }); }, spendMany: function (c) { Object.keys(c).forEach(function (k) { wallet[k] -= c[k]; }); return true; }, add: function (id, a) { return a; } };
NEBUSTION.ShopManager = { addGems: function () {}, canAfford: function () { return true; }, spend: function () { return true; } };
NEBUSTION.Combat = { isUnlocked: function () { return true; }, addFragments: function () { return { ok: true }; } };
NEBUSTION.EquipmentManager = { grant: function (s, r) { return { ok: true, item: { slot: s, rarity: r } }; } };
NEBUSTION.FX = function () { return { toast: function () {}, ring: function () {}, shake: function () {}, vibrate: function () {} }; };
NEBUSTION.HUD = { attach: function () {} }; NEBUSTION.BottomNav = function () {}; NEBUSTION.SceneBackground = { build: function () {} };
NEBUSTION.Settings = { get: function () { return {}; } };
NEBUSTION.SkinFX = null;
load('js/systems/SkinManager.js'); load('js/systems/CrateManager.js');
load('js/ui/SkinFX.js');
// ProgressScene sans NebustionManager & co : progressBadges est try/catch
load('js/scenes/ProgressScene.js'); load('js/scenes/CratesScene.js');
var fails = 0, n = 0; function ok(c, m) { n++; if (!c) { fails++; console.log('FAIL', m); } }
var CM = NEBUSTION.CrateManager;
function run(tab) { var s = new NEBUSTION.CratesScene(); s.init({ tab: tab }); s.create(); return s; }
['crates', 'forge', 'log'].forEach(function (tab) { try { var s = run(tab); ok(s._cards.length > 0, 'cartes ' + tab); } catch (e) { ok(false, 'rendu ' + tab + ' : ' + e.stack); } });
// ouverture complète avec animation + écran de récompense pour chaque type
CM.addCrate('astral', 5); CM.addKey('astral', 5);
try {
  var s = run('crates');
  ['skin', 'equipment', 'fragments', 'resources', 'gems'].forEach(function (kind) {
    var skinTarget = ['hero', 'ship', 'building'];
    (kind === 'skin' ? skinTarget : [null]).forEach(function (tg) {
      var rw = { kind: kind, rarity: 'legendaire', label: 'Test', detail: 'd' };
      if (kind === 'skin') { rw.skin = NEBUSTION.Skins.SKINS.filter(function (x) { return x.target === tg && x.rarity === 'legendaire'; })[0]; }
      if (kind === 'fragments') rw.hero = NEBUSTION.Heroes.all()[0];
      if (kind === 'resources') rw.bundle = [{ id: 'dust', amount: 5, requested: 5 }];
      var res = { ok: true, reward: rw, bonusShards: 30, pityTriggered: true };
      s._modal = null;
      s._playOpen('astral', res);
      (s._delayed || []).forEach(function (fn) { fn(); }); s._delayed = [];
      ok(!!s._modal, 'modal ' + kind + tg);
      s._closeModal();
    });
  });
  s._open('astral'); ok(true, '_open');
  s._forgeSkinCard(NEBUSTION.Skins.get('h_seraph')); ok(true, 'forge card');
} catch (e) { ok(false, 'ouverture : ' + e.stack); }
// SkinFX : tous les effets, mode normal et léger, + drawShip/drawBuilding
try {
  var sc = new Phaser.Scene('x'), cont = chain();
  NEBUSTION.Skins.SKINS.forEach(function (sk) {
    [false, true].forEach(function (light) { var h = NEBUSTION.SkinFX.build(sc, sk, 180, 220, { light: light }); h.destroy(); });
    ['intercepteur', 'corvette', 'cuirasse', 'porte_vaisseaux'].forEach(function (cl) { NEBUSTION.SkinFX.drawShip(sc, cl, sk, 170); });
    ['command', 'hangar', 'lab', 'defense'].forEach(function (b) { NEBUSTION.SkinFX.drawBuilding(sc, b, sk, 170); });
  });
  NEBUSTION.SkinFX.drawShip(sc, 'corvette', null, 170); NEBUSTION.SkinFX.drawBuilding(sc, 'command', null, 170);
  ok(true, 'SkinFX');
} catch (e) { ok(false, 'SkinFX : ' + e.stack); }
console.log(n + ' vérifications, ' + fails + ' échec(s)');
process.exit(fails ? 1 : 0);
