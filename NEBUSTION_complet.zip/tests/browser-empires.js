/*
 * Test dans un vrai Chromium (Playwright, FAUX Phaser) : les modules galaxie/IA/évolution sont chargés par index.html,
 * démarrés par main.js, sauvegardés dans localStorage, rechargés, et rattrapés hors ligne (24 h max).
 *   NODE_PATH=$(npm root -g) node tests/browser-empires.js
 */
const http = require('http'), fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const root = path.join(__dirname, '..');
const mock = fs.readFileSync(path.join(__dirname, 'mock-phaser.js'), 'utf8');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]);
  if (u === '/js/vendor/phaser.min.js') { res.writeHead(200, { 'Content-Type': 'text/javascript' }); return res.end(mock); }
  const f = path.join(root, u === '/' ? 'index.html' : u);
  if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('nf'); }
  res.writeHead(200, { 'Content-Type': mime[path.extname(f)] || 'application/octet-stream' }); res.end(fs.readFileSync(f));
});
let passed = 0, failed = 0;
const ok = (c, m) => { if (c) passed++; else { failed++; console.log('  ✗ ' + m); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  await new Promise(r => server.listen(8766, r));
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 780 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console.error: ' + m.text()); });
  const url = 'http://localhost:8766/index.html';
  const R = expr => page.evaluate(expr);
  async function ready() {
    const t0 = Date.now();
    while (Date.now() - t0 < 15000) { if (await R(`!!(window.__NEBUSTION_GAME__ && __NEBUSTION_GAME__.scene.isActive('MainMenuScene'))`)) return true; await sleep(100); }
    return false;
  }
  console.log('# Chargement et démarrage');
  await page.goto(url);
  ok(await ready(), 'jeu démarré (MainMenuScene)');
  ok(errors.length === 0, 'aucune erreur : ' + errors.join(' | '));
  ok(await R(`['Galaxy','EmpireAI','EmpireDoctrine','EmpireEvolution','GalaxyManager','EmpireAIManager','EmpireEvolutionManager'].every(k => !!NEBUSTION[k])`), 'les 7 modules sont chargés par index.html');
  ok(await R(`NEBUSTION.EmpireEvolutionManager.isRunning()`) === true, 'évolution des empires démarrée par main.js (minuteur unique)');
  ok(await R(`NEBUSTION.Resources.state.empires.v === 2 && Object.keys(NEBUSTION.Resources.state.empires.e).length === 5`), 'état empires v2 présent dans la sauvegarde');
  ok(await R(`Object.keys(NEBUSTION.EmpireAIManager.decideAll(Date.now())).length === 5`), 'décisions IA disponibles (5 empires)');
  ok(await R(`NEBUSTION.EmpireEvolutionManager.mapView(Date.now()).planets.length`) === 28, 'carte galactique : 28 planètes');

  console.log('# Réaction, sauvegarde, rechargement');
  await R(`NEBUSTION.GalaxyManager.setConquered('vx1', true, Date.now())`);
  ok(await R(`NEBUSTION.Resources.state.empires.e.vexor.lost === 1 && NEBUSTION.Resources.state.empires.e.vexor.hurt > 0`), 'conquête : VEXOR réagit immédiatement (mémoire des pertes)');
  await R(`NEBUSTION.Resources.saveNow(Date.now())`);
  await page.reload(); ok(await ready(), 'rechargement');
  ok(await R(`NEBUSTION.Resources.state.empires.e.vexor.lost === 1 && NEBUSTION.GalaxyManager.isConquered('vx1')`), 'après rechargement : perte et conquête conservées (pas de doublon)');
  ok(await R(`NEBUSTION.Resources.state.empires.e.vexor.lost`) === 1, 'perte comptée une seule fois');

  console.log('# Hors ligne : 3 jours d\'absence');
  const n0 = await R(`NEBUSTION.Resources.state.empires.n`);
  await R(`(() => { const e = NEBUSTION.Resources.state.empires; e.lastAt = Date.now() - 3 * 86400000; NEBUSTION.Resources.saveNow(Date.now()); })()`);
  await page.reload(); ok(await ready(), 'rechargement après absence');
  const n1 = await R(`NEBUSTION.Resources.state.empires.n`), la = await R(`NEBUSTION.Resources.state.empires.lastAt`);
  ok(n1 - n0 >= 48 && n1 - n0 <= 50, 'rattrapage limité à 24 h (' + (n1 - n0) + ' pas)');
  ok(Math.abs(la - Date.now()) < 120000, 'horloge des empires remise à l\'heure');
  ok(await R(`NEBUSTION.EmpireEvolutionManager.isRunning()`) === true, 'minuteur actif après rechargement');
  ok(errors.length === 0, 'aucune erreur pendant tout le test : ' + errors.join(' | '));

  await browser.close(); server.close();
  console.log('\n' + (failed === 0 ? '✔ TEST NAVIGATEUR EMPIRES OK (' + passed + ' vérifications)' : '✗ ' + failed + ' ÉCHEC(S)'));
  process.exit(failed === 0 ? 0 : 1);
})().catch(e => { console.error(e); process.exit(1); });
