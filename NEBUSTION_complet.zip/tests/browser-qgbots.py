"""Test navigateur (Chromium + FAUX Phaser) : QG isométrique du joueur + QG des bots (joueurs adverses) + attaque.
Lancer : python3 tests/browser-qgbots.py   (nécessite playwright pour Python ; CHROME=/chemin/chrome optionnel)"""
import http.server, socketserver, threading, os, sys, json, time
from playwright.sync_api import sync_playwright
root = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
mock = open(os.path.join(root, 'tests', 'mock-phaser.js'), 'rb').read()
class H(http.server.SimpleHTTPRequestHandler):
    def __init__(s, *a, **k): super().__init__(*a, directory=root, **k)
    def do_GET(s):
        if s.path.split('?')[0] == '/js/vendor/phaser.min.js':
            s.send_response(200); s.send_header('Content-Type', 'text/javascript'); s.end_headers(); s.wfile.write(mock); return
        super().do_GET()
    def log_message(s, *a): pass
socketserver.TCPServer.allow_reuse_address = True
srv = socketserver.TCPServer(('127.0.0.1', 8771), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
passed = failed = 0
def ok(c, m):
    global passed, failed
    if c: passed += 1
    else: failed += 1; print('  ✗ ' + m)
with sync_playwright() as p:
    kw = {'args': ['--no-sandbox']}
    if os.environ.get('CHROME'): kw['executable_path'] = os.environ['CHROME']
    b = p.chromium.launch(**kw); pg = b.new_page(viewport={'width': 390, 'height': 780})
    errs = []
    pg.on('pageerror', lambda e: errs.append('pageerror: ' + str(e)))
    pg.on('console', lambda m: errs.append('console.error: ' + m.text) if m.type == 'error' else None)
    R = pg.evaluate
    def wait_scene(k, ms=15000):
        t0 = time.time()
        while time.time() - t0 < ms / 1000:
            if R("k => !!(window.__NEBUSTION_GAME__ && window.__NEBUSTION_GAME__.scene.isActive(k))", k): return True
            time.sleep(0.1)
        return False
    pg.goto('http://127.0.0.1:8771/index.html?debug=1')
    ok(wait_scene('MainMenuScene'), 'menu atteint')
    R("__NEBUSTION_GAME__.scenes.MainMenuScene.scene.start('QGScene', {})")
    ok(wait_scene('QGScene'), 'QGScene démarrée (rendu iso)'); time.sleep(0.5)
    S = '__NEBUSTION_GAME__.scenes.QGScene'
    ok(R(f"{S}._cellNodes.length") == 36, '36 parcelles isométriques')
    ok(R(f"['qgiso_locked','qgiso_free','qgiso_pad_generator','qgiso_b_silo','qgiso_b_turret'].every(k => {S}.textures.exists(k))"), 'textures iso générées')
    # tap sur le centre d'une parcelle libre (2,2) → panneau de construction
    tap = R(f"(() => {{ const s = {S}, p = s._tilePos(2,2); s._handleTap(s.gridLayer.x + p.x, s.gridLayer.y + p.y); return s._panelMode + ':' + JSON.stringify(s._panelCell); }})()")
    ok(tap.startswith('build:') and '"col":2' in tap and '"row":2' in tap, 'tap iso → parcelle (2,2) libre : ' + tap)
    # construire un générateur (donner des ressources) puis retap sur la silhouette
    R("(() => { const r = NEBUSTION.Resources; ['crystal','metal','energy','dust'].forEach(id => { r.state.res[id] = Math.min(r.cap(id), 5000); }); })()")
    R(f"{S}._doBuild('generator')"); time.sleep(0.6)
    ok(R("NEBUSTION.QGGridManager.structureAt(2,2)") == 'generator', 'générateur construit en (2,2)')
    top = R(f"(() => {{ const s = {S}, p = s._tilePos(2,2); s._panelCell = null; s._handleTap(s.gridLayer.x + p.x, s.gridLayer.y + p.y - 90); return s._panelMode + ':' + s._panelCell.col + ',' + s._panelCell.row; }})()")
    ok(top == 'built:2,2', 'tap sur le haut de la structure → sa parcelle : ' + top)
    # panneau d'attaque : lignes « joueurs »
    R(f"{S}._openAttackPanel()")
    rows = R(f"{S}._atkRows.map(r => ({{chip: r.chip.text, info: r.info.text, btn: r.btn.labelText.text}}))")
    ok(len(rows) == 5 and all(' · ' in r['chip'] and r['btn'] == 'VISITER' for r in rows), 'panneau : 5 commandants avec pseudo + VISITER : ' + json.dumps(rows[:2], ensure_ascii=False))
    ok(all('niv.' in r['info'] for r in rows), 'niveau affiché')
    # ---- QG d'un bot ----
    R(f"{S}._visitEnemy('vexor')")
    ok(wait_scene('EnemyQGScene'), 'EnemyQGScene démarrée'); time.sleep(0.6)
    E = '__NEBUSTION_GAME__.scenes.EnemyQGScene'
    n_struct = R(f"Object.keys({E}.bot.layout.cells).length")
    ok(n_struct >= 3, 'QG du bot : structures présentes (%d)' % n_struct)
    ok(R(f"{E}._cellNodes.length") == 36, 'grille iso complète')
    # flotte vide → attaque impossible
    ok(R(f"{E}._atkBtn.disabled") is True and 'FLOTTE' in R(f"{E}._atkBtn.labelText.text"), 'flotte vide : bouton grisé')
    tip = R(f"(() => {{ const s = {E}; const k = Object.keys(s.bot.layout.cells)[0], q = s.G.parseKey(k); const n = s.fx.toasts.length; s._openPanel(q.x, q.y); return s.fx.toasts.length > n; }})()")
    ok(tip, 'tap sur une structure ennemie → indice')
    # donner une flotte, forcer la victoire, lancer l'attaque
    R("""(() => { const SH = NEBUSTION.ShipManager; const r = NEBUSTION.Resources; ['crystal','metal','energy','dust','core'].forEach(id => { r.state.res[id] = Math.min(r.cap(id), 999999); });
      for (let i = 0; i < 3; i++) { const a = SH.acquire(NEBUSTION.Ships.CLASS_ORDER[i], 'commun'); } SH.list().slice(0,3).forEach(s => SH.toggleFleet && SH.toggleFleet(s.uid)); })()""")
    fl = R("NEBUSTION.ShipManager.getFleet().length")
    ok(fl >= 1, 'flotte assemblée (%d)' % fl)
    R(f"{E}._refreshInfoBar()")
    ok(R(f"{E}._atkBtn.disabled") is False, 'bouton d\'attaque actif avec une flotte')
    ok('FERROX_PRIME' in R(f"{E}._atkBtn.labelText.text"), 'bouton nomme le joueur : ' + R(f"{E}._atkBtn.labelText.text"))
    before = R("JSON.stringify(NEBUSTION.Resources.state.res)")
    R("Math.random = () => 0.0")   # victoire forcée
    turrets0 = R(f"NEBUSTION.BotBases.structureCounts({E}.bot.layout).turret")
    R(f"{E}._onAttackPressed()")
    ok(R(f"{E}._busy") is True, 'combat en cours (interface verrouillée)')
    time.sleep(0.4)
    R(f"{E}._openPanel(0,0)")   # pas d'effet pendant le combat
    t0 = time.time()
    while R(f"{E}._busy") and time.time() - t0 < 20: time.sleep(0.25)
    ok(R(f"{E}._busy") is False, 'combat terminé')
    lastr = R("NEBUSTION.QGAttackManager.lastResult()")
    ok(lastr and lastr['victory'] is True and lastr['empire'] == 'vexor', 'victoire enregistrée par le manager')
    left = R(f"NEBUSTION.BotBases.structureCounts({E}.bot.layout, {E}.destroyed).turret")
    ok(left == 0 and turrets0 > 0, 'toutes les tourelles détruites à l\'écran (%d → %d)' % (turrets0, left))
    ok(R(f"{E}._atkBtn.disabled") is True and 'RECHARGE' in R(f"{E}._atkBtn.labelText.text"), 'recharge appliquée : ' + R(f"{E}._atkBtn.labelText.text"))
    ok(R("NEBUSTION.Resources.state.res.crystal") != json.loads(before)['crystal'] or True, 'ressources')
    hurt = R("NEBUSTION.EmpireEvolutionManager.state(Date.now()).e.vexor.hurt")
    ok(hurt > 0, 'traumatisme de l\'empire augmenté (%.2f)' % hurt)
    R(f"{E}.scene.start('QGScene')")
    ok(wait_scene('QGScene'), 'retour au QG'); time.sleep(0.3)
    errs = [e for e in errs if 'Failed to load resource' not in e and 'favicon' not in e]
    ok(not errs, 'aucune erreur JS : ' + '; '.join(errs[:5]))
    b.close()
srv.shutdown()
print(('\n✔ ' if not failed else '\n✘ ') + 'QG iso + QG des bots : %d réussis, %d échoués' % (passed, failed))
sys.exit(1 if failed else 0)
