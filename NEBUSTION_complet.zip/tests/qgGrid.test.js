/* Tests de la Grille constructible du QG (NEBUSTION.QGGrid + QGGridManager), Node, sans Phaser.
 * Lancer : node tests/qgGrid.test.js */
'use strict';
const E = require('./progress-env');
const t = E.makeCounter(), ok = t.ok, section = t.section;
const G = NEBUSTION.QGGrid, GM = NEBUSTION.QGGridManager;

section('Formules (données pures)');
{
  ok(G.COLS === 6 && G.ROWS === 6 && G.MAX_CELLS === 36, 'grille 6x6 = 36 parcelles');
  ok(G.inBounds(0, 0) && G.inBounds(5, 5) && !G.inBounds(-1, 0) && !G.inBounds(6, 0), 'inBounds() aux limites');
  ok(G.key(2, 3) === '2,3', 'clé "x,y"');

  const d = G.defaultState();
  ok(Object.keys(d.unlocked).length === 4, 'état par défaut : 4 parcelles centrales déverrouillées');
  ok(Object.keys(d.cells).length === 0, 'état par défaut : aucune structure posée');

  const c0 = G.unlockCost(0), c10 = G.unlockCost(10);
  ok(c0.crystal === 40 && c0.metal === 30, 'coût de déverrouillage de base (n=0)');
  ok(c10.crystal > c0.crystal, 'le coût de déverrouillage augmente avec n');

  const b0 = G.buildCost('generator', 0), b3 = G.buildCost('generator', 3);
  ok(b0.metal === 120 && b0.energy === 70, 'coût de base du Générateur');
  ok(b3.metal > b0.metal, 'le coût de construction augmente avec le nombre déjà construit');

  const refund = G.sellRefund('generator', 1);
  ok(refund.metal === Math.floor(b0.metal * 0.5), 'remboursement = 50 % du coût de la dernière unité');

  ok(typeof G.STRUCTURES.generator.desc(3) === 'string', 'texte d\'effet dynamique par structure');
}

section('Non-régression économie / sauvegarde (sans dépendance directe)');
{
  const g = E.freshGame(), R = g.R;
  ok(R.state.qgGrid && Object.keys(R.state.qgGrid.unlocked).length === 4, 'une nouvelle partie initialise qgGrid avec le noyau central');
}

section('QGGridManager — déverrouillage de parcelles');
{
  const g = E.freshGame(), R = g.R;
  ok(GM.isUnlocked(2, 2) && GM.isUnlocked(3, 3), 'le noyau central est déverrouillé au départ');
  ok(!GM.isUnlocked(0, 0), 'une parcelle en bordure est verrouillée au départ');
  ok(!GM.canUnlock(0, 0), 'fonds insuffisants au tout début');

  const cost = GM.unlockCost();
  Object.keys(cost).forEach((id) => { R.state.res[id] = cost[id] + 1000; });
  ok(GM.canUnlock(0, 0), 'fonds suffisants après crédit manuel');

  const before = {}; Object.keys(cost).forEach((id) => { before[id] = R.get(id); });
  const res = GM.unlockCell(0, 0);
  ok(res.ok && GM.isUnlocked(0, 0), 'déverrouillage réussi');
  Object.keys(cost).forEach((id) => { ok(R.get(id) === before[id] - cost[id], 'paiement exact pour ' + id); });

  const already = GM.unlockCell(0, 0);
  ok(!already.ok && already.reason === 'already', 'ne peut pas déverrouiller deux fois la même parcelle');
}

section('QGGridManager — construction / vente de structures');
{
  const g = E.freshGame(), R = g.R;
  ok(!GM.canBuild(2, 2, 'generator'), 'fonds insuffisants au tout début');

  const cost = GM.buildCost('generator');
  Object.keys(cost).forEach((id) => { R.state.res[id] = cost[id] + 1000; });
  ok(GM.canBuild(2, 2, 'generator'), 'fonds suffisants après crédit manuel');

  const res = GM.build(2, 2, 'generator');
  ok(res.ok && GM.structureAt(2, 2) === 'generator', 'construction réussie sur une parcelle déverrouillée et vide');
  ok(!GM.canBuild(2, 2, 'silo'), 'impossible de construire sur une parcelle déjà occupée');

  const outside = GM.build(0, 0, 'generator');
  ok(!outside.ok && outside.reason === 'locked', 'construction refusée sur une parcelle verrouillée');

  const refund = GM.sellRefund(2, 2);
  const before = R.get('metal');
  const sold = GM.sell(2, 2);
  ok(sold.ok && !GM.structureAt(2, 2), 'vente réussie : la parcelle redevient libre');
  ok(R.get('metal') === before + refund.metal, 'remboursement crédité exactement');
}

section('QGGridManager — bonus (production / stockage / sécurité)');
{
  const g = E.freshGame(), R = g.R;
  ok(GM.bonusValue('production') === 0, 'aucun bonus sans structure posée');

  const rateBefore = R.rate('crystal');
  const cost = GM.buildCost('generator');
  Object.keys(cost).forEach((id) => { R.state.res[id] = cost[id] + 1000; });
  GM.build(2, 2, 'generator');
  ok(Math.abs(GM.bonusValue('production') - 0.02) < 1e-9, '1 Générateur = +2 % de production');
  ok(R.rate('crystal') > rateBefore, 'le taux de production réel augmente après construction (cache invalidé)');

  const capBefore = R.cap('metal');
  const costSilo = GM.buildCost('silo');
  Object.keys(costSilo).forEach((id) => { R.state.res[id] = costSilo[id] + 1000; });
  GM.build(3, 2, 'silo');
  ok(R.cap('metal') > capBefore, 'la capacité de stockage augmente après construction d\'un Silo');

  ok(NEBUSTION.SecurityManager.effectiveLevel() === NEBUSTION.SecurityManager.level(), 'sans Tourelle, niveau affiché = niveau manuel');
  const costTurret = GM.buildCost('turret');
  Object.keys(costTurret).forEach((id) => { R.state.res[id] = costTurret[id] + 1000; });
  GM.build(2, 3, 'turret');
  ok(NEBUSTION.SecurityManager.effectiveLevel() === NEBUSTION.SecurityManager.level() + 1, '1 Tourelle = +1 niveau de Sécurité affiché');
}

section('Plafonds et limites');
{
  const g = E.freshGame(), R = g.R;
  const def = G.STRUCTURES.generator;
  ['2,2', '3,2', '2,3', '3,3'].forEach((k, i) => {
    if (i >= def.maxCount) return;
    const p = G.parseKey(k);
    const cost = GM.buildCost('generator');
    Object.keys(cost).forEach((id) => { R.state.res[id] = cost[id] + 1000; });
    GM.build(p.x, p.y, 'generator');
  });
  ok(GM.counts().generator <= def.maxCount, 'le nombre de Générateurs ne dépasse jamais maxCount');
}

section('Chargement / sauvegarde (SaveManager)');
{
  const raw = { qgGrid: { unlocked: { '0,0': true, '2,2': true }, cells: { '0,0': 'generator' } } };
  const norm = NEBUSTION.Save.normalize(raw, Date.now());
  ok(norm.qgGrid.unlocked['0,0'] === true, 'normalize() reprend une parcelle déverrouillée valide');
  ok(norm.qgGrid.cells['0,0'] === 'generator', 'normalize() reprend une structure valide sur une parcelle déverrouillée');
  ok(Object.keys(norm.qgGrid.unlocked).length >= 4, 'normalize() garantit toujours le noyau central déverrouillé');

  const bogus = { qgGrid: { unlocked: {}, cells: { '9,9': 'generator', '0,0': 'not_a_structure' } } };
  const normBogus = NEBUSTION.Save.normalize(bogus, Date.now());
  ok(Object.keys(normBogus.qgGrid.cells).length === 0, 'normalize() rejette coordonnées hors-grille et structures invalides');

  const normEmpty = NEBUSTION.Save.normalize({}, Date.now());
  ok(Object.keys(normEmpty.qgGrid.unlocked).length === 4, 'sauvegarde sans champ qgGrid → valeur par défaut (rétrocompatible)');
}

t.done('Grille constructible du QG');
