/* Tests d'intégration de NEBUSTION.ShipManager (Node, faux ResourceManager). Lancer : node tests/shipManager.test.js */
'use strict';
global.window = global;
require('../js/data/Economy.js');
require('../js/data/Heroes.js');
require('../js/data/Ships.js');
require('../js/systems/CombatEngine.js');
require('../js/systems/ShipManager.js');

let passed = 0, failed = 0;
function ok(cond, msg) { if (cond) { passed++; } else { failed++; console.log('  ✗ ECHEC : ' + msg); } }
function section(t) { console.log('\n# ' + t); }

function makeFakeResources(res) {
  return {
    state: { res: res, ships: null },
    canAfford(cost) { return Object.keys(cost).every(k => (this.state.res[k] || 0) >= cost[k]); },
    spendMany(cost) { if (!this.canAfford(cost)) return false; Object.keys(cost).forEach(k => this.state.res[k] -= cost[k]); return true; },
    add(id, amount) { this.state.res[id] = (this.state.res[id] || 0) + amount; return amount; },
    saveNow() {}
  };
}

section('Acquisition (acquire)');
{
  NEBUSTION.Resources = makeFakeResources({ crystal: 1000, energy: 1000 });
  var r1 = NEBUSTION.ShipManager.acquire('intercepteur', 'commun');
  ok(r1.ok, 'acquisition réussie avec assez de ressources');
  ok(NEBUSTION.ShipManager.list().length === 1, '1 vaisseau dans le hangar');

  NEBUSTION.Resources = makeFakeResources({ crystal: 0, energy: 0 });
  var r2 = NEBUSTION.ShipManager.acquire('intercepteur', 'commun');
  ok(!r2.ok && r2.reason === 'ressources', 'acquisition refusée sans ressources suffisantes');
}

section('Flotte : ajout/retrait, limite à 3');
{
  NEBUSTION.Resources = makeFakeResources({ crystal: 10000, energy: 10000 });
  var s1 = NEBUSTION.ShipManager.acquire('intercepteur', 'commun').ship;
  var s2 = NEBUSTION.ShipManager.acquire('cuirasse', 'commun').ship;
  var s3 = NEBUSTION.ShipManager.acquire('corvette', 'commun').ship;
  var s4 = NEBUSTION.ShipManager.acquire('porte_vaisseaux', 'commun').ship;

  NEBUSTION.ShipManager.toggleFleet(s1.uid);
  NEBUSTION.ShipManager.toggleFleet(s2.uid);
  NEBUSTION.ShipManager.toggleFleet(s3.uid);
  ok(NEBUSTION.ShipManager.getFleet().length === 3, 'flotte à 3 vaisseaux');
  NEBUSTION.ShipManager.toggleFleet(s4.uid);
  ok(NEBUSTION.ShipManager.getFleet().length === 3, 'un 4e vaisseau est refusé (flotte pleine)');
  ok(!NEBUSTION.ShipManager.isInFleet(s4.uid), 's4 n\'est pas dans la flotte');

  NEBUSTION.ShipManager.toggleFleet(s1.uid);
  ok(NEBUSTION.ShipManager.getFleet().length === 2, 'retirer un vaisseau de la flotte fonctionne');
  ok(!NEBUSTION.ShipManager.isInFleet(s1.uid), 's1 n\'est plus dans la flotte');
}

section('Amélioration');
{
  NEBUSTION.Resources = makeFakeResources({ crystal: 10000, energy: 10000 });
  var sh = NEBUSTION.ShipManager.acquire('intercepteur', 'commun').ship;
  var before = NEBUSTION.Ships.bonusFor(sh.classId, sh.rarity, sh.level).atk;
  var up = NEBUSTION.ShipManager.upgrade(sh.uid);
  ok(up.ok && up.ship.level === 2, 'amélioration passe le vaisseau au niveau 2');
  var after = NEBUSTION.Ships.bonusFor(sh.classId, sh.rarity, up.ship.level).atk;
  ok(after > before, 'le bonus augmente après amélioration');
}

section('Bonus de flotte réellement appliqué en combat (CombatEngine.makeHeroUnit)');
{
  NEBUSTION.Resources = makeFakeResources({ crystal: 10000, energy: 10000 });
  var H = NEBUSTION.Heroes, CE = NEBUSTION.CombatEngine, SM = NEBUSTION.ShipManager;
  var hero = H.get('korvax');

  var unitWithoutFleet = CE.makeHeroUnit(hero, 10, 'korvax', SM.fleetBonus());
  ok(Object.keys(SM.fleetBonus()).every(k => SM.fleetBonus()[k] === 0), 'bonus de flotte nul sans flotte');

  var tank = SM.acquire('cuirasse', 'legendaire').ship;
  SM.toggleFleet(tank.uid);
  var unitWithFleet = CE.makeHeroUnit(hero, 10, 'korvax', SM.fleetBonus());

  ok(unitWithFleet.def > unitWithoutFleet.def, 'la défense du héros augmente réellement avec un cuirassé en flotte (' + unitWithoutFleet.def + ' -> ' + unitWithFleet.def + ')');
  ok(unitWithFleet.atk === unitWithoutFleet.atk, 'l\'attaque ne change pas (le cuirassé ne bonifie que def)');
}

console.log('\n' + (failed === 0 ? '✓ TOUS LES TESTS SONT PASSÉS' : '✗ ÉCHECS DÉTECTÉS') + ' — ' + passed + ' réussis, ' + failed + ' échoués');
process.exit(failed === 0 ? 0 : 1);
