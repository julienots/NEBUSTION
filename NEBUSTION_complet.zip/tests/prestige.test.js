/* Tests de la Renaissance galactique (NEBUSTION.Prestige + PrestigeManager), Node, sans Phaser.
 * Lancer : node tests/prestige.test.js */
'use strict';
const E = require('./progress-env');
const t = E.makeCounter(), ok = t.ok, section = t.section;
const PR = NEBUSTION.Prestige, PM = NEBUSTION.PrestigeManager, XM = NEBUSTION.ExpeditionManager, EM = NEBUSTION.EventManager, AM = NEBUSTION.AchievementsManager;
const C = NEBUSTION.Combat, Eco = NEBUSTION.Economy;

section('Formules (données pures)');
{
  const r0 = PR.requirementsFor(0), r1 = PR.requirementsFor(1), r99 = PR.requirementsFor(99);
  ok(r0.commandLevel === 12 && r0.totalStars === 15, 'objectifs de départ : Commandement 12, 15 étoiles');
  ok(r1.commandLevel === 15 && r1.totalStars === 18, 'les objectifs montent à chaque Renaissance');
  ok(r99.commandLevel === 30 && r99.totalStars === 30 && PR.requirementsFor(-4).commandLevel === 12, 'objectifs plafonnés (30 / 30) et bornés');
  ok(PR.relicsFor(0) === 1 && PR.relicsFor(-100) === 1 && PR.relicsFor(1800) === 1, 'reliques : 1 minimum');
  ok(PR.relicsFor(1800 * 8) === 2 && PR.relicsFor(1800 * 27) === 3 && PR.relicsFor(1800 * 1000) === 10, 'reliques = racine cubique des points / 1800');
  const p0 = PR.pointsFor({}, 0, 0), p1 = PR.pointsFor({ crystal: 1000 }, 10, 500);
  ok(p0 === 0 && p1 === 1000 * 1.0 + 10 * 140 + 500 * 0.4, 'points = ressources pondérées + étoiles + XP');
  ok(PR.pointsFor({ core: 10 }, 0, 0) > PR.pointsFor({ dust: 10 }, 0, 0) * 10, 'un noyau antique vaut bien plus qu\'une poussière');
  ok(PR.TREE.length === 5 && PR.TREE.map(n => n.id).join() === 'production,combatPower,expeditionSlot,offlineEff,headStart', '5 nœuds : production, combatPower, expeditionSlot, offlineEff, headStart');
  ok(PR.node('production') && PR.node('zz') === null && PR.node('__proto__') === null, 'node() : connu / inconnu / prototype');
  ok(PR.nodeCost('production', 0) === 3 && PR.nodeCost('production', 5) > PR.nodeCost('production', 1), 'coût croissant');
  ok(PR.nodeCost('expeditionSlot', 3) === null && PR.nodeCost('zz', 0) === null, 'coût nul au niveau max. / nœud inconnu');
  ok(Math.abs(PR.nodeValue('production', 5) - 0.1) < 1e-9 && PR.nodeValue('production', 999) === PR.node('production').maxLevel * 0.02 && PR.nodeValue('zz', 3) === 0, 'valeur de nœud bornée au niveau max.');
  ok(PR.tierName(0) === 'Origine' && PR.tierName(1) === 'Aube' && PR.tierName(3) === 'Ascension' && PR.tierName(5) === 'Singularité' && PR.tierName(99) === 'Singularité', 'noms de paliers');
  ok(PR.TIER_PERKS.length === 5 && PR.TIER_PERKS.every((p, i) => p.count === i + 1 && p.name && p.desc), '5 paliers documentés');
}

// ---------- Partie simulée ----------
const g = E.freshGame(), R = g.R, SM = NEBUSTION.ShopManager;
const H = E.freeHeroes();
const S = () => R.state;

section('Non-régression économie (aucun bonus = taux inchangés)');
{
  const E0 = Eco.ORDER.every(id => Math.abs(R.rates()[id] - Eco.totalRate(id, S().buildings['ext_' + id].level, S().drones[id], S().buildings.hangar.level)) < 1e-9);
  ok(E0 && Eco.ORDER.every(id => PM.bonusValue('production') === 0 && R.rates()[id] > 0), 'sans bonus de Renaissance, la production est identique au calcul d\'origine');
  ok(PM.bonusValue('offlineEff') === 0 && PM.bonusValue('combatPower') === 0 && PM.bonusValue('expeditionSlot') === 0 && PM.bonusValue('headStart') === 0 && PM.bonusValue('zz') === 0, 'tous les bonus valent 0 au départ');
}

section('Condition de déclenchement');
{
  ok(PM.count() === 0 && PM.relics() === 0 && PM.tierName() === 'Origine', 'départ : 0 Renaissance, 0 reliques');
  const c = PM.canPrestige();
  ok(!c.ok && c.needCommandLevel === 12 && c.needStars === 15, 'refusé au départ (objectifs 12 / 15)');
  ok(PM.perform().reason === 'condition' && PM.count() === 0, 'perform() refusé tant que les objectifs ne sont pas atteints');
  S().buildings.command.level = 12;
  ok(!PM.canPrestige().ok, 'Commandement seul ne suffit pas');
  E.giveStars(15);
  ok(PM.canPrestige().ok, 'objectifs atteints → possible');
  E.giveStars(14); ok(!PM.canPrestige().ok, '14 étoiles : refusé');
  E.giveStars(15);
  ok(PM.previewRelics() >= 1 && PM.previewPoints() >= 15 * 140, 'aperçu du gain ≥ 1 relique');
  ok(PM.requirements().commandLevel === 12, 'requirements() = objectifs actuels');
}

section('Arbre de bonus');
{
  ok(PM.treeStatus().length === 5 && PM.treeStatus().every(n => n.level === 0 && !n.maxed && n.cost > 0), '5 nœuds à 0, coûts affichés');
  ok(PM.buyNode('production').reason === 'reliques', 'achat refusé sans reliques');
  ok(PM.buyNode('zz').reason === 'invalide', 'nœud inconnu refusé');
  S().prestige.relics = 1000;
  const cost = PR.nodeCost('production', 0), r0 = R.rates().crystal;
  const b = PM.buyNode('production');
  ok(b.ok && b.level === 1 && b.cost === cost && PM.relics() === 1000 - cost && PM.nodeLevel('production') === 1, 'achat : niveau +1, reliques dépensées');
  ok(Math.abs(R.rates().crystal / r0 - 1.02) < 1e-6, 'bonus « production » +2 % appliqué immédiatement aux taux (cache invalidé)');
  for (let i = 0; i < 4; i++) PM.buyNode('production');
  ok(Math.abs(R.rates().crystal / r0 - 1.10) < 1e-6, '5 paliers = +10 %');
  // Efficacité hors ligne
  R.state.res.crystal = 0; R._applyOffline(3600, Date.now()); const base = R.state.res.crystal;
  PM.buyNode('offlineEff'); PM.buyNode('offlineEff'); PM.buyNode('offlineEff'); PM.buyNode('offlineEff');
  R.state.res.crystal = 0; R._applyOffline(3600, Date.now()); const boosted = R.state.res.crystal;
  const eff = Eco.CFG.OFFLINE_EFFICIENCY;
  ok(base > 0 && Math.abs(boosted / base - Math.min(1, eff + 0.2) / eff) < 0.01, 'bonus « offlineEff » : ' + Math.round((boosted / base - 1) * 100) + ' % de gain hors ligne en plus');
  // Puissance de combat (via les unités réellement construites pour un combat)
  const stageId = NEBUSTION.Enemies.STAGES ? NEBUSTION.Enemies.STAGES[0].id : 's1';
  C.setTeam(H.slice(0, 5));
  const u0 = C.buildBattle(stageId, 'normal', 'auto').playerUnits[0];
  PM.buyNode('combatPower'); PM.buyNode('combatPower');
  const u1 = C.buildBattle(stageId, 'normal', 'auto').playerUnits[0];
  ok(u1.maxHp > u0.maxHp && u1.atk > u0.atk && u1.def >= u0.def, 'bonus « combatPower » : PV et attaque des unités de combat en hausse');
  ok(Math.abs(u1.atk / u0.atk - 1.03) < 0.01 && Math.abs(u1.maxHp / u0.maxHp - 1.03) < 0.01, 'bonus « combatPower » ≈ +3 % après 2 paliers');
  // Emplacements d'expédition
  PM.buyNode('expeditionSlot'); ok(XM.maxSlots() === 3, 'bonus « expeditionSlot » : 3 emplacements');
  PM.buyNode('expeditionSlot'); PM.buyNode('expeditionSlot');
  ok(XM.maxSlots() === 5 && PM.buyNode('expeditionSlot').reason === 'max' && PM.treeStatus().find(n => n.id === 'expeditionSlot').maxed, 'niveau max. atteint : achat refusé, nœud marqué « max »');
}

section('Renaissance : ce qui est réinitialisé / conservé');
{
  // État riche avant Renaissance
  S().buildings.command.level = 20; S().buildings.storage.level = 6; S().buildings.ext_crystal.level = 15; S().buildings.hangar.level = 9;
  Eco.ORDER.forEach(id => { S().res[id] = 5000; S().life[id] = 200000; S().drones[id] = 4; });
  S().combat.battlesWon = 30; S().combat.battlesLost = 5; S().combat.difficulty = 'difficile'; S().combat.playerXP = 4000;
  E.setLevel(H[0], 12); S().combat.fragments[H[1]] = 77;
  C.setTeam(H.slice(0, 5));
  S().galaxy.conquered = { s2: true, s3: true }; S().galaxy.unlocked.s2 = true;
  SM.addGems(120); const gems = SM.gems();
  const T = Date.now();
  XM.launch('m_courte_facile', [H[6]], T);
  S().events.currency = 33; S().events.stats.bossKills = 4;
  S().achievements.claimed.ach_battles = 2;
  E.giveStars(30);
  const pts = PM.previewPoints(), gain = PM.previewRelics(), relics0 = PM.relics(), total0 = PM.totalEarned();
  ok(gain === PR.relicsFor(pts) && gain >= 2, 'gain annoncé = relicsFor(points) (' + gain + ' reliques)');
  const r = PM.perform(T);
  ok(r.ok && r.relicsGained === gain && r.cycle === 1 && r.tier === 'Aube' && r.totalRelics === relics0 + gain, 'perform() : gain, cycle 1, palier « Aube »');
  ok(PM.count() === 1 && PM.relics() === relics0 + gain && PM.totalEarned() === total0 + gain, 'reliques créditées, total cumulé mis à jour');
  const hs = Math.floor(PM.bonusValue('headStart'));
  // Réinitialisé
  ok(Eco.BUILDING_ORDER.every(b => S().buildings[b].level === Math.min(Eco.CFG.MAX_LEVEL, Eco.BUILDINGS[b].start + hs)), 'bâtiments remis au niveau de départ (+ « Fondations gravées »)');
  ok(Eco.ORDER.every(id => S().life[id] === 0 && S().drones[id] === Eco.CFG.START_DRONES && S().res[id] <= 500), 'ressources, cumuls et drones remis à zéro');
  ok(XM.totalStars() === 0 && S().combat.battlesWon === 0 && S().combat.battlesLost === 0 && S().combat.difficulty === 'normal' && S().combat.playerXP === 0, 'étoiles, victoires, difficulté et XP de combat réinitialisées');
  ok(!S().galaxy.conquered.s2 && !S().galaxy.conquered.s3, 'galaxie : conquêtes réinitialisées');
  // Conservé
  ok(S().combat.fragments[H[1]] === 77 && C.heroLevel(H[0]) === 12, 'héros : fragments et niveaux conservés');
  ok(C.getTeam().join() === H.slice(0, 5).join(), 'équipe de combat conservée');
  ok(SM.gems() === gems, 'Prismes conservés');
  ok(XM.isBusy(H[6]) && XM.usedSlots() === 1, 'expéditions en cours conservées');
  ok(S().events.currency === 33 && S().events.stats.bossKills === 4, 'événements conservés');
  ok(S().achievements.claimed.ach_battles === 2, 'succès réclamés conservés');
  ok(PM.nodeLevel('production') === 5 && PM.nodeLevel('expeditionSlot') === 3, 'arbre de bonus conservé');
  ok(S().prestige.history.length === 1 && S().prestige.history[0].relics === gain && S().prestige.bestRelicsGain === gain, 'historique et meilleur gain enregistrés');
  // Succès : meilleure valeur atteinte
  ok(AM.valueOf('commandLevel') >= 20 && AM.valueOf('battlesWon') >= 30 && AM.valueOf('totalStars') >= 30, 'succès : les meilleures valeurs d\'avant la Renaissance sont gardées');
  // Nouveaux objectifs
  ok(!PM.canPrestige().ok && PM.requirements().commandLevel === 15 && PM.requirements().totalStars === 18, 'nouveaux objectifs plus élevés (15 / 18)');
  ok(PM.perform().reason === 'condition', 'une deuxième Renaissance immédiate est refusée');
  // Effet des paliers
  ok(XM.canLaunch('m_courte_abyssal', [H[7]], T).reason !== 'verrouille' || XM.totalStars() < 20, 'Abyssal n\'est plus verrouillée par la Renaissance (reste les étoiles)');
  E.giveStars(25);
  ok(XM.lockReason(NEBUSTION.Expeditions.mission('m_courte_abyssal')) === null, 'Abyssal déverrouillée avec Renaissance 1 + 20 étoiles');
  ok(XM.lockReason(NEBUSTION.Expeditions.mission('m_courte_mythique')) !== null, 'Mythique toujours verrouillée (Renaissance 3)');
  ok(NEBUSTION.Events.maxAttempts(PM.count()) === 6, '+1 tentative de boss par jour');
}

section('Deuxième Renaissance et sauvegarde');
{
  S().buildings.command.level = 15; E.giveStars(18);
  ok(PM.canPrestige().ok, 'objectifs 15 / 18 atteints');
  const r = PM.perform(Date.now());
  ok(r.ok && r.cycle === 2 && r.tier === 'Éveil' && PM.count() === 2, 'seconde Renaissance : palier « Éveil »');
  R.saveNow(Date.now());
  const loaded = NEBUSTION.Save.load().state;
  const back = NEBUSTION.Save.normalize(JSON.parse(JSON.stringify(loaded)), Date.now());
  ok(back.prestige.count === 2 && back.prestige.relics === PM.relics() && back.prestige.spent.production === 5, 'sauvegarde aller-retour : reliques, compteur et arbre');
}

section('Robustesse de normalizeState');
{
  ok(PM.normalizeState(null).count === 0 && PM.normalizeState('x').relics === 0 && PM.normalizeState(7).history.length === 0, 'entrées absurdes → état neuf');
  const n = PM.normalizeState({ relics: -5, totalEarned: 'a', count: 2.9, bestRelicsGain: NaN, spent: { production: 999, combatPower: -3, zz: 4, headStart: 2.7 }, history: Array.from({ length: 40 }, (_, i) => ({ i })) });
  ok(n.relics === 0 && n.totalEarned === 0 && n.count === 2 && n.bestRelicsGain === 0, 'valeurs négatives / NaN / décimales corrigées');
  ok(n.spent.production === 25 && n.spent.combatPower === 0 && n.spent.headStart === 2 && !('zz' in n.spent), 'paliers bornés [0, max], nœud inconnu écarté');
  ok(n.history.length === 12, 'historique limité à 12 entrées');
}

t.done('TESTS RENAISSANCE');
