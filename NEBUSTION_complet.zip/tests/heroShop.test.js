/* Tests des 8 héros exclusifs Boutique (Velmora … Vulkar) : données, portraits, kits de combat,
 * verrouillage / recrutement, sauvegarde. Lancer : node tests/heroShop.test.js */
'use strict';
global.window = global;
const fs = require('fs'), path = require('path');
['data/Economy', 'data/Heroes', 'data/Enemies', 'data/Galaxy', 'data/EmpireAI', 'data/EmpireDoctrine', 'data/EmpireEvolution', 'data/Equipment', 'data/Ships', 'data/Skins', 'data/Shop', 'data/Pass',
  'systems/SaveManager', 'systems/ResourceManager', 'systems/CombatEngine', 'systems/CombatManager', 'systems/EquipmentManager', 'systems/ShipManager', 'systems/SkinManager', 'systems/ShopManager',
  'systems/PassBilling', 'systems/PassManager'].forEach(f => require('../js/' + f + '.js'));
let passed = 0, failed = 0;
const ok = (c, m) => { if (c) passed++; else { failed++; console.log('  ✗ ECHEC : ' + m); } };
const section = t => console.log('\n# ' + t);
const H = NEBUSTION.Heroes, C = NEBUSTION.Combat, SM = NEBUSTION.ShopManager, CE = NEBUSTION.CombatEngine, EN = NEBUSTION.Enemies;
const NEW = ['velmora', 'zephyrax', 'drakathor', 'selenia', 'krakenis', 'nythera', 'arcanis', 'vulkar'];
const EXPECT = { velmora: ['healer', 'legendaire'], zephyrax: ['assassin', 'epique'], drakathor: ['damage', 'mythique'], selenia: ['sniper', 'epique'],
  krakenis: ['tank', 'legendaire'], nythera: ['damage', 'mythique'], arcanis: ['control', 'epique'], vulkar: ['tank', 'legendaire'] };

const store = { _m: {}, getItem(k) { return this._m[k] || null; }, setItem(k, v) { this._m[k] = v; }, removeItem(k) { delete this._m[k]; } };
NEBUSTION.Save._useStorage(store);
NEBUSTION.Resources = new NEBUSTION.ResourceManager(); NEBUSTION.Resources.init(Date.now());
const R = NEBUSTION.Resources;

section('Données des 8 nouveaux héros');
{
  ok(H.all().length === 39 && H.shopHeroes().length === 23, '39 héros dont 23 exclusivités Boutique (' + H.all().length + ')');
  ok(new Set(H.all().map(h => h.id)).size === H.all().length, 'identifiants uniques');
  NEW.forEach(id => {
    const h = H.get(id);
    ok(!!h, id + ' existe');
    if (!h) return;
    ok(h.role === EXPECT[id][0] && h.rarity === EXPECT[id][1], id + ' : rôle/rareté conformes à la planche (' + h.role + '/' + h.rarity + ')');
    ok(!!H.ROLES[h.role] && !!H.RARITIES[h.rarity], id + ' : rôle et rareté valides');
    ok(['hp', 'atk', 'def', 'spd'].every(k => h.base[k] > 0 && isFinite(h.base[k])), id + ' : stats valides');
    ok(h.skills.passive && h.skills.active && h.skills.ultimate && h.skills.active.cooldown > 0 && h.skills.ultimate.cost === 100, id + ' : 3 compétences complètes');
    ok(h.shop && h.shop.cost && h.shop.cost.gem > 0, id + ' : prix de recrutement défini');
    ok(!!CE.HERO_KIT[id], id + ' : kit de combat dédié');
    ok(h.title.length > 5 && h.visual && h.visual.accent, id + ' : réplique + identité visuelle');
    const png = path.join(__dirname, '..', H.portraitFile(id));
    ok(fs.existsSync(png), id + ' : portrait présent');
    if (fs.existsSync(png)) { const b = fs.readFileSync(png); ok(b.readUInt32BE(16) === 300 && b.readUInt32BE(20) === 380, id + ' : portrait 300×380'); }
  });
  const price = { epique: 220, legendaire: 380, mythique: 560 };
  ok(NEW.every(id => H.get(id).shop.cost.gem === price[H.get(id).rarity]), 'prix cohérents avec la rareté');
  const sw = fs.readFileSync(path.join(__dirname, '..', 'sw.js'), 'utf8');
  ok(NEW.every(id => sw.indexOf('assets/heroes/' + id + '.png') >= 0), 'portraits dans le cache hors-ligne (sw.js)');
}

section('Combat : chaque héros utilise SON kit');
{
  const foesOf = () => ['steel_golem', 'steel_golem', 'umbra_sniper'].map((id, i) => { const f = CE.makeEnemyUnit(EN.get(id), 'normal', i); f.gauge = 0; f.skillCooldown = 999; f.maxHp = f.hp = 1e9; return f; });
  NEW.forEach(id => {
    const hero = CE.makeHeroUnit(H.get(id), 20, id);
    ok(hero.hasKit === true && hero.maxHp > 0 && hero.atk > 0, id + ' : unité créée avec kit');
    const ally = CE.makeHeroUnit(H.get('zyra'), 20, 'zyra'); ally.hp = Math.round(ally.maxHp * 0.3);
    const foes = foesOf(), eng = new CE.CombatEngine([hero, ally], foes, { mode: 'auto' });
    let ev = [];
    hero.skillCooldown = 0; eng.requestSkill(hero.uid);
    for (let i = 0; i < 40 && !eng.isOver(); i++) { eng.update(0.05); ev = ev.concat(eng.consumeEvents()); }
    ok(ev.some(e => e.type === 'skill'), id + ' : la compétence active se déclenche');
    hero.energy = 100; eng.requestUltimate(hero.uid);
    for (let i = 0; i < 60 && !eng.isOver(); i++) { eng.update(0.05); ev = ev.concat(eng.consumeEvents()); }
    ok(ev.some(e => e.type === 'ultimate'), id + ' : l\'ultime se déclenche');
    ok(ev.every(e => e.type !== 'damage' || (isFinite(e.amount) && (e.amount >= 1 || e.absorbed > 0))), id + ' : dégâts finis (ou absorbés par un bouclier)');
    ok([hero, ally].concat(foes).every(u => isFinite(u.hp) && u.hp >= 0 && u.hp <= u.maxHp), id + ' : PV dans les bornes');
    if (H.get(id).role === 'healer') ok(ev.some(e => e.type === 'heal'), id + ' : soigne réellement');
    if (H.get(id).role === 'tank') ok(ev.some(e => e.type === 'shield' || e.type === 'taunt'), id + ' : protège / provoque');
    if (H.get(id).role === 'control') ok(ev.some(e => e.type === 'stun'), id + ' : étourdit');
  });
  const full = ['velmora', 'krakenis', 'drakathor', 'selenia', 'arcanis'].map(id => CE.makeHeroUnit(H.get(id), 30, id));
  const wave = ['steel_golem', 'umbra_sniper', 'drone_sentinel'].map((id, i) => CE.makeEnemyUnit(EN.get(id), 'facile', i));
  const e2 = new CE.CombatEngine(full, wave, { mode: 'auto' });
  let guard = 0; while (!e2.isOver() && guard++ < 4000) e2.update(0.1);
  ok(e2.isOver(), 'un combat complet avec les nouveaux héros se termine');
}

section('Verrouillage : héros à recruter');
{
  ok(NEW.every(id => C.isUnlocked(id) === false), 'les 8 nouveaux héros sont verrouillés au départ');
  ok(H.all().filter(h => !h.shop).every(h => C.isUnlocked(h.id)), 'les 16 héros d\'origine restent débloqués');
  ok(C.isUnlocked('inconnu') === false, 'héros inconnu : refusé');
  ok(C.getTeam().every(id => !H.get(id).shop), 'équipe par défaut sans héros verrouillé');
  C.setTeam(['zyra', 'velmora', 'korvax']);
  ok(JSON.stringify(C.getTeam()) === JSON.stringify(['zyra', 'korvax']), 'un héros verrouillé ne peut pas entrer dans l\'équipe');
  ok(C.unlockHero('zyra').ok === false && C.unlockHero('nexiste_pas').ok === false, 'unlockHero refuse les héros de base / inconnus');
  R.state.shop.gems = 1000;
  ok(SM.buyHeroPack('hp_medium', 'velmora').reason === 'verrouille' && R.state.shop.gems === 1000, 'fragments d\'un héros verrouillé : refusés, rien de débité');
}

section('Achat en Boutique');
{
  R.state.shop.gems = 100;
  const poor = SM.buyHero('velmora');
  ok(poor.ok === false && poor.reason === 'ressources' && R.state.shop.gems === 100 && !C.isUnlocked('velmora'), 'Prismes insuffisants : refus, rien de débité');
  ok(SM.buyHero('zyra').reason === 'invalide' && SM.buyHero('xx').reason === 'invalide', 'héros de base / inconnu : achat invalide');
  R.state.shop.gems = 2000;
  const b = SM.buyHero('velmora');
  ok(b.ok && R.state.shop.gems === 2000 - 380 && C.isUnlocked('velmora'), 'achat de Velmora : 380 Prismes débités, héros débloqué');
  ok(SM.buyHero('velmora').reason === 'deja' && R.state.shop.gems === 1620, 'pas de double achat, pas de double débit');
  ok(SM.buyHeroPack('hp_medium', 'velmora').ok, 'après recrutement : ses fragments s\'achètent');
  C.setTeam(['zyra', 'velmora', 'korvax']);
  ok(C.getTeam().indexOf('velmora') >= 0, 'Velmora peut rejoindre l\'équipe');
  ok(SM.buyHero('vulkar').ok && SM.buyHero('zephyrax').ok, 'autres héros achetables (' + R.state.shop.gems + ' Prismes restants)');
  ok(SM.heroOffers().length === 23, 'heroOffers() liste les 23 offres');
}

section('Aetherion : Dieu obtenu uniquement par fragments');
{
  const h = H.get('aetherion');
  ok(!!h && h.role === 'god' && h.rarity === 'celeste', 'aetherion existe, rôle Dieu, rareté Céleste');
  ok(!!H.ROLES[h.role] && !!H.RARITIES[h.rarity], 'aetherion : rôle et rareté valides');
  ok(['hp', 'atk', 'def', 'spd'].every(k => h.base[k] > 0 && isFinite(h.base[k])), 'aetherion : stats valides');
  ok(h.skills.passive && h.skills.active && h.skills.ultimate && h.skills.ultimate.cost === 100, 'aetherion : 3 compétences complètes');
  ok(!!h.shop && !h.shop.cost && h.shop.fragmentsToUnlock > 0, 'aetherion : pas de prix, seuil de fragments défini');
  ok(!!CE.HERO_KIT.aetherion, 'aetherion : kit de combat dédié');
  const png = path.join(__dirname, '..', H.portraitFile('aetherion'));
  ok(fs.existsSync(png), 'aetherion : portrait présent');
  const sw2 = fs.readFileSync(path.join(__dirname, '..', 'sw.js'), 'utf8');
  ok(sw2.indexOf('assets/heroes/aetherion.png') >= 0, 'aetherion : portrait dans le cache hors-ligne (sw.js)');

  // Un stat supérieur (rareté Céleste) doit surpasser largement tout héros Mythique existant.
  const bestMythPower = Math.max(...H.byRarity('mythique').map(m => H.computePower(H.statsAtLevel(m, 1))));
  ok(H.computePower(H.statsAtLevel(h, 1)) > bestMythPower, 'aetherion : puissance au niveau 1 supérieure au meilleur Mythique');

  ok(C.isUnlocked('aetherion') === false, 'aetherion verrouillé au départ');
  R.state.shop.gems = 100000; R.state.res.dust = 100000; R.state.res.crystal = 100000;
  ok(SM.buyHero('aetherion').reason === 'invalide', 'aetherion : impossible de le recruter directement contre des Prismes');
  ok(SM.buyHeroPack('hp_small', 'aetherion').ok, 'aetherion verrouillé : ses fragments s\'achètent quand même');
  ok(C.isUnlocked('aetherion') === false, 'toujours verrouillé : pas encore assez de fragments');
  while ((R.state.combat.fragments.aetherion || 0) < h.shop.fragmentsToUnlock) SM.buyHeroPack('hp_large', 'aetherion');
  ok(C.isUnlocked('aetherion') === true, 'aetherion se déverrouille automatiquement une fois le seuil de fragments atteint');
  C.setTeam(['aetherion']);
  ok(C.getTeam().indexOf('aetherion') >= 0, 'aetherion peut rejoindre l\'équipe une fois déverrouillé');
  const beforeLvl = C.heroLevel('aetherion');
  ok(SM.buyHeroPack('hp_medium', 'aetherion').ok, 'aetherion déverrouillé : les fragments continuent de le faire progresser');
  ok(C.heroLevel('aetherion') >= beforeLvl, 'aetherion : le niveau ne peut pas régresser après un nouvel achat de fragments');

  const unit = CE.makeHeroUnit(h, 20, 'aetherion');
  ok(unit.hasKit === true && unit.maxHp > 0 && unit.atk > 0, 'aetherion : unité créée avec son kit');
}

section('Sauvegarde / chargement');
{
  R.saveNow(Date.now());
  const R2 = new NEBUSTION.ResourceManager(); R2.init(Date.now());
  const saved = R2.state.combat.unlockedHeroes;
  ok(saved.velmora === true && saved.vulkar === true && saved.zephyrax === true && !saved.krakenis, 'héros recrutés conservés après rechargement, les autres restent verrouillés');
  const old = JSON.parse(JSON.stringify(R.state)); delete old.combat.unlockedHeroes; NEBUSTION.Save.write(old, Date.now());
  const R3 = new NEBUSTION.ResourceManager(); R3.init(Date.now());
  ok(R3.state.combat.unlockedHeroes && Object.keys(R3.state.combat.unlockedHeroes).length === 0, 'ancienne sauvegarde sans le champ : chargée (aucun héros de Boutique)');
  const bad = JSON.parse(JSON.stringify(R.state)); bad.combat.unlockedHeroes = { velmora: 'oui', __proto__x: 1, drakathor: true }; NEBUSTION.Save.write(bad, Date.now());
  const R4 = new NEBUSTION.ResourceManager(); R4.init(Date.now());
  ok(R4.state.combat.unlockedHeroes.velmora === undefined && R4.state.combat.unlockedHeroes.drakathor === true, 'valeurs invalides ignorées à la lecture');
}

console.log('\n' + passed + ' réussis, ' + failed + ' échoués');
process.exit(failed ? 1 : 0);
