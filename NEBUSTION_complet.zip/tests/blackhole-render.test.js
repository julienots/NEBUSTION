/* NEBUSTION - test Node du rendu du Trou Noir (js/utils/BlackHoleRender.js) : physique, symétries, robustesse, coût.
 * Aucun navigateur : le moteur (makeEngine) est indépendant de Phaser. */
global.window = global; global.NEBUSTION = {};
var BR = require('../js/utils/BlackHoleRender.js');
var C = BR.CONST, fails = 0, n = 0;
function ok(c, m) { n++; if (!c) { fails++; console.error('ECHEC: ' + m); } }
function near(a, b, tol) { return Math.abs(a - b) <= tol; }

// ---------- 1. Géodésiques de Schwarzschild ----------
var tb = BR.buildTables();
ok(tb.outer.length === C.NB * C.NP && tb.inner.length === C.NB * C.NP, 'tables : dimensions attendues');
var allFinite = true, i;
for (i = 0; i < tb.outer.length; i++) if (!isFinite(tb.outer[i]) || !isFinite(tb.inner[i])) { allFinite = false; break; }
ok(allFinite, 'tables : aucune valeur non finie');
// champ faible : déviation totale ≈ 4M/b (relativité générale) → angle balayé ≈ π + 4/b
var last = C.NB - 1, bLast = C.BC * (1 + Math.pow(10, Math.log(((30 - C.BC) / C.BC)) / Math.LN10));
ok(near(bLast, 30, 0.05), 'table externe : dernier paramètre d\u2019impact = 30 (obtenu ' + bLast.toFixed(2) + ')');
ok(near(tb.phiEsc[last], Math.PI + 4 / 30, 0.03), 'déviation en champ faible ≈ 4/b (φ = ' + tb.phiEsc[last].toFixed(3) + ', attendu ' + (Math.PI + 4 / 30).toFixed(3) + ')');
// près du bord de l'ombre : les rayons font plus d'un demi-tour (anneau de photons)
ok(tb.phiEsc[0] > 2 * Math.PI, 'juste au-dessus de l\u2019ombre le rayon fait plus d\u2019un tour (φ = ' + tb.phiEsc[0].toFixed(2) + ')');
// monotonie : plus le rayon passe près, plus il est dévié
var mono = true;
for (i = 1; i < C.NB; i++) if (tb.phiEsc[i] > tb.phiEsc[i - 1] + 1e-3) { mono = false; break; }
ok(mono, 'déviation décroissante avec le paramètre d\u2019impact');
// rayon capté : la table interne finit par u = 0,5 (horizon r = 2)
var row = (C.NB - 1) * C.NP, cap = tb.inner[row + C.NP - 1];
ok(near(cap, 0.5, 1e-6), 'rayon très intérieur : capturé par l\u2019horizon (u = 1/2)');

// ---------- 2. Image : ombre, lentille, Doppler ----------
function render(res, cam, t) {
  var eng = BR.makeEngine(res), px = new Uint32Array(res * res);
  eng.frame(cam, t || 0, px);
  return { eng: eng, px: px, res: res };
}
function pix(r, x, y) { return r.px[y * r.res + x]; }
function luma(v) { return (v & 255) * 0.3 + ((v >>> 8) & 255) * 0.59 + ((v >>> 16) & 255) * 0.11; }
function lumaA(v) { return luma(v) * ((v >>> 24) / 255); }

var RES = 192, W = 19, deg = Math.PI / 180, half = RES / 2, sPx = W / half;
var shadowR = C.BC / sPx;                                  // rayon de l'ombre en pixels
var A = render(RES, { incl: 80 * deg, roll: 0, W: W, az: 0 });
var cxp = RES >> 1, cyp = RES >> 1;

// l'ombre est OPAQUE (aucune étoile du décor ne passe à travers) et noire. Vue à 10° du plan du disque, la partie proche du
// disque passe devant l'ombre en bas : on vérifie donc le noir pur dans la moitié HAUTE, et l'opacité partout.
var darkOk = true, opaqueOk = true, cnt = 0, cntAll = 0, dx, dy;
for (dy = -RES / 2; dy < RES / 2; dy++) for (dx = -RES / 2; dx < RES / 2; dx++) {
  var dd = Math.sqrt(dx * dx + dy * dy);
  if (dd < shadowR * 0.90) {
    cntAll++; var v = pix(A, cxp + dx, cyp + dy);
    if ((v >>> 24) !== 255) opaqueOk = false;
    if (dy < -shadowR * 0.15) { cnt++; if (luma(v) > 3) darkOk = false; }
  }
}
ok(cntAll > 1500 && opaqueOk, 'ombre : ' + cntAll + ' pixels, tous opaques (le décor ne transparaît pas)');
ok(cnt > 500 && darkOk, 'ombre : ' + cnt + ' pixels de la moitié haute noirs purs');
ok(shadowR > 20 && shadowR < 60, 'ombre : rayon en pixels plausible (' + shadowR.toFixed(1) + ')');

// anneau de photons : juste à l'extérieur de l'ombre, un liseré lumineux existe dans toutes les directions
var ringHits = 0, dirs = 24, d;
for (d = 0; d < dirs; d++) {
  var ang = d / dirs * 2 * Math.PI, best = 0, rr;
  for (rr = shadowR * 0.98; rr < shadowR * 1.12; rr += 0.5) { var vv = pix(A, Math.round(cxp + Math.cos(ang) * rr), Math.round(cyp - Math.sin(ang) * rr)); best = Math.max(best, lumaA(vv)); }
  if (best > 55) ringHits++;
}
ok(ringHits >= dirs - 1, 'anneau de photons visible sur le contour (' + ringHits + '/' + dirs + ' directions)');

// LENTILLE : par la tranche, la face cachée du disque apparaît AU-DESSUS de l'ombre (sans lentille ce serait noir)
var abovePx = pix(A, cxp, Math.round(cyp - shadowR * 1.18)), belowPx = pix(A, cxp, Math.round(cyp + shadowR * 1.18));
var farPx = pix(A, cxp, Math.round(cyp - shadowR * 2.6));
ok(lumaA(abovePx) > 60, 'lentille : le disque replié brille au-dessus de l\u2019ombre (luma ' + lumaA(abovePx).toFixed(0) + ')');
ok(lumaA(belowPx) > 40, 'lentille : idem sous l\u2019ombre (luma ' + lumaA(belowPx).toFixed(0) + ')');
ok(lumaA(abovePx) > lumaA(farPx) * 3, 'lentille : bien plus lumineux qu\u2019à distance (' + lumaA(farPx).toFixed(0) + ')');

// DOPPLER : la moitié gauche (matière qui s'approche) est plus brillante que la droite
function sumSide(r, left) {
  var s = 0, x, y;
  for (y = 0; y < r.res; y++) for (x = left ? 0 : r.res / 2; x < (left ? r.res / 2 : r.res); x++) s += lumaA(pix(r, x, y));
  return s;
}
var sL = sumSide(A, true), sR = sumSide(A, false);
ok(sL > sR * 1.25, 'Doppler : côté qui s\u2019approche plus brillant (' + sL.toFixed(0) + ' vs ' + sR.toFixed(0) + ')');
// … et le rouleau de caméra (roll = π) inverse cette asymétrie
var Aflip = render(RES, { incl: 80 * deg, roll: Math.PI, W: W, az: 0 });
ok(sumSide(Aflip, false) > sumSide(Aflip, true) * 1.25, 'Doppler : un roulis de 180° inverse la moitié brillante');

// SYMÉTRIE : vu de face (i≈0) l'image est presque à symétrie circulaire
var F = render(RES, { incl: 0.12, roll: 0, W: W, az: 0 });
function ringMean(r, rad) { var s = 0, k = 0, a; for (a = 0; a < 2 * Math.PI; a += 0.15) { s += lumaA(pix(r, Math.round(cxp + Math.cos(a) * rad), Math.round(cyp + Math.sin(a) * rad))); k++; } return { mean: s / k }; }
var fm = ringMean(F, shadowR * 1.9);
ok(fm.mean > 25, 'vu de face : le disque forme un anneau lumineux (luma moyenne ' + fm.mean.toFixed(0) + ')');

// ---------- 3. Temps, déterminisme, robustesse ----------
var A2 = render(RES, { incl: 80 * deg, roll: 0, W: W, az: 0 });
var same = true; for (i = 0; i < A.px.length; i++) if (A.px[i] !== A2.px[i]) { same = false; break; }
ok(same, 'déterminisme : deux rendus identiques sont identiques au bit près');

var eng = BR.makeEngine(RES), p0 = new Uint32Array(RES * RES), p3 = new Uint32Array(RES * RES), cam = { incl: 80 * deg, roll: 0, W: W, az: 0 };
var dirty1 = eng.frame(cam, 0, p0), dirty2 = eng.frame(cam, 3, p3);
ok(dirty1 === true && dirty2 === false, 'frame() : la géométrie n\u2019est recalculée que si la caméra bouge');
var diff = 0; for (i = 0; i < p0.length; i++) if (p0[i] !== p3[i]) diff++;
ok(diff > 500, 'le disque tourne : ' + diff + ' pixels changent entre t = 0 et t = 3 s');
var shadowSame = true;
for (dy = -RES / 2; dy < -shadowR * 0.15; dy++) for (dx = -RES / 2; dx < RES / 2; dx++) {
  if (Math.sqrt(dx * dx + dy * dy) < shadowR * 0.9 && (p0[(cyp + dy) * RES + cxp + dx] !== 0xff000000 || p3[(cyp + dy) * RES + cxp + dx] !== 0xff000000)) shadowSame = false;
}
ok(shadowSame, 'l\u2019ombre (moitié haute) reste un noir pur et opaque pendant la rotation');
// boucle de fondu des deux couches de turbulence : pas de saut à la période
var pa = new Uint32Array(RES * RES), pb = new Uint32Array(RES * RES);
eng.shade(BR.CONST.PERIOD - 0.02, pa); eng.shade(BR.CONST.PERIOD + 0.02, pb);
var jump = 0; for (i = 0; i < pa.length; i++) jump += Math.abs(luma(pa[i]) - luma(pb[i]));
ok(jump / pa.length < 2.5, 'pas de saut visible au recyclage de la turbulence (écart moyen ' + (jump / pa.length).toFixed(2) + ')');

// caméras extrêmes : pas de NaN, alpha valide
var extremes = [
  { incl: 0.10, roll: 0, W: 8.5, az: 0 }, { incl: 1.5, roll: 3.1, W: 44, az: 1.3 }, { incl: 1.5708, roll: 0, W: 19, az: 0 },
  { incl: 0, roll: 0, W: 5.4, az: 0 }, { incl: 1.2, roll: -6.5, W: 48, az: -2 }, { incl: 0.75, roll: 0.4, W: 5.0, az: 0.2 }
];
extremes.forEach(function (c) {
  var r = render(96, c, 1.7), bad = 0, k;
  for (k = 0; k < r.px.length; k++) { var a = r.px[k] >>> 24; if (a > 255) bad++; }
  // une valeur non finie donnerait un canal incohérent : on vérifie que les canaux calculés sont bornés et qu'il y a du contenu
  var lit = 0; for (k = 0; k < r.px.length; k++) if ((r.px[k] >>> 24) > 0) lit++;
  ok(bad === 0 && lit > 100, 'caméra extrême ' + JSON.stringify({ i: +c.incl.toFixed(2), r: +c.roll.toFixed(1), W: c.W }) + ' : image valide (' + lit + ' px)');
});

// lueur (bloom)
var e2 = BR.makeEngine(128), q = new Uint32Array(128 * 128), bl = new Uint32Array(e2.bloomSize * e2.bloomSize);
e2.frame({ incl: 1.3, roll: -0.4, W: 19, az: 0 }, 0, q); e2.bloom(bl);
var blMax = 0, blOpaque = true; for (i = 0; i < bl.length; i++) { blMax = Math.max(blMax, bl[i] & 255); if ((bl[i] >>> 24) !== 255) blOpaque = false; }
ok(blMax > 20 && blOpaque, 'lueur : présente (max ' + blMax + ') et opaque pour la fusion ADD');
var e3 = BR.makeEngine(128), q3 = new Uint32Array(128 * 128), bl3 = new Uint32Array(e3.bloomSize * e3.bloomSize);
e3.frame({ incl: 1.3, roll: -0.4, W: 60, az: 0 }, 0, q3); e3.bloom(bl3);   // caméra très lointaine : très peu de lueur
var s1 = 0, s3 = 0; for (i = 0; i < bl.length; i++) { s1 += bl[i] & 255; s3 += bl3[i] & 255; }
ok(s1 > s3, 'lueur : plus intense de près que de loin');

// ---------- 4. Coût (large marge : machines de CI lentes) ----------
var e4 = BR.makeEngine(160), px4 = new Uint32Array(160 * 160), c4 = { incl: 1.2, roll: -0.3, W: 19, az: 0 }, t0, k2, tot = 0;
for (k2 = 0; k2 < 6; k2++) { c4.incl += 0.01; e4.frame(c4, k2 * 0.05, px4); }
t0 = Date.now();
for (k2 = 0; k2 < 20; k2++) e4.shade(k2 * 0.05, px4);
tot = (Date.now() - t0) / 20;
ok(tot < 25, 'coût : passe de teinte 160 px = ' + tot.toFixed(2) + ' ms / image (< 25 ms)');
t0 = Date.now();
for (k2 = 0; k2 < 10; k2++) { c4.incl += 0.01; e4.geometry(c4); }
tot = (Date.now() - t0) / 10;
ok(tot < 120, 'coût : passe géométrique 160 px = ' + tot.toFixed(2) + ' ms (< 120 ms)');

console.log(n + ' vérifications, ' + fails + ' échec(s)');
process.exit(fails ? 1 : 0);
