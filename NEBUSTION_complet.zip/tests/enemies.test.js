/* Tests du module de données NEBUSTION.Enemies (Node, sans dépendance). Lancer : node tests/enemies.test.js */
'use strict';
global.window = global;
require('../js/data/Enemies.js');

const EN = NEBUSTION.Enemies;
let passed = 0, failed = 0;
function ok(cond, msg) { if (cond) { passed++; } else { failed++; console.log('  ✗ ECHEC : ' + msg); } }
function section(t) { console.log('\n# ' + t); }

section('Structure générale');
{
  ok(EN.ENEMY_LIST.length >= 10, 'au moins 10 ennemis réguliers (' + EN.ENEMY_LIST.length + ')');
  ok(EN.BOSS_LIST.length >= 3, 'au moins 3 boss (' + EN.BOSS_LIST.length + ')');
  const ids = EN.ENEMY_LIST.concat(EN.BOSS_LIST).map(e => e.id);
  ok(new Set(ids).size === ids.length, 'identifiants uniques (ennemis + boss)');
}

section('Chaque ennemi/boss a des données complètes et cohérentes');
{
  EN.ENEMY_LIST.concat(EN.BOSS_LIST).forEach(e => {
    ok(typeof e.id === 'string' && e.id.length > 0, e.id + ' : id valide');
    ok(typeof e.name === 'string' && e.name.length > 0, e.id + ' : nom présent');
    ['hp', 'atk', 'def', 'spd'].forEach(k => {
      ok(typeof e.base[k] === 'number' && e.base[k] > 0, e.id + ' : stat ' + k + ' > 0');
    });
    ok(!!e.visual && typeof e.visual.shape === 'string' && typeof e.visual.color === 'string', e.id + ' : identité visuelle définie');
    if (e.skill) {
      ok(typeof e.skill.cooldown === 'number' && e.skill.cooldown > 0, e.id + ' : compétence a un temps de recharge');
      ok(typeof e.skill.power === 'number' && e.skill.power > 0, e.id + ' : compétence a une puissance');
    }
  });
}

section('Boss : phases et bonus cohérents');
{
  EN.BOSS_LIST.forEach(b => {
    ok(b.isBoss === true, b.id + ' : marqué isBoss');
    ok(Array.isArray(b.phaseThresholds) && b.phaseThresholds.length >= 1, b.id + ' : au moins 1 seuil de phase');
    ok(b.phaseThresholds.every((t, i) => i === 0 || t < b.phaseThresholds[i - 1]), b.id + ' : seuils de phase décroissants');
    ok(!!b.phaseBonus, b.id + ' : bonus de phase défini');
    ok(b.base.hp > 3000, b.id + ' : PV de boss substantiels (' + b.base.hp + ')');
  });
  // Boss final plus fort que le premier boss
  const first = EN.get('vorath'), last = EN.get('omega_krell');
  ok(last.base.hp > first.base.hp, 'le boss final a plus de PV que le premier boss');
}

section('Stages : progression et unicité');
{
  const stages = EN.allStages();
  ok(stages.length >= 13, 'au moins 13 stages (10 ennemis + 3 boss) : ' + stages.length);
  const ids = stages.map(s => s.id);
  ok(new Set(ids).size === ids.length, 'identifiants de stage uniques');
  stages.forEach(s => {
    ok(Array.isArray(s.enemies) && s.enemies.length >= 1, s.id + ' : au moins un ennemi');
    s.enemies.forEach(eid => ok(!!EN.get(eid), s.id + ' : ennemi référencé existe (' + eid + ')'));
  });
  const bossStageCount = stages.filter(s => s.kind === 'boss').length;
  ok(bossStageCount === 3, 'exactement 3 stages de boss (' + bossStageCount + ')');
  ok(EN.firstStageId() === stages[0].id, 'firstStageId cohérent');
  ok(EN.nextStageId(stages[0].id) === stages[1].id, 'nextStageId avance d\'un cran');
  ok(EN.nextStageId(stages[stages.length - 1].id) === null, 'nextStageId du dernier stage = null');
}

section('Difficultés');
{
  ok(EN.DIFFICULTY_ORDER.length === 4, '4 niveaux de difficulté');
  EN.DIFFICULTY_ORDER.forEach(d => ok(!!EN.DIFFICULTIES[d], 'difficulté présente : ' + d));
  const base = EN.get('vorath');
  const facile = EN.statsForEnemy(base, 'facile');
  const normal = EN.statsForEnemy(base, 'normal');
  const cauchemar = EN.statsForEnemy(base, 'cauchemar');
  ok(facile.hp < normal.hp && normal.hp < cauchemar.hp, 'les PV augmentent avec la difficulté');
  ok(facile.atk < normal.atk && normal.atk < cauchemar.atk, 'l\'attaque augmente avec la difficulté');
  ok(facile.spd === normal.spd && normal.spd === cauchemar.spd, 'la vitesse est stable entre difficultés');
}

section('Récompenses');
{
  const stageDef = EN.stage('stage_01'), bossDef = EN.stage('boss_vorath');
  const r0 = EN.rewardsFor(stageDef, 'normal', 0);
  const r3 = EN.rewardsFor(stageDef, 'normal', 3);
  ok(r3.xp > r0.xp, 'plus d\'étoiles = plus de récompenses (xp)');
  ok(r3.fragments >= r0.fragments, 'plus d\'étoiles = plus ou autant de fragments');
  const bossReward = EN.rewardsFor(bossDef, 'normal', 3);
  const stageReward = EN.rewardsFor(stageDef, 'normal', 3);
  ok(bossReward.xp > stageReward.xp, 'un boss rapporte plus qu\'un stage normal');
  ok(typeof bossReward.core === 'number' && bossReward.core > 0, 'un boss rapporte des noyaux antiques');
  const hard = EN.rewardsFor(stageDef, 'cauchemar', 3);
  ok(hard.xp > r3.xp, 'une difficulté plus élevée rapporte plus');
}

section('Progression : échelle de stage, niveau recommandé, récompenses');
{
  const stages = EN.allStages();
  stages.forEach(s => {
    ok(typeof s.scale === 'number' && s.scale >= 1 && s.scale <= 6, s.id + ' : échelle de stage valide (' + s.scale + ')');
    ok(Array.isArray(s.recLevel) && s.recLevel.length === 4 && s.recLevel.every(n => Number.isInteger(n) && n >= 1 && n <= 60), s.id + ' : 4 niveaux recommandés valides');
    ok(s.recLevel.every((n, i) => i === 0 || n >= s.recLevel[i - 1]), s.id + ' : niveau recommandé croissant avec la difficulté');
    ok(typeof s.rewardMult === 'number' && s.rewardMult >= 1, s.id + ' : multiplicateur de récompense valide');
    ok(EN.recommendedLevel(s.id, 'normal') === s.recLevel[1], s.id + ' : recommendedLevel(normal)');
  });
  ok(EN.recommendedLevel('inconnu', 'normal') === 1, 'stage inconnu : niveau 1 par défaut');
  const bossLevels = stages.filter(s => s.kind === 'boss').map(s => EN.recommendedLevel(s.id, 'normal'));
  ok(bossLevels[0] < bossLevels[1] && bossLevels[1] < bossLevels[2], 'les 3 boss demandent des niveaux croissants : ' + bossLevels.join(' < '));
  const base = EN.get('drone_sentinel');
  ok(EN.statsForEnemy(base, 'normal', 2).hp === base.base.hp * 2, 'statsForEnemy applique l\'échelle du stage');
  ok(EN.statsForEnemy(base, 'normal').hp === base.base.hp, 'sans échelle : stats de base (rétrocompatible)');
  ok(EN.statsForEnemy(base, 'normal', 2).spd === base.base.spd, 'la vitesse ne dépend pas de l\'échelle');
  const early = EN.rewardsFor(EN.stage('stage_01'), 'normal', 3), late = EN.rewardsFor(EN.stage('stage_10'), 'normal', 3);
  ok(late.xp > early.xp && late.crystal > early.crystal, 'les stages avancés rapportent davantage');
}

console.log('\n' + (failed === 0 ? '✔ TESTS ENEMIES OK' : '✘ ÉCHECS DÉTECTÉS') + '  (' + passed + ' vérifications' + (failed ? ', ' + failed + ' échecs' : '') + ')');
process.exitCode = failed === 0 ? 0 : 1;
