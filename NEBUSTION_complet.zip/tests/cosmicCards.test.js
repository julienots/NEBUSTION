/* NEBUSTION — 5 cartes cosmiques ajoutées au roster Boutique/Combat. */
'use strict';
global.window = global;
const fs = require('fs'), path = require('path');
require('../js/data/Heroes.js');
require('../js/data/Enemies.js');
require('../js/systems/CombatEngine.js');
const H = NEBUSTION.Heroes, CE = NEBUSTION.CombatEngine;
const ids = ['auraxis', 'ravnor', 'kythar', 'glacivor', 'nymora'];
let passed = 0, failed = 0;
function ok(c, m) { if (c) passed++; else { failed++; console.log('  ✗ ' + m); } }
ids.forEach(id => {
  const h = H.get(id);
  ok(!!h, id + ' existe');
  if (!h) return;
  ok(!!h.shop && h.shop.cost && h.shop.cost.gem > 0, id + ' : achat Boutique');
  ok(!!H.RARITIES[h.rarity] && !!H.ROLES[h.role], id + ' : rareté/rôle valides');
  ok(['hp','atk','def','spd'].every(k => Number.isFinite(h.base[k]) && h.base[k] > 0), id + ' : stats valides');
  ok(h.skills && h.skills.passive && h.skills.active && h.skills.ultimate, id + ' : compétences complètes');
  ok(!!CE.HERO_KIT[id], id + ' : kit de combat branché');
  const png = path.join(__dirname, '..', H.portraitFile(id));
  ok(fs.existsSync(png), id + ' : illustration présente');
  if (fs.existsSync(png)) {
    const b = fs.readFileSync(png);
    ok(b.slice(1,4).toString() === 'PNG', id + ' : PNG valide');
    ok(b.readUInt32BE(16) === 300 && b.readUInt32BE(20) === 380, id + ' : portrait 300x380');
  }
  const unit = CE.makeHeroUnit(h, 1, id);
  ok(unit.hasKit === true && unit.maxHp > 0 && unit.atk > 0, id + ' : unité jouable');
});
const expected = { auraxis:['tank','legendaire'], ravnor:['dps','mythique'], kythar:['control','epique'], glacivor:['tank','legendaire'], nymora:['support','mythique'] };
ids.forEach(id => ok(H.get(id).role === expected[id][0] && H.get(id).rarity === expected[id][1], id + ' : correspond à la carte'));
console.log('\n' + (failed ? '✘ ' + failed + ' échec(s)' : '✔ CARTES COSMIQUES OK') + ' (' + passed + ' vérifications)');
process.exit(failed ? 1 : 0);
