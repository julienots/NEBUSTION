/* Tests de NEBUSTION.Skins (données pures, Node). Lancer : node tests/skins.test.js */
'use strict';
global.window = global;
require('../js/data/Economy.js');
require('../js/data/Heroes.js');
require('../js/data/Ships.js');
const K = require('../js/data/Skins.js');

let passed = 0, failed = 0;
function ok(c, m) { if (c) passed++; else { failed++; console.log('  ✗ ECHEC : ' + m); } }
function section(t) { console.log('\n# ' + t); }

section('Catalogue');
{
  ok(K.SKINS.length === 21, '21 skins (7 par type) : ' + K.SKINS.length);
  ok(new Set(K.SKINS.map(s => s.id)).size === K.SKINS.length, 'identifiants uniques');
  K.TARGET_TYPES.forEach(t => {
    const l = K.forTarget(t);
    ok(l.length === 7, t + ' : 7 skins');
    K.RARITY_ORDER.forEach(r => ok(l.some(s => s.rarity === r), t + ' : rareté ' + r + ' présente'));
  });
  K.SKINS.forEach(s => {
    ok(K.TARGET_TYPES.includes(s.target) && K.RARITIES[s.rarity] && K.FX[s.fx], s.id + ' : type, rareté et effet valides');
    ok(Number.isInteger(s.aura) && s.aura >= 0 && s.aura <= 0xffffff && Number.isInteger(s.hull), s.id + ' : couleurs valides');
    ok(s.target !== 'hero' ? s.tint === null : Number.isInteger(s.tint), s.id + ' : teinte cohérente avec le type');
    ok(typeof s.name === 'string' && s.name && s.desc, s.id + ' : nom et description');
  });
  ok(K.get('h_gold').name === 'Or Solaire' && K.get('nope') === null, 'get()');
  ok(K.BUILDING_TARGETS.every(id => NEBUSTION.Economy.BUILDINGS[id]), 'cibles bâtiment existent dans Economy');
}

section('Prix (croissants avec la rareté)');
{
  const tot = c => Object.values(c).reduce((a, b) => a + b, 0);
  const t = K.RARITY_ORDER.map(r => tot(K.cost(r)));
  ok(t.every((v, i) => i === 0 || v > t[i - 1]), 'prix total strictement croissant : ' + t.join(' < '));
  ok(K.price('h_gold').dust === K.COSTS.epique.dust, 'price(skinId) = coût de sa rareté');
  const c = K.cost('commun'); c.dust = 1;
  ok(K.COSTS.commun.dust === 600, 'cost() renvoie une copie (pas de mutation du barème)');
  ok(K.price('nope') === null, 'price() d\'un skin inconnu = null');
  const caps = { crystal: 15000, energy: 6000, dust: 30000, core: 300 };
  ok(Object.keys(K.cost('legendaire')).every(k => K.cost('legendaire')[k] <= caps[k]), 'le prix légendaire tient sous les plafonds de stockage de départ');
}

section('normalizeState');
{
  const d = K.defaultState();
  ok(JSON.stringify(d) === '{"owned":{},"equipped":{}}', 'état par défaut vide');
  [null, undefined, 42, 'x', [], { owned: 5, equipped: 'a' }].forEach(v => {
    const s = K.normalizeState(v);
    ok(Object.keys(s.owned).length === 0 && Object.keys(s.equipped).length === 0, 'entrée invalide (' + JSON.stringify(v) + ') → état vide');
  });
  const raw = {
    owned: { h_gold: true, s_royal: true, b_cyber: true, inconnu: true, h_cyan: false },
    equipped: {
      'hero:kael': 'h_gold', 'ship:sh3': 's_royal', 'building:command': 'b_cyber',
      'hero:zyra': 's_royal',            // mauvais type
      'hero:nyx': 'h_cyan',               // non possédé
      'hero:vega': 'fantome',             // inconnu
      'monstre:x': 'h_gold', 'sans-deux-points': 'h_gold', 'hero:': 'h_gold'
    }
  };
  const s = K.normalizeState(raw);
  ok(Object.keys(s.owned).sort().join() === 'b_cyber,h_gold,s_royal', 'possédés : inconnus et faux ignorés');
  ok(Object.keys(s.equipped).sort().join() === 'building:command,hero:kael,ship:sh3', 'équipés : seuls les valides sont gardés');
  ok(JSON.stringify(K.normalizeState(s)) === JSON.stringify(s), 'normalizeState est idempotent');
  const big = { owned: {}, equipped: {} }; K.SKINS.forEach(k => { big.owned[k.id] = true; });
  for (let i = 0; i < 500; i++) big.equipped['hero:h' + i] = 'h_cyan';
  ok(Object.keys(K.normalizeState(big).equipped).length === 200, 'équipements plafonnés à 200 entrées');
  const proto = K.normalizeState(JSON.parse('{"owned":{"__proto__":true,"constructor":true},"equipped":{"hero:__proto__":"h_cyan"}}'));
  ok(Object.keys(proto.owned).length === 0 && ({}).polluted === undefined, 'clés dangereuses ignorées');
}

console.log('\n' + (failed === 0 ? '✓ TOUS LES TESTS SONT PASSÉS' : '✗ ÉCHECS') + ' — ' + passed + ' réussis, ' + failed + ' échoués');
process.exit(failed ? 1 : 0);
