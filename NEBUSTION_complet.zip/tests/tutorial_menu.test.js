/* Tests du tutoriel (TutorialManager + TutorialOverlay) et du menu latéral rétractable (BottomNav),
 * avec un faux Phaser minimal (aucun rendu) : vérifie la logique, les interactions et l'absence d'erreurs.
 * Lancer : node tests/tutorial_menu.test.js */
'use strict';
global.window = global;
let passed = 0, failed = 0;
function ok(cond, msg) { if (cond) passed++; else { failed++; console.log('  ✗ ECHEC : ' + msg); } }
function section(t) { console.log('\n# ' + t); }

// ---------- Faux Phaser ----------
function mockObj(zones) {
  const handlers = {};
  const p = new Proxy(function () {}, {
    get(t, k) {
      if (k === 'on' || k === 'once') return (ev, fn) => { (handlers[ev] = handlers[ev] || []).push(fn); return p; };
      if (k === '__h') return handlers;
      if (k === 'list') return [];
      if (k === Symbol.toPrimitive) return () => 0;
      return () => p;
    },
    set() { return true; }
  });
  return p;
}
function makeScene() {
  const zones = [], tweens = [], started = [];
  const mk = () => mockObj();
  const scene = {
    scale: { width: 720, height: 1280 },
    zones, tweens, started, shutdownFns: [],
    events: { once(ev, fn) { if (ev === 'shutdown') scene.shutdownFns.push(fn); } },
    time: { delayedCall(ms, fn) { fn(); } },
    scene: { start(k, d) { started.push([k, d]); }, isActive() { return true; } },
    tweens: { add(cfg) { tweens.push(cfg); if (cfg && typeof cfg.onComplete === 'function') cfg.onComplete(); return { stop() {} }; } },
    add: {
      container: mk, graphics: mk, text: mk, rectangle: mk, circle: mk, image: mk,
      zone() { const z = mk(); zones.push(z); return z; },
      existing() {}
    }
  };
  return scene;
}
global.Phaser = { GameObjects: { Container: class { constructor(s) { this.scene = s; this.list = []; } add(c) { this.list.push(c); return this; } setDepth() { return this; } setAlpha() { return this; } } } };
global.NEBUSTION = {};
require('../js/systems/TutorialManager.js');
require('../js/ui/BottomNav.js');
require('../js/ui/TutorialOverlay.js');
const TM = NEBUSTION.TutorialManager, TO = NEBUSTION.TutorialOverlay, BN = NEBUSTION.BottomNav;
function fire(z, ev) { (z.__h[ev] || []).forEach(fn => fn({}, 0, 0, { stopPropagation() {} })); }

section('TutorialManager');
{
  ok(TM.steps().length >= 6 && TM.steps().every(s => s.id && s.icon && s.title && s.text), 'étapes complètes (id, icône, titre, texte)');
  ok(new Set(TM.steps().map(s => s.id)).size === TM.steps().length, 'identifiants d\'étapes uniques');
  ok(TM.steps().some(s => s.spot === 'nav'), 'une étape met en évidence le menu latéral');
  ok(TM.shouldShow() && !TM.isDone(), 'au départ : à afficher');
  TM.markDone(); ok(TM.isDone() && !TM.shouldShow(), 'markDone : ne s\'affiche plus');
  TM.reset(); ok(TM.shouldShow(), 'reset : de nouveau à afficher');
  ok(TM.normalizeState(null).done === false && TM.normalizeState({ done: true }).done === true && TM.normalizeState({ done: 'oui' }).done === false, 'normalizeState nettoie');
  const s = TM.steps(); s.pop(); ok(TM.steps().length === TM.STEPS.length, 'steps() renvoie une copie');
}

section('BottomNav : menu latéral rétractable');
{
  const scene = makeScene();
  let nav; try { nav = new BN(scene, 'pass'); } catch (e) { ok(false, 'construction sans erreur : ' + e.message); }
  ok(nav && !nav.isOpen && BN.current === nav, 'construit fermé, enregistré comme menu courant');
  const z = scene.zones;   // [bloc, croix, 6 lignes, onglet]
  ok(z.length === 9, '9 zones : bloc, croix, 6 sections, onglet (' + z.length + ')');
  fire(z[8], 'pointerup'); ok(nav.isOpen, 'tap sur l\'onglet : ouvre');
  fire(z[1], 'pointerup'); ok(!nav.isOpen, 'tap sur la croix : ferme');
  nav.toggle(true); nav.toggle(false); ok(!nav.isOpen, 'toggle(true) puis toggle(false)');
  nav.toggle(true); fire(z[2 + 5], 'pointerup');   // section active (pass)
  ok(!nav.isOpen && scene.started.length === 0, 'tap sur la section active : ferme sans changer de scène');
  nav.toggle(true); fire(z[2 + 4], 'pointerup');
  ok(scene.started.length === 1 && scene.started[0][0] === 'ShopScene' && scene.started[0][1].navKey === 'shop', 'tap sur Boutique : démarre ShopScene');
  scene.shutdownFns.forEach(f => f()); ok(BN.current === null, 'fermeture de la scène : menu courant libéré');
  const s2 = makeScene(); let n2; try { n2 = new BN(s2, null); } catch (e) { ok(false, 'activeKey null : ' + e.message); }
  ok(!!n2, 'construction avec activeKey = null (accueil)');
  ok(BN.HANDLE && BN.HANDLE.w > 0 && BN.HANDLE.cyRatio > 0 && BN.HANDLE.cyRatio < 1, 'géométrie de l\'onglet exposée');
}

section('TutorialOverlay : parcours complet');
{
  TM.reset();
  const scene = makeScene(); let closed = false;
  const nav = new BN(scene, null);
  scene.zones.length = 0;
  const api = TO.show(scene, { onClose() { closed = true; } });
  ok(api && scene._tutorialOverlay === api, 'overlay créé et enregistré sur la scène');
  ok(TO.show(scene) === null, 'pas de double affichage');
  const n = TM.steps().length;
  let mark = 0, tested = false;
  const latest = () => { const z = scene.zones.slice(mark); mark = scene.zones.length; return z; };
  for (let i = 0; i < n; i++) {
    let nz = latest();
    const last = i === n - 1;
    const expected = (i > 0 ? 1 : 0) + 1 + (last ? 0 : 1);
    ok(nz.length === expected, 'étape ' + (i + 1) + ' : ' + expected + ' zones interactives (' + nz.length + ')');
    if (i === 3 && !tested) {   // précédent puis suivant : revient à la même étape
      tested = true;
      fire(nz[0], 'pointerup'); const back = latest();
      ok(back.length === 3, 'précédent : étape 3 affichée (3 zones)');
      fire(back[1], 'pointerup'); nz = latest();
      ok(nz.length === 3, 'suivant : retour à l\'étape 4 (3 zones)');
    }
    fire(nz[i > 0 ? 1 : 0], 'pointerup');
  }
  ok(TM.isDone() && closed && scene._tutorialOverlay === null, 'terminer : marqué vu, overlay fermé, onClose appelé');
}

section('TutorialOverlay : passer, rejouer, changement de scène');
{
  TM.reset();
  const scene = makeScene();
  TO.show(scene);
  const skip = scene.zones[1];   // étape 1 : [suivant, passer]
  fire(skip, 'pointerup');
  ok(TM.isDone(), 'passer : marqué comme vu');
  const again = TO.show(scene); ok(again !== null, 'rejouable après fermeture (Paramètres → Revoir le tutoriel)');
  scene.shutdownFns.forEach(f => f()); ok(scene._tutorialOverlay === null, 'fermeture de scène : verrou libéré (pas de blocage définitif)');
  ok(TO.show(scene) !== null, 'réaffichable après un redémarrage de la scène');
}

console.log('\n' + (failed ? '✗ ÉCHECS — ' : '✓ TOUS LES TESTS SONT PASSÉS — ') + passed + ' réussis, ' + failed + ' échoués');
process.exit(failed ? 1 : 0);
