/* Tests d'intégration de NEBUSTION.EquipmentManager (Node, faux ResourceManager). Lancer : node tests/equipmentManager.test.js */
'use strict';
global.window = global;
require('../js/data/Economy.js');
require('../js/data/Heroes.js');
require('../js/data/Equipment.js');
require('../js/systems/CombatEngine.js');
require('../js/systems/EquipmentManager.js');

let passed = 0, failed = 0;
function ok(cond, msg) { if (cond) { passed++; } else { failed++; console.log('  ✗ ECHEC : ' + msg); } }
function section(t) { console.log('\n# ' + t); }

// ---------- Faux ResourceManager (ressources illimitées pour les tests de logique) ----------
function makeFakeResources(res) {
  return {
    state: { res: res, equipment: null },
    canAfford(cost) { return Object.keys(cost).every(k => (this.state.res[k] || 0) >= cost[k]); },
    spendMany(cost) { if (!this.canAfford(cost)) return false; Object.keys(cost).forEach(k => this.state.res[k] -= cost[k]); return true; },
    add(id, amount) { this.state.res[id] = (this.state.res[id] || 0) + amount; return amount; },
    saveNow() {}
  };
}

section('Fabrication (craft)');
{
  NEBUSTION.Resources = makeFakeResources({ metal: 1000, core: 1000, crystal: 0, energy: 0, dust: 0 });
  var r1 = NEBUSTION.EquipmentManager.craft('weapon', 'commun');
  ok(r1.ok, 'fabrication réussie avec assez de ressources');
  ok(NEBUSTION.EquipmentManager.list().length === 1, '1 objet dans l\'inventaire');

  NEBUSTION.Resources = makeFakeResources({ metal: 0, core: 0, crystal: 0, energy: 0, dust: 0 });
  var r2 = NEBUSTION.EquipmentManager.craft('weapon', 'commun');
  ok(!r2.ok && r2.reason === 'ressources', 'fabrication refusée sans ressources suffisantes');
}

section('Équiper / déséquiper');
{
  NEBUSTION.Resources = makeFakeResources({ metal: 5000, core: 5000, crystal: 0, energy: 0, dust: 0 });
  var w1 = NEBUSTION.EquipmentManager.craft('weapon', 'rare').item;
  var a1 = NEBUSTION.EquipmentManager.craft('armor', 'epique').item;

  var eqRes = NEBUSTION.EquipmentManager.equip('zyra', w1.uid);
  ok(eqRes.ok, 'équiper une arme sur zyra réussit');
  ok(NEBUSTION.EquipmentManager.equippedItem('zyra', 'weapon').uid === w1.uid, 'l\'arme équipée est la bonne');
  ok(NEBUSTION.EquipmentManager.isEquipped(w1.uid), 'isEquipped détecte l\'objet équipé');

  NEBUSTION.EquipmentManager.equip('zyra', a1.uid);
  ok(NEBUSTION.EquipmentManager.equippedItem('zyra', 'armor').uid === a1.uid, 'armure équipée sur le même héros');

  // Équiper la même arme sur un autre héros doit la retirer de zyra.
  NEBUSTION.EquipmentManager.equip('korvax', w1.uid);
  ok(!NEBUSTION.EquipmentManager.equippedItem('zyra', 'weapon'), 'l\'arme est retirée de zyra une fois donnée à korvax');
  ok(NEBUSTION.EquipmentManager.equippedItem('korvax', 'weapon').uid === w1.uid, 'l\'arme est bien sur korvax');

  NEBUSTION.EquipmentManager.unequip('korvax', 'weapon');
  ok(!NEBUSTION.EquipmentManager.equippedItem('korvax', 'weapon'), 'déséquiper fonctionne');
}

section('Amélioration et démantèlement');
{
  NEBUSTION.Resources = makeFakeResources({ metal: 5000, core: 5000, crystal: 0, energy: 0, dust: 0 });
  var it = NEBUSTION.EquipmentManager.craft('module', 'commun').item;
  var before = NEBUSTION.Equipment.bonusFor(it.slot, it.rarity, it.level);
  var up = NEBUSTION.EquipmentManager.upgrade(it.uid);
  ok(up.ok && up.item.level === 2, 'amélioration passe l\'objet au niveau 2');
  var after = NEBUSTION.Equipment.bonusFor(it.slot, it.rarity, up.item.level);
  ok(after.spd > before.spd, 'le bonus augmente après amélioration');

  var equippedGuard = NEBUSTION.EquipmentManager.equip('vega', it.uid);
  ok(equippedGuard.ok, 'équipement pour le test de garde');
  var blocked = NEBUSTION.EquipmentManager.dismantle(it.uid);
  ok(!blocked.ok && blocked.reason === 'equipe', 'démantèlement refusé si l\'objet est équipé');
  NEBUSTION.EquipmentManager.unequip('vega', 'module');
  var d = NEBUSTION.EquipmentManager.dismantle(it.uid);
  ok(d.ok && d.refund.metal > 0, 'démantèlement réussi une fois déséquipé, ressources rendues');
  ok(!NEBUSTION.EquipmentManager.get(it.uid), 'l\'objet démantelé disparaît de l\'inventaire');
}

section('Bonus réellement appliqués en combat (CombatEngine.makeHeroUnit)');
{
  NEBUSTION.Resources = makeFakeResources({ metal: 5000, core: 5000, crystal: 0, energy: 0, dust: 0 });
  var H = NEBUSTION.Heroes, CE = NEBUSTION.CombatEngine, EM = NEBUSTION.EquipmentManager;
  var hero = H.get('drakor');

  var unitWithout = CE.makeHeroUnit(hero, 10, 'drakor', EM.bonusForHero('drakor'));
  var w2 = EM.craft('weapon', 'legendaire').item;
  EM.equip('drakor', w2.uid);
  var unitWith = CE.makeHeroUnit(hero, 10, 'drakor', EM.bonusForHero('drakor'));

  ok(unitWith.atk > unitWithout.atk, 'l\'attaque du héros augmente réellement avec l\'arme équipée (' + unitWithout.atk + ' -> ' + unitWith.atk + ')');
  ok(unitWith.maxHp === unitWithout.maxHp, 'les PV ne changent pas (seule l\'arme influence l\'attaque)');
}

section('Nouveaux emplacements (réacteur / artefact)');
{
  NEBUSTION.Resources = makeFakeResources({ metal: 5000, core: 5000, crystal: 0, energy: 0, dust: 0 });
  var reactor = NEBUSTION.EquipmentManager.craft('reactor', 'commun');
  var artifact = NEBUSTION.EquipmentManager.craft('artifact', 'commun');
  ok(reactor.ok, 'fabrication d\'un réacteur réussie');
  ok(artifact.ok, 'fabrication d\'un artefact réussie');
  var eq = NEBUSTION.EquipmentManager.equip('nyx', reactor.uid);
  ok(eq.ok && NEBUSTION.EquipmentManager.equippedItem('nyx', 'reactor').uid === reactor.uid, 'réacteur équipable comme les autres emplacements');
}

section('Fusion');
{
  NEBUSTION.Resources = makeFakeResources({ metal: 5000, core: 5000, crystal: 0, energy: 0, dust: 0 });
  var EM = NEBUSTION.EquipmentManager;
  var m1 = EM.craft('module', 'commun').item;
  var m2 = EM.craft('module', 'commun').item;
  ok(EM.findFusionMatch(m1.uid) === m2.uid, 'un doublon identique non équipé est trouvé pour la fusion');

  var fused = EM.fuse(m1.uid, m2.uid);
  ok(fused.ok, 'la fusion de 2 objets identiques réussit');
  ok(fused.item.rarity === 'rare' && fused.item.level === 1, 'la fusion donne un objet de rareté supérieure au niveau 1');
  ok(!EM.get(m1.uid) && !EM.get(m2.uid), 'les 2 objets fusionnés disparaissent de l\'inventaire');

  var wA = EM.craft('weapon', 'commun').item;
  var wB = EM.craft('weapon', 'rare').item;
  var mismatch = EM.fuse(wA.uid, wB.uid);
  ok(!mismatch.ok && mismatch.reason === 'incompatible', 'la fusion est refusée entre objets de raretés différentes');

  var legA = EM.craft('module', 'legendaire').item;
  var legB = EM.craft('module', 'legendaire').item;
  var atMax = EM.fuse(legA.uid, legB.uid);
  ok(!atMax.ok && atMax.reason === 'rarete_max', 'la fusion est refusée à la rareté maximale');

  var eqA = EM.craft('armor', 'commun').item;
  var eqB = EM.craft('armor', 'commun').item;
  EM.equip('nyx', eqA.uid);
  var blockedFuse = EM.fuse(eqA.uid, eqB.uid);
  ok(!blockedFuse.ok && blockedFuse.reason === 'equipe', 'la fusion est refusée si un des objets est équipé');
}

console.log('\n' + (failed === 0 ? '✓ TOUS LES TESTS SONT PASSÉS' : '✗ ÉCHECS DÉTECTÉS') + ' — ' + passed + ' réussis, ' + failed + ' échoués');
process.exit(failed === 0 ? 0 : 1);
