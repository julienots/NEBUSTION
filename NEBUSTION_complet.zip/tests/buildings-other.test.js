/* NEBUSTION - bâtiments de Nexus-01 SANS rapport avec les ressources : bouclier, académie, spatioport, forge d'éclats, centre de formation.
   node tests/buildings-other.test.js */
global.window = global;
global.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} };
var fs = require('fs'), vm = require('vm'), path = require('path'), root = path.join(__dirname, '..'), fails = 0, checks = 0;
function ok(c, m) { checks++; if (!c) { fails++; console.log('ÉCHEC : ' + m); } }
function load(f) { vm.runInThisContext(fs.readFileSync(path.join(root, f), 'utf8'), { filename: f }); }
['js/data/Economy.js', 'js/data/PlanetBuild.js', 'js/data/Security.js', 'js/data/Heroes.js', 'js/data/Equipment.js', 'js/data/Skins.js', 'js/data/Crates.js', 'js/data/Pass.js', 'js/data/Expeditions.js',
 'js/systems/SaveManager.js', 'js/systems/ResourceManager.js'].forEach(load);
var N = NEBUSTION, PB = N.PlanetBuild;
var R = new N.ResourceManager({ Economy: N.Economy, Save: N.Save });
R.state = N.Save.normalize(null, Date.now()); R.state.planetBuild = PB.defaultState(); R.saveNow = function () {};
N.Economy.ORDER.forEach(function (id) { R.state.res[id] = 1e7; });
N.Resources = R;
var types = ['shield', 'academy', 'spaceport', 'forge', 'training'];
types.forEach(function (t) { var d = PB.CATALOG[t]; ok(d && PB.ORDER.indexOf(t) >= 0 && d.effect && d.badge && d.info && Object.keys(d.base).length <= 2, t + ' au catalogue (effet, badge, ≤ 2 coûts)'); });
ok(PB.ORDER.length === 19, '19 bâtiments au total');
var total = PB.ORDER.reduce(function (n, t) { return n + PB.CATALOG[t].maxCount; }, 0);
ok(PB.MAX_TOTAL === 42 && total > PB.MAX_TOTAL, 'limite totale 42 (les maximums cumulés la dépassent : choix à faire)');

function put(t, i) { var r = PB.place(R, t, (i * 55) % 360 - 180, (i % 3) * 25 - 25, []); return r; }
var k = 0;
// --- Bouclier : +1 niveau de sécurité effectif par générateur (plafonné au niveau max)
load('js/systems/SecurityManager.js');
var SM = N.SecurityManager, s0 = SM.effectiveLevel();
ok(put('shield', k++).ok && SM.effectiveLevel() === Math.min(N.Security.MAX_LEVEL, s0 + 1), 'bouclier : +1 sécurité');
put('shield', k++); put('shield', k++); ok(!put('shield', k++).ok, '4e bouclier refusé (max 3)');
ok(SM.effectiveLevel() === Math.min(N.Security.MAX_LEVEL, s0 + 3), 'bouclier ×3 : +3 sécurité (borné)');
// --- Forge d'éclats : +15 % des Éclats gagnés par ouverture
load('js/systems/CrateManager.js');
N.Combat = { isUnlocked: function () { return true; }, addFragments: function () { return { ok: true }; } };
N.EquipmentManager = { grant: function (slot, r) { return { ok: true, item: { slot: slot, rarity: r } }; } };
N.ShopManager = { addGems: function () {} }; load('js/systems/SkinManager.js');
var CM = N.CrateManager, K = N.Crates;
function shardsFor(n) { var got = []; for (var i = 0; i < n; i++) { CM.addCrate('astral', 1); CM.addKey('astral', 1); var b0 = CM.shards(), r = CM.open('astral'); got.push({ rar: r.reward.rarity, gain: CM.shards() - b0, bonus: r.bonusShards }); } return got; }
var before = shardsFor(40).filter(function (x) { return x.rar === 'legendaire' || x.rar === 'epique'; });
ok(put('forge', k++).ok && put('forge', k++).ok, 'forges posées');
var after = shardsFor(60), leg = after.filter(function (x) { return x.rar === 'legendaire'; }), epi = after.filter(function (x) { return x.rar === 'epique'; });
ok(after.every(function (x) { return x.bonus === Math.round(K.BONUS_SHARDS[x.rar] * 1.3); }), 'forge ×2 : Éclats bonus +30 % (' + after.slice(0, 3).map(function (x) { return x.rar + ':' + x.bonus; }).join(', ') + ')');
// --- Centre de formation : +10 % d'XP de Pass
load('js/systems/PassManager.js');
var PM = N.PassManager;
R.state.pass = N.Pass.defaultState ? N.Pass.defaultState(Date.now()) : R.state.pass;
var x0 = R.state.pass.xp; PM.addXp(1000); var d0 = R.state.pass.xp - x0;
ok(put('training', k++).ok && put('training', k++).ok, 'centres de formation posés');
x0 = R.state.pass.xp; var r1 = PM.addXp(1000); var d1 = R.state.pass.xp - x0;
ok(d0 === 1000 && d1 === 1200 && r1.gained === 1200, 'XP Pass +20 % avec 2 centres (' + d0 + ' → ' + d1 + ')');
ok(PM.addXp(0).gained === 0 && PM.addXp(-50).gained === 0, 'XP nulle/négative inchangée');
// --- Spatioport : durée des expéditions réduite (jamais > 60 %, Éclair instantané)
load('js/systems/ExpeditionManager.js');
var EM = N.ExpeditionManager, m = { durationSec: 1000 }, e0 = EM.effectiveDuration(m);
ok(e0 === 1000 && EM.effectiveDuration({ durationSec: 0 }) === 0, 'sans spatioport : durée inchangée, Éclair = 0');
ok(put('spaceport', k++).ok && EM.effectiveDuration(m) === 920, 'spatioport : −8 % (920 s)');
put('spaceport', k++); put('spaceport', k++); ok(EM.effectiveDuration(m) === 760 && !put('spaceport', k++).ok, '3 spatioports : −24 % (760 s), 4e refusé');
// --- Académie : bonus de combat (heroPower des expéditions) +2 % chacune
var C = N.Combat; C.heroLevel = function () { return 5; }; C.getTeam = function () { return []; };
var hid = N.Heroes.all()[0].id, hp0 = EM.heroPower(hid);
ok(put('academy', k++).ok && put('academy', k++).ok, 'académies posées');
var hp1 = EM.heroPower(hid); ok(hp1 > hp0 && Math.abs(hp1 / hp0 - 1.04) < 0.01, 'puissance de héros +4 % avec 2 académies (' + hp0 + ' → ' + hp1 + ')');
// --- Recyclage : le bonus disparaît
var id = R.state.planetBuild.items.filter(function (i) { return i.type === 'academy'; })[0].id; PB.recycle(R, id);
ok(Math.abs(PB.effectSum(R.state.planetBuild, 'combatPower') - 0.02) < 1e-9, 'recyclage retire le bonus');
// --- Sauvegarde / entrées invalides
ok(PB.effectSum(null, 'security') === 0 && PB.effectSum({ items: [{ type: 'zzz' }] }, 'passXp') === 0, 'entrées invalides sans erreur');
console.log(checks + ' vérifications, ' + fails + ' échec(s)'); process.exit(fails ? 1 : 0);
