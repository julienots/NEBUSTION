global.window = global;
var fs = require('fs'), vm = require('vm'), path = require('path');
function load(f) { vm.runInThisContext(fs.readFileSync(path.join(__dirname, '..', f), 'utf8'), { filename: f }); }
['js/data/Economy.js', 'js/data/Colonies.js'].forEach(load);
var wallet = { crystal: 1e6, metal: 1e6, energy: 1e6, core: 1e3, dust: 1e6 }, capRoom = Infinity;
NEBUSTION.Resources = { state: {}, saveNow: function () {},
  canAfford: function (c) { return Object.keys(c).every(function (k) { return wallet[k] >= c[k]; }); },
  spendMany: function (c) { Object.keys(c).forEach(function (k) { wallet[k] -= c[k]; }); return true; },
  add: function (id, a) { var x = Math.min(a, capRoom); wallet[id] += x; return x; } };
load('js/systems/ColonyManager.js');
var CM = NEBUSTION.ColonyManager, K = NEBUSTION.Colonies, fails = 0, n = 0;
function ok(c, m) { n++; if (!c) { fails++; console.log('FAIL', m); } }
var T0 = 1700000000000;

ok(CM.count() === 0 && !CM.isColonized('pyros'), 'départ sans colonie');
ok(CM.colonize('nope').reason === 'invalide', 'planète inconnue');
var w0 = wallet.metal; var r = CM.colonize('pyros', T0);
ok(r.ok && wallet.metal === w0 - 4000 && CM.isColonized('pyros') && CM.level('pyros', 'forge') === 1, 'fondation + coût');
ok(CM.colonize('pyros', T0).reason === 'deja', 'double fondation refusée');
wallet.metal = 0; ok(CM.colonize('aqualis', T0).reason === 'ressources' && !CM.isColonized('aqualis'), 'fondation sans ressources'); wallet.metal = 1e6;

// production : 1 colonie => ×1,05 ; 100 s
var rate = K.rateAt('pyros', 'forge', 1) * 1.05;
var p = CM.pending('pyros', T0 + 100000);
ok(Math.abs(p.metal - rate * 100) < 1e-9, 'production/100 s');
// plafond 4 h (hors ligne)
var pMax = CM.pending('pyros', T0 + 999 * 3600 * 1000);
ok(Math.abs(pMax.metal - rate * K.CAP_SEC) < 1e-6 && CM.isFull('pyros', T0 + 999 * 3600 * 1000), 'plafond de temps');
// récolte
var m0 = wallet.metal; var c = CM.collect('pyros', T0 + 100000);
ok(c.ok && Math.abs(wallet.metal - m0 - rate * 100) < 1e-6, 'récolte crédite');
ok(CM.pendingTotal('pyros', T0 + 100000) === 0, 'récolte remet à zéro');
// stockage plein : rien de perdu, colonie garde le reste
capRoom = 0; var c2 = CM.collect('pyros', T0 + 200000); ok(!c2.ok && c2.reason === 'plein', 'stockage plein');
ok(CM.pendingTotal('pyros', T0 + 200000) > 0, 'reste dans la colonie');
capRoom = Infinity;
// amélioration
var lv0 = CM.level('pyros', 'geo'); var cost = K.upgradeCost('pyros', 'geo', lv0);
var r2 = CM.upgrade('pyros', 'geo', T0 + 200000);
ok(r2.ok && CM.level('pyros', 'geo') === lv0 + 1, 'amélioration');
ok(cost.metal === Math.ceil(700 * 1.6), 'coût ×1,6');
wallet.metal = 0; ok(CM.upgrade('pyros', 'geo', T0).reason === 'ressources', 'amélioration sans ressources'); wallet.metal = 1e6;
for (var i = 0; i < 20; i++) CM.upgrade('pyros', 'forge', T0 + 300000);
ok(CM.level('pyros', 'forge') === K.MAX_LEVEL && CM.upgrade('pyros', 'forge', T0).reason === 'max', 'niveau max');
ok(CM.upgrade('aqualis', 'perle').reason === 'invalide', 'amélioration sans colonie');
// bonus global
CM.colonize('aqualis', T0); CM.colonize('glacia', T0);
ok(Math.abs(CM.bonusMult() - 1.15) < 1e-9 && CM.count() === 3, 'bonus ×1,15 avec 3 colonies');
var ca = CM.collectAll(T0 + 600000); ok(ca.ok && ca.gained.crystal > 0, 'collectAll');
// normalisation robuste
var bad = K.normalizeState({ colonies: { pyros: { on: true, last: 'x', lv: { forge: 999, geo: -3, noyau: NaN } }, fake: { on: true }, rubea: 5 } }, T0);
ok(bad.colonies.pyros.on && bad.colonies.pyros.lv.forge === K.MAX_LEVEL && !bad.colonies.pyros.lv.geo && !bad.colonies.pyros.lv.noyau && bad.colonies.pyros.last === T0, 'normalisation bornes');
ok(!bad.colonies.fake && !bad.colonies.rubea.on, 'normalisation inconnues');
['null', 'undefined', '"x"', '[]', '{}'].forEach(function (j) { var s = K.normalizeState(j === 'undefined' ? undefined : JSON.parse(j), T0); ok(K.IDS.every(function (id) { return s.colonies[id] && !s.colonies[id].on; }), 'normalisation ' + j); });
var fut = K.normalizeState({ colonies: { glacia: { on: true, last: T0 * 2, lv: {} } } }, T0); ok(fut.colonies.glacia.last === T0, 'date future ramenée');
// équilibrage : chaque planète a 3 installations, ressources valides, coûts payables
K.IDS.forEach(function (id) { var d = K.get(id); ok(d.inst.length === 3, id + ' 3 installations');
  d.inst.forEach(function (i) { ok(NEBUSTION.Economy.RES[i.res] && i.rate > 0, id + '/' + i.id + ' ressource'); Object.keys(i.cost).forEach(function (k) { ok(NEBUSTION.Economy.RES[k], 'coût ' + k); }); });
  Object.keys(d.colonize).forEach(function (k) { ok(NEBUSTION.Economy.RES[k], 'colonize ' + k); }); });
console.log(n - fails + '/' + n + ' vérifications OK' + (fails ? ' — ' + fails + ' ÉCHEC(S)' : ''));
process.exit(fails ? 1 : 0);
