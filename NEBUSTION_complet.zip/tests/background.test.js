/* Test Node : les textures de fond spatial sont répétables sans couture (repli sur les bords). */
const fs = require('fs'), path = require('path'), vm = require('vm');
let passed = 0, failed = 0;
const ok = (c, m) => { if (c) passed++; else { failed++; console.log('  ✘ ' + m); } };

// Faux canvas 2D qui enregistre les dessins
function makeCtx(rec) {
  const noop = () => {};
  return new Proxy({}, {
    get(t, k) {
      if (k === 'createRadialGradient') return () => ({ addColorStop: noop });
      if (k === 'arc') return (x, y, r) => rec.arcs.push({ x, y, r });
      if (k === 'fillRect') return (x, y, w, h) => rec.rects.push({ x, y, w, h });
      if (k in t) return t[k];
      return noop;
    },
    set(t, k, v) { t[k] = v; return true; }
  });
}
const rec = { arcs: [], rects: [] };
const scene = { textures: { exists: () => false, createCanvas: (key, w, h) => ({ context: makeCtx(rec), refresh() {}, w, h }) } };
const ctxWin = {}; ctxWin.window = ctxWin;
vm.createContext(ctxWin);
vm.runInContext(fs.readFileSync(path.join(__dirname, '../js/utils/TextureGenerator.js'), 'utf8'), ctxWin);
const TG = ctxWin.NEBUSTION.TextureGenerator;

// 1) Tuile d'étoiles : tout élément qui touche un bord a sa copie de l'autre côté
[['far', 1024, 220], ['near', 512, 35]].forEach(([n, size, count]) => {
  rec.arcs = [];
  TG.generateStarfieldTile(scene, 'k_' + n, size, size, count, 0.5);
  const arcs = rec.arcs;
  ok(arcs.length >= count, 'étoiles dessinées (' + n + ')');
  const has = (x, y, r) => arcs.some(a => Math.abs(a.x - x) < 1e-6 && Math.abs(a.y - y) < 1e-6 && Math.abs(a.r - r) < 1e-6);
  let checked = 0;
  arcs.forEach(a => {
    if (a.x - a.r < 0) { ok(has(a.x + size, a.y, a.r) || a.x >= 0 && a.x - a.r >= 0, 'copie droite ' + n); checked++; }
    if (a.x + a.r > size) { ok(has(a.x - size, a.y, a.r), 'copie gauche ' + n); checked++; }
    if (a.y - a.r < 0) { ok(has(a.x, a.y + size, a.r), 'copie bas ' + n); checked++; }
    if (a.y + a.r > size) { ok(has(a.x, a.y - size, a.r), 'copie haut ' + n); checked++; }
  });
  ok(true, 'tuile ' + n + ' : ' + checked + ' raccords de bord vérifiés');
});

// 2) Poussière spatiale : même contrôle
rec.arcs = [];
TG.generateSpaceDustTile(scene, 'k_dust', 1024);
{
  const size = 1024, arcs = rec.arcs;
  ok(arcs.length >= 16, 'nuages de poussière dessinés');
  arcs.forEach(a => {
    if (a.x - a.r < 0) ok(arcs.some(b => Math.abs(b.x - (a.x + size)) < 1e-6 && Math.abs(b.y - a.y) < 1e-6), 'poussière : raccord droite');
    if (a.x + a.r > size) ok(arcs.some(b => Math.abs(b.x - (a.x - size)) < 1e-6 && Math.abs(b.y - a.y) < 1e-6), 'poussière : raccord gauche');
    if (a.y - a.r < 0) ok(arcs.some(b => Math.abs(b.y - (a.y + size)) < 1e-6 && Math.abs(b.x - a.x) < 1e-6), 'poussière : raccord bas');
    if (a.y + a.r > size) ok(arcs.some(b => Math.abs(b.y - (a.y - size)) < 1e-6 && Math.abs(b.x - a.x) < 1e-6), 'poussière : raccord haut');
  });
}

// 3) generateAll ne plante pas et crée bien la nouvelle texture
const made = [];
const scene2 = { textures: { exists: () => false, createCanvas: (k) => { made.push(k); return { context: makeCtx({ arcs: [], rects: [] }), refresh() {} }; } } };
TG.generateAll(scene2);
ok(made.includes('tex_space_dust') && made.includes('tex_starfield_far') && made.includes('tex_nebula_purple'), 'generateAll crée dust + starfield + nébuleuses');

console.log('\n' + (failed === 0 ? '✔ TESTS FOND SPATIAL OK' : '✘ ' + failed + ' échec(s)') + ' (' + passed + ' vérifications)');
process.exit(failed === 0 ? 0 : 1);
