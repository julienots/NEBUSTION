/* Nouvelles mécaniques du combat de QG : frappe orbitale du Commandant, formation/escouade, objets.
 * Lancer : node tests/qgBattle_mechanics.test.js */
'use strict';
const { makeCounter } = require('./progress-env');
const c = makeCounter(), ok = c.ok, section = c.section;
const QB = NEBUSTION.QGBattle, T = NEBUSTION.Troops;

function base() {
  return QB.buildBase({ unlocked: {}, cells: { '0,0': 'turret', '1,1': 'wall' } }, { scale: 1 });
}

section('Frappe orbitale du Commandant');
{
  const sim = QB.create(base(), { marine: 20 });
  ok(sim.strikeCharge === 0, 'jauge à 0 au départ');
  ok(!sim.strikeReady(), 'pas prête au départ');
  const r0 = sim.useStrike(0, 0);
  ok(r0.ok === false && r0.reason === 'charge', 'refusée si jauge non pleine');

  for (let i = 0; i < 15; i++) sim.deploy('marine', -1.4, 3 + i * 0.04);
  run(sim, 40);
  ok(sim.strikeCharge > 0, 'la jauge progresse avec les dégâts infligés : ' + sim.strikeCharge.toFixed(1));
}

{
  const sim = QB.create(base(), { marine: 5 });
  sim.strikeCharge = 100;
  ok(sim.strikeReady(), 'prête à 100');
  const turret = sim.buildings.find(b => b.kind === 'turret');
  const before = turret.hp;
  const res = sim.useStrike(turret.x, turret.y);
  ok(res.ok === true, 'la frappe orbitale se déclenche');
  ok(turret.hp < before, 'la structure ciblée perd des PV : ' + before + ' -> ' + turret.hp);
  ok(sim.strikeCharge === 0, 'la jauge est remise à zéro après usage');
  const res2 = sim.useStrike(turret.x, turret.y);
  ok(res2.ok === false, 'ne peut pas être réutilisée immédiatement');
}

section('Formation / escouade (positionnement avant-arrière)');
{
  const sim = QB.create(base(), { marine: 10, sniper: 10 });
  const meleeDef = T.get('marine'), rangedDef = T.get('sniper');
  ok(meleeDef.range <= 1, 'la troupe de mêlée a une portée courte (référence pour "avant")');
  ok(rangedDef.range > 1, 'la troupe de tir a une portée longue (référence pour "arrière")');
  const res = sim.deploySquad(['marine', 'sniper'], -1.4, 3);
  ok(res.ok === true, 'déploiement groupé réussi');
  ok(sim.troops.length === 2, 'les 2 troupes sont déployées en un seul appel');
  const melee = sim.troops.find(u => u.type === 'marine');
  const ranged = sim.troops.find(u => u.type === 'sniper');
  const center = QB.GRID / 2;
  const dMelee = Math.abs(melee.x - center) + Math.abs(melee.y - center);
  const dRanged = Math.abs(ranged.x - center) + Math.abs(ranged.y - center);
  ok(dMelee < dRanged, 'la mêlée (avant) est déployée plus près de la base que le tir (arrière) : ' + dMelee.toFixed(2) + ' vs ' + dRanged.toFixed(2));
}
{
  const sim = QB.create(base(), { marine: 3 });
  const bad = sim.deploySquad(['marine'], 3, 3); // au centre de la base = hors zone de déploiement
  ok(bad.ok === false, 'refuse une escouade hors zone de déploiement');
}

section('Objets/consommables en combat de QG');
{
  const sim = QB.create(base(), { marine: 10 });
  ok(sim.items.medkit.charges === 1, 'kit de soin disponible avec 1 charge par défaut');
  sim.deploy('marine', -1.4, 0);
  const troop = sim.troops[0];
  troop.hp = 1;
  const res = sim.useItem('medkit', troop.x, troop.y);
  ok(res.ok === true, 'utilisation du kit de soin réussie');
  ok(troop.hp > 1, 'la troupe est soignée : hp=' + troop.hp);
  ok(sim.items.medkit.charges === 0, 'charge consommée');
  const res2 = sim.useItem('medkit', troop.x, troop.y);
  ok(res2.ok === false && res2.reason === 'stock', 'plus de charge disponible');
}
{
  const sim = QB.create(base(), { marine: 5 });
  sim.deploy('marine', -1.4, 0);
  const troop = sim.troops[0];
  const res = sim.useItem('shield_drone', troop.x, troop.y);
  ok(res.ok === true, 'bouclier posé');
  ok(troop._shieldUntil > sim.t, 'la troupe est protégée temporairement');
}
{
  const sim = QB.create(base(), { marine: 5 });
  const before = sim.buildings.find(b => b.kind === 'turret').hp;
  sim.useItem('emp_grenade', 0, 0);
  const after = sim.buildings.find(b => b.kind === 'turret').hp;
  ok(after < before, 'la grenade EMP endommage les structures dans son rayon : ' + before + ' -> ' + after);
}

function run(sim, secs) { for (let i = 0; i < secs * 20 && !sim.over; i++) sim.step(0.05); }

c.done('Mécaniques de combat QG (frappe orbitale, formation, objets)');
