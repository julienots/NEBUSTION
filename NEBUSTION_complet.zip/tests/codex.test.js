/**
 * Tests purs de NEBUSTION.Codex (aucune dépendance à Phaser/localStorage).
 */
global.window = global.window || global;
require('../js/data/Codex.js');

var pass = 0, fail = 0;
function check(label, cond) {
  if (cond) { pass++; } else { fail++; console.log('  \u2717 ' + label); }
}

(function () {
  var Codex = window.NEBUSTION.Codex;

  // Contexte vide : seul le prologue est débloqué.
  var s0 = Codex.story({});
  check('prologue toujours débloqué', s0.filter(function (e) { return e.id === 'prologue'; })[0].unlocked === true);
  check('le reste est verrouillé sans progression', s0.filter(function (e) { return e.id !== 'prologue' && e.unlocked; }).length === 0);
  check('les entrées verrouillées n\'exposent aucun texte', s0.filter(function (e) { return !e.unlocked; }).every(function (e) { return e.body === null; }));

  // Progression des Hérauts.
  var ctxHerald = { stageStars: function (id) { return id === 'boss_vorath' ? 3 : 0; } };
  var s1 = Codex.story(ctxHerald);
  check('VORATH débloque son entrée', s1.filter(function (e) { return e.id === 'herald_vorath'; })[0].unlocked === true);
  check('NEXUS PRIME reste verrouillé', s1.filter(function (e) { return e.id === 'herald_nexus'; })[0].unlocked === false);

  // Révélation : dépend de nebustion.unlocked, pas des stageStars.
  var s2 = Codex.story({ nebustion: { unlocked: true } });
  check('révélation débloquée via nebustion.unlocked', s2.filter(function (e) { return e.id === 'revelation'; })[0].unlocked === true);

  // Sanctuaire / avant-postes / Symtor.
  var ctx3 = { nebustion: { sanctuaryLevel: 1, symtorFeeds: 2, symtorCorrupted: true }, stageStars: function (id) { return id === 'corruption_outpost_2' ? 1 : 0; } };
  var s3 = Codex.story(ctx3);
  ['sanctuary', 'outposts', 'symtor_dilemma', 'symtor_corrupted'].forEach(function (id) {
    check(id + ' débloqué', s3.filter(function (e) { return e.id === id; })[0].unlocked === true);
  });

  // Renaissance.
  var s4 = Codex.story({ prestigeCount: 1 });
  check('cycle de Renaissance débloqué dès 1', s4.filter(function (e) { return e.id === 'renaissance_cycle'; })[0].unlocked === true);
  check('vétéran de plusieurs cycles pas encore débloqué à 1', s4.filter(function (e) { return e.id === 'renaissance_veteran'; })[0].unlocked === false);
  var s5 = Codex.story({ prestigeCount: 3 });
  check('vétéran débloqué à 3 Renaissances', s5.filter(function (e) { return e.id === 'renaissance_veteran'; })[0].unlocked === true);

  // Comptages.
  check('storyTotalCount cohérent avec la liste', Codex.storyTotalCount() === Codex.story({}).length);
  check('storyUnlockedCount(vide) === 1 (prologue)', Codex.storyUnlockedCount({}) === 1);

  // Connexions : toujours débloquées, jamais vides.
  var conns = Codex.connections();
  check('au moins 5 entrées de connexion', conns.length >= 5);
  check('toutes les connexions sont débloquées avec un texte', conns.every(function (e) { return e.unlocked === true && typeof e.body === 'string' && e.body.length > 0; }));

  // chapterName ne plante jamais sur un id inconnu.
  check('chapterName id inconnu -> chaîne vide', Codex.chapterName(999) === '');
})();

console.log((fail === 0 ? '\u2713 OK' : '\u2717 \u00c9CHECS') + ' \u2014 ' + pass + ' r\u00e9ussis, ' + fail + ' \u00e9chou\u00e9s');
