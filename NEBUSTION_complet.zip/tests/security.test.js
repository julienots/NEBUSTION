/* Tests de la Sécurité de zone du QG (NEBUSTION.Security + SecurityManager), Node, sans Phaser.
 * Lancer : node tests/security.test.js */
'use strict';
const E = require('./progress-env');
const t = E.makeCounter(), ok = t.ok, section = t.section;
const S = NEBUSTION.Security, SM = NEBUSTION.SecurityManager;

section('Formules (données pures)');
{
  ok(S.MAX_LEVEL === 20, 'niveau max = 20');
  ok(S.lvl(0) === 1 && S.lvl(-5) === 1 && S.lvl(NaN) === 1, 'niveau invalide/négatif → 1');
  ok(S.lvl(999) === 20, 'niveau borné au maximum');
  const d = S.defaultState();
  ok(d.level === 1, 'état par défaut : niveau 1');
  const n0 = S.normalizeState(null), n1 = S.normalizeState({ level: 7 }), n2 = S.normalizeState({ level: 'oops' });
  ok(n0.level === 1 && n1.level === 7 && n2.level === 1, 'normalizeState : absent/valide/invalide');
  const c1 = S.upgradeCost(1), c5 = S.upgradeCost(5);
  ok(c1.crystal === 250 && c1.metal === 200 && c1.energy === 120, 'coût de base au niveau 1');
  ok(c5.crystal > c1.crystal && c5.metal > c1.metal && c5.energy > c1.energy, 'le coût augmente avec le niveau');
  ok(S.effectText(20).indexOf('maximum') >= 0, 'texte dédié au niveau maximum');
  ok(S.effectText(1).length > 0, 'texte d\'effet non vide en dessous du max');
}

section('Non-régression économie / sauvegarde (sans dépendance directe)');
{
  const g = E.freshGame(), R = g.R;
  ok(R.state.security && R.state.security.level === 1, 'une nouvelle partie initialise security.level = 1');
}

section('SecurityManager — partie simulée');
{
  const g = E.freshGame(), R = g.R;
  ok(SM.level() === 1 && !SM.maxed(), 'départ : niveau 1, pas encore maxé');
  const cost0 = SM.cost();
  ok(!SM.canAfford(), 'fonds insuffisants au tout début');

  const bad = SM.upgrade();
  ok(!bad.ok && bad.reason === 'cost' && SM.level() === 1, 'amélioration refusée sans fonds, niveau inchangé');

  Object.keys(cost0).forEach((id) => { R.state.res[id] = cost0[id] + 1000; });
  ok(SM.canAfford(), 'fonds suffisants après crédit manuel');
  const before = {}; Object.keys(cost0).forEach((id) => { before[id] = R.get(id); });
  const res = SM.upgrade();
  ok(res.ok && res.level === 2 && SM.level() === 2, 'amélioration réussie : niveau 2');
  Object.keys(cost0).forEach((id) => { ok(R.get(id) === before[id] - cost0[id], 'paiement exact pour ' + id); });

  R.state.security.level = 20;
  ok(SM.maxed(), 'niveau 20 = maxé');
  const atMax = SM.upgrade();
  ok(!atMax.ok && atMax.reason === 'max', 'amélioration refusée au niveau maximum');
}

section('Chargement / sauvegarde (SaveManager)');
{
  const raw = { security: { level: 12 } };
  const norm = NEBUSTION.Save.normalize(raw, Date.now());
  ok(norm.security.level === 12, 'normalize() du SaveManager reprend security.level');
  const normEmpty = NEBUSTION.Save.normalize({}, Date.now());
  ok(normEmpty.security.level === 1, 'sauvegarde sans champ security → valeur par défaut (rétrocompatible)');
}

t.done('Sécurité de zone (QG)');
