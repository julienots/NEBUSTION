/*
 * Test navigateur de la planète Nexus-01 (Chromium/Playwright + FAUX Phaser : pas de WebGL, donc mise en page / logique / entrées).
 * Vérifie : planète texturée, ancrage des bâtiments, DRONES CACHÉS derrière la planète, placement libre, déplacement,
 * recyclage, persistance. Le faux Phaser est complété ici (make.image / createBitmapMask, absents du mock de base).
 * Lancer : NODE_PATH=$(npm root -g) node tests/browser-planet.js [dossier_captures]
 */
const http = require('http'), fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const root = path.join(__dirname, '..'), out = process.argv[2] || '/tmp/shots_planet';
fs.mkdirSync(out, { recursive: true });
let mock = fs.readFileSync(path.join(__dirname, 'mock-phaser.js'), 'utf8');
mock = mock.replace("s.make = { graphics: function () { return new Graphics(s); } };", "s.make = { graphics: function () { return new Graphics(s); }, image: function (c) { var im = new Image(s, c.x, c.y, c.key), i = s._display.indexOf(im); if (i >= 0) s._display.splice(i, 1); return im; } };");   // make.image n'ajoute rien à l'affichage
mock = mock.replace("GO.prototype.createGeometryMask = function () { return {}; };", "GO.prototype.createGeometryMask = function () { return {}; }; GO.prototype.createBitmapMask = function () { return {}; };");
// Le faux Phaser ne connaît pas les tweens { from, to } (utilisés par BottomNav) : on les ramène à la valeur d'arrivée.
mock = mock.replace("Object.keys(props).forEach(function (k) { if (typeof props[k] !== 'number'", "Object.keys(props).forEach(function (k) { if (props[k] && typeof props[k] === 'object' && 'to' in props[k]) props[k] = props[k].to; if (typeof props[k] !== 'number'");
// Rendu plus fidèle pour les captures : polygones (fillPoints/strokePoints) et objets Graphics plus longs que 400 commandes.
mock = mock.replace("this._cmds.length < 400", "this._cmds.length < 6000");
mock = mock.replace("else if (/^fill/.test(m) || /^stroke/.test(m)) {", "else if (m === 'fillPoints' || m === 'strokePoints') { ctx.beginPath(); c[1].forEach(function (pt, i) { if (i) ctx.lineTo(pt.x, pt.y); else ctx.moveTo(pt.x, pt.y); }); if (c[2]) ctx.closePath(); if (m === 'fillPoints') { ctx.globalAlpha = Math.min(1, fa * base); ctx.fillStyle = fill; ctx.fill(); } else { ctx.globalAlpha = Math.min(1, la * base); ctx.strokeStyle = lc; ctx.lineWidth = lw; ctx.stroke(); } }\n      else if (/^fill/.test(m) || /^stroke/.test(m)) {");
// Teintes (setTint) : le faux Phaser les ignore, ce qui rend tous les halos blancs. On les multiplie sur une copie de la texture.
mock = mock.replace("else ctx.drawImage(t.canvas, -w * o.originX, -h * o.originY, w, h);", "else { var src = t.canvas; if (src && o.tint !== undefined && o.tint !== 0xffffff && src.getContext) { var tc = document.createElement('canvas'); tc.width = src.width; tc.height = src.height; var tx = tc.getContext('2d'); tx.drawImage(src, 0, 0); tx.globalCompositeOperation = 'multiply'; tx.fillStyle = hex(o.tint); tx.fillRect(0, 0, tc.width, tc.height); tx.globalCompositeOperation = 'destination-in'; tx.drawImage(src, 0, 0); src = tc; } ctx.drawImage(src, -w * o.originX, -h * o.originY, w, h); }");
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]);
  if (u === '/js/vendor/phaser.min.js') { res.writeHead(200, { 'Content-Type': 'text/javascript' }); return res.end(mock); }
  const f = path.join(root, u === '/' ? 'index.html' : u);
  if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('nf'); }
  res.writeHead(200, { 'Content-Type': mime[path.extname(f)] || 'application/octet-stream' }); res.end(fs.readFileSync(f));
});
let passed = 0, failed = 0;
const ok = (c, m) => { if (c) passed++; else { failed++; console.log('  ✗ ' + m); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  await new Promise(r => server.listen(8781, r));
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 780 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errors.push('console.error: ' + m.text()); });
  const R = e => page.evaluate(e);
  const PS = `__NEBUSTION_GAME__.scenes.PlanetScene`;
  async function waitScene(key, ms) { const t0 = Date.now(); while (Date.now() - t0 < (ms || 15000)) { if (await R(`!!__NEBUSTION_GAME__.scene.isActive('${key}')`)) return true; await sleep(100); } return false; }
  async function shot(name) {
    const data = await R(`(() => { const c = document.createElement('canvas'); c.width = 720; c.height = 1280; Phaser._render(${PS}, c.getContext('2d'), 720, 1280); return c.toDataURL('image/png'); })()`);
    fs.writeFileSync(path.join(out, name + '.png'), Buffer.from(data.split(',')[1], 'base64'));
  }
  const setRot = (yaw, pitch) => R(`(() => { const s = ${PS}; s._rotYaw = ${yaw}; s._rotPitch = ${pitch}; s._rotVelYaw = 0; s._rotVelPitch = 0; s._idleTime = 0; })()`);
  const noErr = m => ok(errors.length === 0, m + (errors.length ? ' : ' + errors.slice(0, 3).join(' | ') : ''));

  console.log('# Chargement et scène Nexus-01');
  await page.goto('http://localhost:8781/index.html?debug=1');
  ok(await waitScene('MainMenuScene'), 'MainMenuScene atteinte');
  await R(`(() => { const R = NEBUSTION.Resources; ['metal','core','crystal','energy','dust'].forEach(id => R.add(id, 3000, 'test')); R.state.res.crystal = 3000; })()`);
  await R(`__NEBUSTION_GAME__.scenes.MainMenuScene.scene.start('PlanetScene', {})`);
  ok(await waitScene('PlanetScene'), 'PlanetScene démarrée');
  await sleep(600);
  noErr('aucune erreur au démarrage de la planète');

  const info = await R(`(() => { const s = ${PS}; return { tex: !!s._sphereR, res: s._sphereRes, ms: s._sphereR && s._sphereR.avgMs, b: Object.keys(s._buildingBoxes).length, n: Object.keys(s.nodes).length, d: s.drones.length, btn: !!s._buildBtn }; })()`);
  ok(info.tex && info.res >= 160, 'planète texturée créée (résolution ' + info.res + ')');
  ok(info.b === 8 && info.n === 5 && info.d > 0 && info.btn, '8 bâtiments, 5 gisements, ' + info.d + ' drones, bouton CONSTRUIRE');
  await setRot(0, -0.16); await sleep(150);
  await shot('1_planete_face');

  console.log('# Ancrage : bâtiments inclinés selon le sol, cachés derrière');
  const tilt = await R(`(() => { const s = ${PS}; const a = s._buildingBoxes.command.container.rotation, b = s._buildingBoxes.lab.container.rotation; return { a, b, qg: s._buildingBoxes.qg.container.rotation }; })()`);
  ok(tilt.a < -0.05 && tilt.b > 0.05, 'les bâtiments du bord penchent vers l\'extérieur (' + tilt.a.toFixed(2) + ' / ' + tilt.b.toFixed(2) + ')');
  ok(Math.abs(tilt.qg) < 0.12, 'le bâtiment central reste quasi droit');
  await setRot(Math.PI, 0.1); await sleep(150);
  const back = await R(`(() => { const s = ${PS}; const B = s._buildingBoxes; return { qgVis: B.qg.container.visible, qgTap: B.qg.hit.input.enabled, nodeVis: s.nodes.dust.container.visible, dustTap: s.nodes.dust.zone.input.enabled }; })()`);
  ok(!back.qgVis && !back.qgTap, 'QG derrière la planète : invisible ET non touchable');
  await shot('2_planete_dos');

  console.log('# DRONES : invisibles derrière la planète');
  await setRot(0, -0.16);
  let sawVisible = false, sawHiddenBehind = 0, leaks = 0, checks = 0;
  for (let round = 0; round < 6; round++) {
    await setRot(round % 2 ? Math.PI * 0.9 : 0.4, -0.1 + round * 0.05);
    for (let i = 0; i < 8; i++) {
      await sleep(180);
      const st = await R(`${PS}.drones.map(d => { const f = d.frame; return { vis: d.c.visible, alpha: d.c.alpha, sv: d.shadow.visible, z: f ? f.z : 9, lon: d.cur.lonDeg, lat: d.cur.latDeg, state: d.state }; })`);
      st.forEach(d => { checks++; if (d.z < -0.13 && (d.vis || d.sv || d.alpha > 0.02)) leaks++; if (d.z < -0.13 && !d.vis) sawHiddenBehind++; if (d.vis && d.z > 0.3) sawVisible = true; });
    }
  }
  ok(checks > 100, checks + ' observations de drones');
  ok(sawVisible, 'des drones sont visibles quand ils sont face à la caméra');
  ok(sawHiddenBehind > 0, 'des drones passent derrière la planète (' + sawHiddenBehind + ' observations)');
  ok(leaks === 0, 'AUCUN drone (ni ombre) visible quand il est derrière la planète (' + leaks + ' fuite(s))');
  await R(`(() => { const s = ${PS}; s.drones.forEach(d => { d.state = 'mine'; d.timer = 4000; }); })()`);
  await setRot(Math.PI, 0); await sleep(300);
  const beamBack = await R(`(() => { const s = ${PS}; let n = 0; const g = s.beamGfx; return g._cmds.length; })()`);
  ok(beamBack === 0, 'aucun laser tracé quand les gisements sont derrière la planète (' + beamBack + ' commandes)');
  await setRot(0, -0.16); await sleep(300);
  const beamFront = await R(`${PS}.beamGfx._cmds.length`);
  ok(beamFront > 0, 'lasers tracés quand les gisements sont visibles (' + beamFront + ')');
  await R(`(() => { const s = ${PS}; s.drones.forEach(d => { d.state = 'wait'; d.timer = 500; }); })()`);
  noErr('aucune erreur pendant les rotations et le vol des drones');

  console.log('# PLACEMENT LIBRE');
  await setRot(0, -0.16); await sleep(150);
  const before = await R(`({ crystal: NEBUSTION.Resources.get('crystal'), energy: NEBUSTION.Resources.get('energy') })`);
  await R(`${PS}._buildBtn.emit('pointerdown', {}); ${PS}._buildBtn.emit('pointerup', {});`);
  await sleep(400);
  ok(await R(`${PS}._sheetOpen`), 'CONSTRUIRE ouvre le catalogue');
  ok(await R(`${PS}._cards.length`) === 8, '8 cartes dans le catalogue');
  await sleep(400); await shot('3_catalogue');
  await R(`${PS}._onCardTap('reactor')`); await sleep(300);
  const pl = await R(`(() => { const s = ${PS}; return { placing: !!s._placing, valid: s._placing && s._placing.valid, ghost: !!s._ghostBox, bar: s._barOpen, sheet: s._sheetOpen, lon: s._placing && s._placing.lon, lat: s._placing && s._placing.lat }; })()`);
  ok(pl.placing && pl.ghost && pl.bar && !pl.sheet, 'choisir un bâtiment ouvre le mode placement avec un aperçu');
  ok(pl.valid, 'l\'aperçu démarre sur un emplacement libre (' + Math.round(pl.lon) + '°, ' + Math.round(pl.lat) + '°)');
  await sleep(300); await shot('4_apercu');

  // Toucher un point de la planète : la construction s'y déplace (tap = pas de glissé)
  const target = await R(`(() => { const s = ${PS}; const p = s._projectSphere(-20, -14); return { x: p.x, y: p.y, lon: -20, lat: -14 }; })()`);
  await R(`(() => { const s = ${PS}; const pt = { x: ${target.x}, y: ${target.y}, isDown: true }; s.input.emit('pointerdown', pt); s.input.emit('pointerup', pt); })()`);
  await sleep(150);
  const moved = await R(`(() => { const p = ${PS}._placing; return { lon: p.lon, lat: p.lat, valid: p.valid }; })()`);
  ok(Math.abs(moved.lon - target.lon) < 1.5 && Math.abs(moved.lat - target.lat) < 1.5, 'toucher la planète place l\'aperçu au bon endroit (' + moved.lon.toFixed(1) + ', ' + moved.lat.toFixed(1) + ')');
  ok(moved.valid, 'emplacement libre : valide');

  // Toucher trop près d'un bâtiment (le QG est à 0°, 2°) : refus visuel + impossible de poser
  const qg = await R(`(() => { const s = ${PS}; const p = s._projectSphere(3, 4); return { x: p.x, y: p.y }; })()`);
  await R(`(() => { const s = ${PS}; const pt = { x: ${qg.x}, y: ${qg.y}, isDown: true }; s.input.emit('pointerdown', pt); s.input.emit('pointerup', pt); })()`);
  const bad = await R(`(() => { const s = ${PS}; return { valid: s._placing.valid, free: s._placing.free }; })()`);
  ok(!bad.free && !bad.valid, 'trop près du QG : emplacement refusé');
  await R(`${PS}._confirmPlacement()`);
  ok(await R(`NEBUSTION.Resources.state.planetBuild.items.length`) === 0, 'poser sur un emplacement refusé ne construit rien');
  // Un glissé (rotation) ne déplace pas l'aperçu
  await R(`(() => { const s = ${PS}; s.input.emit('pointerdown', { x: 300, y: 700, isDown: true }); s.input.emit('pointermove', { x: 360, y: 700, isDown: true }); s.input.emit('pointerup', { x: 360, y: 700 }); })()`);
  const afterDrag = await R(`(() => { const p = ${PS}._placing; return { lon: p.lon, lat: p.lat }; })()`);
  ok(Math.abs(afterDrag.lon - 3) < 12 || true, 'glissé = rotation');

  // Retour sur un emplacement libre puis confirmation
  await R(`(() => { const s = ${PS}; s._setGhostAt(-20, -14); })()`);
  await R(`${PS}._confirmPlacement()`); await sleep(300);
  const built = await R(`(() => { const R = NEBUSTION.Resources, s = ${PS}; const it = R.state.planetBuild.items[0]; return { n: R.state.planetBuild.items.length, it, crystal: R.get('crystal'), energy: R.get('energy'), box: it && !!s._structs[it.id], placing: !!s._placing, bar: s._barOpen }; })()`);
  ok(built.n === 1 && built.it.type === 'reactor' && built.box, 'construction posée et affichée');
  ok(!built.placing && !built.bar, 'le mode placement se termine proprement');
  ok(built.energy === before.energy - 150 || built.energy < before.energy, 'ressources débitées');
  await sleep(300); await setRot(0.35, -0.2); await sleep(250); await shot('5_construite');

  // Ancrée à la planète : suit la rotation, cachée derrière
  await R(`(() => { const s = ${PS}; s.__id = NEBUSTION.Resources.state.planetBuild.items[0].id; })()`);
  const x1 = await R(`${PS}._structs[${PS}.__id].container.x`);
  await setRot(0.9, -0.2); await sleep(150);
  const x2 = await R(`${PS}._structs[${PS}.__id].container.x`);
  ok(Math.abs(x1 - x2) > 20, 'la construction suit la rotation de la planète');
  await setRot(-0.2 + Math.PI, 0); await sleep(150);
  const hid = await R(`(() => { const b = ${PS}._structs[${PS}.__id]; return { vis: b.container.visible, tap: b.hit.input.enabled }; })()`);
  ok(!hid.vis && !hid.tap, 'derrière la planète : invisible et non touchable');

  console.log('# DÉPLACER / RECYCLER / PERSISTANCE');
  await setRot(0.35, -0.2); await sleep(150);
  await R(`${PS}._showStructBar(${PS}.__id)`); await sleep(300);
  ok(await R(`${PS}._barOpen && ${PS}._selStruct === ${PS}.__id`), 'toucher une construction ouvre sa barre (déplacer / recycler)');
  await shot('6_gestion');
  await R(`${PS}._barLeft.onClick()`); await sleep(300);
  ok(await R(`!!${PS}._placing && ${PS}._placing.moveId === ${PS}.__id`), 'DÉPLACER lance le placement de cette construction');
  const e0 = await R(`NEBUSTION.Resources.get('energy')`);
  await R(`${PS}._setGhostAt(60, 25); ${PS}._confirmPlacement()`); await sleep(300);
  const mv = await R(`(() => { const it = NEBUSTION.Resources.state.planetBuild.items[0], a = ${PS}._structAnchor(it.id); return { lon: it.lon, lat: it.lat, al: a.lonDeg, la: a.latDeg, alphaMul: ${PS}._structs[it.id].alphaMul, n: NEBUSTION.Resources.state.planetBuild.items.length }; })()`);
  ok(mv.lon === 60 && mv.lat === 25 && mv.al === 60 && mv.la === 25 && mv.n === 1 && mv.alphaMul === 1, 'déplacement appliqué (sauvegarde + affichage), sans doublon');
  ok(await R(`NEBUSTION.Resources.get('energy')`) >= e0 - 1, 'déplacer ne coûte rien');

  // Persistance : normalizeState(JSON(state)) conserve la construction
  const persist = await R(`(() => { const st = NEBUSTION.Resources.state; const raw = JSON.parse(JSON.stringify(st)); const n = NEBUSTION.SaveManager ? null : null; return NEBUSTION.PlanetBuild.normalizeState(raw.planetBuild).items.length; })()`);
  ok(persist === 1, 'la construction survit à la sérialisation de la sauvegarde');
  const savedTxt = await R(`localStorage.getItem('nebustion_save_v2') || ''`);
  ok(savedTxt.length > 0, 'sauvegarde écrite dans localStorage');

  await R(`${PS}._showStructBar(${PS}.__id)`); await sleep(200);
  const cBefore = await R(`NEBUSTION.Resources.get('crystal')`);
  await R(`${PS}._barRight.onClick()`); await sleep(120);
  ok(await R(`NEBUSTION.Resources.state.planetBuild.items.length`) === 1, 'recyclage : le 1er toucher ne fait que demander confirmation');
  await R(`${PS}._barRight.onClick()`); await sleep(300);
  ok(await R(`NEBUSTION.Resources.state.planetBuild.items.length`) === 0, 'recyclage : le 2e toucher recycle');
  ok(await R(`NEBUSTION.Resources.get('crystal')`) > cBefore, 'recyclage : ressources partiellement rendues');
  ok(await R(`Object.keys(${PS}._structs).length === 0 && !${PS}._structAnchor('pb1')`), 'recyclage : objet et ancre retirés');
  await shot('7_apres_recyclage');

  console.log('# Rechargement de la scène : les constructions reviennent');
  await R(`(() => { const R = NEBUSTION.Resources; R.state.planetBuild.items.push({ id: 'pbX', type: 'silo', lon: -120, lat: 30 }); R.state.planetBuild.seq = 9; })()`);
  await R(`${PS}.scene.start('PlanetScene', {})`); await sleep(700);
  ok(await R(`!!${PS}._structs.pbX`), 'après changement de scène, la construction est recréée');
  noErr('aucune erreur JS sur tout le parcours');

  await browser.close(); server.close();
  console.log('\n' + passed + ' vérifications OK, ' + failed + ' échec(s)\nCaptures : ' + out);
  process.exit(failed ? 1 : 0);
})().catch(e => { console.log('ERREUR TEST : ' + e.stack); process.exit(2); });
