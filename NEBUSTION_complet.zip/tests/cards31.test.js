/* NEBUSTION — 8 cartes 24 à 31 : Boutique + collection + combat. */
'use strict';
global.window = global;
const fs = require('fs'), path = require('path');
require('../js/data/Heroes.js');
require('../js/data/Enemies.js');
require('../js/systems/CombatEngine.js');
const H = NEBUSTION.Heroes, CE = NEBUSTION.CombatEngine;
const cards = [
  ['necravion','Divin','celeste'], ['symbioroth','Mythique','mythique'],
  ['aqualith','Légendaire','legendaire'], ['umbrielle','Épique','epique'],
  ['terraxis','Mythique','mythique'], ['stellaris','Légendaire','legendaire'],
  ['virulom','Rare Suprême','rare'], ['zentihar','Divin','celeste']
];
let passed=0,failed=0;
function ok(c,m){if(c)passed++;else{failed++;console.log('  ✗ '+m);}}
for(const [id,label,rarity] of cards){
  const h=H.get(id); ok(!!h,id+' existe'); if(!h) continue;
  ok(h.rarity===rarity,id+' rareté interne'); ok((h.rarityLabel||H.RARITIES[h.rarity].name)===label,id+' rareté affichée');
  ok(!!h.shop&&h.shop.cost&&h.shop.cost.gem>0,id+' achetable');
  ok(h.shop.cost.xon>0,id+' coût Xon');
  ok(!!CE.HERO_KIT[id],id+' kit combat');
  ok(['hp','atk','def','spd'].every(k=>Number.isFinite(h.base[k])&&h.base[k]>0),id+' stats');
  ok(['passive','active','ultimate'].every(k=>h.skills[k]&&h.skills[k].name),id+' compétences');
  const f=path.join(__dirname,'..',H.portraitFile(id));
  ok(fs.existsSync(f),id+' illustration');
  const u=CE.makeHeroUnit(h,1,id); ok(u.hasKit===true&&u.maxHp>0&&u.atk>0,id+' unité jouable');
}
console.log('\n'+(failed?'✘ '+failed+' échec(s)':'✔ CARTES 24–31 OK')+' ('+passed+' vérifications)');
process.exit(failed?1:0);
