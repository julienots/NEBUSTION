/*
 * Test de fumée du MODULE ÉQUIPEMENT dans un vrai Chromium (Playwright) avec le FAUX Phaser
 * (tests/mock-phaser.js) : ouverture de l'écran, 5 emplacements, fabrication, filtre, tri,
 * équiper/déséquiper, amélioration, fusion, démantèlement, icônes de ressources réelles.
 *   NODE_PATH=$(npm root -g) node tests/browser-equipment.js
 */
const http = require('http'), fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const root = path.join(__dirname, '..');
const mock = fs.readFileSync(path.join(__dirname, 'mock-phaser.js'), 'utf8');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]);
  if (u === '/js/vendor/phaser.min.js') { res.writeHead(200, { 'Content-Type': 'text/javascript' }); return res.end(mock); }
  const f = path.join(root, u === '/' ? 'index.html' : u);
  if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('nf'); }
  res.writeHead(200, { 'Content-Type': mime[path.extname(f)] || 'application/octet-stream' }); res.end(fs.readFileSync(f));
});
let passed = 0, failed = 0;
const ok = (c, m) => { if (c) passed++; else { failed++; console.log('  ✗ ' + m); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  await new Promise(r => server.listen(8768, r));
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 780 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console.error: ' + m.text()); });
  const R = expr => page.evaluate(expr);
  const G = '__NEBUSTION_GAME__.scenes.';
  async function waitScene(key, ms) {
    const t0 = Date.now();
    while (Date.now() - t0 < (ms || 15000)) {
      if (await R(`!!(window.__NEBUSTION_GAME__ && window.__NEBUSTION_GAME__.scene.isActive('${key}'))`)) return true;
      await sleep(100);
    }
    return false;
  }
  async function openEquipment(heroId, extra) {
    await R(`(() => { var g = __NEBUSTION_GAME__; var cur = Object.keys(g.active)[0]; g.scenes[cur].scene.start('EquipmentScene', Object.assign({ heroId: '${heroId}' }, ${JSON.stringify(extra || {})})); })()`);
    return waitScene('EquipmentScene');
  }

  console.log('# Chargement');
  await page.goto('http://localhost:8768/index.html?debug=1');
  ok(await waitScene('MainMenuScene'), 'MainMenuScene atteinte');
  ok(errors.length === 0, 'aucune erreur au chargement : ' + errors.join(' | '));
  // Ressources abondantes pour tester fabrication/amélioration/fusion sans blocage.
  await R(`(() => { var R = NEBUSTION.Resources; ['metal','core','crystal','energy','dust'].forEach(id => R.add(id, 100000, 'test')); })()`);

  console.log('# Ouverture, 5 emplacements');
  const heroId = await R(`NEBUSTION.Heroes.all()[0].id`);
  ok(await openEquipment(heroId), 'EquipmentScene démarrée');
  await sleep(150);
  ok(errors.length === 0, 'aucune erreur à l\'ouverture : ' + errors.join(' | '));
  const slotCount = await R(`NEBUSTION.Equipment.SLOT_ORDER.length`);
  ok(slotCount === 5, '5 emplacements définis (' + slotCount + ')');
  const hasReactorArtifact = await R(`!!NEBUSTION.Equipment.SLOTS.reactor && !!NEBUSTION.Equipment.SLOTS.artifact`);
  ok(hasReactorArtifact, 'réacteur et artefact présents dans SLOTS');

  console.log('# Icônes de ressources réelles (pas de symboles texte)');
  const texOk = await R(`(() => { const m = __NEBUSTION_GAME__.textures._map; return !!m['tex_icon_metal'] && !!m['tex_icon_core']; })()`);
  ok(texOk, 'textures tex_icon_metal / tex_icon_core disponibles pour les coûts');

  console.log('# Fabrication de tous les emplacements');
  let craftAll = await R(`(() => {
    var EQ = NEBUSTION.Equipment, EM = NEBUSTION.EquipmentManager, out = [];
    EQ.SLOT_ORDER.forEach(function (slot) { out.push(EM.craft(slot, 'commun').ok); });
    return out;
  })()`);
  ok(craftAll.every(x => x), 'fabrication réussie sur les 5 emplacements : ' + JSON.stringify(craftAll));

  console.log('# Filtre par emplacement');
  await R(`${G}EquipmentScene.scene.restart({ heroId: '${heroId}', filterSlot: 'reactor' })`);
  await waitScene('EquipmentScene');
  await sleep(150);
  ok(errors.length === 0, 'aucune erreur avec un filtre actif : ' + errors.join(' | '));

  console.log('# Tri');
  for (const mode of ['niveau', 'nom', 'rarete']) {
    await R(`${G}EquipmentScene.scene.restart({ heroId: '${heroId}', sortMode: '${mode}' })`);
    await waitScene('EquipmentScene');
    await sleep(120);
  }
  ok(errors.length === 0, 'aucune erreur en changeant de tri : ' + errors.join(' | '));

  console.log('# Équiper / améliorer / démanteler (via EquipmentManager, vérifié en jeu)');
  const flow = await R(`(() => {
    var EM = NEBUSTION.EquipmentManager;
    var w = EM.craft('weapon', 'rare').item;
    EM.equip('${heroId}', w.uid);
    var equippedOk = EM.equippedItem('${heroId}', 'weapon').uid === w.uid;
    var up = EM.upgrade(w.uid);
    var bonusBefore = NEBUSTION.Equipment.bonusFor(w.slot, w.rarity, 1).atk;
    var bonusAfter = NEBUSTION.Equipment.bonusFor(w.slot, w.rarity, up.item.level).atk;
    return { equippedOk: equippedOk, leveledUp: up.ok && up.item.level === 2, bonusGrew: bonusAfter > bonusBefore };
  })()`);
  ok(flow.equippedOk, 'équiper une arme fonctionne');
  ok(flow.leveledUp, 'améliorer augmente le niveau');
  ok(flow.bonusGrew, 'le bonus de stat augmente réellement avec le niveau');

  console.log('# Fusion');
  const fusion = await R(`(() => {
    var EM = NEBUSTION.EquipmentManager;
    // Emplacement neuf (pas encore fabriqué dans ce test) pour éviter tout doublon préexistant.
    var a = EM.craft('armor', 'rare').item;
    var b = EM.craft('armor', 'rare').item;
    var match = EM.findFusionMatch(a.uid) === b.uid;
    var res = EM.fuse(a.uid, b.uid);
    return { match: match, fused: res.ok, rarity: res.item && res.item.rarity };
  })()`);
  ok(fusion.match, 'un doublon identique est proposé pour la fusion');
  ok(fusion.fused && fusion.rarity === 'epique', 'la fusion produit un objet de rareté supérieure');

  console.log('# Démantèlement');
  const dismantle = await R(`(() => {
    var EM = NEBUSTION.EquipmentManager;
    var it = EM.craft('artifact', 'commun').item;
    var before = Object.keys(NEBUSTION.Resources.state.res).length;
    var res = EM.dismantle(it.uid);
    return { ok: res.ok, refundHasMetal: res.refund.metal > 0, gone: !EM.get(it.uid) };
  })()`);
  ok(dismantle.ok && dismantle.refundHasMetal && dismantle.gone, 'démantèlement rend des ressources et retire l\'objet');

  console.log('# Sauvegarde / rechargement (persistance des 5 emplacements)');
  await R(`NEBUSTION.Resources.saveNow(Date.now())`);
  await page.reload();
  ok(await waitScene('MainMenuScene'), 'rechargement OK');
  const persisted = await R(`Object.keys(NEBUSTION.Resources.state.equipment.items).length`);
  ok(persisted > 0, 'les objets d\'équipement sont bien rechargés depuis la sauvegarde (' + persisted + ')');

  await browser.close();
  server.close();
  console.log('\n' + (failed === 0 ? '✔ TEST DE FUMÉE ÉQUIPEMENT OK' : '✗ ÉCHECS') + ' (' + passed + ' vérifications' + (failed ? ', ' + failed + ' échecs' : '') + ')');
  process.exit(failed === 0 ? 0 : 1);
})();
