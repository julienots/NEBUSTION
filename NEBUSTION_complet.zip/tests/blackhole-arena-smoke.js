/* NEBUSTION - test de fumée Node de l'arène du Trou Noir (faux Phaser, pas de navigateur).
 * Fait jouer des « bots » dans les 3 épreuves et vérifie : fin de partie, performance valide, pas de NaN/fuite,
 * puis l'application atomique du résultat par BlackHoleManager (fragments, intégrité, profondeur, retour forcé). */
global.window = global; global.NEBUSTION = {};
var fails = 0, n = 0;
function ok(c, m) { n++; if (!c) { fails++; console.error('ECHEC: ' + m); } }

// ---------- Faux Phaser minimal ----------
function stub() {
  var st = { active: true, scaleX: 1, scaleY: 1, alpha: 1, rotation: 0, x: 0, y: 0, text: '', tilePositionY: 0 };
  var p = new Proxy(function () {}, {
    get: function (t, k) {
      if (typeof k === 'symbol' || k === 'then') return undefined;
      if (k in st) return st[k];
      if (k === 'setPosition') return function (x, y) { st.x = x; st.y = y; return p; };
      if (k === 'setText') return function (v) { st.text = v; return p; };
      if (k === 'setAlpha') return function (v) { st.alpha = v; return p; };
      if (k === 'setY') return function (v) { st.y = v; return p; };
      if (k === 'destroy') return function () { st.active = false; };
      return function () { return p; };
    },
    set: function (t, k, v) { st[k] = v; return true; }
  });
  return p;
}
var timers = [], simNow = 0;
global.Phaser = {
  BlendModes: { ADD: 1 },
  Scene: class { constructor(key) { this.key = key; } }
};
function installSceneEnv(sc) {
  var handlers = {}, calls = { resumed: null, stopped: false };
  sc.scale = { width: 720, height: 1280 };
  sc.cameras = { main: stub() };
  sc.textures = { exists: function () { return true; } };
  sc.add = new Proxy({}, { get: function () { return function () { return stub(); }; } });
  sc.make = { graphics: function () { return stub(); } };
  sc.tweens = { add: function (cfg) { if (cfg && cfg.onComplete && cfg.duration < 400 && !cfg.repeat) timers.push({ at: simNow + cfg.duration, cb: cfg.onComplete }); return stub(); } };
  sc.time = { delayedCall: function (ms, cb) { timers.push({ at: simNow + ms, cb: cb }); } };
  sc.input = { on: function (ev, cb) { handlers[ev] = cb; } };
  sc.scene = { resume: function (k) { calls.resumed = k; }, stop: function () { calls.stopped = true; } };
  sc._handlers = handlers; sc._calls = calls;
}
function runTimers() { for (var i = timers.length - 1; i >= 0; i--) { if (timers[i].at <= simNow) { var t = timers.splice(i, 1)[0]; t.cb(); } } }

// ---------- Environnement NEBUSTION minimal ----------
NEBUSTION.FX = function () { return new Proxy({}, { get: function () { return function () {}; } }); };
NEBUSTION.BlackHoleTextures = { ensureCloseup: function () { return 'tex_bh_closeup'; } };
NEBUSTION.Economy = { RES: { crystal: { color: 0x00e5ff, hex: '#00e5ff', short: 'Cristaux' }, metal: { color: 0xaaaaaa, hex: '#aaaaaa', short: 'Métal' }, energy: { color: 0xffff00, hex: '#ffff00', short: 'Énergie' }, dust: { color: 0x996633, hex: '#996633', short: 'Poussière' }, core: { color: 0xff00ff, hex: '#ff00ff', short: 'Noyaux' } } };
NEBUSTION.Enemies = { get: function (id) { return { name: 'Ennemi ' + id }; } };
require('../js/data/BlackHole.js');
require('../js/scenes/BlackHoleRunScene.js');
var BH = NEBUSTION.BlackHole;

// ---------- Un « bot » joue une épreuve complète ----------
function play(kind, depth, botName, teamPower) {
  var params = BH.arenaParams(kind, depth, teamPower, 777, 0);
  var plan = { ok: true, idx: 0, kind: kind, title: BH.KIND_META[kind].name, mode: params.mode, params: params, depth: depth, integrity: 100, maxIntegrity: 100, zone: BH.zoneForDepth(depth) };
  var got = null, sc = new NEBUSTION.BlackHoleRunScene();
  timers = []; simNow = 0;
  installSceneEnv(sc);
  sc.init({ plan: plan, parent: 'BlackHoleScene', onDone: function (perf) { got = perf; } });
  sc.create();
  var maxEnts = 0, bad = false;
  for (var f = 0; f < 60 * 45 && !got; f++) {
    simNow += 16;
    var S = sc.S, ptr = null;
    if (botName === 'chasseur' && !S.over) {
      // collecte : vise l'orbe le plus proche au-dessus de la sonde ; combat : se place sous l'ennemi
      if (params.mode === 'fight' && S.enemy) ptr = { x: S.enemy.x, y: sc.H - 240 + 110, isDown: true };
      else { var best = null, bd = 1e9; S.ents.forEach(function (e) { if (e.type === 'orb') { var d = Math.abs(e.y - S.probe.y) + Math.abs(e.x - S.probe.x); if (d < bd) { bd = d; best = e; } } }); ptr = { x: best ? best.x : 360, y: best ? Math.min(best.y, sc.H - 130) + 110 : sc.H - 130, isDown: true }; }
    } else if (botName === 'esquive') { ptr = { x: 360 + Math.sin(f / 40) * 250, y: sc.H - 130 + 110, isDown: true }; }
    if (ptr) sc._handlers.pointermove(ptr);
    sc.update(simNow, 16);
    runTimers();
    maxEnts = Math.max(maxEnts, S.ents.length + S.bullets.length + S.eshots.length);
    if (!isFinite(S.probe.x) || !isFinite(S.probe.y)) bad = true;
  }
  return { perf: got, sc: sc, maxEnts: maxEnts, bad: bad, params: params };
}

var r;
r = play('cache', 4, 'chasseur', 500);
ok(r.perf && !r.bad, 'collecte : l\u2019épreuve se termine, pas de NaN');
ok(r.perf.score > 0.5, 'collecte : le bot chasseur récolte >50 % (obtenu ' + (r.perf && r.perf.score.toFixed(2)) + ')');
ok(r.maxEnts < 60, 'collecte : pas de fuite d\u2019entités (max ' + r.maxEnts + ')');
ok(r.sc._calls.resumed === 'BlackHoleScene' && r.sc._calls.stopped, 'la scène parente est reprise et l\u2019arène s\u2019arrête');
r = play('cache', 4, 'immobile', 500);
ok(r.perf && r.perf.score < 0.5, 'collecte : rester immobile récolte peu (' + (r.perf && r.perf.score.toFixed(2)) + ')');
r = play('relique', 12, 'chasseur', 500);
ok(r.perf && /Fragments/.test(r.perf.summary), 'relique : résumé « Fragments »');
r = play('anomalie_negative', 6, 'esquive', 500);
ok(r.perf && r.perf.damage >= 0 && !r.bad, 'marée : se termine (dégâts ' + (r.perf && r.perf.damage) + ')');
r = play('echo', 5, 'chasseur', 1e6);
ok(r.perf && r.perf.win === true && r.perf.score === 1, 'écho : équipe très forte + bot aligné = victoire');
r = play('echo', 5, 'immobile', 10);
ok(r.perf && r.perf.win === false, 'écho : équipe faible + immobile = échec');
r = play('abime', 10, 'chasseur', 1e7);
ok(r.perf && typeof r.perf.summary === 'string' && r.maxEnts < 120, 'Seuil : se termine (boss), entités bornées (max ' + r.maxEnts + ')');
r = play('echo', 25, 'immobile', 10);
ok(r.perf && r.perf.damage > 0 && r.perf.damage <= 100, 'dégâts subis bornés par l\u2019intégrité de départ');

// ---------- Manager : application atomique du résultat ----------
var res = { state: { blackhole: null }, added: {}, add: function (id, a) { this.added[id] = (this.added[id] || 0) + a; return a; }, saveNow: function () {}, rates: function () { return { crystal: 3, metal: 2.5, energy: 2, dust: 3, core: 0.3 }; } };
NEBUSTION.Resources = res; NEBUSTION.ShopManager = { addGems: function () {} };
NEBUSTION.ExpeditionManager = { teamPowerOf: function () { return 400; } }; NEBUSTION.Combat = { getTeam: function () { return []; } };
require('../js/systems/BlackHoleManager.js');
var BM = NEBUSTION.BlackHoleManager;
/** Nouvelle plongée dont l'option 0 de la profondeur 1 produit le type `kind` (seed choisie, donc test déterministe). */
function freshDive(kind) {
  res.state.blackhole = BM.defaultState(); BM.startOrResumeDive();
  for (var sd = 1; sd < 5000; sd++) { if (BH.previewKind(sd, 1, BH.choiceOptions(sd, 1)[0], res.state.blackhole.talents) === kind) { res.state.blackhole.dive.seed = sd; return sd; } }
  throw new Error('seed introuvable pour ' + kind);
}
freshDive('cache');
var plan = BM.planNode(0);
ok(plan.ok && plan.kind === 'cache' && plan.mode === 'collect' && plan.params.total === 14, 'planNode : type + épreuve révélés');
ok(!BM.planNode(9).ok && !BM.planNode(-1).ok, 'planNode : option invalide refusée');
var out = BM.chooseNode(0, undefined, { score: 1, win: true, damage: 9, resId: plan.params.resId });
ok(out.ok && out.depth === 1 && out.outcome.played === true, 'chooseNode(perf) avance la profondeur et marque « jouée »');
ok(out.integrity === 100 - 9, 'intégrité = 100 - dégâts subis dans l\u2019arène (' + out.integrity + ')');
ok((res.added[plan.params.resId] || 0) > 0, 'la ressource affichée dans l\u2019arène est bien celle créditée');
// sonde détruite : retour forcé
freshDive('cache');
var out2 = BM.chooseNode(0, undefined, { score: 0.3, win: false, damage: 9999, resId: 'metal' });
ok(out2.ok && out2.forcedEnd === true && !BM.hasActiveDive() && out2.integrity === 0, 'sonde détruite = retour forcé, plongée terminée');
// Repos : jamais jouable
freshDive('sanctuaire');
var pr = BM.planNode(0);
ok(pr.ok && pr.mode === null && pr.params === null, 'point d\u2019ancrage : pas d\u2019épreuve (repos instantané)');
// ancien chemin (sans perf) inchangé
freshDive('cache');
var legacy = BM.chooseNode(0);
ok(legacy.ok && legacy.outcome.played === false, 'sans perf : résolution automatique comme avant');
console.log(n + ' vérifications, ' + fails + ' échec(s)');
process.exit(fails ? 1 : 0);
