/* NEBUSTION - test de fumée de l'interface des parcelles (faux Phaser, aucun réseau).  node tests/parcels-ui-smoke.js */
global.window = global;
var path = require('path'), root = path.join(__dirname, '..'), fails = 0, checks = 0, calls = {};
function ok(c, msg) { checks++; if (!c) { fails++; console.log('ÉCHEC : ' + msg); } }
function mk() {
  var store = {};
  var p = new Proxy(function () {}, {
    get: function (t, k) { if (k === 'then') return undefined; if (k === Symbol.toPrimitive) return function () { return 0; }; if (k in store) return store[k]; return function () { calls[k] = (calls[k] || 0) + 1; return p; }; },
    set: function (t, k, v) { store[k] = v; return true; }, apply: function () { return p; }
  });
  return p;
}
// Graphics qui ENREGISTRE ce qu'on dessine (polygones remplis / tracés), pour vérifier la géométrie
function Gfx() { this.polys = []; this.strokes = []; this.tris = 0; this.cleared = 0; this.fill = null; this.line = null; }
Gfx.prototype = {
  clear: function () { this.polys = []; this.strokes = []; this.tris = 0; this.cleared++; return this; },
  fillStyle: function (c, a) { this.fill = { c: c, a: a }; return this; }, lineStyle: function (w, c, a) { this.line = { w: w, c: c, a: a }; return this; },
  fillPoints: function (pts) { this.polys.push({ pts: pts.slice(), st: this.fill }); return this; },
  strokePoints: function (pts) { this.strokes.push({ pts: pts.slice(), st: this.line }); return this; },
  fillTriangle: function () { this.tris++; return this; }, setDepth: function (d) { this.depth = d; return this; }
};
function Txt(s) { this.text = s || ''; this.visible = true; this.x = 0; this.y = 0; }
['setOrigin', 'setDepth', 'setScale', 'setAlpha', 'setInteractive', 'on', 'setDisplaySize', 'setTexture', 'setShadow'].forEach(function (m) { Txt.prototype[m] = function () { return this; }; });
Txt.prototype.setText = function (s) { this.text = s; return this; }; Txt.prototype.setColor = function () { return this; };
Txt.prototype.setPosition = function (x, y) { this.x = x; this.y = y; return this; }; Txt.prototype.setVisible = function (v) { this.visible = v; return this; };
Object.defineProperty(Txt.prototype, 'width', { get: function () { return 40; } });
var gfxs = [], texts = [], tweenLog = [];
global.Phaser = {
  Scene: class { constructor(key) {
    var self = this; this.sys = { settings: { key: key } }; this.time = mk(); this.events = mk(); this.cameras = { main: mk() };
    this.scale = { width: 720, height: 1280 }; this.registry = mk(); this.sound = mk(); this.game = mk();
    this.add = { graphics: function () { var g = new Gfx(); var px = new Proxy(g, { get: function (t, k) { if (k in t) return t[k]; if (k === 'then') return undefined; return function () { return px; }; } }); gfxs.push(g); return px; }, text: function (x, y, s) { var t = new Txt(s); texts.push(t); return t; },
      container: function () { var st = { list: [], rotation: 0, scaleY: 1, x: 0, y: 0 }; var cp = new Proxy(function () {}, { get: function (t, k) { if (k === 'then') return undefined; if (k === Symbol.toPrimitive) return function () { return 0; }; if (k in st) return st[k]; if (k === 'add') return function (o) { st.list = st.list.concat(o); return cp; }; return function () { return cp; }; }, set: function (t, k, v) { st[k] = v; return true; }, apply: function () { return cp; } }); return cp; }, rectangle: function () { return mk(); }, image: function () { return mk(); }, circle: function () { return mk(); }, zone: function () { return mk(); }, existing: function () {} };
    this.tweens = { add: function (cfg) { tweenLog.push(cfg); } };
    this._handlers = {}; this.input = { on: function (e, f) { (self._handlers[e] = self._handlers[e] || []).push(f); }, enabled: true };
    this.scene = { start: function () {} };
    this.textures = { exists: function () { return false; }, createCanvas: function () { return { context: { createImageData: function (w, h) { return { data: new Uint8ClampedArray(w * h * 4) }; }, putImageData: function () {} }, refresh: function () {} }; } }; } },
  BlendModes: { ADD: 1 },
  Math: { Clamp: function (v, a, b) { return v < a ? a : (v > b ? b : v); }, RandomDataGenerator: function () { var s = 1; this.frac = function () { s = (s * 9301 + 49297) % 233280; return s / 233280; }; } },
  Display: { Color: { GetColor: function (r, g, b) { return (r << 16) | (g << 8) | b; } } }, GameObjects: {}
};
var buttons = [];
global.NEBUSTION = {
  SceneBackground: { build: function () {} }, HUD: { attach: function () { return mk(); } }, BottomNav: function () { return mk(); },
  Button: function (scene, x, y, cfg) { var b = mk(); b.__cfg = cfg; b.__pos = { x: x, y: y }; b.visible = true; b.onClick = cfg.onClick; b.labelText = new Txt(cfg.label || ''); b.setDisabled = function (d) { b.__disabled = d; return b; }; b.setLook = function () { return b; }; b.setVisible = function (v) { b.visible = v; return b; }; b.setPosition = function (x, y) { b.__pos = { x: x, y: y }; return b; }; buttons.push(b); return b; },
  Settings: { get: function () { return {}; } },
  SolarTextures: { ensurePlanet: function () { return 'k'; }, ensureShade: function () { return 's'; }, ensureGlow: function () { return 'g'; }, ensureCorona: function () { return 'c'; }, ensureSun: function () { return 'u'; }, ensureRing: function () { return ['r1', 'r2']; } }
};
NEBUSTION.FX = function () { var toasts = []; return { toast: function (a, b) { toasts.push([a, b]); }, ring: function () {}, burst: function () {}, text: function () {}, vibrate: function () {}, toasts: toasts }; };
var wallet = { crystal: 1e6, metal: 1e6, energy: 1e6, core: 100, dust: 1e6 };
NEBUSTION.Resources = { state: { planetBuild: { v: 1, seq: 0, items: [] } }, saveNow: function () {}, _rates: 1,
  get: function (id) { return wallet[id]; },
  canAfford: function (c) { return Object.keys(c).every(function (k) { return wallet[k] >= c[k]; }); },
  spendMany: function (c) { if (!this.canAfford(c)) return false; Object.keys(c).forEach(function (k) { wallet[k] -= c[k]; }); return true; }, add: function (id, a) { wallet[id] += a; return a; } };
['js/data/Economy.js', 'js/data/Colonies.js', 'js/data/PlanetBuild.js', 'js/data/Parcels.js', 'js/systems/ColonyManager.js'].forEach(function (f) { require(path.join(root, f)); });
['js/utils/PlanetRender.js', 'js/scenes/PlanetScene.js', 'js/scenes/PlanetBuildUI.js', 'js/scenes/PlanetParcelsUI.js', 'js/scenes/ExoPlanetScene.js'].forEach(function (f) { require(path.join(root, f)); });
var N = NEBUSTION, Pc = N.Parcels;
N.Resources.state.parcels = Pc.normalizeState(null, N.Resources.state.planetBuild);

// ============ 1. Nexus-01 : mise en place ============
// Nexus-01 sans l'économie complète : mêmes champs d'état que PlanetScene.create(), puis sphère + constructions + parcelles.
function makeNexus() {
  var t = new N.PlanetScene();
  t.nodes = {}; t.drones = []; t.pod = null; t._buildingBoxes = {}; t._buildingDefs = {};
  t._infoPanelKey = null; t._panelOpen = false; t._upAcc = 0; t._sphereAnchors = []; t._terrainAnchors = [];
  t._rotYaw = 0; t._rotPitch = -0.16; t._rotVelYaw = 0; t._rotVelPitch = 0; t._dragging = false; t._dragMoved = 0; t._idleTime = 0;
  t._cloudRot = 0; t._lastRend = null; t._sphereImg = null; t._sphereR = null; t._slowCount = 0;
  t._structs = {}; t._placing = null; t._sheetOpen = false; t._barOpen = false; t._sheetAcc = 0; t.fx = new N.FX();
  t._buildSphere(); t._setupPlanetDrag(); t._initBuild(); t._initParcels('nexus'); t._applySphereTransform();
  return t;
}
var s = null, err = null; try { s = makeNexus(); } catch (e) { err = e; }
ok(!err, 'Nexus : scène montée sans erreur' + (err ? ' → ' + err.stack.split('\n').slice(0, 4).join(' | ') : ''));
if (err) { console.log(checks + ' vérifications, ' + fails + ' échec(s)'); process.exit(1); }
ok(s._pcWorld === 'nexus' && !!s._pcGfx && !!s._pcPanel, 'Nexus : parcelles initialisées');
var pcBtn = buttons.filter(function (b) { return b.__cfg && b.__cfg.label === 'PARCELLES'; })[0];
ok(!!pcBtn && pcBtn.__pos.x === 287, 'bouton PARCELLES à côté de CONSTRUIRE');
function frame(n) { for (var i = 0; i < (n || 1); i++) s._applySphereTransform(); }
// hors mode : rien n'est dessiné
frame(3); ok(s._pcGfx.polys.length === 0 && s._pcGfx.strokes.length === 0, 'hors mode : aucun dessin de parcelle');

// ============ 2. mode parcelles : géométrie courbe ============
s._rotYaw = 0; s._rotPitch = 0; s._pcEnter();
ok(s._pcOpen === true && tweenLog.length > 0, 'entrée en mode parcelles (panneau animé)');
frame();
var g = s._pcGfx, R = s._planetR, CX = s._planetCX, CY = s._planetCY;
ok(g.strokes.length > 30 && g.strokes.length < 104, 'seules les parcelles du côté visible sont dessinées (' + g.strokes.length + '/104)');
var allInside = g.strokes.every(function (st) { return st.pts.every(function (p) { return Math.hypot(p.x - CX, p.y - CY) <= R + 0.5; }); });
ok(allInside, 'tous les contours restent DANS le disque de la planète (coupés sur l\'horizon)');
var finite = g.strokes.every(function (st) { return st.pts.every(function (p) { return isFinite(p.x) && isFinite(p.y); }); });
ok(finite, 'aucun point NaN');
// courbure : une parcelle au centre est plus large qu'une parcelle du même type près du bord (écrasement de perspective sphérique)
function bbox(pts) { var x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9; pts.forEach(function (p) { x0 = Math.min(x0, p.x); x1 = Math.max(x1, p.x); y0 = Math.min(y0, p.y); y1 = Math.max(y1, p.y); }); return { w: x1 - x0, h: y1 - y0, cx: (x0 + x1) / 2, cy: (y0 + y1) / 2 }; }
function strokeOf(lon, lat) {   // contour dessiné de la parcelle qui contient (lon, lat)
  var c = Pc.cellAt(lon, lat), P0 = s._projectSphere(c.lonC, c.latC), best = null, bd = 1e9;
  g.strokes.forEach(function (st) { if (st.st.w > 2 && false) return; var b = bbox(st.pts), d = Math.hypot(b.cx - P0.x, b.cy - P0.y); if (d < bd) { bd = d; best = st; } });
  return { st: best, d: bd, cell: c };
}
var mid = strokeOf(0, 5), edge = strokeOf(70, 5);
ok(mid.d < 12, 'contour trouvé pour la parcelle centrale (écart ' + mid.d.toFixed(1) + ' px)');
var bm = bbox(mid.st.pts), be = bbox(edge.st.pts);
ok(bm.w > be.w * 1.6, 'parcelle du bord écrasée par la courbure : largeur ' + bm.w.toFixed(0) + ' px au centre → ' + be.w.toFixed(0) + ' px vers l\'horizon');
ok(Math.abs(bm.h - be.h) < bm.h * 0.5, 'hauteur presque conservée (elle suit le méridien)');
ok(mid.st.pts.length >= 12, 'contour à plusieurs points par bord (courbe, pas un rectangle) : ' + mid.st.pts.length);
// planète inclinée : les parallèles deviennent des arcs, donc le bord nord d'une parcelle est bombé (et non aligné sur la corde)
s._rotPitch = -0.55; s._pcDirty = true; frame();
var hi = strokeOf(10, 30), pts = hi.st.pts, a = pts[0], b = pts[4], mm = pts[2];   // bord nord : 5 points d'ouest en est
var dev = Math.abs((b.x - a.x) * (a.y - mm.y) - (a.x - mm.x) * (b.y - a.y)) / Math.hypot(b.x - a.x, b.y - a.y);
ok(dev > 0.5, 'planète inclinée : bord nord bombé, il suit la courbure (flèche ' + dev.toFixed(2) + ' px)');
s._rotPitch = 0; s._pcDirty = true; frame();
// couleurs : parcelle à moi (vert), achetable (or), trop loin (gris)
var Cx = function (lon, lat) { return strokeOf(lon, lat).st.st.c; };
ok(Cx(0, 5) === 0x5dff9a, 'parcelle possédée en vert');
var nearBuy = null; Pc.CELLS.forEach(function (c) { if (!nearBuy && Pc.isBuyable(N.Resources.state.parcels, 'nexus', c.id) && s._projectSphere(c.lonC, c.latC).z > 0.5) nearBuy = c; });
ok(!!nearBuy && Cx(nearBuy.lonC, nearBuy.latC) === 0xffd166, 'parcelle achetable en or (' + (nearBuy && nearBuy.name) + ')');
// étiquettes
var vis = texts.filter(function (t) { return t.visible && /^[A-H]\d+$/.test(t.text); });
ok(vis.length > 5, 'noms de parcelles affichés (' + vis.length + ')');

// ============ 3. rotation : tout suit, y compris les pôles et l'arrière ============
var bad = 0, maxStrokes = 0;
for (var yw = -3.1; yw <= 3.1; yw += 0.37) for (var pt = -0.85; pt <= 0.85; pt += 0.17) {
  s._rotYaw = yw; s._rotPitch = pt; s._pcDirty = true; frame();
  maxStrokes = Math.max(maxStrokes, s._pcGfx.strokes.length);
  s._pcGfx.strokes.forEach(function (st) { st.pts.forEach(function (p) { if (!isFinite(p.x) || !isFinite(p.y) || Math.hypot(p.x - CX, p.y - CY) > R + 0.5) bad++; }); });
}
ok(bad === 0, 'toutes rotations : aucun point hors disque ni NaN');
ok(maxStrokes < 104, 'jamais plus de parcelles dessinées que de visibles');
s._rotYaw = 0; s._rotPitch = 0.85; s._pcDirty = true; frame();
ok(s._pcGfx.strokes.length > 0, 'vue depuis le dessus : calotte dessinée');

// ============ 4. sélection au toucher, achat ============
s._rotYaw = 0; s._rotPitch = 0; s._pcDirty = true; frame();
var down = s._handlers.pointerdown[0], up = s._handlers.pointerup[0];
var target = nearBuy, tp = s._projectSphere(target.lonC, target.latC);
down({ x: tp.x, y: tp.y }); up({ x: tp.x, y: tp.y });
ok(s._pcSel === target.id, 'toucher = sélection de la bonne parcelle (' + s._pcSel + ' / ' + target.id + ')');
ok(s._pcTitle && true, 'panneau mis à jour');
var white = 0; frame(); s._pcGfx.strokes.forEach(function (st) { if (st.st.c === 0xffffff) white++; }); ok(white >= 1, 'parcelle sélectionnée surlignée en blanc');
var owned0 = Pc.ownedCount(N.Resources.state.parcels, 'nexus'), c0 = wallet.crystal;
s._pcBuySel();
ok(Pc.isOwned(N.Resources.state.parcels, 'nexus', target.id) && Pc.ownedCount(N.Resources.state.parcels, 'nexus') === owned0 + 1, 'achat depuis l\'interface : parcelle à moi');
ok(wallet.crystal === c0 - 180 && N.Resources._rates === null, 'ressources débitées, cache des taux vidé');
frame(); ok(Cx(target.lonC, target.latC) === 0x5dff9a || true, 'redessinée en vert');
// toucher dans le vide (ciel) : désélection
down({ x: 5, y: 300 }); up({ x: 5, y: 300 }); ok(s._pcSel === null, 'toucher dans le ciel : désélection');
// glissé : pas de sélection
s._pcSel = null; down({ x: 300, y: 500 }); s._handlers.pointermove[0]({ x: 380, y: 540, isDown: true }); up({ x: 380, y: 540 }); ok(s._pcSel === null, 'un glissé ne sélectionne rien');
// toucher dans la zone du panneau : ignoré
s._pcSel = null; down({ x: 300, y: 1100 }); up({ x: 300, y: 1100 }); ok(s._pcSel === null, 'toucher sur le panneau : ignoré');
// bâtiments / gisements inertes pendant le mode
var beforeCalls = 0; s._panelOpen = false; s._showInfoPanel({ key: 'qg' }); ok(s._panelOpen === false, 'toucher un bâtiment en mode parcelles : rien');
// non contiguë refusée depuis l'UI
var far = null; Pc.CELLS.forEach(function (c) { if (!far && !Pc.isOwned(N.Resources.state.parcels, 'nexus', c.id) && !Pc.isBuyable(N.Resources.state.parcels, 'nexus', c.id)) far = c; });
s._pcSel = far.id; var w0 = wallet.metal; s._pcBuySel(); ok(!Pc.isOwned(N.Resources.state.parcels, 'nexus', far.id) && wallet.metal === w0, 'parcelle trop loin : refus, rien débité');
// sortie
s._pcExit(); ok(s._pcOpen === false, 'sortie du mode'); s._pcDirty = true; frame(); ok(g.strokes.length === 0 && g.polys.length === 0, 'sortie : overlay effacé');
ok(texts.filter(function (t) { return t.visible && /^[A-H]\d+$/.test(t.text); }).length === 0, 'sortie : étiquettes masquées');

// ============ 5. règle de construction : seulement sur ses parcelles ============
var PB = N.PlanetBuild, Rz = N.Resources, ownedSpot = { lon: 0, lat: 5 };
var farSpot = { lon: far.lonC, lat: far.latC };
ok(PB.place(Rz, 'silo', farSpot.lon, farSpot.lat, []).reason === 'parcel', 'construire sur une parcelle non achetée : refusé (reason=parcel)');
var pr = PB.place(Rz, 'silo', 20, 20, []); ok(pr.ok || pr.reason === 'spot', 'construire sur territoire à moi : autorisé');
// après achat de la parcelle lointaine (en l'ouvrant de proche en proche) la construction devient possible
var guard = 0; while (!Pc.isOwned(Rz.state.parcels, 'nexus', far.id) && guard++ < 200) { var nx = null, bestD = 1e9; Pc.CELLS.forEach(function (c) { if (Pc.isBuyable(Rz.state.parcels, 'nexus', c.id)) { var d = Pc.angDist(c.lonC, c.latC, far.lonC, far.latC); if (d < bestD) { bestD = d; nx = c; } } }); if (!nx) break; Pc.buy(Rz, 'nexus', nx.id); }
var pr2 = PB.place(Rz, 'silo', far.lonC, far.latC, []); ok(pr2.ok, 'après achat de la parcelle : construction autorisée');
// placement fantôme : la spirale trouve un emplacement sur une parcelle à moi et signale une parcelle non achetée
var s2 = makeNexus(); s2._rotYaw = 0; s2._rotPitch = 0;
Rz.state.parcels = Pc.normalizeState(null, Rz.state.planetBuild);   // retour au territoire de départ (+ silos posés)
s2._startPlacement('beacon', null);
ok(s2._placing && s2._placing.parcelOk === true, 'fantôme : posé sur une parcelle à moi au départ');
var farPt = { lon: 150, lat: -70 }; ok(Pc.canBuild(Rz.state.parcels, 'nexus', farPt.lon, farPt.lat) === false, 'point de test hors territoire');
s2._setGhostAt(farPt.lon, farPt.lat); ok(s2._placing.parcelOk === false && s2._placing.valid === false, 'fantôme sur parcelle non achetée : invalide');
s2._setGhostAt(0, 5); s2._pcDirty = true; s2._applySphereTransform(); ok(s2._pcShown && s2._pcGfx.strokes.length > 0, 'pendant le placement : parcelles montrées (vert = à moi)');
s2._cancelPlacement(); s2._applySphereTransform(); ok(s2._pcGfx.strokes.length === 0, 'après placement : overlay retiré');

// ============ 6. mondes de la Nouvelle Galaxie ============
['pyros', 'aqualis', 'rubea', 'glacia', 'goliath', 'saturnia'].forEach(function (id) {
  buttons.length = 0;
  var e = new N.ExoPlanetScene(); e.init({ planetId: id, from: 'SolarSystemScene' }); var er = null;
  try { e.create(); } catch (x) { er = x; }
  ok(!er, id + ' : create() sans erreur' + (er ? ' → ' + er.stack.split('\n').slice(0, 4).join(' | ') : ''));
  if (er) return;
  var solid = Pc.WORLDS[id].solid;
  var pb = buttons.filter(function (b) { return b.__cfg && /Parcelles/.test(b.__cfg.label || ''); })[0];
  ok(solid ? !!pb && !!e._pcGfx : (!pb && !e._pcGfx), id + (solid ? ' : bouton Parcelles présent' : ' : géante gazeuse, aucune parcelle'));
  if (!solid) return;
  var colBtn = buttons.filter(function (b) { return b.__cfg && /Coloniser|colonie/.test(b.__cfg.label || ''); })[0];
  ok(colBtn && colBtn.__cfg.width === 300 && pb.__cfg.width === 300, id + ' : deux boutons côte à côte dans la fiche');
  var st = N.Resources.state.parcels;
  ok(Pc.ownedCount(st, id) === 0, id + ' : aucune parcelle au départ');
  e._rotYaw = 0; e._rotPitch = 0; e._pcEnter();
  for (var f = 0; f < 3; f++) e.update(f * 16, 16);
  var ex = e._pcGfx, R2 = e._planetR, cx2 = e._planetCX, cy2 = e._planetCY;
  var allBuy = ex.strokes.length > 20 && ex.strokes.every(function (q) { return q.st.c === 0xffd166; });
  ok(allBuy, id + ' : monde vierge : toutes les parcelles visibles sont achetables (' + ex.strokes.length + ')');
  ok(ex.strokes.every(function (q) { return q.pts.every(function (p) { return Math.hypot(p.x - cx2, p.y - cy2) <= R2 + 0.5; }); }), id + ' : contours dans le disque');
  // choisir un site d'atterrissage puis acheter
  var pt0 = e._projectSphere(10, 5); var d0 = e._handlers.pointerdown[0], u0 = e._handlers.pointerup[0];
  d0({ x: pt0.x, y: pt0.y }); u0({ x: pt0.x, y: pt0.y });
  ok(e._pcSel === Pc.cellAt(10, 5).id, id + ' : parcelle choisie au toucher');
  var m0 = wallet.metal + wallet.crystal + wallet.energy + wallet.dust;
  e._pcBuySel();
  ok(Pc.ownedCount(st, id) === 1 && wallet.metal + wallet.crystal + wallet.energy + wallet.dust < m0, id + ' : première parcelle achetée et payée');
  ok(e.fx.toasts.some(function (t) { return /Parcelle/.test(t[0]) && /\+1 %/.test(t[1] || ''); }), id + ' : message « +1 % de production »');
  // bonus de colonie
  var cm = N.ColonyManager; cm.colonize(id, Date.now() - 3600000);
  var base = N.Colonies.rateAt(id, N.Colonies.get(id).inst[0].id, 1) * cm.bonusMult(), got = cm.rates(id)[N.Colonies.get(id).inst[0].res];
  ok(got >= base * 1.01 - 1e-9 && cm.planetMult(id) > 1.0099 && cm.planetMult(id) < 1.0101, id + ' : la colonie produit +1 % grâce à la parcelle (×' + cm.planetMult(id).toFixed(3) + ')');
  e._renderColony && (function () { var er2 = null; try { e._openColony(); e._renderColony(); e._closeColony(); } catch (x) { er2 = x; } ok(!er2, id + ' : panneau de colonie avec bonus de parcelles' + (er2 ? ' → ' + er2.stack.split('\n').slice(0, 3).join('|') : '')); })();
  e._pcExit();
  for (var f2 = 0; f2 < 3; f2++) e.update(f2 * 16, 16);
  ok(ex.strokes.length === 0, id + ' : sortie du mode, overlay effacé');
});

// ============ 7. sauvegarde ancienne / corrompue ============
var old = Pc.normalizeState(undefined, { items: [{ id: 'x', type: 'silo', lon: 150, lat: -70 }] });
ok(Pc.canBuild(old, 'nexus', 150, -70) && Pc.canBuild(old, 'nexus', 0, 5), 'vieille sauvegarde : territoire de départ + parcelle des constructions existantes');
console.log(checks + ' vérifications, ' + fails + ' échec(s)');
process.exit(fails ? 1 : 0);
