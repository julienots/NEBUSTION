global.window = global;
var path = require('path'), root = path.join(__dirname, '..'), fails = 0, checks = 0, calls = {};
function ok(c, m) { checks++; if (!c) { fails++; console.log('ÉCHEC : ' + m); } }
function mk() { var store = {}; var p = new Proxy(function () {}, { get: function (t, k) { if (k === 'then') return undefined; if (k === Symbol.toPrimitive) return function () { return 0; }; if (k in store) return store[k]; return function () { calls[k] = (calls[k] || 0) + 1; return p; }; }, set: function (t, k, v) { store[k] = v; return true; }, apply: function () { return p; } }); return p; }
global.Phaser = { Scene: class { constructor(k) { this.add = mk(); this.tweens = mk(); this.scale = { width: 720, height: 1280 }; } }, BlendModes: { ADD: 1 }, Math: { Clamp: function (v, a, b) { return Math.max(a, Math.min(b, v)); } } };
global.NEBUSTION = { Button: function () { return mk(); }, Economy: {}, Resources: null };
['js/data/PlanetBuild.js', 'js/scenes/PlanetScene.js', 'js/scenes/PlanetBuildUI.js'].forEach(function (f) { require(path.join(root, f)); });
var PB = NEBUSTION.PlanetBuild, s = new NEBUSTION.PlanetScene();
s.fx = mk(); s._cards = [];
// dessin de chaque construction (dont la tour)
PB.ORDER.forEach(function (t) {
  var box = { anim: null }, e = null; calls = {};
  try { s._drawStructure(mk(), PB.CATALOG[t], box); } catch (x) { e = x; }
  ok(!e, 'dessin ' + t + (e ? ' : ' + e.stack.split('\n').slice(0, 2).join('|') : ''));
  if (['tower', 'warehouse', 'harvester', 'chrono', 'refinery', 'condenser'].indexOf(t) >= 0) {
    ok(typeof box.anim === 'function', t + ' : animation présente');
    var e2 = null; try { for (var k = 0; k < 200; k++) box.anim(k * 16); } catch (x) { e2 = x; }
    ok(!e2, t + ' : animation 200 images sans erreur');
  }
});
// catalogue : 14 cartes → 4 rangées, panneau agrandi et aligné
s._buildSheet();
ok(s._cards.length === 14, '14 cartes dans le catalogue');
ok(s._sheetExtra === 240, 'catalogue agrandi de deux rangées (extra = ' + s._sheetExtra + ')');
var maxBottom = Math.max.apply(null, s._cards.map(function (c) { return c.cy + c.ch / 2; }));
ok(maxBottom + 8 < 170 + s._sheetExtra, 'dernière rangée à l\'intérieur du panneau (bas des cartes ' + maxBottom + ' < ' + (170 + s._sheetExtra) + ')');
ok(s._sheetOpenY === 1280 - 300 - s._sheetExtra, 'position ouverte recalculée');
s._sheetOpen = true; ok(s._uiBlocks({ y: 1280 - 500 - 240 }) === false && s._uiBlocks({ y: 1280 - 470 - 240 + 5 }) === true, 'zone bloquant le glissé suit la hauteur du catalogue');
console.log(checks + ' vérifications, ' + fails + ' échec(s)');
process.exit(fails ? 1 : 0);
