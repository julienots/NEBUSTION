/* Tests d'intégration de la Boutique (NEBUSTION.Shop + NEBUSTION.ShopManager), Node, sans Phaser.
 * Lancer : node tests/shop.test.js */
'use strict';
global.window = global;
require('../js/data/Economy.js');
require('../js/data/Heroes.js');
require('../js/data/Enemies.js');
require('../js/data/Galaxy.js');
require('../js/data/EmpireAI.js');
require('../js/data/EmpireDoctrine.js');
require('../js/data/EmpireEvolution.js');
require('../js/data/Equipment.js');
require('../js/data/Ships.js');
require('../js/data/Skins.js');
require('../js/data/Shop.js');
require('../js/systems/SaveManager.js');
require('../js/systems/ResourceManager.js');
require('../js/systems/CombatEngine.js');
require('../js/systems/CombatManager.js');
require('../js/systems/EquipmentManager.js');
require('../js/systems/ShipManager.js');
require('../js/systems/SkinManager.js');
require('../js/systems/ShopManager.js');

let passed = 0, failed = 0;
function ok(cond, msg) { if (cond) { passed++; } else { failed++; console.log('  ✗ ECHEC : ' + msg); } }
function section(t) { console.log('\n# ' + t); }

NEBUSTION.Save._useStorage({ _m: {}, getItem(k) { return this._m[k] || null; }, setItem(k, v) { this._m[k] = v; }, removeItem(k) { delete this._m[k]; } });
NEBUSTION.Resources = new NEBUSTION.ResourceManager();
NEBUSTION.Resources.init(Date.now());

const SM = NEBUSTION.ShopManager, Shop = NEBUSTION.Shop;

section('État par défaut');
{
  ok(NEBUSTION.Resources.state.shop != null, 'state.shop initialisé par SaveManager.defaultState');
  ok(SM.gems() === 30, 'solde de Prismes de départ = 30 (' + SM.gems() + ')');
}

section('Cadeau quotidien');
{
  ok(SM.giftAvailable() === true, 'cadeau disponible au départ');
  const before = SM.gems();
  const res = SM.claimDailyGift();
  ok(res.ok === true, 'réclamation réussie');
  ok(SM.gems() === before + Shop.DAILY_GIFT_GEMS, 'Prismes crédités (+' + Shop.DAILY_GIFT_GEMS + ')');
  const res2 = SM.claimDailyGift();
  ok(res2.ok === false && res2.reason === 'deja', 'un second appel le même jour est refusé');
}

section('Boutique quotidienne : achat en ressources');
{
  const offers = SM.dailyOffers();
  ok(offers.length === Shop.DAILY_SLOTS, Shop.DAILY_SLOTS + ' offres tirées aujourd\'hui');
  const resOffer = offers.find(o => o.kind === 'resource' || o.kind === 'bundle');
  if (resOffer) {
    NEBUSTION.Resources.spendMany(NEBUSTION.Resources.state.res); // vide le stock pour un test propre
    Object.keys(resOffer.cost).forEach(id => { if (id !== 'gem') NEBUSTION.Resources.add(id, resOffer.cost[id] + 100, 'test'); });
    if (resOffer.cost.gem) SM.addGems(resOffer.cost.gem + 100); // crédite aussi les Prismes si l'offre en coûte (ex. « Lot express »)
    const before = NEBUSTION.Resources.get(Object.keys(resOffer.res)[0]);
    const res = SM.buyDaily(resOffer.id);
    ok(res.ok === true, 'achat de « ' + resOffer.label + ' » réussi');
    const after = NEBUSTION.Resources.get(Object.keys(resOffer.res)[0]);
    ok(after > before, 'la ressource achetée a bien été créditée');
    const res2 = SM.buyDaily(resOffer.id);
    ok(res2.ok === false && res2.reason === 'deja', 'un second achat de la même offre le même jour est refusé');
  } else {
    failed++; console.log('  ✗ ECHEC : aucune offre "resource"/"bundle" dans le tirage du jour (imprévu)');
  }
}

section('Boutique quotidienne : offre en Prismes, fonds insuffisants');
{
  const offers = SM.dailyOffers();
  const gemOffer = offers.find(o => o.cost.gem && !SM.isPurchasedToday(o.id));
  if (gemOffer) {
    NEBUSTION.Resources.state.shop.gems = 0;
    const res = SM.buyDaily(gemOffer.id);
    ok(res.ok === false && res.reason === 'ressources', 'achat refusé faute de Prismes suffisants (raison: ' + (res && res.reason) + ')');
  } else {
    ok(true, '(aucune offre en Prismes encore disponible pour ce test — non bloquant)');
  }
}

section('Boutique de héros : paquet de fragments');
{
  SM.claimDailyGift; // no-op, juste pour lisibilité
  NEBUSTION.Resources.state.shop.gems = 500; // recharge pour le test
  const hero = NEBUSTION.Heroes.all()[0];
  const fragBefore = NEBUSTION.Resources.state.combat.fragments[hero.id] || 0;
  const pack = Shop.HERO_PACKS[1]; // paquet moyen (Prismes)
  const res = SM.buyHeroPack(pack.id, hero.id);
  ok(res.ok === true, 'achat du paquet « ' + pack.name + ' » réussi');
  const fragAfter = NEBUSTION.Resources.state.combat.fragments[hero.id] || 0;
  ok(fragAfter === fragBefore + pack.amount, 'fragments crédités au bon héros (+' + pack.amount + ')');
}

section('Boutique d\'équipement');
{
  NEBUSTION.Resources.state.shop.gems = 500;
  const before = Object.keys(NEBUSTION.Resources.state.equipment.items).length;
  const res = SM.buyEquipment('weapon', 'legendaire');
  ok(res.ok === true, 'achat d\'un objet légendaire réussi');
  const after = Object.keys(NEBUSTION.Resources.state.equipment.items).length;
  ok(after === before + 1, 'un nouvel objet a rejoint l\'inventaire');
  ok(res.item.rarity === 'legendaire' && res.item.slot === 'weapon' && res.item.level === 1, 'objet conforme (rareté/emplacement/niveau)');
}

section('Boutique événementielle : achat unique');
{
  const offer = SM.eventOffer();
  ok(SM.isEventBought() === false, 'non achetée au départ');
  Object.keys(offer.cost).forEach(id => NEBUSTION.Resources.add(id, offer.cost[id] + 100, 'test'));
  const gemsBefore = SM.gems();
  const res = SM.buyEvent();
  ok(res.ok === true, 'achat de l\'offre événementielle réussi');
  ok(SM.isEventBought() === true, 'marquée comme achetée');
  ok(SM.gems() === gemsBefore + (offer.contents.gem || 0), 'Prismes du lot crédités');
  const res2 = SM.buyEvent();
  ok(res2.ok === false && res2.reason === 'deja', 'un second achat est refusé (offre unique)');
}

section('Skins : la boutique s\'appuie sur SkinManager existant (aucune donnée dupliquée)');
{
  const skin = NEBUSTION.Skins.SKINS[0];
  const cost = NEBUSTION.Skins.cost(skin.rarity);
  Object.keys(cost).forEach(id => NEBUSTION.Resources.add(id, cost[id] + 100, 'test'));
  ok(NEBUSTION.SkinManager.isOwned(skin.id) === false, 'skin non possédé au départ');
  const res = NEBUSTION.SkinManager.buy(skin.id);
  ok(res.ok === true, 'achat du skin via SkinManager.buy réussi');
  ok(NEBUSTION.SkinManager.isOwned(skin.id) === true, 'skin marqué comme possédé');
}

section('Persistance : normalizeState reconstruit un état valide');
{
  const raw = JSON.parse(JSON.stringify(NEBUSTION.Resources.state.shop));
  const norm = Shop.normalizeState(raw, Date.now());
  ok(norm.gems === raw.gems, 'Prismes conservés à la relecture');
  ok(norm.eventBought === true, 'achat événementiel conservé à la relecture');
  const junk = Shop.normalizeState({ gems: -50, dayIndex: 'NaN', purchasedToday: { d_dust: true, inconnu: true } }, Date.now());
  ok(junk.gems === 0, 'un solde négatif est ramené à 0 (' + junk.gems + ')');
  ok(junk.purchasedToday.d_dust === true && !junk.purchasedToday.inconnu, 'seules les offres connues sont conservées');
}

console.log('\n' + passed + ' tests réussis, ' + failed + ' échec(s).');
process.exit(failed ? 1 : 0);
