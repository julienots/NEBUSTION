"""Test navigateur (Chromium + FAUX Phaser) : QG isométrique du joueur + QG des bots (joueurs adverses) + attaque.
Lancer : python3 tests/browser-qgbots.py   (nécessite playwright pour Python ; CHROME=/chemin/chrome optionnel)"""
import http.server, socketserver, threading, os, sys, json, time
from playwright.sync_api import sync_playwright
root = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
mock = open(os.path.join(root, 'tests', 'mock-phaser.js'), 'rb').read()
class H(http.server.SimpleHTTPRequestHandler):
    def __init__(s, *a, **k): super().__init__(*a, directory=root, **k)
    def do_GET(s):
        if s.path.split('?')[0] == '/js/vendor/phaser.min.js':
            s.send_response(200); s.send_header('Content-Type', 'text/javascript'); s.end_headers(); s.wfile.write(mock); return
        super().do_GET()
    def log_message(s, *a): pass
socketserver.TCPServer.allow_reuse_address = True
srv = socketserver.TCPServer(('127.0.0.1', 8772), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
passed = failed = 0
def ok(c, m):
    global passed, failed
    if c: passed += 1
    else: failed += 1; print('  ✗ ' + m)
with sync_playwright() as p:
    kw = {'args': ['--no-sandbox']}
    if os.environ.get('CHROME'): kw['executable_path'] = os.environ['CHROME']
    b = p.chromium.launch(**kw); pg = b.new_page(viewport={'width': 390, 'height': 780})
    errs = []
    pg.on('pageerror', lambda e: errs.append('pageerror: ' + str(e)))
    pg.on('console', lambda m: errs.append('console.error: ' + m.text) if m.type == 'error' else None)
    R = pg.evaluate
    def wait_scene(k, ms=15000):
        t0 = time.time()
        while time.time() - t0 < ms / 1000:
            if R("k => !!(window.__NEBUSTION_GAME__ && window.__NEBUSTION_GAME__.scene.isActive(k))", k): return True
            time.sleep(0.1)
        return False
    pg.goto('http://127.0.0.1:8772/index.html?debug=1')
    ok(wait_scene('MainMenuScene'), 'menu atteint')
    G = '__NEBUSTION_GAME__.scenes.'
    # ---- Caserne ----
    R("__NEBUSTION_GAME__.scenes.MainMenuScene.scene.start('QGScene', {})")
    ok(wait_scene('QGScene'), 'QGScene'); time.sleep(0.4)
    R("(() => { const r = NEBUSTION.Resources; ['crystal','metal','energy','dust'].forEach(id => { r.state.res[id] = Math.min(r.cap(id), 5000); }); })()")
    ok(R("NEBUSTION.Troops.ORDER.length") == 13, 'catalogue de troupes chargé')
    R("__NEBUSTION_GAME__.scenes.QGScene.scene.start('TroopsScene')")
    ok(wait_scene('TroopsScene'), 'Caserne démarrée'); time.sleep(0.4)
    ok(R(f"{G}TroopsScene._cards.length") == 13, '13 cartes de troupes dans la Caserne')
    R(f"{G}TroopsScene.openShop()")
    ok(wait_scene('ShopScene'), 'Caserne → Boutique'); time.sleep(0.5)
    SS = G + 'ShopScene'
    ok(R(f"{SS}.tab") == 'troops', 'onglet Troupes ouvert')
    ok(R(f"{SS}._tabDefs().some(t => t.id === 'troops')"), 'onglet Troupes déclaré')
    ok(R(f"{SS}._cards.length") >= 14, 'cartes de troupes rendues (%d)' % R(f"{SS}._cards.length"))
    n0 = R("NEBUSTION.TroopManager.count('marine')")
    R("NEBUSTION.ShopManager.buyTroop('marine', 2)")
    ok(R("NEBUSTION.TroopManager.count('marine')") == n0 + 2, 'achat de 2 marines en boutique')
    R(f"{SS}.troopQty = 5; {SS}._render(false)")
    R(f"{SS}.scene.start('QGScene')")
    ok(wait_scene('QGScene'), 'retour QG'); time.sleep(0.4)
    # ---- Barricade dans le QG ----
    S = G + 'QGScene'
    ok(R(f"{S}._buildCards.length") == 4, '4 cartes de structures (barricade incluse)')
    R(f"(() => {{ const s = {S}, p = s._tilePos(2,2); s._handleTap(s.gridLayer.x + p.x, s.gridLayer.y + p.y); }})()")
    R(f"{S}._doBuild('wall')"); time.sleep(0.5)
    ok(R("NEBUSTION.QGGridManager.structureAt(2,2)") == 'wall', 'barricade construite en (2,2)')
    # ---- Mode combat ----
    R(f"{S}._visitEnemy('vexor')")
    ok(wait_scene('EnemyQGScene'), 'EnemyQGScene'); time.sleep(0.5)
    R(f"{G}EnemyQGScene.scene.start('QGBattleScene', {{eid: 'vexor'}})")
    ok(wait_scene('QGBattleScene'), 'QGBattleScene démarrée'); time.sleep(0.5)
    B = G + 'QGBattleScene'
    ok(R(f"{B}.sim.buildings.some(b => b.kind === 'wall') && {B}.sim.buildings.some(b => b.kind === 'core')"), 'base ennemie : barricades + cœur')
    ok(len(R(f"{B}._cards")) >= 2 and R(f"{B}.selected") == 'marine', 'réserve affichée, marine sélectionnée')
    # rendu iso : conversion écran <-> cellule fidèle, design de chaque troupe généré (2 images de marche), cœur en volume
    ok(R(f"(() => {{ const s = {B}; const p = s._scr(-1, 2.3); const q = s._unproject(p.x, p.y); return Math.abs(q.x + 1) < 1e-6 && Math.abs(q.y - 2.3) < 1e-6; }})()"), 'conversion iso écran <-> cellule aller-retour')
    # ---- Zoom de la zone de combat (module 20) ----
    ok(R(f"{B}.zoom") == 1 and R(f"{B}.worldScale") == R(f"{B}.ws"), 'zoom initial = 100 % (aucun effet sur le rendu existant)')
    R(f"{B}._applyZoomAt({B}.zoom * 1.5, {B}.cx, {B}.cy)")
    ok(abs(R(f"{B}.zoom") - 1.5) < 1e-6 and abs(R(f"{B}.worldScale") - R(f"{B}.ws") * 1.5) < 1e-6, 'zoom avant (molette/bouton +) applique bien x1.5')
    ok(R(f"(() => {{ const s = {B}; const p = s._scr(2, -1.5); const q = s._unproject(p.x, p.y); return Math.abs(q.x - 2) < 1e-6 && Math.abs(q.y + 1.5) < 1e-6; }})()"), 'conversion écran <-> cellule toujours fidèle une fois zoomé')
    R(f"{B}._applyZoomAt(99, {B}.cx, {B}.cy)")
    ok(R(f"{B}.zoom") == R(f"{B}.maxZoom"), 'le zoom est plafonné (maxZoom)')
    R(f"{B}._applyZoomAt(0.01, {B}.cx, {B}.cy)")
    ok(R(f"{B}.zoom") == R(f"{B}.minZoom"), 'le zoom est plancher (minZoom)')
    R(f"{B}._resetZoom()")
    ok(R(f"{B}.zoom") == 1 and R(f"{B}.worldX") == R(f"{B}.cx") and R(f"{B}.worldY") == R(f"{B}.cy"), 'le bouton ⟲ réinitialise zoom + position')
    ok(R(f"(() => {{ try {{ {B}._handlePinch(); return true; }} catch (e) {{ return false; }} }})()"), '_handlePinch() ne plante pas hors pincement (pointer1/2 absents en environnement de test)')
    ok(R("NEBUSTION.Troops.ORDER.every(id => __NEBUSTION_GAME__.textures.exists('qgtr_' + id + '_0') && __NEBUSTION_GAME__.textures.exists('qgtr_' + id + '_1'))"), 'design de chaque troupe (2 images) généré')
    ok(R("__NEBUSTION_GAME__.textures.exists('qgiso_b_core')"), 'cœur du QG dessiné en volume iso')
    ok(R(f"Object.keys({B}._bn).length") == R(f"{B}.sim.buildings.length"), 'chaque structure a son volume iso')
    before = R("NEBUSTION.TroopManager.total()")
    R(f"{B}._onTap({{x: {B}._scr(3,3).x, y: {B}._scr(3,3).y}})")   # dans la base : refusé
    ok(R("NEBUSTION.TroopManager.total()") == before, 'tap dans la base : aucune troupe consommée')
    R(f"(() => {{ const s = {B}; for (let i = 0; i < 6; i++) s._onTap({{x: s._scr(-1, 2 + i * 0.3).x, y: s._scr(-1, 2 + i * 0.3).y}}); }})()")
    ok(R("NEBUSTION.TroopManager.total()") == before - 6, '6 troupes déployées et consommées')
    ok(R(f"Object.keys({B}._un).length") == 6, '6 sprites de troupes créés (design par troupe)')
    R(f"(() => {{ const s = {B}; s.selected = 'berserker'; for (let i = 0; i < 2; i++) s._onTap({{x: s._scr(7, 2.5 + i * 0.3).x, y: s._scr(7, 2.5 + i * 0.3).y}}); }})()")
    R(f"(() => {{ for (let i = 0; i < 400; i++) {B}.sim.step(1); }})()")   # accélère la fin du combat (le temps réel prendrait ~30 s)
    t0 = time.time()
    while time.time() - t0 < 5 and not R(f"{B}._done"): time.sleep(0.2)
    ok(R(f"{B}.sim.over"), 'combat terminé (temps réel simulé)')
    ok(R(f"{B}._done"), 'écran de résultat affiché')
    res = R(f"{B}.sim.result()")
    print('  résultat :', json.dumps(res))
    ok(R("NEBUSTION.QGAttackManager.log().length") >= 1, 'résultat appliqué au journal d\'attaques')
    # ---- Trophées de QG (module 20) ----
    lastEntry = R("NEBUSTION.QGAttackManager.lastResult()")
    ok('trophies' in lastEntry, 'chaque résultat de combat porte un delta de Trophées')
    ok(R("NEBUSTION.QGAttackManager.trophies()") >= 0, 'le total de Trophées ne descend jamais sous 0')
    if lastEntry.get('victory'):
        ok(lastEntry['trophies'] > 0 and R("NEBUSTION.QGAttackManager.trophies()") == lastEntry['trophies'], 'victoire : Trophées gagnés et crédités au total')
    else:
        ok(lastEntry['trophies'] <= 0, 'défaite : pas de gain de Trophées')
    R(f"{B}.scene.start('EnemyQGScene', {{eid: 'vexor'}})")
    ok(wait_scene('EnemyQGScene'), 'retour au QG ennemi'); time.sleep(0.3)
    R(f"{G}EnemyQGScene.scene.start('QGBattleScene', {{eid: 'vexor'}})")
    ok(wait_scene('QGBattleScene'), 'nouveau combat'); time.sleep(0.3)
    R(f"{G}QGBattleScene.scene.start('PassScene')")
    ok(wait_scene('PassScene'), 'Pass (récompenses de troupes) s\'ouvre'); time.sleep(0.5)
    errs = [e for e in errs if 'Failed to load resource' not in e and 'favicon' not in e]
    ok(not errs, 'zéro erreur JS ' + json.dumps(errs[:3], ensure_ascii=False))
    b.close()
print('\n' + ('✔ ' if not failed else '✘ ') + 'Mode combat (navigateur, faux Phaser) : %d réussis, %d échoués' % (passed, failed))
sys.exit(1 if failed else 0)
