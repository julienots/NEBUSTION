/* Tests du Pass Doré (palier au-dessus du Premium) + coffrets + skins exclusifs. Node, sans Phaser.
 * Lancer : node tests/goldenpass.test.js */
'use strict';
global.window = global;
['data/Economy', 'data/Heroes', 'data/Enemies', 'data/Galaxy', 'data/EmpireAI', 'data/EmpireDoctrine', 'data/EmpireEvolution', 'data/Equipment', 'data/Ships', 'data/Skins', 'data/Shop', 'data/Pass',
  'systems/SaveManager', 'systems/ResourceManager', 'systems/CombatEngine', 'systems/CombatManager', 'systems/EquipmentManager', 'systems/ShipManager', 'systems/SkinManager', 'systems/ShopManager',
  'systems/PassBilling', 'systems/PassManager'].forEach(f => require('../js/' + f + '.js'));

let passed = 0, failed = 0;
function ok(cond, msg) { if (cond) passed++; else { failed++; console.log('  ✗ ECHEC : ' + msg); } }
function section(t) { console.log('\n# ' + t); }

const P = NEBUSTION.Pass, PM = NEBUSTION.PassManager, B = NEBUSTION.PassBilling, SM = NEBUSTION.SkinManager;
const store = { _m: {}, getItem(k) { return this._m[k] || null; }, setItem(k, v) { this._m[k] = v; }, removeItem(k) { delete this._m[k]; } };
NEBUSTION.Save._useStorage(store);
NEBUSTION.Resources = new NEBUSTION.ResourceManager();
NEBUSTION.Resources.init(Date.now());
const R = NEBUSTION.Resources;
function fresh() { PM._reset(); R.state.pass = P.defaultState(Date.now()); }

section('Données : piste Dorée');
{
  P.THEMES.forEach((th, i) => {
    const L = P.levelsFor(i);
    ok(L.length === 30 && L.every(l => l.golden && l.golden.kind), th.key + ' : 30 récompenses dorées');
    ok([5, 15, 25].every(n => L[n - 1].golden.kind === 'chest'), th.key + ' : coffrets aux niveaux 5, 15, 25');
    ok(L[11].golden.kind === 'skin' && L[29].golden.kind === 'skin', th.key + ' : skins exclusifs aux niveaux 12 et 30');
    [11, 29].forEach(k => { const sk = NEBUSTION.Skins.get(L[k].golden.skinId); ok(sk && sk.exclusive, th.key + ' : skin niveau ' + (k + 1) + ' exclusif (' + L[k].golden.skinId + ')'); });
    ok(NEBUSTION.Skins.get(L[29].golden.skinId).rarity === 'legendaire', th.key + ' : skin niveau 30 légendaire');
  });
  const c = P.levelsFor(0)[4].golden;
  ok(c.items.length === 2 && c.items.every(it => NEBUSTION.Economy.RES[it.res] && it.amount > 0), 'coffret : ressources valides');
  const all = new Set(); P.THEMES.forEach((th, i) => P.levelsFor(i).forEach(l => { if (l.golden.kind === 'skin') all.add(l.golden.skinId); }));
  ok(all.size === 8, '8 skins exclusifs distincts sur les 4 thèmes (' + all.size + ')');
  ok(P.reward(0, 12, 'golden').skinId === P.levelsFor(0)[11].golden.skinId, 'reward(golden) cohérent avec levelsFor');
}

section('Skins exclusifs non achetables');
{
  const r = SM.buy('h_couronne');
  ok(r.ok === false && r.reason === 'exclusif' && !SM.isOwned('h_couronne'), 'buy() refuse un skin exclusif');
  ok(SM.buy('h_cyan').reason !== 'exclusif', 'un skin normal reste achetable');
}

section('État et octroi');
{
  fresh();
  ok(!PM.isGolden() && PM.rightTrack() === 'premium', 'départ : ni Golden, colonne de droite = premium');
  ok(PM.status(1, 'golden') === 'locked', 'niveau non atteint : locked');
  PM.addXp(P.MAX_XP);
  ok(PM.status(1, 'golden') === 'golden_locked', 'sans Golden : golden_locked');
  ok(PM.claim(1, 'golden').reason === 'golden', 'claim golden refusé sans Pass Doré');
  ok(PM.claimableList().every(c => c.track !== 'golden'), 'claimableList sans golden');
  PM.grantGolden({ source: 'test' });
  ok(PM.isGolden() && PM.isPremium() && PM.rightTrack() === 'golden', 'grantGolden : Golden + Premium, colonne = golden');
  ok(PM.state().goldenSource === 'test', 'source enregistrée');
  const cl = PM.claimableList();
  ok(cl.filter(c => c.track === 'golden').length === 30 && cl.filter(c => c.track === 'free').length === 30 && !cl.some(c => c.track === 'premium'), 'réclamables : 30 free + 30 golden (pas de premium)');
}

section('Réclamation : coffrets, ressources, skins exclusifs');
{
  fresh(); PM.addXp(P.MAX_XP); PM.grantGolden({ source: 'test' });
  const before = { crystal: R.get('crystal'), energy: R.get('energy') };
  const r5 = PM.claim(5, 'golden');
  ok(r5.ok && r5.reward.kind === 'chest', 'coffret niveau 5 réclamé');
  ok(R.get('crystal') > before.crystal && R.get('energy') > before.energy, 'les 2 ressources du coffret sont créditées');
  ok(PM.claim(5, 'golden').reason === 'deja', 'double réclamation refusée');
  const r12 = PM.claim(12, 'golden');
  ok(r12.ok && SM.isOwned(r12.reward.skinId), 'skin exclusif niveau 12 ajouté à la collection');
  const all = PM.claimAll();
  ok(all.claimed.length + all.blocked.length > 0, 'claimAll traite les pistes free + golden');
  ok(PM.state().claimed.golden[5] === true && PM.state().claimed.premium[5] !== true, 'claims golden séparés des claims premium');
}

section('Coffret : tout ou rien si stockage plein');
{
  fresh(); PM.addXp(P.MAX_XP); PM.grantGolden({ source: 'test' });
  const cap = R.cap('crystal'); R.add('crystal', cap, 'test');
  const e0 = R.get('energy');
  const r = PM.claim(5, 'golden');
  ok(r.ok === false && r.reason === 'stockage', 'stockage plein : refus');
  ok(Math.abs(R.get('energy') - e0) < 1e-6 && !PM.state().claimed.golden[5], 'refus atomique : rien crédité, non marqué réclamé');
}

section('Upgrade Premium → Golden');
{
  fresh(); PM.addXp(P.MAX_XP); PM.grantPremium({ source: 'test' });
  ok(PM.claim(3, 'premium').ok, 'niveau 3 réclamé sur la piste Premium');
  PM.grantGolden({ source: 'test' });
  ok(PM.status(3, 'golden') === 'available', 'après upgrade : le niveau 3 est réclamable sur la piste Dorée');
  ok(PM.status(3, 'premium') === 'claimed', 'le claim Premium reste enregistré');
}

section('Achat en ressources');
{
  fresh();
  const full = B.goldenPrice(), E = NEBUSTION.Economy;
  ok(Object.keys(full).length === 5 && Object.keys(full).every(id => full[id] <= E.PROD[id].cap), 'prix complet ≤ stockage de base');
  full.crystal = 1; ok(B.goldenPrice().crystal !== 1, 'goldenPrice() renvoie une copie');
  PM.grantPremium({ source: 'test' });
  const up = B.goldenPrice(), pr = B.resourcePrice();
  ok(Object.keys(up).every(id => up[id] + pr[id] === (id === 'crystal' ? 14000 : id === 'metal' ? 11000 : id === 'energy' ? 5500 : id === 'core' ? 140 : 28000)), 'upgrade = prix complet − Premium');
  Object.keys(up).forEach(id => R.spend(id, R.get(id)));
  ok(!B.canPayGoldenWithResources() && B.payGoldenWithResources().reason === 'ressources' && !PM.isGolden(), 'sans ressources : refus');
  Object.keys(up).forEach(id => R.add(id, up[id], 'test'));
  const r = B.payGoldenWithResources();
  ok(r.ok && PM.isGolden() && PM.state().goldenSource === 'resources', 'paiement : Pass Doré activé');
  ok(Object.keys(up).every(id => R.get(id) < 1e-6), 'ressources débitées exactement');
  ok(B.payGoldenWithResources().reason === 'deja', 'double achat refusé');
  ok(B.skuForSeasonGolden(3) === 'nebustion_pass_golden_s3', 'SKU doré par saison');
}

section('Achats intégrés : aucune simulation');
{
  fresh();
  B.resetProvider();
  let done = false;
  B.purchaseGolden().then(r => { ok(r.ok === false && r.reason === 'billing_unavailable' && !PM.isGolden(), 'fournisseur absent : rien activé'); done = true; });
  setTimeout(() => { ok(done, 'promesse résolue'); finish(); }, 20);
}

section('Sauvegarde');
{
  const s = P.normalizeState({ season: P.seasonIndex(Date.now()), xp: 100, golden: true, goldenSource: 'x', claimed: { golden: { 3: true, 99: true } } }, Date.now());
  ok(s.golden && s.premium && s.claimed.golden[3] === true && !s.claimed.golden[99], 'normalizeState : golden conservé, premium forcé, niveaux hors bornes nettoyés');
  const old = P.normalizeState({ season: P.seasonIndex(Date.now()), xp: 10, premium: true, claimed: { free: {}, premium: { 1: true } } }, Date.now());
  ok(old.golden === false && old.claimed.golden && Object.keys(old.claimed.golden).length === 0, 'ancienne sauvegarde : pas de Golden, piste dorée vide');
  const a = P.normalizeState({ season: -1 + P.seasonIndex(Date.now()), xp: 900, golden: true }, Date.now());
  ok(a.golden === false && a.history.length === 1 && a.history[0].golden === true, 'nouvelle saison : Golden expire, archivé dans l\'historique');
}

function finish() {
  console.log('\n' + (failed ? '✗ ÉCHECS — ' : '✓ TOUS LES TESTS SONT PASSÉS — ') + passed + ' réussis, ' + failed + ' échoués');
  process.exit(failed ? 1 : 0);
}
