/* Tests des attaques du JOUEUR contre le QG des empires (NEBUSTION.QGAttack + QGAttackManager). Node, sans Phaser.
 * Lancer : node tests/qgAttack.test.js */
'use strict';
global.window = global;
require('../js/data/Economy.js'); require('../js/data/Heroes.js'); require('../js/data/Enemies.js'); require('../js/data/Galaxy.js');
require('../js/data/EmpireAI.js'); require('../js/data/EmpireDoctrine.js'); require('../js/data/EmpireEvolution.js');
require('../js/data/Equipment.js'); require('../js/data/Ships.js');
require('../js/data/Security.js'); require('../js/data/QGGrid.js'); require('../js/data/QGRaid.js'); require('../js/data/QGAttack.js');
require('../js/systems/SaveManager.js'); require('../js/systems/ResourceManager.js'); require('../js/systems/CombatEngine.js');
require('../js/systems/CombatManager.js'); require('../js/systems/EquipmentManager.js'); require('../js/systems/ShipManager.js');
require('../js/systems/GalaxyManager.js'); require('../js/systems/EmpireAIManager.js');
require('../js/systems/EmpireEvolutionManager.js'); require('../js/systems/SecurityManager.js'); require('../js/systems/QGGridManager.js');
require('../js/systems/QGRaidManager.js'); require('../js/systems/QGAttackManager.js');

const D = NEBUSTION.QGAttack, Ships = NEBUSTION.Ships, EM = NEBUSTION.EmpireEvolutionManager, GM = NEBUSTION.GalaxyManager;
const SH = NEBUSTION.ShipManager, AM = NEBUSTION.QGAttackManager, Save = NEBUSTION.Save, G = NEBUSTION.Galaxy;
let passed = 0, failed = 0;
function ok(c, m) { if (c) passed++; else { failed++; console.log('  ✗ ECHEC : ' + m); } }
function section(t) { console.log('\n# ' + t); }
function memStorage() { const m = {}; return { data: m, getItem: k => (k in m ? m[k] : null), setItem: (k, v) => { m[k] = String(v); }, removeItem: k => { delete m[k]; } }; }
const T0 = 1_800_000_000_000, H = 3600 * 1000, DAY = 24 * H;
function fresh(seed, team) {
  const storage = memStorage(); Save._useStorage(storage);
  NEBUSTION.Resources = new NEBUSTION.ResourceManager(); NEBUSTION.Resources.init(T0);
  NEBUSTION.Resources.state.empires.seed = seed || 12345;
  G.SECTORS.forEach(s => { GM.state().unlocked[s.id] = true; });
  GM.teamLevel = () => (team == null ? 45 : team);
  EM.stop();
  return NEBUSTION.Resources;
}
/** Ajoute un vaisseau directement dans le hangar ET dans la flotte, sans passer par le coût (pratique pour les tests). */
function giveShip(classId, rarity, level) {
  const s = NEBUSTION.Resources.state.ships, uid = 'sh' + (s.nextSeq++);
  s.ships[uid] = { classId: classId, rarity: rarity, level: level || 1 };
  s.fleet.push(uid);
  return uid;
}

section('QGAttack — formules pures');
{
  ok(D.attackPower(0) >= 1, 'puissance d\'attaque jamais nulle, même sans flotte');
  ok(D.attackPower(20) > D.attackPower(5), 'puissance d\'attaque croissante avec la puissance de flotte');
  ok(D.defensePower(0, 0) < D.defensePower(4, 0) && D.defensePower(4, 0) < D.defensePower(8, 0), 'défense croissante avec le développement (evo)');
  ok(D.defensePower(4, 1) < D.defensePower(4, 0), 'le traumatisme (hurt) affaiblit la défense');
  ok(D.victoryChance(10, 10) === 0.5, 'attaque = défense -> 50 / 50');
  ok(D.victoryChance(20, 5) > D.victoryChance(10, 10) && D.victoryChance(10, 10) > D.victoryChance(5, 20), 'chance de victoire croissante avec l\'écart attaque - défense');
  ok(D.victoryChance(0, 999) >= 0 && D.victoryChance(999, 0) <= 1, 'chance de victoire toujours dans [0,1]');
  const l1 = D.lootFor(0, 0), l2 = D.lootFor(8, 1);
  ok(l2.crystal > l1.crystal && l2.metal > l1.metal && l2.energy > l1.energy, 'butin plus riche contre un empire développé / grande marge de victoire');
  ok(l1.core === undefined, 'les Noyaux antiques (core) ne font jamais partie du butin');
}

section('QGAttack — normalizeState résiste aux données abîmées');
{
  const n = D.normalizeState(null);
  ok(Object.keys(n.cooldowns).length === 0 && n.log.length === 0, 'état par défaut : aucune recharge, historique vide');
  const bad = D.normalizeState({ cooldowns: { vexor: -5, kael9: 'x', elyra: 999 }, log: [null, 42, { empire: 'vexor', at: 5, victory: true, attack: 9, defense: 2, loot: { crystal: -3, metal: 'x', energy: 4 } }, { at: 9 }] });
  ok(bad.cooldowns.elyra === 999 && bad.cooldowns.vexor === undefined && bad.cooldowns.kael9 === undefined, 'recharges invalides ignorées, la valide conservée');
  ok(bad.log.length === 1 && bad.log[0].empire === 'vexor', 'entrées d\'historique invalides ignorées, la valide conservée');
  ok(bad.log[0].loot.crystal === 0 && bad.log[0].loot.energy === 4 && bad.log[0].loot.metal === undefined, 'butin invalide nettoyé ligne par ligne');
  const long = D.normalizeState({ log: Array.from({ length: 20 }, (_, i) => ({ empire: 'vexor', at: i, victory: false, attack: 1, defense: 1, loot: {} })) });
  ok(long.log.length === D.LOG_MAX, 'historique tronqué à LOG_MAX entrées (les plus récentes)');
}

section('QGAttackManager — non-régression sauvegarde (nouvelle partie)');
{
  const R = fresh();
  ok(R.state.qgAttack && Array.isArray(R.state.qgAttack.log) && R.state.qgAttack.log.length === 0, 'une nouvelle partie initialise qgAttack sans historique');
  ok(AM.log().length === 0, 'aucune attaque au démarrage');
  ok(AM.lastResult() === null, 'aucun dernier résultat au démarrage');
}

section('QGAttackManager — sans flotte, aucune attaque possible');
{
  fresh(1);
  EM.update(T0 + 60 * DAY);   // laisse les empires se développer largement
  const eid = G.EMPIRE_ORDER[0];
  ok(SH.getFleet().length === 0, 'flotte vide par défaut');
  const can = AM.canAttack(eid, T0 + 60 * DAY);
  ok(!can.ok && can.reason === 'flotte_vide', 'attaque refusée : flotte vide');
  const res = AM.attack(eid, T0 + 60 * DAY);
  ok(!res.ok && res.reason === 'flotte_vide', 'attack() refuse aussi directement sans flotte');
}

section('QGAttackManager — victoire garantie (flotte écrasante) : butin crédité, empire affaibli, cooldown posé');
{
  fresh(2);
  EM.update(T0 + 5 * DAY);
  const eid = G.EMPIRE_ORDER[0];
  giveShip('intercepteur', 'legendaire', 10); giveShip('cuirasse', 'legendaire', 10); giveShip('corvette', 'legendaire', 10);
  const before = { crystal: NEBUSTION.Resources.get('crystal'), metal: NEBUSTION.Resources.get('metal'), energy: NEBUSTION.Resources.get('energy') };
  const esBefore = EM.state(T0 + 5 * DAY).e[eid], hurtBefore = esBefore.hurt || 0, momBefore = esBefore.mom || 0;
  const realRandom = Math.random;
  Math.random = () => 0;   // force la victoire (0 < n'importe quelle victoryChance > 0)
  const can = AM.canAttack(eid, T0 + 5 * DAY);
  ok(can.ok, 'attaque possible : flotte non vide, empire vivant, pas de recharge');
  const res = AM.attack(eid, T0 + 5 * DAY);
  Math.random = realRandom;
  ok(res.ok && res.result.victory, 'l\'attaque forcée est bien une victoire');
  ok(res.result.loot.crystal > 0 && res.result.loot.metal > 0 && res.result.loot.energy > 0, 'butin non nul sur victoire');
  ok(NEBUSTION.Resources.get('crystal') === before.crystal + res.result.loot.crystal, 'cristaux crédités exactement du butin annoncé');
  ok(NEBUSTION.Resources.get('metal') === before.metal + res.result.loot.metal, 'métal crédité exactement du butin annoncé');
  ok(NEBUSTION.Resources.get('energy') === before.energy + res.result.loot.energy, 'énergie créditée exactement du butin annoncé');
  const esAfter = EM.state(T0 + 5 * DAY).e[eid];
  ok(esAfter.hurt > hurtBefore, 'l\'empire encaisse un traumatisme accru après une défaite de son QG');
  ok(esAfter.mom <= momBefore, 'l\'élan de l\'empire ne progresse pas après une défaite de son QG');
  ok(AM.cooldownRemaining(eid, T0 + 5 * DAY) === D.COOLDOWN_MS, 'la recharge démarre immédiatement après l\'attaque');
  const can2 = AM.canAttack(eid, T0 + 5 * DAY + 60000);
  ok(!can2.ok && can2.reason === 'recharge', 'une seconde attaque immédiate contre le même empire est refusée (recharge)');
  const can3 = AM.canAttack(eid, T0 + 5 * DAY + D.COOLDOWN_MS + 1000);
  ok(can3.ok, 'l\'attaque redevient possible une fois la recharge écoulée');
}

section('QGAttackManager — défaite garantie (flotte dérisoire) : rien perdu, rien gagné, recharge quand même posée');
{
  fresh(3);
  EM.update(T0 + 200 * DAY);   // empire très développé
  const eid = G.EMPIRE_ORDER[0];
  giveShip('intercepteur', 'commun', 1);
  const before = { crystal: NEBUSTION.Resources.get('crystal'), metal: NEBUSTION.Resources.get('metal'), energy: NEBUSTION.Resources.get('energy') };
  const realRandom = Math.random;
  Math.random = () => 0.999999;   // force la défaite (chance de victoire toujours < 1)
  const res = AM.attack(eid, T0 + 200 * DAY);
  Math.random = realRandom;
  ok(res.ok && !res.result.victory, 'l\'attaque forcée est bien une défaite');
  ok(NEBUSTION.Resources.get('crystal') === before.crystal && NEBUSTION.Resources.get('metal') === before.metal && NEBUSTION.Resources.get('energy') === before.energy, 'aucune ressource perdue ni gagnée sur une défaite');
  ok(AM.cooldownRemaining(eid, T0 + 200 * DAY) === D.COOLDOWN_MS, 'la recharge est posée même après une défaite (anti-spam)');
}

section('QGAttackManager — empire déjà vaincu : cible invalide');
{
  fresh(4);
  EM.update(T0 + 5 * DAY);
  giveShip('intercepteur', 'legendaire', 10);
  const eid = G.EMPIRE_ORDER[0];
  G.planetsOfEmpire(eid).forEach(p => GM.setConquered(p.id, true, T0 + 5 * DAY));
  ok(!AM.isAlive(eid), 'empire sans planète non conquise = considéré vaincu');
  const can = AM.canAttack(eid, T0 + 5 * DAY);
  ok(!can.ok && can.reason === 'vaincu', 'attaque refusée contre un empire déjà vaincu');
  ok(AM.targets().indexOf(eid) < 0, 'un empire vaincu ne fait plus partie des cibles proposées');
}

section('Ships / ShipManager — puissance d\'attaque de la flotte (module 17)');
{
  fresh(5);
  ok(SH.fleetPower() === 0, 'puissance de flotte nulle sans vaisseau');
  const a = Ships.attackPower('intercepteur', 'commun', 1);
  const b = Ships.attackPower('intercepteur', 'legendaire', 1);
  const c = Ships.attackPower('intercepteur', 'commun', 10);
  ok(b > a, 'la rareté augmente la puissance d\'attaque');
  ok(c > a, 'le niveau augmente la puissance d\'attaque');
  giveShip('intercepteur', 'commun', 1); giveShip('cuirasse', 'commun', 1);
  ok(Math.abs(SH.fleetPower() - a * 2) < 0.01, 'la puissance de flotte est la somme des vaisseaux engagés (rôles à parts égales)');
}

const label = 'Tests QGAttack (attaques du QG ennemi)';
console.log('\n' + (failed ? '✘ ' : '✔ ') + label + ' : ' + passed + ' réussis, ' + failed + ' échoués');
process.exit(failed ? 1 : 0);
