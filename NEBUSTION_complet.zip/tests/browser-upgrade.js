/*
 * Test navigateur (Chromium + FAUX Phaser) de l'amélioration des bâtiments / extracteurs / stockage.
 *   NODE_PATH=$(npm root -g) node tests/browser-upgrade.js
 * Vérifie l'interface réelle : tap sur un bâtiment → panneau, bouton grisé + toast si trop pauvre,
 * amélioration payée exactement, badge / étiquette mis à jour, extracteurs (▲), Stockage (panneau Production),
 * niveau maximum, persistance après rechargement, zéro erreur JS.
 */
const http = require('http'), fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const root = path.join(__dirname, '..');
const mock = fs.readFileSync(path.join(__dirname, 'mock-phaser.js'), 'utf8');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]);
  if (u === '/js/vendor/phaser.min.js') { res.writeHead(200, { 'Content-Type': 'text/javascript' }); return res.end(mock); }
  const f = path.join(root, u === '/' ? 'index.html' : u);
  if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('nf'); }
  res.writeHead(200, { 'Content-Type': mime[path.extname(f)] || 'application/octet-stream' }); res.end(fs.readFileSync(f));
});
let passed = 0, failed = 0;
const ok = (c, m) => { if (c) passed++; else { failed++; console.log('  ✗ ' + m); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  await new Promise(r => server.listen(8766, r));
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 780 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console.error: ' + m.text()); });
  const R = expr => page.evaluate(expr);
  async function waitScene(key, ms) {
    const t0 = Date.now();
    while (Date.now() - t0 < (ms || 15000)) {
      if (await page.evaluate(k => !!(window.__NEBUSTION_GAME__ && window.__NEBUSTION_GAME__.scene.isActive(k)), key)) return true;
      await sleep(100);
    }
    return false;
  }
  const S = '__NEBUSTION_GAME__.scenes.PlanetScene';
  // élément interactif d'un conteneur de bâtiment (la zone tactile)
  const tapBuilding = key => R(`(() => { const s = ${S}; const z = s._buildingBoxes.${key}.container.list.find(o => o._interactive); z.emit('pointerdown', {}); return true; })()`);
  const pressUpgrade = async () => { await R(`${S}._upgradeBtn.emit('pointerup', {})`); await sleep(300); };
  const give = amt => R(`(() => { const r = NEBUSTION.Resources; ['crystal','metal','energy','dust'].forEach(id => { r.state.res[id] = Math.min(r.cap(id), ${amt}); }); r.state.res.core = Math.min(r.cap('core'), 200); })()`);

  console.log('# Chargement, nouvelle partie');
  await page.goto('http://localhost:8766/index.html?debug=1');
  ok(await waitScene('MainMenuScene'), 'menu atteint');
  await R(`__NEBUSTION_GAME__.scenes.MainMenuScene.scene.start('PlanetScene', {})`);
  ok(await waitScene('PlanetScene'), 'PlanetScene démarrée');
  await sleep(500);

  console.log('# Commandement : trop pauvre');
  ok(await R('NEBUSTION.Resources.level("command")') === 3, 'Commandement niveau 3 au départ');
  await tapBuilding('command');
  await sleep(350);
  let st = await R(`(() => { const s = ${S}; return { open: s._panelOpen, key: s._infoPanelKey, title: s._infoPanelTitle.text, level: s._infoPanelLevel.text, eff: s._infoPanelEffect.text, btn: s._upgradeBtn.labelText.text, costs: s._costSlots.filter(c => c.text.visible).map(c => c.text.text) }; })()`);
  ok(st.open && st.key === 'command' && st.title === 'Commandement', 'panneau ouvert sur Commandement : ' + JSON.stringify(st));
  ok(/Niveau 3/.test(st.level), 'niveau affiché : ' + st.level);
  ok(/Renaissance/.test(st.eff), 'effet (Renaissance) : ' + st.eff);
  ok(st.costs.length === 3, '3 coûts affichés (cristaux, métal, énergie) : ' + st.costs.join(','));
  ok(/insuffisantes/.test(st.btn), 'bouton « ressources insuffisantes » : ' + st.btn);
  const resBefore = await R('JSON.stringify(NEBUSTION.Resources.state.res)');
  const toasts0 = await R(`${S}.fx.toasts.length`);
  await pressUpgrade();
  ok(await R('NEBUSTION.Resources.level("command")') === 3, 'niveau inchangé si trop pauvre');
  ok(await R(`${S}.fx.toasts.length`) > toasts0, 'toast « Ressources insuffisantes » affiché');
  const spent = await R(`(() => { const a = ${resBefore}, b = NEBUSTION.Resources.state.res; return Object.keys(a).some(k => b[k] < a[k] - 1e-6); })()`);
  ok(!spent, 'aucune ressource débitée si refus');

  console.log('# Commandement : amélioration payée');
  await give(5000);
  await sleep(350);
  st = await R(`(() => { const s = ${S}; return { btn: s._upgradeBtn.labelText.text, costs: s._costSlots.filter(c => c.text.visible).map(c => c.text.text) }; })()`);
  ok(/Nv\.4/.test(st.btn), 'bouton actif « → Nv.4 » : ' + st.btn);
  const pre = await R('({ c: NEBUSTION.Resources.get("crystal"), m: NEBUSTION.Resources.get("metal"), e: NEBUSTION.Resources.get("energy") })');
  await pressUpgrade();
  ok(await R('NEBUSTION.Resources.level("command")') === 4, 'Commandement → niveau 4');
  const post = await R('({ c: NEBUSTION.Resources.get("crystal"), m: NEBUSTION.Resources.get("metal"), e: NEBUSTION.Resources.get("energy") })');
  const cost = await R('NEBUSTION.Economy.upgradeCost("command", 3)');
  ok(Math.abs((pre.c - post.c) - cost.crystal) < 5 && Math.abs((pre.m - post.m) - cost.metal) < 5 && Math.abs((pre.e - post.e) - cost.energy) < 5,
    `coût exact débité (${JSON.stringify(cost)}) : Δ ${(pre.c - post.c).toFixed(1)}/${(pre.m - post.m).toFixed(1)}/${(pre.e - post.e).toFixed(1)}`);
  st = await R(`(() => { const s = ${S}; return { badge: s._buildingBoxes.command.badge.text, level: s._infoPanelLevel.text }; })()`);
  ok(st.badge === 'Nv.4' && /Niveau 4/.test(st.level), 'badge et panneau à jour : ' + JSON.stringify(st));
  ok(await R('NEBUSTION.Save.read ? true : true'), 'sauvegarde OK');

  console.log('# Hangar / Laboratoire / Défense');
  for (const k of ['hangar', 'lab', 'defense']) {
    await give(6000);
    const l0 = await R(`NEBUSTION.Resources.level("${k}")`);
    await tapBuilding(k); await sleep(350);
    await pressUpgrade();
    ok(await R(`NEBUSTION.Resources.level("${k}")`) === l0 + 1, `${k} : niveau ${l0} → ${l0 + 1}`);
  }
  ok(await R(`NEBUSTION.Resources.droneRate("crystal")`) > 0.2 * 1.12 + 0.0001, 'le Hangar amélioré augmente bien le rendement des drones');

  console.log('# Extracteurs (flèche ▲ / niveau)');
  await give(5000);
  await sleep(300);
  const arrow = await R(`(() => { const n = ${S}.nodes.crystal; return { can: n._canUp, x: n.upArrow.x, hasZone: !!n.upZone._interactive }; })()`);
  ok(arrow.can === true && arrow.hasZone, 'flèche ▲ verte quand on peut payer, zone tactile présente : ' + JSON.stringify(arrow));
  await R(`${S}.nodes.crystal.upZone.emit('pointerdown', {})`);
  await sleep(350);
  st = await R(`(() => { const s = ${S}; return { key: s._infoPanelKey, title: s._infoPanelTitle.text, skins: s._infoPanelSkins.visible, eff: s._infoPanelEffect.text, btn: s._upgradeBtn.labelText.text }; })()`);
  ok(st.key === 'ext_crystal' && /cristaux/i.test(st.title) && st.skins === false, 'panneau extracteur (sans lien Skins) : ' + JSON.stringify(st));
  ok(/0\.50 → 0\.61/.test(st.eff), 'effet extracteur : ' + st.eff);
  const rate0 = await R('NEBUSTION.Resources.rate("crystal")');
  await pressUpgrade();
  ok(await R('NEBUSTION.Resources.extractorLevel("crystal")') === 2, 'extracteur de cristaux → niveau 2');
  ok(await R('NEBUSTION.Resources.rate("crystal")') > rate0 * 1.1, 'production de cristaux augmentée');
  await sleep(300);
  ok(/Nv\.2/.test(await R(`${S}.nodes.crystal.label.text`)), 'étiquette du gisement : ' + await R(`${S}.nodes.crystal.label.text`));
  // un tap sur le gisement récolte toujours (la zone ▲ ne le bloque pas)
  const m0 = await R('NEBUSTION.Resources.get("metal")');
  await R(`${S}.nodes.metal.zone.emit('pointerdown', {})`);
  ok(await R('NEBUSTION.Resources.get("metal")') > m0 + 1, 'la récolte au tap fonctionne toujours');
  for (const id of ['metal', 'energy', 'core', 'dust']) {
    const a = await R(`(() => { const n = ${S}.nodes.${id}; const x = n.x + n.upArrow.x; return x >= 0 && x <= 720; })()`);
    ok(a, `flèche de ${id} dans l'écran`);
  }

  console.log('# Niveau maximum');
  await R(`NEBUSTION.Resources.state.buildings.hangar.level = NEBUSTION.Economy.CFG.MAX_LEVEL`);
  await tapBuilding('hangar'); await sleep(350);
  ok(/MAXIMUM/.test(await R(`${S}._upgradeBtn.labelText.text`)), 'bouton « NIVEAU MAXIMUM »');
  ok(await R(`NEBUSTION.Resources.upgradeBuilding('hangar').reason`) === 'max', 'refus au niveau max');
  await pressUpgrade();
  ok(await R('NEBUSTION.Resources.level("hangar")') === 50, 'niveau max inchangé');

  console.log('# Stockage (panneau Production)');
  await R(`${S}._hideInfoPanel()`);
  await give(6000);
  await R(`${S}.hud.togglePanel(true)`); await sleep(450);
  st = await R(`(() => { const h = ${S}.hud; return { title: h.stTitle.text, eff: h.stEffect.text, btn: h.stBtn.labelText.text }; })()`);
  ok(/Niv\. 1/.test(st.title) && /15K → 22\.5K/.test(st.eff), 'ligne Stockage : ' + JSON.stringify(st));
  ok(/Métal 500/.test(st.btn) && /Poussière 600/.test(st.btn), 'coût affiché : ' + st.btn);
  await R(`${S}.hud.stBtn.emit('pointerup', {})`); await sleep(300);
  ok(await R('NEBUSTION.Resources.level("storage")') === 2, 'Stockage → niveau 2');
  ok(await R('NEBUSTION.Resources.cap("crystal")') === 22500, 'capacité des cristaux ×1,5 = 22 500');
  ok(/amélioré/.test(await R(`${S}.hud.stBtn.labelText.text`)), 'retour visuel « Stockage amélioré »');
  await page.screenshot({ path: '/tmp/upgrade_hud.png' });
  await R(`${S}.hud.togglePanel(false)`); await sleep(400);

  console.log('# Persistance');
  await R(`NEBUSTION.Resources.saveNow()`);
  await page.goto('http://localhost:8766/index.html?debug=1');
  ok(await waitScene('MainMenuScene'), 'menu après rechargement');
  const lv = await R(`({ c: NEBUSTION.Resources.level('command'), s: NEBUSTION.Resources.level('storage'), x: NEBUSTION.Resources.extractorLevel('crystal') })`);
  ok(lv.c === 4 && lv.s === 2 && lv.x === 2, 'niveaux conservés après rechargement : ' + JSON.stringify(lv));
  ok(errors.length === 0, 'aucune erreur JS : ' + errors.join(' | '));

  await browser.close(); server.close();
  console.log('\n' + (failed ? '✘' : '✔') + ' TEST AMÉLIORATIONS : ' + passed + ' réussis, ' + failed + ' échoués');
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
