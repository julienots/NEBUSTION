/* Tests du module de données NEBUSTION.Equipment (Node, sans dépendance). Lancer : node tests/equipment.test.js */
'use strict';
global.window = global;
require('../js/data/Equipment.js');

const E = NEBUSTION.Equipment;
let passed = 0, failed = 0;
function ok(cond, msg) { if (cond) { passed++; } else { failed++; console.log('  ✗ ECHEC : ' + msg); } }
function section(t) { console.log('\n# ' + t); }

section('Structure générale');
{
  ok(E.SLOT_ORDER.length === 5, '5 emplacements définis');
  ok(E.RARITY_ORDER.length === 4, '4 raretés définies');
  E.SLOT_ORDER.forEach(s => ok(!!E.SLOTS[s], 'emplacement présent : ' + s));
  E.RARITY_ORDER.forEach(r => ok(!!E.RARITIES[r], 'rareté présente : ' + r));
}

section('bonusFor : croissance avec la rareté et le niveau');
{
  const commun1 = E.bonusFor('weapon', 'commun', 1);
  const rare1 = E.bonusFor('weapon', 'rare', 1);
  const commun5 = E.bonusFor('weapon', 'commun', 5);
  ok(commun1.atk > 0, 'bonus positif au niveau 1');
  ok(rare1.atk > commun1.atk, 'une rareté supérieure donne un bonus plus élevé');
  ok(commun5.atk > commun1.atk, 'un niveau supérieur donne un bonus plus élevé');
  const capped = E.bonusFor('weapon', 'commun', 999);
  const maxLvl = E.bonusFor('weapon', 'commun', E.MAX_LEVEL);
  ok(capped.atk === maxLvl.atk, 'le niveau est plafonné à MAX_LEVEL');
}

section('Coûts cohérents');
{
  const c1 = E.craftCost('armor', 'commun');
  const c2 = E.craftCost('armor', 'legendaire');
  ok(c2.metal > c1.metal, 'fabriquer un objet légendaire coûte plus cher qu\'un commun');
  const u1 = E.upgradeCost('rare', 1);
  const u5 = E.upgradeCost('rare', 5);
  ok(u5.metal > u1.metal, 'améliorer coûte plus cher à mesure que le niveau augmente');
  const refund = E.dismantleRefund('module', 'epique', 3);
  ok(refund.metal > 0 && refund.core > 0, 'le démantèlement rend des ressources');
}

section('normalizeState : robustesse');
{
  const empty = E.normalizeState(null);
  ok(Object.keys(empty.items).length === 0, 'état vide par défaut sans données');

  const raw = {
    nextSeq: 5,
    items: {
      eq1: { slot: 'weapon', rarity: 'rare', level: 3 },
      eq2: { slot: 'invalide', rarity: 'rare', level: 1 },      // emplacement invalide -> ignoré
      eq3: { slot: 'armor', rarity: 'inconnue', level: 1 },     // rareté invalide -> ignoré
      eq4: { slot: 'module', rarity: 'commun', level: 9999 }    // niveau hors bornes -> plafonné
    },
    equipped: {
      zyra: { weapon: 'eq1', armor: 'eq_absent' }               // référence vers un objet inexistant -> ignorée
    }
  };
  const s = E.normalizeState(raw);
  ok(Object.keys(s.items).length === 2, 'seuls les objets valides sont conservés (' + Object.keys(s.items).length + ')');
  ok(s.items.eq4.level === E.MAX_LEVEL, 'niveau plafonné à MAX_LEVEL');
  ok(s.equipped.zyra.weapon === 'eq1', 'référence valide conservée');
  ok(!s.equipped.zyra.armor, 'référence vers un objet inexistant supprimée');
  ok(s.nextSeq === 5, 'nextSeq conservé');
}

console.log('\n' + (failed === 0 ? '✓ TOUS LES TESTS SONT PASSÉS' : '✗ ÉCHECS DÉTECTÉS') + ' — ' + passed + ' réussis, ' + failed + ' échoués');
process.exit(failed === 0 ? 0 : 1);
