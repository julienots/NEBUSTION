/* NEBUSTION - tests SocialManager (faux Resources + faux Firestore).  node tests/social-manager.test.js */
global.window = global; global.NEBUSTION = {};
require('../js/data/Social.js');
var fails = 0, checks = 0; function ok(c, m) { checks++; if (!c) { fails++; console.log('ÉCHEC : ' + m); } }
// --- faux Resources
var res = { crystal: 5000, metal: 100, energy: 100, dust: 0, core: 0 };
NEBUSTION.Resources = { state: { buildings: { command: { level: 4 } } }, level: function () { return 4; }, canAfford: function (c) { return Object.keys(c).every(function (k) { return res[k] >= c[k]; }); },
  spend: function (k, n) { if (res[k] < n) return false; res[k] -= n; return true; }, add: function (k, n) { res[k] += n; return n; }, isFull: function () { return false; }, _dirtyNow: function () {} };
NEBUSTION.ShipManager = { fleetPower: function () { return 2000; } };
global.setTimeout = (function (o) { return function (f, ms) { return o(f, Math.min(ms || 0, 5)); }; })(global.setTimeout);
require('../js/systems/SocialManager.js'); var SM = NEBUSTION.SocialManager, SO = NEBUSTION.Social;
(async function () {
  ok(SM.me().level === 4 && SM.me().power === 2000, 'stats joueur'); ok(/^Commandant\d{3}$/.test(SM.state().name), 'pseudo par défaut : ' + SM.state().name);
  ok(!SM.setName('a').ok && SM.setName('Zeta_9').ok && SM.state().name === 'Zeta_9', 'pseudo');
  var L = await SM.listPlayers({}); ok(L.list.length === 160 && !L.realOk, 'liste = 160 bots hors compte'); ok(L.list[0].status === 'online' || L.list.every(function (p) { return p.status !== 'online'; }), 'en ligne d\'abord');
  var on = await SM.listPlayers({ filter: 'online' }); ok(on.list.every(function (p) { return p.status === 'online'; }), 'filtre en ligne');
  var b = L.list[0]; ok(SM.toggleFriend(b.id).friend && SM.isFriend(b.id), 'ami ajouté'); var fr = await SM.listPlayers({ filter: 'friends' }); ok(fr.list.length === 1, 'liste amis'); ok(!SM.toggleFriend(b.id).friend, 'ami retiré');
  var c0 = res.crystal, g = await SM.sendGift(b); ok(g.ok && res.crystal === c0 - 100 && SM.giftsLeft() === 4, 'cadeau bot'); for (var i = 0; i < 4; i++) await SM.sendGift(b); ok(!(await SM.sendGift(b)).ok && SM.giftsLeft() === 0, 'limite de cadeaux');
  SM._pending().forEach(function (p) { p.at = 0; }); ok(SM.inbox().length === SM._pending().length + SM.inbox().length && true, 'inbox lisible');
  var inb = SM.inbox(); if (inb.length) { var b0 = res.crystal, cl = SM.claimGift(inb[0].id); ok(cl.ok && res.crystal === b0 + inb[0].amount, 'cadeau reçu réclamé'); ok(!SM.claimGift(inb[0].id).ok, 'pas de double réclamation'); }
  var d = SM.duel(b); ok(d.ok && typeof d.win === 'boolean' && d.chance > 0, 'duel'); for (i = 0; i < 4; i++) SM.duel(b); ok(!SM.duel(b).ok && SM.duelsLeft() === 0, 'limite de duels');
  // clans de bots
  var CL = await SM.listClans(); ok(CL.list.length === 14, '14 clans de bots listés'); var cv = await SM.clanView(CL.list[0].id, true); ok(cv && cv.members.length >= 3, 'vue clan');
  cv.minLevel = 99; var r = await SM.joinClan(cv); ok(!r.ok && /Niveau/.test(r.error), 'niveau requis'); cv.minLevel = 1;
  r = await SM.joinClan(cv); ok(r.ok && SM.myClan().id === cv.id && SM.myClan().kind === 'bot', 'rejoindre clan bot'); ok(!(await SM.joinClan(cv)).ok, 'déjà dans un clan');
  ok(SM.chestReady(), 'coffre prêt'); var ch = SM.claimChest(cv.level); ok(ch.ok && !SM.chestReady() && !SM.claimChest(1).ok, 'coffre 1×/jour');
  var xp0 = res.crystal; r = await SM.donate(); ok(r.ok && res.crystal === xp0 - 500, 'don'); for (i = 0; i < 3; i++) await SM.donate(); ok(!(await SM.donate()).ok, 'limite de dons');
  var opts = SM.clanChatOpts(cv); ok(opts.pool.length === cv.members.length, 'chat de clan = membres du clan');
  ok((await SM.leaveClan()).ok && !SM.myClan(), 'quitter le clan');
  // chat local
  var last = null, w = SM.watchChat('global', {}, function (l) { last = l; }); await new Promise(function (r) { setTimeout(r, 20); }); ok(last && last.length > 3, 'chat général rempli (' + (last && last.length) + ')');
  var s1 = await w.send('salut tout le monde'); ok(s1.ok && last.some(function (m) { return m.mine; }), 'message envoyé'); ok(!(await w.send('encore')).ok, 'anti-spam'); await new Promise(function (r) { setTimeout(r, 30); });
  var repl = last.filter(function (m) { return m.isBot && m.t >= Date.now() - 2000; }); console.log('réponses de bots récentes :', repl.length); w.stop();
  // ---------- faux Firestore : vrais joueurs, clans, cadeaux, chat
  var store = { players: {}, clans: {}, gifts: {}, chat_global: {} }, listeners = [], idc = 0;
  function Snap(docs) { this.docs = docs; this.empty = !docs.length; } Snap.prototype.forEach = function (f) { this.docs.forEach(f); };
  function mkDoc(col, id) { var self = { id: id, ref: { delete: function () { delete store[col][id]; return Promise.resolve(); } }, exists: !!store[col][id], data: function () { return JSON.parse(JSON.stringify(store[col][id])); } }; return self; }
  function Q(col, docs) { this.col = col; this.docs = docs; }
  Q.prototype.orderBy = function (k, dir) { var d = this.docs.slice().sort(function (a, b) { return dir === 'desc' ? (b[1][k] || 0) - (a[1][k] || 0) : (a[1][k] || 0) - (b[1][k] || 0); }); return new Q(this.col, d); };
  Q.prototype.limit = function (n) { return new Q(this.col, this.docs.slice(0, n)); };
  Q.prototype.where = function (k, op, v) { return new Q(this.col, this.docs.filter(function (d) { return d[1][k] === v; })); };
  Q.prototype.get = function () { var c = this.col; return Promise.resolve(new Snap(this.docs.map(function (d) { return mkDoc(c, d[0]); }))); };
  Q.prototype.onSnapshot = function (f) { var self = this, c = this.col; var fn = function () { f(new Snap(Object.keys(store[c]).map(function (id) { return mkDoc(c, id); }))); }; listeners.push(fn); setTimeout(fn, 0); return function () {}; };
  function col(name) { var q = new Q(name, Object.keys(store[name]).map(function (id) { return [id, store[name][id]]; }));
    var o = Object.create(q); o.add = function (x) { var id = 'id' + (++idc); store[name][id] = JSON.parse(JSON.stringify(x)); listeners.forEach(function (f) { f(); }); return Promise.resolve({ id: id }); };
    o.doc = function (id) { id = id || 'a' + (++idc); return { id: id, collection: function (s) { store[name + '/' + id + '/' + s] = store[name + '/' + id + '/' + s] || {}; return col(name + '/' + id + '/' + s); },
      set: function (x) { store[name][id] = JSON.parse(JSON.stringify(x)); return Promise.resolve(); }, update: function (x) { var d = store[name][id]; Object.keys(x).forEach(function (k) { d[k] = (x[k] && x[k].__inc) ? (d[k] || 0) + x[k].__inc : x[k]; }); return Promise.resolve(); },
      get: function () { return Promise.resolve(mkDoc(name, id)); }, delete: function () { delete store[name][id]; return Promise.resolve(); } }; };
    return o; }
  var fakeDb = { collection: function (n) { store[n] = store[n] || {}; return col(n); }, runTransaction: function (fn) { var tx = { get: function (ref) { return ref.get(); }, update: function (ref, x) { ref.update(x); }, delete: function (ref) { ref.delete(); }, set: function (ref, x) { ref.set(x); } }; return fn(tx); } };
  global.firebase = { firestore: { FieldValue: { increment: function (n) { return { __inc: n }; } } } };
  NEBUSTION.CloudSave = { getDb: function () { return fakeDb; }, currentUser: function () { return { uid: 'me1', email: 'a@b.c' }; }, _deviceId: function () { return 'dev'; } };
  store.players.u9 = { uid: 'u9', name: 'VraiJoueur', level: 7, power: 4000, clanId: '', clanTag: '', updatedAt: Date.now() - 10000 };
  store.players.u8 = { uid: 'u8', name: 'Ancien', level: 3, power: 900, updatedAt: Date.now() - 3600000 };
  ok(SM.online(), 'en ligne (faux Firebase)'); await SM.publishProfile(true); ok(store.players.me1 && store.players.me1.name === 'Zeta_9' && store.players.me1.power === 2000, 'profil publié');
  var L2 = await SM.listPlayers({}); ok(L2.realOk && L2.realCount === 2, 'vrais joueurs listés (sans moi)'); ok(L2.list[0].uid === 'u9' && L2.list[0].status === 'online' && !L2.list[0].isBot, 'vrai joueur en ligne en tête'); ok(L2.list.some(function (p) { return p.uid === 'u8' && p.status === 'offline'; }), 'vrai joueur hors ligne');
  var rp = await SM.playerById('u9'); ok(rp && rp.name === 'VraiJoueur', 'fiche vrai joueur');
  res.crystal = 5000; SM.state().gifts = { day: 0, n: 0 }; var gg = await SM.sendGift(rp); ok(gg.ok && Object.keys(store.gifts).length === 1 && store.gifts[Object.keys(store.gifts)[0]].to === 'u9', 'cadeau réel écrit');
  store.gifts.gx = { to: 'me1', from: 'u9', fromName: 'VraiJoueur', amount: 100, t: Date.now() }; store.gifts.gy = { to: 'other', from: 'u9', amount: 100 };
  var n = await SM.pullRealGifts(); ok(n === 1 && !store.gifts.gx && store.gifts.gy, 'cadeau reçu puis supprimé, ceux des autres intacts'); var rg = SM.inbox().filter(function (m) { return m.real; }); ok(rg.length === 1 && rg[0].amount === 100, 'cadeau réel en boîte');
  // clan réel
  res.crystal = 5000; r = await SM.createClan('Les Testeurs', 'tst', 'go'); ok(r.ok && SM.myClan().kind === 'real' && res.crystal === 3000, 'clan créé (coût débité)'); var cid = r.id; ok(store.clans[cid].members.length === 1 && store.clans[cid].leader === 'me1', 'clan en base');
  ok((await SM.leaveClan()).ok && !store.clans[cid], 'dernier membre part → clan supprimé');
  ok(!(await SM.createClan('X', 'TS', '')).ok && !(await SM.createClan('Nom valide', 'toolong', '')).ok, 'validation création');
  store.clans.k1 = { name: 'Clan Réel', tag: 'CRL', motto: 'hey', color: 255, leader: 'u9', open: true, minLevel: 1, xp: 5000, members: [{ uid: 'u9', name: 'VraiJoueur', power: 4000, level: 7, role: 'leader' }], memberUids: ['u9'] };
  var CL2 = await SM.listClans(); ok(CL2.realOk && CL2.list[0].id === 'k1' && !CL2.list[0].isBot && CL2.list.length === 15, 'clan réel en tête de liste');
  var kv = await SM.clanView('k1', false); ok(kv && kv.members.length === 1 && kv.level >= 3, 'vue clan réel'); r = await SM.joinClan(kv); ok(r.ok && store.clans.k1.members.length === 2 && SM.myClan().kind === 'real', 'rejoindre clan réel');
  SM.state().donate = { day: 0, n: 0 }; r = await SM.donate(); ok(r.ok && store.clans.k1.xp === 5050, 'don → xp du clan réel'); SM.state().lastChest = 0; ok(SM.claimChest(kv.level).ok, 'coffre clan réel');
  ok((await SM.leaveClan()).ok && store.clans.k1.members.length === 1 && store.clans.k1.leader === 'u9', 'quitter clan réel');
  // chat réel
  var got = null, w2 = SM.watchChat('global', {}, function (l) { got = l; }); await new Promise(function (r) { setTimeout(r, 20); });
  SM._resetThrottle(); var s2 = await w2.send('bonjour depuis le vrai chat'); ok(s2.ok && Object.keys(store.chat_global).length === 1, 'message réel écrit'); await new Promise(function (r) { setTimeout(r, 20); });
  ok(got.some(function (m) { return m.real && m.text === 'bonjour depuis le vrai chat'; }), 'message réel relu'); w2.stop();
  function lastSendReset() {}
  // erreur de règles
  var bad = { collection: function () { var e = { code: 'permission-denied' }; var q = { orderBy: function () { return q; }, limit: function () { return q; }, get: function () { return Promise.reject(e); } }; return q; } };
  NEBUSTION.CloudSave.getDb = function () { return bad; }; var L3 = await SM.listPlayers({}); ok(!L3.realOk && /Règles/.test(L3.realError) && L3.list.length === 160, 'règles absentes → bots seuls + message');
  console.log(checks + ' vérifications, ' + fails + ' échec(s)'); process.exit(fails ? 1 : 0);
})().catch(function (e) { console.log('EXCEPTION', e && e.stack || e); process.exit(2); });
