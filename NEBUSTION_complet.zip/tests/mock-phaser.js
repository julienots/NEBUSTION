/*
 * FAUX Phaser 3 — uniquement pour le test de fumée (tests/browser-smoke.js).
 * Il implémente un sous-ensemble strict de l'API : un appel à une méthode absente lève une erreur,
 * ce qui détecte les fautes de frappe et les méthodes inexistantes. Il NE remplace PAS un vrai test avec Phaser
 * (rendu, WebGL, physique des tweens/particules réels ne sont pas simulés).
 */
(function () {
  var Ease = function () {};
  function Emitter() { this._l = {}; }
  Emitter.prototype.on = function (e, f, ctx) { (this._l[e] = this._l[e] || []).push({ f: f, once: false, ctx: ctx }); return this; };
  Emitter.prototype.once = function (e, f, ctx) { (this._l[e] = this._l[e] || []).push({ f: f, once: true, ctx: ctx }); return this; };
  Emitter.prototype.off = function (e, f) { var a = this._l[e]; if (!a) return this; this._l[e] = a.filter(function (x) { return x.f !== f; }); return this; };
  Emitter.prototype.emit = function (e) {
    var a = this._l[e]; if (!a) return false; var args = [].slice.call(arguments, 1);
    a.slice().forEach(function (x) { if (x.once) Emitter.prototype.off.call(this, e, x.f); x.f.apply(x.ctx || null, args); }, this);
    return true;
  };

  var registry = { interactives: [], created: 0 };

  function GO(scene, x, y) {
    Emitter.call(this);
    this.scene = scene; this.x = x || 0; this.y = y || 0; this.active = true; this.depth = 0; this.alpha = 1;
    this.scale = 1; this.scaleX = 1; this.scaleY = 1; this.angle = 0; this.rotation = 0; this.visible = true;
    this.width = 0; this.height = 0; this.list = []; this.parentContainer = null; this._interactive = false;
    registry.created++;
    if (scene && scene._display) scene._display.push(this);
  }
  GO.prototype = Object.create(Emitter.prototype);
  ['setOrigin', 'setDepth', 'setAlpha', 'setTint', 'setBlendMode', 'setColor', 'setShadow', 'setStroke', 'setFontSize',
    'setVisible', 'setName', 'setStrokeStyle', 'setFillStyle', 'setActive', 'setTexture', 'setFlipX'].forEach(function (m) {
    GO.prototype[m] = function (a) {
      if (m === 'setDepth') this.depth = a; if (m === 'setAlpha') this.alpha = a; if (m === 'setVisible') this.visible = a;
      if (m === 'setFillStyle' || m === 'setStrokeStyle') return this;
      return this;
    };
  });
  ['setTintFill', 'clearTint', 'setCrop', 'setMask', 'setScrollFactor', 'setOrigin', 'setShadow', 'setWordWrapWidth'].forEach(function (m) { GO.prototype[m] = function () { return this; }; });
  GO.prototype.createGeometryMask = function () { return {}; };
  GO.prototype.setOrigin = function (x, y) { this.originX = x; this.originY = (y === undefined ? x : y); return this; };
  GO.prototype.setTint = function (c) { this.tint = c; return this; };
  GO.prototype.setBlendMode = function (m) { this.blend = m; return this; };
  GO.prototype.setScale = function (x, y) { this.scale = x; this.scaleX = x; this.scaleY = y === undefined ? x : y; return this; };
  GO.prototype.setPosition = function (x, y) { this.x = x; this.y = y; return this; };
  GO.prototype.setAngle = function (a) { this.angle = a; return this; };
  GO.prototype.setRotation = function (a) { this.rotation = a; return this; };
  GO.prototype.setSize = function (w, h) { this.width = w; this.height = h; return this; };
  GO.prototype.setDisplaySize = function (w, h) { this.displayWidth = w; this.displayHeight = h; return this; };
  GO.prototype.setInteractive = function (cfg) {
    this._interactive = true; registry.interactives.push(this);
    if (!this.input) this.input = { cursor: null };
    return this;
  };
  GO.prototype.disableInteractive = function () {
    this._interactive = false;
    var k = registry.interactives.indexOf(this); if (k >= 0) registry.interactives.splice(k, 1);
    return this;
  };
  GO.prototype.destroy = function () {
    if (!this.active) return; this.active = false;
    this.list.slice().forEach(function (c) { if (c.destroy) c.destroy(); });
    if (this.parentContainer) { var i = this.parentContainer.list.indexOf(this); if (i >= 0) this.parentContainer.list.splice(i, 1); }
    var k = registry.interactives.indexOf(this); if (k >= 0) registry.interactives.splice(k, 1);
    if (this.scene && this.scene._display) { var d = this.scene._display.indexOf(this); if (d >= 0) this.scene._display.splice(d, 1); }
    this._l = {};
  };
  Object.defineProperty(GO.prototype, 'displayWidth', { get: function () { return this._dw !== undefined ? this._dw : this.width * this.scaleX; }, set: function (v) { this._dw = v; } });
  Object.defineProperty(GO.prototype, 'displayHeight', { get: function () { return this._dh !== undefined ? this._dh : this.height * this.scaleY; }, set: function (v) { this._dh = v; } });

  function Container(scene, x, y, children) { GO.call(this, scene, x, y); var self = this; (children || []).forEach(function (c) { self.add(c); }); }
  Container.prototype = Object.create(GO.prototype);
  Container.prototype.add = function (c) {
    var self = this;
    (Array.isArray(c) ? c : [c]).forEach(function (o) { if (o.parentContainer) { var i = o.parentContainer.list.indexOf(o); if (i >= 0) o.parentContainer.list.splice(i, 1); } o.parentContainer = self; self.list.push(o); });
    return this;
  };
  Container.prototype.addAt = function (c, idx) {
    if (c.parentContainer) { var i = c.parentContainer.list.indexOf(c); if (i >= 0) c.parentContainer.list.splice(i, 1); }
    c.parentContainer = this; this.list.splice(Math.max(0, Math.min(idx || 0, this.list.length)), 0, c); return this;
  };
  Container.prototype.sort = function () { return this; };
  Container.prototype.getIndex = function (c) { return this.list.indexOf(c); };
  Container.prototype.removeAll = function (destroy) {
    this.list.slice().forEach(function (o) { o.parentContainer = null; if (destroy && o.destroy) o.destroy(); });
    this.list = []; return this;
  };
  Container.prototype.setInteractive = function (cfg) { if (cfg && cfg.hitArea && !Phaser.Geom.Rectangle.Contains) throw new Error('hitAreaCallback'); return GO.prototype.setInteractive.call(this, cfg); };

  function Text(scene, x, y, text, style) { GO.call(this, scene, x, y); this.style = style || {}; this.originX = 0; this.originY = 0; this.setText(text); }
  Text.prototype = Object.create(GO.prototype);
  Text.prototype.setText = function (t) {
    this.text = String(t === undefined ? '' : t);
    var fs = parseFloat((this.style && this.style.fontSize) || 16) || 16;
    this.width = this.text.length * fs * 0.56; this.height = fs * 1.2; return this;
  };
  Text.prototype.setColor = function (c) { this.style.color = c; return this; };
  Text.prototype.setFontSize = function (s) { this.style.fontSize = s; return this.setText(this.text); };

  function Graphics(scene) { GO.call(this, scene, 0, 0); this._cmds = []; }
  Graphics.prototype = Object.create(GO.prototype);
  ['clear', 'fillStyle', 'lineStyle', 'fillRect', 'strokeRect', 'fillRoundedRect', 'strokeRoundedRect', 'fillCircle', 'strokeCircle',
    'fillEllipse', 'strokeEllipse', 'lineBetween', 'fillPoints', 'strokePoints', 'fillGradientStyle', 'fillTriangle', 'strokeTriangle', 'beginPath', 'closePath', 'arc', 'strokePath', 'fillPath', 'moveTo', 'lineTo'
  ].forEach(function (m) { Graphics.prototype[m] = function () {
    for (var i = 0; i < arguments.length; i++) { if (typeof arguments[i] === 'number' && !isFinite(arguments[i])) throw new Error('Graphics.' + m + ' reçoit NaN/Infinity'); }
    if (m === 'clear') this._cmds = []; else if (this._cmds.length < 400) this._cmds.push([m].concat([].slice.call(arguments)));
    return this; }; });

  Graphics.prototype.generateTexture = function (k, w, h) { if (!(w > 0 && h > 0)) throw new Error('generateTexture taille invalide'); this.scene.textures._map[k] = { width: w, height: h }; return this; };

  function Image(scene, x, y, key) {
    GO.call(this, scene, x, y); this.textureKey = key; this.originX = 0.5; this.originY = 0.5;
    if (key && !scene.textures.exists(key)) throw new Error('Texture inconnue : ' + key);
    var t = scene.textures._map[key]; if (t) { this.width = t.width; this.height = t.height; }
  }
  Image.prototype = Object.create(GO.prototype);
  function TileSprite(scene, x, y, w, h, key) { Image.call(this, scene, x, y, key); this.width = w; this.height = h; this.tileW = w; this.tileH = h; this.tilePositionX = 0; this.tilePositionY = 0; }
  TileSprite.prototype = Object.create(Image.prototype);
  function Zone(scene, x, y, w, h) { GO.call(this, scene, x, y); this.width = w; this.height = h; }
  Zone.prototype = Object.create(GO.prototype);
  function Shape(scene, x, y, w, h, color, alpha) { GO.call(this, scene, x, y); this.width = w || 0; this.height = h || 0; this.fillColor = color; this.fillAlpha = alpha === undefined ? 1 : alpha; this.originX = 0.5; this.originY = 0.5; }
  Shape.prototype = Object.create(GO.prototype);
  function Particles(scene, x, y, key, cfg) {
    GO.call(this, scene, x, y);
    if (!scene.textures.exists(key)) throw new Error('Texture particules inconnue : ' + key);
    this.emitted = 0;
  }
  Particles.prototype = Object.create(GO.prototype);
  Particles.prototype.explode = function (n, x, y) { if (!isFinite(n) || !isFinite(x) || !isFinite(y)) throw new Error('explode NaN'); this.emitted += n; return this; };
  Particles.prototype.emitParticleAt = function (x, y, n) { if (!isFinite(x) || !isFinite(y)) throw new Error('emitParticleAt NaN'); this.emitted += n || 1; return this; };

  // ----- Tweens / temps -----
  function Tweens(scene) { this.scene = scene; this.list = []; this.timeScale = 1; }
  Tweens.prototype.add = function (cfg) {
    var targets = Array.isArray(cfg.targets) ? cfg.targets : [cfg.targets];
    var props = {};
    Object.keys(cfg).forEach(function (k) {
      if (['targets', 'duration', 'delay', 'yoyo', 'repeat', 'ease', 'onComplete', 'onUpdate', 'hold', 'repeatDelay'].indexOf(k) < 0) props[k] = cfg[k];
    });
    targets.forEach(function (t) { if (!t) throw new Error('Tween sur une cible null'); });
    Object.keys(props).forEach(function (k) { if (typeof props[k] !== 'number' || !isFinite(props[k])) throw new Error('Tween ' + k + ' invalide : ' + props[k]); });
    var tw = { targets: targets, props: props, from: null, dur: Math.max(1, cfg.duration || 1000), delay: cfg.delay || 0, yoyo: !!cfg.yoyo, repeat: cfg.repeat || 0, t: 0, dir: 1, cfg: cfg, done: false, stop: function () { this.done = true; } };
    this.list.push(tw); return tw;
  };
  Tweens.prototype.addCounter = function (cfg) {
    var tw = { counter: true, value: cfg.from || 0, from: cfg.from || 0, to: cfg.to === undefined ? 1 : cfg.to, dur: Math.max(1, cfg.duration || 1000), delay: 0, yoyo: false, repeat: 0, t: 0, dir: 1, cfg: cfg, done: false, getValue: function () { return this.value; } };
    this.list.push(tw); return tw;
  };
  Tweens.prototype.killTweensOf = function (targets) {
    var arr = Array.isArray(targets) ? targets : [targets];
    this.list.forEach(function (tw) { if (tw.targets && tw.targets.some(function (t) { return arr.indexOf(t) >= 0; })) tw.done = true; });
  };
  Tweens.prototype.update = function (dt) {
    dt = dt * this.timeScale;
    this.list.slice().forEach(function (tw) {
      if (tw.done) return;
      if (tw.targets && tw.targets.every(function (t) { return !t.active && t.active !== undefined && t.destroy; })) { tw.done = true; return; }
      if (tw.delay > 0) { tw.delay -= dt; if (tw.delay > 0) return; dt = -tw.delay; tw.delay = 0; }
      if (!tw.from && !tw.counter) { tw.from = {}; tw.targets.forEach(function (t, i) { tw.from[i] = {}; Object.keys(tw.props).forEach(function (k) { tw.from[i][k] = t[k]; }); }); }
      tw.t += dt * tw.dir;
      var end = false;
      if (tw.t >= tw.dur) { if (tw.yoyo) { tw.t = tw.dur; tw.dir = -1; } else if (tw.repeat !== 0) { tw.t = 0; if (tw.repeat > 0) tw.repeat--; } else { tw.t = tw.dur; end = true; } }
      else if (tw.t <= 0 && tw.dir === -1) { if (tw.repeat === 0) { tw.t = 0; end = true; } else { tw.t = 0; tw.dir = 1; if (tw.repeat > 0) tw.repeat--; } }
      var k = Math.min(1, Math.max(0, tw.t / tw.dur));
      if (tw.counter) { tw.value = tw.from + (tw.to - tw.from) * k; if (tw.cfg.onUpdate) tw.cfg.onUpdate(tw); }
      else tw.targets.forEach(function (t, i) { Object.keys(tw.props).forEach(function (p) { var v = tw.from[i][p] + (tw.props[p] - tw.from[i][p]) * k; if (p === 'scale') { t.scale = v; t.scaleX = v; t.scaleY = v; } else t[p] = v; }); if (tw.cfg.onUpdate) tw.cfg.onUpdate(tw, t); });
      if (end) { tw.done = true; if (tw.cfg.onComplete) tw.cfg.onComplete(tw, tw.targets); }
    });
    this.list = this.list.filter(function (t) { return !t.done; });
  };

  function Time(scene) { this.scene = scene; this.events = []; this.timeScale = 1; this.now = 0; }
  Time.prototype.delayedCall = function (ms, fn) { var ev = { left: ms, fn: fn, loop: false, delay: ms }; this.events.push(ev); ev.remove = function () { ev.dead = true; }; return ev; };
  Time.prototype.addEvent = function (cfg) { var ev = { left: cfg.delay, fn: cfg.callback, loop: !!cfg.loop, delay: cfg.delay }; ev.remove = function () { ev.dead = true; }; this.events.push(ev); return ev; };
  Time.prototype.update = function (dt) {
    this.now += dt; dt = dt * this.timeScale;
    this.events.slice().forEach(function (ev) {
      if (ev.dead) return; ev.left -= dt;
      if (ev.left <= 0) { ev.fn(); if (ev.loop) ev.left += ev.delay; else ev.dead = true; }
    });
    this.events = this.events.filter(function (e) { return !e.dead; });
  };

  function Camera(scene) { Emitter.call(this); this.scene = scene; }
  Camera.prototype = Object.create(Emitter.prototype);
  Camera.prototype.setBackgroundColor = function () { return this; };
  Camera.prototype.fadeIn = function () { return this; };
  Camera.prototype.shake = function () { return this; };
  Camera.prototype.flash = function () { return this; };
  Camera.prototype.fadeOut = function (d) { var self = this; this.scene.time.delayedCall(d || 0, function () { self.emit('camerafadeoutcomplete'); }); return this; };

  // ----- Scene / Game -----
  function Scene(key) { Emitter.call(this); this.key = key; }
  Scene.prototype = Object.create(Emitter.prototype);

  var Phaser = {
    AUTO: 0, Scene: Scene,
    Scale: { FIT: 1, CENTER_BOTH: 2 },
    BlendModes: { ADD: 1 },
    GameObjects: { Container: Container },
    Math: {
      Between: function (a, b) { return Math.floor(a + Math.random() * (b - a + 1)); },
      Clamp: function (v, a, b) { return Math.min(b, Math.max(a, v)); }
    },
    Utils: { Array: { GetRandom: function (a) { return a[Math.floor(Math.random() * a.length)]; } } },
    Geom: {
      Rectangle: Object.assign(function (x, y, w, h) { this.x = x; this.y = y; this.width = w; this.height = h; }, { Contains: function () { return true; } }),
      Circle: function (x, y, r) { this.x = x; this.y = y; this.radius = r; }
    },
    Display: { Color: { HexStringToColor: function (h) { return { color: parseInt(String(h).replace('#', ''), 16) }; },
      // HSV → RGB (mêmes conventions que Phaser : h, s, v ∈ [0,1] ; renvoie { r, g, b, color })
      HSVToRGB: function (h, s, v) {
        h = ((h % 1) + 1) % 1; var i = Math.floor(h * 6), f = h * 6 - i, p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s), r, g, b;
        switch (i % 6) { case 0: r = v; g = t; b = p; break; case 1: r = q; g = v; b = p; break; case 2: r = p; g = v; b = t; break; case 3: r = p; g = q; b = v; break; case 4: r = t; g = p; b = v; break; default: r = v; g = p; b = q; }
        r = Math.round(r * 255); g = Math.round(g * 255); b = Math.round(b * 255);
        return { r: r, g: g, b: b, color: (r << 16) | (g << 8) | b };
      } } },
    Core: { Events: { STEP: 'step' } },
    _registry: registry
  };

  Phaser.Game = function (config) {
    var game = this; this.config = config; this.events = new Emitter(); this.scale = { refresh: function () {}, width: 720, height: 1280 };
    this.scenes = {}; this.active = {}; this._t = 0;
    var mgr = {
      scenes: [],
      isActive: function (k) { return !!game.active[k]; },
      getScene: function (k) { return game.scenes[k]; },
      start: null
    };
    this.scene = mgr;
    config.scene.forEach(function (Cls) {
      var s = new Cls(); var key = s.key;
      s.game = game; s.events = new Emitter(); s.tweens = new Tweens(s); s.time = new Time(s); s.cameras = { main: new Camera(s) };
      s.input = new Emitter(); s.scale = { width: 720, height: 1280 }; s._display = [];
      s.textures = game.textures;
      s.scene = { start: function (k, d) { game._start(s, k, d); }, restart: function (d) { game._start(s, s.key, d); }, isActive: mgr.isActive };
      var add = {};
      add.text = function (x, y, t, st) { return new Text(s, x, y, t, st); };
      add.graphics = function () { return new Graphics(s); };
      add.image = function (x, y, k) { return new Image(s, x, y, k); };
      add.tileSprite = function (x, y, w, h, k) { return new TileSprite(s, x, y, w, h, k); };
      add.container = function (x, y, ch) { return new Container(s, x, y, ch); };
      add.zone = function (x, y, w, h) { return new Zone(s, x, y, w, h); };
      add.circle = function (x, y, r) { var sh = new Shape(s, x, y, r * 2, r * 2); sh.isCircle = true; return sh; };
      add.rectangle = function (x, y, w, h, c, a) { return new Shape(s, x, y, w, h, c, a); };
      add.ellipse = function (x, y, w, h) { return new Shape(s, x, y, w, h); };
      add.particles = function (x, y, k, c) { return new Particles(s, x, y, k, c); };
      add.existing = function (o) { return o; };
      s.add = add;
      s.make = { graphics: function () { return new Graphics(s); } };
      s.load = (function () {
        var q = [], em = new Emitter();
        return {
          image: function (k) { q.push(k); },
          on: function (e, f) { em.on(e, f); }, once: function (e, f) { em.once(e, f); }, off: function (e, f) { em.off(e, f); },
          start: function () { var keys = q.splice(0); setTimeout(function () { keys.forEach(function (k) { em.emit('loaderror', { key: k }); }); em.emit('complete'); }, 0); }
        };
      })();
      game.scenes[key] = s; mgr.scenes.push(s);
    });
    var tex = { _map: {}, exists: function (k) { return !!tex._map[k]; }, remove: function (k) { delete tex._map[k]; }, createCanvas: function (k, w, h) {
      if (tex._map[k]) throw new Error('Texture déjà existante : ' + k);
      var cv = document.createElement('canvas'); cv.width = w; cv.height = h;
      var t = { width: w, height: h, canvas: cv, context: cv.getContext('2d'), refresh: function () {} }; tex._map[k] = t; return t; } };
    this.textures = tex;
    mgr.scenes.forEach(function (s) { s.textures = tex; });

    this._start = function (from, key, data) {
      if (from && game.active[from.key]) { delete game.active[from.key]; from.events.emit('shutdown'); from._display.slice().forEach(function (o) { o.destroy(); }); from.tweens.list = []; from.time.events = []; from.input._l = {}; }
      var s = game.scenes[key]; if (!s) throw new Error('Scène inconnue : ' + key);
      game.active[key] = true; s.tweens.list = []; s.time.events = [];
      if (s.init) s.init(data); s.create(data);
    };
    setTimeout(function () { game._start(null, config.scene[0].name ? game.scenes.BootScene.key : 'BootScene'); }, 0);
    var last = performance.now();
    this._loop = setInterval(function () {
      var now = performance.now(), dt = Math.min(100, now - last); last = now; game._t += dt;
      game.events.emit('step', game._t, dt);
      Object.keys(game.active).forEach(function (k) {
        var s = game.scenes[k]; s.tweens.update(dt); s.time.update(dt);
        s.events.emit('update', game._t, dt); if (s.update) s.update(game._t, dt);
      });
    }, 16);
  };

  // ----- Rendu de débogage (mise en page uniquement) : dessine la scène sur un canvas 2D. -----
  function hex(c) { return '#' + ('000000' + (c >>> 0).toString(16)).slice(-6); }
  Phaser._render = function (scene, ctx, W, H) {
    ctx.save(); ctx.fillStyle = '#05070f'; ctx.fillRect(0, 0, W, H);
    var tops = scene._display.filter(function (o) { return !o.parentContainer && o.active !== false; });
    tops.forEach(function (o, i) { o.__ord = i; });
    tops.sort(function (a, b) { return (a.depth - b.depth) || (a.__ord - b.__ord); });
    tops.forEach(function (o) { drawObj(ctx, o, 1); });
    ctx.restore();
  };
  function drawObj(ctx, o, parentAlpha) {
    if (o.visible === false) return;
    var a = parentAlpha * (o.alpha === undefined ? 1 : o.alpha);
    if (a <= 0.005) return;
    ctx.save();
    ctx.translate(o.x, o.y);
    if (o.angle) ctx.rotate(o.angle * Math.PI / 180);
    ctx.scale(o.scaleX === undefined ? 1 : o.scaleX, o.scaleY === undefined ? 1 : o.scaleY);
    ctx.globalAlpha = Math.min(1, a);
    if (o.blend === 1) ctx.globalCompositeOperation = 'lighter';
    if (o instanceof Container) {
      o.list.forEach(function (c) { drawObj(ctx, c, a); });
    } else if (o instanceof Graphics) {
      replay(ctx, o._cmds);
    } else if (o instanceof Text) {
      var fs = parseFloat(o.style.fontSize || 16) || 16;
      ctx.font = (o.style.fontStyle === '900' || o.style.fontStyle === 'bold' ? 'bold ' : '') + fs + 'px Arial';
      var lines = String(o.text).split('\n'), lh = fs * 1.2;
      var maxW = o.style.wordWrap && o.style.wordWrap.width;
      var wrapped = [];
      lines.forEach(function (ln) {
        if (!maxW) { wrapped.push(ln); return; }
        var words = ln.split(' '), cur = '';
        words.forEach(function (w) { var t = cur ? cur + ' ' + w : w; if (ctx.measureText(t).width > maxW && cur) { wrapped.push(cur); cur = w; } else cur = t; });
        wrapped.push(cur);
      });
      var tw = 0; wrapped.forEach(function (l) { tw = Math.max(tw, ctx.measureText(l).width); });
      var th = wrapped.length * lh, ox = o.originX * tw, oy = o.originY * th;
      ctx.textBaseline = 'top';
      wrapped.forEach(function (l, i) {
        var w = ctx.measureText(l).width, x = -ox + (o.style.align === 'center' ? (tw - w) / 2 : (o.style.align === 'right' ? tw - w : 0));
        if (o.style.stroke) { ctx.lineWidth = o.style.strokeThickness || 2; ctx.strokeStyle = o.style.stroke; ctx.lineJoin = 'round'; ctx.strokeText(l, x, -oy + i * lh); }
        ctx.fillStyle = o.style.color || '#fff'; ctx.fillText(l, x, -oy + i * lh);
      });
    } else if (o instanceof Image) {
      var t = o.scene.textures._map[o.textureKey];
      if (t) {
        var w = o.displayWidth !== undefined ? o.displayWidth / (o.scaleX || 1) : t.width, h = o.displayHeight !== undefined ? o.displayHeight / (o.scaleY || 1) : t.height;
        if (o.tileW) { ctx.fillStyle = ctx.createPattern(t.canvas, 'repeat'); ctx.fillRect(0, 0, o.tileW, o.tileH); }
        else ctx.drawImage(t.canvas, -w * o.originX, -h * o.originY, w, h);
      }
    } else if (o instanceof Shape && o.fillColor !== undefined) {
      ctx.fillStyle = hex(o.fillColor);
      if (o.isCircle) { ctx.beginPath(); ctx.arc(0, 0, o.width / 2, 0, 6.2832); ctx.fill(); }
      else ctx.fillRect(-o.width * o.originX, -o.height * o.originY, o.width, o.height);
    }
    ctx.restore();
  }
  function rr(ctx, x, y, w, h, r) {
    r = Math.min(r || 0, Math.abs(w) / 2, Math.abs(h) / 2);
    ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  function replay(ctx, cmds) {
    var fill = '#fff', fa = 1, lw = 1, lc = '#fff', la = 1, grad = null;
    var F = function () { ctx.globalAlpha = Math.min(1, fa * ctx.__base); ctx.fillStyle = grad || fill; };
    ctx.__base = ctx.globalAlpha;
    var base = ctx.globalAlpha;
    cmds.forEach(function (c) {
      var m = c[0], x = c[1], y = c[2], w = c[3], h = c[4];
      if (m === 'fillStyle') { fill = hex(c[1]); fa = c[2] === undefined ? 1 : c[2]; grad = null; }
      else if (m === 'fillGradientStyle') { grad = { tl: c[1], bl: c[3], a: c[5] === undefined ? 1 : c[5] }; }
      else if (m === 'lineStyle') { lw = c[1]; lc = hex(c[2]); la = c[3] === undefined ? 1 : c[3]; }
      else if (/^fill/.test(m) || /^stroke/.test(m)) {
        var isFill = /^fill/.test(m);
        ctx.globalAlpha = Math.min(1, (isFill ? (grad ? grad.a : fa) : la) * base);
        if (isFill) {
          if (grad && (m === 'fillRoundedRect' || m === 'fillRect')) { var g = ctx.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, hex(grad.tl)); g.addColorStop(1, hex(grad.bl)); ctx.fillStyle = g; }
          else ctx.fillStyle = fill;
        } else { ctx.strokeStyle = lc; ctx.lineWidth = lw; }
        var op = isFill ? 'fill' : 'stroke';
        if (/RoundedRect$/.test(m)) { rr(ctx, x, y, w, h, typeof c[5] === 'number' ? c[5] : 8); ctx[op](); }
        else if (/Rect$/.test(m)) { ctx.beginPath(); ctx.rect(x, y, w, h); ctx[op](); }
        else if (/Circle$/.test(m)) { ctx.beginPath(); ctx.arc(x, y, w, 0, 6.2832); ctx[op](); }
        else if (/Ellipse$/.test(m)) { ctx.beginPath(); ctx.ellipse(x, y, w / 2, h / 2, 0, 0, 6.2832); ctx[op](); }
        else if (/Triangle$/.test(m)) { ctx.beginPath(); ctx.moveTo(c[1], c[2]); ctx.lineTo(c[3], c[4]); ctx.lineTo(c[5], c[6]); ctx.closePath(); ctx[op](); }
      } else if (m === 'lineBetween') { ctx.globalAlpha = Math.min(1, la * base); ctx.strokeStyle = lc; ctx.lineWidth = lw; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(w, h); ctx.stroke(); }
    });
    ctx.globalAlpha = base;
  }
  window.Phaser = Phaser;
})();
