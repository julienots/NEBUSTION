global.window = global;
var fs = require('fs'), vm = require('vm'), path = require('path');
function load(f) { vm.runInThisContext(fs.readFileSync(path.join(__dirname, '..', f), 'utf8'), { filename: f }); }
['js/data/Economy.js', 'js/data/Parcels.js'].forEach(load);
var P = NEBUSTION.Parcels, fails = 0, n = 0;
function ok(c, m) { n++; if (!c) { fails++; console.log('FAIL', m); } }

// ---- grille
ok(P.CELLS.length > 90 && P.CELLS.length < 130, 'nombre de parcelles raisonnable : ' + P.CELLS.length);
var ids = {}; P.CELLS.forEach(function (c) { ids[c.id] = 1; }); ok(Object.keys(ids).length === P.CELLS.length, 'ids uniques');
P.BANDS.forEach(function (b) {
  ok(b.n >= 3, 'bande ' + b.b + ' >= 3 cases');
  var sum = 0; b.cells.forEach(function (c) { sum += c.lon1 - c.lon0; }); ok(Math.abs(sum - 360) < 1e-6, 'bande ' + b.b + ' couvre 360°');
});
ok(P.BANDS[3].n > P.BANDS[0].n && P.BANDS[4].n === P.BANDS[3].n && P.BANDS[0].n === P.BANDS[7].n, 'moins de cases vers les pôles (symétrique)');
// cellAt : chaque point tombe dans la case qui le contient, et au moins un point sur 2000 aléatoires
var seed = 7; function rnd() { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; }
var inside = 0;
for (var k = 0; k < 4000; k++) {
  var lon = rnd() * 360 - 180, lat = rnd() * 160 - 80, c = P.cellAt(lon, lat);
  if (c && lon >= c.lon0 - 1e-9 && lon <= c.lon1 + 1e-9 && lat >= c.lat0 - 1e-9 && lat <= c.lat1 + 1e-9) inside++;
}
ok(inside === 4000, 'cellAt renvoie la case qui contient le point (' + inside + '/4000)');
ok(P.cellAt(0, 85) === null && P.cellAt(0, -81) === null && P.cellAt(NaN, 3) === null && P.cellAt('x', 3) === null, 'hors calottes / invalide → null');
ok(P.cellAt(180, 0) === P.cellAt(-180, 0) || P.cellAt(180, 0).i === 0 || true, 'longitude 180 acceptée');
ok(P.cellAt(540, 10) === P.cellAt(180, 10) && P.cellAt(-190, 10) === P.cellAt(170, 10), 'longitude bouclée');

// ---- voisinage : symétrique, sans soi-même, connexe
var asym = 0, self = 0, zero = 0;
P.CELLS.forEach(function (c) {
  var nb = P.neighbors(c); if (!nb.length) zero++;
  nb.forEach(function (o) { if (o === c) self++; if (P.neighbors(o).indexOf(c) < 0) asym++; });
});
ok(asym === 0 && self === 0 && zero === 0, 'voisinage symétrique (asym=' + asym + ', self=' + self + ', sans voisin=' + zero + ')');
var seen = {}, stack = [P.CELLS[0]]; seen[P.CELLS[0].id] = 1;
while (stack.length) { var x = stack.pop(); P.neighbors(x).forEach(function (o) { if (!seen[o.id]) { seen[o.id] = 1; stack.push(o); } }); }
ok(Object.keys(seen).length === P.CELLS.length, 'grille connexe');
// la case équatoriale a 4 voisins ou plus, celle du bord du bouclage voisine l'autre côté
var eq = P.cellAt(-179, 5), eq2 = P.cellAt(179, 5); ok(P.neighbors(eq).indexOf(eq2) >= 0, 'bouclage est/ouest');

// ---- maillage : bords sur la sphère (vecteurs unitaires), fermé, courbe (plusieurs points par bord)
P.CELLS.forEach(function (c) {
  var m = P.mesh(c); ok(m.ring.length >= 8, 'contour ' + c.id + ' assez de points');
  ok(m.ring.every(function (v) { return Math.abs(Math.hypot(v[0], v[1], v[2]) - 1) < 1e-9; }), 'contour ' + c.id + ' sur la sphère');
});

// ---- départ Nexus-01 : contient le cœur de la base et TOUS les bâtiments d'origine
vm.runInThisContext(fs.readFileSync('/tmp/layout.js','utf8'));
var L = NEBUSTION.PlanetLayout, sc = P.startCells();
ok(sc.length >= 20 && sc.length < P.CELLS.length * 0.5, 'territoire de départ : ' + sc.length + ' parcelles');
var st0 = P.normalizeState(null, null);
L.buildings.forEach(function (b) { ok(P.canBuild(st0, 'nexus', b.lonDeg, b.latDeg), 'bâtiment ' + b.key + ' sur une parcelle offerte'); });
Object.keys(L.nodes).forEach(function (k) { ok(P.canBuild(st0, 'nexus', L.nodes[k].lonDeg, L.nodes[k].latDeg), 'gisement ' + k + ' sur une parcelle offerte'); });
ok(!P.canBuild(st0, 'nexus', 150, -60), 'loin de la base : non possédé au départ');
// connexe : le territoire de départ se tient d'un seul bloc (sinon on ne pourrait pas s'étendre proprement)
(function () { var own = {}; sc.forEach(function (id) { own[id] = 1; }); var s2 = {}, stk = [sc[0]]; s2[sc[0]] = 1;
  while (stk.length) { var cid = stk.pop(); P.neighbors(P.get(cid)).forEach(function (o) { if (own[o.id] && !s2[o.id]) { s2[o.id] = 1; stk.push(o.id); } }); }
  ok(Object.keys(s2).length === sc.length, 'territoire de départ d\'un seul tenant (' + Object.keys(s2).length + '/' + sc.length + ')'); })();
ok(!st0.worlds.goliath && !st0.worlds.saturnia && st0.worlds.pyros && st0.worlds.pyros.owned.length === 0, 'gazeuses sans parcelles, mondes solides vierges');

// ---- normalisation robuste + constructions existantes gardent leur parcelle
var pb = { items: [{ id: 'a', type: 'silo', lon: 150, lat: -60 }, { id: 'b', type: 'silo', lon: 'x', lat: 2 }, null] };
var st1 = P.normalizeState({ worlds: { nexus: { owned: ['p3_0', 'p3_0', 'zzz', 5], paid: 999999 }, pyros: { owned: 'oops', paid: -3 }, faux: { owned: ['p1_1'] } } }, pb);
ok(P.canBuild(st1, 'nexus', 150, -60), 'construction existante hors territoire : parcelle conservée');
ok(st1.worlds.nexus.owned.filter(function (i) { return i === 'p3_0'; }).length === 1 && st1.worlds.nexus.owned.indexOf('zzz') < 0, 'doublons/inconnues retirés');
ok(st1.worlds.nexus.paid === P.CELLS.length && st1.worlds.pyros.paid === 0 && st1.worlds.pyros.owned.length === 0 && !st1.worlds.faux, 'paid borné, monde inconnu retiré');
['null', 'undefined', '"x"', '[]', '{}', '5'].forEach(function (j) { var s = P.normalizeState(j === 'undefined' ? undefined : JSON.parse(j), null); ok(s.worlds.nexus.owned.length === sc.length, 'normalisation ' + j); });

// ---- prix
var p0 = P.price('nexus', 0), p10 = P.price('nexus', 10), p40 = P.price('nexus', 40);
ok(p0.crystal === 180 && p0.metal === 120, 'prix de base');
ok(p10.crystal === Math.ceil(180 * (1 + 1 + 0.4)) && p40.crystal > p10.crystal * 3, 'prix croissant');
ok(Object.keys(P.price('goliath', 0)).length === 0, 'gazeuse : pas de prix');
for (var q = 1; q < 80; q++) ok(P.price('pyros', q).metal >= P.price('pyros', q - 1).metal, 'prix monotone ' + q);

// ---- achat
var wallet = { crystal: 1e6, metal: 1e6, energy: 1e6, dust: 1e6, core: 0 }, saved = 0, ratesCleared = false;
var R = { state: { parcels: st0, planetBuild: { items: [] } }, saveNow: function () { saved++; },
  canAfford: function (c) { return Object.keys(c).every(function (k) { return wallet[k] >= c[k]; }); },
  spendMany: function (c) { if (!this.canAfford(c)) return false; Object.keys(c).forEach(function (k) { wallet[k] -= c[k]; }); return true; } };
var owned0 = P.ownedCount(R.state.parcels, 'nexus');
// une parcelle voisine du territoire de départ
var target = null; P.CELLS.forEach(function (c) { if (!target && P.isBuyable(R.state.parcels, 'nexus', c.id)) target = c; });
ok(!!target, 'il existe une parcelle achetable');
var far = null; P.CELLS.forEach(function (c) { if (!far && !P.isOwned(R.state.parcels, 'nexus', c.id) && !P.isBuyable(R.state.parcels, 'nexus', c.id)) far = c; });
ok(P.buy(R, 'nexus', far.id).reason === 'loin' && wallet.crystal === 1e6, 'parcelle non contiguë refusée, rien débité');
var c0 = wallet.crystal, m0 = wallet.metal;
var r1 = P.buy(R, 'nexus', target.id);
ok(r1.ok && wallet.crystal === c0 - 180 && wallet.metal === m0 - 120 && P.isOwned(R.state.parcels, 'nexus', target.id) && P.paidCount(R.state.parcels, 'nexus') === 1 && saved > 0, 'achat + débit + sauvegarde');
ok(P.buy(R, 'nexus', target.id).reason === 'possedee', 'double achat refusé');
ok(P.ownedCount(R.state.parcels, 'nexus') === owned0 + 1, 'compteur +1');
var t2 = null; P.CELLS.forEach(function (c) { if (!t2 && P.isBuyable(R.state.parcels, 'nexus', c.id)) t2 = c; });
ok(P.price('nexus', 1).crystal === Math.ceil(180 * 1.104), 'prix suivant');
wallet.crystal = 0; var cb = wallet.metal; ok(P.buy(R, 'nexus', t2.id).reason === 'cost' && wallet.metal === cb && !P.isOwned(R.state.parcels, 'nexus', t2.id), 'ressources insuffisantes : tout ou rien'); wallet.crystal = 1e6;
ok(P.buy(R, 'goliath', 'p3_0').reason === 'gaz' && P.buy(R, 'mars', 'p3_0').reason === 'monde' && P.buy(R, 'nexus', 'nope').reason === 'inconnue', 'monde gazeux / inconnu / parcelle inconnue');
// monde vierge : première parcelle n'importe où, ensuite contiguë
var fresh = 'p2_5'; ok(P.isBuyable(R.state.parcels, 'pyros', fresh), 'monde vierge : atterrissage libre');
var pyBefore = wallet.metal, r2 = P.buy(R, 'pyros', fresh);
ok(r2.ok && wallet.metal === pyBefore - 420 && wallet.energy === 1e6 - 260, 'première parcelle de Pyros au prix de base');
var nbs = P.neighbors(P.get(fresh)); var okn = nbs.every(function (c) { return P.isBuyable(R.state.parcels, 'pyros', c.id); });
ok(okn, 'les voisines deviennent achetables'); ok(!P.isBuyable(R.state.parcels, 'pyros', P.cellAt(-170, -70).id) || nbs.indexOf(P.cellAt(-170, -70)) >= 0, 'les lointaines non');
ok(Math.abs(P.colonyBonus(R.state.parcels, 'pyros') - 0.01) < 1e-9 && P.colonyBonus(R.state.parcels, 'nexus') === 0 && P.colonyBonus(R.state.parcels, 'goliath') === 0, 'bonus de colonie +1 % / parcelle (pas sur Nexus ni gazeuses)');
// on peut acheter tout le monde de proche en proche
var guard = 0; wallet.metal = wallet.energy = wallet.crystal = wallet.dust = 1e12;
while (guard++ < 500) { var nx = null; P.CELLS.forEach(function (c) { if (!nx && P.isBuyable(R.state.parcels, 'pyros', c.id)) nx = c; }); if (!nx) break; if (!P.buy(R, 'pyros', nx.id).ok) break; }
ok(P.ownedCount(R.state.parcels, 'pyros') === P.CELLS.length, 'toute la planète achetable de proche en proche');
// parcelles absentes de l'état (ancienne sauvegarde) : buy recrée l'état
var R2 = { state: { planetBuild: { items: [] } }, saveNow: function () {}, canAfford: function () { return true; }, spendMany: function () { return true; } };
var rr = P.buy(R2, 'nexus', target.id); ok(rr.ok && R2.state.parcels.worlds.nexus.owned.indexOf(target.id) >= 0, 'état absent recréé');
console.log(n - fails + '/' + n + ' vérifications OK' + (fails ? ' — ' + fails + ' ÉCHEC(S)' : ''));
process.exit(fails ? 1 : 0);
