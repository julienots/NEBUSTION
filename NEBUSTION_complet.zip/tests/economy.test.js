/* Tests de la logique économique NEBUSTION (Node, sans dépendance).  Lancer : node tests/economy.test.js */
'use strict';
global.window = global;
require('../js/data/Economy.js');
require('../js/systems/SaveManager.js');
require('../js/systems/ResourceManager.js');

const E = NEBUSTION.Economy, Save = NEBUSTION.Save, RM = NEBUSTION.ResourceManager;
let passed = 0, failed = 0;
function ok(cond, msg) { if (cond) { passed++; } else { failed++; console.log('  ✗ ECHEC : ' + msg); } }
function near(a, b, tol, msg) { ok(Math.abs(a - b) <= tol, msg + ' (obtenu ' + a + ', attendu ' + b + ')'); }
function section(t) { console.log('\n# ' + t); }

function memStorage() {
  const m = {};
  return { data: m, getItem: k => (k in m ? m[k] : null), setItem: (k, v) => { m[k] = String(v); }, removeItem: k => { delete m[k]; } };
}
function fresh(t0, opts) {
  opts = opts || {};
  const storage = opts.storage || memStorage();
  Save._useStorage(storage);
  const rm = new RM({ rng: opts.rng });
  rm.init(t0);
  return { rm, storage };
}
const T0 = 1_800_000_000_000;
const seqRng = (vals) => { let i = 0; return () => vals[i++ % vals.length]; };
const noCrit = () => 0.99;

section('Formules');
{
  near(E.totalRate('crystal', 1, 1, 2), 0.5 + 0.2 * 1.12, 1e-12, 'crystal niveau 1 + 1 drone hangar 2');
  near(E.totalRate('core', 1, 0, 1), 0.01, 1e-12, 'noyaux sans drone');
  ok(E.totalRate('crystal', 1, -5, 1) === 0.5, 'drones négatifs ignorés');
  ok(E.totalRate('crystal', NaN, NaN, NaN) >= 0, 'entrées NaN → taux ≥ 0');
  ok(E.totalRate('metal', 5, 3, 3) > E.totalRate('metal', 4, 3, 3), 'la production croît avec le niveau');
  ok(E.storageCap('crystal', 2) === 22500, 'capacité niveau 2 = ×1.5');
  E.BUILDING_ORDER.forEach(b => {
    let prev = 0;
    for (let l = 1; l <= 20; l++) {
      const c = E.upgradeCost(b, l); let sum = 0;
      Object.keys(c).forEach(k => { ok(Number.isInteger(c[k]) && c[k] > 0, 'coût entier > 0 ' + b + ' L' + l); sum += c[k]; });
      ok(sum > prev, 'coût croissant ' + b + ' L' + l); prev = sum;
    }
  });
  ok(E.fmt(8452) === '8 452', 'fmt 8452 → ' + E.fmt(8452));
  ok(E.fmt(9999.9) === '9 999', 'fmt arrondi vers le bas');
  ok(E.fmt(12399) === '12.3K', 'fmt 12399 → ' + E.fmt(12399));
  ok(E.fmt(1250000) === '1.25M', 'fmt 1.25M → ' + E.fmt(1250000));
  ok(E.fmt(-5) === '0' && E.fmt(NaN) === '0' && E.fmt(Infinity) === '0', 'fmt valeurs invalides → 0');
  ok(E.fmt(12.39, 1) === '12.3', 'fmt 1 décimale arrondie vers le bas');
  ok(E.fmt(0, 1) === '0.0', 'fmt zéro noyaux');
  ok(E.fmtRate(0.01448) === '0.014', 'fmtRate noyaux → ' + E.fmtRate(0.01448));
  ok(E.fmtRate(0.724) === '0.72' && E.fmtRate(14.56) === '14.6' && E.fmtRate(128.4) === '128', 'fmtRate paliers');
  ok(E.fmtGain(4) === '4' && E.fmtGain(0.04) === '0.04' && E.fmtGain(4.48) === '4.48' && E.fmtGain(1.2) === '1.2', 'fmtGain');
  ok(E.fmtDuration(45) === '45 s' && E.fmtDuration(125) === '2 min 05 s' && E.fmtDuration(11520) === '3 h 12 min', 'fmtDuration');
}

section('Nouvelle partie & production en temps réel');
{
  const { rm } = fresh(T0, { rng: noCrit });
  ok(rm.isNewGame, 'nouvelle partie détectée');
  E.ORDER.forEach(id => ok(rm.get(id) === E.PROD[id].start, 'stock de départ ' + id));
  const r0 = Object.assign({}, rm.rates());
  near(r0.crystal, 0.5 + 0.2 * 1.12, 1e-9, 'taux cristaux');
  near(r0.dust * 60, (1 + 0.4 * 1.12) * 60, 1e-9, 'poussière /min');
  // 10 minutes à ~60 FPS avec gigue
  let t = T0;
  for (let i = 0; i < 36000; i++) { t += 16 + (i % 3); rm.tick(t); }
  const el = (t - T0) / 1000;
  E.ORDER.forEach(id => near(rm.get(id) - E.PROD[id].start, r0[id] * el, r0[id] * el * 1e-6 + 1e-6, 'production ' + id + ' sur ' + el.toFixed(0) + ' s'));
  ok(rm.state.stats.playSec > 590, 'temps de jeu cumulé');
  // même durée à 5 FPS → même résultat (indépendant des FPS)
  const b = fresh(T0, { rng: noCrit }).rm; let t2 = T0;
  for (let i = 0; i < 3000; i++) { t2 += 200; b.tick(t2); }
  near(b.get('crystal'), rm.get('crystal') - r0.crystal * (t - t2) / 1000 * 0 - (rm.get('crystal') - E.PROD.crystal.start - r0.crystal * 600) , 50, 'sanity');
  near(b.get('crystal') - 100, r0.crystal * 600, 1e-6, 'indépendance vis-à-vis du FPS');
}

section('Plafond de stockage');
{
  const { rm } = fresh(T0, { rng: noCrit });
  rm.state.res.crystal = rm.cap('crystal') - 1;
  let t = T0; for (let i = 0; i < 200; i++) { t += 100; rm.tick(t); }
  ok(rm.get('crystal') === rm.cap('crystal'), 'plafonné exactement à la capacité');
  ok(rm.isFull('crystal'), 'isFull');
  ok(rm.add('crystal', 100, 'test') === 0, 'add refusé quand plein');
  const tap = rm.tap('crystal', t);
  ok(!tap.ok && tap.reason === 'full', 'tap refusé quand plein');
  ok(rm.charges('crystal', t) >= 7.99, 'une charge n\'est pas consommée si le stock est plein');
  ok(rm.spend('crystal', 500), 'dépense possible depuis un stock plein');
  ok(rm.get('crystal') === rm.cap('crystal') - 500, 'stock diminué');
}

section('Dépenses : jamais de valeur négative, atomicité');
{
  const { rm } = fresh(T0, { rng: noCrit });
  ok(!rm.spend('crystal', 101), 'dépense > stock refusée');
  ok(rm.get('crystal') === 100, 'stock inchangé après refus');
  ok(!rm.spend('crystal', -50), 'montant négatif refusé');
  ok(!rm.spend('crystal', NaN) && !rm.spend('crystal', Infinity), 'NaN / Infinity refusés');
  ok(!rm.spend('inconnu', 1), 'ressource inconnue refusée');
  ok(!rm.spendMany({ crystal: 50, metal: 61 }), 'coût multiple partiellement impayable refusé');
  ok(rm.get('crystal') === 100 && rm.get('metal') === 60, 'atomicité : rien n\'a été débité');
  ok(rm.spendMany({ crystal: 100, metal: 60 }), 'coût exact payable');
  ok(rm.get('crystal') === 0 && rm.get('metal') === 0, 'stocks à zéro exactement, pas négatifs');
  ok(rm.add('crystal', -10, 't') === 0 && rm.get('crystal') === 0, 'add négatif ignoré');
  ok(rm.add('crystal', NaN, 't') === 0 && rm.add('crystal', 'abc', 't') === 0, 'add NaN ignoré');
}

section('Récolte manuelle (tap)');
{
  const { rm } = fresh(T0, { rng: noCrit });
  let t = T0; const before = rm.get('crystal');
  for (let i = 0; i < 8; i++) { const r = rm.tap('crystal', t); ok(r.ok && !r.crit && r.amount === 3, 'tap ' + (i + 1) + ' = +3'); }
  ok(rm.get('crystal') === before + 24, '8 taps = +24');
  const r9 = rm.tap('crystal', t);
  ok(!r9.ok && r9.reason === 'empty' && r9.wait > 2.9 && r9.wait <= 3, 'réserve vide au 9e tap');
  t += 3000; ok(rm.tap('crystal', t).ok, 'une charge revient après 3 s');
  ok(!rm.tap('crystal', t).ok, 'mais une seule');
  t += 60000; ok(Math.abs(rm.charges('crystal', t) - 8) < 1e-9, 'recharge complète plafonnée à 8');
  ok(rm.tap('nimportequoi', t).reason === 'invalid', 'gisement invalide');
  // critique forcé
  const c = fresh(T0, { rng: () => 0.01 }).rm;
  const cr = c.tap('metal', T0);
  ok(cr.ok && cr.crit && cr.amount === 6, 'critique = ×3 (métal 2 → 6)');
  ok(c.state.stats.crits === 1 && c.state.stats.taps === 1, 'stats taps/crits');
  // horloge reculée : pas de charges négatives ni NaN
  const cc = fresh(T0, { rng: noCrit }).rm;
  cc.tap('dust', T0 + 100000);
  const ch = cc.charges('dust', T0);
  ok(isFinite(ch) && ch >= 0 && ch <= 8, 'charges valides si l\'horloge recule');
  // noyaux : montant fractionnaire cohérent
  const k = fresh(T0, { rng: noCrit }).rm; k.tap('core', T0);
  near(k.get('core'), 0.04, 1e-12, 'tap noyaux = 0.04');
}

section('Production hors ligne');
{
  const { rm } = fresh(T0, { rng: noCrit });
  const rates = Object.assign({}, rm.rates());
  const start = {}; E.ORDER.forEach(id => start[id] = rm.get(id));
  rm.tick(T0 + 600000);   // 10 min d'absence
  E.ORDER.forEach(id => near(rm.get(id) - start[id], rates[id] * 600 * 0.6, 1e-6, 'hors-ligne 10 min ' + id));
  const rep = rm.consumeOfflineReport();
  ok(rep && rep.seconds === 600 && !rep.truncated, 'rapport 10 min');
  near(rep.gains.crystal, rates.crystal * 360, 1e-6, 'rapport = gains crédités');
  ok(rm.consumeOfflineReport() === null, 'le rapport n\'est remis qu\'UNE fois');
  const a = rm.get('crystal'); rm.tick(T0 + 600016); near(rm.get('crystal') - a, rates.crystal * 0.016, 1e-6, 'pas de crédit en double au tick suivant');

  // 30 s : crédité mais pas de fenêtre
  const s = fresh(T0, { rng: noCrit }).rm; s.tick(T0 + 30000);
  near(s.get('crystal') - 100, s.rate('crystal') * 30 * 0.6, 1e-6, 'absence 30 s créditée');
  ok(s.pendingReport === null, 'pas de fenêtre sous 60 s');

  // 30 h : plafonné à 8 h
  const big = fresh(T0, { rng: noCrit }).rm; const br = Object.assign({}, big.rates());
  big.tick(T0 + 30 * 3600 * 1000);
  const rp = big.consumeOfflineReport();
  ok(rp.truncated && rp.credited === 8 * 3600, 'absence > 8 h tronquée à 8 h');
  E.ORDER.forEach(id => ok(big.get(id) <= big.cap(id) + 1e-9, 'cap respecté après 30 h ' + id));
  near(big.get('crystal'), 100 + br.crystal * 8 * 3600 * 0.6, 1e-6, '8 h × 60 % cristaux');

  // stockage presque plein : on perd le surplus, jamais de dépassement
  const f = fresh(T0, { rng: noCrit }).rm; f.state.res.crystal = f.cap('crystal') - 10;
  f.tick(T0 + 3600000);
  ok(f.get('crystal') === f.cap('crystal'), 'plafonné hors ligne');
  ok(f.consumeOfflineReport().lost.crystal > 0, 'surplus perdu signalé');

  // horloge reculée : rien de crédité, pas de négatif
  const b = fresh(T0, { rng: noCrit }).rm; const v = b.get('crystal');
  b.tick(T0 - 5000000); ok(b.get('crystal') === v, 'horloge reculée : aucun gain / aucune perte');
  b.tick(T0 - 5000000 + 1000); ok(b.get('crystal') > v && b.get('crystal') < v + 2, 'reprise normale après recul');

  // deux absences non consultées s'additionnent
  const m = fresh(T0, { rng: noCrit }).rm; m.tick(T0 + 100000); m.tick(T0 + 300000);
  ok(m.pendingReport.seconds === 300, 'rapports fusionnés (100 s + 200 s)');
}

section('Sauvegarde / rechargement');
{
  const storage = memStorage();
  let { rm } = fresh(T0, { storage, rng: noCrit });
  let t = T0; for (let i = 0; i < 600; i++) { t += 100; rm.tick(t); }
  rm.tap('crystal', t); rm.tap('crystal', t);
  rm.saveNow(t);
  const snap = JSON.parse(JSON.stringify(rm.state.res));
  const life = JSON.parse(JSON.stringify(rm.state.life));

  // rechargement 2 h plus tard : ressources sauvegardées + hors-ligne, appliqué UNE fois
  Save._useStorage(storage);
  let r2 = new RM({ rng: noCrit }); const rates = Object.assign({}, (r2.init(t + 7200000), r2.rates()));
  E.ORDER.forEach(id => near(r2.get(id), Math.min(r2.cap(id), snap[id] + rates[id] * 7200 * 0.6), 1e-6, 'après rechargement +2 h : ' + id));
  const after1 = r2.get('crystal');
  ok(r2.state.stats.sessions === 2, 'compteur de sessions');
  ok(r2.consumeOfflineReport().seconds === 7200, 'rapport 2 h');

  // rechargement immédiat (F5) : aucun gain gratuit
  Save._useStorage(storage);
  let r3 = new RM({ rng: noCrit }); r3.init(t + 7200000 + 1000);
  near(r3.get('crystal') - after1, 0, 1, 'F5 immédiat ≈ aucun crédit supplémentaire (< 1 s)');
  ok(r3.pendingReport === null, 'pas de fenêtre sur un simple rechargement');
  ok(r3.state.life.crystal >= life.crystal, 'total historique jamais en baisse');

  // état persistant : niveaux, drones, charges
  const s4 = fresh(T0, { rng: noCrit }); s4.rm.state.drones.dust = 3; s4.rm.state.buildings.ext_dust.level = 4; s4.rm._rates = null;
  s4.rm.tap('dust', T0); s4.rm.saveNow(T0 + 1);
  Save._useStorage(s4.storage);
  const r5 = new RM({ rng: noCrit }); r5.init(T0 + 2);
  ok(r5.droneCount('dust') === 3 && r5.extractorLevel('dust') === 4, 'niveaux et drones persistés');
  ok(r5.charges('dust', T0 + 2) < 7.1, 'charges de récolte persistées (pas de recharge par F5)');
}

section('Sauvegarde corrompue / falsifiée');
{
  const storage = memStorage();
  fresh(T0, { storage, rng: noCrit });
  const good = storage.data[Save.KEY];
  // 1) primaire tronquée → secours
  storage.data[Save.KEY] = good.slice(0, good.length - 20);
  Save._useStorage(storage);
  let r = new RM({ rng: noCrit }); r.init(T0 + 1000);
  ok(r.loadInfo.corrupted && r.loadInfo.source === 'backup', 'primaire corrompue → copie de secours');
  ok(Object.keys(storage.data).some(k => k.endsWith('_corrupt')), 'copie corrompue conservée pour analyse');
  ok(r.get('crystal') >= 100, 'état restauré');
  // 2) tout est corrompu → nouvelle partie propre
  const st2 = memStorage(); st2.data[Save.KEY] = '{"h":"x","d":"{}"}'; st2.data[Save.KEY + '_bak'] = 'n\'importe quoi';
  Save._useStorage(st2);
  const r2 = new RM({ rng: noCrit }); r2.init(T0);
  ok(r2.isNewGame && r2.get('crystal') === 100, 'tout corrompu → nouvelle partie valide');
  // 3) valeurs modifiées à la main (somme de contrôle invalide) → rejet
  const st3 = memStorage(); Save._useStorage(st3);
  const g = new RM({ rng: noCrit }); g.init(T0); g.state.res.crystal = 50; g.saveNow(T0 + 1);
  const env = JSON.parse(st3.data[Save.KEY]); const body = JSON.parse(env.d); body.res.crystal = 999999; env.d = JSON.stringify(body);
  st3.data[Save.KEY] = JSON.stringify(env); st3.data[Save.KEY + '_bak'] = 'x';
  const r3 = new RM({ rng: noCrit }); r3.init(T0 + 2);
  ok(r3.get('crystal') < 999999, 'sauvegarde éditée à la main rejetée');
}

section('Normalisation de données invalides');
{
  const junk = {
    lastSeen: 'demain', createdAt: -5, res: { crystal: -100, metal: NaN, energy: Infinity, core: '12abc', dust: 1e99 },
    life: { crystal: -1 }, buildings: { storage: { level: 9999 }, hangar: { level: -3 }, ext_core: { level: 'x' }, pirate: { level: 3 } },
    drones: { crystal: 500, metal: -2, energy: 2.9 }, nodes: { crystal: { ch: 99, t: T0 * 10 }, metal: { ch: -4, t: 'a' } },
    stats: { taps: -1, playSec: NaN, lastPod: T0 * 5 }
  };
  const s = Save.normalize(junk, T0);
  E.ORDER.forEach(id => {
    ok(Number.isFinite(s.res[id]) && s.res[id] >= 0 && s.res[id] <= E.storageCap(id, s.buildings.storage.level), 'res valide ' + id + ' = ' + s.res[id]);
    ok(Number.isInteger(s.drones[id]) && s.drones[id] >= 0 && s.drones[id] <= E.CFG.MAX_DRONES, 'drones valides ' + id);
    ok(s.nodes[id].ch >= 0 && s.nodes[id].ch <= 8 && s.nodes[id].t <= T0, 'nodes valides ' + id);
  });
  ok(s.buildings.storage.level === E.CFG.MAX_LEVEL && s.buildings.hangar.level === 1 && s.buildings.ext_core.level === 1, 'niveaux bornés');
  ok(!('pirate' in s.buildings), 'bâtiment inconnu supprimé');
  ok(s.lastSeen <= T0 && s.stats.lastPod <= T0 && s.stats.taps === 0 && s.stats.playSec === 0, 'dates/stats valides');
  ok(JSON.stringify(Save.normalize(null, T0)).length > 100 && Save.normalize('x', T0).res.crystal === 100, 'null / chaîne → partie par défaut');
}

section('Plusieurs onglets : pas de duplication');
{
  const storage = memStorage(); Save._useStorage(storage);
  const A = new RM({ rng: noCrit }); A.init(T0);
  const B = new RM({ rng: noCrit }); B.init(T0);
  A.spend('crystal', 40); A.saveNow(T0 + 10);
  ok(B._adoptExternal(storage.data[Save.KEY]), 'B adopte la sauvegarde de A');
  ok(B.get('crystal') === 60, 'B voit 60 cristaux (pas de duplication)');
  ok(!A._adoptExternal(storage.data[Save.KEY]), 'A ignore sa propre écriture');
  B.tick(T0 + 1000); B.saveNow(T0 + 1000); A._adoptExternal(storage.data[Save.KEY]);
  near(A.get('crystal'), B.get('crystal'), 1e-9, 'A et B convergent sur le même stock');
}

section('Caisse de ravitaillement');
{
  for (let i = 0; i < 300; i++) {
    const p = E.rollPodReward({ crystal: 0.7, metal: 0.5, energy: 0.3, core: 0.014, dust: 1.4 }, Math.random);
    ok(p.length === 2 && p[0].id !== p[1].id, 'deux ressources distinctes');
    p.forEach(x => ok(Number.isFinite(x.amount) && x.amount > 0, 'montant > 0'));
  }
  const p2 = E.rollPodReward({ crystal: 0, metal: 0, energy: 0, core: 0, dust: 0 }, Math.random);
  p2.forEach(x => ok(x.amount >= (x.id === 'core' ? 0.1 : 1), 'plancher même à production nulle'));
  const { rm } = fresh(T0, { rng: seqRng([0.0, 0.5, 0.5, 0.5]) });
  const before = JSON.parse(JSON.stringify(rm.state.res));
  const got = rm.claimPod(T0 + 5000);
  got.forEach(g => near(rm.get(g.id) - before[g.id], g.amount, 1e-9, 'caisse créditée ' + g.id));
  ok(rm.state.stats.pods === 1 && rm.state.stats.lastPod === T0 + 5000, 'stats caisse');
  const events = []; rm.on('gain', e => events.push(e));
  rm.state.res.crystal = rm.cap('crystal'); rm.state.res.metal = rm.cap('metal'); rm.state.res.energy = rm.cap('energy');
  rm.state.res.core = rm.cap('core'); rm.state.res.dust = rm.cap('dust');
  const full = rm.claimPod(T0 + 9000);
  ok(full.every(x => x.amount === 0), 'caisse sur stock plein : rien de perdu ni de négatif');
}

section('Bâtiments améliorables (API prête)');
{
  const { rm } = fresh(T0, { rng: noCrit });
  const r1 = rm.rate('crystal');
  const bad = rm.upgradeBuilding('ext_crystal');
  ok(!bad.ok && bad.reason === 'cost' && rm.extractorLevel('crystal') === 1, 'amélioration refusée sans ressources');
  rm.state.res.metal = 1000; rm.state.res.dust = 1000;
  const up = rm.upgradeBuilding('ext_crystal');
  ok(up.ok && up.level === 2 && rm.get('metal') === 850 && rm.get('dust') === 700, 'amélioration payée (150 métal + 300 poussière)');
  near(rm.rate('crystal'), r1 + 0.5 * 0.22, 1e-9, 'taux mis à jour immédiatement');
  ok(rm.upgradeBuilding('pirate').reason === 'unknown', 'bâtiment inconnu');
  rm.state.buildings.hangar.level = 50; ok(rm.upgradeBuilding('hangar').reason === 'max', 'niveau max');
  rm.state.res.metal = 1e4; rm.state.res.dust = 1e4; const cap1 = rm.cap('metal');
  ok(rm.upgradeBuilding('storage').ok && rm.cap('metal') === Math.floor(cap1 * 1.5), 'le stockage augmente la capacité');
  ok(rm.addDrone('crystal') && rm.droneCount('crystal') === 2 && rm.rate('crystal') > r1, 'ajout de drone');
  for (let i = 0; i < 20; i++) rm.addDrone('crystal'); ok(rm.droneCount('crystal') === E.CFG.MAX_DRONES, 'drones bornés');
}

section('Gains récents (fenêtre glissante 60 s)');
{
  const { rm } = fresh(T0, { rng: noCrit });
  let t = T0; for (let i = 0; i < 300; i++) { t += 100; rm.tick(t); }   // 30 s
  const w = rm.recent('crystal', t);
  near(w.total, rm.rate('crystal') * 30, 0.05, 'fenêtre = 30 s de production');
  ok(w.seconds >= 29.9 && w.seconds <= 30.1, 'durée couverte');
  for (let i = 0; i < 900; i++) { t += 100; rm.tick(t); }   // +90 s
  near(rm.recent('crystal', t).total, rm.rate('crystal') * 60, rm.rate('crystal') * 1.05, 'fenêtre plafonnée à 60 s (±1 s : la seconde en cours est partielle)');
  const idle = rm.recent('crystal', t + 120000).total; ok(idle < 1e-6, 'fenêtre vide après 2 min sans gain');
}

section('Événements & robustesse');
{
  const { rm } = fresh(T0, { rng: noCrit });
  let n = 0; const off = rm.on('gain', () => { n++; });
  rm.tap('crystal', T0); ok(n === 1, 'événement gain');
  off(); rm.tap('crystal', T0); ok(n === 1, 'désabonnement effectif (pas de doublon d\'écouteur)');
  rm.on('gain', () => { throw new Error('boum'); });
  const origErr = console.error; console.error = () => {};
  let threw = false; try { rm.tap('crystal', T0); } catch (e) { threw = true; } console.error = origErr;
  ok(!threw, 'un écouteur qui plante ne casse pas l\'économie');
  // stockage indisponible → jeu jouable en mémoire
  Save._useStorage({ getItem() { throw new Error('bloqué'); }, setItem() { throw new Error('quota'); }, removeItem() { throw new Error('x'); } });
  const r = new RM({ rng: noCrit }); r.init(T0);
  ok(r.isNewGame && r.get('crystal') === 100, 'lecture impossible → nouvelle partie jouable');
  r.tick(T0 + 1000); ok(r.get('crystal') > 100, 'production OK sans stockage');
  ok(r.saveNow(T0 + 2000) === false && r.lastSaveOk === false, 'échec d\'écriture signalé sans exception');
  const rr = new RM({ rng: noCrit }); Save._useStorage(memStorage()); rr.init(T0); rr.reset(T0 + 5);
  ok(rr.get('crystal') === 100 && rr.state.stats.taps === 0, 'reset');
}

section('Simulation d\'équilibrage (joueur actif vs inactif)');
{
  const { rm: idle } = fresh(T0, { rng: noCrit });
  const { rm: act } = fresh(T0, { rng: seqRng([0.5, 0.05, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5]) });
  let t = T0, tapClock = 0;
  const marks = {};
  for (let s = 1; s <= 3600; s++) {
    t += 1000; idle.tick(t); act.tick(t);
    if (s % 3 === 0) E.ORDER.forEach(id => act.tap(id, t));   // 1 tap toutes les 3 s par gisement (= vitesse de recharge)
    if (s === 60 || s === 600 || s === 3600) marks[s] = { idle: E.ORDER.map(id => Math.floor(idle.get(id))), act: E.ORDER.map(id => Math.floor(act.get(id))) };
  }
  console.log('  Stocks [cristaux, métal, énergie, noyaux, poussière]');
  Object.keys(marks).forEach(k => console.log('   ' + (k / 60) + ' min  inactif ' + marks[k].idle.join(' / ') + '   |   actif ' + marks[k].act.join(' / ')));
  ok(act.get('crystal') > idle.get('crystal') * 1.5, 'jouer activement rapporte nettement plus qu\'attendre');
  E.ORDER.forEach(id => ok(idle.get(id) <= idle.cap(id) && act.get(id) <= act.cap(id), 'jamais au-dessus du plafond après 1 h ' + id));
  const secs = (cost, rid) => Math.ceil((cost - 0) / idle.rate(rid));
  const c1 = E.upgradeCost('ext_crystal', 1);
  console.log('  1re amélioration (extracteur cristaux) : ' + JSON.stringify(c1) + ' → ≈ ' + E.fmtDuration(Math.max(secs(c1.metal - 60, 'metal'), secs(c1.dust - 150, 'dust'))) + ' d\'attente passive');
  const off8 = fresh(T0, { rng: noCrit }).rm; off8.tick(T0 + 8 * 3600000);
  console.log('  8 h hors ligne (60 %) : ' + E.ORDER.map(id => E.fmt(off8.get(id), E.RES[id].decimals) + '/' + E.fmt(off8.cap(id))).join('  '));
}

console.log('\n' + (failed === 0 ? '✔ TOUS LES TESTS PASSENT' : '✘ ' + failed + ' ÉCHEC(S)') + '  (' + passed + ' vérifications réussies)');
process.exit(failed === 0 ? 0 : 1);
