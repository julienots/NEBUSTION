global.window = global;
var fs = require('fs'), vm = require('vm');
function load(f) { vm.runInThisContext(fs.readFileSync(require('path').join(__dirname, '..', f), 'utf8'), { filename: f }); }
['js/data/Economy.js','js/data/Heroes.js','js/data/Equipment.js','js/data/Skins.js','js/data/Crates.js'].forEach(load);
var wallet = { dust: 100000, crystal: 100000, energy: 100000, metal: 100000, core: 100 }, gems = 500, frags = {}, eq = [];
NEBUSTION.Resources = { state: {}, saveNow: function () {}, canAfford: function (c) { return Object.keys(c).every(function (k) { return (wallet[k] || 0) >= c[k]; }); },
  spendMany: function (c) { Object.keys(c).forEach(function (k) { wallet[k] -= c[k]; }); return true; }, add: function (id, a) { wallet[id] = (wallet[id] || 0) + a; return a; } };
NEBUSTION.ShopManager = { addGems: function (n) { gems += n; }, canAfford: function (c) { return (!c.gem || gems >= c.gem) && NEBUSTION.Resources.canAfford(Object.keys(c).filter(function (k) { return k !== 'gem'; }).reduce(function (o, k) { o[k] = c[k]; return o; }, {})); },
  spend: function (c) { if (!this.canAfford(c)) return false; var r = Object.assign({}, c); delete r.gem; NEBUSTION.Resources.spendMany(r); if (c.gem) gems -= c.gem; return true; } };
NEBUSTION.Combat = { isUnlocked: function () { return true; }, addFragments: function (id, a) { frags[id] = (frags[id] || 0) + a; return { ok: true }; } };
NEBUSTION.EquipmentManager = { grant: function (slot, r) { eq.push([slot, r]); return { ok: true, item: { slot: slot, rarity: r } }; } };
load('js/systems/SkinManager.js'); load('js/systems/CrateManager.js');
var CM = NEBUSTION.CrateManager, K = NEBUSTION.Crates, fails = 0, n = 0;
function ok(c, m) { n++; if (!c) { fails++; console.log('FAIL', m); } }

// ouverture impossible sans caisse / clé
ok(CM.open('astral').reason === 'caisse', 'sans caisse');
CM.addCrate('astral', 1); ok(CM.open('astral').reason === 'cle', 'sans clé');
// achat clé (Prismes) et caisse (ressources)
var g0 = gems; ok(CM.buyKey('astral').ok && gems === g0 - 20 && CM.keys('astral') === 1, 'achat clé');
var d0 = wallet.dust; ok(CM.buyCrate('astral').ok && wallet.dust === d0 - 1500 && CM.crates('astral') === 2, 'achat caisse');
gems = 0; ok(CM.buyKey('nebula').reason === 'ressources', 'prismes insuffisants'); gems = 5000;
// ouverture : consomme 1 caisse + 1 clé, historique, pitié
var r = CM.open('astral');
ok(r.ok && CM.crates('astral') === 1 && CM.keys('astral') === 0, 'consommation');
ok(CM.opened() === 1 && CM.history().length === 1, 'historique');
ok(CM.shards() >= K.BONUS_SHARDS[r.reward.rarity], 'éclats bonus');
// 200 ouvertures : aucune exception, types cohérents, doublons => éclats
CM.addCrate('singularity', 200); CM.addKey('singularity', 200);
var kinds = {}, dups = 0, newSkins = 0;
for (var i = 0; i < 200; i++) {
  var o = CM.open('singularity'); ok(o.ok, 'open ' + i);
  kinds[o.reward.kind] = (kinds[o.reward.kind] || 0) + 1;
  if (o.reward.kind === 'skin') { if (o.reward.dup) dups++; else newSkins++; ok(NEBUSTION.SkinManager.isOwned(o.reward.skin.id), 'skin possédé'); }
  ok(o.reward.rarity === 'epique' || o.reward.rarity === 'legendaire', 'singularité ≥ épique');
}
ok(kinds.skin > 0 && kinds.equipment > 0 && kinds.fragments > 0 && kinds.resources > 0, 'tous les types sortent ' + JSON.stringify(kinds));
ok(CM.history().length === K.HISTORY_MAX, 'historique borné');
ok(eq.length === kinds.equipment && Object.keys(frags).length > 0, 'équipement/fragments donnés');
// Forge
var s0 = CM.shards(); ok(s0 > 0, 'éclats accumulés ' + s0);
CM.addShards(5000);
var fl = CM.forgeList(); ok(fl.every(function (s) { return !NEBUSTION.SkinManager.isOwned(s.id) && (s.crate || !s.exclusive); }), 'forgeList');
if (fl.length) { var f0 = fl[0], before = CM.shards(), fr = CM.forgeSkin(f0.id); ok(fr.ok && NEBUSTION.SkinManager.isOwned(f0.id) && CM.shards() === before - K.forgeSkinCost(f0.id), 'forge skin'); ok(CM.forgeSkin(f0.id).reason === 'deja', 'forge doublon refusée'); }
ok(CM.forgeSkin('h_astral').reason === 'invalide', 'forge exclusif Pass refusée');
var sh = CM.shards(), fk = CM.forgeKey('astral'); ok(fk.ok && CM.shards() === sh - K.CRATES.astral.keyShards && CM.keys('astral') === 1, 'forge clé');
CM.state; var low = CM.shards(); NEBUSTION.Resources.state.crates.shards = 0; ok(CM.forgeKey('nebula').reason === 'eclats', 'forge clé sans éclats');
// Quotidien
var now = Date.now(); ok(CM.dailyAvailable(now), 'daily dispo'); var c0 = CM.crates('astral'); ok(CM.claimDaily(now).ok && CM.crates('astral') === c0 + 1, 'daily'); ok(!CM.dailyAvailable(now) && CM.claimDaily(now).reason === 'deja', 'daily unique'); ok(CM.dailyAvailable(now + 86400000), 'daily lendemain');
// Butin passif
var got = 0; for (i = 0; i < 2000; i++) { got += CM.dropFromCombat(3).length; } ok(got > 200 && got < 900, 'drops combat ' + got);
ok(CM.dropFromCombat(0).length === 0, 'défaite = rien');
var pg = 0; for (i = 0; i < 2000; i++) if (CM.dropFromPod()) pg++; ok(pg > 120 && pg < 400, 'drops pod ' + pg);
ok(CM.readyCount() >= 0 && CM.totalCrates() > 0, 'compteurs');
console.log(n + ' vérifications, ' + fails + ' échec(s)');
process.exit(fails ? 1 : 0);
