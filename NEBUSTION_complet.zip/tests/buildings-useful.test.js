/* NEBUSTION - bâtiments utiles de Nexus-01 : entrepôt, foreuse, chronodôme, raffinerie, condenseur.  node tests/buildings-useful.test.js */
global.window = global;
global.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} };
var path = require('path'), root = path.join(__dirname, '..');
['js/data/Economy.js', 'js/data/PlanetBuild.js', 'js/systems/SaveManager.js', 'js/systems/ResourceManager.js'].forEach(function (f) { require(path.join(root, f)); });
var N = NEBUSTION, PB = N.PlanetBuild, E = N.Economy, fails = 0, checks = 0;
function ok(c, m) { checks++; if (!c) { fails++; console.log('ÉCHEC : ' + m); } }
function fresh() {
  var R = new N.ResourceManager({ Economy: E, Save: N.Save });
  R.state = N.Save.normalize(null, Date.now()); R.state.planetBuild = PB.defaultState(); R.saveNow = function () {};
  E.ORDER.forEach(function (id) { R.state.res[id] = 1e6; }); return R;
}
var ids = ['warehouse', 'harvester', 'chrono', 'refinery', 'condenser'];
ids.forEach(function (t) { var d = PB.CATALOG[t]; ok(d && PB.ORDER.indexOf(t) >= 0 && d.effect && d.badge && d.info, t + ' au catalogue avec effet'); ok(Object.keys(d.base).length <= 2, t + ' : ≤ 2 ressources de coût'); });
ok(PB.ORDER.length === 19 && PB.ORDER.every(function (t) { return PB.CATALOG[t]; }), '19 bâtiments, tous définis');

// --- Entrepôt : +10 % de stockage chacun
var R = fresh(), cap0 = R.cap('metal'), n = 0;
for (var i = 0; i < 4; i++) { ok(PB.place(R, 'warehouse', i * 60, 0, []).ok, 'entrepôt ' + (i + 1)); }
ok(!PB.place(R, 'warehouse', 200, 0, []).ok && PB.place(R, 'warehouse', 200, 0, []).reason === 'max', '5e entrepôt refusé');
ok(Math.abs(R.cap('metal') / cap0 - 1.4) < 1e-3, 'stockage ×1,4 avec 4 entrepôts (' + cap0 + ' → ' + R.cap('metal') + ')');
var id = R.state.planetBuild.items[0].id; PB.recycle(R, id); ok(Math.abs(R.cap('metal') / cap0 - 1.3) < 1e-3, 'recyclage retire le bonus de stockage');

// --- Foreuse : +8 % de récolte manuelle (RNG fixé pour comparer sans critique)
R = fresh(); R.rng = function () { return 0.99; }; R.state.res.crystal = 0;
var y0 = R.tap('crystal', 1e12).requested; R.state.res.crystal = 0;
ok(PB.place(R, 'harvester', 0, 0, []).ok && PB.place(R, 'harvester', 60, 0, []).ok, 'foreuses posées');
R.state.res.crystal = 0; R.state.nodes.crystal.ch = 8; var y1 = R.tap('crystal', 2e12).requested;
ok(Math.abs(y1 / y0 - 1.16) < 1e-6, 'récolte +16 % avec 2 foreuses (' + y0.toFixed(2) + ' → ' + y1.toFixed(2) + ')');

// --- Raffinerie / Condenseur : bonus ciblés par ressource
R = fresh(); var base = R.rates(), b = {}; E.ORDER.forEach(function (k) { b[k] = base[k]; });
ok(PB.place(R, 'refinery', 0, 0, []).ok && R._rates === null, 'raffinerie posée, cache invalidé');
var a = R.rates();
ok(a.metal > b.metal && a.dust > b.dust && Math.abs(a.crystal - b.crystal) < 1e-12 && Math.abs(a.energy - b.energy) < 1e-12, 'raffinerie : métal & poussière seulement');
ok(PB.place(R, 'condenser', 60, 0, []).ok, 'condenseur posé');
var c2 = R.rates(); ok(c2.energy > b.energy && c2.crystal > b.crystal && Math.abs(c2.metal - a.metal) < 1e-12, 'condenseur : énergie & cristaux seulement');
ok(Math.abs(PB.resBonus(R.state.planetBuild, 'metal') - 0.08) < 1e-9 && PB.resBonus(R.state.planetBuild, 'core') === 0, 'resBonus exact');
// s'additionne à la tour de relais (même multiplicateur)
PB.place(R, 'tower', 120, 0, []); var c3 = R.rates(); ok(c3.metal > a.metal, 'tour + raffinerie se cumulent');

// --- Chronodôme : +8 pts d'efficacité hors ligne, plafonné à 100 %
R = fresh(); R.state.res.metal = 0; R.state.lastSeen = 0;
var g0 = (function () { var r = fresh(); r.state.res.metal = 0; r._applyOffline(3600, Date.now()); return r.state.res.metal; })();
ok(PB.place(R, 'chrono', 0, 0, []).ok && PB.place(R, 'chrono', 60, 0, []).ok, 'chronodômes posés');
R.state.res.metal = 0; R._applyOffline(3600, Date.now());
var ratio = R.state.res.metal / g0; ok(Math.abs(ratio - (0.6 + 0.16) / 0.6) < 0.01, 'hors ligne ×' + ratio.toFixed(3) + ' (attendu ' + ((0.76) / 0.6).toFixed(3) + ')');
PB.place(R, 'chrono', 120, 0, []); ok(PB.effectSum(R.state.planetBuild, 'offlineEff') <= 0.24 + 1e-9, 'max 3 chronodômes = +24 pts');

// --- Sauvegarde : types inconnus toujours filtrés, nouveaux types conservés, limites respectées
var norm = PB.normalizeState({ items: [{ id: 'a', type: 'warehouse', lon: 1, lat: 1 }, { id: 'b', type: 'faux', lon: 1, lat: 1 }, { id: 'c', type: 'chrono', lon: 'x', lat: 0 },
  { id: 'd', type: 'condenser', lon: 10, lat: 10 }] });
ok(norm.items.length === 2 && norm.items[0].type === 'warehouse' && norm.items[1].type === 'condenser', 'normalisation OK');
ok(PB.effectSum(null, 'tap') === 0 && PB.resBonus({}, 'metal') === 0 && PB.effectSum({ items: [{ type: 'zzz' }] }, 'storage') === 0, 'entrées invalides sans erreur');
console.log(checks + ' vérifications, ' + fails + ' échec(s)'); process.exit(fails ? 1 : 0);
