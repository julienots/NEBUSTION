/* Tests des QG de bots « considérés comme des joueurs » (NEBUSTION.BotBases), Node, sans Phaser.
 * Lancer : node tests/botBases.test.js */
'use strict';
const E = require('./progress-env');
const t = E.makeCounter(), ok = t.ok, section = t.section;
const B = NEBUSTION.BotBases, Q = NEBUSTION.QGGrid, GAL = NEBUSTION.Galaxy;

section('Profil « joueur »');
{
  GAL.EMPIRE_ORDER.forEach(eid => {
    const p = B.profile(eid, 3);
    ok(typeof p.handle === 'string' && p.handle.length > 2 && p.handle !== eid.toUpperCase() + '_bot', eid + ' : pseudo dédié');
  });
  const handles = GAL.EMPIRE_ORDER.map(B.handleOf);
  ok(new Set(handles).size === handles.length, 'pseudos tous différents');
  ok(B.profile('vexor', 0).level < B.profile('vexor', 8).level, 'le niveau croît avec le développement');
  ok(B.profile('vexor', 0).qgLevel >= 1 && B.profile('vexor', 99).qgLevel <= 10, 'niveau de QG borné 1..10');
  ok(B.profile('vexor', 8).rank !== B.profile('vexor', 0).rank, 'le grade évolue');
  ok(B.profile('vexor', NaN).level === B.profile('vexor', 0).level, 'evo invalide → niveau de départ');
  ok(B.handleOf('inconnu').indexOf('INCONNU') === 0, 'pseudo de secours pour un empire inconnu');
}

section('Plan de structures');
{
  const a = B.structurePlan(0, 0), b = B.structurePlan(8, 0), c = B.structurePlan(8, 1);
  ok(a.turret >= 1 && a.generator >= 1 && a.silo >= 1, 'tout empire a au moins 1 de chaque');
  ok(b.turret > a.turret && b.generator > a.generator && b.silo > a.silo, 'plus développé → plus de structures');
  ok(c.turret < b.turret, 'traumatisme maximal → moins de tourelles');
  ok(c.generator === b.generator && c.silo === b.silo, 'le traumatisme ne touche que les tourelles');
  Object.keys(b).forEach(k => ok(b[k] <= Q.STRUCTURES[k].maxCount, k + ' respecte le plafond du QG joueur'));
}

section('Disposition du QG bot');
{
  GAL.EMPIRE_ORDER.forEach(eid => {
    [0, 2, 5, 8].forEach(evo => [0, 0.5, 1].forEach(hurt => {
      const L = B.layout(eid, evo, hurt), plan = B.structurePlan(evo, hurt);
      const ks = Object.keys(L.cells);
      ok(ks.every(k => L.unlocked[k]), `${eid} evo${evo} hurt${hurt} : structures sur parcelles ouvertes`);
      ok(Object.keys(L.unlocked).every(k => Q.inBounds(Q.parseKey(k).x, Q.parseKey(k).y)), 'parcelles dans la grille');
      const c = B.structureCounts(L);
      ok(c.turret === plan.turret && c.generator === plan.generator && c.silo === plan.silo, `${eid} evo${evo} : comptes conformes au plan`);
      ok(Object.keys(L.unlocked).length >= ks.length, 'assez de parcelles');
    }));
  });
  const A = JSON.stringify(B.layout('vexor', 5, 0.2)), A2 = JSON.stringify(B.layout('vexor', 5, 0.2));
  ok(A === A2, 'déterministe : même état → même QG');
  ok(JSON.stringify(B.layout('vexor', 5, 0.2)) !== JSON.stringify(B.layout('kael9', 5, 0.2)), 'empires différents → QG différents');
  // Tourelles en périphérie : plus loin du centre que les générateurs
  const L = B.layout('morvak', 8, 0), cx = (Q.COLS - 1) / 2, cy = (Q.ROWS - 1) / 2;
  const dist = k => { const p = Q.parseKey(k); return Math.hypot(p.x - cx, p.y - cy); };
  const avg = sid => { const ks = Object.keys(L.cells).filter(k => L.cells[k] === sid); return ks.reduce((s, k) => s + dist(k), 0) / ks.length; };
  ok(avg('turret') > avg('generator'), 'tourelles plus en périphérie que les générateurs');
  ok(Object.keys(B.layout('vexor', 8, 0).unlocked).length <= Q.MAX_CELLS, 'jamais plus de parcelles que la grille');
}

section('Comptes avec structures détruites');
{
  const L = B.layout('elyra', 6, 0), first = Object.keys(L.cells)[0];
  const full = B.structureCounts(L), less = B.structureCounts(L, { [first]: true });
  ok(Object.values(full).reduce((a, b) => a + b, 0) === Object.values(less).reduce((a, b) => a + b, 0) + 1, 'une structure détruite en moins');
}

section('Mise en scène du combat');
{
  const L = B.layout('vexor', 8, 0), nT = B.structureCounts(L).turret;
  const V = B.battlePlan(L, true, 123);
  const all = V.order.map(o => o.key).concat(V.rest);
  ok(V.order.every(o => o.kind === 'destroy'), 'victoire : tirs destructeurs');
  ok(V.turrets.length === nT, 'toutes les tourelles listées');
  ok(V.turrets.every(k => all.indexOf(k) >= 0), 'victoire : toutes les tourelles sont détruites');
  ok(new Set(all).size === all.length, 'aucune cible en double');
  ok(all.every(k => L.cells[k]), 'cibles = vraies structures');
  ok(V.order.length <= 6, 'au plus 6 tirs visibles');
  const total = Object.keys(L.cells).length;
  ok(all.length < total && all.length >= nT, 'victoire : pas tout détruit, au moins les tourelles');
  ok(JSON.stringify(B.battlePlan(L, true, 123)) === JSON.stringify(V), 'même graine → même mise en scène');

  const D = B.battlePlan(L, false, 5);
  ok(D.rest.length === 0 && D.order.every(o => o.kind !== 'destroy'), 'défaite : rien de détruit');
  ok(D.order.length >= 1 && D.order.length <= 3, 'défaite : 1 à 3 tirs absorbés');
  const small = B.layout('vexor', 0, 0);
  ok(B.battlePlan(small, true, 1).order.length >= 1, 'petit QG : au moins une cible');
}

t.done('QG de bots (joueurs adverses)');
