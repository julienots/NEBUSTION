/* Tests des expéditions (NEBUSTION.Expeditions + ExpeditionManager), Node, sans Phaser.
 * Lancer : node tests/expeditions.test.js */
'use strict';
const E = require('./progress-env');
const t = E.makeCounter(), ok = t.ok, section = t.section;
const EX = NEBUSTION.Expeditions, XM = NEBUSTION.ExpeditionManager, C = NEBUSTION.Combat;
const MIN = 60000, HOUR = 3600000;

section('Catalogue de missions');
{
  const all = EX.allMissions();
  ok(all.length === 24 && new Set(all.map(m => m.id)).size === 24, '24 missions (4 types × 6 difficultés), identifiants uniques');
  ok(EX.TYPE_ORDER.length === 4 && EX.DIFF_ORDER.length === 6, '4 types, 6 difficultés');
  ok(all.filter(m => m.typeId === 'eclair').every(m => m.durationSec === 0 && m.cooldownSec === 900), 'Éclair : durée 0, recharge 15 min');
  ok(all.filter(m => m.typeId !== 'eclair').every(m => m.durationSec > 0 && m.cooldownSec === 0), 'autres types : durée > 0, pas de recharge');
  ok(all.every(m => m.minHeroes >= 1 && m.maxHeroes >= m.minHeroes && m.powerReq > 0 && m.minLevel >= 1 && m.name && m.favoredRole), 'champs valides sur chaque mission');
  const d = t => all.filter(m => m.typeId === t)[0].durationSec;
  ok(d('courte') < d('longue') && d('longue') < d('epique'), 'durées croissantes Courte < Longue < Épique');
  ok(EX.mission('m_courte_facile') && EX.mission('inconnue') === null && EX.mission('__proto__') === null, 'mission() : connue / inconnue / prototype');
  const ab = EX.mission('m_courte_abyssal'), my = EX.mission('m_courte_mythique');
  ok(ab.unlockPrestige === 1 && my.unlockPrestige === 3, 'Abyssal = Renaissance 1, Mythique = Renaissance 3');
  ok(!EX.isUnlocked(ab, 99, 0) && EX.isUnlocked(ab, 20, 1) && !EX.isUnlocked(ab, 19, 1), 'isUnlocked : étoiles ET Renaissance requises');
  ok(!EX.isUnlocked(my, 99, 2) && EX.isUnlocked(my, 99, 3), 'Mythique verrouillée avant la Renaissance 3');

  const courte = EX.mission('m_courte_facile'), longue = EX.mission('m_longue_facile'), epique = EX.mission('m_epique_facile');
  ok(courte.unlockQG === 1 && longue.unlockQG === 3 && epique.unlockQG === 6, 'unlockQG croissant : Courte 1, Longue 3, Épique 6');
  ok(EX.isUnlocked(courte, 0, 0, 1) && !EX.isUnlocked(longue, 0, 0, 1) && !EX.isUnlocked(epique, 0, 0, 5), 'Longue/Épique verrouillées tant que le QG n\'a pas le niveau requis');
  ok(EX.isUnlocked(longue, 0, 0, 3) && EX.isUnlocked(epique, 0, 0, 6), 'Longue/Épique déverrouillées au bon niveau de QG');
  ok(EX.isUnlocked(courte, 0, 0), 'qgLevel omis → équivaut à niveau 1 (compatibilité)');
}

section('Formules de récompense');
{
  const m = EX.mission('m_longue_normal');
  const lo = EX.qualityScale(m, 0), hi = EX.qualityScale(m, m.powerReq * 50), mid = EX.qualityScale(m, m.powerReq);
  ok(lo.scale === EX.SCALE_MIN && hi.scale === EX.SCALE_MAX && Math.abs(mid.scale - 1) < 1e-9, 'qualité bornée [0,4 ; 1,6], = 1 à la puissance recommandée');
  const a = EX.rewardsFor(m, m.powerReq, 7), b = EX.rewardsFor(m, m.powerReq, 7), c = EX.rewardsFor(m, m.powerReq, 8);
  ok(JSON.stringify(a) === JSON.stringify(b), 'rewardsFor déterministe pour une même graine');
  ok(JSON.stringify(a.res) !== JSON.stringify(c.res) || a.gems !== c.gems, 'la graine fait varier la récompense');
  const weak = EX.rewardsFor(m, m.powerReq * 0.1, 7), strong = EX.rewardsFor(m, m.powerReq * 2, 7);
  ok(strong.res.crystal > a.res.crystal && a.res.crystal > weak.res.crystal, 'plus de puissance → plus de ressources');
  ok(!weak.success && a.success && strong.success, 'succès à partir de 60 % de la puissance recommandée');
  ok(weak.res.crystal > 0 && weak.fragments >= 1 && weak.xp >= 1, 'une équipe faible gagne quand même quelque chose (pas de perte sèche)');
  const rm = EX.rewardsFor(m, m.powerReq, 7, null, { roleMatch: true });
  ok(rm.res.crystal > a.res.crystal && Math.abs(rm.res.crystal / a.res.crystal - 1 - EX.ROLE_BONUS) < 0.02, 'rôle recommandé ≈ +12 %');
  const rich = EX.rewardsFor(m, m.powerReq, 7, { crystal: 1e6, metal: 1e6, energy: 1e6, core: 1e6, dust: 1e6 });
  ok(rich.res.crystal > a.res.crystal * 100, 'proportionnel à la production actuelle du joueur');
  const nz = EX.rewardsFor(m, m.powerReq, 7, { crystal: 0, metal: 0, energy: 0, core: 0, dust: 0 });
  ok(nz.res.crystal === a.res.crystal || nz.res.crystal > 0, 'production nulle → plancher = production de départ');
  const mult = k => EX.rewardsFor(EX.mission('m_courte_' + k), EX.mission('m_courte_' + k).powerReq, 3).res.crystal;
  ok(mult('mythique') > mult('cauchemar') && mult('cauchemar') > mult('facile'), 'la difficulté augmente la récompense');
  ok(EX.mission('m_eclair_facile').durationSec === 0 && EX.rewardsFor(EX.mission('m_eclair_facile'), 900, 1).res.crystal > 0, 'Éclair : récompense calculée');
  ok(EX.rewardsFor(EX.mission('m_epique_mythique'), 1e9, 5).gems >= 0 && EX.baseRates().crystal > 0, 'baseRates > 0');
}

// ---------- Partie simulée ----------
const g = E.freshGame(), R = g.R;
const H = E.freeHeroes();
H.slice(0, 8).forEach(id => E.setLevel(id, 60));
E.giveStars(25);
R.state.buildings.qg.level = 10; // QG au max pour tester les autres verrous indépendamment
const T0 = E.local(2026, 8, 21, 12);

section('Emplacements');
{
  ok(XM.maxSlots() === 2 && XM.freeSlots() === 2 && XM.usedSlots() === 0, '2 emplacements de base');
  R.state.prestige.spent.expeditionSlot = 1; ok(XM.maxSlots() === 3, '+1 emplacement avec la Renaissance');
  R.state.prestige.spent.expeditionSlot = 3; ok(XM.maxSlots() === 5, 'jusqu\'à 5 emplacements');
  R.state.prestige.spent.expeditionSlot = 99; ok(XM.maxSlots() === 5, 'plafonné à 5');
  R.state.prestige.spent.expeditionSlot = 0; ok(XM.maxSlots() === 2, 'retour à 2');
}

section('Vérifications avant lancement (canLaunch)');
{
  ok(XM.canLaunch('nope', [H[0]], T0).reason === 'invalide', 'mission inconnue → invalide');
  ok(XM.canLaunch('m_courte_abyssal', [H[0]], T0).reason === 'verrouille', 'Abyssal sans Renaissance → verrouillée');
  ok(XM.lockReason(EX.mission('m_courte_abyssal')).indexOf('Renaissance') >= 0, 'lockReason mentionne la Renaissance');
  ok(XM.lockReason(EX.mission('m_courte_facile')) === null, 'mission Facile : pas de verrou');
  E.giveStars(2); ok(XM.canLaunch('m_courte_normal', [H[0]], T0).reason === 'verrouille' && /étoiles/.test(XM.lockReason(EX.mission('m_courte_normal'))), 'Normal sans 4 étoiles → verrouillée (étoiles)');
  E.giveStars(25);
  ok(XM.totalStars() === 25, 'totalStars = 25');
  const weakId = H[10]; E.setLevel(weakId, 1);
  ok(XM.canLaunch('m_courte_normal', [weakId], T0).reason === 'niveau', 'héros niveau 1 refusé sur Normal (niveau 4 requis)');
  ok(XM.heroEligibility(weakId, EX.mission('m_courte_normal')).reason === 'niveau' && XM.heroEligibility('zzz', EX.mission('m_courte_normal')).reason === 'inconnu', 'heroEligibility : niveau / inconnu');
  const shopHero = NEBUSTION.Heroes.all().filter(h => h.shop)[0];
  if (shopHero) ok(XM.heroEligibility(shopHero.id, EX.mission('m_courte_facile')).reason === 'inconnu', 'héros de Boutique non recruté → inconnu');
  ok(XM.canLaunch('m_longue_facile', [H[0]], T0).reason === 'heros_min', 'Longue : 2 héros minimum');

  R.state.buildings.qg.level = 1;
  ok(XM.canLaunch('m_longue_facile', [H[0], H[1]], T0).reason === 'verrouille', 'Longue verrouillée sous QG niv.3');
  ok(XM.lockReason(EX.mission('m_longue_facile')).indexOf('Quartier Général') >= 0, 'lockReason mentionne le Quartier Général');
  ok(XM.qgLevel() === 1, 'qgLevel() lit le niveau du bâtiment QG');
  R.state.buildings.qg.level = 10; // on remet le niveau haut pour la suite des tests
  ok(XM.canLaunch('m_eclair_facile', [H[0], H[1]], T0).reason === 'heros_max', 'Éclair : 1 héros maximum');
  ok(XM.canLaunch('m_courte_facile', [], T0).reason === 'heros_min', 'aucun héros → refusé');
  const dup = XM.canLaunch('m_courte_facile', [H[0], H[0]], T0);
  ok(dup.ok && dup.heroIds.length === 1, 'doublons de héros dédupliqués');
}

section('Éclair : instantanée + recharge');
{
  const before = { dust: R.state.res.dust, crystal: R.state.res.crystal };
  const r = XM.launch('m_eclair_facile', [H[0]], T0);
  ok(r.ok && r.reward && r.reward.res && r.delivered, 'Éclair résolue tout de suite (reward + delivered)');
  ok(R.state.res.crystal > before.crystal || R.state.res.dust > before.dust, 'ressources créditées');
  ok(XM.usedSlots() === 0 && !XM.isBusy(H[0]), 'aucun emplacement ni héros occupé après une Éclair');
  ok(XM.cooldownLeft('m_eclair_facile', T0) > 14 * MIN, 'recharge de 15 min enclenchée');
  ok(XM.canLaunch('m_eclair_facile', [H[0]], T0 + MIN).reason === 'recharge', 'relance immédiate refusée (recharge)');
  ok(XM.canLaunch('m_eclair_facile', [H[0]], T0 + 16 * MIN).ok || XM.canLaunch('m_eclair_facile', [H[0]], T0 + 16 * MIN).reason !== 'recharge', 'relançable après 15 min');
  ok(XM.canLaunch('m_eclair_normal', [H[0]], T0).ok, 'la recharge est propre à chaque mission');
  ok(typeof r.reward.gems === 'number' && typeof r.reward.fragments === 'number', 'reward.gems / reward.fragments (pluriel)');
}

section('Expédition différée : lancement, héros occupés, réclamation');
{
  const stat0 = XM.stats().sent;
  const r = XM.launch('m_courte_facile', [H[1], H[2]], T0);
  ok(r.ok && r.instant === false && r.entry && r.entry.endsAt === T0 + 20 * MIN, 'lancement différé (fin = début + 20 min)');
  ok(XM.usedSlots() === 1 && XM.freeSlots() === 1 && XM.stats().sent === stat0 + 1, 'un emplacement pris, compteur « envoyées » +1');
  ok(XM.isBusy(H[1]) && XM.isBusy(H[2]) && !XM.isBusy(H[3]), 'héros envoyés = occupés, les autres libres');
  ok(XM.canLaunch('m_courte_facile', [H[1]], T0).reason === 'occupe', 'un héros occupé ne peut pas repartir');
  ok(XM.heroEligibility(H[1], EX.mission('m_courte_facile')).reason === 'occupe', 'heroEligibility : occupé');
  ok(XM.timeLeft(r.entry, T0) === 20 * MIN && !XM.isReady(r.entry, T0) && XM.readyCount(T0) === 0, 'en cours : temps restant, pas prêt');
  ok(XM.claim(r.entry.id, T0 + 5 * MIN).reason === 'en_cours', 'réclamation avant la fin refusée');
  ok(XM.claim('inexistant', T0).reason === 'introuvable', 'réclamation d\'une entrée inconnue refusée');
  ok(XM.readyCount(T0 + 21 * MIN) === 1 && XM.listActive(T0 + 21 * MIN)[0].ready, 'prête après 20 min');
  // Membres de l'équipe de combat occupés
  C.setTeam([H[1], H[3], H[4], H[5], H[6]]);
  ok(XM.busyTeamMembers().length === 1 && XM.busyTeamMembers()[0] === H[1], 'busyTeamMembers repère un héros d\'équipe en expédition');
  const crystal0 = R.state.res.crystal, frag0 = R.state.combat.fragments[H[1]] || 0, comp0 = XM.stats().completed;
  const c1 = XM.claim(r.entry.id, T0 + 21 * MIN);
  ok(c1.ok && c1.reward && c1.heroIds.length === 2 && c1.mission.id === 'm_courte_facile', 'claim OK');
  ok(R.state.res.crystal > crystal0, 'ressources créditées');
  ok((R.state.combat.fragments[H[1]] || 0) > frag0, 'fragments crédités aux héros envoyés');
  ok(XM.stats().completed === comp0 + 1 && XM.usedSlots() === 0 && !XM.isBusy(H[1]), 'stats +1, emplacement et héros libérés');
  ok(XM.busyTeamMembers().length === 0, 'plus aucun membre d\'équipe occupé');
  const c2 = XM.claim(r.entry.id, T0 + 22 * MIN);
  ok(!c2.ok && c2.reason === 'introuvable', 'DOUBLE réclamation impossible (pas de double versement)');
}

section('Emplacements pleins, annulation, tout réclamer');
{
  const a = XM.launch('m_courte_facile', [H[1]], T0), b = XM.launch('m_longue_facile', [H[2], H[3]], T0);
  ok(a.ok && b.ok && XM.freeSlots() === 0, '2 expéditions simultanées : emplacements pleins');
  ok(XM.canLaunch('m_courte_facile', [H[4]], T0).reason === 'emplacements', 'troisième refusée : emplacements');
  const cx = XM.cancel(a.entry.id);
  ok(cx.ok && !XM.isBusy(H[1]) && XM.freeSlots() === 1, 'annulation : héros et emplacement libérés');
  ok(XM.cancel(a.entry.id).reason === 'introuvable', 'annulation d\'une entrée déjà retirée refusée');
  const c0 = R.state.res.crystal;
  ok(XM.claimAll(T0 + 1 * MIN).length === 0 && R.state.res.crystal === c0, 'claimAll : rien à réclamer tant que rien n\'est fini');
  const d = XM.launch('m_courte_facile', [H[4]], T0);
  const all = XM.claimAll(T0 + 30 * MIN);
  ok(all.length === 1 && all[0].ok && d.ok && XM.usedSlots() === 1, 'claimAll : réclame les expéditions terminées seulement (la Longue reste en cours)');
  ok(XM.claimAll(T0 + 30 * MIN).length === 0, 'claimAll idempotent');
  ok(XM.claimAll(T0 + 4 * HOUR).length === 1 && XM.usedSlots() === 0, 'la Longue est réclamable après 3 h');
}

section('Catalogue affiché (availableMissions)');
{
  const list = XM.availableMissions(T0);
  ok(list.length === 24 && list.every(m => typeof m.unlocked === 'boolean' && m.cooldownLeft >= 0), '24 missions avec verrou et recharge');
  ok(list.find(m => m.id === 'm_courte_facile').unlocked && !list.find(m => m.id === 'm_courte_mythique').unlocked, 'verrous cohérents');
  ok(XM.heroPower(H[0]) > 0 && XM.heroPower('zzz') === 0 && XM.teamPowerOf([H[0], H[1]]) === XM.heroPower(H[0]) + XM.heroPower(H[1]), 'puissance : héros / inconnu / somme');
  R.state.prestige.spent.combatPower = 10;
  ok(XM.heroPower(H[0]) > Math.round(XM.heroPower(H[0]) / 1.15), 'le bonus Renaissance « combatPower » augmente la puissance');
  R.state.prestige.spent.combatPower = 0;
}

section('Robustesse de normalizeState');
{
  const now = T0;
  ok(XM.normalizeState(null, now).active.length === 0 && XM.normalizeState('x', now).active.length === 0 && XM.normalizeState(42, now).stats.sent === 0, 'entrées nulles / absurdes → état neuf');
  const junk = XM.normalizeState({ active: [null, 5, 'x', { missionId: 'nope', heroIds: ['a'] }, { missionId: 'm_courte_facile', heroIds: [] }, { missionId: 'm_courte_facile', heroIds: [1, 2, {}] }], cooldowns: { zzz: 5 }, history: 'x', stats: { sent: -4, completed: 'a' } }, now);
  ok(junk.active.length === 0 && Object.keys(junk.cooldowns).length === 0 && junk.history.length === 0 && junk.stats.sent === 0 && junk.stats.completed === 0, 'entrées invalides écartées, stats bornées à 0');
  const far = XM.normalizeState({ active: [{ id: 'e1', missionId: 'm_courte_facile', heroIds: ['a', 'a', 'b', 'c'], startedAt: now + 9e12, endsAt: now + 9e15, seed: 'x', teamPower: -5 }], cooldowns: { m_eclair_facile: now + 9e15, m_eclair_normal: now - 5 } }, now);
  const en = far.active[0];
  ok(en && en.heroIds.length === 2 && en.startedAt <= now && en.endsAt <= en.startedAt + 20 * MIN, 'héros dédupliqués et limités, dates ramenées à des valeurs légitimes');
  ok(en.teamPower === 0 && en.seed === 1, 'puissance négative et graine invalide corrigées');
  ok(far.cooldowns.m_eclair_facile <= now + 15 * MIN && !('m_eclair_normal' in far.cooldowns), 'recharge plafonnée à 15 min, recharges échues supprimées');
  const many = XM.normalizeState({ history: Array.from({ length: 50 }, (_, i) => ({ i })) }, now);
  ok(many.history.length === 20, 'historique limité à 20 entrées');
}

section('Sauvegarde aller-retour (hors ligne : dates absolues)');
{
  const s = XM.launch('m_longue_facile', [H[6], H[7]], T0);
  R.saveNow(T0);
  const loaded = NEBUSTION.Save.load().state;
  ok(loaded && loaded.expeditions && loaded.expeditions.active.some(a => a.id === s.entry.id), 'l\'expédition est dans la sauvegarde');
  const norm = NEBUSTION.Save.normalize(JSON.parse(JSON.stringify(loaded)), T0 + 2 * HOUR);
  const back = norm.expeditions.active.find(a => a.id === s.entry.id);
  ok(back && back.endsAt === s.entry.endsAt && back.heroIds.join() === s.entry.heroIds.join(), 'après rechargement, mêmes héros et même date de fin');
  const old = NEBUSTION.Save.normalize({ v: 6 }, T0);
  ok(old.expeditions && old.expeditions.active.length === 0 && old.events && old.prestige && old.achievements, 'sauvegarde v6 (sans les nouveaux champs) migrée avec des états neufs');
}

t.done('TESTS EXPÉDITIONS');
