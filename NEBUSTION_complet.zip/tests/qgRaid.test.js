/* Tests des raids ennemis contre le QG (NEBUSTION.QGRaid + QGRaidManager). Node, sans Phaser.
 * Lancer : node tests/qgRaid.test.js */
'use strict';
global.window = global;
require('../js/data/Economy.js'); require('../js/data/Heroes.js'); require('../js/data/Enemies.js'); require('../js/data/Galaxy.js');
require('../js/data/EmpireAI.js'); require('../js/data/EmpireDoctrine.js'); require('../js/data/EmpireEvolution.js');
require('../js/data/Security.js'); require('../js/data/QGGrid.js'); require('../js/data/QGRaid.js');
require('../js/systems/SaveManager.js'); require('../js/systems/ResourceManager.js'); require('../js/systems/CombatEngine.js');
require('../js/systems/CombatManager.js'); require('../js/systems/GalaxyManager.js'); require('../js/systems/EmpireAIManager.js');
require('../js/systems/EmpireEvolutionManager.js'); require('../js/systems/SecurityManager.js'); require('../js/systems/QGGridManager.js');
require('../js/systems/QGRaidManager.js');

const D = NEBUSTION.QGRaid, EM = NEBUSTION.EmpireEvolutionManager, GM = NEBUSTION.GalaxyManager, RM = NEBUSTION.QGRaidManager, Save = NEBUSTION.Save;
let passed = 0, failed = 0;
function ok(c, m) { if (c) passed++; else { failed++; console.log('  ✗ ECHEC : ' + m); } }
function section(t) { console.log('\n# ' + t); }
function memStorage() { const m = {}; return { data: m, getItem: k => (k in m ? k in m ? m[k] : null : null), setItem: (k, v) => { m[k] = String(v); }, removeItem: k => { delete m[k]; } }; }
const T0 = 1_800_000_000_000, H = 3600 * 1000, DAY = 24 * H;
let storage;
function fresh(seed, team) {
  storage = memStorage(); Save._useStorage(storage);
  NEBUSTION.Resources = new NEBUSTION.ResourceManager(); NEBUSTION.Resources.init(T0);
  NEBUSTION.Resources.state.empires.seed = seed || 12345;
  NEBUSTION.Resources.state.qgRaid.seed = seed || 12345;
  NEBUSTION.Galaxy.SECTORS.forEach(s => { GM.state().unlocked[s.id] = true; });
  GM.teamLevel = () => (team == null ? 45 : team);
  EM.stop(); RM.stop();
  return NEBUSTION.Resources;
}
/** Fait avancer les empires (élan/développement) ET les raids, en pas de 6 h, sur `days` jours. */
function run(days, from) {
  let t = from || T0;
  for (let i = 0; i < days * 4; i++) { t += 6 * H; EM.update(t); RM.update(t); }
  return t;
}

section('QGRaid — formules pures');
{
  ok(D.STEP_MS === 1800000 && D.MAX_CATCHUP_STEPS === 48, 'pas de 30 min, rattrapage max 24 h (même patron que EmpireEvolution)');
  ok(D.attackPower(0, 0, 0) < D.attackPower(4, 0, 0) && D.attackPower(4, 0, 0) < D.attackPower(8, 0, 0), 'puissance d\'attaque croissante avec le développement (evo)');
  ok(D.attackPower(4, 1, 0) > D.attackPower(4, 0, 0), 'l\'élan (momentum) augmente la puissance d\'attaque');
  ok(D.attackPower(4, 0, 1) < D.attackPower(4, 0, 0), 'le traumatisme (hurt) réduit la puissance d\'attaque');
  ok(D.defenseChance(10, 10) === 0.5, 'défense = attaque -> 50 / 50');
  ok(D.defenseChance(20, 5) > D.defenseChance(10, 10) && D.defenseChance(10, 10) > D.defenseChance(5, 20), 'chance de défense croissante avec l\'écart défense - attaque');
  ok(D.defenseChance(0, 999) >= 0 && D.defenseChance(999, 0) <= 1, 'chance de défense toujours dans [0,1]');
  const lf1 = D.lossFraction(20, 5), lf2 = D.lossFraction(5, 20);
  ok(lf1 >= D.LOSS_MIN && lf1 <= D.LOSS_MAX && lf2 >= D.LOSS_MIN && lf2 <= D.LOSS_MAX, 'part perdue toujours dans [LOSS_MIN, LOSS_MAX]');
  ok(lf2 > lf1, 'pillage plus lourd quand l\'attaque dépasse largement la défense');
  const a = D.rand01(7, 3, 5), b = D.rand01(7, 3, 5);
  ok(a === b && a >= 0 && a < 1 && D.rand01(7, 4, 5) !== a, 'aléa déterministe et dans [0,1)');
}

section('QGRaid — normalizeState résiste aux données abîmées');
{
  const n = D.normalizeState(null, T0);
  ok(n.seed >= 1 && n.n === 0 && n.log.length === 0, 'état par défaut : compteur à 0, historique vide');
  const bad = D.normalizeState({ seed: -5, n: 'x', lastRaidAt: -1, log: [null, 42, { empire: 'vexor', at: 5, victory: true, attack: 9, defense: 2, lossPct: 0.3 }, { at: 9 }] }, T0);
  ok(bad.seed >= 1, 'seed invalide corrigée');
  ok(bad.log.length === 1 && bad.log[0].empire === 'vexor', 'entrées d\'historique invalides ignorées, la valide conservée');
  const long = D.normalizeState({ log: Array.from({ length: 20 }, (_, i) => ({ empire: 'vexor', at: i, victory: false, attack: 1, defense: 1, lossPct: 0 })) }, T0);
  ok(long.log.length === D.LOG_MAX, 'historique tronqué à LOG_MAX entrées (les plus récentes)');
}

section('QGRaidManager — non-régression sauvegarde (nouvelle partie)');
{
  const R = fresh();
  ok(R.state.qgRaid && Array.isArray(R.state.qgRaid.log) && R.state.qgRaid.log.length === 0, 'une nouvelle partie initialise qgRaid sans historique');
  ok(RM.update(T0).steps === 0, 'aucun pas à rattraper au même instant');
  ok(RM.log(T0).length === 0, 'aucun raid au démarrage');
  ok(RM.consumeReport(T0) === null, 'rien à consommer sans raid');
}

section('QGRaidManager — simulation : des raids surviennent, cooldown respecté, pillage borné');
{
  let anyRaid = false, seenSeeds = 0;
  for (let seed = 1; seed <= 8; seed++) {
    fresh(seed * 9973 + 1, 50);
    const end = run(45); // 45 jours simulés : largement assez pour dépasser MIN_EVO et déclencher au moins un tirage
    const log = RM.log(end);
    if (log.length) { anyRaid = true; seenSeeds++; }
    for (let i = 1; i < log.length; i++) {
      ok(log[i].at - log[i - 1].at >= D.MIN_GAP_MS, 'cooldown minimum respecté entre deux raids (seed ' + seed + ')');
    }
    log.forEach(e => {
      if (e.victory) ok(e.lossPct >= D.LOSS_MIN && e.lossPct <= D.LOSS_MAX, 'pillage borné sur raid réussi');
      else ok(e.lossPct === 0, 'aucune perte sur raid repoussé');
      ok(NEBUSTION.Galaxy.EMPIRE_ORDER.indexOf(e.empire) >= 0, 'empire raider valide');
    });
  }
  ok(anyRaid, 'au moins un raid survient sur 8 parties de 45 jours simulés');
  ok(seenSeeds >= 4, 'les raids ne sont pas un accident isolé : la majorité des parties simulées en subissent');
}

section('QGRaidManager — déterminisme (même seed, même déroulé -> même historique)');
{
  fresh(555222, 60);
  const end1 = run(30);
  const log1 = JSON.stringify(RM.log(end1));

  fresh(555222, 60);
  const end2 = run(30);
  const log2 = JSON.stringify(RM.log(end2));

  ok(log1 === log2, 'rejouer la même sauvegarde (même seed) donne exactement le même historique de raids');
  ok(log1 !== JSON.stringify([]), 'le scénario déterministe ci-dessus produit bien au moins un raid');
}

section('QGRaidManager — rattrapage hors ligne borné (comme EmpireEvolutionManager)');
{
  fresh(4242, 55);
  EM.update(T0 + 5 * DAY);           // développe les empires sans encore vérifier les raids
  const before = RM.state().n;
  const res = RM.update(T0 + 400 * DAY); // très longue absence
  ok(res.steps <= D.MAX_CATCHUP_STEPS, 'jamais plus de MAX_CATCHUP_STEPS vérifications rattrapées en un seul appel');
  ok(RM.state().n === before + res.steps, 'le compteur de pas avance exactement du nombre de vérifications rattrapées');
}

section('QGRaidManager — consumeReport() : consommé une seule fois');
{
  fresh(778899, 55);
  let end = T0, firstReport = null;
  for (let seed = 778899; ; seed += 1) {
    fresh(seed, 55);
    end = run(60);
    if (RM.log(end).length) { firstReport = RM.consumeReport(end); break; }
    if (seed > 778899 + 40) break;
  }
  ok(firstReport && firstReport.raids.length > 0, 'consumeReport() renvoie les raids survenus');
  ok(RM.consumeReport(end) === null, 'un second appel immédiat ne renvoie rien de neuf (déjà consommé)');
}

const label = 'Tests QGRaid (raids du QG)';
console.log('\n' + (failed ? '✘ ' : '✔ ') + label + ' : ' + passed + ' réussis, ' + failed + ' échoués');
process.exit(failed ? 1 : 0);
