global.window = global;
var fs = require('fs'), vm = require('vm');
function load(f) { vm.runInThisContext(fs.readFileSync(require('path').join(__dirname, '..', f), 'utf8'), { filename: f }); }
['js/data/Economy.js','js/data/Heroes.js','js/data/Equipment.js','js/data/Skins.js','js/data/Crates.js'].forEach(load);
var K = NEBUSTION.Crates, S = NEBUSTION.Skins, fails = 0, n = 0;
function ok(c, m) { n++; if (!c) { fails++; console.log('FAIL', m); } }

// 1. données
ok(K.TIERS.length === 3, 'tiers');
K.TIERS.forEach(function (t) { var sum = 0; Object.keys(K.CRATES[t].odds).forEach(function (r) { sum += K.CRATES[t].odds[r]; }); ok(sum === 100, 'odds ' + t + '=' + sum); });
['commun','rare','epique','legendaire'].forEach(function (r) { ok(K.skinPool(r).length > 0, 'pool ' + r); ok(K.FORGE_SKIN[r] > 0 && K.DUP_SHARDS[r] > 0, 'costs ' + r); });
ok(K.skinPool('legendaire').every(function (s) { return s.crate || !s.exclusive; }), 'pool exclut exclusivités Pass');
ok(K.skinPool('epique').every(function (s) { return s.id !== 'h_astral' && s.id !== 'b_eclipse'; }), 'pass exclu');

// 2. rollOutcome : distribution + pitié
var rng = (function () { var s = 12345; return function () { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; })();
var counts = { commun: 0, rare: 0, epique: 0, legendaire: 0 }, pity = { epic: 0, leg: 0 }, N = 20000, maxGapE = 0, gapE = 0, maxGapL = 0, gapL = 0;
for (var i = 0; i < N; i++) {
  var o = K.rollOutcome('astral', pity, rng); counts[o.rarity]++; pity = o.pity;
  gapE++; gapL++;
  if (o.rarity === 'epique' || o.rarity === 'legendaire') { maxGapE = Math.max(maxGapE, gapE); gapE = 0; }
  if (o.rarity === 'legendaire') { maxGapL = Math.max(maxGapL, gapL); gapL = 0; }
}
ok(maxGapE <= K.PITY.epic, 'pitié épique max ' + maxGapE);
ok(maxGapL <= K.PITY.leg, 'pitié légendaire max ' + maxGapL);
ok(counts.commun > counts.rare && counts.rare > counts.epique && counts.epique > counts.legendaire, 'ordre des raretés ' + JSON.stringify(counts));
var c2 = { commun: 0, rare: 0, epique: 0, legendaire: 0 }; pity = { epic: 0, leg: 0 };
for (i = 0; i < 5000; i++) { var o2 = K.rollOutcome('singularity', pity, rng); c2[o2.rarity]++; pity = o2.pity; }
ok(c2.commun === 0 && c2.rare === 0, 'singularité ≥ épique');
var c3 = 0; for (i = 0; i < 5000; i++) { if (K.rollOutcome('nebula', { epic: 0, leg: 0 }, rng).rarity === 'commun') c3++; }
ok(c3 === 0, 'nébuleuse ≥ rare');
ok(K.rollOutcome('nope', null) === null, 'palier inconnu');

// 3. pickSkin
var owned = {}; S.SKINS.forEach(function (s) { if (s.rarity === 'legendaire') owned[s.id] = true; });
ok(K.pickSkin('legendaire', owned, rng) !== null, 'pickSkin tout possédé -> doublon');
var fresh = 0; for (i = 0; i < 300; i++) { var pk = K.pickSkin('rare', {}, rng); if (pk) fresh++; } ok(fresh === 300, 'pickSkin');

// 4. état
var st = K.normalizeState({ crates: { astral: 3, bogus: 9 }, keys: { nebula: -5, astral: '4' }, shards: 1e12, pity: { epic: 99, leg: -3 }, history: [{ tier: 'astral', rarity: 'rare', kind: 'skin', label: 'x' }, { tier: 'zzz', rarity: 'rare' }, null] });
ok(st.crates.astral === 3 && st.keys.nebula === 0 && st.keys.astral === 4, 'normalize stacks');
ok(st.pity.epic === K.PITY.epic - 1 && st.pity.leg === 0, 'normalize pity');
ok(st.history.length === 1, 'normalize history');
ok(st.shards <= 9999999, 'shards cap');
ok(JSON.stringify(K.normalizeState(null)) === JSON.stringify(K.defaultState()), 'défaut');
ok(K.forgeSkinCost('h_astral') === null && K.forgeSkinCost('h_seraph') === K.FORGE_SKIN.legendaire && K.forgeSkinCost('xx') === null, 'forge cost');
console.log(n + ' vérifications, ' + fails + ' échec(s)');
process.exit(fails ? 1 : 0);
