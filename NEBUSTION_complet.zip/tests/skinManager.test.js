/* Tests d'intégration de NEBUSTION.SkinManager + sauvegarde v4→v5 (Node, faux ResourceManager). Lancer : node tests/skinManager.test.js */
'use strict';
global.window = global;
global.localStorage = undefined;
require('../js/data/Economy.js');
require('../js/data/Heroes.js');
require('../js/data/Ships.js');
require('../js/data/Skins.js');
require('../js/systems/CombatEngine.js');
require('../js/systems/ShipManager.js');
require('../js/systems/SkinManager.js');
const SM = NEBUSTION.SkinManager, K = NEBUSTION.Skins;

let passed = 0, failed = 0;
function ok(c, m) { if (c) passed++; else { failed++; console.log('  ✗ ECHEC : ' + m); } }
function section(t) { console.log('\n# ' + t); }

let saves = 0;
function fake(res) {
  return {
    state: { res: res, ships: null, skins: null },
    canAfford(cost) { return Object.keys(cost).every(k => (this.state.res[k] || 0) >= cost[k]); },
    spendMany(cost) { if (!this.canAfford(cost)) return false; Object.keys(cost).forEach(k => this.state.res[k] -= cost[k]); return true; },
    saveNow() { saves++; }
  };
}
const RICH = { crystal: 1e5, energy: 1e5, dust: 1e6, core: 500 };

section('Achat');
{
  NEBUSTION.Resources = fake({ crystal: 1000, energy: 1000, dust: 1000, core: 0 });
  const r = SM.buy('h_cyan');
  ok(r.ok && SM.isOwned('h_cyan'), 'achat d\'un skin commun avec assez de ressources');
  ok(NEBUSTION.Resources.state.res.dust === 400 && NEBUSTION.Resources.state.res.crystal === 850, 'coût débité exactement (dust 600, crystal 150)');
  ok(saves > 0, 'sauvegarde déclenchée à l\'achat');
  const again = SM.buy('h_cyan');
  ok(!again.ok && again.reason === 'deja' && NEBUSTION.Resources.state.res.dust === 400, 'racheter un skin possédé : refusé, rien débité');
  const poor = SM.buy('h_spectre');
  ok(!poor.ok && poor.reason === 'ressources' && !SM.isOwned('h_spectre'), 'légendaire refusé sans ressources');
  ok(NEBUSTION.Resources.state.res.dust === 400, 'achat refusé : ressources intactes (atomique)');
  ok(SM.buy('inconnu').reason === 'invalide', 'skin inconnu : invalide');
  ok(SM.buy('constructor').reason === 'invalide' && !SM.isOwned('constructor') && !SM.isOwned('toString'), 'noms hérités d\'Object refusés (constructor, toString)');
}

section('Équipement');
{
  NEBUSTION.Resources = fake(Object.assign({}, RICH));
  SM.buy('h_gold'); SM.buy('b_cyber'); SM.buy('s_royal');
  ok(!SM.equip('hero', 'kael', 'h_spectre').ok && SM.equip('hero', 'kael', 'h_spectre').reason === 'non_possede', 'équiper un skin non possédé : refusé');
  ok(SM.equip('hero', 'kael', 'h_gold').ok && SM.equippedId('hero', 'kael') === 'h_gold', 'équiper Or Solaire sur Kael');
  ok(SM.equippedSkin('hero', 'kael').name === 'Or Solaire', 'equippedSkin() renvoie la définition');
  ok(SM.equippedSkin('hero', 'zyra') === null, 'un autre héros reste sans skin');
  ok(SM.equip('hero', 'zyra', 'h_gold').ok, 'le même skin peut équiper plusieurs héros (cosmétique)');
  ok(SM.equip('hero', 'kael', 'b_cyber').reason === 'invalide', 'skin de bâtiment sur un héros : refusé');
  ok(SM.equip('hero', 'fantome', 'h_gold').reason === 'cible', 'héros inexistant : refusé');
  ok(SM.equip('building', 'command', 'b_cyber').ok && SM.equip('building', 'usine', 'b_cyber').reason === 'cible', 'bâtiment : valide / inconnu');
  const sh = NEBUSTION.ShipManager.acquire('cuirasse', 'commun').ship;
  ok(SM.equip('ship', sh.uid, 's_royal').ok, 'équiper un skin sur un vaisseau possédé');
  ok(SM.equip('ship', 'sh999', 's_royal').reason === 'cible', 'vaisseau inexistant : refusé');
  ok(SM.equippedCount() === 4, '4 équipements actifs : ' + SM.equippedCount());
  ok(SM.unequip('hero', 'kael').ok && SM.equippedId('hero', 'kael') === null, 'retirer un skin');
  ok(SM.unequip('hero', 'kael').reason === 'rien', 'retirer sans skin : sans effet');
  ok(SM.equip('hero', 'kael', 'h_gold').ok, 'rééquiper après retrait');
}

section('Collection');
{
  const c = SM.collection();
  ok(c.total === 21 && c.owned === 3 && c.byType.hero.owned === 1 && c.byType.ship.owned === 1 && c.byType.building.owned === 1, 'compteurs de collection : ' + JSON.stringify(c));
  ok(SM.owned('hero').length === 1 && SM.owned().length === 3, 'inventaire filtrable par type');
}

section('Aucun effet sur les statistiques de combat');
{
  NEBUSTION.Resources = fake(Object.assign({}, RICH));
  const CE = NEBUSTION.CombatEngine, hero = NEBUSTION.Heroes.get('kael');
  const before = CE.makeHeroUnit(hero, 5, 'kael', {});
  SM.buy('h_spectre'); SM.equip('hero', 'kael', 'h_spectre');
  const after = CE.makeHeroUnit(hero, 5, 'kael', {});
  ok(['hp', 'maxHp', 'atk', 'def', 'spd'].every(k => before[k] === after[k]), 'stats identiques avec ou sans skin (cosmétique pur)');
}

section('Sauvegarde : aller-retour, v4 → v5, données corrompues');
{
  // SaveManager réel avec un localStorage simulé
  const mem = {};
  global.localStorage = { getItem: k => (k in mem ? mem[k] : null), setItem: (k, v) => { mem[k] = String(v); }, removeItem: k => { delete mem[k]; } };
  delete require.cache[require.resolve('../js/systems/SaveManager.js')];
  const Save = require('../js/systems/SaveManager.js');
  ok(Save.VERSION === 7, 'version de sauvegarde = 7 (expéditions, événements, prestige, succès)');
  const now = Date.now();
  const st = Save.defaultState ? Save.defaultState(now) : null;
  ok(Save.normalize && Save.normalize(null, now).skins && Save.normalize(null, now).skins.owned !== undefined, 'nouvelle partie : état skins vide présent');

  // sauvegarde v4 (sans champ skins) : chargée sans casse, skins vides, ships conservés
  const v4 = Save.normalize({ v: 4, ships: { ships: { sh1: { classId: 'cuirasse', rarity: 'rare', level: 3 } }, fleet: ['sh1'], nextSeq: 2 } }, now);
  ok(v4.skins && Object.keys(v4.skins.owned).length === 0, 'sauvegarde v4 → skins vides, pas d\'erreur');
  ok(v4.ships.ships.sh1.level === 3 && v4.ships.fleet[0] === 'sh1', 'v4 → les vaisseaux sont conservés');

  // aller-retour avec skins
  const raw = { v: 5, skins: { owned: { h_gold: true, b_cyber: true }, equipped: { 'hero:kael': 'h_gold', 'building:hangar': 'b_cyber' } } };
  const n1 = Save.normalize(raw, now);
  ok(n1.skins.equipped['hero:kael'] === 'h_gold' && n1.skins.owned.b_cyber === true, 'skins possédés/équipés conservés au chargement');
  ok(JSON.stringify(Save.normalize(JSON.parse(JSON.stringify(n1)), now).skins) === JSON.stringify(n1.skins), 'aller-retour JSON stable');

  // corrompu
  const bad = Save.normalize({ skins: { owned: { h_gold: 'oui', evil: true }, equipped: { 'hero:kael': { x: 1 }, 'ship:sh1': 's_royal' } } }, now);
  ok(bad.skins.owned.h_gold === true && !bad.skins.owned.evil && Object.keys(bad.skins.equipped).length === 0, 'données corrompues réparées (non possédé → non équipé)');
  const num = Save.normalize({ skins: 12345 }, now);
  ok(Object.keys(num.skins.owned).length === 0, 'champ skins de mauvais type → état vide');
}

console.log('\n' + (failed === 0 ? '✓ TOUS LES TESTS SONT PASSÉS' : '✗ ÉCHECS') + ' — ' + passed + ' réussis, ' + failed + ' échoués');
process.exit(failed ? 1 : 0);
