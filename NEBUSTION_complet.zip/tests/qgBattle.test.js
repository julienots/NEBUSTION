/* Tests du MODE COMBAT (QGBattle.js), des Troupes (Troops.js + TroopManager) et de la Barricade (QGGrid). Node, sans Phaser.
 * Lancer : node tests/qgBattle.test.js */
'use strict';
const { makeCounter, freshGame } = require('./progress-env');
['data/EmpireAI', 'data/EmpireDoctrine', 'data/QGRaid', 'data/QGAttack'].forEach(f => require('../js/' + f + '.js'));
['GalaxyManager', 'EmpireAIManager', 'EmpireEvolutionManager', 'QGRaidManager', 'QGAttackManager'].forEach(f => require('../js/systems/' + f + '.js'));
const c = makeCounter(), ok = c.ok, section = c.section;
const QB = NEBUSTION.QGBattle, T = NEBUSTION.Troops, TM = NEBUSTION.TroopManager, G = NEBUSTION.QGGrid, GMg = NEBUSTION.QGGridManager;

function run(sim, secs) { for (let i = 0; i < secs * 20 && !sim.over; i++) sim.step(0.05); }
function ring(sim, tid, n, x, y) { for (let i = 0; i < n; i++) { const r = sim.deploy(tid, x, y + i * 0.05); if (!r.ok) return r; } return { ok: true }; }

section('Barricade (structure de grille)');
{
  ok(!!G.STRUCTURES.wall && G.STRUCTURE_ORDER.indexOf('wall') >= 0, 'la Barricade existe dans le catalogue');
  const s = G.normalizeState({ unlocked: { '2,2': true }, cells: { '2,2': 'wall' } });
  ok(s.cells['2,2'] === 'wall', 'une barricade survit à normalizeState');
  ok(G.bonusValue('security', { cells: { a: 'wall', b: 'wall' } }) === 1, '2 barricades = +1 niveau de sécurité');
  freshGame();
  const R = NEBUSTION.Resources;
  R.state.res.metal = 5000; R.state.res.dust = 5000;
  const r = GMg.build(2, 2, 'wall');
  ok(r.ok && GMg.structureAt(2, 2) === 'wall', 'construction d\'une barricade (paie metal + poussière)');
  ok(G.buildCost('wall', 1).metal > G.buildCost('wall', 0).metal, 'coût croissant');
  ok(G.STRUCTURES.wall.maxCount === 8, 'plafond 8');
}

section('Troupes : catalogue');
{
  ok(T.ORDER.length === 27, '27 types de troupes (' + T.ORDER.length + ')');
  ok(['eco', 'core', 'turret', 'wall', 'any'].every(p => T.ORDER.some(id => T.get(id).pref === p)), 'toutes les préférences de cible représentées');
  ok(T.ORDER.every(id => T.get(id).hp > 0 && T.get(id).space > 0 && Object.keys(T.get(id).cost).every(r => NEBUSTION.Economy.RES[r])), 'stats et coûts valides');
  ok(T.ORDER.some(id => T.get(id).fly) && T.ORDER.some(id => T.get(id).blast), 'un volant et un casseur de murs existent');
  ok(T.capacity(2) === 20 && T.capacity(0) === 12, 'capacité = 12 + 4 / niveau de Hangar');
  const n = T.normalizeState({ stock: { marine: 3, fantome: 9, titan: -4 }, bought: 'x' });
  ok(n.stock.marine === 3 && !n.stock.fantome && !n.stock.titan && n.bought === 0, 'normalizeState nettoie');
  ok(T.normalizeState(null).stock.marine === 6, 'armée de départ');
}

section('TroopManager');
{
  const { R } = freshGame();
  ok(TM.count('marine') === 6 && TM.count('berserker') === 2, 'nouvelle partie : armée de départ');
  ok(R.state.troops && TM.used() === 10 && TM.capacity() === 20, 'places utilisées / capacité (Hangar niv. 2)');
  R.state.res.crystal = 1000; R.state.res.metal = 1000; R.state.res.energy = 1000;
  const b = TM.buy('marine', 2);
  ok(b.ok && TM.count('marine') === 8 && R.state.res.crystal === 920, 'achat : stock + ressources débitées');
  ok(TM.buy('titan', 1).ok && TM.count('titan') === 1, 'Titan (6 places) tient encore dans l\'armée');
  ok(TM.buy('titan', 1).reason === 'capacite', 'armée pleine refusée (' + TM.used() + '/' + TM.capacity() + ')');
  R.state.res.crystal = 0;
  ok(TM.buy('marine', 1).reason === 'cost', 'ressources insuffisantes refusées');
  ok(TM.grant('titan', 2).ok && TM.count('titan') === 3 && TM.used() > TM.capacity(), 'grant (Pass) ignore la capacité');
  ok(TM.consume('titan', 1) && TM.count('titan') === 2 && !TM.consume('titan', 5), 'consume');
  ok(!TM.buy('inconnu', 1).ok, 'type inconnu refusé');
  const saved = NEBUSTION.Save.normalize(JSON.parse(JSON.stringify(R.state)), Date.now());
  ok(saved.troops && saved.troops.stock.marine === 8, 'sauvegarde/normalisation conserve l\'armée');
}

section('Boutique : achat de troupes');
{
  const { R } = freshGame(), SM = NEBUSTION.ShopManager;
  R.state.res.crystal = 5000; R.state.res.metal = 5000; R.state.res.energy = 5000; R.state.res.dust = 5000; R.state.res.core = 10;
  const c0 = R.state.res.crystal, n0 = TM.count('ranger');
  const r = SM.buyTroop('ranger', 5);
  ok(r.ok && TM.count('ranger') === n0 + 5 && R.state.res.crystal === c0 - 35 * 5, 'buyTroop ×5 : stock + ressources');
  ok(SM.buyTroop('cruiser', 1).reason === 'capacite', 'Croiseur (10 places) refusé si armée pleine');
  ok(SM.buyTroop('inconnu', 1).reason === 'invalide' && SM.buyTroop('marine', 500).reason === 'invalide', 'entrées invalides refusées');
  R.state.res.crystal = 0;
  ok(SM.buyTroop('marine', 1).reason === 'ressources', 'ressources insuffisantes');
  const t2 = freshGame().R; t2.state.res.crystal = 5000; t2.state.res.metal = 5000; t2.state.res.energy = 5000; t2.state.res.core = 3;
  t2.state.troops.stock = {};
  ok(SM.buyTroop('cruiser', 1).ok && t2.state.res.core === 0, 'Croiseur : coûte 3 Noyaux antiques');
  ok(SM.troopCost('mecha', 2).metal === 1040, 'troopCost ×2');
}

section('Nouvelles troupes en combat');
{
  const lay = { unlocked: { '2,2': true, '3,2': true, '2,3': true, '3,3': true, '1,1': true, '4,4': true }, cells: { '1,1': 'generator', '4,4': 'silo', '2,2': 'turret' } };
  function first(tid, x, y) {
    const b = QB.buildBase(lay, { scale: 0.4 }), s = QB.create(b, { [tid]: 1 });
    s.deploy(tid, x, y); run(s, 4); return { s, b };
  }
  const e = first('ranger', -1, 4.5);
  ok(e.b.buildings.some(b => (b.kind === 'generator' || b.kind === 'silo') && b.hp < b.maxHp), 'l\'Éclaireur vise générateurs/silos');
  const w = first('wraith', 7, 3);
  ok(w.b.buildings.find(b => b.kind === 'core').hp < w.b.buildings.find(b => b.kind === 'core').maxHp, 'le Spectre vise le cœur');
  const m = first('mecha', 7, 2.5);
  ok(m.s.troops[0].alive || m.b.buildings.find(b => b.kind === 'turret').hp < 240 * 0.4, 'le Mécha va vers la tourelle');
  const bo = first('bomber', -1, 1);
  ok(bo.b.buildings.some(b => (b.kind === 'generator' || b.kind === 'silo') && b.hp < b.maxHp), 'le Bombardier (volant) pilonne l\'économie');
}

section('Pass : récompenses de troupes');
{
  const P = NEBUSTION.Pass;
  const L = P.levelsFor(0);
  const troops = L.filter(x => x.free.kind === 'troop' || x.premium.kind === 'troop');
  ok(troops.length >= 3, 'le Pass propose des troupes (' + troops.length + ' niveaux)');
  ok(P.reward(0, 7, 'free').kind === 'troop' && !!T.get(P.reward(0, 7, 'free').troopId), 'niveau 7 gratuit = Marines');
}

section('Base ennemie');
{
  const lay = NEBUSTION.BotBases.layout('vexor', 4, 0);
  const w = QB.withWalls(lay, 3);
  ok(Object.keys(lay.cells).every(k => lay.cells[k] !== 'wall'), 'withWalls ne modifie pas le layout d\'origine');
  ok(Object.keys(w.cells).filter(k => w.cells[k] === 'wall').length === 3, '3 barricades posées');
  const base = QB.botBase('vexor', 4, 0);
  ok(base.buildings.filter(b => b.kind === 'core').length === 1, 'un seul cœur');
  ok(base.buildings.some(b => b.kind === 'wall') && base.buildings.some(b => b.kind === 'turret'), 'barricades + tourelles');
  const again = QB.botBase('vexor', 4, 0);
  ok(JSON.stringify(base.buildings.map(b => [b.kind, b.x, b.y, b.hp])) === JSON.stringify(again.buildings.map(b => [b.kind, b.x, b.y, b.hp])), 'déterministe');
  ok(QB.botBase('vexor', 8, 0).buildings.find(b => b.kind === 'core').hp > QB.botBase('vexor', 0, 0).buildings.find(b => b.kind === 'core').hp, 'plus développé = plus solide');
  ok(QB.botBase('vexor', 8, 1).buildings.find(b => b.kind === 'core').hp < QB.botBase('vexor', 8, 0).buildings.find(b => b.kind === 'core').hp, 'traumatisé = plus fragile');
  ok(QB.wallCount(0) >= 1 && QB.wallCount(8) <= 6, 'nombre de barricades borné');
}

section('Déploiement');
{
  const sim = QB.create(QB.botBase('vexor', 0, 0), { marine: 2, drone: 1 });
  ok(!sim.deploy('marine', 3, 3).ok && sim.deploy('marine', 3, 3).reason === 'zone', 'déploiement dans la base refusé');
  ok(sim.deploy('marine', 3, 3.1).reason === 'zone' && sim.deploy('marine', 99, 0).reason === 'zone', 'hors arène refusé');
  ok(!sim.started, 'le chrono ne démarre pas sur un refus');
  ok(sim.deploy('marine', -1, 3).ok && sim.started, 'déploiement valide démarre le combat');
  ok(sim.deploy('marine', -1, 2).ok && sim.deploy('marine', -1, 4).reason === 'stock', 'stock épuisé refusé');
  ok(sim.deploy('fantome', -1, 1).reason === 'inconnu', 'type inconnu');
  ok(sim.remaining() === 1, 'reste 1 troupe (drone)');
  ok(QB.inDeployZone(-1, -1) && !QB.inDeployZone(NaN, 0), 'zone : coins OK, NaN refusé');
}

section('Simulation');
{
  // Sans troupes : rien ne bouge, pas de fin
  const idle = QB.create(QB.botBase('vexor', 0, 0), { marine: 1 });
  idle.step(5);
  ok(!idle.over && idle.t === 0, 'sans déploiement le temps ne s\'écoule pas');

  // Une seule marine contre un QG solide : les tourelles la tuent, fin par manque de troupes
  const solo = QB.create(QB.botBase('vexor', 8, 0), { marine: 1 });
  solo.deploy('marine', -1, 3);
  run(solo, 60);
  const rs = solo.result();
  ok(solo.over && !rs.victory && rs.lost === 1, 'une marine isolée échoue contre un QG développé');

  // Armée massive contre QG faible : victoire
  const strong = QB.create(QB.botBase('vexor', 0, 0), { marine: 12, berserker: 6, breacher: 4 });
  ring(strong, 'breacher', 4, -1, 3); ring(strong, 'berserker', 3, -1, 2); ring(strong, 'berserker', 3, 7, 3);
  ring(strong, 'marine', 6, 3, -1); ring(strong, 'marine', 6, 3, 7);
  run(strong, 120);
  const rr = strong.result();
  ok(strong.over && rr.victory && rr.stars >= 1, 'une grosse armée pille un QG de niveau 0 (' + rr.stars + '★, ' + Math.round(rr.pct * 100) + ' %)');

  // Barricade : un marine au sol doit d'abord abattre le mur qui bloque
  const lay = { unlocked: { '2,2': true, '3,2': true, '2,3': true, '3,3': true, '1,2': true, '1,3': true }, cells: { '1,2': 'wall', '1,3': 'wall' } };
  const wallBase = QB.buildBase(lay, { scale: 1 });
  const ws = QB.create(wallBase, { marine: 1, drone: 1 });
  ws.deploy('marine', -1, 2.5);
  run(ws, 6);
  const wall = wallBase.buildings.find(b => b.kind === 'wall' && b.x === 1.5 && b.y === 2.5);
  const mar = ws.troops[0];
  ok(wall.hp < wall.maxHp && mar.x < 2.2, 'un fantassin est bloqué par la barricade et la frappe (mur ' + Math.round(wall.hp) + '/' + wall.maxHp + ', x=' + mar.x.toFixed(2) + ')');

  // Un vaisseau vole au-dessus du mur
  const base2 = QB.buildBase(lay, { scale: 1 });
  const fs = QB.create(base2, { drone: 1 });
  fs.deploy('drone', -1, 2.5);
  run(fs, 6);
  ok(fs.troops[0].x > 1.3 && base2.buildings.filter(b => b.kind === 'wall').every(b => b.hp === b.maxHp), 'un vaisseau survole les barricades sans les toucher');

  // Casseur : explose sur le mur
  const base3 = QB.buildBase(lay, { scale: 1 });
  const bs = QB.create(base3, { breacher: 1 });
  bs.deploy('breacher', -1, 2.5);
  run(bs, 8);
  ok(!bs.troops[0].alive && base3.buildings.some(b => b.kind === 'wall' && b.hp < b.maxHp), 'le Casseur explose et endommage la barricade');

  // Tourelle : tue une unité fragile à portée
  const tb = QB.buildBase({ unlocked: { '2,2': true }, cells: { '2,2': 'turret' } }, { scale: 1 });
  const ts = QB.create(tb, { sniper: 1, marine: 1 });
  ts.deploy('marine', 2.5, -0.5);
  run(ts, 20);
  ok(ts.result().lost >= 1 || ts.result().pct > 0, 'tourelle et troupes interagissent');

  // Résultat : étoiles cohérentes
  const full = QB.create(QB.buildBase({ unlocked: { '2,2': true }, cells: { '2,2': 'silo' } }, { scale: 0.3 }), { titan: 1 });
  full.deploy('titan', -1, 3);
  run(full, 120);
  const rf = full.result();
  ok(rf.pct === 1 && rf.coreDown && rf.stars === 3 && rf.victory, 'destruction totale = 3 étoiles');

  // Temps limite
  const slow = QB.create(QB.botBase('vexor', 8, 0), { titan: 1 });
  slow.deploy('titan', -1, 3);
  slow.step(500);
  ok(slow.t <= slow.duration + 0.06, 'le temps est borné (' + slow.t.toFixed(2) + ' s)');
  slow.retreat();
  ok(slow.over && slow.deploy('titan', -1, 3).reason === 'termine', 'abandon termine le combat');
}

section('Résultat appliqué (QGAttackManager.applyBattle)');
{
  const { R } = freshGame();
  const AM = NEBUSTION.QGAttackManager, EMg = NEBUSTION.EmpireEvolutionManager, Gal = NEBUSTION.Galaxy;
  EMg.stop();
  const eid = Gal.EMPIRE_ORDER[0];
  ok(AM.isAlive(eid), 'empire en vie');
  const before = JSON.parse(JSON.stringify(R.state.res)), es = EMg.state(Date.now()).e[eid], h0 = es.hurt || 0;
  const v = AM.applyBattle(eid, { stars: 2, pct: 0.8, victory: true }, Date.now());
  ok(v.ok && v.result.victory && v.result.loot.crystal > 0, 'victoire : butin calculé');
  ok(R.state.res.crystal > before.crystal && R.state.res.core === before.core, 'butin crédité, jamais de Noyaux');
  ok((EMg.state(Date.now()).e[eid].hurt || 0) > h0, 'traumatisme de l\'empire accru');
  const cdBefore = Object.keys(AM.state().cooldowns).length;
  const d = AM.applyBattle(eid, { stars: 0, pct: 0.1, victory: false }, Date.now());
  ok(d.ok && !d.result.victory && Object.keys(d.result.loot).length === 0, 'échec : pas de butin');
  ok(Object.keys(AM.state().cooldowns).length === cdBefore, 'le mode combat ne pose pas de recharge');
  ok(!AM.applyBattle('inconnu', { stars: 3, pct: 1 }, Date.now()).ok, 'empire inconnu refusé');
}

c.done('Mode combat, troupes et barricades');
