/* Tests du module de données NEBUSTION.Heroes (Node, sans dépendance). Lancer : node tests/heroes.test.js */
'use strict';
global.window = global;
require('../js/data/Heroes.js');

const H = NEBUSTION.Heroes;
let passed = 0, failed = 0;
function ok(cond, msg) { if (cond) { passed++; } else { failed++; console.log('  ✗ ECHEC : ' + msg); } }
function section(t) { console.log('\n# ' + t); }

section('Structure générale');
{
  ok(Array.isArray(H.HERO_LIST) && H.HERO_LIST.length >= 15, 'au moins 15 héros (' + H.HERO_LIST.length + ')');
  const ids = H.HERO_LIST.map(h => h.id);
  ok(new Set(ids).size === ids.length, 'identifiants uniques');
  ok(H.RARITY_ORDER.length === 6, '6 raretés définies');
  ['commun', 'rare', 'epique', 'legendaire', 'mythique', 'celeste'].forEach(r => {
    ok(!!H.RARITIES[r], 'rareté présente : ' + r);
  });
  ok(H.RARITY_ORDER.every((r, i) => H.RARITIES[r].order === i + 1), 'ordre des raretés cohérent');
}

section('Chaque héros a des données complètes et cohérentes');
{
  H.HERO_LIST.forEach(h => {
    ok(typeof h.id === 'string' && h.id.length > 0, h.id + ' : id valide');
    ok(typeof h.name === 'string' && h.name.length > 0, h.id + ' : nom présent');
    ok(!!H.ROLES[h.role], h.id + ' : rôle valide (' + h.role + ')');
    ok(!!H.RARITIES[h.rarity], h.id + ' : rareté valide (' + h.rarity + ')');
    ['hp', 'atk', 'def', 'spd'].forEach(k => {
      ok(typeof h.base[k] === 'number' && h.base[k] > 0, h.id + ' : stat ' + k + ' > 0');
    });
    ok(!!h.visual && typeof h.visual.body === 'string' && typeof h.visual.prop === 'string', h.id + ' : identité visuelle définie');
    ['passive', 'active', 'ultimate'].forEach(s => {
      ok(!!h.skills[s] && !!h.skills[s].name && !!h.skills[s].desc, h.id + ' : compétence ' + s + ' complète');
    });
  });
}

section('Au moins un héros par rôle attendu et par rareté clé');
{
  ['assassin', 'tank', 'healer', 'damage', 'sniper', 'control', 'support', 'dps'].forEach(r => {
    ok(H.byRole(r).length > 0, 'au moins un héros de rôle ' + r);
  });
  ['commun', 'rare', 'epique', 'legendaire', 'mythique', 'celeste'].forEach(r => {
    if (r === 'commun' || r === 'rare') return; // pas obligatoires dans le roster de départ
    ok(H.byRarity(r).length > 0, 'au moins un héros de rareté ' + r);
  });
}

section('Statistiques dérivées');
{
  const zyra = H.get('zyra');
  ok(!!zyra, 'récupération par id (zyra)');
  const s1 = H.statsAtLevel(zyra, 1);
  const s10 = H.statsAtLevel(zyra, 10);
  ok(s1.hp === zyra.base.hp, 'niveau 1 = stats de base');
  ok(s10.hp > s1.hp && s10.atk > s1.atk, 'les stats augmentent avec le niveau');
  ok(typeof s1.power === 'number' && s1.power > 0, 'puissance calculée > 0');
  const sMax = H.statsAtLevel(zyra, 999);
  ok(sMax.hp === H.statsAtLevel(zyra, H.MAX_LEVEL).hp, 'niveau plafonné à MAX_LEVEL');

  // La puissance doit rester globalement corrélée à la rareté du héros
  const avgPower = r => {
    const list = H.byRarity(r);
    return list.reduce((a, h) => a + H.statsAtLevel(h, 1).power, 0) / list.length;
  };
  ok(avgPower('legendaire') > avgPower('epique'), 'puissance moyenne Légendaire > Épique');
}

section('Portraits');
{
  H.HERO_LIST.forEach(h => {
    ok(H.portraitKey(h.id) === 'hero_portrait_' + h.id, 'clé de texture cohérente : ' + h.id);
    ok(H.portraitFile(h.id) === 'assets/heroes/' + h.id + '.png', 'chemin de fichier attendu : ' + h.id);
  });
}

section('Fichiers de portraits fournis (assets/heroes)');
{
  const fs = require('fs'), path = require('path');
  const provided = ['zyra','korvax','lumina','drakor','selene','vortex','nyx','rexar','vega','orion','kael','soraya','targon','elys','xanor'];
  provided.forEach(id => {
    ok(!!H.get(id), 'héros existant dans la base : ' + id);
    const f = path.join(__dirname, '..', H.portraitFile(id));
    ok(fs.existsSync(f), 'portrait présent : ' + H.portraitFile(id));
    if (fs.existsSync(f)) {
      const b = fs.readFileSync(f);
      ok(b.slice(1, 4).toString() === 'PNG', 'fichier PNG valide : ' + id);
      ok(b.readUInt32BE(16) === 300 && b.readUInt32BE(20) === 380, 'dimensions 300x380 : ' + id);
    }
  });
  // Aeon (Céleste) n'a pas d'illustration fournie : il garde son portrait temporaire généré.
}

console.log('\n' + (failed === 0 ? '✔ TESTS HEROES OK' : '✘ ' + failed + ' échec(s)') + ' (' + passed + ' vérifications)');
process.exit(failed === 0 ? 0 : 1);
