/* Tests du module d'évolution des empires (EmpireEvolution + EmpireEvolutionManager). Node, sans dépendance. Lancer : node tests/empireEvolution.test.js */
'use strict';
global.window = global;
require('../js/data/Economy.js'); require('../js/data/Heroes.js'); require('../js/data/Enemies.js'); require('../js/data/Galaxy.js');
require('../js/data/EmpireAI.js'); require('../js/data/EmpireDoctrine.js'); require('../js/data/EmpireEvolution.js');
require('../js/systems/SaveManager.js'); require('../js/systems/ResourceManager.js'); require('../js/systems/CombatEngine.js');
require('../js/systems/CombatManager.js'); require('../js/systems/GalaxyManager.js'); require('../js/systems/EmpireAIManager.js'); require('../js/systems/EmpireEvolutionManager.js');

const G = NEBUSTION.Galaxy, GM = NEBUSTION.GalaxyManager, AIM = NEBUSTION.EmpireAIManager, EE = NEBUSTION.EmpireEvolution, EM = NEBUSTION.EmpireEvolutionManager, Save = NEBUSTION.Save;
let passed = 0, failed = 0;
function ok(c, m) { if (c) passed++; else { failed++; console.log('  ✗ ECHEC : ' + m); } }
function section(t) { console.log('\n# ' + t); }
function memStorage() { const m = {}; return { data: m, getItem: k => (k in m ? m[k] : null), setItem: (k, v) => { m[k] = String(v); }, removeItem: k => { delete m[k]; } }; }
const T0 = 1_800_000_000_000, H = 3600 * 1000, DAY = 24 * H;
const realTeam = GM.teamLevel;
let storage;
function fresh(team, diff) {
  storage = memStorage(); Save._useStorage(storage);
  NEBUSTION.Resources = new NEBUSTION.ResourceManager(); NEBUSTION.Resources.init(T0);
  NEBUSTION.Resources.state.empires.seed = 12345;
  G.SECTORS.forEach(s => { GM.state().unlocked[s.id] = true; });
  GM.teamLevel = () => (team == null ? 45 : team);
  NEBUSTION.Resources.state.combat.difficulty = diff || 'normal';
  AIM.invalidate(); EM.stop();
  return NEBUSTION.Resources;
}
function run(days, from) { let t = from || T0; for (let i = 0; i < days * 4; i++) { t += 6 * H; EM.update(t); } return t; }
function defSum(eid, kind) { const d = EM.state().e[eid].def; return Object.keys(d).reduce((s, k) => s + d[k][kind], 0); }

section('Données : coûts, plafonds, cohérence');
{
  ok(EE.STEP_MS === 1800000 && EE.MAX_CATCHUP_STEPS === 48, 'pas de 30 min, rattrapage max 24 h');
  for (let e = 0; e < EE.MAX_EVO; e++) ok(EE.evoCost(e + 1, 5) > EE.evoCost(e, 5), 'coût de développement croissant (' + e + ')');
  ['sh', 'tu', 'fl'].forEach(k => { for (let l = 0; l < 5; l++) ok(EE.upgradeCost(k, l + 1, 10) > EE.upgradeCost(k, l, 10), 'coût ' + k + ' croissant'); });
  ok(EE.evoCost(EE.MAX_EVO - 1, 5) < EE.CAP_POINTS && EE.upgradeCost('sh', EE.SH_MAX - 1, 25) < EE.CAP_POINTS, 'la dernière amélioration reste payable (< plafond de stock)');
  ok(EE.ceilingFor(1, 'normal') === 1 && EE.ceilingFor(999, 'normal') === EE.MAX_EVO, 'plafond de développement borné [1..8]');
  ok(EE.ceilingFor(30, 'facile') < EE.ceilingFor(30, 'normal') && EE.ceilingFor(30, 'normal') < EE.ceilingFor(30, 'difficile') && EE.ceilingFor(30, 'difficile') <= EE.ceilingFor(30, 'cauchemar'), 'plafond croissant avec la difficulté');
  ok(EE.ceilingFor(NaN, 'zzz') === 1, 'entrées invalides tolérées');
  ok(EE.shMax(0) === 0 && EE.shMax(99) === EE.SH_MAX && EE.tuMax(99) === EE.TU_MAX && EE.flMax(0, 5) === 0 && EE.flMax(99, 5) <= 2, 'niveaux maximum dépendants du développement');
  const a = EE.rand01(5, 10, 3), b = EE.rand01(5, 10, 3);
  ok(a === b && a >= 0 && a < 1 && EE.rand01(5, 11, 3) !== a, 'aléa déterministe et dans [0,1)');
  const s = { res: { metal: 100, energy: 100 } }; // 100 + 120 = 220 points
  ok(EE.pay(s, 'vexor', 110) && Math.abs(EE.wealth(s, 'vexor') - 110) < 0.5, 'paiement mixte : moitié de la richesse prélevée');
  ok(!EE.pay(s, 'vexor', 1000) && Math.abs(EE.wealth(s, 'vexor') - 110) < 0.5, 'paiement impossible = aucune dépense (tout ou rien)');
}

section('Sauvegarde : normalizeState résiste aux données abîmées');
{
  const n = EE.normalizeState(null, T0);
  ok(G.EMPIRE_ORDER.every(e => n.e[e] && n.e[e].evo === 0), 'état neuf : 6 empires à evo 0');
  ok(Object.keys(n.e).length === 6, 'exactement 6 empires (pas de doublon)');
  const bad = EE.normalizeState({
    lastAt: T0 + 9 * DAY, n: -5, seed: 'x',
    e: {
      vexor: { evo: 99, res: { metal: 1e12, energy: -5, crystal: 50 }, def: { vx1: { sh: 99, tu: 99, fl: 99 }, k91: { sh: 3 }, zzz: { sh: 1 }, vx2: { sh: NaN, tu: 'a' } }, lastRec: T0 + DAY, rec: -3, spent: NaN, ups: 1e99 },
      ghost: { evo: 5 }, kael9: 'nimportequoi', morvak: { evo: 2, def: { mo1: { sh: 5, tu: 5, fl: 5 } } }
    }
  }, T0);
  ok(bad.lastAt <= T0 && bad.n === 0 && bad.seed >= 1, 'date future ramenée à maintenant, compteur/seed réparés');
  ok(bad.e.ghost === undefined && Object.keys(bad.e).length === 6, 'empire inconnu ignoré');
  ok(bad.e.vexor.evo === EE.MAX_EVO, 'evo plafonné');
  ok(bad.e.vexor.res.metal <= EE.capRes('metal') && bad.e.vexor.res.energy === 0 && bad.e.vexor.res.crystal === undefined, 'stocks bornés, ressource étrangère rejetée');
  const d1 = bad.e.vexor.def.vx1;
  ok(d1 && d1.sh === EE.SH_MAX && d1.tu === EE.tuMax(EE.MAX_EVO, 'vexor') && d1.fl <= EE.FL_MAX[1], 'niveaux de défense plafonnés');
  ok(!bad.e.vexor.def.k91 && !bad.e.vexor.def.zzz && !bad.e.vexor.def.vx2, 'planètes d\'un autre empire / inconnues / vides rejetées');
  ok(bad.e.vexor.lastRec <= T0 && bad.e.vexor.rec === 0 && bad.e.vexor.spent === 0 && bad.e.vexor.ups <= 1e9, 'compteurs réparés');
  ok(bad.e.morvak.def.mo1.sh <= 2 && bad.e.morvak.def.mo1.tu <= 1 && bad.e.morvak.def.mo1.fl <= 1, 'niveaux limités par le développement de l\'empire (pas de triche via la sauvegarde)');
  const round = EE.normalizeState(JSON.parse(JSON.stringify(bad)), T0);
  ok(JSON.stringify(round) === JSON.stringify(bad), 'normalize est idempotent');
}

section('Intégration SaveManager : ancienne sauvegarde et cycle complet');
{
  fresh();
  const R = NEBUSTION.Resources;
  ok(R.state.empires && R.state.empires.e.vexor, 'nouvelle partie : état des empires présent');
  const old = JSON.parse(JSON.stringify(R.state)); delete old.empires;
  const s = Save.normalize(old, T0 + 5 * DAY);
  ok(s.empires && s.empires.lastAt === T0 + 5 * DAY && s.empires.n === 0, 'ancienne sauvegarde sans empires : état neuf, AUCUN rattrapage rétroactif');
  R.state.empires.e.morvak.evo = 3; R.state.empires.e.morvak.def.mo1 = { sh: 2, tu: 1, fl: 0 }; R.state.empires.e.morvak.res.metal = 1234.5;
  R.saveNow(T0 + 1000);
  const R2 = new NEBUSTION.ResourceManager(); R2.init(T0 + 2000);
  const m = R2.state.empires.e.morvak;
  ok(m.evo === 3 && m.def.mo1.sh === 2 && m.def.mo1.tu === 1 && m.res.metal === 1234.5, 'progression rechargée à l\'identique après sauvegarde/rechargement');
  ok(R2.state.empires.seed === 12345, 'seed conservé');
  const bak = Save.load(); ok(bak.state && bak.state.empires && bak.state.empires.e.morvak.evo === 3, 'l\'enveloppe sauvegardée contient bien les empires');
  const R3 = new NEBUSTION.ResourceManager(); R3.init(T0 + 2500); R3._adoptExternal(Save._encode(Object.assign({}, R.state, { sid: 'autre-onglet' })));   // autre onglet
  ok(R3.state.empires.e.morvak.evo === 3, 'un autre onglet qui sauvegarde : empires adoptés à l\'identique');
  R.reset(T0 + 3000); ok(R.state.empires.e.morvak.evo === 0, 'reset de la partie remet les empires à zéro');
}

section('Évolution : ressources, développement, défenses au fil du temps');
{
  fresh(45);
  const before = G.empirePower('vexor');
  EM.update(T0 + 29 * 60 * 1000); ok(EM.state().n === 0, 'moins de 30 min : aucun pas');
  EM.update(T0 + 31 * 60 * 1000);
  const v1 = EM.state().e.vexor;
  ok(EM.state().n === 1 && v1.res.metal > 0 && v1.res.energy > 0, 'un pas : revenus de metal + energy (ressources propres de VEXOR)');
  ok(v1.res.crystal === undefined, 'VEXOR ne produit pas de cristal');
  const t = run(3, T0 + 31 * 60 * 1000);
  const st = EM.empireStatus('vexor', t);
  ok(st.evo >= 2 && st.upgrades >= 10, 'après 3 jours : développement et améliorations réels (evo ' + st.evo + ', ' + st.upgrades + ' améliorations)');
  ok(st.power > before && st.growth > 1.1, 'puissance de VEXOR supérieure à sa puissance d\'origine (x' + st.growth + ')');
  ok(G.empirePower('vexor') === before, 'Galaxy.js inchangé : les données d\'origine ne sont jamais modifiées');
  const cap = G.planet('vx5');
  const info = EM.planetInfo('vx5', t), sp = EM.battleSpec('vx5', t), base = G.battleSpec('vx5');
  ok(info.shield >= cap.defense.shield && info.turrets >= cap.defense.turrets && info.power >= cap.power, 'défense évoluée ≥ défense d\'origine');
  ok(sp.shield === info.shield && sp.turrets === info.turrets && sp.scale >= base.scale, 'battleSpec évolué cohérent avec planetInfo');
  const cnt = s => s.waves.reduce((a, w) => a + w.length, 0);
  ok(cnt(sp) >= cnt(base) && sp.waves.every(w => w.length >= 1 && w.length <= 3), 'vagues de 3 ennemis max, jamais moins d\'unités');
  ok(Object.keys(base.rewards).every(k => k in sp.rewards) && sp.rewards.xp >= base.rewards.xp && sp.rewards.first === base.rewards.first || JSON.stringify(sp.rewards.first) === JSON.stringify(base.rewards.first), 'récompenses conservées (légère hausse, premières récompenses intactes)');
  ok(EM.battleSpec('nexus_01', t) === null && EM.battleSpec('inconnue', t) === null, 'planète-mère / inconnue : null comme Galaxy.battleSpec');
  const neutral = G.PLANETS.filter(p => p.kind === 'neutral')[0];
  ok(JSON.stringify(EM.battleSpec(neutral.id, t)) === JSON.stringify(G.battleSpec(neutral.id)), 'planète neutre : spec d\'origine inchangée');
}

section('Équilibrage : bornes, plafond lié au joueur, difficulté');
{
  fresh(45); let t = run(40);
  G.EMPIRE_ORDER.forEach(e => {
    const s = EM.empireStatus(e, t), es = EM.state().e[e];
    ok(s.evo === EE.MAX_EVO, e + ' : atteint le développement max en 40 j (' + s.evo + ')');
    ok(s.growth >= 1.15 && s.growth <= 1.75, e + ' : puissance finale bornée (x' + s.growth + ', 1.15..1.75)');
    ok(es.ups <= 5 * (EE.SH_MAX + EE.TU_MAX + 2) + EE.MAX_EVO + 5 * 3, e + ' : nombre d\'améliorations fini (' + es.ups + ')');
    Object.keys(es.res).forEach(r => ok(es.res[r] <= EE.capRes(r) + 1e-6, e + ' : stock ' + r + ' plafonné'));
    G.planetsOfEmpire(e).forEach(p => { const v = EM.planetInfo(p.id, t); ok(v.shield <= p.defense.shield * EE.SHIELD_TOTAL_CAP + 1, p.id + ' : bouclier ≤ ×' + EE.SHIELD_TOTAL_CAP); });
  });
  const ups = G.EMPIRE_ORDER.map(e => EM.state().e[e].ups); t = run(20, t);
  ok(G.EMPIRE_ORDER.every((e, i) => EM.state().e[e].ups === ups[i]), 'sans nouveau plafond, la progression s\'arrête (aucune croissance infinie)');

  fresh(3); t = run(30);
  ok(G.EMPIRE_ORDER.every(e => EM.state().e[e].evo <= EE.ceilingFor(3, 'normal')), 'joueur faible (niv. 3) : empires plafonnés à evo ' + EE.ceilingFor(3, 'normal'));
  const weak = EM.empireStatus('nyrah', t).growth;
  fresh(45); const t2 = run(30);
  ok(EM.empireStatus('nyrah', t2).growth > weak, 'à mesure que le joueur progresse, les empires rattrapent');
  GM.teamLevel = () => 45; run(0); // plafond relevé en cours de partie
  fresh(3); t = run(20); GM.teamLevel = () => 30; t = run(20, t);
  ok(EM.state().e.morvak.evo > EE.ceilingFor(3, 'normal'), 'niveau d\'équipe relevé en cours de partie : l\'évolution reprend');

  const evoAt = (d) => { fresh(45, d); run(4); return G.EMPIRE_ORDER.reduce((s, e) => s + EM.state().e[e].evo, 0); };
  const f = evoAt('facile'), n = evoAt('normal'), c = evoAt('cauchemar');
  ok(f <= n && n <= c && f < c, 'difficulté : facile ≤ normal ≤ cauchemar après 4 jours (' + [f, n, c].join(' ≤ ') + ')');
}

section('Stratégie : chaque empire dépense selon sa posture');
{
  fresh(45); run(9);
  const s = e => ({ sh: defSum(e, 'sh'), tu: defSum(e, 'tu'), fl: defSum(e, 'fl') });
  ok(EM.empireStatus('morvak').posture === 'offensive', 'posture issue d\'EmpireAI (MORVAK offensif)');
  // Même empire, mêmes ressources, seule la posture change → la répartition des dépenses change
  const spend = posture => {
    const es = { res: { metal: 6000, energy: 6000 }, evo: 3, def: {}, lastRec: 0, rec: 0, spent: 0, ups: 0 };
    const ctx = { eid: 'vexor', planets: G.planetsOfEmpire('vexor').map(p => ({ id: p.id, tier: p.tier, threat: p.threat, isCapital: p.isCapital, deposits: p.deposits, owned: true })), posture, reinforceRate: 1, targets: {}, ceiling: 8, capitalLost: false };
    for (let i = 0; i < 10; i++) EE.stepEmpire(es, ctx);
    const f = k => Object.keys(es.def).reduce((a, x) => a + es.def[x][k], 0);
    return { sh: f('sh'), tu: f('tu'), fl: f('fl'), evo: es.evo };
  };
  const dF = spend('defensive'), oF = spend('offensive'), bF = spend('balanced');
  console.log('  défensif', JSON.stringify(dF), '| offensif', JSON.stringify(oF), '| équilibré', JSON.stringify(bF));
  ok(dF.sh > oF.sh, 'posture défensive : plus de boucliers que l\'offensive');
  ok(oF.fl > dF.fl, 'posture offensive : plus d\'unités de renfort que la défensive');
  ok(bF.sh > oF.sh && bF.sh < dF.sh, 'posture équilibrée : entre les deux pour les boucliers');
  // Situation réelle : ELYRA amputée bascule en repli défensif et renforce ses boucliers
  const elP = G.planetsOfEmpire('elyra'); elP.slice(0, 3).forEach(p => GM.setConquered(p.id, true, T0 + 9 * DAY)); AIM.invalidate();
  ok(EM.empireStatus('elyra', T0 + 9 * DAY).posture === 'defensive', 'ELYRA touchée : repli défensif décidé par EmpireAI');
  // Conquête totale : l'empire n'a plus de revenus et ne progresse plus
  fresh(45); run(2);
  G.planetsOfEmpire('vexor').forEach(p => GM.setConquered(p.id, true, T0 + 2 * DAY));
  const w0 = EM.state().e.vexor.res.metal, u0 = EM.state().e.vexor.ups; run(3, T0 + 2 * DAY);
  ok(EM.state().e.vexor.res.metal === w0 && EM.state().e.vexor.ups === u0, 'empire entièrement conquis : plus aucun revenu ni amélioration');
  ok(EM.empireStatus('vexor').owned === 0 && EM.empireStatus('vexor').power === 0, 'empire vaincu : puissance 0');
  ok(EM.state().e.kael9.ups > 0, 'les autres empires continuent d\'évoluer');
  // Capitale tombée : revenus réduits de moitié
  fresh(45); G.planetsOfEmpire('kael9').filter(p => p.isCapital).forEach(p => GM.setConquered(p.id, true, T0));
  const a = { res: {}, evo: 0, def: {}, lastRec: 0, rec: 0, spent: 0, ups: 0 }, mk = cl => ({ eid: 'kael9', planets: G.planetsOfEmpire('kael9').map(p => ({ id: p.id, tier: p.tier, threat: p.threat, isCapital: p.isCapital, deposits: p.deposits, owned: true })), posture: 'balanced', reinforceRate: 1, targets: {}, ceiling: 0, capitalLost: cl });
  const b = JSON.parse(JSON.stringify(a));
  const ia = EE.stepEmpire(a, mk(false)).income, ib = EE.stepEmpire(b, mk(true)).income;
  ok(Math.abs(ib / ia - 0.5) < 0.01, 'capitale tombée : revenus divisés par 2');
}

section('Contre-offensive : impact réel et garde-fous');
{
  fresh(20);
  const k = G.planetsOfEmpire('morvak').filter(p => !p.isCapital && p.tier === 3)[0];
  run(12); ok(EM.state().e.morvak.evo >= 2, 'préparation : MORVAK développé');
  GM.setConquered(k.id, true, T0 + 12 * DAY); const cap = G.planetsOfEmpire('morvak').filter(p => p.isCapital)[0];
  let recap = 0; EM.on('recapture', () => { recap++; });
  let t = T0 + 12 * DAY + 6 * H; EM.update(t);
  ok(GM.isConquered(k.id) && recap === 0, 'délai de grâce (12 h) : planète fraîchement conquise jamais reprise');
  // On force les autres conditions favorables : difficulté cauchemar, équipe modeste
  NEBUSTION.Resources.state.combat.difficulty = 'cauchemar'; AIM.invalidate();
  GM.teamLevel = () => 8;   // niveau du joueur faible face à MORVAK évolué
  const es = EM.state().e.morvak; es.res.metal = 60000; es.res.dust = 60000; es.res.core = 500;
  for (let i = 0; i < 40 && recap === 0; i++) { t += DAY; EM.update(t); NEBUSTION.Resources.state.empires.e.morvak.res.metal = 60000; NEBUSTION.Resources.state.empires.e.morvak.res.dust = 120000; }
  ok(recap === 1 && !GM.isConquered(k.id), 'MORVAK reprend la planète conquise (planète rendue : conquered=false, événement émis)');
  ok(EM.state().e.morvak.rec === 1 && EM.state().e.morvak.lastRec > 0, 'reprise comptée et datée (sauvegardée)');
  const after = EM.state().e.morvak.lastRec;
  GM.setConquered(k.id, true, t); const t2 = t + 6 * H; EM.update(t2);
  ok(GM.isConquered(k.id) && EM.state().e.morvak.lastRec === after, 'cooldown 24 h : pas de deuxième reprise immédiate');
  GM.setConquered(cap.id, true, t2);
  for (let i = 0; i < 20; i++) { EM.update(t2 + (i + 2) * DAY); }
  ok(GM.isConquered(cap.id), 'une capitale conquise n\'est jamais reprise');

  // Joueur très supérieur : aucune riposte
  fresh(60, 'cauchemar'); run(12); GM.setConquered(k.id, true, T0 + 12 * DAY);
  let r2 = 0; EM.on('recapture', () => { r2++; }); run(20, T0 + 12 * DAY + DAY);
  ok(r2 === 0 && GM.isConquered(k.id), 'joueur très supérieur au niveau des planètes : aucune contre-offensive');
}

section('Sans doublon : idempotence, minuteur unique, hors ligne, horloge');
{
  fresh(45); const t = T0 + 5 * H;
  EM.update(t); const snap = JSON.stringify(EM.state());
  EM.update(t); EM.update(t); EM.update(t + 60 * 1000);
  ok(JSON.stringify(EM.state()) === snap, 'appels répétés au même instant : aucun pas rejoué');
  EM.update(T0 + 1 * H);
  ok(JSON.stringify(EM.state()) === snap, 'horloge reculée : rien ne change (pas de double progression)');
  EM.start(); const running = EM.isRunning(); EM.start(); EM.start();
  ok(running && EM.isRunning(), 'start() répété : un seul minuteur'); EM.stop(); ok(!EM.isRunning(), 'stop() arrête le minuteur');

  fresh(45); const r = EM.update(T0 + 30 * DAY);
  ok(r.truncated && r.steps === EE.MAX_CATCHUP_STEPS && EM.state().n === EE.MAX_CATCHUP_STEPS, '30 jours d\'absence : rattrapage limité à 24 h (48 pas)');
  ok(EM.state().lastAt === T0 + 30 * DAY, 'excédent abandonné : lastAt = maintenant');
  const ups = EM.state().e.vexor.ups; EM.update(T0 + 30 * DAY + 60 * 1000);
  ok(EM.state().e.vexor.ups === ups, 'aucun rattrapage supplémentaire juste après');

  // Même progression en ligne (petits pas) et après une seule absence de 24 h
  fresh(45); run(1); const a = JSON.stringify(EM.state().e);
  fresh(45); EM.update(T0 + DAY); const b = JSON.stringify(EM.state().e);
  ok(a === b, 'progression identique : 4 mises à jour de 6 h = 1 absence de 24 h (déterministe)');

  // Sauvegarde/rechargement en plein milieu : la suite est identique
  fresh(45); run(2); const R = NEBUSTION.Resources; R.saveNow(T0 + 2 * DAY);
  const R2 = new NEBUSTION.ResourceManager(); R2.init(T0 + 2 * DAY); NEBUSTION.Resources = R2;
  ok(EM.state().n === R.state.empires.n && EM.state().lastAt === R.state.empires.lastAt, 'rechargement : compteur de pas et horloge conservés');
  const t3 = run(3, T0 + 2 * DAY); const cont = JSON.stringify(EM.state().e);
  fresh(45); run(5); ok(cont === JSON.stringify(EM.state().e), 'sauvegarder/recharger au milieu ne change pas la suite (pas de perte ni de double gain)');

  ok(['decide', 'decideAll', 'intents', 'assess', 'wire'].every(f => typeof AIM[f] === 'function'), 'API EmpireAIManager intacte');
  GM.teamLevel = realTeam;
}

console.log('\n' + (failed === 0 ? '✔ TESTS ÉVOLUTION DES EMPIRES OK  (' + passed + ' vérifications)' : '✗ ' + failed + ' ÉCHEC(S) sur ' + (passed + failed)));
process.exit(failed === 0 ? 0 : 1);
