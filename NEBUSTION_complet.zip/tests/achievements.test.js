/* Tests des succès, objectifs long terme et récompenses quotidiennes (NEBUSTION.Achievements + AchievementsManager), Node, sans Phaser.
 * Lancer : node tests/achievements.test.js */
'use strict';
const E = require('./progress-env');
const t = E.makeCounter(), ok = t.ok, section = t.section;
const A = NEBUSTION.Achievements, AM = NEBUSTION.AchievementsManager, XM = NEBUSTION.ExpeditionManager, PM = NEBUSTION.PrestigeManager, C = NEBUSTION.Combat;
const D = n => E.local(2026, 9, n, 12);            // n-ième jour d'octobre 2026, à midi (heure locale)

section('Données');
{
  ok(A.ACHIEVEMENTS.length === 5 && A.LONG_TERM.length === 4 && A.all().length === 9, '5 succès + 4 objectifs long terme');
  ok(new Set(A.all().map(a => a.id)).size === 9, 'identifiants uniques');
  ok(A.all().every(a => a.tiers.length === 3 && a.rewards.length === 3 && a.tiers.every((v, i) => i === 0 || v > a.tiers[i - 1])), 'chaque succès : 3 paliers croissants, 3 récompenses');
  ok(A.ACHIEVEMENTS.every(a => a.category === 'succes') && A.LONG_TERM.every(a => a.category === 'longterme'), 'catégories « succes » / « longterme »');
  ok(A.TIERS.join() === 'bronze,argent,or' && A.TIER_COLOR.or && A.TIER_COLOR.bronze, 'paliers bronze / argent / or');
  ok(A.get('ach_battles') && A.get('zz') === null && A.get('__proto__') === null, 'get() : connu / inconnu / prototype');
  const d = A.get('ach_command');
  ok(A.tierReached(d, 0) === 0 && A.tierReached(d, 5) === 1 && A.tierReached(d, 9) === 1 && A.tierReached(d, 10) === 2 && A.tierReached(d, 20) === 3 && A.tierReached(d, 999) === 3, 'tierReached : seuils exacts');
  ok(A.DAILY_REWARDS.length === 7, 'calendrier de 7 jours');
  ok(A.dailyReward(1) === A.DAILY_REWARDS[0] && A.dailyReward(7) === A.DAILY_REWARDS[6] && A.dailyReward(8) === A.DAILY_REWARDS[0] && A.dailyReward(15) === A.DAILY_REWARDS[0], 'récompense quotidienne : cycle de 7 en boucle');
  ok(A.dailyReward(0) === A.DAILY_REWARDS[0] && A.dailyReward(-3) === A.DAILY_REWARDS[0], 'jour ≤ 0 → 1er jour');
  ok(A.get('lt_heroes').tiers[2] === NEBUSTION.Heroes.all().length, 'objectif « héros » : palier or = nombre total de héros (' + NEBUSTION.Heroes.all().length + ')');
}

const g = E.freshGame(), R = g.R, SM = NEBUSTION.ShopManager;
const H = E.freeHeroes();
const S = () => R.state;

section('Lecture des métriques');
{
  ok(AM.valueOf('commandLevel') === S().buildings.command.level, 'commandLevel = niveau du Commandement');
  ok(AM.valueOf('zzz') === 0 && AM.valueOf('battlesWon') === 0 && AM.valueOf('totalStars') === 0 && AM.valueOf('conqueredPlanets') === 0, 'valeurs de départ à 0, métrique inconnue → 0');
  S().buildings.command.level = 7; S().combat.battlesWon = 12; E.giveStars(11); S().galaxy.conquered = { s2: true, s3: false, s4: true };
  ok(AM.valueOf('commandLevel') === 7 && AM.valueOf('battlesWon') === 12 && AM.valueOf('totalStars') === 11 && AM.valueOf('conqueredPlanets') === 2, 'niveau, victoires, étoiles, planètes conquises');
  ok(AM.valueOf('heroesUnlocked') === NEBUSTION.Heroes.all().filter(h => !h.shop).length, 'héros recrutés = héros gratuits au départ');
  const shopHero = NEBUSTION.Heroes.all().filter(h => h.shop)[0];
  if (shopHero) { C.unlockHero(shopHero.id); ok(AM.valueOf('heroesUnlocked') === NEBUSTION.Heroes.all().filter(h => !h.shop).length + 1, 'recruter un héros de Boutique fait monter le compteur'); }
  ok(AM.valueOf('prestigeCount') === 0 && AM.valueOf('relicsTotal') === 0 && AM.valueOf('eventBossKills') === 0 && AM.valueOf('expeditionsCompleted') === 0, 'compteurs Renaissance / boss / expéditions à 0');
  S().events.stats.bossKills = 3; S().prestige.count = 2; S().prestige.totalEarned = 25;
  ok(AM.valueOf('eventBossKills') === 3 && AM.valueOf('prestigeCount') === 2 && AM.valueOf('relicsTotal') === 25, 'boss, Renaissances et reliques lus depuis leurs systèmes');
  S().events.stats.bossKills = 0; S().prestige.count = 0; S().prestige.totalEarned = 0;
}

section('Succès : paliers et réclamation');
{
  const all = AM.list(), succ = AM.list('succes'), lt = AM.list('longterme');
  ok(all.length === 9 && succ.length === 5 && lt.length === 4, 'list() : tout / succès / long terme');
  const bat = () => AM.list().find(a => a.id === 'ach_battles');
  ok(bat().value === 12 && bat().reached === 1 && bat().claimed === 0 && bat().claimable && !bat().maxed && bat().nextTarget === 10, 'ach_battles : 12 victoires → bronze atteint, réclamable');
  ok(AM.claimableCount() >= 2, 'claimableCount compte les succès prêts');
  const dust0 = S().res.dust;
  const c = AM.claim('ach_battles');
  ok(c.ok && c.tier === 1 && c.tierName === 'bronze' && c.granted.dust > 0 && S().res.dust > dust0, 'palier bronze : poussière créditée');
  ok(AM.claim('ach_battles').reason === 'verrouille', 'pas de double réclamation du même palier');
  ok(!bat().claimable && bat().claimed === 1 && bat().nextTarget === 50, 'après réclamation : prochain palier = 50');
  S().combat.battlesWon = 60;
  ok(bat().reached === 2 && bat().claimable, 'palier argent atteint');
  const g0 = SM.gems(), c2 = AM.claim('ach_battles');
  ok(c2.ok && c2.tierName === 'argent' && SM.gems() === g0 + 15 && c2.granted.gems === 15, 'palier argent : +15 Prismes');
  ok(AM.claim('ach_battles').reason === 'verrouille', 'or non atteint : refusé');
  S().combat.battlesWon = 500;
  const c3 = AM.claim('ach_battles');
  ok(c3.ok && c3.tierName === 'or' && bat().maxed && bat().nextTarget === null && !bat().claimable, 'palier or : succès terminé');
  ok(AM.claim('ach_battles').reason === 'verrouille' && AM.claim('zzz').reason === 'invalide', 'terminé / inconnu : refusé');
  // Réclamer plusieurs paliers d'un coup : un par appel
  S().buildings.command.level = 25;
  ok(AM.claim('ach_command').tier === 1 && AM.claim('ach_command').tier === 2 && AM.claim('ach_command').tier === 3 && AM.claim('ach_command').ok === false, 'plusieurs paliers atteints : réclamés un par un, dans l\'ordre');
  // Expéditions terminées → succès
  E.giveStars(25); H.slice(0, 3).forEach(id => E.setLevel(id, 30));
  for (let i = 0; i < 5; i++) XM.launch('m_courte_facile', [H[i % 3]], D(1) - 4 * 3600000 + i), XM.claimAll(D(1) + 3600000 * i);
  const ex = AM.list().find(a => a.id === 'ach_expeditions');
  ok(ex.value === XM.stats().completed && ex.value >= 5 && ex.claimable, 'expéditions réclamées comptées pour « Capitaine explorateur »');
}

section('Succès conservés après une Renaissance (meilleure valeur atteinte)');
{
  S().buildings.command.level = 28; E.giveStars(20); S().combat.battlesWon = 700;
  AM.snapshot();
  S().buildings.command.level = 3; E.giveStars(0); S().combat.battlesWon = 0;
  ok(AM.valueOf('commandLevel') === 28 && AM.valueOf('battlesWon') === 700 && AM.valueOf('totalStars') >= 20, 'valeurs remises à zéro, mais le pic est conservé');
  ok(AM.list().find(a => a.id === 'ach_stars').reached >= 2, 'paliers déjà atteints restent atteints');
  S().buildings.command.level = 30;
  ok(AM.valueOf('commandLevel') === 30, 'une valeur supérieure au pic le remplace');
  S().buildings.command.level = 3;
  ok(AM.valueOf('commandLevel') === 30, 'et le nouveau pic est conservé');
}

section('Récompenses quotidiennes : série et calendrier');
{
  const st0 = AM.dailyStatus(D(1));
  ok(st0.available && st0.streak === 0 && st0.nextStreak === 1 && st0.cycleDay === 1 && st0.cycleLength === 7 && st0.doneInCycle === 0, 'départ : disponible, série 0, jour 1/7');
  const dust0 = S().res.dust;
  const c1 = AM.claimDaily(D(1));
  ok(c1.ok && c1.streak === 1 && S().res.dust === dust0 + 500 && c1.granted.dust === 500, 'jour 1 : +500 poussière, série 1');
  ok(AM.claimDaily(D(1) + 3600000).reason === 'deja' && !AM.dailyStatus(D(1) + 3600000).available, 'une seule récompense par jour');
  const after = AM.dailyStatus(D(1) + 3600000);
  ok(after.nextStreak === 2 && after.cycleDay === 2 && after.doneInCycle === 1, 'après réclamation : la carte de demain est annoncée');
  const cr0 = S().res.crystal, c2 = AM.claimDaily(D(2));
  ok(c2.ok && c2.streak === 2 && S().res.crystal === cr0 + 400, 'jour 2 (consécutif) : +400 cristaux, série 2');
  const g0 = SM.gems(), c3 = AM.claimDaily(D(3));
  ok(c3.ok && c3.streak === 3 && SM.gems() === g0 + 10, 'jour 3 : +10 Prismes');
  const c4 = AM.claimDaily(D(4)), c5 = AM.claimDaily(D(5)), core0 = S().res.core, c6 = AM.claimDaily(D(6));
  ok(c4.ok && c5.ok && c6.ok && c6.streak === 6 && S().res.core >= core0 + 2 - 1e-9, 'jours 4 à 6 : série 6, +2 noyaux au jour 6');
  const g1 = SM.gems(), c7 = AM.claimDaily(D(7));
  ok(c7.ok && c7.streak === 7 && SM.gems() === g1 + 30 && c7.granted.dust > 0 && c7.granted.crystal > 0, 'jour 7 : gros lot (30 Prismes + poussière + cristaux)');
  const c8 = AM.claimDaily(D(8));
  ok(c8.ok && c8.streak === 8 && c8.reward === A.DAILY_REWARDS[0], 'jour 8 : la série continue et le calendrier reboucle sur le jour 1');
  ok(AM.dailyStatus(D(8) + 1).nextStreak === 9 && AM.dailyStatus(D(8) + 1).cycleDay === 2 && A.dailyReward(8) === A.DAILY_REWARDS[0], 'jour 8 = récompense du jour 1 du calendrier');
  ok(AM.dailyStatus(D(8)).bestStreak === 8, 'record de série = 8');
  // Jour manqué → série remise à 1
  const c10 = AM.claimDaily(D(10));
  ok(c10.ok && c10.streak === 1 && AM.dailyStatus(D(10)).bestStreak === 8, 'jour manqué : la série repart à 1, le record est conservé');
  ok(AM.dailyStatus(D(12)).nextStreak === 1 && AM.dailyStatus(D(12)).available, 'plusieurs jours manqués : la prochaine récompense est celle du jour 1');
}

section('Anti-retour d\'horloge');
{
  const d = AM.claimDaily(D(20));
  ok(d.ok, 'réclamation le 20');
  const streak = d.streak;
  ok(!AM.dailyStatus(D(15)).available && AM.claimDaily(D(15)).reason === 'deja', 'horloge reculée : aucune récompense supplémentaire');
  ok(!AM.dailyStatus(D(20) - 2 * 86400000).available && AM.dailyStatus(D(21)).available, 'reculer la date n\'en donne pas, avancer d\'un jour oui');
  ok(AM.claimDaily(D(21)).streak === streak + 1, 'la série continue normalement le lendemain');
}

section('Robustesse de normalizeState + sauvegarde');
{
  ok(AM.normalizeState(null).daily.streak === 0 && AM.normalizeState('x').claimed.ach_battles === undefined && AM.normalizeState(9).daily.lastClaimDay === -1, 'entrées absurdes → état neuf');
  const n = AM.normalizeState({ claimed: { ach_battles: 99, ach_stars: -2, zz: 3, lt_boss: 2.9 }, peak: { battlesWon: 1e15, commandLevel: -4, zz: 5, totalStars: 'a' }, daily: { streak: -3, lastClaimDay: 'x', bestStreak: 5.8, totalClaims: NaN } });
  ok(n.claimed.ach_battles === 3 && !('ach_stars' in n.claimed) && !('zz' in n.claimed) && n.claimed.lt_boss === 2, 'paliers réclamés bornés à [0, 3], id inconnu écarté');
  ok(n.peak.battlesWon === 1e12 && !('commandLevel' in n.peak) && !('zz' in n.peak) && !('totalStars' in n.peak), 'pics bornés, valeurs invalides écartées');
  ok(n.daily.streak === 0 && n.daily.lastClaimDay === -1 && n.daily.bestStreak === 5 && n.daily.totalClaims === 0, 'quotidien : valeurs négatives / NaN corrigées');
  R.saveNow(Date.now());
  const loaded = NEBUSTION.Save.load().state;
  const back = NEBUSTION.Save.normalize(JSON.parse(JSON.stringify(loaded)), Date.now());
  ok(back.achievements.claimed.ach_battles === 3 && back.achievements.daily.streak === S().achievements.daily.streak && back.achievements.peak.commandLevel === 30, 'sauvegarde aller-retour : paliers, série et pics conservés');
}

t.done('TESTS SUCCÈS');
