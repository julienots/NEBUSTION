/*
 * Test de fumée dans un vrai Chromium (Playwright) avec un FAUX Phaser (tests/mock-phaser.js),
 * ciblé sur la nouvelle exploration du Trou Noir (BlackHoleScene + BlackHoleManager).
 *   node tests/blackhole-smoke.js
 */
const http = require('http'), fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const root = path.join(__dirname, '..');
const mock = fs.readFileSync(path.join(__dirname, 'mock-phaser.js'), 'utf8');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const CHROME = process.env.CHROME_PATH || '/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome';

const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]);
  if (u === '/js/vendor/phaser.min.js') { res.writeHead(200, { 'Content-Type': 'text/javascript' }); return res.end(mock); }
  const f = path.join(root, u === '/' ? 'index.html' : u);
  if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('nf'); }
  res.writeHead(200, { 'Content-Type': mime[path.extname(f)] || 'application/octet-stream' }); res.end(fs.readFileSync(f));
});

let passed = 0, failed = 0;
const ok = (c, m) => { if (c) passed++; else { failed++; console.log('  ✗ ' + m); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  await new Promise(r => server.listen(8766, r));
  const browser = await chromium.launch({ executablePath: fs.existsSync(CHROME) ? CHROME : undefined, args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 780 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  // Le bruit réseau (musiques d'ambiance absentes de ce ZIP, Firebase bloqué hors ligne) est sans
  // rapport avec la logique du jeu et n'est jamais une erreur JS : on ne garde que les vraies erreurs.
  page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errors.push('console.error: ' + m.text()); });
  const url = 'http://localhost:8766/index.html?debug=1';

  async function waitScene(key, ms) {
    const t0 = Date.now();
    while (Date.now() - t0 < (ms || 15000)) {
      if (await page.evaluate(k => !!(window.__NEBUSTION_GAME__ && window.__NEBUSTION_GAME__.scene.isActive(k)), key)) return true;
      await sleep(100);
    }
    return false;
  }
  const R = expr => page.evaluate(expr);

  console.log('# Chargement + accès direct au Trou Noir');
  await page.goto(url);
  ok(await waitScene('MainMenuScene'), 'MainMenuScene atteinte');
  ok(errors.length === 0, 'aucune erreur au chargement : ' + errors.join(' | '));
  ok(await R('typeof NEBUSTION.BlackHole === "object" && typeof NEBUSTION.BlackHoleManager === "object"'), 'modules Trou Noir chargés dans le navigateur');

  await R(`__NEBUSTION_GAME__.scenes.MainMenuScene.scene.start('BlackHoleScene', { from: 'MainMenuScene' })`);
  ok(await waitScene('BlackHoleScene'), 'BlackHoleScene démarrée');
  await sleep(200);
  ok(await R(`__NEBUSTION_GAME__.scenes.BlackHoleScene._mode`) === 'closeup', 'mode initial : gros plan');
  ok(errors.length === 0, 'aucune erreur à l\'entrée sur BlackHoleScene : ' + errors.join(' | '));

  console.log('# Plongée : tunnel puis exploration');
  await R(`NEBUSTION.Resources.state.blackhole.charge = { ch: 3, t: Date.now() }`);
  await R(`__NEBUSTION_GAME__.scenes.BlackHoleScene._onDiveButton()`);
  await sleep(2400); // délai (500) + tunnel (1300) + marge
  const mode1 = await R(`__NEBUSTION_GAME__.scenes.BlackHoleScene._mode`);
  ok(mode1 === 'interior', 'entrée en exploration après le tunnel (mode = ' + mode1 + ')');
  ok(errors.length === 0, 'aucune erreur pendant la plongée : ' + errors.join(' | '));
  ok(await R(`__NEBUSTION_GAME__.scenes.BlackHoleScene.explLayer.visible`), 'calque d\'exploration visible');
  ok(await R(`NEBUSTION.BlackHoleManager.currentOptions().length`) === 3, '3 options proposées à la première profondeur');

  console.log('# Résolution de plusieurs nœuds (choix, résultat, continuer / Seuil / remontée forcée)');
  let forced = false, sawAbimeCard = false, sawContinue = false, sawIntegrityTag = false;
  for (let i = 0; i < 30 && !forced; i++) {
    const opts = await R(`NEBUSTION.BlackHoleManager.currentOptions()`);
    if (opts.some(o => o.forced === 'abime')) sawAbimeCard = true;
    await R(`__NEBUSTION_GAME__.scenes.BlackHoleScene._onChoose(${opts[0].idx})`);
    await sleep(220); // flash de transition
    const hasContinue = await R(`__NEBUSTION_GAME__.scenes.BlackHoleScene.explLayer.list.some(o => o.labelText && /CONTINUER/.test(o.labelText.text))`);
    const hasExit = await R(`__NEBUSTION_GAME__.scenes.BlackHoleScene.explLayer.list.some(o => o.labelText && /REMONTER/.test(o.labelText.text))`);
    const outcomeKind = await R(`__NEBUSTION_GAME__.scenes.BlackHoleScene._pendingOutcome && __NEBUSTION_GAME__.scenes.BlackHoleScene._pendingOutcome.outcome.kind`);
    if (outcomeKind === 'echo' || outcomeKind === 'abime') sawIntegrityTag = true;
    if (hasContinue) { sawContinue = true; await R(`__NEBUSTION_GAME__.scenes.BlackHoleScene.explLayer.list.filter(o => o.labelText && /CONTINUER/.test(o.labelText.text))[0].onClick()`); await sleep(60); }
    else if (hasExit) { forced = true; }
    if (errors.length) break;
  }
  ok(errors.length === 0, 'aucune erreur JS pendant la résolution des nœuds : ' + errors.join(' | '));
  ok(sawContinue, 'au moins un nœud résolu avec bouton CONTINUER');

  if (forced) {
    console.log('  (fin forcée atteinte pendant le test — vérification du retour forcé)');
    await R(`__NEBUSTION_GAME__.scenes.BlackHoleScene.explLayer.list.filter(o => o.labelText && /REMONTER/.test(o.labelText.text))[0].onClick()`);
  } else {
    console.log('# Remontée volontaire');
    await R(`__NEBUSTION_GAME__.scenes.BlackHoleScene._onRetreat()`);
  }
  await sleep(1200);
  ok(await R(`__NEBUSTION_GAME__.scenes.BlackHoleScene._mode`) === 'closeup', 'retour en mode gros plan après remontée');
  ok(errors.length === 0, 'aucune erreur pendant la remontée : ' + errors.join(' | '));
  ok(await R(`NEBUSTION.BlackHoleManager.maxDepthReached()`) > 0, 'profondeur record enregistrée : ' + await R(`NEBUSTION.BlackHoleManager.maxDepthReached()`));

  console.log('# Comptoir de l\'Abîme (améliorations + échanges)');
  await R(`NEBUSTION.Resources.state.blackhole.fragments = 10000`);
  await R(`__NEBUSTION_GAME__.scenes.BlackHoleScene._openExchange()`);
  await sleep(150);
  ok(await R(`__NEBUSTION_GAME__.scenes.BlackHoleScene.exchangeLayer.visible`), 'Comptoir ouvert');
  ok(errors.length === 0, 'aucune erreur à l\'ouverture du Comptoir : ' + errors.join(' | '));

  const hullBefore = await R(`NEBUSTION.BlackHoleManager.talentLevel('hull')`);
  await R(`__NEBUSTION_GAME__.scenes.BlackHoleScene._buyTalent('hull')`);
  await sleep(80);
  ok(await R(`NEBUSTION.BlackHoleManager.talentLevel('hull')`) === hullBefore + 1, 'achat d\'amélioration (Coque renforcée) via le Comptoir');

  const crystalBefore = await R(`NEBUSTION.Resources.get('crystal')`);
  await R(`__NEBUSTION_GAME__.scenes.BlackHoleScene._buyExchange('ex_crystal')`);
  await sleep(80);
  ok(await R(`NEBUSTION.Resources.get('crystal')`) > crystalBefore, 'échange de Fragments contre des Cristaux via le Comptoir');
  ok(errors.length === 0, 'aucune erreur pendant les achats du Comptoir : ' + errors.join(' | '));

  await R(`__NEBUSTION_GAME__.scenes.BlackHoleScene._closeExchange()`);
  await sleep(80);
  ok(!(await R(`__NEBUSTION_GAME__.scenes.BlackHoleScene.exchangeLayer.visible`)), 'Comptoir fermé proprement');

  console.log('# Persistance après rechargement');
  const depthBefore = await R(`NEBUSTION.BlackHoleManager.maxDepthReached()`);
  await R(`NEBUSTION.Resources.saveNow(Date.now())`);
  await page.reload();
  ok(await waitScene('MainMenuScene'), 'redémarrage OK après rechargement');
  const depthAfter = await R(`NEBUSTION.BlackHoleManager.maxDepthReached()`);
  ok(depthAfter === depthBefore, 'profondeur record conservée après rechargement (' + depthAfter + ' === ' + depthBefore + ')');

  ok(errors.length === 0, 'aucune erreur JS sur l\'ensemble de la session : ' + errors.join(' | '));
  await browser.close(); server.close();
  console.log('\n' + (failed === 0 ? '✔ TEST DE FUMÉE TROU NOIR OK' : '✘ ' + failed + ' échec(s)') + ' (' + passed + ' vérifications)');
  process.exit(failed === 0 ? 0 : 1);
})().catch(async e => { console.error('ERREUR TEST :', e); process.exit(2); });
