/* Faux Phaser : les shaders s'installent, s'appliquent, et sont ignorés proprement sans WebGL / en économie de batterie. */
global.window = global;
var fs = require('fs'), vm = require('vm'), path = require('path'), fails = 0, n = 0;
function ok(c, m) { n++; if (!c) { fails++; console.log('ÉCHEC', m); } }
var added = {}, post = {}, uni = {};
function mkScene(type) {
  var img = { pp: null, getPostPipeline: function () { return post.inst || null; }, setPostPipeline: function (k) { post.inst = new post.cls({}); post.inst.rim = [0, 0, 0]; return img; } };
  return { img: img, sys: { settings: { key: 'UniverseScene' }, game: { renderer: type === null ? null : { type: type, pipelines: { addPostPipeline: function (k, c) { post.cls = c; post.name = k; } } } } },
    scale: { width: 720, height: 1280 },
    cache: { shader: { exists: function (k) { return !!added[k]; }, add: function (k, b) { added[k] = b; } } },
    add: { shader: function () { var s = { setDepth: function () { return s; }, setUniform: function (k, v) { uni[k] = v; return s; } }; return s; } } };
}
global.Phaser = { WEBGL: 2, CANVAS: 1, Display: { BaseShader: function (k, f, v, u) { this.frag = f; this.u = u; } },
  Renderer: { WebGL: { Pipelines: { PostFXPipeline: class { constructor(cfg) { this.cfg = cfg; this.game = { loop: { time: 1000 } }; } set1f() {} set3f() {} } } } } };
global.NEBUSTION = { Settings: { get: function () { return {}; } } };
vm.runInThisContext(fs.readFileSync(path.join(__dirname, '..', 'js/utils/Shaders.js'), 'utf8'));
var S = NEBUSTION.Shaders;
ok(/void main/.test(S._SPACE_FRAG) && /gl_FragColor/.test(S._SPACE_FRAG) && /void main/.test(S._PLANET_FRAG), 'sources GLSL présentes');
// équilibre des accolades / parenthèses GLSL
[S._SPACE_FRAG, S._PLANET_FRAG].forEach(function (f, i) { ok((f.match(/\{/g) || []).length === (f.match(/\}/g) || []).length && (f.match(/\(/g) || []).length === (f.match(/\)/g) || []).length, 'GLSL ' + i + ' équilibré'); });
// Canvas : tout est ignoré sans erreur
var c = mkScene(1); ok(S.install(c.sys.game) === false && S.space(c, 'space') === null && S.planet(c, c.img, 0xffffff) === false, 'Canvas ignoré');
// avant boot (renderer absent) : pas d'exception
Phaser.Core = { Events: { READY: 'ready' } }; var pending = null;
var g0 = { renderer: null, events: { once: function (e, f) { pending = f; } } };
ok(S.install(g0) === false && typeof pending === 'function', 'installation différée jusqu\'au READY');
// WebGL
var w = mkScene(2); ok(S.install(w.sys.game) === true && post.name === 'NebPlanetFX', 'pipeline planète enregistré');
ok(S.space(w, 'galaxy') !== null && added.neb_space_shader && uni['uMode.value'] === 1, 'fond galaxie (uMode 1)');
S.space(w, 'space'); ok(uni['uMode.value'] === 0 && Object.keys(added).length === 1, 'fond espace, shader partagé');
ok(S.planet(w, w.img, 0x62c0ff) === true && Math.abs(post.inst.rim[2] - 1) < 1e-9, 'planète : couleur du liseré');
// économie de batterie / effets réduits
NEBUSTION.Settings.get = function () { return { batterySaver: true }; };
ok(S.space(w, 'space') === null && S.planet(w, w.img, 0) === false, 'batterySaver : shaders désactivés');
NEBUSTION.Settings.get = function () { return { reducedFX: true }; }; ok(S.space(w, 'space') === null, 'reducedFX : désactivé');
console.log(n - fails + '/' + n + ' vérifications OK'); process.exit(fails ? 1 : 0);
