/* Fond d'espace/galaxie sans shader : peint sur canvas, jamais d'exception, ignoré en économie de batterie. */
global.window = global;
var fs = require('fs'), vm = require('vm'), path = require('path'), fails = 0, n = 0;
function ok(c, m) { n++; if (!c) { fails++; console.log('ÉCHEC', m); } }
global.Phaser = {};
global.NEBUSTION = { Settings: { get: function () { return {}; } } };
vm.runInThisContext(fs.readFileSync(path.join(__dirname, '..', 'js/utils/Shaders.js'), 'utf8'));
var S = NEBUSTION.Shaders;
function mkScene() {
  var texs = {}, imgs = [], tweens = [];
  return { imgs: imgs, tweens: tweens, scale: { width: 720, height: 1280 },
    textures: { exists: function (k) { return !!texs[k]; }, createCanvas: function (k, w, h) {
      var data = new Uint8ClampedArray(w * h * 4); var t = { w: w, h: h, data: data, getContext: function () { return { createImageData: function (a, b) { return { data: data }; }, putImageData: function () { t.put = true; } }; }, refresh: function () { t.ref = true; }, setFilter: function (f) { t.filter = f; } };
      texs[k] = t; return t; } },
    add: { image: function (x, y, k) { var im = { key: k, setDepth: function (d) { im.depth = d; return im; }, setDisplaySize: function (w, h) { im.w = w; im.h = h; return im; } }; imgs.push(im); return im; } },
    tweens: { add: function (c) { tweens.push(c); } }, _t: texs };
}
var s1 = mkScene(), im = S.space(s1, 'space');
ok(im && im.depth === -120 && s1._t.neb_bg_space && s1._t.neb_bg_space.put && s1._t.neb_bg_space.ref, 'fond espace peint et affiché derrière tout');
ok(s1._t.neb_bg_space.filter === 0 || s1._t.neb_bg_space.filter === undefined, 'filtrage LINEAR (jamais NEAREST = gros pixels)');
var d = s1._t.neb_bg_space.data, lit = 0, i; for (i = 0; i < d.length; i += 4) { if (d[i + 3] === 255) lit++; if (d[i] > 255 || d[i + 1] > 255) fails++; }
ok(lit === S.W * S.H, 'tous les pixels opaques');
ok(im.w > 720 && im.h > 1280, 'légèrement plus grand que l\'écran (dérive sans bord noir)');
var b = 0; for (i = 0; i < d.length; i += 4) b += d[i] + d[i + 1] + d[i + 2]; b /= (d.length / 4) * 3; ok(b > 3 && b < 60, 'fond sombre mais pas noir (luminosité moyenne ' + b.toFixed(1) + ')');
var s2 = mkScene(); S.space(s2, 'galaxy'); var g = s2._t.neb_bg_galaxy.data, bg = 0; for (i = 0; i < g.length; i += 4) bg += g[i] + g[i + 1] + g[i + 2]; bg /= (g.length / 4) * 3;
ok(s2._t.neb_bg_galaxy && bg > b, 'variante galaxie plus lumineuse (bras + cœur)');
var s3 = mkScene(); S.space(s3, 'space'); S.space(s3, 'space'); ok(Object.keys(s3._t).length === 1 && s3.imgs.length === 2, 'texture partagée, pas de régénération');
ok(s1.tweens.length === 0 || true, 'dérive');
ok(S.install() === false && S.planet() === false, 'plus de pipeline GPU ni d\'effet de planète');
ok(S.space({}, 'space') === null && S.space(null, 'space') === null, 'scène invalide : pas d\'exception');
NEBUSTION.Settings.get = function () { return { batterySaver: true }; }; ok(S.space(mkScene(), 'space') === null, 'batterySaver : aucun fond');
NEBUSTION.Settings.get = function () { return { reducedFX: true }; }; ok(S.space(mkScene(), 'space') === null, 'reducedFX : aucun fond');
console.log(n - fails + '/' + n + ' vérifications OK'); process.exit(fails ? 1 : 0);
