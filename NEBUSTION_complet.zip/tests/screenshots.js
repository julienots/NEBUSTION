/* Captures de MISE EN PAGE (faux Phaser : géométrie, textes, images, dégradés ; pas de particules/WebGL).
 * Sert à vérifier visuellement les écrans sans appareil. NODE_PATH=$(npm root -g) node tests/screenshots.js [dossier] */
const http = require('http'), fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const root = path.join(__dirname, '..'), out = process.argv[2] || '/tmp/shots';
fs.mkdirSync(out, { recursive: true });
const mock = fs.readFileSync(path.join(__dirname, 'mock-phaser.js'), 'utf8');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png' };
const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]);
  if (u === '/js/vendor/phaser.min.js') { res.writeHead(200, { 'Content-Type': 'text/javascript' }); return res.end(mock); }
  const f = path.join(root, u === '/' ? 'index.html' : u);
  if (!fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('nf'); }
  res.writeHead(200, { 'Content-Type': mime[path.extname(f)] || 'application/octet-stream' }); res.end(fs.readFileSync(f));
});
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  await new Promise(r => server.listen(8767, r));
  const browser = await chromium.launch();
  const page = await (await browser.newContext({ viewport: { width: 720, height: 1280 } })).newPage();
  page.on('pageerror', e => console.log('ERR', e.message));
  const R = e => page.evaluate(e);
  async function shot(scene, name) {
    const data = await R(`(() => { const c = document.createElement('canvas'); c.width = 720; c.height = 1280; Phaser._render(__NEBUSTION_GAME__.scenes.${scene}, c.getContext('2d'), 720, 1280); return c.toDataURL('image/png'); })()`);
    fs.writeFileSync(path.join(out, name + '.png'), Buffer.from(data.split(',')[1], 'base64'));
  }
  const active = () => R(`Object.keys(__NEBUSTION_GAME__.active)[0]`);
  const go = async (scene, data) => { await R(`__NEBUSTION_GAME__.scenes.${await active()}.scene.start('${scene}', ${JSON.stringify(data || {})})`); await sleep(700); };
  await page.goto('http://localhost:8767/index.html?debug=1'); await sleep(4500);
  await go('CombatPrepScene'); await shot('CombatPrepScene', '1_preparation');
  await R(`(() => { const s = __NEBUSTION_GAME__.scenes.CombatPrepScene; s.pickScroll = 200; s.pickContainer.y = s.pickTop - 200; s._moveStage(4); })()`); await sleep(200);
  await shot('CombatPrepScene', '2_preparation_boss_verrouille');
  await go('CombatScene', { stageId: 'stage_03', difficulty: 'normal' });
  await R(`(() => { const s = __NEBUSTION_GAME__.scenes.CombatScene; s.engine.player[0].energy = 100; s.engine.player[2].hp = s.engine.player[2].maxHp * 0.4; s.heroViews[2].targetHp = s.heroViews[2].shownHp = s.heroViews[2].ghostHp = s.engine.player[2].hp; })()`);
  await sleep(2600); await shot('CombatScene', '3_combat_stage');
  await go('CombatScene', { stageId: 'boss_nexus_prime', difficulty: 'normal' });
  await R(`(() => { const s = __NEBUSTION_GAME__.scenes.CombatScene; s.engine.enemy[0].hp *= 0.6; s.bossView.targetHp = s.bossView.shownHp = s.bossView.ghostHp = s.engine.enemy[0].hp; s.engine.player[1].shield = 200; s.engine.player[3].stunTime = 3; })()`);
  await sleep(2000); await shot('CombatScene', '4_combat_boss');
  await R(`(() => { const s = __NEBUSTION_GAME__.scenes.CombatScene; s.engine.enemy.forEach(u => { u.hp = 1; }); s._cycleSpeed(); s._cycleSpeed(); })()`);
  await sleep(4200); await shot('CombatScene', '5_resultat');
  await browser.close(); server.close(); console.log('captures dans', out);
})();
