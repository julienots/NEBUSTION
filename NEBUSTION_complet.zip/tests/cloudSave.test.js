/* Tests du compte + sauvegarde en ligne (NEBUSTION.CloudSave), Node, faux Firebase en mémoire (aucun réseau).
 * Lancer : node tests/cloudSave.test.js */
'use strict';
const E = require('./progress-env');
const t = E.makeCounter(), ok = t.ok, section = t.section;

// ---------- Faux Firebase (Auth + Firestore, transactions comprises) ----------
const docs = {}; let failGet = false, authCb = null, curUser = null;
const fakeDb = {
  collection: name => ({ doc: id => { const path = name + '/' + id; return {
    path,
    get: () => failGet ? Promise.reject({ code: 'unavailable', message: 'offline' }) : Promise.resolve({ exists: path in docs, data: () => docs[path] }),
    set: p => { docs[path] = p; return Promise.resolve(); } }; } }),
  runTransaction: fn => { const writes = []; const tx = { get: ref => ref.get(), set: (ref, p) => { writes.push([ref.path, p]); } };
    return Promise.resolve(fn(tx)).then(r => { writes.forEach(w => { docs[w[0]] = w[1]; }); return r; }); }
};
global.firebase = { initializeApp: () => ({}), auth: () => ({ onAuthStateChanged: cb => { authCb = cb; }, signOut: () => { curUser = null; authCb && authCb(null); return Promise.resolve(); } }), firestore: () => fakeDb };
NEBUSTION.FirebaseConfig = { apiKey: 'test', projectId: 'test' };
require('../js/systems/CloudSave.js');
const CS = NEBUSTION.CloudSave;
function login(uid) { curUser = { uid, email: uid + '@x.fr' }; authCb(curUser); }
const wait = () => new Promise(r => setTimeout(r, 5));
const stripVolatile = st => { const c = JSON.parse(JSON.stringify(st)); delete c.sid; delete c.savedAt; delete c.lastSeen; delete c.events; return JSON.stringify(c); };   // events : cycle horaire recalculé à chaque chargement
const P1 = NEBUSTION.Galaxy.PLANETS.find(p => p.kind !== 'home').id;   // conquered[id] = horodatage de conquête

(async () => {
  section('Initialisation');
  ok(CS.init() === true && CS.isReady(), 'CloudSave.init() réussit avec le faux Firebase');
  ok(CS.pushSave({ savedAt: 1 }) instanceof Promise, 'pushSave renvoie une promesse');
  login('alice'); await wait();
  ok(CS.currentUser() && CS.currentUser().uid === 'alice', 'utilisateur connecté');

  section('Garde : aucun envoi avant réconciliation');
  {
    const g = E.freshGame(); global.localStorage = g.store;
    const r = await CS.pushSave(g.R.state, { force: true });
    ok(r === false && !('saves/alice' in docs), 'garde fermée → rien n\'est écrit dans le compte');
  }

  section('decide() — table de décision');
  {
    const cl = (createdAt, savedAt) => ({ status: 'ok', state: { createdAt }, savedAt });
    ok(CS.decide({ createdAt: 5, baseline: 100, isNew: false }, { status: 'none' }, true) === 'push', 'compte vide → envoi');
    ok(CS.decide({ createdAt: 5, baseline: 0, isNew: true }, cl(5, 999), true) === 'adopt', 'appareil neuf + compte plein → restauration');
    ok(CS.decide({ createdAt: 5, baseline: 100, isNew: false }, cl(9, 50), true) === 'conflict', 'deux parties différentes → choix du joueur');
    ok(CS.decide({ createdAt: 5, baseline: 100, isNew: false }, cl(5, 50), true) === 'push', 'même partie, compte plus ancien → envoi');
    ok(CS.decide({ createdAt: 5, baseline: 100, isNew: false }, cl(5, 9000), true) === 'adopt', 'même partie, compte plus récent, au démarrage → restauration');
    ok(CS.decide({ createdAt: 5, baseline: 100, isNew: false }, cl(5, 9000), false) === 'conflict', 'même partie, compte plus récent, en cours de session → choix');
    ok(CS.decide({ createdAt: 5, baseline: 100, isNew: false }, cl(5, 101), true) === 'push', 'écart < 2 s = tolérance');
  }

  section('Partie jouée → compte → nouvel appareil : tout est restauré');
  let A, cloudSavedAt;
  {
    const g = E.freshGame(); global.localStorage = g.store; A = g.R;
    // On joue : ressources, bâtiment, combat, étoiles, boutique...
    A.state.res.crystal = 1234; A.state.life.crystal = 9999;
    A.state.buildings.storage.level = 4;
    A.state.combat.stageStars = { s1: 3, s2: 2 }; A.state.combat.unlockedHeroes = { zyra: true }; A.state.combat.fragments = { vega: 12 };
    A.state.galaxy.conquered = { [P1]: 1000 };
    A.state.prestige.relics = 7; A.state.achievements && (A.state.achievements.claimed = A.state.achievements.claimed || {});
    A.saveNow(Date.now());
    E.freshGame; // (no-op)
    const res = await CS.sync(A.state, { baseline: A.loadInfo.state ? A.loadInfo.state.savedAt : 0, isNew: true, atStart: false });
    // Pas de compte encore → push
    ok(res.action === 'pushed', 'première synchro : la partie est envoyée (' + res.action + ')');
    ok(CS.isGateOpen(), 'garde ouverte après réconciliation');
    const d = docs['saves/alice']; cloudSavedAt = d.savedAt;
    ok(d && typeof d.data === 'string' && d.by === CS._deviceId(), 'document Firestore écrit avec l\'identifiant de l\'appareil');
    const st = JSON.parse(d.data);
    ok(st.res.crystal === 1234 && st.buildings.storage.level === 4, 'ressources et bâtiments dans le compte');
    ok(st.combat.stageStars.s2 === 2 && st.combat.unlockedHeroes.zyra && st.combat.fragments.vega === 12, 'combat, étoiles, héros et fragments dans le compte');
    ok(st.galaxy.conquered[P1] === 1000 && st.prestige.relics === 7, 'conquêtes et Prestige dans le compte');
    const modules = ['galaxy', 'empires', 'equipment', 'ships', 'skins', 'shop', 'pass', 'expeditions', 'events', 'prestige', 'achievements', 'security', 'qgGrid', 'qgRaid', 'qgAttack', 'symbiote'];
    const present = modules.filter(m => m in st);
    ok(present.length === modules.length, 'les ' + modules.length + ' modules du jeu sont dans la sauvegarde envoyée (manque : ' + modules.filter(m => !(m in st)).join(',') + ')');
  }
  {
    // Nouvel appareil : stockage vide → nouvelle partie → connexion → restauration
    const g2 = E.freshGame(); global.localStorage = g2.store;
    ok(g2.R.isNewGame, 'nouvel appareil = nouvelle partie');
    CS._reset();
    const res = await CS.sync(g2.R.state, { baseline: 0, isNew: true, atStart: true });
    ok(res.action === 'adopted', 'nouvel appareil : la partie du compte est restaurée');
    const stored = E.freshGame && NEBUSTION.Save.load();
    ok(stored.state && stored.state.res.crystal === 1234, 'la sauvegarde locale contient maintenant la partie du compte');
    const g3 = new NEBUSTION.ResourceManager(); g3.init(Date.now());
    ok(!g3.isNewGame && g3.state.buildings.storage.level === 4 && g3.state.combat.stageStars.s1 === 3, 'rechargement : bâtiments, étoiles retrouvés');
    ok(g3.state.combat.unlockedHeroes.zyra === true && g3.state.galaxy.conquered[P1] === 1000 && g3.state.prestige.relics === 7, 'rechargement : héros, conquêtes, reliques retrouvés');
    ok(stripVolatile(NEBUSTION.Save.normalize(JSON.parse(docs['saves/alice'].data), Date.now())) === stripVolatile(NEBUSTION.Save.normalize(stored.state, Date.now())), 'partie restaurée identique à celle du compte (hors horodatages)');
  }

  section('Régression : la sauvegarde de fermeture ne réécrit pas la partie restaurée');
  {
    // Fausse fenêtre/document : on capte les écouteurs de fermeture installés par ResourceManager
    const handlers = {}; const fakeWin = { addEventListener: (n, f) => { (handlers[n] = handlers[n] || []).push(f); } };
    const fakeDoc = { hidden: false, addEventListener: (n, f) => { (handlers['doc:' + n] = handlers['doc:' + n] || []).push(f); } };
    const g = E.freshGame(); global.localStorage = g.store; NEBUSTION.Resources = g.R;
    g.R.installLifecycle(fakeWin, fakeDoc);
    g.R.state.res.crystal = 5;   // état périmé en mémoire (partie « vide » de l'appareil)
    CS._reset();
    const cloudState = JSON.parse(docs['saves/alice'].data);
    CS.adopt(cloudState);
    handlers['pagehide'].forEach(f => f()); handlers['beforeunload'].forEach(f => f());   // ce que fait location.reload()
    const after = NEBUSTION.Save.load().state;
    ok(after && after.res.crystal === 1234, 'après fermeture/rechargement, la sauvegarde restaurée n\'a PAS été écrasée par l\'ancien état');
    ok(g.store.getItem(NEBUSTION.Save.KEY + '_before_cloud'), 'l\'ancienne partie de l\'appareil est gardée en copie de secours');
    NEBUSTION.Resources = null;
  }

  section('Deux appareils : jamais d\'écrasement silencieux');
  {
    const g = E.freshGame(); global.localStorage = g.store;
    CS._reset(); CS.signOut && 0;
    const base = g.R.loadInfo.state ? g.R.loadInfo.state.savedAt : 0;
    // Le compte contient une partie de la même lignée
    const lineage = JSON.parse(docs['saves/alice'].data).createdAt;
    g.R.state.createdAt = lineage; g.R.saveNow(Date.now());
    let r = await CS.sync(g.R.state, { baseline: Date.now(), isNew: false, atStart: false });
    ok(r.action === 'pushed' && CS.isGateOpen(), 'même lignée, appareil à jour → envoi');
    // Un autre appareil écrit une version plus récente
    const before = docs['saves/alice'];
    const other = Object.assign({}, before, { by: 'autre-appareil', savedAt: before.savedAt + 50000, data: JSON.stringify(Object.assign(JSON.parse(before.data), { savedAt: before.savedAt + 50000, res: Object.assign(JSON.parse(before.data).res, { crystal: 650 }) })) });
    docs['saves/alice'] = other;
    let fired = 0; const off = CS.onConflict(() => fired++);
    const pushed = await CS.pushSave(g.R.state, { force: true });
    ok(pushed === false, 'l\'envoi est refusé quand un autre appareil a une version plus récente');
    ok(docs['saves/alice'] === other, 'le compte n\'a PAS été écrasé');
    ok(CS.getPendingConflict() && CS.getPendingConflict().res.crystal === 650, 'le conflit conserve la partie de l\'autre appareil');
    ok(fired === 1 && !CS.isGateOpen(), 'conflit signalé + envois bloqués');
    ok(await CS.pushSave(g.R.state, { force: true }) === false, 'aucun envoi tant que le joueur n\'a pas choisi');
    off();
    // Choix : garder cet appareil
    const kept = await CS.keepLocal(g.R.state);
    ok(kept === true && docs['saves/alice'].by === CS._deviceId() && CS.isGateOpen() && !CS.getPendingConflict(), '« Garder cet appareil » : le compte est remplacé, envois rétablis');
    // Nouveau conflit puis choix : utiliser le compte
    const other2 = Object.assign({}, other, { savedAt: other.savedAt + 90000 });
    docs['saves/alice'] = other2;
    await CS.pushSave(g.R.state, { force: true });
    ok(!!CS.getPendingConflict(), 'nouveau conflit détecté');
    NEBUSTION.Resources = g.R;
    const n = CS.useCloud();
    ok(n && NEBUSTION.Save.load().state.res.crystal === 650 && CS.getPendingConflict() === null, '« Utiliser le compte » : la partie du compte est écrite localement');
    NEBUSTION.Resources = null;
  }

  section('Lecture impossible ≠ compte vide');
  {
    CS._reset(); const g = E.freshGame(); global.localStorage = g.store;
    const snapshot = docs['saves/alice'];
    failGet = true;
    const r = await CS.sync(g.R.state, { baseline: 0, isNew: false, atStart: true });
    failGet = false;
    ok(r.action === 'error' && !CS.isGateOpen(), 'hors ligne au démarrage : erreur, envois bloqués');
    ok(docs['saves/alice'] === snapshot, 'le compte n\'est pas écrasé par une partie vide');
    ok(CS.getLastSync().ok === false && typeof CS.getLastSync().error === 'string', 'l\'échec est exposé à l\'interface (dernier envoi)');
  }

  section('Limitation d\'envoi + envoi immédiat à la mise en veille');
  {
    CS._reset(); const g = E.freshGame(); global.localStorage = g.store;
    docs['saves/alice'] = undefined; delete docs['saves/alice'];
    const r0 = await CS.sync(g.R.state, { baseline: 0, isNew: true, atStart: false });
    ok(r0.action === 'pushed', 'compte vide : envoi initial');
    const w1 = docs['saves/alice'].updatedAt;
    g.R.state.res.crystal = 4242;
    const r1 = await CS.pushSave(g.R.state);
    ok(r1 === false && JSON.parse(docs['saves/alice'].data).res.crystal !== 4242, 'envoi automatique limité (20 s) : différé');
    const r2 = await CS.flush(g.R.state);
    ok(r2 === true && JSON.parse(docs['saves/alice'].data).res.crystal === 4242, 'flush() envoie immédiatement (mise en veille / fermeture)');
    CS._reset();
  }

  section('Sauvegarde auto (périodique)');
  {
    CS._reset(); const g = E.freshGame(); global.localStorage = g.store;
    delete docs['saves/alice'];
    const auto = CS.startAutoSave(() => g.R.state, { everyMs: 40 });
    await new Promise(r => setTimeout(r, 120));
    ok(!('saves/alice' in docs), 'garde fermée : la sauvegarde auto n\'envoie rien');
    await CS.sync(g.R.state, { baseline: 0, isNew: true, atStart: false });
    g.R.state.res.crystal = 321;
    await new Promise(r => setTimeout(r, 150));
    ok(JSON.parse(docs['saves/alice'].data).res.crystal === 321, 'garde ouverte : l\'intervalle envoie les changements tout seul');
    g.R.state.res.crystal = 654; await auto.now();
    ok(JSON.parse(docs['saves/alice'].data).res.crystal === 654, 'auto.now() envoie immédiatement');
    auto.stop(); const w = docs['saves/alice'].updatedAt; g.R.state.res.crystal = 111;
    await new Promise(r => setTimeout(r, 120));
    ok(docs['saves/alice'].updatedAt === w, 'stop() arrête la sauvegarde auto');
    CS._reset();
  }

  section('Déconnexion + résumé + taille');
  {
    const sm = CS.summarize({ savedAt: 10, stats: { playSec: 3700 }, combat: { stageStars: { a: 3, b: 1 } }, buildings: { x: { level: 2 }, y: { level: 5 } }, galaxy: { conquered: { p: 1, q: 1 } } });
    ok(sm.playSec === 3700 && sm.stars === 4 && sm.buildingLevels === 7 && sm.conquered === 2, 'summarize : temps, étoiles, niveaux, conquêtes');
    ok(CS.summarize(null).stars === 0, 'summarize tolère null');
    const g = E.freshGame(); global.localStorage = g.store;
    const big = JSON.parse(JSON.stringify(g.R.state)); big.junk = 'x'.repeat(950000);
    const rb = await CS.pushSave(big, { override: true });
    ok(rb === false && /volumineuse/.test(CS.getLastSync().error), 'sauvegarde > 900 Ko refusée avec un message clair');
    await CS.signOut();
    ok(!CS.isGateOpen() && CS.getPendingConflict() === null, 'déconnexion : garde refermée');
  }

  t.done('Compte + sauvegarde en ligne (CloudSave)');
})().catch(e => { console.log('  ✗ EXCEPTION', e); process.exit(1); });
