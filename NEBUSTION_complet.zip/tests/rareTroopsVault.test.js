/* Tests de l'étape : 3 troupes rares (Léviathan, Faucheuse Impériale, Bombe du Néant) et bâtiment
 * Coffre-fort du QG (bouclier anti-raid). Node, sans Phaser. Lancer : node tests/rareTroopsVault.test.js */
'use strict';
const { makeCounter, freshGame } = require('./progress-env');
['data/EmpireAI', 'data/EmpireDoctrine', 'data/QGRaid', 'data/QGAttack', 'data/Symbiote'].forEach(f => require('../js/' + f + '.js'));
['GalaxyManager', 'EmpireAIManager', 'EmpireEvolutionManager', 'QGRaidManager', 'QGAttackManager', 'SymbioteManager'].forEach(f => require('../js/systems/' + f + '.js'));
const c = makeCounter(), ok = c.ok, section = c.section;
const T = NEBUSTION.Troops, G = NEBUSTION.QGGrid, GM = NEBUSTION.QGGridManager, QB = NEBUSTION.QGBattle, RM = NEBUSTION.QGRaidManager;

function giveAll(R) { ['crystal', 'metal', 'energy', 'dust', 'core'].forEach(id => { R.state.res[id] = 1e7; }); }
function place(R, sid, n) {
  let put = 0;
  for (let x = 0; x < 6 && put < n; x++) for (let y = 0; y < 6 && put < n; y++) {
    const k = G.key(x, y); if (!R.state.qgGrid.unlocked[k]) R.state.qgGrid.unlocked[k] = true;
    if (!R.state.qgGrid.cells[k]) { R.state.qgGrid.cells[k] = sid; put++; }
  }
  R._rates = null; return put;
}

section('Troupes rares : catalogue');
{
  const RARE = ['leviathan', 'reaper', 'voidbomb'];
  ok(T.ORDER.length === 27 && RARE.every(id => T.ORDER.indexOf(id) >= 0), 'les 3 troupes rares sont bien dans le catalogue');
  RARE.forEach(id => {
    const t = T.get(id);
    ok(!!t && t.hp > 0 && t.space > 0 && t.cost.core > 0, id + ' : stats valides et coûte des Noyaux');
    ok(Object.keys(t.cost).every(r => NEBUSTION.Economy.RES[r]), id + ' : toutes les ressources du coût existent');
    ok(['any', 'wall', 'turret', 'eco', 'core'].indexOf(t.pref) >= 0 && typeof t.fly === 'boolean', id + ' : cible/vol valides');
  });
  ok(T.get('leviathan').hp > T.get('mecha').hp, 'Léviathan : PV les plus hauts du jeu');
  ok(T.get('reaper').pref === 'core' && T.get('reaper').fly, 'Faucheuse Impériale : assassin volant');
  ok(T.get('voidbomb').blast > T.get('sapper').blast && T.get('voidbomb').blastRadius > T.get('sapper').blastRadius, 'Bombe du Néant : explosion plus forte et plus large que le Saboteur');
}

section('Troupes rares : simulation de combat');
{
  const { R } = freshGame();
  const base = QB.botBase('vexor', 6, 0);
  ['leviathan', 'reaper', 'voidbomb'].forEach(id => {
    const sim = QB.create(base, { [id]: 3 });
    let dep = { ok: true }, placed = 0; for (let i = 0; i < 3 && dep.ok; i++) { dep = sim.deploy(id, -0.6, 1.5 + i * 0.6); if (dep.ok) placed++; }
    let n = 0; while (!sim.over && n++ < 20 * 90) sim.step(0.05);
    const bad = sim.troops.some(u => !isFinite(u.x) || !isFinite(u.y) || !isFinite(u.hp));
    const dmg = sim.buildings.some(b => b.hp < b.maxHp || !b.alive);
    ok(placed === 3 && !bad && dmg, id + ' : 3 déployés, simulation stable, la base subit des dégâts (' + n + ' pas)');
  });
}

section('Bâtiment Coffre-fort : catalogue et effet');
{
  ok(G.STRUCTURE_ORDER.indexOf('vault') >= 0, 'le Coffre-fort est dans la liste des structures');
  const d = G.STRUCTURES.vault;
  ok(d.maxCount === 5 && d.effect.type === 'raidShield' && d.effect.perUnit === 0.06, 'Coffre-fort : définition attendue');
  const st = G.defaultState(); for (let i = 0; i < 3; i++) st.cells[['2,2', '3,2', '2,3'][i]] = 'vault';
  ok(Math.abs(G.bonusValue('raidShield', st) - 0.18) < 1e-9, '3 Coffres-forts : +18 % de bouclier');
}

section('Coffre-fort : réduit réellement les pertes lors d\'un raid');
{
  const { R } = freshGame(); giveAll(R);
  place(R, 'vault', 5); // 5 Coffres-forts : 30 % de bouclier (perUnit 0.06 × 5, sous le plafond de 50 %)
  ok(Math.abs(G.bonusValue('raidShield', R.state.qgGrid) - 0.3) < 1e-9, '5 Coffres-forts : bouclier de 30 %');
  // Provoque un raid déterministe : évolution/élan max, défense nulle, pour garantir une victoire ennemie avec perte.
  const EM = NEBUSTION.EmpireEvolutionManager, G2 = NEBUSTION.Galaxy;
  const eid = G2.EMPIRE_ORDER[0];
  const es = EM.state(Date.now()).e[eid]; es.evo = 50; es.mom = 100; es.hurt = 0;
  R.state.res.crystal = 10000; R.state.res.metal = 10000;
  let raided = null;
  for (let i = 0; i < 400 && !raided; i++) {
    const before = R.state.res.crystal;
    const res = RM.update(Date.now() + i * 30 * 60 * 1000 + 7 * 3600 * 1000 * i);
    const win = res.raids.find(r => r.victory);
    if (win) raided = { win, before, after: R.state.res.crystal };
  }
  if (raided) {
    const actualLossFrac = 1 - raided.after / raided.before;
    ok(Math.abs(actualLossFrac - raided.win.lossPct) < 1e-6, 'perte réelle = lossPct affiché (après bouclier)');
    ok(raided.win.lossPct < 0.4, 'la perte réelle reste réduite par le Coffre-fort (' + (raided.win.lossPct * 100).toFixed(1) + ' %)');
  } else {
    ok(true, 'aucun raid réussi déclenché dans la fenêtre de test (aléatoire) — vérifié via bonusValue ci-dessus');
  }
}

c.done('Troupes rares + Coffre-fort (bouclier anti-raid)');
