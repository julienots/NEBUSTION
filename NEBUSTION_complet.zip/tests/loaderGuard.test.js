/* Tests du garde-fou de chargement des images (LoaderGuard) + intégrité des illustrations.
 * Lancer : node tests/loaderGuard.test.js */
'use strict';
global.window = global;
const fs = require('fs'), path = require('path'), zlib = require('zlib');
require('../js/data/Heroes.js'); require('../js/data/Enemies.js'); require('../js/utils/LoaderGuard.js');
let passed = 0, failed = 0;
const ok = (c, m) => { if (c) passed++; else { failed++; console.log('  ✗ ECHEC : ' + m); } };
const section = t => console.log('\n# ' + t);
const G = NEBUSTION.LoaderGuard;

// Faux scène : loader (émetteur) + horloge pilotée à la main + Date.now simulé.
function fakeScene() {
  const handlers = {}, events = [];
  const load = { on(n, f) { (handlers[n] = handlers[n] || []).push(f); }, off(n, f) { handlers[n] = (handlers[n] || []).filter(x => x !== f); }, emit(n, a) { (handlers[n] || []).slice().forEach(f => f(a)); } };
  const time = { addEvent(cfg) { const ev = { cfg, dead: false, remove() { ev.dead = true; } }; events.push(ev); return ev; } };
  return { load, time, handlers, tickSecond() { events.filter(e => !e.dead).forEach(e => e.cfg.callback()); }, live() { return events.filter(e => !e.dead).length; } };
}
const realNow = Date.now; let clock = 1e12;
Date.now = () => clock;
const advance = (sc, sec) => { for (let i = 0; i < sec; i++) { clock += 1000; sc.tickSecond(); } };

section('LoaderGuard : chargement lent mais actif ≠ bloqué');
{
  const sc = fakeScene(); let stalled = 0;
  const g = G.watch(sc, () => stalled++);
  for (let i = 0; i < 40; i++) { advance(sc, 5); sc.load.emit('fileprogress', {}); }   // 200 s au total, activité toutes les 5 s
  ok(stalled === 1, 'plafond absolu (120 s) atteint malgré l\'activité (' + stalled + ')');
  const sc2 = fakeScene(); let s2 = 0;
  G.watch(sc2, () => s2++, { maxMs: 1e9 });
  for (let i = 0; i < 100; i++) { advance(sc2, 10); sc2.load.emit('filecomplete', 'k'); }   // 1000 s de chargement actif (10 s entre 2 fichiers)
  ok(s2 === 0, 'un chargement lent mais actif n\'est jamais interrompu (l\'ancien délai fixe de 4 s l\'aurait été)');
}
section('LoaderGuard : chargement réellement bloqué');
{
  const sc = fakeScene(); let stalled = 0;
  G.watch(sc, () => stalled++);
  advance(sc, 10); ok(stalled === 0, 'pas de blocage après 10 s de silence');
  advance(sc, 6); ok(stalled === 1, 'blocage déclaré après 15 s sans aucun octet');
  advance(sc, 30); ok(stalled === 1 && sc.live() === 0, 'déclenché une seule fois, horloge arrêtée');
  ok((sc.handlers.fileprogress || []).length === 0 && (sc.handlers.filecomplete || []).length === 0, 'écouteurs retirés');
}
section('LoaderGuard : arrêt propre');
{
  const sc = fakeScene(); let stalled = 0;
  const g = G.watch(sc, () => stalled++);
  advance(sc, 5); g.stop(); advance(sc, 60);
  ok(stalled === 0 && sc.live() === 0, 'stop() : plus aucun déclenchement');
  g.stop(); ok(true, 'stop() idempotent');
}
Date.now = realNow;

section('Intégrité des illustrations');
{
  const root = path.join(__dirname, '..');
  const SIG = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  let total = 0;
  function check(file, label) {
    const p = path.join(root, file);
    if (!fs.existsSync(p)) { ok(false, label + ' : fichier manquant (' + file + ')'); return; }
    const b = fs.readFileSync(p); total += b.length;
    ok(b.slice(0, 8).equals(SIG), label + ' : signature PNG');
    // Parcours des blocs : CRC valides, IHDR/IDAT/IEND présents (fichier non tronqué)
    let off = 8, seen = {}, good = true;
    while (off + 12 <= b.length) {
      const len = b.readUInt32BE(off), type = b.toString('ascii', off + 4, off + 8);
      if (off + 12 + len > b.length) { good = false; break; }
      const crc = b.readInt32BE(off + 8 + len);
      if (zlib.crc32 && (zlib.crc32(b.slice(off + 4, off + 8 + len)) | 0) !== crc) { good = false; break; }
      seen[type] = true; off += 12 + len;
      if (type === 'IEND') break;
    }
    ok(good && seen.IHDR && seen.IDAT && seen.IEND, label + ' : PNG complet et non corrompu');
  }
  NEBUSTION.Heroes.all().filter(h => h.id !== 'aeon').forEach(h => { check(NEBUSTION.Heroes.portraitFile(h.id), 'héros ' + h.id); });
  NEBUSTION.Heroes.all().filter(h => h.id !== 'aeon').forEach(h => { const b = fs.readFileSync(path.join(root, NEBUSTION.Heroes.portraitFile(h.id))); ok(b.readUInt32BE(16) === 300 && b.readUInt32BE(20) === 380, h.id + ' : 300×380'); });
  const sw = fs.readFileSync(path.join(root, 'sw.js'), 'utf8');
  const enemyFiles = fs.readdirSync(path.join(root, 'assets/enemies')).filter(f => f.endsWith('.png'));
  enemyFiles.forEach(f => check('assets/enemies/' + f, 'boss/ennemi ' + f));
  ok(enemyFiles.length >= 13, 'illustrations d\'ennemis présentes (' + enemyFiles.length + ')');
  console.log('   poids total des illustrations : ' + (total / 1048576).toFixed(1) + ' Mo');
  const idx = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  ok(idx.indexOf('js/utils/LoaderGuard.js') >= 0 && idx.indexOf('js/utils/LoaderGuard.js') < idx.indexOf('js/utils/HeroTextures.js'), 'LoaderGuard chargé avant HeroTextures');
  ok(sw.indexOf('js/utils/LoaderGuard.js') >= 0, 'LoaderGuard dans le cache hors-ligne');
  const ht = fs.readFileSync(path.join(root, 'js/utils/HeroTextures.js'), 'utf8'), et = fs.readFileSync(path.join(root, 'js/utils/EnemyTextures.js'), 'utf8');
  ok(!/delayedCall\(\s*4000/.test(ht) && !/delayedCall\(\s*4000/.test(et), 'plus aucun délai fixe de 4 s dans les chargeurs d\'images');
  ok(!/Promise\.all\(CORE\.map/.test(sw), 'le pré-cache ne lance plus ~120 téléchargements simultanés');
}
console.log('\n' + passed + ' réussis, ' + failed + ' échoués');
process.exit(failed ? 1 : 0);
