/* Tests de la logique des constructions libres sur la planète (PlanetBuild) : coûts, distance, placement,
 * déplacement, recyclage, sauvegarde corrompue. Lancer : node tests/planetBuild.test.js */
'use strict';
global.window = global;
require('../js/data/Economy.js'); require('../js/data/PlanetBuild.js');
let passed = 0, failed = 0;
const ok = (c, m) => { if (c) passed++; else { failed++; console.log('  ✗ ECHEC : ' + m); } };
const section = t => console.log('\n# ' + t);
const P = NEBUSTION.PlanetBuild, E = NEBUSTION.Economy;

// Faux gestionnaire de ressources (même contrat que ResourceManager : canAfford / spendMany / add / saveNow).
function fakeR(res) {
  const r = { state: { res: Object.assign({ crystal: 0, metal: 0, energy: 0, dust: 0, core: 0 }, res), planetBuild: P.defaultState() }, saves: 0 };
  r.canAfford = c => Object.keys(c).every(k => r.state.res[k] + 1e-9 >= c[k]);
  r.spendMany = c => { if (!r.canAfford(c)) return false; Object.keys(c).forEach(k => { r.state.res[k] -= c[k]; }); return true; };
  r.add = (k, n) => { r.state.res[k] += n; };
  r.saveNow = () => { r.saves++; };
  return r;
}
const RICH = { crystal: 1e6, metal: 1e6, energy: 1e6, dust: 1e6 };

section('Catalogue');
ok(P.ORDER.length === 8 && P.ORDER.every(k => P.CATALOG[k]), '8 bâtiments dans le catalogue');
P.ORDER.forEach(k => {
  const d = P.CATALOG[k];
  ok(Object.keys(d.base).every(id => E.RES[id]), k + ' : coûts sur des ressources existantes');
  ok(d.maxCount >= 1 && d.growth > 1 && d.name && d.icon && d.info, k + ' : champs complets');
});
ok(P.cost('beacon', 0).crystal === 30 && P.cost('beacon', 1).crystal === Math.ceil(30 * 1.25), 'coût croissant par exemplaire');
ok(Object.keys(P.cost('inconnu', 0)).length === 0, 'type inconnu : coût vide');

section('Géométrie');
ok(Math.abs(P.angDist(0, 0, 90, 0) - 90) < 1e-6, 'distance 90° sur l\'équateur');
ok(Math.abs(P.angDist(170, 0, -170, 0) - 20) < 1e-6, 'passage de l\'antiméridien');
ok(Math.abs(P.angDist(0, 90, 123, 90)) < 1e-6, 'tous les méridiens se rejoignent au pôle');
ok(P.normLon(190) === -170 && P.normLon(-190) === 170 && P.normLon(540) === -180 + 360 - 360 + 0 || P.normLon(540) === -180, 'normalisation de la longitude');
ok(P.spotOk(0, 0, [{ lon: 30, lat: 0 }]) && !P.spotOk(0, 0, [{ lon: 10, lat: 0 }]), 'écart minimal entre constructions');
ok(!P.spotOk(0, 85, []) && !P.spotOk(NaN, 0, []) && !P.spotOk(0, Infinity, []), 'pôles et NaN refusés');
ok(P.spotOk(5, 0, [{ id: 'a', lon: 5, lat: 0 }], 'a'), 'on peut se replacer sur soi-même (déplacement)');

section('Pose');
{
  const R = fakeR(RICH), others = [{ lon: 46, lat: 6 }];
  const r = P.place(R, 'beacon', 10, 10, others);
  ok(r.ok && R.state.planetBuild.items.length === 1, 'pose réussie');
  ok(R.state.res.crystal === 1e6 - 30 && R.state.res.energy === 1e6 - 20, 'ressources débitées exactement');
  ok(R.saves === 1, 'sauvegarde déclenchée');
  ok(r.item.id === 'pb1', 'id séquentiel');
  ok(P.place(R, 'beacon', 12, 12, others).reason === 'spot', 'trop près d\'une construction : refus');
  ok(R.state.res.crystal === 1e6 - 30, 'refus : rien débité');
  ok(P.place(R, 'beacon', 48, 6, others).reason === 'spot', 'trop près d\'un bâtiment existant : refus');
  ok(P.place(R, 'zzz', 0, 0, []).reason === 'type', 'type inconnu refusé');
  const poor = fakeR({ crystal: 10 });
  ok(P.place(poor, 'beacon', 0, 0, []).reason === 'cost' && poor.state.planetBuild.items.length === 0 && poor.state.res.crystal === 10, 'ressources insuffisantes : tout ou rien');
  const many = fakeR(RICH);
  for (let i = 0; i < 6; i++) P.place(many, 'beacon', -150 + i * 40, 0, []);
  ok(P.count(many.state.planetBuild, 'beacon') === 6 && P.place(many, 'beacon', 100, 40, []).reason === 'max', 'plafond par type');
  const cap = fakeR(RICH); let n = 0;
  for (let i = 0; i < 12 && n < P.MAX_TOTAL + 5; i++) for (let j = 0; j < 8; j++) { const t = P.ORDER[j]; if (P.place(cap, t, -175 + ((i * 8 + j) * 31) % 350, -70 + (i * 13) % 140, []).ok) n++; }
  ok(cap.state.planetBuild.items.length <= P.MAX_TOTAL, 'plafond global respecté (' + cap.state.planetBuild.items.length + ')');
}

section('Déplacement et recyclage');
{
  const R = fakeR(RICH), it = P.place(R, 'dome', 0, 0, []).item;
  const before = R.state.res.crystal;
  ok(P.move(R, it.id, 60, 20, []).ok && it.lon === 60 && it.lat === 20, 'déplacement gratuit');
  ok(R.state.res.crystal === before, 'déplacement : aucun coût');
  ok(P.move(R, it.id, 60, 20, [{ lon: 62, lat: 20 }]).reason === 'spot', 'déplacement vers un endroit occupé : refus');
  ok(P.move(R, 'nope', 0, 0, []).reason === 'unknown', 'déplacement d\'un id inconnu');
  const c1 = P.cost('dome', 0);
  const rc = P.recycle(R, it.id);
  ok(rc.ok && R.state.planetBuild.items.length === 0, 'recyclage retire la construction');
  ok(R.state.res.crystal === before + Math.floor(c1.crystal * P.REFUND), 'remboursement de 50 %');
  ok(P.recycle(R, it.id).reason === 'unknown', 'double recyclage impossible');
  const R2 = fakeR(RICH); P.place(R2, 'pylon', 0, 0, []); P.place(R2, 'pylon', 60, 0, []);
  const paid2 = P.cost('pylon', 1), b2 = R2.state.res.metal;
  P.recycle(R2, 'pb2');
  ok(R2.state.res.metal === b2 + Math.floor(paid2.metal * 0.5), 'recycler le dernier exemplaire rembourse le prix du dernier payé');
}

section('Sauvegarde : normalizeState');
{
  const n = P.normalizeState({ v: 1, seq: 3, items: [
    { id: 'a', type: 'beacon', lon: 10.123456, lat: 20 }, { id: 'a', type: 'beacon', lon: 50, lat: 20 },
    { id: 'b', type: 'inconnu', lon: 0, lat: 0 }, { id: 'c', type: 'pylon', lon: 'x', lat: 0 },
    { id: 'd', type: 'pylon', lon: 999, lat: 500 }, null, 5, { type: 'silo', lon: 0, lat: 0 } ] });
  ok(n.items.length === 2, 'doublon, type inconnu, NaN, sans id, non-objets écartés (' + n.items.length + ')');
  ok(n.items[0].lon === 10.12, 'coordonnées arrondies');
  ok(n.items[1].lon === 180 && n.items[1].lat === P.MAX_LAT, 'coordonnées bornées');
  ok(n.seq >= 2, 'seq cohérente');
  ok(P.normalizeState(null).items.length === 0 && P.normalizeState('x').items.length === 0 && P.normalizeState({ items: 'x' }).items.length === 0, 'entrées invalides : état vide');
  const big = { items: [] }; for (let i = 0; i < 200; i++) big.items.push({ id: 'i' + i, type: 'pylon', lon: 0, lat: 0 });
  ok(P.normalizeState(big).items.length === P.CATALOG.pylon.maxCount, 'excédent par type coupé');
  const json = JSON.parse(JSON.stringify(n));
  ok(JSON.stringify(P.normalizeState(json)) === JSON.stringify(n), 'normalizeState idempotent après aller-retour JSON');
}

console.log('\n' + passed + ' vérifications OK, ' + failed + ' échec(s)');
process.exit(failed ? 1 : 0);
