# Paramètres Plus — intégré à NEBUSTION_TROUPES_AMELIOREES

Ajouté dans cette version :
- volume SFX indépendant ;
- vibration ON/OFF ;
- effets réduits ;
- économie batterie ;
- réinitialisation des paramètres ;
- persistance localStorage ;
- branchement des réglages aux sons et aux FX existants.

Aucun fichier existant ni asset n'a été supprimé.
