# NEBUSTION — Module 21 : jeu 100 % hors ligne + pose des bâtiments du QG

## Placement des bâtiments (QG) — `js/scenes/QGScene.js`
Trois causes, toutes corrigées :
1. **Taps volés par les structures** : chaque structure captait les taps dans un rectangle de 112×168 px → la parcelle libre
   juste *derrière* un bâtiment (et une partie de celles à côté) n'était plus touchable. Le test suit maintenant la **silhouette réelle**
   du bâtiment (lecture de la transparence de sa texture) + sa propre dalle ; la structure la plus en avant gagne.
2. **Seuil de glissement trop bas** : 8 px du jeu ≈ 4 px d'écran sur téléphone → un doigt qui tremble = « glissement » = tap perdu.
   Seuil porté à 22 px du jeu (≈ 12 px d'écran), et le tap vise l'endroit où le doigt a *touché*.
3. **Aucun retour quand ça échoue** : manque de ressources = simple tremblement d'écran. Maintenant un message
   « Ressources insuffisantes — Il manque : 40 Métal · 20 Cristaux » (idem : maximum atteint, parcelle verrouillée).
Cartes de construction : textes 13/12 px (au lieu de 11), un coût par ligne, cartes plus hautes (112 px), zone tactile élargie.

## Hors ligne — `sw.js`, `index.html`
- **Phaser n'est pas dans le ZIP** : il est maintenant *pré-mis en cache* depuis le CDN dès la première visite en ligne
  (avant, il ne l'était qu'« au passage », de façon fragile). Pour une robustesse totale : `node tools/get-phaser.js` puis
  déployer `js/vendor/phaser.min.js`.
- Service worker : réseau d'abord mais **3,5 s maximum** puis copie en cache (réseau lent/coupé à moitié = plus de blocage) ;
  recherche du cache sans tenir compte du `?…` ; page d'accueil de secours ; **requêtes « Range » (audio)** servies depuis le cache ;
  pré-cache complété (héros Outsiderz, carte Outsiderz). Cache : `nebustion-v27-hors-ligne`.
- Firebase (compte) : non chargé quand l'appareil est hors ligne (démarrage immédiat, sauvegarde locale).

## Tests
`python3 tests/browser-offline.py` (nouveau, 13 vérifs : 1re visite → coupure réseau → rechargement → menu → QG → taps).
Les autres tests inchangés. (2 échecs déjà présents dans l'archive d'origine : `loaderGuard` — image outsiderz 300×380, et 3 attentes périmées de `browser-combat.py`.)

## À valider sur téléphone
Faux Phaser en test (pas de vrai rendu) ; le test de silhouette (`getPixelAlpha`) n'est exercé que dans le vrai Phaser.
Procédure hors ligne : ouvrir le jeu **une fois en ligne** (attendre ~30 s), puis mode avion, puis relancer.
