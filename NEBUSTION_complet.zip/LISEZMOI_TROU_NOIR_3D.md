# Le Trou Noir — vraie destination 3D (mise à jour du 2026-09-30)

Le Trou Noir n'est plus une image posée sur un fond : c'est une **destination 3D** à part entière, comme les planètes
de Nexus-01 et de la Nouvelle Galaxie. On y **arrive en vol**, on **tourne autour du doigt**, on **s'approche** ou on
s'éloigne, puis on **plonge** (l'exploration à profondeurs et ses épreuves sont inchangées).

## Ce que voit le joueur

- **Arrivée en vol** (2,6 s) depuis la carte Univers : le trou noir n'est d'abord qu'un point minuscule, la caméra
  s'en rapproche jusqu'à la distance d'orbite. Même arrivée à chaque retour de plongée.
- **Glisser** = tourner autour (inclinaison du disque + roulis, avec inertie). **Pincer**, **molette** ou boutons **+ / −**
  = s'approcher / s'éloigner (jusqu'à voir l'ombre remplir l'écran).
- **Toucher franchement** le trou noir (sans glisser) = plonger, comme avant. Les boutons PLONGER et COMPTOIR sont inchangés.
- **PLONGER** : la caméra fonce vers l'horizon (l'ombre grandit, l'anneau de photons envahit l'écran), puis le tunnel de
  lumière existant prend le relais.
- Une ligne de **télémétrie** : distance (millions de km), inclinaison, et **dilatation du temps** (× 0,xx) qui diminue
  quand on s'approche.
- **Icône de la carte Univers** : le même rendu, en miniature vivante (disque qui tourne).

## Pourquoi c'est plus beau : la lumière est réellement courbée

Chaque pixel est un rayon lumineux dont la trajectoire suit l'équation de Schwarzschild (`u'' + u = 3u²`), intégrée une
fois (RK4) puis lue dans une table. Conséquences visibles, sans aucun truc dessiné à la main :

| Effet | Ce qu'on voit |
| --- | --- |
| Lentille gravitationnelle | La face **cachée** du disque se replie **au-dessus et au-dessous** de l'ombre (façon *Interstellar*) |
| Ombre | Disque noir de rayon 3√3 M ≈ 5,2 M, **opaque** devant le décor |
| Anneau de photons | Liseré fin et brillant qui fait le tour de l'ombre |
| Effet Doppler + décalage gravitationnel | Le côté qui **s'approche** est plus brillant et plus blanc/bleu ; le côté qui s'éloigne plus sombre et rouge |
| Étoiles lentillées | Le ciel derrière est étiré en arcs près de l'ombre |
| Disque turbulent | Stries le long de l'orbite, **rotation différentielle** (le centre tourne plus vite), palette corps noir brun → orange → blanc |
| Jets polaires, lueur | Jets bleutés très discrets ; lueur (bloom) légère autour des zones les plus chaudes |

Toutes les inclinaisons fonctionnent : de face (anneau), de biais, et par la tranche (disque fin + arcs lentillés).

## Coût / batterie

- Deux passes : **géométrie** (coûteuse) refaite seulement quand la caméra bouge ; **teinte** (≈ 1-2 ms) à chaque image
  (elle ne fait que tourner le disque).
- Résolution adaptative : plus basse pendant un geste (fluidité), pleine au repos, et **recule d'un cran** toute seule si
  l'appareil est lent (remonte s'il est rapide). Résolutions : 96 → 256 px, au repos 224 (160 en économie de batterie).
- Économie de batterie / effets réduits : résolution de repos 160, lueur atténuée, ~11 images/s au repos, icône de
  l'Univers figée.
- Aucun rendu pendant l'exploration (tunnel, épreuves) : le moteur ne tourne qu'en mode « gros plan ».
- Si le canvas n'est pas disponible : **repli automatique** sur l'ancienne image statique (`BlackHoleTextures.js`,
  conservé) — sans arrivée en vol ni boutons de zoom.

## Fichiers

- **Nouveau** `js/utils/BlackHoleRender.js` — le moteur (cœur sans dépendance à Phaser + enveloppe texture canvas).
- **Modifié** `js/scenes/BlackHoleScene.js` — rendu en direct, caméra orbitale, gestes, arrivée en vol, chute vers l'horizon.
  L'exploration, le Comptoir et les épreuves (`BlackHoleRunScene`) ne sont **pas** touchés.
- **Modifié** `js/scenes/UniverseScene.js` — icône vivante du nœud « Trou Noir ».
- **Modifié** `index.html`, `sw.js` (nouveau script + cache `v68`).
- **Nouveaux** `tests/blackhole-render.test.js` (32), `tests/blackhole-3d-smoke.js` (65), `tools/bh-preview.js`.
- Aucune sauvegarde ni donnée de jeu modifiée.

## Réglages (dans `BlackHoleScene._initCamera` / `BlackHoleRender.js`)

| Quoi | Où |
| --- | --- |
| Vue d'arrivée (distance, inclinaison, roulis) | `_camHome` = `{ W: 19, incl: 1.28, roll: -0.42 }` |
| Zoom mini / maxi, inclinaison mini / maxi | `WMIN`, `WMAX`, `INCL_MIN`, `INCL_MAX` |
| Durée de l'arrivée en vol | `_startIntro` → `dur` |
| Taille du disque (rayons M) | `R_IN`, `R_OUT` |
| Force de l'effet Doppler | `DOPPLER` (1 = physique, trop violent à l'écran) |
| Vitesse de rotation du disque | `W0` |
| Luminosité / contraste du disque | `GAIN`, `EXPO`, et l'intensité dans `shade()` |
| Palette du disque | `ANC` dans `buildDisk()` |
| Nombre d'étoiles lentillées | boucle `for (i = 0; i < 3400 ...)` dans `buildStars()` |

## Vérifier sans téléphone

```
node tools/bh-preview.js apercu.png --res 384 --incl 74 --roll -24 --w 19     # image PNG
node tools/bh-preview.js tranche.png --incl 86 --roll 0                       # disque par la tranche
node tests/blackhole-render.test.js && node tests/blackhole-3d-smoke.js
```

## À valider sur ton téléphone (honnêteté)

1. **Pas testé avec le vrai Phaser/WebGL** (pas de réseau ici) : la physique, l'image, les gestes et l'enchaînement des
   scènes sont vérifiés (rendu PNG sous Node + faux Phaser), mais la fluidité réelle dépend de l'appareil. Si le geste
   saccade, le moteur baisse seul la résolution ; en dernier recours, activer l'économie de batterie.
2. Sens du glissé : si l'inclinaison te semble inversée, changer le signe de `dIncl` dans `_orbitMove` (une ligne).
3. Le rendu suppose un observateur immobile autour d'un trou noir de Schwarzschild avec un disque « type rotation rapide »
   (bord interne à 4 M) : c'est une représentation fidèle dans l'esprit, pas une simulation scientifique complète.
