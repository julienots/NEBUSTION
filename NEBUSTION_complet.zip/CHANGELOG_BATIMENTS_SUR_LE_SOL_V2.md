# NEBUSTION — Bâtiments posés sur le sol (v2)
- `js/scenes/PlanetScene.js`, `_projectVec` : `tilt = MAX_TILT * (xa/len) * k` — le bâtiment suit la direction du sol
  (s'écarte du centre sur les côtés), inclinaison continue et plafonnée (`MAX_TILT = 1.15` rad ≈ 66°).
  Pas de saut, pas de bâtiment à l'envers ni couché à plat en bas de la planète.
- Réglage : `MAX_TILT` = 0 → toujours droits ; 1.57 → tout à fait perpendiculaires au sol.
- Cache PWA : `nebustion-v55-batiments-sur-le-sol`.
