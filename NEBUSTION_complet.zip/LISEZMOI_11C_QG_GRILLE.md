# NEBUSTION — Ajout : Zone constructible du QG (grille)

Fait suite à `LISEZMOI_11B_QG_SECURITE.md`. La zone intérieure du QG (`QGScene`) n'est plus
un simple bouton « SÉCURISER LA ZONE » : c'est maintenant une **vraie zone constructible**,
une grille de 6×6 parcelles plus grande que l'écran (on la fait glisser au doigt pour
l'explorer), où l'on déverrouille des parcelles puis y pose des structures qui apportent
de vrais bonus de jeu.

## Ce qui a été ajouté

- `js/data/QGGrid.js` (nouveau) : données pures — grille 6×6, noyau central (2×2)
  déverrouillé gratuitement au départ, coût de déverrouillage d'une parcelle (croissant
  linéairement avec le nombre déjà déverrouillé), catalogue de structures (`STRUCTURES`) :
  - **Générateur** 🔋 — effet `production` (+2 %/unité, jusqu'à 6)
  - **Silo** 🛢️ — effet `storage` (+3 %/unité, jusqu'à 6)
  - **Tourelle** 🗼 — effet `security` (+1 niveau équivalent/unité, jusqu'à 6)
  Coût de construction croissant par type (×1,35/unité déjà posée), remboursement à la
  revente (50 % du dernier coût payé). Aucune dépendance à Phaser, testable sous Node.
- `js/systems/QGGridManager.js` (nouveau) : glue avec `Resources`
  (`Resources.state.qgGrid = { unlocked, cells }`) — déverrouillage, construction, vente,
  `bonusValue(type)` consommé par `ResourceManager`/`SecurityManager`. Suit le patron de
  `SecurityManager.js`.
- `js/scenes/QGScene.js` (réécrite) : grille pannable (glisser pour explorer), parcelles
  verrouillées/vides/construites rendues différemment, tap pour ouvrir un panneau
  (déverrouiller / choisir une structure à construire / vendre), barre de bonus en temps
  réel (production, stockage, sécurité), compteur de parcelles.
- `js/systems/ResourceManager.js` : `rates()` et `cap()` intègrent désormais le bonus de
  la grille (même mécanisme que le bonus de Renaissance `PrestigeManager`), avec
  invalidation du cache `_rates` à chaque construction/vente.
- `js/systems/SecurityManager.js` : nouvelle fonction `effectiveLevel()` = niveau manuel +
  bonus des Tourelles posées (affichage uniquement ; `level()`/`cost()`/`upgrade()`
  inchangés, aucune régression sur l'ancien système).
- `js/systems/SaveManager.js` : `state.qgGrid` ajouté à `defaultState()`/`normalize()`,
  rétrocompatible (une sauvegarde sans ce champ reçoit le noyau central par défaut).
- `index.html`, `tests/progress-env.js` : nouveaux fichiers enregistrés dans l'ordre de
  chargement.

## Tests

`tests/qgGrid.test.js` (nouveau, 39 vérifications) : formules, déverrouillage, construction/
vente, plafonds, bonus réellement appliqués (production/stockage/sécurité), sauvegarde.

`for f in tests/*.test.js; do node $f | tail -1; done` → tout passe, sauf `shop.test.js`
(3 échecs préexistants et sans rapport, voir Pistes ci-dessous).

## Pistes pour la suite (pas fait ici)

- Faire dépendre la taille/le nombre de parcelles déverrouillables du niveau du bâtiment
  QG (actuellement indépendant, uniquement basé sur le coût en ressources).
- Textures dédiées pour les structures (actuellement fond coloré + emoji).
- `tests/shop.test.js` : le test « Lot express » ne crédite pas de Prismes avant l'achat
  quand le tirage du jour propose une offre `bundle` (coût en `gem` uniquement) — bug de
  test préexistant, sans rapport avec ce module, à corriger séparément.
