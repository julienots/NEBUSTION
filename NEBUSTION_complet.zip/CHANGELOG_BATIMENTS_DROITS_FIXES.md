# NEBUSTION — Bâtiments de Nexus-01 : plus d'inclinaison quand on tourne la planète

## Problème
En faisant glisser la planète, les bâtiments (et constructions libres) se penchaient et
changeaient de hauteur à l'écran : ils « tournaient un peu » au lieu de rester tels quels.

## Correctif (js/scenes/PlanetScene.js, méthode `_applyBox`)
- Plus d'**inclinaison** (`setRotation(0)`) : le bâtiment reste toujours droit.
- Plus d'**écrasement vertical** variable (échelle X = échelle Y) : même forme partout sur le globe.
- Le petit enfoncement de la dalle dans le sol est maintenant toujours vers le bas de l'écran.
- Le badge de niveau n'a plus de contre-rotation à appliquer.

## Ce qui reste identique
Le bâtiment suit toujours sa place sur la planète (position, taille selon la profondeur, fondu
derrière le globe, tap coupé quand il est caché). Ombre projetée et pastille au sol suivent
toujours la surface, pour que le bâtiment reste « posé ».

## Non modifié
Les gisements (ResourceNode) s'inclinent encore selon le sol : dis-moi si tu veux la même chose pour eux
(`setRotation(p.rot)` dans `_applySphereTransform`, branche `a.type === 'node'`).

## Non testé
Syntaxe vérifiée (`node --check`) ; rendu réel Phaser/téléphone à valider en jeu.
Cache du service worker : `nebustion-v48-batiments-droits-fixes`.
