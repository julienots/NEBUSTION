# NEBUSTION — Améliorations des troupes

Ajout d'un système permanent d'amélioration des troupes, branché sur la Caserne, la Boutique, les sauvegardes et le moteur de combat.

## 3 branches
- **Assaut** : +7 % DPS par rang, jusqu'à 5 rangs.
- **Blindage** : +8 % PV par rang, jusqu'à 5 rangs.
- **Propulsion** : +6 % vitesse et +0,05 portée par rang, jusqu'à 5 rangs.

Chaque troupe possède ses propres niveaux. Les améliorations sont conservées dans la sauvegarde et n'effacent pas le stock existant.

## Intégration
- Caserne : niveau réel + statistiques améliorées affichées ; toucher une troupe ouvre son panneau d'amélioration.
- Boutique : niveau et statistiques actuelles affichés pour chaque troupe.
- Combat QG : les statistiques améliorées sont appliquées au moment du déploiement, y compris DPS/PV/vitesse/portée et explosifs.
- Anciennes sauvegardes : migration automatique sans perte ; les anciennes troupes commencent avec les trois branches à 0.

Aucun ancien fichier, asset, son, carte, troupe ou mécanique n'est supprimé.
