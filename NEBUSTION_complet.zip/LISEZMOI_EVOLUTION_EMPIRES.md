# NEBUSTION — Évolution des 5 empires (module IA 3/3)

Suite de `EmpireAI` / `EmpireAIManager` (décisions). Rien n'est réécrit : la posture vient d'`EmpireAIManager.decide()`,
les planètes/flottes de `Galaxy.js`, les conquêtes de `GalaxyManager`. **Un seul état ajouté : `state.empires`.**

## Fichiers
| Fichier | Rôle |
|---|---|
| `js/data/EmpireEvolution.js` (nouveau) | Logique pure : coûts, plafonds, pas de simulation, défense évoluée, `normalizeState`. |
| `js/systems/EmpireEvolutionManager.js` (nouveau) | Branche le tout sur le jeu : `update`, `start/stop`, `battleSpec`, `planetInfo`, `empireStatus`. |
| `js/systems/SaveManager.js` (modifié, +2 blocs) | Sauvegarde/valide `empires` (ancienne sauvegarde → état neuf, aucun rattrapage rétroactif). |
| `tests/empireEvolution.test.js` (nouveau) | 146 vérifications. |

## Fonctionnement
- **Pas de 30 min** : chaque empire encaisse les dépôts de ses planètes non conquises (×0,12, ×(1+6 %/niveau d'évolution)),
  puis dépense (3 actions max/pas) selon sa posture : **développement** (0..8), **bouclier** (0..5), **tourelles** (0..4),
  **unités de renfort** (0..2/planète). Défensif → boucliers/tourelles ; offensif → unités ; équilibré → tout en douceur.
- **Borné** : plafonds fixes, coûts croissants ×1,5/niveau, stocks plafonnés, puissance finale ≈ ×1,3 à ×1,7 (test).
  Le développement max dépend du **niveau d'équipe du joueur** et de la difficulté (niv. 3 → evo 1 ; niv. 45 → evo 8).
  Sans plafond relevé, la progression s'arrête : jamais infinie.
- **Impact réel** : `EmpireEvolutionManager.battleSpec(pid)` remplace `Galaxy.battleSpec(pid)` (même format, défense évoluée,
  posture appliquée, récompenses +0..25 %). Un empire **offensif** peut **reprendre** une planète conquise depuis > 12 h
  (`GalaxyManager.setConquered(pid,false)`), max 1 / 24 h, jamais une capitale, seulement si ses défenses ne sont pas
  écrasées par le joueur. Capitale tombée = revenus −50 % ; empire entièrement conquis = plus aucun revenu.
- **Hors ligne, sans doublon** : aucun serveur ; au plus 24 h rattrapées (l'excédent est abandonné) ; `update()` ne rejoue
  jamais un pas (`lastAt`), horloge reculée ignorée, aléa déterministe (pas de `Math.random` → recharger ne change rien),
  `start()` = un seul minuteur, état indexé par empire/planète (pas de doublon possible).

## Connexion (comme les modules 1 et 2, non chargé tant que la scène Galaxie n'existe pas)
Ajouter dans `index.html` (après `SaveManager.js`) : `Galaxy.js`, `EmpireAI.js`, `EmpireEvolution.js`, `GalaxyManager.js`,
`EmpireAIManager.js`, `EmpireEvolutionManager.js` (et dans `sw.js`), puis dans `main.js` après `Resources.init` :
`NEBUSTION.EmpireEvolutionManager.start();`. Le module d'invasion appellera `EmpireEvolutionManager.battleSpec(pid)`.

## Tests
`node tests/empireEvolution.test.js` (146) · non-régression : galaxy 916, empireAI 220, economy 1763, heroes 312, enemies 265, combat 857, background 51 — tous verts.
