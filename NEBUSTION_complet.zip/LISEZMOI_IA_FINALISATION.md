# NEBUSTION — Module IA des 5 empires : version finale

Suite directe du ZIP « évolution des empires ». **Aucun système supprimé** : Galaxie, IA (décisions), évolution, économie, héros,
combat, sauvegarde et fond spatial sont conservés ; on n'a fait qu'ajouter et brancher.

## Ce qui change
| Fichier | Statut | Rôle |
|---|---|---|
| `js/data/EmpireDoctrine.js` | **nouveau** | Style de chaque empire, capacités (evo 2/4/6) + capacité de crise, adaptation aux pertes, unités entraînées (rang 0..3). Pur, sans Phaser. |
| `js/data/EmpireEvolution.js` | étendu | État v2 (mémoire, rangs, revendications ; l'ancien état v1 est migré), dépenses adaptées, plafonds propres à chaque empire. |
| `js/systems/EmpireEvolutionManager.js` | étendu | Mémoire des pertes, revendications, **carte / plan d'invasion / résultat d'invasion**, capacités dans `battleSpec`. |
| `js/data/EmpireAI.js`, `js/systems/EmpireAIManager.js` | +quelques lignes | La stratégie tient compte de la mémoire (blessé → plus défensif ; vient de tenir → plus offensif). Sans mémoire : décisions identiques à avant. |
| `index.html`, `sw.js`, `js/main.js` | branchés | Les 7 fichiers galaxie/IA sont chargés et mis en cache (hors ligne) ; `main.js` lance `EmpireAIManager.wire()` + `EmpireEvolutionManager.start()`. |
| `tests/empireAdaptation.test.js`, `tests/browser-empires.js` | nouveaux | 172 + 16 vérifications. |

## Adaptation des empires
- **Pertes** : chaque planète conquise par le joueur est comptée **une seule fois** (`lostAt`). Elle crée un *traumatisme* (`hurt` 0..1, plus fort pour une capitale, nul pour une conquête ancienne)
  qui s'estompe (½-vie ≈ 8 h). Blessé, l'empire investit plus en boucliers/tourelles, moins en développement, active sa **capacité de crise**.
- **Défenses tenues** : une défaite du joueur donne de l'*élan* (`mom`) → plus d'entraînement, de renforts, riposte plus probable. Borné à 1.
- **Ressources/situation** : capitale perdue = reconstruction de flotte ; stock plein = 1 action de plus (max 4) ; plus aucune planète = plus de revenu.
- **Unités** : entraînement par rang (+2 %/rang hp/atk, max rang 3, lié au développement) sur les rôles de prédilection de l'empire ; les définitions d'origine ne sont jamais modifiées.
- **Capacités** (données pour le combat, plafonnées) : VEXOR réparation/blindage/production de masse ; KAEL-9 liaison/grille/frappe synchronisée ; ELYRA régénération/barrière/jugement ;
  MORVAK brûlure/fureur/terre brûlée ; NYR'AH brume/drain/singularité.
- **Comportements distincts** (plafonds propres) : ELYRA boucliers 5/tourelles 2 ; MORVAK boucliers 2/tourelles 4/renforts ; NYR'AH tourelles ; KAEL-9 répartit ses niveaux (coordination) ; VEXOR renforts bon marché.
- **Expansion** : un empire offensif/équilibré relié à un monde neutre par ≤ 2 routes peut le *revendiquer* (garnison ajoutée, max 2, 1/24 h). Seul VEXOR est relié aux mondes neutres.
  Revendication retirée si le joueur conquiert le monde ou si l'empire perd ses planètes proches.

## Carte galactique et invasions (API du futur module d'invasion)
`EmpireEvolutionManager` :
- `mapView(now)` : chaque planète (propriétaire, conquise, atteignable, frontière, invasion possible, puissance/niveau évolués, alerte 0..3, posture) + bilan des 5 empires.
- `invasionPlan(pid, now)` : faisabilité (scan…), `spec` complet, ratio équipe/niveau, verdict (`deconseille|risque|equilibre|favorable`), capacités, récompenses.
- `battleSpec(pid, now)` : remplace `Galaxy.battleSpec` (mêmes champs + `bonus`, `capabilities`, `posture`, `strategy`, `alert`, `claimedBy`, `evo`).
- `resolveInvasion(pid, victory, now)` : **point d'entrée unique** du résultat (idempotent) : victoire → conquête + mémoire de la perte ; défaite → l'empire « a tenu ».

## Bornes (pas de progression infinie)
Développement ≤ 8 (lié au niveau d'équipe et à la difficulté), rangs ≤ 3, boucliers ≤ 5, tourelles ≤ 4, renforts ≤ 2, revendications ≤ 2, stocks plafonnés, bonus de capacités plafonnés,
hors ligne ≤ 24 h rattrapées. Test : après 200 jours, plus aucune amélioration ; état ≈ 6 Ko stable ; aucun `Math.random` dans la simulation.

## Tests
`node tests/empireAdaptation.test.js` (172) · `empireEvolution` 146 · `empireAI` 220 · `galaxy` 916 · `economy` 1763 · `heroes` 312 · `enemies` 265 · `combat` ≈857 · `background` (nombre variable, tirages aléatoires du test)
`NODE_PATH=$(npm root -g) node tests/browser-smoke.js` (37) · `browser-combat.js` (52) · `browser-empires.js` (16) — Chromium réel, Phaser simulé.

## Limites connues
- Pas encore de scène « Galaxie » ni de module d'invasion dans le jeu : tout est prêt côté données/API, rien n'est affiché.
- `CombatEngine` ne lit pas encore `spec.bonus` / `capabilities` / `trait` : ce sont des données prêtes à consommer.
- Équilibrage à valider en jeu réel : puissance finale ×1,29 (NYR'AH) à ×1,56 (VEXOR) ; la hiérarchie absolue VEXOR < KAEL-9 < ELYRA < MORVAK < NYR'AH est conservée.
- Avancer l'horloge du téléphone donne au plus 24 h de progression par saut, dans les mêmes plafonds.
