# NEBUSTION — Étape 4/10 : Combats spatiaux et boss (module complet)

Ce module remplace la livraison intermédiaire « partie 1 ». Il contient TOUT le combat :
données, moteur, sauvegarde, écran de préparation, arène, récompenses, intégration.

## Intégration (ZIP « module »)

Décompressez `nebustion_etape4_module_combat.zip` **par-dessus** votre projet de l'étape 3
(acceptez le remplacement). Il ne contient que les fichiers ajoutés / modifiés :

| Ajoutés | Modifiés (petites intégrations) |
|---|---|
| `js/data/Enemies.js` | `index.html` (ordre des scripts) |
| `js/systems/CombatEngine.js` | `js/main.js` (2 scènes déclarées) |
| `js/systems/CombatManager.js` | `js/scenes/PreloadScene.js` (génère les textures ennemies) |
| `js/utils/EnemyTextures.js` | `js/scenes/MainMenuScene.js` (raccourci Combat) |
| `js/scenes/CombatPrepScene.js` | `js/ui/BottomNav.js` (onglet Combat) |
| `js/scenes/CombatScene.js` | `js/systems/SaveManager.js` (champ `combat`, rétrocompatible) |
| `tests/…` (voir plus bas) | `sw.js` (cache hors ligne v4) · `tests/mock-phaser.js` |

`nebustion_etape4_complet.zip` = le projet entier déjà fusionné, prêt à jouer.
Les sauvegardes de l'étape 3 sont conservées (le champ `combat` est créé au premier lancement).

## Ce que fait le jeu

- **Menu → Combat** (ou onglet Combat) ouvre la **préparation** : équipe de 5 héros parmi les 16
  (niveau et puissance réels affichés, bouton « Équipe auto »), 13 stages (10 stages + 3 boss,
  déverrouillés dans l'ordre), 4 difficultés (Facile / Normal / Difficile / Cauchemar), aperçu des
  ennemis, des récompenses et **niveau d'équipe conseillé**.
- **Arène** : fond 2.5D animé (étoiles, planète, astéroïdes, sol en perspective), héros (vos vrais
  portraits) contre 1 à 3 ennemis ou 1 boss. Barres de vie avec traînée, bouclier, énergie d'ultime,
  projectiles, coups de mêlée, impacts, éclairs, tremblements légers.
- **Contrôles** : `MODE AUTO / MANUEL`, vitesse ×1 / ×2 / ×3, pause. Chaque héros a un bouton de
  compétence (temps de recharge visible) et un bouton d'ultime (jauge d'énergie). En AUTO tout part
  seul mais vous pouvez déclencher à la main ; en MANUEL seules vos commandes lancent compétences et ultimes.
- **10 ennemis** (Drone Sentinelle, Chasseur Voltaïque, Blindé Corvex, Nuée Sporale, Sniper Umbra,
  Bombardier Cinder, Spectre Glacial, Golem d'Acier, Vampire Stellaire, Architecte Nexus) et
  **3 boss** à phases : VORATH (2 phases), NEXUS PRIME (3), OMEGA-KRELL (3). À chaque changement de
  phase : bonus d'attaque/vitesse/recharge + onde de choc. Un boss lance aussi un « Déchaînement »
  quand son énergie est pleine. Après 100 s, les ennemis entrent en **rage** (dégâts croissants).
- **Victoire / défaite** : 0 à 3 étoiles (selon les héros tombés), ressources, XP, **fragments**
  (chaque héros de l'équipe en reçoit), montées de niveau affichées. Une défaite donne une petite
  récompense de consolation (25 %). **Abandonner** ne donne rien. Récompenses créditées **une seule
  fois** ; le stockage plein est signalé.

## Héros : vraies stats, vraies compétences

Les PV / ATQ / DÉF / VIT viennent de `Heroes.js` (`statsAtLevel`). Le niveau d'un héros = 1 + fragments ÷ 8
(en attendant l'écran d'amélioration d'une prochaine étape). **Chacun des 16 héros a un kit dédié** dans
`CombatEngine.js` (`HERO_KIT`) qui reproduit ses 3 compétences décrites dans `Heroes.js` :
Zyra 3 coups + ultime critique garanti · Korvax bouclier + provocation, ultime étourdissant + soin ·
Lumina soin + bouclier, ultime de zone qui purge · Drakor saignement · Selene tir perforant, pluie de 3 salves ·
Vortex ×2 vitesse/dégâts · Nyx étourdissement, ultime « réduit la précision » (les ennemis ratent) ·
Vega équipe accélérée, action supplémentaire · Aeon réanimation unique · Targon insensible à
l'étourdissement, coup de masse · Soraya brûlures · etc. Un héros ajouté plus tard sans kit reste jouable
(comportement générique déduit de son rôle).

## Changements par rapport à la partie 1 (à connaître)

- **Rythme** : la version intermédiaire faisait agir chaque unité toutes les ~9 s (trop mou). Réglage
  actuel ≈ 4 s ; les dégâts sont recalibrés (`CFG` en tête de `CombatEngine.js`) pour des combats de
  10–20 s (stages) et 1–3 min (boss). Les stats affichées ne sont pas modifiées.
- Passifs qui étaient annoncés mais sans effet (reflet, régénération, ralentissement, réduction d'équipe,
  bouclier d'équipe) : **maintenant réellement appliqués**.
- **Progression** : chaque stage a une `scale` (puissance) et un `recLevel` (niveau conseillé par difficulté,
  calibré par simulation : ≥ 85 % de victoires). Ex. au niveau 1 les premiers stages passent, VORATH demande
  ≈ niv. 5, NEXUS PRIME ≈ 11, OMEGA-KRELL ≈ 18 (Normal).
- **Fragments** : tous les héros de l'équipe les reçoivent (avant : un seul, au hasard) ; 8 fragments = 1 niveau
  (avant 20). C'est une hypothèse de confort à valider : réglable par `FRAGMENTS_PER_LEVEL` dans `CombatManager.js`.
- Un test de fumée de l'étape 3 était cassé (le faux Phaser ignorait `scene.load`) : corrigé dans `tests/mock-phaser.js`.

## Tests (tous verts)

```
node tests/heroes.test.js      312      node tests/enemies.test.js    265
node tests/economy.test.js    1763      node tests/combat.test.js     856
node tests/background.test.js  (aléatoire, ~50)
NODE_PATH=$(npm root -g) node tests/browser-smoke.js     37   (étapes 2-3, non-régression)
NODE_PATH=$(npm root -g) node tests/browser-combat.js    52   (préparation → combat → boss → défaite → sauvegarde)
```
`tests/combat.test.js` couvre notamment : les 16 kits (actif + ultime), chaque effet cité ci-dessus, ordres du
joueur, rage, récompenses, fragments. `browser-combat.js` joue de vrais combats dans Chromium : victoire stage 1,
enchaînement stage 2, mode MANUEL (compétence + ultime au toucher), pause, abandon, boss avec passage de phase,
défaite, rechargement de la sauvegarde, absence de fuite d'objets.

## ⚠ Ce qui n'a PAS pu être testé ici (à vérifier sur votre téléphone)

Je n'ai pas pu télécharger le vrai Phaser 3 dans mon environnement : les scènes ont été exécutées avec le
**faux Phaser** du projet (il refuse les appels d'API inconnus et les textures absentes) et j'ai généré des
captures de mise en page (`tests/screenshots.js`). Restent à confirmer avec le vrai moteur : fluidité réelle
sur votre Android, rendu des particules/mélange additif, recadrage des portraits sur les boutons de compétence
(`setCrop`), défilement de la liste de héros (masque), apparence exacte des textes. Si un détail visuel cloche,
dites-moi lequel (capture d'écran) : les réglages sont localisés (`CombatScene.js`).
Si l'écran ralentit : passer la vitesse à ×1, ou dites-le-moi et je réduis les particules (`_buildParticles`).

## Réglages utiles

`CombatEngine.js` → `CFG` (GAUGE_RATE = tempo, DAMAGE_SCALE, ENEMY_DAMAGE, HEAL_SCALE, ENRAGE_START…) ·
`Enemies.js` → `STAGES[].scale / rewardMult / recLevel`, `BASE_REWARD`, `DIFFICULTIES` ·
`CombatManager.js` → `FRAGMENTS_PER_LEVEL`.
