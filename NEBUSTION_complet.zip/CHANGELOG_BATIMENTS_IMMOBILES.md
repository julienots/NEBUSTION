# NEBUSTION — Bâtiments de Nexus-01 : immobiles à l'écran

## Problème
Même droits, les bâtiments suivaient encore la rotation de la planète (ils changeaient de place,
de taille, passaient derrière le globe), et les gisements s'inclinaient selon le sol.

## Correctif
Bâtiments, gisements, constructions libres et drones sont placés d'après une rotation de
RÉFÉRENCE fixe (`_fixYaw` / `_fixPitch`, = la vue de départ), jamais d'après la rotation courante.
- `js/scenes/PlanetScene.js` : nouvelle `_projectFixed()` (toujours droit, sans écrasement, jamais
  caché ni fondu, toujours touchable) ; `_projectVec` accepte une rotation optionnelle ;
  `_unprojectSphere(px, py, true)` pour le placement ; `_applySphereTransform`, `_buildBuildings`
  et `_buildNodes` l'utilisent.
- `js/entities/MiningDrone.js` : les drones volent dans le même repère immobile.
- `js/scenes/PlanetBuildUI.js` : le placement d'une construction utilise le repère immobile
  (l'endroit touché = l'endroit où elle apparaît).

## Ce qui tourne toujours
Seule la planète (surface, nuages, grille) tourne en décor, au doigt et en rotation lente au repos.

## Réglages
Pour changer la place de tout le monde d'un coup : `_fixYaw` / `_fixPitch` dans `create()`.
Places individuelles : `PlanetLayout` (lonDeg / latDeg).

## Non testé
Calculs vérifiés sous Node (positions identiques pour 4 rotations différentes, aller-retour
placement exact, aucun NaN) ; rendu Phaser/téléphone à valider en jeu.
Cache du service worker : `nebustion-v49-batiments-immobiles`.
