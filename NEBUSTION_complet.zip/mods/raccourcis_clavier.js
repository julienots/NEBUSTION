/**
 * NEBUSTION - Mod : Raccourcis clavier
 * ---------------------------------------------------------------------------
 * Confort pour qui teste/joue au clavier (navigateur desktop) : les touches
 * 1 à 6 basculent directement vers un écran principal, sans repasser par les
 * menus. Un petit badge ⌨️ (bas-centre) rappelle les touches et peut être
 * replié.
 *
 * Sécurités :
 *   - ignoré si le focus est dans un champ de texte (saisie de pseudo, etc.) ;
 *   - ignoré pendant un combat ou une bataille de QG, pour ne jamais couper
 *     une séquence en cours (voir LISTE_INTERDITE ci-dessous).
 */
(function () {
  'use strict';

  var RACCOURCIS = [
    { touche: '1', scene: 'PlanetScene', label: 'Planète' },
    { touche: '2', scene: 'GalaxyScene', label: 'Galaxie' },
    { touche: '3', scene: 'HeroesScene', label: 'Héros' },
    { touche: '4', scene: 'ShopScene', label: 'Boutique' },
    { touche: '5', scene: 'QGScene', label: 'QG' },
    { touche: '6', scene: 'CodexScene', label: 'Codex' }
  ];

  // Scènes pendant lesquelles on n'intercepte jamais les touches (séquences en cours).
  var SCENES_PROTEGEES = ['CombatScene', 'CombatPrepScene', 'SymbioteBattleScene', 'QGBattleScene'];

  function champDeSaisieActif() {
    var el = document.activeElement;
    if (!el) return false;
    var tag = el.tagName;
    return tag === 'INPUT' || tag === 'TEXTAREA' || el.isContentEditable === true;
  }

  NEBUSTION.Mods.register({
    id: 'raccourcis_clavier',
    name: 'Raccourcis clavier',
    version: '1.0.0',

    onGameReady: function (game) {
      if (!game || !game.scene) return;

      // ---------- Badge légende (repliable) ----------
      var ouvert = false;
      var bascule = document.createElement('div');
      bascule.textContent = '⌨️';
      bascule.style.cssText =
        'position:fixed; bottom:calc(env(safe-area-inset-bottom,0px) + 10px); left:50%; transform:translateX(-50%);' +
        'z-index:99998; background:rgba(8,12,26,0.85); color:#8ff0ff; border:1px solid rgba(143,240,255,0.4);' +
        'border-radius:8px; width:30px; height:30px; display:flex; align-items:center; justify-content:center;' +
        'font-size:15px; cursor:pointer; user-select:none;';

      var legende = document.createElement('div');
      legende.textContent = RACCOURCIS.map(function (r) { return r.touche + ' ' + r.label; }).join('  ·  ');
      legende.style.cssText =
        'position:fixed; bottom:calc(env(safe-area-inset-bottom,0px) + 48px); left:50%; transform:translateX(-50%);' +
        'z-index:99998; display:none; max-width:90vw; text-align:center; white-space:normal;' +
        'background:rgba(8,12,26,0.92); color:#e6ecff; border:1px solid rgba(143,240,255,0.35);' +
        'border-radius:10px; padding:8px 12px; font:11px/1.5 monospace;';

      bascule.addEventListener('click', function () {
        ouvert = !ouvert;
        legende.style.display = ouvert ? 'block' : 'none';
      });

      document.body.appendChild(legende);
      document.body.appendChild(bascule);

      // ---------- Écoute clavier ----------
      var index = {};
      RACCOURCIS.forEach(function (r) { index[r.touche] = r.scene; });

      document.addEventListener('keydown', function (e) {
        if (champDeSaisieActif()) return;
        var cible = index[e.key];
        if (!cible) return;

        for (var i = 0; i < SCENES_PROTEGEES.length; i++) {
          try { if (game.scene.isActive(SCENES_PROTEGEES[i])) return; } catch (err) { /* scène absente : ignorer */ }
        }

        try { game.scene.start(cible); } catch (err) { console.error('[raccourcis_clavier] échec du changement de scène', err); }
      });
    }
  });
})();
