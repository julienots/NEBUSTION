/**
 * NEBUSTION - Mod : Journal d'activité
 * ---------------------------------------------------------------------------
 * Petit badge repliable (haut-droite, 📜) qui tient un journal des événements
 * notables de la partie, en s'abonnant aux événements déjà émis par
 * NEBUSTION.Resources (voir js/systems/ResourceManager.js) :
 *   - 'upgrade'  -> amélioration d'un bâtiment du QG
 *   - 'gain'     -> récolte manuelle critique uniquement (data.crit === true)
 *   - 'prestige' -> déclenchement d'une Renaissance galactique
 *
 * Purement passif : ne modifie aucune donnée du jeu, ne fait que lire les
 * événements et les afficher. Les 30 dernières entrées sont conservées d'une
 * session à l'autre dans une clé localStorage séparée, indépendante de la
 * sauvegarde de partie (comme mods/temps_de_jeu.js).
 */
(function () {
  'use strict';

  var STORAGE_KEY = 'nebustion_mod_journal_activite_v1';
  var MAX_ENTRIES = 30;

  function chargerJournal() {
    try {
      var arr = JSON.parse(window.localStorage.getItem(STORAGE_KEY) || '[]');
      return Array.isArray(arr) ? arr : [];
    } catch (e) { return []; }
  }
  function sauvegarderJournal(arr) {
    try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(arr)); } catch (e) { /* best-effort */ }
  }

  function heure(ts) {
    var d = new Date(ts);
    var h = String(d.getHours()).padStart(2, '0');
    var m = String(d.getMinutes()).padStart(2, '0');
    return h + ':' + m;
  }

  NEBUSTION.Mods.register({
    id: 'journal_activite',
    name: "Journal d'activité",
    version: '1.0.0',

    onGameReady: function (game, NEB) {
      var journal = chargerJournal();
      var ouvert = false;

      function ajouter(icone, texte) {
        journal.unshift({ t: Date.now(), icone: icone, texte: texte });
        if (journal.length > MAX_ENTRIES) journal.length = MAX_ENTRIES;
        sauvegarderJournal(journal);
        rafraichir();
      }

      // ---------- Interface ----------
      var bascule = document.createElement('div');
      bascule.textContent = '📜';
      bascule.style.cssText =
        'position:fixed; top:calc(env(safe-area-inset-top,0px) + 10px); right:10px; z-index:99998;' +
        'background:rgba(8,12,26,0.85); color:#c9d4ea; border:1px solid rgba(201,212,234,0.4);' +
        'border-radius:8px; width:30px; height:30px; display:flex; align-items:center; justify-content:center;' +
        'font-size:16px; cursor:pointer; user-select:none;';

      var panneau = document.createElement('div');
      panneau.style.cssText =
        'position:fixed; top:calc(env(safe-area-inset-top,0px) + 48px); right:10px; z-index:99998;' +
        'display:none; flex-direction:column; width:250px; max-height:50vh; overflow-y:auto;' +
        'background:rgba(8,12,26,0.92); border:1px solid rgba(201,212,234,0.35); border-radius:10px; padding:8px;' +
        'font:11px/1.5 monospace; color:#e6ecff;';

      var titre = document.createElement('div');
      titre.textContent = "📜 Journal d'activité";
      titre.style.cssText = 'color:#c9d4ea; font-weight:bold; margin-bottom:6px;';
      panneau.appendChild(titre);

      var liste = document.createElement('div');
      panneau.appendChild(liste);

      var vider = document.createElement('button');
      vider.textContent = 'Vider le journal';
      vider.style.cssText =
        'margin-top:6px; background:#151b30; color:#e6ecff; border:1px solid rgba(255,255,255,0.15);' +
        'border-radius:6px; padding:5px 8px; font:10px monospace; cursor:pointer;';
      vider.addEventListener('click', function () {
        journal = [];
        sauvegarderJournal(journal);
        rafraichir();
      });
      panneau.appendChild(vider);

      function rafraichir() {
        liste.innerHTML = '';
        if (!journal.length) {
          var vide = document.createElement('div');
          vide.textContent = 'Aucun événement pour le moment.';
          vide.style.cssText = 'color:#7d879e;';
          liste.appendChild(vide);
          return;
        }
        journal.forEach(function (e) {
          var ligne = document.createElement('div');
          ligne.style.cssText = 'padding:3px 0; border-top:1px solid rgba(255,255,255,0.06);';
          ligne.textContent = heure(e.t) + '  ' + e.icone + ' ' + e.texte;
          liste.appendChild(ligne);
        });
      }

      bascule.addEventListener('click', function () {
        ouvert = !ouvert;
        panneau.style.display = ouvert ? 'flex' : 'none';
      });

      document.body.appendChild(panneau);
      document.body.appendChild(bascule);
      rafraichir();

      // ---------- Abonnements aux événements du jeu ----------
      if (!NEB.Resources || typeof NEB.Resources.on !== 'function') return;

      NEB.Resources.on('upgrade', function (data) {
        if (!data || !data.id) return;
        var def = NEB.Economy && NEB.Economy.BUILDINGS ? NEB.Economy.BUILDINGS[data.id] : null;
        var nom = def ? def.name : data.id;
        ajouter('🏗️', nom + ' → Niveau ' + data.level);
      });

      NEB.Resources.on('gain', function (data) {
        if (!data || !data.crit || !data.id) return;
        var res = NEB.Economy && NEB.Economy.RES ? NEB.Economy.RES[data.id] : null;
        var nom = res ? res.short : data.id;
        var qte = Math.round(data.amount || 0);
        ajouter('✨', 'Récolte critique : +' + qte + ' ' + nom);
      });

      NEB.Resources.on('prestige', function (data) {
        var gain = (data && data.relics) || 0;
        ajouter('🌌', 'Renaissance galactique — +' + gain + ' Reliques');
      });
    }
  });
})();
