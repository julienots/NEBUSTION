/**
 * NEBUSTION - Mod : Offres boutique +
 * ---------------------------------------------------------------------------
 * Ajoute cinq nouvelles offres au pool de la boutique quotidienne (voir
 * js/data/Shop.js : NEBUSTION.Shop.DAILY_POOL / DAILY_INDEX, 4 offres tirées
 * chaque jour parmi le pool). Purement additif : ne modifie ni ne retire
 * aucune offre existante, et vérifie qu'un rechargement ne duplique rien.
 * Inspiré de mods/exemple_mod.js — voir ce fichier pour le modèle commenté.
 */
(function () {
  'use strict';

  var OFFRES = [
    { id: 'mod_off_metal', kind: 'resource', label: 'Alliage renforcé (mod)', res: { metal: 900 }, cost: { dust: 1400 } },
    { id: 'mod_off_core', kind: 'resource', label: 'Noyaux excédentaires (mod)', res: { core: 4 }, cost: { crystal: 700, metal: 400 } },
    { id: 'mod_off_bundle', kind: 'bundle', label: 'Ravitaillement du mod', res: { dust: 1800, crystal: 700, energy: 400 }, cost: { gem: 45 } },
    { id: 'mod_off_equip_e', kind: 'equipment', label: 'Objet aléatoire (Épique, mod)', rarity: 'epique', cost: { gem: 90 } },
    { id: 'mod_off_gems', kind: 'gems', label: 'Prismes du mod', amount: 15, cost: { dust: 3200, energy: 900 } }
  ];

  NEBUSTION.Mods.register({
    id: 'offres_boutique_plus',
    name: 'Offres boutique +',
    version: '1.0.0',

    // Appelé avant le démarrage de Phaser : NEB.Shop existe déjà (module de données pur).
    init: function (NEB) {
      if (!NEB.Shop || !Array.isArray(NEB.Shop.DAILY_POOL) || !NEB.Shop.DAILY_INDEX) {
        console.warn('[offres_boutique_plus] NEBUSTION.Shop indisponible, aucune offre ajoutée.');
        return;
      }
      var ajoutees = 0;
      OFFRES.forEach(function (offre) {
        if (NEB.Shop.DAILY_INDEX[offre.id]) return; // déjà présente (rechargement à chaud) : pas de doublon
        NEB.Shop.DAILY_POOL.push(offre);
        NEB.Shop.DAILY_INDEX[offre.id] = offre;
        ajoutees++;
      });
      console.log('[offres_boutique_plus] ' + ajoutees + ' offre(s) ajoutée(s) au pool de la boutique quotidienne (4 tirées/jour parmi tout le pool, donc pas forcément visibles immédiatement).');
    }
  });
})();
