/**
 * NEBUSTION - Mod : HUD Ressources & taux
 * ---------------------------------------------------------------------------
 * Barre en haut de l'écran affichant le stock actuel et la production par
 * minute des 5 ressources (cristaux, métal, énergie, noyaux, poussière),
 * mise à jour une fois par seconde. Toucher la barre la réduit (ne garde que
 * les cristaux) ou l'agrandit à nouveau. Lecture seule : ne modifie aucune
 * donnée du jeu, s'appuie sur NEBUSTION.Resources (get/ratePerMin), déjà
 * utilisé par mods/outils_debug.js et le reste du jeu.
 */
(function () {
  'use strict';

  var ID = 'mod-hud-ressources';
  var ORDRE = ['crystal', 'metal', 'energy', 'core', 'dust'];
  var LABELS = { crystal: 'Cristaux', metal: 'Métal', energy: 'Énergie', core: 'Noyaux', dust: 'Poussière' };
  var COULEURS = { crystal: '#8fd8ff', metal: '#c9d4ea', energy: '#ffe07a', core: '#ff9a8f', dust: '#c9a8ff' };

  function formater(n) {
    n = Number(n) || 0;
    if (n >= 1e9) return (n / 1e9).toFixed(2) + 'G';
    if (n >= 1e6) return (n / 1e6).toFixed(2) + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
    return Math.floor(n).toString();
  }

  var conteneur = null;
  var lignes = {};
  var reduit = false;

  function creerBarre() {
    conteneur = document.createElement('div');
    conteneur.id = ID;
    conteneur.title = 'Toucher pour réduire/agrandir';
    conteneur.style.cssText =
      'position:fixed; top:calc(env(safe-area-inset-top,0px) + 10px); left:50%; transform:translateX(-50%);' +
      'z-index:99997; display:flex; gap:10px; flex-wrap:wrap; justify-content:center; max-width:92vw;' +
      'background:rgba(8,12,26,0.78); border:1px solid rgba(143,216,255,0.3); border-radius:10px;' +
      'padding:6px 12px; font:11px/1.4 monospace; cursor:pointer; user-select:none; pointer-events:auto;';

    ORDRE.forEach(function (id) {
      var span = document.createElement('span');
      span.style.cssText = 'color:' + (COULEURS[id] || '#e6ecff') + '; white-space:nowrap;';
      conteneur.appendChild(span);
      lignes[id] = span;
    });

    conteneur.addEventListener('click', function () {
      reduit = !reduit;
      ORDRE.forEach(function (id, i) { if (i > 0) lignes[id].style.display = reduit ? 'none' : 'inline'; });
    });

    document.body.appendChild(conteneur);
  }

  function rafraichir(NEB) {
    if (!conteneur || !NEB.Resources) return;
    ORDRE.forEach(function (id) {
      var stock = NEB.Resources.get(id) || 0;
      var taux = (typeof NEB.Resources.ratePerMin === 'function') ? NEB.Resources.ratePerMin(id) : 0;
      lignes[id].textContent = LABELS[id] + ' ' + formater(stock) + (taux > 0.05 ? ' (+' + formater(taux) + '/min)' : '');
    });
  }

  var dernierRendu = 0;

  NEBUSTION.Mods.register({
    id: 'hud_ressources_taux',
    name: 'HUD Ressources & taux',
    version: '1.0.0',

    onGameReady: function (game, NEB) {
      creerBarre();
      rafraichir(NEB);
    },

    // Même convention que mods/temps_de_jeu.js : onTick est appelé en continu, on se
    // limite nous-mêmes à une mise à jour par seconde.
    onTick: function (t, NEB) {
      if (!conteneur || t - dernierRendu < 1000) return;
      dernierRendu = t;
      rafraichir(NEB);
    }
  });
})();
