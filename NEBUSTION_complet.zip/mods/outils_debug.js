/**
 * NEBUSTION - Mod : Outils de debug
 * Petit panneau de boutons pratiques pour tester le jeu, affiché UNIQUEMENT quand l'URL contient
 * ?debug=1 (même convention que le reste du jeu — voir js/main.js : NEBUSTION.DEBUG). Un joueur
 * normal ne voit jamais ce panneau.
 */
(function () {
  'use strict';

  function bouton(conteneur, libelle, action) {
    var b = document.createElement('button');
    b.textContent = libelle;
    b.style.cssText =
      'background:#151b30; color:#e6ecff; border:1px solid rgba(255,255,255,0.15);' +
      'border-radius:6px; padding:5px 8px; font:11px monospace; cursor:pointer; text-align:left;';
    b.addEventListener('click', action);
    conteneur.appendChild(b);
    return b;
  }

  function creerPanneau(NEB) {
    var el = document.createElement('div');
    el.style.cssText =
      'position:fixed; bottom:calc(env(safe-area-inset-bottom,0px) + 10px); right:10px; z-index:99998;' +
      'display:flex; flex-direction:column; gap:4px; background:rgba(8,12,26,0.88);' +
      'border:1px solid rgba(255,196,120,0.4); border-radius:10px; padding:8px; width:190px;';

    var titre = document.createElement('div');
    titre.textContent = '🛠 Outils debug (mod)';
    titre.style.cssText = 'color:#ffc478; font:11px monospace; margin-bottom:2px;';
    el.appendChild(titre);

    bouton(el, '+1000 de chaque ressource', function () {
      if (!NEB.Resources || typeof NEB.Resources.add !== 'function') return;
      ['crystal', 'metal', 'energy', 'core', 'dust'].forEach(function (id) {
        try { NEB.Resources.add(id, 1000, 'mod:outils_debug'); } catch (err) { console.error('[outils_debug]', err); }
      });
      console.log('[outils_debug] +1000 crystal/metal/energy/core/dust');
    });

    bouton(el, 'Sauvegarder maintenant', function () {
      if (!NEB.Resources || typeof NEB.Resources.saveNow !== 'function') return;
      var ok = NEB.Resources.saveNow(Date.now());
      console.log('[outils_debug] Sauvegarde manuelle : ' + (ok ? 'réussie' : 'échouée'));
    });

    bouton(el, "Logger l'état des ressources", function () {
      console.log('[outils_debug] NEBUSTION.Resources.state =', NEB.Resources && NEB.Resources.state);
    });

    bouton(el, 'Lister les mods actifs', function () {
      console.log('[outils_debug] Mods actifs :', NEB.Mods.list());
      var err = NEB.Mods.errors();
      if (err.length) console.log('[outils_debug] Erreurs de mods :', err);
    });

    document.body.appendChild(el);
    return el;
  }

  NEBUSTION.Mods.register({
    id: 'outils_debug',
    name: 'Outils de debug',
    version: '1.0.0',

    // NEB.DEBUG n'est mis à jour par js/main.js que juste avant la création de Phaser.Game,
    // donc APRÈS init() de ce mod : c'est pour ça que la vérification se fait ici, dans onGameReady.
    onGameReady: function (game, NEB) {
      if (!NEB.DEBUG) return;
      creerPanneau(NEB);
      console.log('[outils_debug] Panneau affiché (mode ?debug=1 actif).');
    }
  });
})();
