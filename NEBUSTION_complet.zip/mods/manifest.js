/**
 * NEBUSTION - Manifeste des mods
 * ---------------------------------------------------------------------------
 * Historiquement, ce fichier listait « à la main » les mods à charger. Il fait
 * maintenant la même chose, mais la liste peut être pilotée depuis le jeu :
 * Paramètres ⚙ → « 🧩 Mods et plugins » (voir js/scenes/ModsScene.js), qui
 * active/désactive chaque mod avec un interrupteur et une animation
 * d'installation, puis enregistre le choix ici, dans localStorage.
 *
 * NEBUSTION.ModsCatalog.AVAILABLE décrit chaque mod fourni (id, fichier, nom,
 * description) ; NEBUSTION.ModsCatalog.buildManifest() calcule la liste finale
 * des fichiers à charger (ceux activés) et la pose dans
 * window.NEBUSTION_MODS_MANIFEST — c'est cette variable que index.html lit
 * pour charger les mods, un par un, dans l'ordre.
 *
 * Pour ajouter un mod « à la main » sans passer par l'écran des Paramètres :
 * ajoutez une entrée dans AVAILABLE ci-dessous (defaultOn: true/false).
 * Un mod absent ou en erreur est ignoré sans bloquer le jeu (voir la console).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.ModsCatalog = {
  STORAGE_KEY: 'nebustion_mods_prefs',

  AVAILABLE: [
    {
      id: 'exemple_mod',
      file: 'mods/exemple_mod.js',
      name: 'Mod exemple',
      desc: 'Modèle de base : ajoute une offre à la boutique quotidienne et affiche un badge listant les mods actifs pendant 5 s.',
      defaultOn: true
    },
    {
      id: 'hud_fps',
      file: 'mods/hud_fps.js',
      name: 'Compteur FPS',
      desc: 'Petit compteur d\u2019images par seconde en haut à gauche. Touchez le badge pour le masquer/afficher.',
      defaultOn: true
    },
    {
      id: 'temps_de_jeu',
      file: 'mods/temps_de_jeu.js',
      name: 'Temps de jeu',
      desc: 'Badge en bas à gauche : temps de jeu total (cumulé entre les sessions) + temps de la session en cours.',
      defaultOn: true
    },
    {
      id: 'outils_debug',
      file: 'mods/outils_debug.js',
      name: 'Outils de debug',
      desc: 'Panneau de boutons de test (ressources, sauvegarde\u2026). Visible uniquement avec ?debug=1 dans l\u2019adresse.',
      defaultOn: true
    },
    {
      id: 'offres_boutique_plus',
      file: 'mods/offres_boutique_plus.js',
      name: 'Offres boutique +',
      desc: 'Ajoute 5 nouvelles offres au pool de la boutique quotidienne (ressources, lot, objet épique, prismes).',
      defaultOn: true
    },
    {
      id: 'hud_ressources_taux',
      file: 'mods/hud_ressources_taux.js',
      name: 'HUD Ressources & taux',
      desc: 'Barre en haut de l\u2019écran : stock et production/minute des 5 ressources. Toucher pour réduire/agrandir.',
      defaultOn: true
    },
    {
      id: 'alerte_stockage_plein',
      file: 'mods/alerte_stockage_plein.js',
      name: 'Alerte stockage plein',
      desc: 'Bandeau d\u2019avertissement quand une ressource atteint son plafond de stockage.',
      defaultOn: true
    },
    {
      id: 'bouton_sauvegarde_rapide',
      file: 'mods/bouton_sauvegarde_rapide.js',
      name: 'Sauvegarde rapide',
      desc: 'Bouton flottant \uD83D\uDCBE pour déclencher une sauvegarde manuelle immédiate, à tout moment.',
      defaultOn: true
    },
    {
      id: 'arsenal_cosmique',
      file: 'mods/arsenal_cosmique.js',
      name: 'Arsenal Cosmique (pack)',
      desc: 'GROS MOD : 2 nouveaux héros (Nébulon, Voidram), 3 nouveaux objets d\u2019équipement, et un panneau Booster d\u2019équilibrage réversible.',
      defaultOn: false
    },
    {
      id: 'journal_activite',
      file: 'mods/journal_activite.js',
      name: "Journal d'activité",
      desc: 'Badge \uD83D\uDCDC replié (haut-droite) : historique des améliorations de bâtiments, récoltes critiques et Renaissances.',
      defaultOn: true
    },
    {
      id: 'raccourcis_clavier',
      file: 'mods/raccourcis_clavier.js',
      name: 'Raccourcis clavier',
      desc: 'Touches 1 à 6 pour aller directement à Planète / Galaxie / Héros / Boutique / QG / Codex (désactivé pendant les combats).',
      defaultOn: true
    },
    {
      id: 'bestiaire_menace',
      file: 'mods/bestiaire_menace.js',
      name: 'Bestiaire de la Menace',
      desc: 'Ajoute 2 ennemis (Nécroptère, Bastion-Zéro) jouables dans l\u2019Arène personnalisée.',
      defaultOn: true
    }
  ],

  /** Préférences enregistrées : { 'mods/xxx.js': true|false, ... }. */
  getPrefs: function () {
    try { return JSON.parse(window.localStorage.getItem(this.STORAGE_KEY)) || {}; }
    catch (e) { return {}; }
  },

  /** Active/désactive un mod (par chemin de fichier) et enregistre le choix. */
  setPref: function (file, enabled) {
    var p = this.getPrefs();
    p[file] = !!enabled;
    try { window.localStorage.setItem(this.STORAGE_KEY, JSON.stringify(p)); } catch (e) {}
  },

  /** Un mod est actif si un choix a été enregistré, sinon selon son réglage par défaut. */
  isEnabled: function (item) {
    var p = this.getPrefs();
    return Object.prototype.hasOwnProperty.call(p, item.file) ? !!p[item.file] : !!item.defaultOn;
  },

  /** Construit la liste des chemins de fichiers à charger (mods actifs), dans l'ordre d'AVAILABLE. */
  buildManifest: function () {
    var self = this;
    return this.AVAILABLE.filter(function (it) { return self.isEnabled(it); })
      .map(function (it) { return it.file; });
  }
};

window.NEBUSTION_MODS_MANIFEST = NEBUSTION.ModsCatalog.buildManifest();
