/**
 * NEBUSTION - Mod d'exemple
 * ---------------------------------------------------------------------------
 * Sert de MODÈLE pour créer vos propres mods. Il fait volontairement trois
 * choses simples, chacune illustrant une façon différente de se brancher sur
 * le jeu :
 *
 *   1. init()        -> ajoute une offre à la boutique quotidienne (donnée pure,
 *                        pas besoin de Phaser). Additif : ne retire/écrase rien.
 *   2. onGameReady()  -> lit une valeur du jeu (stock de cristaux) et affiche un
 *                        petit badge à l'écran listant les mods actifs, quelques
 *                        secondes, pour prouver que le mod tourne bien.
 *   3. (onTick existe aussi si besoin d'une action répétée ; non utilisé ici.)
 *
 * Pour créer votre propre mod :
 *   - copiez ce fichier sous un nouveau nom dans mods/ (ex. mods/mon_mod.js) ;
 *   - changez au minimum "id" (unique) et "name" ;
 *   - ajoutez son chemin dans mods/manifest.js ;
 *   - rechargez le jeu et regardez la console du navigateur.
 *
 * Conseil : préfixez les identifiants que vous ajoutez à des données existantes
 * (ex. 'mod_xxx') pour ne jamais entrer en collision avec le jeu ou un autre mod.
 */
(function () {
  'use strict';

  function afficherBadge(texte) {
    try {
      var el = document.createElement('div');
      el.textContent = texte;
      el.style.cssText =
        'position:fixed; top:calc(env(safe-area-inset-top,0px) + 10px); right:10px;' +
        'max-width:72vw; z-index:99999; pointer-events:none;' +
        'background:rgba(8,12,26,0.88); color:#8ff0ff; border:1px solid rgba(143,240,255,0.45);' +
        'border-radius:10px; padding:8px 12px; font:12px/1.4 monospace;' +
        'box-shadow:0 4px 16px rgba(0,0,0,0.4); opacity:0; transition:opacity .4s ease;';
      document.body.appendChild(el);
      requestAnimationFrame(function () { el.style.opacity = '1'; });
      setTimeout(function () {
        el.style.opacity = '0';
        setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 500);
      }, 5000);
    } catch (err) { /* affichage best-effort : une page hors navigateur ne doit pas planter */ }
  }

  NEBUSTION.Mods.register({
    id: 'exemple_mod',
    name: "Mod d'exemple",
    version: '1.0.0',

    // Appelé dès le chargement du fichier, avant le démarrage de Phaser.
    // Les données du jeu (NEBUSTION.Shop, NEBUSTION.Heroes, NEBUSTION.Economy, ...) existent déjà.
    init: function (NEB) {
      if (NEB.Shop && Array.isArray(NEB.Shop.DAILY_POOL) && NEB.Shop.DAILY_INDEX && !NEB.Shop.DAILY_INDEX.mod_exemple_don) {
        var offre = {
          id: 'mod_exemple_don',
          kind: 'resource',
          label: 'Don du mod (exemple)',
          res: { dust: 500 },
          cost: { crystal: 50 }
        };
        NEB.Shop.DAILY_POOL.push(offre);
        NEB.Shop.DAILY_INDEX[offre.id] = offre;
        console.log('[exemple_mod] Offre ajoutée au pool de la boutique quotidienne : ' + offre.id);
      }
    },

    // Appelé une fois Phaser.Game créé.
    onGameReady: function (game, NEB) {
      var cristaux = (NEB.Resources && typeof NEB.Resources.get === 'function') ? NEB.Resources.get('crystal') : '?';
      console.log('[exemple_mod] Jeu prêt. Cristaux actuels du joueur : ' + cristaux);
      var noms = NEB.Mods.list().map(function (m) { return m.name + ' v' + m.version; }).join(', ');
      afficherBadge('🔌 Mods actifs : ' + noms);
    }

    // onTick: function (t, NEB) { /* appelé en continu si besoin d'une action répétée */ }
    // scenes: [ /* classes de scène Phaser à ajouter au jeu, si besoin */ ]
  });
})();
