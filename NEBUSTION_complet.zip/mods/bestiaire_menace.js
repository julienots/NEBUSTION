/**
 * NEBUSTION - Mod : Bestiaire de la Menace
 * ---------------------------------------------------------------------------
 * Ajoute deux ennemis via NEBUSTION.CustomContent.upsertEnemy — la même API
 * que l'Atelier créateur (tools/studio.html). Comme pour les héros créés sans
 * code, ils apparaissent automatiquement dans le stage toujours débloqué
 * « Arène personnalisée » (voir js/data/Enemies.js, customArenaStage()),
 * sans toucher au fichier d'ennemis du jeu.
 *
 * Purement additif : n'écrase ni ne retire aucun ennemi existant.
 *
 *   - Nécroptère   : rôle drain, draine la vie d'une cible isolée.
 *   - Bastion-Zéro : rôle tank, se protège (et protège son camp) avec un bouclier.
 */
(function () {
  'use strict';

  function ajouterEnnemis(NEB) {
    var CC = window.NEBUSTION && NEBUSTION.CustomContent;
    if (!CC || typeof CC.upsertEnemy !== 'function') {
      console.warn('[bestiaire_menace] NEBUSTION.CustomContent.upsertEnemy indisponible, contenu non ajouté.');
      return;
    }

    try {
      CC.upsertEnemy({
        id: 'menace_necroptere', name: 'Nécroptère', tier: 7, role: 'drain',
        base: { hp: 900, atk: 95, def: 35, spd: 100 },
        visual: { shape: 'vampire', color: '#7a1f4d', accent: '#ff5fa8' },
        skill: { name: 'Morsure exsangue', cooldown: 7, target: 'single', kind: 'drain', power: 1.3 }
      });
      CC.upsertEnemy({
        id: 'menace_bastion_zero', name: 'Bastion-Zéro', tier: 9, role: 'tank',
        base: { hp: 2400, atk: 55, def: 170, spd: 45 },
        visual: { shape: 'golem', color: '#2a3a55', accent: '#8fd8ff' },
        skill: { name: 'Champ statique', cooldown: 10, target: 'allEnemies_self', kind: 'selfShield', power: 1.6 }
      });
      console.log('[bestiaire_menace] Ennemis ajoutés à l\u2019Arène personnalisée : Nécroptère, Bastion-Zéro.');
    } catch (err) { console.error('[bestiaire_menace] Échec ajout ennemis', err); }
  }

  NEBUSTION.Mods.register({
    id: 'bestiaire_menace',
    name: 'Bestiaire de la Menace',
    version: '1.0.0',

    // Comme arsenal_cosmique : contenu ajouté avant le démarrage de Phaser,
    // NEB.CustomContent existe déjà à ce stade (voir LISEZMOI_MODS.md).
    init: function (NEB) { ajouterEnnemis(NEB); }
  });
})();
