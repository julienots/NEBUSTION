/**
 * NEBUSTION - Mod : ARSENAL COSMIQUE (gros mod, plusieurs fonctionnalités)
 * ---------------------------------------------------------------------------
 * Pack de contenu + confort, purement additif (n'écrase ni ne retire rien) :
 *
 *   1. Deux nouveaux héros jouables, ajoutés via NEBUSTION.CustomContent.upsert
 *      — la même API que l'Atelier créateur (tools/studio.html) : ils
 *      apparaissent automatiquement en Boutique, dans l'écran Héros et en
 *      Combat, sans toucher à js/data/Heroes.js (voir sa fonction fullList()).
 *
 *   2. Trois nouveaux modèles d'objets d'équipement, ajoutés via
 *      NEBUSTION.CustomContent.upsertItem (identité visuelle uniquement — les
 *      bonus/coûts restent calculés par les formules de js/data/Equipment.js,
 *      donc toujours équilibrés). Utilisables comme n'importe quel modèle de
 *      l'Atelier.
 *
 *   3. Un panneau « ⚡ Booster » (repliable, bas-droite) qui applique des
 *      multiplicateurs globaux via NEBUSTION.CustomContent.GameConfig — les
 *      mêmes réglages que l'onglet Réglages de l'Atelier créateur. Entièrement
 *      réversible avec son bouton « Réinitialiser », et n'affecte que la
 *      production/les coûts, jamais une sauvegarde ou un fichier du jeu.
 *
 * Désactivable à tout moment depuis Paramètres ⚙ → 🧩 Mods et plugins. Les
 * héros/objets déjà ajoutés restent dans NEBUSTION.CustomContent (stockés à
 * part en localStorage) même mod désactivé ; utilisez l'Atelier créateur pour
 * les retirer individuellement si besoin (tools/studio.html, ou en jeu si un
 * écran équivalent existe).
 */
(function () {
  'use strict';

  // ---------- 1 & 2. Contenu additif (héros + objets) ----------
  function ajouterContenu(NEB) {
    var CC = window.NEBUSTION && NEBUSTION.CustomContent;
    if (!CC) { console.warn('[arsenal_cosmique] NEBUSTION.CustomContent indisponible, contenu non ajouté.'); return; }

    if (typeof CC.upsert === 'function') {
      try {
        CC.upsert({
          id: 'arsenal_nebulon', name: 'Nébulon', title: 'Je vise là où la lumière n\u2019arrive plus.',
          role: 'sniper', rarity: 'legendaire', affinity: 'foudre',
          base: { hp: 780, atk: 178, def: 68, spd: 114 },
          visual: { body: 'armored_soldier', prop: 'rifle', accent: '#7dfcff', accent2: '#062830' },
          skills: {
            passive: { name: 'Visée orbitale', desc: 'Les tirs contre une cible isolée, loin de ses alliés, infligent 18 % de dégâts supplémentaires.' },
            active: { name: 'Tir traceur', cooldown: 6, desc: 'Marque la cible : les deux prochaines attaques portées contre elle ne peuvent pas rater.' },
            ultimate: { name: 'Salve stellaire', cost: 100, desc: 'Enchaîne cinq tirs répartis sur les ennemis présents, en priorité les cibles marquées.' }
          },
          shop: { cost: { gem: 340 } }
        });
        CC.upsert({
          id: 'arsenal_voidram', name: 'Voidram', title: 'Rien ne passe. Rien ne recule.',
          role: 'tank', rarity: 'epique', affinity: 'ombre',
          base: { hp: 1080, atk: 92, def: 140, spd: 70 },
          visual: { body: 'bulky', prop: 'shield', accent: '#8a5cff', accent2: '#140a26' },
          skills: {
            passive: { name: 'Carapace du vide', desc: 'Réduit les dégâts subis de 10 % tant qu\u2019il reste le dernier allié en vie.' },
            active: { name: 'Onde de choc', cooldown: 9, desc: 'Repousse et étourdit brièvement les ennemis proches.' },
            ultimate: { name: 'Effondrement local', cost: 100, desc: 'Attire les ennemis proches et leur inflige des dégâts basés sur sa défense.' }
          },
          shop: { cost: { gem: 240 } }
        });
        console.log('[arsenal_cosmique] Héros ajoutés : Nébulon (légendaire, sniper), Voidram (épique, tank).');
      } catch (err) { console.error('[arsenal_cosmique] Échec ajout héros', err); }
    }

    if (typeof CC.upsertItem === 'function') {
      try {
        CC.upsertItem({ id: 'arsenal_eclat_nova', name: 'Éclat de Nova', slot: 'weapon', rarity: 'legendaire', accent: '#ff6a3d' });
        CC.upsertItem({ id: 'arsenal_noyau_abyssal', name: 'Noyau Abyssal', slot: 'reactor', rarity: 'epique', accent: '#4fd1ff' });
        CC.upsertItem({ id: 'arsenal_griffe_du_vide', name: 'Griffe du Vide', slot: 'artifact', rarity: 'rare', accent: '#b47bff' });
        console.log('[arsenal_cosmique] 3 modèles d\u2019objets ajoutés à l\u2019Atelier (Éclat de Nova, Noyau Abyssal, Griffe du Vide).');
      } catch (err) { console.error('[arsenal_cosmique] Échec ajout objets', err); }
    }
  }

  // ---------- 3. Panneau Booster (équilibrage réversible via GameConfig) ----------
  var CLES_BOOST = ['eco_global_prod_mult', 'eco_global_tap_mult', 'eco_building_cost_mult'];

  function creerPanneauBooster() {
    var GC = window.NEBUSTION.CustomContent && NEBUSTION.CustomContent.GameConfig;
    if (!GC) { console.warn('[arsenal_cosmique] GameConfig indisponible, panneau Booster non affiché.'); return; }

    var ouvert = false;

    var bascule = document.createElement('button');
    bascule.textContent = '⚡ Booster';
    bascule.style.cssText =
      'position:fixed; bottom:calc(env(safe-area-inset-bottom,0px) + 10px); right:10px; z-index:99997;' +
      'background:rgba(8,12,26,0.85); color:#ffd166; border:1px solid rgba(255,209,102,0.4);' +
      'border-radius:8px; padding:6px 10px; font:11px monospace; cursor:pointer;';

    var panneau = document.createElement('div');
    panneau.style.cssText =
      'position:fixed; bottom:calc(env(safe-area-inset-bottom,0px) + 52px); right:10px; z-index:99997;' +
      'display:none; flex-direction:column; gap:4px; width:220px; background:rgba(8,12,26,0.92);' +
      'border:1px solid rgba(255,209,102,0.4); border-radius:10px; padding:8px;';

    var titre = document.createElement('div');
    titre.textContent = '⚡ Booster du mod (équilibrage)';
    titre.style.cssText = 'color:#ffd166; font:11px monospace; margin-bottom:2px;';
    panneau.appendChild(titre);

    var etat = document.createElement('div');
    etat.style.cssText = 'color:#c9d4ea; font:10px monospace; margin-bottom:4px;';
    panneau.appendChild(etat);

    function rafraichirEtat() {
      var prod = GC.get('eco_global_prod_mult');
      var cout = GC.get('eco_building_cost_mult');
      etat.textContent = 'Production x' + Number(prod).toFixed(2) + ' — Coûts bâtiments x' + Number(cout).toFixed(2);
    }

    function bouton(libelle, action) {
      var b = document.createElement('button');
      b.textContent = libelle;
      b.style.cssText =
        'background:#151b30; color:#e6ecff; border:1px solid rgba(255,255,255,0.15);' +
        'border-radius:6px; padding:5px 8px; font:11px monospace; cursor:pointer; text-align:left;';
      b.addEventListener('click', function () {
        try { action(); } catch (err) { console.error('[arsenal_cosmique]', err); }
        rafraichirEtat();
      });
      panneau.appendChild(b);
      return b;
    }

    bouton('Production x2 / Coûts -15 %', function () {
      GC.set('eco_global_prod_mult', 2);
      GC.set('eco_global_tap_mult', 2);
      GC.set('eco_building_cost_mult', 0.85);
    });
    bouton('Production x3 / Coûts -30 %', function () {
      GC.set('eco_global_prod_mult', 3);
      GC.set('eco_global_tap_mult', 3);
      GC.set('eco_building_cost_mult', 0.7);
    });
    bouton('Réinitialiser l\u2019équilibrage', function () {
      CLES_BOOST.forEach(function (k) { GC.reset(k); });
    });

    var note = document.createElement('div');
    note.textContent = 'Réglages partagés avec l\u2019Atelier créateur (onglet Réglages) : réversible à tout moment.';
    note.style.cssText = 'color:#7d879e; font:9px monospace; margin-top:2px;';
    panneau.appendChild(note);

    bascule.addEventListener('click', function () {
      ouvert = !ouvert;
      panneau.style.display = ouvert ? 'flex' : 'none';
      if (ouvert) rafraichirEtat();
    });

    document.body.appendChild(panneau);
    document.body.appendChild(bascule);
  }

  NEBUSTION.Mods.register({
    id: 'arsenal_cosmique',
    name: 'Arsenal Cosmique (pack)',
    version: '1.0.0',

    // Contenu (héros/objets) ajouté avant le démarrage de Phaser, comme documenté dans
    // LISEZMOI_MODS.md : NEB.CustomContent existe déjà à ce stade.
    init: function (NEB) { ajouterContenu(NEB); },

    // Panneau : après le démarrage de Phaser, comme les autres mods avec interface
    // (voir mods/hud_fps.js, mods/outils_debug.js).
    onGameReady: function () { creerPanneauBooster(); }
  });
})();
