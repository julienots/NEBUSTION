/**
 * NEBUSTION - Mod : Temps de jeu
 * Affiche en bas à gauche le temps de jeu total (cumulé sur toutes les sessions, stocké à part
 * dans localStorage — indépendant de la sauvegarde du jeu) et le temps de la session en cours.
 */
(function () {
  'use strict';

  var CLE_STOCKAGE = 'nebustion_mod_temps_de_jeu_total_ms';

  function chargerTotal() {
    try {
      var v = parseInt(localStorage.getItem(CLE_STOCKAGE), 10);
      return (isFinite(v) && v > 0) ? v : 0;
    } catch (err) { return 0; }
  }
  function sauverTotal(ms) {
    try { localStorage.setItem(CLE_STOCKAGE, String(Math.floor(ms))); } catch (err) { /* stockage indisponible : tant pis */ }
  }
  function formater(ms) {
    var s = Math.floor(ms / 1000);
    var h = Math.floor(s / 3600); s -= h * 3600;
    var m = Math.floor(s / 60); s -= m * 60;
    function pad(n) { return (n < 10 ? '0' : '') + n; }
    return (h > 0 ? h + ':' : '') + pad(m) + ':' + pad(s);
  }

  var totalAuDemarrage = chargerTotal();
  var debutSession = Date.now();
  var el = null;
  var dernierEnregistrement = 0;
  var dernierRendu = 0;

  function totalActuel(t) { return totalAuDemarrage + (t - debutSession); }

  function surFermeture() { sauverTotal(totalActuel(Date.now())); }
  window.addEventListener('pagehide', surFermeture);
  document.addEventListener('visibilitychange', function () { if (document.hidden) surFermeture(); });

  NEBUSTION.Mods.register({
    id: 'temps_de_jeu',
    name: 'Temps de jeu',
    version: '1.0.0',

    onGameReady: function () {
      el = document.createElement('div');
      el.style.cssText =
        'position:fixed; bottom:calc(env(safe-area-inset-bottom,0px) + 10px); left:10px; z-index:99998;' +
        'background:rgba(8,12,26,0.7); color:#c9d4ea; border:1px solid rgba(201,212,234,0.3);' +
        'border-radius:8px; padding:4px 8px; font:11px/1.3 monospace; pointer-events:none;';
      document.body.appendChild(el);
    },

    // NEBUSTION.Mods appelle onTick à chaque frame (voir js/main.js) : on se limite nous-mêmes
    // à une mise à jour par seconde pour ne pas re-dessiner le texte 60 fois par seconde.
    onTick: function (t) {
      if (!el || t - dernierRendu < 1000) return;
      dernierRendu = t;
      el.textContent = '⏱ Total : ' + formater(totalActuel(t)) + '  (session : ' + formater(t - debutSession) + ')';
      if (t - dernierEnregistrement > 10000) { dernierEnregistrement = t; sauverTotal(totalActuel(t)); }
    }
  });
})();
