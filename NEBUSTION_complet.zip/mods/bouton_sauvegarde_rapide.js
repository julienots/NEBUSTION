/**
 * NEBUSTION - Mod : Sauvegarde rapide
 * ---------------------------------------------------------------------------
 * Petit bouton flottant 💾 (bas-droite) qui déclenche une sauvegarde manuelle
 * immédiate via NEBUSTION.Resources.saveNow(now) — la même méthode que le
 * bouton « Sauvegarder maintenant » de mods/outils_debug.js, mais accessible
 * en permanence (pas seulement en ?debug=1). Affiche un petit statut
 * ✅/⚠️ juste au-dessus pendant 1,8 s.
 */
(function () {
  'use strict';

  var minuteur = null;

  function afficherStatut(el, texte, ok) {
    el.textContent = texte;
    el.style.color = ok ? '#9dffb0' : '#ff8f8f';
    el.style.opacity = '1';
    if (minuteur) clearTimeout(minuteur);
    minuteur = setTimeout(function () { el.style.opacity = '0'; }, 1800);
  }

  NEBUSTION.Mods.register({
    id: 'bouton_sauvegarde_rapide',
    name: 'Sauvegarde rapide',
    version: '1.0.0',

    onGameReady: function (game, NEB) {
      if (!NEB.Resources || typeof NEB.Resources.saveNow !== 'function') return;

      var bouton = document.createElement('button');
      bouton.textContent = '💾';
      bouton.title = 'Sauvegarder maintenant';
      bouton.style.cssText =
        'position:fixed; bottom:calc(env(safe-area-inset-bottom,0px) + 90px); right:10px; z-index:99997;' +
        'width:42px; height:42px; border-radius:50%; border:1px solid rgba(143,216,255,0.4);' +
        'background:rgba(8,12,26,0.85); color:#8fd8ff; font-size:18px; line-height:1; cursor:pointer;';

      var statut = document.createElement('div');
      statut.style.cssText =
        'position:fixed; bottom:calc(env(safe-area-inset-bottom,0px) + 138px); right:10px; z-index:99997;' +
        'font:11px monospace; background:rgba(8,12,26,0.85); border-radius:6px; padding:3px 8px; color:#9dffb0;' +
        'opacity:0; transition:opacity .3s ease; pointer-events:none;';

      bouton.addEventListener('click', function () {
        var ok = false;
        try { ok = !!NEB.Resources.saveNow(Date.now()); } catch (err) { console.error('[bouton_sauvegarde_rapide]', err); }
        afficherStatut(statut, ok ? '✅ Sauvegardé' : '⚠️ Échec', ok);
        console.log('[bouton_sauvegarde_rapide] Sauvegarde manuelle : ' + (ok ? 'réussie' : 'échouée'));
      });

      document.body.appendChild(statut);
      document.body.appendChild(bouton);
    }
  });
})();
