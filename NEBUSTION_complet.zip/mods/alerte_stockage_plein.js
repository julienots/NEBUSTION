/**
 * NEBUSTION - Mod : Alerte stockage plein
 * ---------------------------------------------------------------------------
 * S'abonne à l'événement 'full' de NEBUSTION.Resources (émis à chaque tentative
 * d'ajout alors qu'une ressource est déjà à son plafond — voir js/systems/
 * ResourceManager.js) et affiche un bandeau temporaire pour prévenir le joueur.
 * Un cooldown par ressource évite le spam (l'événement peut se répéter à
 * chaque tick tant que le stock reste plein).
 */
(function () {
  'use strict';

  var LABELS = { crystal: 'Cristaux', metal: 'Métal', energy: 'Énergie', core: 'Noyaux', dust: 'Poussière' };
  var COOLDOWN_MS = 60000;
  var dernierAffichage = {};

  function toast(texte) {
    try {
      var el = document.createElement('div');
      el.textContent = texte;
      el.style.cssText =
        'position:fixed; top:calc(env(safe-area-inset-top,0px) + 60px); left:50%; transform:translateX(-50%);' +
        'z-index:99996; max-width:80vw; text-align:center; pointer-events:none;' +
        'background:rgba(40,16,16,0.9); color:#ffb3a8; border:1px solid rgba(255,138,120,0.5);' +
        'border-radius:10px; padding:8px 14px; font:12px/1.4 monospace; opacity:0; transition:opacity .35s ease;';
      document.body.appendChild(el);
      requestAnimationFrame(function () { el.style.opacity = '1'; });
      setTimeout(function () {
        el.style.opacity = '0';
        setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 400);
      }, 3200);
    } catch (err) { /* affichage best-effort : ne doit jamais planter le jeu */ }
  }

  NEBUSTION.Mods.register({
    id: 'alerte_stockage_plein',
    name: 'Alerte stockage plein',
    version: '1.0.0',

    onGameReady: function (game, NEB) {
      if (!NEB.Resources || typeof NEB.Resources.on !== 'function') return;
      NEB.Resources.on('full', function (data) {
        var id = data && data.id;
        if (!id) return;
        var maintenant = Date.now();
        if (dernierAffichage[id] && maintenant - dernierAffichage[id] < COOLDOWN_MS) return;
        dernierAffichage[id] = maintenant;
        toast('📦 Stockage plein : ' + (LABELS[id] || id) + ' — améliorez le stockage ou dépensez le surplus.');
      });
    }
  });
})();
