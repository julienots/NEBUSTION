/**
 * NEBUSTION - Mod : Moniteur FPS
 * Petit compteur d'images par seconde en haut à gauche de l'écran, utile pour repérer un ralentissement
 * pendant le développement. Touchez le badge pour le masquer/l'afficher.
 * S'appuie sur game.loop.actualFps (API native de Phaser) — voir onGameReady ci-dessous.
 */
(function () {
  'use strict';

  var ID = 'mod-hud-fps';

  function creerBadge() {
    var el = document.createElement('div');
    el.id = ID;
    el.textContent = 'FPS: --';
    el.title = 'Toucher pour masquer/afficher';
    el.style.cssText =
      'position:fixed; top:calc(env(safe-area-inset-top,0px) + 10px); left:10px; z-index:99998;' +
      'background:rgba(8,12,26,0.75); color:#9dffb0; border:1px solid rgba(157,255,176,0.35);' +
      'border-radius:8px; padding:4px 8px; font:11px/1.3 monospace; pointer-events:auto;' +
      'cursor:pointer; user-select:none;';
    var visible = true;
    el.addEventListener('click', function () {
      visible = !visible;
      el.style.opacity = visible ? '1' : '0.15';
    });
    document.body.appendChild(el);
    return el;
  }

  NEBUSTION.Mods.register({
    id: 'hud_fps',
    name: 'Moniteur FPS',
    version: '1.0.0',

    // Appelé une fois Phaser.Game créé : on branche directement sur la boucle du jeu plutôt que
    // sur onTick (appelé par NEBUSTION.Mods pour tous les mods) pour contrôler nous-mêmes le
    // rafraîchissement (2x/seconde suffit, pas besoin de redessiner à 60 FPS).
    onGameReady: function (game) {
      var el = creerBadge();
      var dernierRafraichissement = 0;
      game.events.on('step', function () {
        var maintenant = Date.now();
        if (maintenant - dernierRafraichissement < 500) return;
        dernierRafraichissement = maintenant;
        var fps = (game.loop && typeof game.loop.actualFps === 'number') ? Math.round(game.loop.actualFps) : 0;
        el.textContent = 'FPS: ' + fps;
        el.style.color = fps >= 50 ? '#9dffb0' : (fps >= 30 ? '#ffe07a' : '#ff8f8f');
      });
    }
  });
})();
