# NEBUSTION — Système de mods/plugins

Permet d'ajouter du contenu ou du comportement au jeu **sans toucher aux fichiers du jeu**
(`js/data/`, `js/systems/`, `js/scenes/`...). Un mod est un fichier `.js` posé dans `mods/` et
déclaré dans `mods/manifest.js`.

## Activer / désactiver un mod depuis le jeu (recommandé)
Ouvrez ⚙ **Paramètres → 🧩 Mods et plugins** : chaque mod fourni a un interrupteur. Le basculer
joue une petite animation « installation/désinstallation » puis enregistre le choix (stocké dans
`localStorage`, indépendant de la sauvegarde de partie). Comme les mods sont chargés tout au début
du jeu (voir `index.html`), un bouton **« 🔄 Recharger le jeu »** en bas de cet écran applique le
changement immédiatement.

## Activer / désactiver un mod à la main (édition de fichier)
Éditez `mods/manifest.js` : chaque mod fourni est une entrée du tableau `NEBUSTION.ModsCatalog.AVAILABLE`,
avec un champ `defaultOn: true/false`. C'est ce réglage qui s'applique tant qu'aucun choix n'a été
fait depuis l'écran Paramètres (une fois touché dans le jeu, le choix stocké dans `localStorage`
prend le dessus sur `defaultOn`).
```js
{ id: 'mon_mod', file: 'mods/mon_mod.js', name: 'Mon mod', desc: '...', defaultOn: true }
```
Ajoutez une entrée pour proposer un nouveau mod dans la liste (à l'écran Paramètres comme dans le
fichier), ou passez `defaultOn` à `false` pour qu'il soit désactivé par défaut.

## Écrire un mod
Un mod s'enregistre avec `NEBUSTION.Mods.register({ ... })` :

```js
NEBUSTION.Mods.register({
  id: 'mon_mod',              // identifiant unique (obligatoire)
  name: 'Mon mod',            // nom affiché
  version: '1.0.0',

  init: function (NEB) {
    // Appelé immédiatement au chargement du fichier, AVANT le démarrage de Phaser.
    // Toutes les données du jeu existent déjà : NEB.Shop, NEB.Heroes, NEB.Economy,
    // NEB.Equipment, NEB.Ships, NEB.Codex, etc.
  },

  onGameReady: function (game, NEB) {
    // Appelé une fois Phaser.Game créé (game = window.__NEBUSTION_GAME__).
  },

  onTick: function (t, NEB) {
    // Optionnel : appelé en continu, quelle que soit la scène affichée (même rythme que
    // les autres managers hors-écran — voir js/main.js). t = Date.now().
  },

  scenes: [
    // Optionnel : classes de scène Phaser à ajouter au jeu (ex. new Phaser.Scene(...) / class).
  ]
});
```
Seul `id` est obligatoire ; tout le reste est optionnel selon ce que fait le mod.

**Ordre de chargement** (voir `index.html`) : Phaser → toutes les données et tous les managers du
jeu → tous les mods du manifeste, dans l'ordre → `js/main.js` (qui démarre Phaser.Game). Un mod
peut donc lire/modifier n'importe quelle donnée du jeu dans `init()`, et le jeu n'a pas encore
démarré à ce moment-là.

## Modifier des données existantes
Les modules de données exposent leurs tableaux/objets par référence (ex.
`NEBUSTION.Shop.DAILY_POOL`, `NEBUSTION.Shop.DAILY_INDEX`). Un mod peut donc les compléter
directement dans `init()` :
```js
NEB.Shop.DAILY_POOL.push({ id: 'mod_xxx', kind: 'resource', label: '...', res: { dust: 500 }, cost: { crystal: 50 } });
NEB.Shop.DAILY_INDEX['mod_xxx'] = NEB.Shop.DAILY_POOL[NEB.Shop.DAILY_POOL.length - 1];
```
**Préfixez toujours vos identifiants** (`mod_...`) pour ne jamais entrer en collision avec un id
du jeu ou d'un autre mod — `register()` refuse un `id` de mod déjà pris, mais rien n'empêche deux
mods d'écraser la même clé dans une donnée du jeu si vous ne préfixez pas.

## Mods fournis
Le réglage `defaultOn` de chaque mod (voir `mods/manifest.js`) ne s'applique que tant qu'aucun
choix n'a été fait depuis l'écran Paramètres — une fois touché dans le jeu, c'est ce choix qui
prend le dessus. Les mods de confort/HUD légers sont activés par défaut ; tout ce qui ajoute du
contenu ou un comportement plus visible démarre désactivé, à activer volontairement.

| Fichier | Par défaut | Ce qu'il fait |
|---|---|---|
| `mods/exemple_mod.js` | Activé | Modèle de base : ajoute une offre à la boutique quotidienne, lit le stock de cristaux, affiche un badge (haut-droite) listant les mods actifs pendant 5 s. |
| `mods/hud_fps.js` | Activé | Compteur FPS en haut à gauche (branché sur `game.loop.actualFps`). Toucher le badge le masque/l'affiche. |
| `mods/temps_de_jeu.js` | Activé | Badge en bas à gauche : temps de jeu total (cumulé entre sessions, stocké à part en `localStorage`, indépendant de la sauvegarde du jeu) + temps de la session en cours. |
| `mods/outils_debug.js` | Activé | Panneau en bas à droite, **visible uniquement avec `?debug=1` dans l'URL** (même convention que le reste du jeu) : boutons « +1000 de chaque ressource », « Sauvegarder maintenant », « Logger l'état des ressources », « Lister les mods actifs ». |
| `mods/offres_boutique_plus.js` | Activé | Ajoute 5 offres au pool de la boutique quotidienne (ressources, lot, objet épique, prismes) — additif, sans doublon au rechargement. |
| `mods/hud_ressources_taux.js` | Activé | Barre en haut de l'écran : stock + production/minute des 5 ressources. Toucher la barre la réduit (cristaux seuls) ou l'agrandit. |
| `mods/alerte_stockage_plein.js` | Activé | Bandeau d'avertissement quand une ressource atteint son plafond (écoute l'événement `'full'` du ResourceManager), avec anti-spam par ressource. |
| `mods/bouton_sauvegarde_rapide.js` | Activé | Bouton flottant 💾 (bas-droite) pour sauvegarder manuellement à tout moment, avec petit statut ✅/⚠️. |
| `mods/arsenal_cosmique.js` | **Désactivé** | **Gros mod** : 2 héros jouables (Nébulon, Voidram), 3 objets d'équipement, et un panneau « ⚡ Booster » pour multiplier production/réduire coûts via `NEBUSTION.CustomContent.GameConfig` (réversible). |
| `mods/journal_activite.js` | **Désactivé** | Badge 📜 replié (haut-droite) : journal des améliorations de bâtiments, récoltes critiques et Renaissances, abonné aux événements `upgrade`/`gain`/`prestige` de `NEBUSTION.Resources`. Les 30 dernières entrées sont conservées entre les sessions. |
| `mods/raccourcis_clavier.js` | **Désactivé** | Touches **1 à 6** (clavier desktop) pour aller directement à Planète / Galaxie / Héros / Boutique / QG / Codex. Badge ⌨️ (bas-droite, empilé au-dessus de Sauvegarde rapide) pour rappeler les touches. Désactivé pendant un combat ou une bataille de QG, et si le focus est dans un champ de texte. |
| `mods/bestiaire_menace.js` | **Désactivé** | Ajoute 2 ennemis jouables dans l'**Arène personnalisée** via `NEBUSTION.CustomContent.upsertEnemy` : Nécroptère (drain) et Bastion-Zéro (tank à bouclier). |

Copiez n'importe lequel pour démarrer votre propre mod — `exemple_mod.js` est le plus commenté.

## Limites à connaître
- Un mod tourne dans le **même contexte global** que le jeu (pas de bac à sable) : il peut donc
  aussi bien enrichir une donnée que la corrompre s'il est mal écrit. Testez vos mods un par un.
- `NEBUSTION.Mods.list()` et `NEBUSTION.Mods.errors()` (console du navigateur) donnent à tout
  moment la liste des mods chargés et les erreurs rencontrées.
- Ce système ne fournit pas de mise à jour à chaud : un mod modifié n'est repris qu'au rechargement
  de la page (F5 / relance de l'appli).
