# NEBUSTION — Module IA des 5 empires (suite du module Galaxie)

Ce ZIP part de votre module Galaxie (`Galaxy.js` / `GalaxyManager.js` / `SaveManager.js` mis à jour)
et ajoute l'intelligence des 5 empires : **VEXOR, KAEL-9, ELYRA, MORVAK, NYR'AH**. Rien n'est réécrit :
les fichiers du module Galaxie et tout le reste du jeu (économie, héros, combat, sauvegarde) sont
strictement inchangés.

## Fichiers ajoutés

| Fichier | Rôle |
|---|---|
| `js/data/EmpireAI.js` | Données + logique **pures** (sans Phaser, sans sauvegarde) : personnalité, stratégies, niveaux de difficulté de chaque empire. |
| `js/systems/EmpireAIManager.js` | Branche `EmpireAI` sur l'état réel du jeu (`Galaxy` + `GalaxyManager` + `Resources`) : évalue la situation de chaque empire, choisit sa décision, propose des intentions. |
| `tests/empireAI.test.js` | 220 vérifications automatiques (données, décisions, difficulté, réactions aux événements). |

Comme `Galaxy.js`/`GalaxyManager.js`, ces fichiers ne sont **pas encore chargés par `index.html`** : il n'y
a pas encore d'écran « Galaxie » dans le jeu, donc rien à y brancher visuellement. Ils sont testables sous
Node dès maintenant et prêts à être consommés par la future scène + le futur module d'invasion, sans aucune
modification nécessaire de leur API.

## Ce que fait ce module

Chaque empire a :
- **une identité propre** (déjà posée dans `Galaxy.js` : description, doctrine, trait, unités, défenses,
  ressources — réutilisée telle quelle, pas dupliquée) ;
- **une personnalité** (`EmpireAI.PERSONALITY`) : 6 poids (agressivité, défense, expansion, opportunisme,
  résilience, coordination) qui différencient nettement les 5 empires — MORVAK est le plus agressif,
  ELYRA le plus porté sur la défense, NYR'AH le plus opportuniste, KAEL-9 le plus coordonné, VEXOR le plus
  résilient ;
- **3 stratégies** (`EmpireAI.STRATEGIES`), une par posture (équilibrée / défensive / offensive), chacune
  avec un nom, un texte, une condition d'activation liée à la situation réelle, et des effets numériques
  (bouclier, tourelles, vitesse de renfort, chance de contre-attaque) ;
- **4 niveaux de difficulté** (`facile / normal / difficile / cauchemar`, les mêmes clés que le module
  Combat) qui amplifient réactivité, agressivité et vitesse de renfort — vérifié strictement croissant.

`EmpireAIManager.decide(empire, maintenant)` évalue la situation réelle de l'empire (planètes conquises,
secteur sous pression, scans/visites du joueur, niveau d'équipe comparé au niveau conseillé de l'empire,
capitale tombée ou non) et choisit la stratégie la plus adaptée — par exemple un empire totalement conquis
bascule en repli défensif, tandis qu'un empire intact garde son tempérament naturel (MORVAK reste offensif
même au calme). Un anti-oscillation (`thinkDelayMs`, plus court aux difficultés élevées) évite qu'un empire
change d'avis à chaque frame.

`EmpireAIManager.intents(empire, maintenant)` traduit la décision en actions **proposées** (renforcer sa
capitale, fortifier sa frontière, contre-attaquer sa planète la plus profondément conquise, étendre son
influence vers le monde neutre le plus proche), triées par priorité — une lecture seule, aucune mutation de
la sauvegarde : c'est la base sur laquelle le futur module d'invasion pourra s'appuyer sans rien casser ici.

`EmpireAIManager.wire()` branche le recalcul sur les événements déjà émis par `GalaxyManager`
(`conquest`, `scanDone`, `unlock`) : conquérir une planète de MORVAK ne fait réagir que MORVAK, pas les
autres empires — vérifié par test.

Tout est 100 % hors ligne, calculé en mémoire à partir de votre sauvegarde existante : aucun serveur,
aucun faux multijoueur.

## Ce que ce module ne fait PAS (volontairement, pour la suite)

Ce lot prépare le système de décision mais ne fait pas encore évoluer les empires dans la durée : pas de
ressources/territoires/puissance des empires qui progressent tout seuls, pas de renforcement persistant
après une défaite du joueur, pas de nouvel état sauvegardé pour les empires. `decide()`/`intents()` sont
recalculés à la demande à partir de votre sauvegarde actuelle (planètes conquises, secteurs débloqués...).
Cette base est conçue pour qu'une prochaine étape puisse y ajouter cette évolution et sa sauvegarde sans
modifier l'API existante.

## Tests

```
node tests/empireAI.test.js     220 vérifications (personnalités, stratégies, difficulté, décisions, intentions, réactions)
node tests/galaxy.test.js       916 vérifications (non-régression du module Galaxie)
node tests/economy.test.js, tests/heroes.test.js, tests/enemies.test.js, tests/combat.test.js   (non-régression, tous verts)
```
