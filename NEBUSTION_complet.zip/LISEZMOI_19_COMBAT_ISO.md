# NEBUSTION — Mode combat en 2.5D isométrique + design des troupes

Le MODE COMBAT (`QGBattleScene`) n'est plus une vue de dessus avec des emojis : il reprend la vue **iso 2D/3D** du QG.

## Ce qui a changé (rendu uniquement — le moteur `QGBattle.js`, les troupes, le butin, les étoiles sont intacts)
- **Terrain iso** : la base ennemie est posée sur sa plateforme flottante (mêmes parcelles/structures que dans la visite du QG),
  entourée d'un terrain de largage en losange. Toute l'arène (9×9 cellules) tient à l'écran, sans glisser.
- **Structures en volume** : Cœur du QG (nouvelle tour à cristal), Barricades, Tourelles, Générateurs, Silos — barres de PV,
  flash + étincelles quand elles sont touchées, **ruines + flammes** quand elles tombent, explosion en boule de feu.
- **Déploiement** : choisis une troupe → la **zone verte** (déploiement) et la **zone rouge** (interdite) s'affichent →
  tape dans le vert : un faisceau lumineux « largue » la troupe, elle atterrit avec un rebond.
- **Chaque troupe a SON design dessiné** (2 images de marche, tourné vers sa direction) :
  Marine (fusil) · Berserker (casque à cornes + hache) · Tireur (capuche + long fusil) · Éclaireur (lignes de vitesse) ·
  Grenadier (sac + lance-grenades) · Garde-bouclier (grand bouclier) · Casseur (bombe à mèche qui clignote) ·
  Spectre (capuche fantôme) · Vaisseau d'assaut / Bombardier / Croiseur (volent, ombre au sol, flammes des moteurs) ·
  Titan (char à chenilles) · Mécha Golem (bipède géant).
- Animation : marche (alternance + rebond), attaque au corps à corps (élan + étincelles sur la cible), tirs à distance
  (traînée lumineuse), flash rouge quand la troupe est touchée, disparition en fumée quand elle tombe.
- Les cartes de la réserve (en bas) montrent le design de chaque troupe au lieu d'un emoji.
- `sw.js` : cache `nebustion-v24-combat-iso` (force la mise à jour de la PWA).

## Fichiers
`js/scenes/QGBattleScene.js` (réécrit ; hérite de `QGScene` pour réutiliser plateforme, parcelles et volumes iso),
`sw.js`, `tests/browser-combat.py` (taps convertis en coordonnées iso + 5 vérifications).

## Tests
`python3 tests/browser-combat.py` (Chromium + faux Phaser) → 31 OK. `node tests/qgBattle.test.js` → 68 OK. `browser-qgbots.py` OK.

## À valider sur téléphone
Vérifié avec un **faux Phaser** (pas d'accès réseau pour charger le vrai) : les dessins des troupes/structures ont été
rendus et regardés, mais les tailles, la fluidité et les animations sont à valider dans le vrai jeu.
Réglages faciles dans `QGBattleScene.js` : taille des troupes (`UI` dans `_makeUnit`), vitesse de marche (`iv` dans `_syncUnits`).
