# NEBUSTION — Étape 9 : 8 nouveaux héros (Boutique)

Velmora (Légendaire, Soigneur), Zephyrax (Épique, Assassin), Drakathor (Mythique, Dégâts), Sélénia (Épique, Sniper),
Krakenis (Légendaire, Tank), Nythera (Mythique, Dégâts), Arcanis (Épique, Contrôle), Vulkar (Légendaire, Tank).

- **Achat** : Boutique → onglet **Héros** (ouvre directement sur le premier héros à recruter ; flèches ‹ › pour changer) → « Acheter » → confirmation.
  Aussi : Collection (Héros) → toucher un héros marqué « BOUTIQUE » ouvre la Boutique sur lui.
- **Prix** (Prismes, modifiables dans `js/data/Heroes.js`, champ `shop.cost`) : Épique 220 · Légendaire 380 · Mythique 560.
- Tant qu'un héros n'est pas recruté : absent de la sélection d'équipe de combat, fragments non achetables.
  Une fois recruté : niveau 1, fragments achetables comme les autres héros.
- Chaque héros a son kit de combat dédié (`HERO_KIT` dans `js/systems/CombatEngine.js`).
- Sauvegarde : `state.combat.unlockedHeroes` (anciennes sauvegardes compatibles).
- Portraits : `assets/heroes/<id>.png` (300×380, découpés de la planche fournie).

Tests : `node tests/heroShop.test.js` ; `NODE_PATH=$(npm root -g) node tests/browser-heroshop.js` (faux Phaser).

## Correctif chargement des images (héros / boss)
Cause probable : le chargeur abandonnait les vraies illustrations après un délai FIXE de 4 s (8,4 Mo d'images) et le pré-cache
du service worker lançait ~120 téléchargements simultanés en concurrence avec le jeu → portraits/boss « générés » à la place.
Corrigé : `js/utils/LoaderGuard.js` (blocage = aucun octet reçu pendant 15 s, jamais un simple chargement lent), images de boss
appliquées même si elles arrivent tard, pré-cache du service worker limité à 2 requêtes à la fois, PNG recompressés sans perte.
Test : `node tests/loaderGuard.test.js`. Si le problème persiste : ouvrir la console du navigateur (F12) et chercher les erreurs
« 404 » / « Failed to load » ; le jeu doit être servi en HTTP(S) (pas en double-cliquant index.html : file:// bloque le chargement d'images par Phaser).
