# NEBUSTION — Shaders (espace, galaxie, planètes)

## Ce qui change
- **Fond spatial animé** (toutes les scènes qui utilisent `SceneBackground` : Univers, Galaxie, système solaire, planètes…) :
  nébuleuse qui dérive (bruit fbm violet/cyan/magenta) + étoiles qui scintillent + vignette.
  **Univers et Galaxie** : variante *galaxie* avec bras spiraux qui tournent lentement et cœur lumineux chaud.
- **Planètes** (Nexus-01 et les 6 mondes de la Nouvelle Galaxie) : liseré d'atmosphère à la couleur du monde, léger battement, reflet de lumière.
- Le décor existant (étoiles, nébuleuses, poussière) reste par-dessus : le shader est juste un nouveau fond, derrière.

## Sécurité / performance
- Actif seulement en **WebGL**. En mode Canvas, **économie de batterie** ou **effets réduits** : aucun shader, décor classique.
- Toute erreur d'un shader est ignorée (le jeu continue sans l'effet).
- Fond : 3 octaves de bruit seulement. Si ça ralentit sur un vieux téléphone, baisse `NEB` ou retire la 2e couche d'étoiles dans `js/utils/Shaders.js`.

## Fichiers
- Nouveau : `js/utils/Shaders.js` (GLSL + installation), `tests/shaders-smoke.js`.
- Modifiés : `js/utils/SceneBackground.js`, `js/main.js` (installation), `js/scenes/PlanetScene.js` et `ExoPlanetScene.js` (effet planète), `index.html`, `sw.js` (cache v61).

## À vérifier sur téléphone (honnêteté)
Pas testé avec un vrai WebGL ici : le code GLSL n'a pas été compilé par un GPU. Logique, installation et désactivation testées avec un faux Phaser
(`node tests/shaders-smoke.js`). Si l'écran reste noir ou si le fond ne s'affiche pas, active « effets réduits » (repli classique) et dis-moi.
