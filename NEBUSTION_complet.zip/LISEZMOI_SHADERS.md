# NEBUSTION — Fond d'espace / galaxie (sans shader GPU)

Les shaders WebGL sont **retirés** : ils rendaient l'affichage pixelisé et faisaient chuter les FPS (PlanetScene baissait alors la résolution de la planète).
Le garde-fou FPS est supprimé avec eux.

Nouveau fond : peint **une seule fois** sur un petit canvas (`js/utils/Shaders.js`), affiché comme une image lissée derrière le décor, avec une lente dérive.
- Toutes les scènes utilisant `SceneBackground` : nébuleuse violet/cyan/magenta.
- Univers et Galaxie : en plus, bras spiraux et cœur lumineux chaud.
- Aucun coût GPU après la génération (~50 ms, une fois par session). Désactivé en économie de batterie / effets réduits.
- Plus de liseré de planète ni de post-traitement. `main.js` n'installe plus rien côté GPU.

Test : `node tests/shaders-smoke.js` (11 vérifications).
