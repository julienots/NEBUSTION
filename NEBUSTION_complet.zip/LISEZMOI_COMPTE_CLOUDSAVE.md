# NEBUSTION — Compte joueur + sauvegarde en ligne (Firebase)

## Ce qui a été ajouté
- **Écran Compte** : accessible depuis l'icône ⚙ (en haut à gauche, présente sur tout écran
  avec HUD) → « Compte ». Connexion / création de compte par e-mail + mot de passe, statut
  connecté, bouton « Synchroniser maintenant », déconnexion, mot de passe oublié.
- **Sauvegarde en ligne** : une fois connecté, la sauvegarde de l'appareil est automatiquement
  envoyée en ligne (Firestore) à chaque sauvegarde locale (limité à 1 envoi toutes les 20 s).
- **Restauration automatique** : si le jeu est rouvert sur un appareil/navigateur où une session
  Firebase existe déjà (retrouve un compte déjà connecté) ET que cet appareil n'a lui-même aucune
  progression locale, sa sauvegarde en ligne est restaurée automatiquement, sans rien demander.
- **Conflit géré sans rien écraser en silence** : si un joueur se connecte à un compte qui a déjà
  une sauvegarde en ligne ALORS que l'appareil a lui aussi sa propre progression, un écran demande
  explicitement laquelle garder (ce choix pousse l'autre en ligne ou recharge le jeu avec celle
  choisie — jamais de perte silencieuse).
- Entièrement **facultatif et non bloquant** : tant que Firebase n'est pas configuré (voir
  ci-dessous), le jeu tourne exactement comme avant, en sauvegarde locale uniquement. Si le SDK
  Firebase ne charge pas (pas de réseau, bloqueur de pub…), pareil : aucun blocage du jeu.

## ⚠️ À FAIRE avant que ça fonctionne : configurer Firebase (5 min, gratuit)
Toutes les étapes détaillées sont en commentaire tout en haut de **`js/data/FirebaseConfig.js`**.
En résumé :
1. Créer un projet sur https://console.firebase.google.com
2. Authentication → activer le fournisseur « E-mail/Mot de passe »
3. Firestore Database → créer une base (mode production)
4. Publier les règles de sécurité fournies dans le fichier (chaque joueur ne lit/écrit que sa
   propre sauvegarde)
5. Copier les clés `firebaseConfig` de ton app web dans `js/data/FirebaseConfig.js`, à la place
   des `REMPLACE_MOI`
6. Redéployer le ZIP tel quel sur Vercel (aucune configuration Vercel supplémentaire : tout se
   passe entre le navigateur du joueur et Firebase directement)

## Fichiers ajoutés / modifiés
- **Ajoutés** : `js/data/FirebaseConfig.js`, `js/systems/CloudSave.js`, `js/scenes/AccountScene.js`
- **Modifiés** : `index.html` (chargement facultatif du SDK Firebase + nouveaux fichiers),
  `js/main.js` (initialisation, restauration silencieuse, envoi automatique), `js/ui/SettingsMenu.js`
  (bouton « Compte »), `css/style.css` (style des champs e-mail/mot de passe), `sw.js` (cache PWA)

## Non testé
Je n'ai pas pu lancer le jeu dans un navigateur ici (pas de réseau sortant dans cet environnement),
ni créer de vrai projet Firebase pour tester de bout en bout. À vérifier une fois Firebase
configuré : connexion, inscription, écran de conflit, restauration automatique sur un second
appareil/navigateur, positionnement des champs e-mail/mot de passe sur ton téléphone.


---
## Correctif « comptes fiables » (v21)

**Bug corrigé** : à la restauration d'un compte (nouvel appareil, ou choix « utiliser la partie du compte »), la page se
rechargeait et la sauvegarde de fermeture du jeu **réécrivait aussitôt l'ancien état en mémoire par-dessus** la partie
restaurée → la restauration n'avait aucun effet. Les sauvegardes locales sont maintenant verrouillées pendant la restauration
(`ResourceManager.lockSaves()`), et l'ancienne partie de l'appareil est gardée en copie (`nebustion_save_v2_before_cloud`).

**Ce qui est sauvegardé dans le compte** : toute la partie (un seul objet) — ressources, bâtiments, drones, héros, étoiles/combat,
galaxie et conquêtes, empires IA, équipement, vaisseaux, skins, boutique, pass, expéditions, événements, Renaissance,
succès, sécurité et grille du QG, raids, attaques, symbiote.

**Nouveautés**
- Envoi immédiat à la mise en veille / changement d'appli / fermeture (avant : minuteur de 20 s perdu à la fermeture).
- Aucun envoi tant que l'appareil et le compte n'ont pas été comparés (évite qu'une vieille partie écrase la récente).
- Écriture en transaction : si un **autre appareil** a joué entre-temps, rien n'est écrasé → écran « Deux parties trouvées »
  avec un résumé de chaque partie (temps de jeu, étoiles, niveaux, conquêtes, date) et choix du joueur.
- Lecture impossible (hors ligne) ≠ compte vide : rien n'est envoyé, message clair dans l'écran Compte.
- Écran Compte : date de la dernière sauvegarde en ligne, ou message d'échec. Marqueur « ⚠ choix requis » dans ⚙.
- Refus propre d'une sauvegarde > 900 Ko (limite Firestore 1 Mo).

**Non sauvegardé dans le compte (volontairement)** : réglages audio de l'appareil et contenu personnalisé des outils `tools/`.

**Tests** : `node tests/cloudSave.test.js` (45 vérifications, faux Firebase en mémoire). Toujours **non testé** avec un vrai
projet Firebase (pas de réseau ici) : à valider sur ton téléphone (voir la liste plus haut).

## Sauvegarde auto en ligne (v22)
Envoi automatique toutes les 30 s (`CloudSave.startAutoSave`), immédiat à chaque amélioration/réinitialisation, à la mise en
veille/fermeture, et reprise dès le retour du réseau après un échec. Sans effet tant que le compte n'est pas connecté ou qu'un
choix de conflit est attendu. Test : `node tests/cloudSave.test.js` (49 vérifications).
