# NEBUSTION — Module 28 : nouveaux bâtiments à CONSTRUCTION (achat + temps de chantier)

## Ce qui change

Jusqu'ici, tous les bâtiments de la grille du QG (`QGScene` → « Entrer › » depuis le panneau QG sur
Nexus-01) étaient posés **instantanément** dès le paiement. Ce module ajoute 4 bâtiments qui doivent
être **achetés PUIS construits** : une fois payés, ils entrent en chantier et ne deviennent actifs
(et ne comptent dans les bonus) qu'après un vrai délai. Les 12 bâtiments existants ne changent pas
de comportement (rétrocompatibilité totale, aucune sauvegarde cassée).

## Les 4 nouveaux bâtiments

| Bâtiment | Icône | Temps de chantier | Effet (par unité) | Utilité |
|---|---|---|---|---|
| **Observatoire stellaire** | 🔭 | 4 min | +3 % d'efficacité de production **hors ligne** | Rentabilise les absences (retour de session) |
| **Balise de ravitaillement** | 🛰️ | 3 min 20 | −8 % d'attente entre deux **caisses de ravitaillement** (plafond 50 %) | Plus de caisses = plus de farm actif |
| **Arsenal de combat** | ⚔️ | 4 min 20 | −2 % supplémentaires sur le **prix des troupes** (cumulable avec l'Atelier) | Armée moins chère à entretenir |
| **Citadelle orbitale** | 🏯 | 5 min | −4 % de **pertes en cas de raid réussi** (cumulable avec le Coffre-fort) | Protège l'économie contre les raids ennemis |

Coûts et plafonds (`maxCount`) : voir `js/data/QGGrid.js` (`STRUCTURES.observatory/beacon/arsenal/citadel`),
même esprit que les bâtiments existants (coût croissant ×growth par exemplaire déjà construit).

## Comment ça marche (mécanique de chantier)

1. **Achat** : le coût est débité intégralement à l'instant du clic (comme avant), rien n'est remboursé
   en cas d'annulation partielle — sauf via le bouton ANNULER (voir plus bas).
2. **Chantier** : la parcelle passe en état « en construction » : `state.qgGrid.building[x,y] = { id, start, end }`.
   Elle n'est ni vide (on ne peut pas y construire autre chose) ni active (aucun bonus, `structureAt()` renvoie `null`).
3. **Décompte visuel** (`QGScene`) : barre de progression + temps restant affichés sur la parcelle,
   rafraîchis chaque seconde par un minuteur (`this.time.addEvent`, nettoyé au `shutdown` de la scène).
   Le panneau (tap sur la parcelle) affiche aussi le temps restant et un bouton **ANNULER** (rembourse 50 %
   du coût payé, même taux que la revente d'un bâtiment terminé).
4. **Fin du chantier** : dès que `Date.now() >= end`, la structure est transférée dans `state.qgGrid.cells`
   et devient active — cela se produit dès le prochain tick (max 1 s de latence), **même si le joueur a
   quitté la scène QG entre-temps** : `completePending()` est pur et basé sur l'horloge réelle, il n'y a pas
   besoin que la scène soit ouverte pour que le temps s'écoule (seul l'AFFICHAGE attend que la scène soit
   rouverte ou que le minuteur coche).

## Fichiers modifiés

- `js/data/QGGrid.js` — catalogue (+4 bâtiments), `state.building`, `startBuild`, `completePending`,
  `remainingMs`, `cancelBuild`, `countsPending`, `pendingAt`, garde-fou `MAX_BUILD_MS` dans `normalizeState`.
- `js/systems/QGGridManager.js` — `build()` route désormais vers un chantier si `def.buildTimeSec` est défini
  (sinon pose instantanée, inchangé) ; ajout de `tick()`, `cancelBuild()`, `pendingAt/isPending/remainingMs/pendingKeys`.
- `js/systems/SaveManager.js` — `QGGrid.normalizeState(raw.qgGrid, now)` (le `now` sert à valider les chantiers).
- `js/systems/ResourceManager.js` — l'Observatoire contribue à l'efficacité hors ligne (`qm.bonusValue('offlineEff')`,
  à côté du bonus de Renaissance existant).
- `js/scenes/PlanetScene.js` — la Balise réduit l'intervalle entre deux caisses de ravitaillement (`_schedulePod`).
- `js/scenes/QGScene.js` — rendu des parcelles en chantier (barre de progression + décompte), panneau
  « en construction » avec bouton ANNULER, minuteur de rafraîchissement (1x/s), toast à la fin du chantier.
- `sw.js` — nom de cache incrémenté (`nebustion-v41-qg-chantiers`) pour forcer la mise à jour du Service Worker.

**Aucun nouveau fichier de script** (le catalogue et la mécanique vivent dans les fichiers `QGGrid`/`QGGridManager`
existants) — seul un fichier de test a été ajouté.

## Tests

```
node tests/qgGridConstruction.test.js   # nouveau : 56 vérifications (chantier, tick, annulation, plafonds, sauvegarde)
node tests/qgGrid.test.js               # 39 vérifications, inchangé (bâtiments d'origine toujours instantanés)
node tests/module20.test.js             # 83 vérifications — 2 assertions mises à jour (12 → 16 structures/couleurs)
node tests/economy.test.js              # 1 923 vérifications, inchangé
```

**Non testé ici** (limite de l'environnement, comme pour les étapes précédentes) : le rendu réel dans Phaser/WebGL
(barre de progression, tween de scintillement, panneau « en construction ») — la logique de données et de sauvegarde
est testée à 100 % sous Node, mais l'affichage sur téléphone est à valider par vous.

## Pistes pour la suite (non faites ici, hors budget de cette étape)

- Bouton « accélérer le chantier » (gemmes) — les autres systèmes temporisés du jeu (Expéditions) ont ce genre
  d'option ; pas encore branché ici.
- Notification hors-scène (toast sur `PlanetScene`) quand un chantier se termine pendant que le joueur est ailleurs.
