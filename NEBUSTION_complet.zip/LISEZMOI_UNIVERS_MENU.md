# NEBUSTION - Les autres galaxies visibles depuis le menu

- Modifiés : js/scenes/MainMenuScene.js, js/scenes/UniverseScene.js, js/scenes/GalaxyScene.js, sw.js (cache v33)
- Le raccourci « Galaxie » du menu principal (Nexus-01) n'ouvre plus directement la Voie Aube : il ouvre
  désormais l'écran UNIVERS, qui existait déjà mais n'était accessible que depuis l'intérieur de la Voie
  Aube (petit portail rouge en haut à droite de l'écran Galaxie).
- L'écran UNIVERS affiche les 4 galaxies (Voie Aube jouable, Nébuleuse Écarlate à débloquer, Amas Glacial
  et Confins de Kaelis « bientôt disponible ») : toutes visibles, avec leur thème et leur état (jouable /
  verrouillée / aperçu). Le bouton « ENTRER SUR LA VOIE AUBE » fait entrer dans notre propre galaxie
  (GalaxyScene) — c'est donc bien cet écran qui s'affiche avant d'entrer dans notre galaxie.
- Le bouton retour de l'écran UNIVERS revient maintenant à l'écran d'où on est venu (menu principal ou
  Galaxie), au lieu de toujours revenir sur la Galaxie.
- La barre de navigation basse (onglet « Galaxie », présente sur tous les écrans) continue d'aller
  directement dans notre galaxie pour un accès rapide ; le portail vers l'Univers depuis l'intérieur de
  la Galaxie reste disponible aussi.
- Logique de jeu, sauvegardes et contenu des galaxies inchangés (le contenu jouable des galaxies autres
  que la Voie Aube arrive galaxie par galaxie, comme prévu).
