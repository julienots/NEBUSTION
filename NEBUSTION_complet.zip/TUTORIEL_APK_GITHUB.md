# NEBUSTION — Construire et installer l'APK Android via GitHub

Ce jeu est une page web statique (Phaser 3 + JS, PWA). Ce document explique comment le transformer
automatiquement en fichier **.apk** installable sur un téléphone Android, grâce à **Capacitor** et à
un **workflow GitHub Actions** déjà fourni dans le dépôt : `.github/workflows/build-apk.yml`.

⚠️ **Non testé de bout en bout ici** (mon environnement de travail n'a pas d'accès réseau, donc pas
moyen de lancer un vrai `npm install` ni un vrai build Gradle). Le script `tools/build-www.js` a été
testé localement et copie bien les bons fichiers. Le reste (workflow complet) est à valider une fois
poussé sur ton propre dépôt GitHub, qui lui a accès à internet.

## Fichiers concernés (déjà présents dans le projet)
- `package.json` — dépendances Capacitor
- `capacitor.config.json` — nom de l'app, identifiant Android, dossier web
- `tools/build-www.js` — copie les fichiers utiles du jeu dans `www/` (ignoré par Git)
- `.github/workflows/build-apk.yml` — le workflow qui construit l'APK
- `.gitignore` — évite de versionner `node_modules/`, `www/`, `android/`, les `.apk`

## Étape 1 — Mettre le projet sur GitHub
1. Crée un compte GitHub si besoin (gratuit) : https://github.com
2. Crée un nouveau dépôt (bouton **New repository**), par exemple `nebustion`.
3. Envoie le contenu dans le dépôt. Deux façons :

   **A. Le plus simple : uploader juste 2 éléments, sans décompresser le jeu toi-même**
   GitHub doit voir le fichier du workflow en clair pour savoir qu'il existe (il ne peut pas
   le découvrir à l'intérieur d'un zip) — mais tout le reste du jeu peut rester zippé, le
   workflow le décompresse lui-même au tout début du build (étape « Décompresser automatiquement
   le ZIP du jeu »). Sur la page du dépôt vide → **uploading an existing file** → glisse :
   - le dossier **`.github`** (contient `.github/workflows/build-apk.yml`)
   - le fichier **`NEBUSTION_complet.zip`** tel quel (pas besoin de l'extraire sur ton PC)

   → **Commit changes**. Rien d'autre à faire : dès cet envoi, le workflow se lance, dézippe le
   reste du projet (package.json, capacitor.config.json, index.html, js/...) tout seul, construit,
   et publie l'APK.

   **B. Sans ligne de commande, fichiers déjà décompressés** : glisse-dépose tous les
   fichiers/dossiers déjà extraits (au lieu du `.zip`) de la même façon.

   **C. Avec Git** (si installé) :
     ```bash
     cd nebustion
     git init
     git add .
     git commit -m "NEBUSTION"
     git branch -M main
     git remote add origin https://github.com/TON-COMPTE/nebustion.git
     git push -u origin main
     ```

## Étape 2 — Lancer la construction de l'APK
Le workflow se déclenche automatiquement au premier envoi sur `main` (celui de l'étape 1 suffit déjà).
Pour le relancer plus tard sans rien changer au code :
1. Va dans l'onglet **Actions** du dépôt GitHub.
2. Clique sur **Build Android APK** dans la liste à gauche.
3. Clique sur **Run workflow** (bouton en haut à droite) → **Run workflow**.
4. Attends la fin du run (rond vert ✔). La toute première fois, compte **5 à 10 minutes**
   (téléchargement de Gradle et des outils Android) ; les suivantes sont plus rapides.

## Étape 3 — Télécharger l'APK
Une fois le run terminé (coche verte) :
1. Ouvre ce run (clique dessus).
2. Tout en bas de la page, section **Artifacts** : télécharge **nebustion-apk** (fichier `.zip`
   contenant `app-debug.apk`).
3. Dézippe-le sur ton PC ou directement sur ton téléphone.

**Téléchargement direct sans dézipper** : à chaque envoi sur `main`, le workflow publie/actualise
automatiquement une Release nommée **latest-apk** (onglet **Releases** du dépôt) avec `app-debug.apk`
en pièce jointe — clique dessus, c'est l'APK brut, aucun `.zip` à extraire. C'est le lien à partager
ou à ouvrir directement depuis le téléphone. L'onglet **Artifacts** (étape 3 ci-dessus) reste
disponible mais lui est toujours zippé par GitHub (limitation de GitHub Actions, pas du workflow).

**Alternative avec une Release versionnée (fichier directement en `.apk`, sans zip)** :
crée un tag de version et pousse-le :
```bash
git tag v1.0.0
git push origin v1.0.0
```
Le workflow tourne à nouveau et publie automatiquement une **Release** GitHub avec `app-debug.apk`
joint (onglet **Releases** du dépôt) — pratique pour partager un lien de téléchargement direct.

## Étape 4 — Installer l'APK sur le téléphone Android
1. Transfère le fichier `app-debug.apk` sur le téléphone (câble USB, e-mail, Google Drive, lien de
   la Release ouvert directement dans le navigateur du téléphone…).
2. Ouvre le fichier depuis l'app **Fichiers** (ou la notification de téléchargement).
3. Android demande d'autoriser l'installation d'apps depuis cette source : accepte
   (**Paramètres → Applications → Installer des apps inconnues**, à activer pour l'app utilisée
   pour ouvrir le fichier, ex. le navigateur ou le gestionnaire de fichiers).
4. Appuie sur **Installer**. Le jeu apparaît ensuite avec son icône dans le tiroir d'applications.

## À savoir
- L'APK produit est un **build « debug »** : il s'installe et fonctionne très bien sur un téléphone,
  mais il n'est **pas signé pour le Play Store**. Pour publier sur le Play Store, il faudrait générer
  une release signée (clé de signature Android, `./gradlew assembleRelease` + configuration de
  signature) — étape plus avancée, non nécessaire pour un usage personnel ou pour le partager
  directement en `.apk`.
- Le jeu fonctionne **hors ligne** une fois installé (les fichiers sont embarqués dans l'app par
  `tools/build-www.js` + Capacitor) ; seule la sauvegarde en ligne (Compte, voir
  `LISEZMOI_COMPTE_CLOUDSAVE.md`) nécessite une connexion internet.
- L'icône de l'app utilise pour l'instant l'icône par défaut de Capacitor. Pour utiliser
  `icons/icon-512.png` comme icône réelle de l'app Android, l'outil `@capacitor/assets` peut générer
  automatiquement toutes les tailles (`npx @capacitor/assets generate --android`) — facultatif,
  purement cosmétique.
- Pour construire en local plutôt que sur GitHub (si Android Studio est installé) :
  `npm install`, puis `npm run android:sync`, puis `npm run android:open` ouvre le projet dans
  Android Studio pour lancer/débugger directement.

## En cas de problème
- **Le workflow échoue à `gradlew assembleDebug`** : regarde le détail du log dans Actions ; le plus
  souvent une histoire de version Java (le workflow installe le JDK 17, requis par les outils Android
  récents) ou un souci réseau temporaire côté GitHub — relance le workflow (**Re-run jobs**).
- **« Artifacts » vide** : le build a probablement échoué avant l'étape de publication ; regarde les
  logs de l'étape précédente.
- **L'app plante ou reste sur un écran noir** : vérifie d'abord que le jeu tourne bien dans un
  navigateur normal (`python3 -m http.server 8080` puis `http://localhost:8080`) avant de blâmer
  l'APK — si ça bloque déjà dans le navigateur, ce n'est pas lié à Capacitor.
