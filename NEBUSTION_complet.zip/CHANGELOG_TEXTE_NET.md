# v3.3.6 — Texte net, sans pixels

Cause : `antialias:false` dans js/main.js => Phaser utilisait le filtre NEAREST (gros pixels) quand le jeu 720x1280
est agrandi sur l'écran, et les textes étaient créés en résolution 1.

Correctifs (js/main.js uniquement) :
- `antialias:true` (filtre LINEAR) ; `antialiasGL:false` pour ne pas perdre de FPS.
- Tous les `add.text(...)` / `make.text(...)` sont automatiquement rendus en résolution 2 ou 3 selon l'écran
  (NEBUSTION.TEXT_RESOLUTION).
- sw.js : cache renommé pour forcer la mise à jour.
