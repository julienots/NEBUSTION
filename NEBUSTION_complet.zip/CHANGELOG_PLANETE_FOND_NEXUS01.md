# NEBUSTION — Une vraie planète en fond sur Nexus-01 (PlanetScene)

## Le problème visé
Sur l'écran de base (PlanetScene, « Touchez un gisement pour récolter »), les bâtiments étaient
posés sur une simple grille technologique flottant dans le vide (une ellipse plate + lignes
cyan), sans aucune planète visible dessous. Ça faisait flotter la base dans l'espace au lieu de
donner l'impression d'être posée sur un monde — le même souci que sur l'écran Galaxie, réglé la
fois précédente.

## Ce qui change
- Un grand disque incurvé (« corps de planète ») est maintenant dessiné en fond, centré sous la
  plateforme : dégradé sombre (plus clair en haut, plus sombre en bas, lumière venant d'en haut
  puisqu'on regarde la base en plongée), quelques reliefs/cratères discrets, halo lumineux
  « atmosphère » tout autour du bord visible.
- La plateforme high-tech existante (grille cyan) reste identique, mais se lit maintenant comme
  une zone bâtie posée SUR cette planète, au lieu d'être seule dans le vide.
- Entièrement en formes vectorielles + halos déjà utilisés ailleurs dans le jeu
  (`tex_glow_white`, `tex_glow_cyan`) : aucune nouvelle image chargée, aucun risque de flou en
  grand format.
- Aucun bâtiment, aucune position, aucune logique de jeu déplacés ou modifiés : uniquement du
  décor, ajouté derrière (profondeur -17 à -12, donc toujours derrière la plateforme à -10 et les
  bâtiments).

## Fichier modifié
- `js/scenes/PlanetScene.js` — méthode `_buildPlatform()` uniquement.

## Non testé
Pas d'exécution réelle dans un navigateur ici (pas d'accès réseau) : la syntaxe a été vérifiée
(`node --check`), les textures utilisées (`tex_glow_white`, `tex_glow_cyan`) sont bien générées
avant cette scène (PreloadScene). Le rendu réel (proportions, lisibilité de la grille par-dessus
la planète) est à vérifier en jeu — à ajuster facilement si le disque est trop grand/petit ou
trop clair/sombre (variables `pW`, `pH` et les deux couleurs du dégradé en tête de fonction).
