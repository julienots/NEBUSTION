# NEBUSTION — Nouvelle Galaxie : système solaire

## Accès
Écran Univers → nouvelle galaxie dorée/turquoise « Nouvelle Galaxie » (en bas à gauche) → zoom → système solaire.
Bouton ← en haut à gauche pour revenir à l'Univers.

## Contenu
**Les planètes sont maintenant cliquables** : touche-en une pour l'explorer en 3D (voir `CHANGELOG_TOUR_RELAIS_ET_PLANETES_3D.md`, scène `ExoPlanetScene`).
- Soleil animé (surface, couronne qui tourne, halo qui pulse).
- 6 planètes sur leurs orbites inclinées : Pyros (lave), Aqualis (océans + lune), Rubéa (désert), Goliath (géante gazeuse),
  Saturnia (anneaux), Glacia (glace). Passent devant/derrière le soleil, ombre tournée à l'opposé du soleil.
- Ceinture d'astéroïdes qui tourne. Noms sous les planètes.

## Fichiers
- Nouveaux : `js/scenes/SolarSystemScene.js`, `js/utils/SolarSystemTextures.js` (textures générées par code, aucune image).
- Modifiés : `js/scenes/UniverseScene.js` (nœud `_buildNewGalaxyNode`), `js/main.js`, `index.html`, `sw.js` (cache v54).

## Planètes cliquables
`SolarSystemScene._buildPlanet` crée une zone de toucher par planète → `_openPlanet` → `ExoPlanetScene` (fiches dans `NEBUSTION.ExoPlanets`).
Réglages : `_planetDefs()` (taille, orbite, période), `_ROT` / `_RATIO` (inclinaison de la vue).

## Non testé sur téléphone
Vérifié sous Node avec un canvas simulé : aucune erreur, planètes toujours dans l'écran. Rendu à valider en jeu.
