/**
 * NEBUSTION - SkinFX
 * Rendu des skins (module Personnalisation, étape 6/10) : teinte, aura, effets animés, et dessins
 * procéduraux de vaisseaux / bâtiments pour l'aperçu. Réutilisé par HeroesScene, CombatScene,
 * ShipsScene, PlanetScene et SkinsScene : une seule implémentation, aucun doublon.
 *
 * Textures réutilisées (déjà générées par le jeu) : tex_glow_white, tex_ring_soft, tex_spark.
 * Chaque effet renvoie une « poignée » { back, front, destroy() } ; destroy() arrête les tweens créés.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.SkinFX = (function () {
  'use strict';

  var INTENSITY = [0, 0.30, 0.42, 0.56, 0.72];   // selon l'ordre de rareté (1..4)
  var TAU = Math.PI * 2;

  // ---------- Petits utilitaires ----------
  function mix(c1, c2, t) {
    var r1 = (c1 >> 16) & 255, g1 = (c1 >> 8) & 255, b1 = c1 & 255, r2 = (c2 >> 16) & 255, g2 = (c2 >> 8) & 255, b2 = c2 & 255;
    return (Math.round(r1 + (r2 - r1) * t) << 16) | (Math.round(g1 + (g2 - g1) * t) << 8) | Math.round(b1 + (b2 - b1) * t);
  }
  function hue(h) {   // teinte 0..1 → couleur vive pastel (prisme)
    var r = Math.sin(h * TAU) * 0.5 + 0.5, g = Math.sin(h * TAU + 2.094) * 0.5 + 0.5, b = Math.sin(h * TAU + 4.188) * 0.5 + 0.5;
    return (Math.round(120 + r * 135) << 16) | (Math.round(120 + g * 135) << 8) | Math.round(120 + b * 135);
  }
  function isLite(opts) {
    if (opts && opts.light) return true;
    try { var st = NEBUSTION.Settings && NEBUSTION.Settings.get && NEBUSTION.Settings.get(); return !!(st && (st.batterySaver || st.reducedFX)); } catch (e) { return false; }
  }
  /** Anneau runique en tirets (cercle de rayon r, `dashes` arcs), centré sur (0,0). */
  function dashRing(scene, r, color, dashes, width, alpha, ratio) {
    var g = scene.add.graphics().setBlendMode(Phaser.BlendModes.ADD), step = TAU / dashes, i;
    g.lineStyle(width, color, alpha);
    for (i = 0; i < dashes; i++) { g.beginPath(); g.arc(0, 0, r, i * step, i * step + step * (ratio || 0.55), false); g.strokePath(); }
    return g;
  }
  /** Éclair zigzaguant de (x0,y0) à (x1,y1). */
  function bolt(g, x0, y0, x1, y1, c1, c2, segs) {
    var dx = x1 - x0, dy = y1 - y0, len = Math.sqrt(dx * dx + dy * dy) || 1, nx = -dy / len, ny = dx / len, pts = [[x0, y0]], i;
    for (i = 1; i < segs; i++) {
      var t = i / segs, j = (Math.random() - 0.5) * len * 0.28;
      pts.push([x0 + dx * t + nx * j, y0 + dy * t + ny * j]);
    }
    pts.push([x1, y1]);
    [[6, c1, 0.30], [2.2, c2, 0.95]].forEach(function (L) {
      g.lineStyle(L[0], L[1], L[2]); g.beginPath(); g.moveTo(pts[0][0], pts[0][1]);
      for (var k = 1; k < pts.length; k++) g.lineTo(pts[k][0], pts[k][1]);
      g.strokePath();
    });
  }
  /** Plume de lumière (triangle effilé) : base en (0,0), pointe à (len, angle). */
  function feather(g, len, ang, wid, c1, c2) {
    var tx = Math.cos(ang) * len, ty = Math.sin(ang) * len, px = -Math.sin(ang) * wid, py = Math.cos(ang) * wid;
    g.fillStyle(c1, 0.5); g.fillTriangle(px, py, -px, -py, tx, ty);
    g.fillStyle(c2, 0.85); g.fillTriangle(px * 0.45, py * 0.45, -px * 0.45, -py * 0.45, tx * 0.94, ty * 0.94);
  }

  /**
   * Construit l'aura + l'effet d'un skin, centrés en (opts.x, opts.y) de son conteneur.
   * opts.light : version économe (combat, listes) — moins de particules, pas d'animation d'aura.
   * Le décor s'enrichit avec la rareté : anneau runique (Rare+), rayons de lumière (Épique+), double anneau et étoiles (Légendaire).
   */
  function build(scene, skin, w, h, opts) {
    opts = opts || {};
    var ADD = Phaser.BlendModes.ADD, lite = isLite(opts);
    var R = NEBUSTION.Skins.RARITIES[skin.rarity] || { order: 1 };
    var inten = INTENSITY[R.order] || INTENSITY[1];
    var a1 = skin.aura, a2 = (skin.aura2 !== undefined && skin.aura2 !== null) ? skin.aura2 : mix(skin.aura, 0xffffff, 0.55);
    var back = scene.add.container(opts.x || 0, opts.y || 0);
    var front = scene.add.container(opts.x || 0, opts.y || 0);
    var targets = [], tweens = [], timers = [];
    function tw(cfg) { var t = scene.tweens.add(cfg); tweens.push(t); return t; }
    var rx = w * 0.62, base = Math.max(w, h);

    // -- Aura principale + halo secondaire (Rare+) --
    var aura = scene.add.image(0, 0, 'tex_glow_white').setDisplaySize(w * 1.7, h * 1.45).setTint(a1).setBlendMode(ADD).setAlpha(inten);
    back.add(aura);
    if (!lite) {
      tw({ targets: aura, alpha: inten * 0.55, duration: 1100, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
      targets.push(aura);
    }
    if (R.order >= 2 && !lite) {
      var halo = scene.add.image(0, h * 0.02, 'tex_glow_white').setDisplaySize(w * 1.05, h * 0.95).setTint(a2).setBlendMode(ADD).setAlpha(0.22 + R.order * 0.04);
      back.add(halo);
      tw({ targets: halo, alpha: 0.08, scaleX: halo.scaleX * 1.12, scaleY: halo.scaleY * 1.12, duration: 1500, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    }

    // -- Rayons de lumière (Épique+) --
    if (R.order >= 3 && !lite) {
      var rays = scene.add.container(0, 0), nr = R.order >= 4 ? 8 : 6;
      for (var ri = 0; ri < nr; ri++) {
        var ray = scene.add.image(0, 0, 'tex_glow_white').setDisplaySize(base * 0.11, base * (R.order >= 4 ? 1.75 : 1.4))
          .setTint(ri % 2 ? a2 : a1).setBlendMode(ADD).setAlpha(R.order >= 4 ? 0.2 : 0.14).setRotation(ri * (Math.PI / nr));
        rays.add(ray);
      }
      var raysSq = scene.add.container(0, 0).setScale(1, 0.62); raysSq.add(rays); back.addAt(raysSq, 0);
      tw({ targets: rays, rotation: TAU, duration: R.order >= 4 ? 16000 : 22000, repeat: -1, ease: 'Linear' });
    }

    // -- Anneau runique (Rare+) ; deuxième anneau à contre-sens + losanges (Légendaire) --
    if (R.order >= 2 && skin.fx !== 'ring') {
      var sq = scene.add.container(0, h * 0.03).setScale(1, 0.34), rg = dashRing(scene, rx * 1.02, a1, R.order >= 4 ? 24 : 16, 2.5, 0.6);
      sq.add(rg); front.add(sq);
      if (!lite) tw({ targets: rg, rotation: TAU, duration: 14000, repeat: -1, ease: 'Linear' });
    }
    if (R.order >= 4 && !lite) {
      var sq2 = scene.add.container(0, h * 0.03).setScale(1, 0.34), rg2 = scene.add.container(0, 0);
      rg2.add(dashRing(scene, rx * 1.22, a2, 40, 1.6, 0.45, 0.35));
      [0, 1, 2, 3].forEach(function (k) {
        var d = scene.add.image(Math.cos(k * Math.PI / 2) * rx * 1.22, Math.sin(k * Math.PI / 2) * rx * 1.22, 'tex_spark').setTint(a2).setBlendMode(ADD).setScale(0.3);
        rg2.add(d);
      });
      sq2.add(rg2); front.add(sq2);
      tw({ targets: rg2, rotation: -TAU, duration: 20000, repeat: -1, ease: 'Linear' });
      for (var si = 0; si < 3; si++) {
        var star = scene.add.image((Math.random() - 0.5) * w * 1.1, (Math.random() - 0.5) * h * 0.9, 'tex_spark').setTint(0xffffff).setBlendMode(ADD).setScale(0.12).setAlpha(0);
        front.add(star);
        tw({ targets: star, alpha: 0.95, scale: 0.34, duration: 700, yoyo: true, repeat: -1, delay: si * 650 + Math.random() * 400, repeatDelay: 900, ease: 'Sine.easeInOut' });
      }
    }

    // -- Effet propre au skin --
    var fx = skin.fx, i;
    if (fx === 'pulse') {
      var ring = scene.add.image(0, 0, 'tex_ring_soft').setDisplaySize(w * 0.95, h * 0.95).setTint(a1).setBlendMode(ADD).setAlpha(0.75);
      front.add(ring);
      var s0 = ring.scaleX;
      tw({ targets: ring, scaleX: s0 * 1.55, scaleY: s0 * 1.55, alpha: 0, duration: 1500, repeat: -1, ease: 'Sine.easeOut' });
      if (!lite) {   // seconde onde décalée
        var ring2 = scene.add.image(0, 0, 'tex_ring_soft').setDisplaySize(w * 0.95, h * 0.95).setTint(a2).setBlendMode(ADD).setAlpha(0.5);
        front.add(ring2);
        tw({ targets: ring2, scaleX: s0 * 1.55, scaleY: s0 * 1.55, alpha: 0, duration: 1500, delay: 750, repeat: -1, ease: 'Sine.easeOut' });
      }
    } else if (fx === 'sparkle' || fx === 'flame') {
      var flame = fx === 'flame', n = lite ? 2 : 7;
      for (i = 0; i < n; i++) {
        var x = -w * 0.4 + (n > 1 ? i / (n - 1) : 0.5) * w * 0.8;
        var sp = scene.add.image(x, h * 0.42, 'tex_spark').setTint(i % 2 ? a2 : a1).setBlendMode(ADD)
          .setScale(flame ? 0.28 : 0.2).setAlpha(0.95);
        front.add(sp);
        tw({ targets: sp, y: -h * (flame ? 0.4 : 0.52), x: x + (i % 2 ? 10 : -10), alpha: 0, scale: flame ? 0.08 : 0.32, duration: flame ? 1000 : 1700,
          delay: i * (flame ? 150 : 260), repeat: -1, ease: 'Sine.easeOut' });
      }
    } else if (fx === 'orbit') {
      var tilt = scene.add.container(0, h * 0.05).setScale(1, 0.32), orb = scene.add.container(0, 0);
      [rx, -rx].forEach(function (px) {
        orb.add(scene.add.image(px, 0, 'tex_glow_white').setTint(a1).setBlendMode(ADD).setScale(0.55).setAlpha(0.7));
        orb.add(scene.add.image(px, 0, 'tex_spark').setTint(a2).setBlendMode(ADD).setScale(0.34));
      });
      tilt.add(orb); front.add(tilt);
      tw({ targets: orb, rotation: TAU, duration: 3200, repeat: -1, ease: 'Linear' });
    } else if (fx === 'ring') {
      var rsq = scene.add.container(0, h * 0.03).setScale(1, 0.36), ra = dashRing(scene, rx, a1, 14, 3, 0.85), rb = dashRing(scene, rx * 0.8, a2, 9, 2, 0.7, 0.45);
      rsq.add([ra, rb]); front.add(rsq);
      tw({ targets: ra, rotation: TAU, duration: 9000, repeat: -1, ease: 'Linear' });
      tw({ targets: rb, rotation: -TAU, duration: 6500, repeat: -1, ease: 'Linear' });
    } else if (fx === 'lightning') {
      var lg = scene.add.graphics().setBlendMode(ADD); front.add(lg);
      var strike = function () {
        lg.clear();
        var nb = lite ? 1 : 2 + Math.floor(Math.random() * 2);
        for (var b = 0; b < nb; b++) {
          var ang = Math.random() * TAU, ex = Math.cos(ang) * w * 0.7, ey = Math.sin(ang) * h * 0.55;
          bolt(lg, ex, ey, (Math.random() - 0.5) * w * 0.25, (Math.random() - 0.5) * h * 0.25, a1, a2, 6);
        }
        lg.setAlpha(1);
        tw({ targets: lg, alpha: 0, duration: 260, ease: 'Quad.easeIn' });
      };
      strike();
      timers.push(scene.time.addEvent({ delay: lite ? 900 : 520, loop: true, callback: strike }));
      var flash = scene.add.image(0, 0, 'tex_glow_white').setDisplaySize(w * 0.9, h * 0.8).setTint(a2).setBlendMode(ADD).setAlpha(0);
      front.add(flash);
      tw({ targets: flash, alpha: 0.35, duration: 90, yoyo: true, repeat: -1, repeatDelay: lite ? 800 : 420 });
    } else if (fx === 'vortex') {
      var nv = lite ? 6 : 12, vs = [], vsq = scene.add.container(0, h * 0.03).setScale(1, 0.4);
      for (i = 0; i < nv; i++) {
        var vsp = scene.add.image(0, 0, 'tex_spark').setTint(i % 2 ? a2 : a1).setBlendMode(ADD).setAlpha(0);
        vsq.add(vsp); vs.push(vsp);
      }
      front.add(vsq);
      var core = scene.add.image(0, 0, 'tex_glow_white').setDisplaySize(w * 0.5, h * 0.4).setTint(a1).setBlendMode(ADD).setAlpha(0.35);
      back.add(core);
      var vp = { p: 0 };
      tw({ targets: vp, p: 1, duration: 3000, repeat: -1, ease: 'Linear', onUpdate: function () {
        for (var k = 0; k < vs.length; k++) {
          var ph = (vp.p + k / vs.length) % 1, ang = ph * TAU * 2 + k, rad = rx * 1.05 * (1 - ph * 0.9);
          vs[k].setPosition(Math.cos(ang) * rad, Math.sin(ang) * rad).setAlpha(Math.sin(ph * Math.PI) * 0.95).setScale(0.14 + 0.24 * (1 - ph));
        }
      } });
    } else if (fx === 'prism') {
      var np = lite ? 4 : 8, psq = scene.add.container(0, h * 0.03).setScale(1, 0.4), porb = scene.add.container(0, 0);
      for (i = 0; i < np; i++) {
        var pa = i / np * TAU;
        porb.add(scene.add.image(Math.cos(pa) * rx, Math.sin(pa) * rx, 'tex_glow_white').setTint(hue(i / np)).setBlendMode(ADD).setScale(0.5).setAlpha(0.6));
        porb.add(scene.add.image(Math.cos(pa) * rx, Math.sin(pa) * rx, 'tex_spark').setTint(0xffffff).setBlendMode(ADD).setScale(0.26));
      }
      psq.add(porb); front.add(psq);
      tw({ targets: porb, rotation: TAU, duration: 5200, repeat: -1, ease: 'Linear' });
      if (!lite) {   // losange prismatique qui tourne derrière
        var dg = scene.add.graphics().setBlendMode(ADD);
        for (i = 0; i < 3; i++) {
          dg.lineStyle(2, hue(i / 3), 0.7);
          var dr = base * (0.3 + i * 0.07), rot = i * 0.5;
          dg.beginPath();
          for (var q = 0; q < 4; q++) { var qa = rot + q * Math.PI / 2; var px2 = Math.cos(qa) * dr * (q % 2 ? 0.62 : 1), py2 = Math.sin(qa) * dr * (q % 2 ? 1 : 0.62); if (q === 0) dg.moveTo(px2, py2); else dg.lineTo(px2, py2); }
          dg.closePath(); dg.strokePath();
        }
        back.add(dg);
        tw({ targets: dg, rotation: -TAU, duration: 12000, repeat: -1, ease: 'Linear' });
      }
    } else if (fx === 'wings') {
      var wingL = scene.add.container(-w * 0.16, -h * 0.04), wingR = scene.add.container(w * 0.16, -h * 0.04);
      var wg = scene.add.graphics().setBlendMode(ADD), wl = w * (lite ? 0.55 : 0.68), k2;
      for (k2 = 0; k2 < 6; k2++) feather(wg, wl * (0.55 + k2 * 0.09), -0.95 + k2 * 0.3, base * 0.05, a1, a2);
      wingR.add(wg);
      var wg2 = scene.add.graphics().setBlendMode(ADD);
      for (k2 = 0; k2 < 6; k2++) feather(wg2, wl * (0.55 + k2 * 0.09), -0.95 + k2 * 0.3, base * 0.05, a1, a2);
      wingL.add(wg2); wingL.setScale(-1, 1);
      back.addAt(wingL, 1); back.addAt(wingR, 1);
      if (!lite) {
        tw({ targets: wingR, rotation: 0.14, duration: 1400, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
        tw({ targets: wingL, rotation: -0.14, duration: 1400, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
        for (i = 0; i < 4; i++) {
          var fp = scene.add.image((Math.random() - 0.5) * w * 0.9, h * 0.1, 'tex_spark').setTint(a2).setBlendMode(ADD).setScale(0.16).setAlpha(0.9);
          front.add(fp);
          tw({ targets: fp, y: -h * 0.4, alpha: 0, duration: 2200, delay: i * 520, repeat: -1, ease: 'Sine.easeOut' });
        }
      }
    }

    return {
      back: back, front: front, targets: targets,
      destroy: function () {
        try { scene.tweens.killTweensOf(targets); } catch (e) { /* ignore */ }
        tweens.forEach(function (t) { try { t.stop(); if (t.remove) t.remove(); } catch (e) { /* ignore */ } });
        timers.forEach(function (t) { try { t.remove(false); } catch (e) { /* ignore */ } });
        back.destroy(); front.destroy();
      }
    };
  }

  /**
   * Applique un skin à un sprite déjà placé dans `container` : teinte + aura derrière + effets devant.
   * L'effet est centré sur le sprite, ou en (opts.x, opts.y) si fourni (ex. bâtiment sans sprite). Renvoie la poignée (ou null).
   */
  function attach(scene, container, sprite, skin, w, h, opts) {
    if (!skin || !container) return null;
    opts = opts || {};
    var cx = (opts.x !== undefined) ? opts.x : (sprite ? sprite.x : 0);
    var cy = (opts.y !== undefined) ? opts.y : (sprite ? sprite.y : 0);
    if (sprite && skin.tint !== null && skin.tint !== undefined && sprite.setTint) sprite.setTint(skin.tint);
    var fx = build(scene, skin, w, h, { x: cx, y: cy, light: opts.light });
    var idx = 0;
    if (sprite && container.getIndex) idx = Math.max(0, container.getIndex(sprite));
    container.addAt(fx.back, idx);   // l'aura passe derrière le sprite
    container.add(fx.front);
    fx.tint = (skin.tint === undefined) ? null : skin.tint;
    return fx;
  }

  // ---------- Dessins procéduraux (aperçu) ----------
  function engine(scene, c, x, y, S, color) {
    var ADD = Phaser.BlendModes.ADD;
    var halo = scene.add.image(x, y + S * 0.06, 'tex_glow_white').setDisplaySize(S * 0.42, S * 0.5).setTint(color).setBlendMode(ADD).setAlpha(0.65);
    var e = scene.add.ellipse(x, y, S * 0.16, S * 0.3, color, 0.9).setBlendMode(ADD);
    var core = scene.add.ellipse(x, y - S * 0.03, S * 0.07, S * 0.18, 0xffffff, 0.85).setBlendMode(ADD);
    c.add([halo, e, core]);
    scene.tweens.add({ targets: [e, core], scaleY: 1.5, alpha: 0.55, duration: 180 + Math.round(Math.abs(x)) % 90, yoyo: true, repeat: -1 });
    scene.tweens.add({ targets: halo, alpha: 0.35, duration: 260, yoyo: true, repeat: -1 });
    e.extra = [halo, core];
    return e;
  }

  /** Vaisseau de classe `classId` dessiné en vectoriel (pointe vers le haut), taille ≈ S px. */
  function drawShip(scene, classId, skin, S, defaultAccent) {
    var accent = skin ? skin.aura : (defaultAccent !== undefined ? defaultAccent : 0x4fd1ff);
    var hull = skin ? skin.hull : 0x2a3a5c;
    var c = scene.add.container(0, 0);
    var g = scene.add.graphics();
    c.add(g);
    var eng = [];

    function poly(color, a, pts) { g.fillStyle(color, a); g.fillTriangle(pts[0], pts[1], pts[2], pts[3], pts[4], pts[5]); }

    if (classId === 'intercepteur') {
      poly(hull, 1, [-S * 0.06, -S * 0.05, -S * 0.48, S * 0.42, -S * 0.1, S * 0.3]);
      poly(hull, 1, [S * 0.06, -S * 0.05, S * 0.48, S * 0.42, S * 0.1, S * 0.3]);
      poly(hull, 1, [0, -S * 0.5, -S * 0.16, S * 0.4, S * 0.16, S * 0.4]);
      poly(accent, 0.95, [0, -S * 0.36, -S * 0.05, S * 0.1, S * 0.05, S * 0.1]);
      poly(accent, 0.7, [-S * 0.3, S * 0.3, -S * 0.46, S * 0.42, -S * 0.2, S * 0.36]);
      poly(accent, 0.7, [S * 0.3, S * 0.3, S * 0.46, S * 0.42, S * 0.2, S * 0.36]);
      eng.push([0, S * 0.46]);
    } else if (classId === 'corvette') {
      g.fillStyle(hull, 1); g.fillRoundedRect(-S * 0.13, -S * 0.42, S * 0.26, S * 0.8, S * 0.1);
      poly(hull, 1, [-S * 0.13, S * 0.05, -S * 0.34, S * 0.38, -S * 0.13, S * 0.34]);
      poly(hull, 1, [S * 0.13, S * 0.05, S * 0.34, S * 0.38, S * 0.13, S * 0.34]);
      poly(accent, 0.95, [0, -S * 0.5, -S * 0.1, -S * 0.3, S * 0.1, -S * 0.3]);
      g.fillStyle(accent, 0.9); g.fillEllipse(0, -S * 0.08, S * 0.1, S * 0.2);
      eng.push([0, S * 0.44]);
    } else if (classId === 'cuirasse') {
      g.fillStyle(hull, 1); g.fillRoundedRect(-S * 0.3, -S * 0.38, S * 0.6, S * 0.78, S * 0.08);
      g.fillRoundedRect(-S * 0.46, -S * 0.15, S * 0.16, S * 0.5, S * 0.05);
      g.fillRoundedRect(S * 0.3, -S * 0.15, S * 0.16, S * 0.5, S * 0.05);
      poly(hull, 1, [0, -S * 0.52, -S * 0.3, -S * 0.36, S * 0.3, -S * 0.36]);
      g.fillStyle(accent, 0.95);
      g.fillRoundedRect(-S * 0.09, -S * 0.28, S * 0.18, S * 0.16, S * 0.03);
      g.fillRoundedRect(-S * 0.09, S * 0.02, S * 0.18, S * 0.16, S * 0.03);
      g.fillRoundedRect(-S * 0.44, -S * 0.02, S * 0.12, S * 0.05, 1);
      g.fillRoundedRect(S * 0.32, -S * 0.02, S * 0.12, S * 0.05, 1);
      eng.push([-S * 0.15, S * 0.44], [S * 0.15, S * 0.44]);
    } else {   // porte_vaisseaux
      g.fillStyle(hull, 1); g.fillRoundedRect(-S * 0.2, -S * 0.5, S * 0.4, S * 1.0, S * 0.08);
      g.fillRoundedRect(-S * 0.44, -S * 0.2, S * 0.26, S * 0.5, S * 0.06);
      g.fillRoundedRect(S * 0.18, -S * 0.2, S * 0.26, S * 0.5, S * 0.06);
      g.fillStyle(accent, 0.95);
      g.fillRoundedRect(-S * 0.1, -S * 0.38, S * 0.2, S * 0.14, S * 0.04);
      g.fillRoundedRect(-S * 0.38, -S * 0.1, S * 0.14, S * 0.08, 2);
      g.fillRoundedRect(S * 0.24, -S * 0.1, S * 0.14, S * 0.08, 2);
      g.fillRoundedRect(-S * 0.38, S * 0.08, S * 0.14, S * 0.08, 2);
      g.fillRoundedRect(S * 0.24, S * 0.08, S * 0.14, S * 0.08, 2);
      eng.push([-S * 0.1, S * 0.54], [S * 0.1, S * 0.54]);
    }
    g.lineStyle(1.5, accent, 0.55);
    g.strokeRoundedRect(-S * 0.2, -S * 0.36, S * 0.4, S * 0.72, S * 0.08);

    // --- Finitions : reflets de coque, nervure centrale, chevrons de livrée, verrière, feux de position ---
    var acc2 = (skin && skin.aura2 !== undefined && skin.aura2 !== null) ? skin.aura2 : mix(accent, 0xffffff, 0.55);
    var hi = mix(hull, 0xffffff, 0.38), lo = mix(hull, 0x000000, 0.5), o = scene.add.graphics();
    c.add(o);
    o.lineStyle(1.4, hi, 0.6); o.beginPath(); o.moveTo(0, -S * 0.46); o.lineTo(0, S * 0.36); o.strokePath();
    o.lineStyle(1, lo, 0.7);
    [-S * 0.12, S * 0.12].forEach(function (px) { o.beginPath(); o.moveTo(px, -S * 0.2); o.lineTo(px * 1.15, S * 0.34); o.strokePath(); });
    if (skin) {   // livrée du skin : chevrons lumineux aux couleurs secondaires
      o.lineStyle(2.4, acc2, 0.6);
      [0.02, 0.16].forEach(function (yy) {
        o.beginPath(); o.moveTo(-S * 0.17, S * (yy + 0.06)); o.lineTo(0, S * yy); o.lineTo(S * 0.17, S * (yy + 0.06)); o.strokePath();
      });
    }
    o.fillStyle(0xffffff, 0.24); o.fillEllipse(-S * 0.015, -S * 0.17, S * 0.07, S * 0.17);
    o.fillStyle(acc2, 0.9);
    var navs = [];
    [[-S * 0.44, S * 0.36], [S * 0.44, S * 0.36]].forEach(function (pp) {
      var n = scene.add.circle(pp[0], pp[1], Math.max(2, S * 0.018), acc2, 1).setBlendMode(Phaser.BlendModes.ADD);
      c.add(n); navs.push(n);
      scene.tweens.add({ targets: n, alpha: 0.15, duration: 600, yoyo: true, repeat: -1, delay: pp[0] > 0 ? 300 : 0 });
    });

    c.fxTargets = eng.map(function (p) { return engine(scene, c, p[0], p[1], S, accent); });
    c.fxTargets = c.fxTargets.concat(navs);
    c.fxTargets.slice().forEach(function (e) { if (e && e.extra) c.fxTargets = c.fxTargets.concat(e.extra); });
    return c;
  }

  var BUILDING_COLORS = { command: 0x00e5ff, hangar: 0xffd166, lab: 0x6c3ce9, defense: 0xff4d6d };

  /** Bâtiment stylisé (origine au centre bas), taille ≈ S px — sert d'aperçu (la planète garde ses propres dessins). */
  function drawBuilding(scene, buildingId, skin, S) {
    var accent = skin ? skin.aura : (BUILDING_COLORS[buildingId] || 0x00e5ff);
    var hull = skin ? skin.hull : 0x1c2c4d;
    var c = scene.add.container(0, 0);
    var g = scene.add.graphics();
    c.add(g);
    g.fillStyle(0x000000, 0.35); g.fillEllipse(0, S * 0.04, S * 0.9, S * 0.22);
    g.fillStyle(hull, 1); g.fillRoundedRect(-S * 0.4, -S * 0.62, S * 0.8, S * 0.62, S * 0.07);
    g.lineStyle(2, accent, 0.75); g.strokeRoundedRect(-S * 0.4, -S * 0.62, S * 0.8, S * 0.62, S * 0.07);
    if (buildingId === 'hangar') {
      g.fillStyle(0x05070f, 1); g.fillRoundedRect(-S * 0.26, -S * 0.42, S * 0.52, S * 0.42, S * 0.12);
      g.fillStyle(accent, 0.9); g.fillRoundedRect(-S * 0.26, -S * 0.5, S * 0.52, S * 0.06, 3);
    } else if (buildingId === 'lab') {
      g.fillStyle(accent, 0.35); g.fillEllipse(0, -S * 0.66, S * 0.62, S * 0.5);
      g.lineStyle(2, accent, 0.95); g.strokeEllipse(0, -S * 0.66, S * 0.62, S * 0.5);
    } else if (buildingId === 'defense') {
      g.fillStyle(hull, 1); g.fillRoundedRect(-S * 0.3, -S * 0.82, S * 0.16, S * 0.22, 3); g.fillRoundedRect(S * 0.14, -S * 0.82, S * 0.16, S * 0.22, 3);
      g.fillStyle(accent, 0.95); g.fillRoundedRect(-S * 0.27, -S * 0.98, S * 0.1, S * 0.18, 2); g.fillRoundedRect(S * 0.17, -S * 0.98, S * 0.1, S * 0.18, 2);
    } else {   // command
      g.fillStyle(hull, 1); g.fillRoundedRect(-S * 0.16, -S * 0.98, S * 0.32, S * 0.38, S * 0.05);
      g.fillStyle(accent, 0.9); g.fillEllipse(0, -S * 1.0, S * 0.42, S * 0.2);
    }
    g.fillStyle(accent, 0.9);
    for (var i = 0; i < 3; i++) g.fillRoundedRect(-S * 0.3 + i * S * 0.22, -S * 0.2, S * 0.1, S * 0.07, 2);

    // --- Finitions : ombrage latéral, reflet de toit, fenêtres éclairées, plinthe rayée, mât d'antenne, halo au sol ---
    var acc2 = (skin && skin.aura2 !== undefined && skin.aura2 !== null) ? skin.aura2 : mix(accent, 0xffffff, 0.55);
    g.fillStyle(0x000000, 0.22); g.fillRoundedRect(S * 0.16, -S * 0.62, S * 0.24, S * 0.62, S * 0.07);
    g.lineStyle(2, mix(hull, 0xffffff, 0.45), 0.7); g.beginPath(); g.moveTo(-S * 0.34, -S * 0.6); g.lineTo(S * 0.34, -S * 0.6); g.strokePath();
    for (var wr = 0; wr < 2; wr++) for (var wc = 0; wc < 5; wc++) {
      var lit = ((wr * 5 + wc) * 7 + (skin ? skin.hull % 5 : 2)) % 3 !== 0;
      g.fillStyle(lit ? acc2 : mix(hull, 0x000000, 0.4), lit ? 0.85 : 0.6);
      g.fillRect(-S * 0.34 + wc * S * 0.145, -S * 0.5 + wr * S * 0.14, S * 0.06, S * 0.07);
    }
    for (var hz = 0; hz < 8; hz++) { g.fillStyle(hz % 2 ? accent : 0x05070f, 0.7); g.fillRect(-S * 0.4 + hz * S * 0.1, -S * 0.045, S * 0.1, S * 0.045); }
    g.lineStyle(2, accent, 0.8); g.beginPath(); g.moveTo(0, -S * 1.02); g.lineTo(0, -S * 1.1); g.strokePath();
    var ground = scene.add.ellipse(0, S * 0.04, S * 1.0, S * 0.26, accent, 0).setStrokeStyle(2, accent, 0.7).setBlendMode(Phaser.BlendModes.ADD);
    c.add(ground); c.sendToBack(ground);
    scene.tweens.add({ targets: ground, alpha: 0.35, scaleX: 1.12, scaleY: 1.12, duration: 1300, yoyo: true, repeat: -1 });
    var beacon = scene.add.circle(0, -S * 1.1, 4, accent, 1).setBlendMode(Phaser.BlendModes.ADD);
    var bglow = scene.add.image(0, -S * 1.1, 'tex_glow_white').setDisplaySize(S * 0.3, S * 0.3).setTint(accent).setBlendMode(Phaser.BlendModes.ADD).setAlpha(0.6);
    c.add([bglow, beacon]);
    scene.tweens.add({ targets: [beacon, bglow], alpha: 0.2, duration: 700, yoyo: true, repeat: -1 });
    c.fxTargets = [beacon, bglow, ground];
    return c;
  }

  return { build: build, attach: attach, drawShip: drawShip, drawBuilding: drawBuilding, mix: mix, hue: hue };
})();
