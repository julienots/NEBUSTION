/**
 * NEBUSTION - SkinFX
 * Rendu des skins (module Personnalisation, étape 6/10) : teinte, aura, effets animés, et dessins
 * procéduraux de vaisseaux / bâtiments pour l'aperçu. Réutilisé par HeroesScene, CombatScene,
 * ShipsScene, PlanetScene et SkinsScene : une seule implémentation, aucun doublon.
 *
 * Textures réutilisées (déjà générées par le jeu) : tex_glow_white, tex_ring_soft, tex_spark.
 * Chaque effet renvoie une « poignée » { back, front, destroy() } ; destroy() arrête les tweens créés.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.SkinFX = (function () {
  'use strict';

  var INTENSITY = [0, 0.30, 0.42, 0.56, 0.72];   // selon l'ordre de rareté (1..4)

  /**
   * Construit l'aura + l'effet d'un skin, centrés en (opts.x, opts.y) de son conteneur.
   * opts.light : version économe (combat, listes) — moins de particules, pas d'animation d'aura.
   */
  function build(scene, skin, w, h, opts) {
    opts = opts || {};
    var ADD = Phaser.BlendModes.ADD;
    var R = NEBUSTION.Skins.RARITIES[skin.rarity] || { order: 1 };
    var inten = INTENSITY[R.order] || INTENSITY[1];
    var back = scene.add.container(opts.x || 0, opts.y || 0);
    var front = scene.add.container(opts.x || 0, opts.y || 0);
    var targets = [];

    var aura = scene.add.image(0, 0, 'tex_glow_white').setDisplaySize(w * 1.7, h * 1.45)
      .setTint(skin.aura).setBlendMode(ADD).setAlpha(inten);
    back.add(aura);
    if (!opts.light) {
      scene.tweens.add({ targets: aura, alpha: inten * 0.55, duration: 1100, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
      targets.push(aura);
    }

    var fx = skin.fx;
    if (fx === 'pulse') {
      var ring = scene.add.image(0, 0, 'tex_ring_soft').setDisplaySize(w * 0.95, h * 0.95)
        .setTint(skin.aura).setBlendMode(ADD).setAlpha(0.75);
      front.add(ring);
      var s0 = ring.scaleX;
      scene.tweens.add({ targets: ring, scaleX: s0 * 1.55, scaleY: s0 * 1.55, alpha: 0, duration: 1500, repeat: -1, ease: 'Sine.easeOut' });
      targets.push(ring);
    } else if (fx === 'sparkle' || fx === 'flame') {
      var flame = fx === 'flame';
      var n = opts.light ? 2 : 5;
      for (var i = 0; i < n; i++) {
        var x = -w * 0.38 + (n > 1 ? i / (n - 1) : 0.5) * w * 0.76;
        var sp = scene.add.image(x, h * 0.42, 'tex_spark').setTint(skin.aura).setBlendMode(ADD)
          .setScale(flame ? 0.26 : 0.2).setAlpha(0.95);
        front.add(sp);
        scene.tweens.add({
          targets: sp, y: -h * (flame ? 0.38 : 0.5), alpha: 0, duration: flame ? 1000 : 1700,
          delay: i * (flame ? 190 : 330), repeat: -1, ease: 'Sine.easeOut'
        });
        targets.push(sp);
      }
    } else if (fx === 'orbit') {
      var tilt = scene.add.container(0, h * 0.05).setScale(1, 0.32);   // écrase l'orbite en ellipse
      var orb = scene.add.container(0, 0);
      var rx = w * 0.62;
      [rx, -rx].forEach(function (px) {
        orb.add(scene.add.image(px, 0, 'tex_spark').setTint(skin.aura).setBlendMode(ADD).setScale(0.32));
      });
      tilt.add(orb); front.add(tilt);
      scene.tweens.add({ targets: orb, rotation: Math.PI * 2, duration: 3200, repeat: -1, ease: 'Linear' });
      targets.push(orb);
    }

    return {
      back: back, front: front, targets: targets,
      destroy: function () {
        try { scene.tweens.killTweensOf(targets); } catch (e) { /* ignore */ }
        back.destroy(); front.destroy();
      }
    };
  }

  /**
   * Applique un skin à un sprite déjà placé dans `container` : teinte + aura derrière + effets devant.
   * L'effet est centré sur le sprite, ou en (opts.x, opts.y) si fourni (ex. bâtiment sans sprite). Renvoie la poignée (ou null).
   */
  function attach(scene, container, sprite, skin, w, h, opts) {
    if (!skin || !container) return null;
    opts = opts || {};
    var cx = (opts.x !== undefined) ? opts.x : (sprite ? sprite.x : 0);
    var cy = (opts.y !== undefined) ? opts.y : (sprite ? sprite.y : 0);
    if (sprite && skin.tint !== null && skin.tint !== undefined && sprite.setTint) sprite.setTint(skin.tint);
    var fx = build(scene, skin, w, h, { x: cx, y: cy, light: opts.light });
    var idx = 0;
    if (sprite && container.getIndex) idx = Math.max(0, container.getIndex(sprite));
    container.addAt(fx.back, idx);   // l'aura passe derrière le sprite
    container.add(fx.front);
    fx.tint = (skin.tint === undefined) ? null : skin.tint;
    return fx;
  }

  // ---------- Dessins procéduraux (aperçu) ----------
  function engine(scene, c, x, y, S, color) {
    var e = scene.add.ellipse(x, y, S * 0.16, S * 0.3, color, 0.9).setBlendMode(Phaser.BlendModes.ADD);
    c.add(e);
    scene.tweens.add({ targets: e, scaleY: 1.5, alpha: 0.55, duration: 180 + Math.round(Math.abs(x)) % 90, yoyo: true, repeat: -1 });
    return e;
  }

  /** Vaisseau de classe `classId` dessiné en vectoriel (pointe vers le haut), taille ≈ S px. */
  function drawShip(scene, classId, skin, S, defaultAccent) {
    var accent = skin ? skin.aura : (defaultAccent !== undefined ? defaultAccent : 0x4fd1ff);
    var hull = skin ? skin.hull : 0x2a3a5c;
    var c = scene.add.container(0, 0);
    var g = scene.add.graphics();
    c.add(g);
    var eng = [];

    function poly(color, a, pts) { g.fillStyle(color, a); g.fillTriangle(pts[0], pts[1], pts[2], pts[3], pts[4], pts[5]); }

    if (classId === 'intercepteur') {
      poly(hull, 1, [-S * 0.06, -S * 0.05, -S * 0.48, S * 0.42, -S * 0.1, S * 0.3]);
      poly(hull, 1, [S * 0.06, -S * 0.05, S * 0.48, S * 0.42, S * 0.1, S * 0.3]);
      poly(hull, 1, [0, -S * 0.5, -S * 0.16, S * 0.4, S * 0.16, S * 0.4]);
      poly(accent, 0.95, [0, -S * 0.36, -S * 0.05, S * 0.1, S * 0.05, S * 0.1]);
      poly(accent, 0.7, [-S * 0.3, S * 0.3, -S * 0.46, S * 0.42, -S * 0.2, S * 0.36]);
      poly(accent, 0.7, [S * 0.3, S * 0.3, S * 0.46, S * 0.42, S * 0.2, S * 0.36]);
      eng.push([0, S * 0.46]);
    } else if (classId === 'corvette') {
      g.fillStyle(hull, 1); g.fillRoundedRect(-S * 0.13, -S * 0.42, S * 0.26, S * 0.8, S * 0.1);
      poly(hull, 1, [-S * 0.13, S * 0.05, -S * 0.34, S * 0.38, -S * 0.13, S * 0.34]);
      poly(hull, 1, [S * 0.13, S * 0.05, S * 0.34, S * 0.38, S * 0.13, S * 0.34]);
      poly(accent, 0.95, [0, -S * 0.5, -S * 0.1, -S * 0.3, S * 0.1, -S * 0.3]);
      g.fillStyle(accent, 0.9); g.fillEllipse(0, -S * 0.08, S * 0.1, S * 0.2);
      eng.push([0, S * 0.44]);
    } else if (classId === 'cuirasse') {
      g.fillStyle(hull, 1); g.fillRoundedRect(-S * 0.3, -S * 0.38, S * 0.6, S * 0.78, S * 0.08);
      g.fillRoundedRect(-S * 0.46, -S * 0.15, S * 0.16, S * 0.5, S * 0.05);
      g.fillRoundedRect(S * 0.3, -S * 0.15, S * 0.16, S * 0.5, S * 0.05);
      poly(hull, 1, [0, -S * 0.52, -S * 0.3, -S * 0.36, S * 0.3, -S * 0.36]);
      g.fillStyle(accent, 0.95);
      g.fillRoundedRect(-S * 0.09, -S * 0.28, S * 0.18, S * 0.16, S * 0.03);
      g.fillRoundedRect(-S * 0.09, S * 0.02, S * 0.18, S * 0.16, S * 0.03);
      g.fillRoundedRect(-S * 0.44, -S * 0.02, S * 0.12, S * 0.05, 1);
      g.fillRoundedRect(S * 0.32, -S * 0.02, S * 0.12, S * 0.05, 1);
      eng.push([-S * 0.15, S * 0.44], [S * 0.15, S * 0.44]);
    } else {   // porte_vaisseaux
      g.fillStyle(hull, 1); g.fillRoundedRect(-S * 0.2, -S * 0.5, S * 0.4, S * 1.0, S * 0.08);
      g.fillRoundedRect(-S * 0.44, -S * 0.2, S * 0.26, S * 0.5, S * 0.06);
      g.fillRoundedRect(S * 0.18, -S * 0.2, S * 0.26, S * 0.5, S * 0.06);
      g.fillStyle(accent, 0.95);
      g.fillRoundedRect(-S * 0.1, -S * 0.38, S * 0.2, S * 0.14, S * 0.04);
      g.fillRoundedRect(-S * 0.38, -S * 0.1, S * 0.14, S * 0.08, 2);
      g.fillRoundedRect(S * 0.24, -S * 0.1, S * 0.14, S * 0.08, 2);
      g.fillRoundedRect(-S * 0.38, S * 0.08, S * 0.14, S * 0.08, 2);
      g.fillRoundedRect(S * 0.24, S * 0.08, S * 0.14, S * 0.08, 2);
      eng.push([-S * 0.1, S * 0.54], [S * 0.1, S * 0.54]);
    }
    g.lineStyle(1.5, accent, 0.55);
    g.strokeRoundedRect(-S * 0.2, -S * 0.36, S * 0.4, S * 0.72, S * 0.08);
    c.fxTargets = eng.map(function (p) { return engine(scene, c, p[0], p[1], S, accent); });
    return c;
  }

  var BUILDING_COLORS = { command: 0x00e5ff, hangar: 0xffd166, lab: 0x6c3ce9, defense: 0xff4d6d };

  /** Bâtiment stylisé (origine au centre bas), taille ≈ S px — sert d'aperçu (la planète garde ses propres dessins). */
  function drawBuilding(scene, buildingId, skin, S) {
    var accent = skin ? skin.aura : (BUILDING_COLORS[buildingId] || 0x00e5ff);
    var hull = skin ? skin.hull : 0x1c2c4d;
    var c = scene.add.container(0, 0);
    var g = scene.add.graphics();
    c.add(g);
    g.fillStyle(0x000000, 0.35); g.fillEllipse(0, S * 0.04, S * 0.9, S * 0.22);
    g.fillStyle(hull, 1); g.fillRoundedRect(-S * 0.4, -S * 0.62, S * 0.8, S * 0.62, S * 0.07);
    g.lineStyle(2, accent, 0.75); g.strokeRoundedRect(-S * 0.4, -S * 0.62, S * 0.8, S * 0.62, S * 0.07);
    if (buildingId === 'hangar') {
      g.fillStyle(0x05070f, 1); g.fillRoundedRect(-S * 0.26, -S * 0.42, S * 0.52, S * 0.42, S * 0.12);
      g.fillStyle(accent, 0.9); g.fillRoundedRect(-S * 0.26, -S * 0.5, S * 0.52, S * 0.06, 3);
    } else if (buildingId === 'lab') {
      g.fillStyle(accent, 0.35); g.fillEllipse(0, -S * 0.66, S * 0.62, S * 0.5);
      g.lineStyle(2, accent, 0.95); g.strokeEllipse(0, -S * 0.66, S * 0.62, S * 0.5);
    } else if (buildingId === 'defense') {
      g.fillStyle(hull, 1); g.fillRoundedRect(-S * 0.3, -S * 0.82, S * 0.16, S * 0.22, 3); g.fillRoundedRect(S * 0.14, -S * 0.82, S * 0.16, S * 0.22, 3);
      g.fillStyle(accent, 0.95); g.fillRoundedRect(-S * 0.27, -S * 0.98, S * 0.1, S * 0.18, 2); g.fillRoundedRect(S * 0.17, -S * 0.98, S * 0.1, S * 0.18, 2);
    } else {   // command
      g.fillStyle(hull, 1); g.fillRoundedRect(-S * 0.16, -S * 0.98, S * 0.32, S * 0.38, S * 0.05);
      g.fillStyle(accent, 0.9); g.fillEllipse(0, -S * 1.0, S * 0.42, S * 0.2);
    }
    g.fillStyle(accent, 0.9);
    for (var i = 0; i < 3; i++) g.fillRoundedRect(-S * 0.3 + i * S * 0.22, -S * 0.2, S * 0.1, S * 0.07, 2);
    var beacon = scene.add.circle(0, -S * 1.1, 4, accent, 1).setBlendMode(Phaser.BlendModes.ADD);
    c.add(beacon);
    scene.tweens.add({ targets: beacon, alpha: 0.2, duration: 700, yoyo: true, repeat: -1 });
    c.fxTargets = [beacon];
    return c;
  }

  return { build: build, attach: attach, drawShip: drawShip, drawBuilding: drawBuilding };
})();
