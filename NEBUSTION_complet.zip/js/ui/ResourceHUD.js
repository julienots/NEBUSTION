/**
 * NEBUSTION - ResourceHUD
 * Barre de ressources PERMANENTE (5 cellules, lisible sur téléphone) + panneau de production
 * (tap sur la barre) : stock / capacité, gains par seconde et par minute, gains réels sur 60 s,
 * et amélioration du Stockage (capacité ×1,5 par niveau).
 * Utilisation : NEBUSTION.HUD.attach(scene) dans le create() de chaque scène de jeu.
 * Gère aussi la fenêtre « bon retour » (production hors ligne).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.HUD = class ResourceHUD {
  static attach(scene) { return new NEBUSTION.HUD(scene); }

  constructor(scene) {
    this.scene = scene;
    this.R = NEBUSTION.Resources;
    this.E = NEBUSTION.Economy;
    this.cells = {};
    this._acc = 0;
    this._panelOpen = false;
    this._resetArmed = 0;

    this._buildBar();
    this._buildPanel();
    if (NEBUSTION.SettingsMenu) NEBUSTION.SettingsMenu.attach(scene);

    var self = this;
    this._onGain = function (ev) { self._onGainEvent(ev); };
    this._onOffline = function () { self._showOffline(); };
    this._onReset = function () { self._acc = 999; };
    this._off = [this.R.on('gain', this._onGain), this.R.on('offline', this._onOffline), this.R.on('reset', this._onReset)];

    this._upd = function (time, delta) { self.update(delta); };
    scene.events.on('update', this._upd);
    scene.events.once('shutdown', function () { self.destroy(); });

    this.refresh();
    // Un rapport d'absence en attente (retour dans le jeu) est affiché dès l'entrée dans une scène avec HUD.
    scene.time.delayedCall(450, function () { self._showOffline(); });
    // Raids ennemis contre le QG survenus pendant l'absence (module 12) : un toast, une seule fois, quelle que soit la scène.
    scene.time.delayedCall(900, function () { self._showRaidReport(); });
  }

  destroy() {
    if (this._destroyed) return;
    this._destroyed = true;
    this._off.forEach(function (f) { f(); });
    this.scene.events.off('update', this._upd);
  }

  // ---------- Barre ----------
  _buildBar() {
    var s = this.scene, E = this.E, w = s.scale.width;
    // Marge à gauche réservée à l'icône ⚙ des paramètres (SettingsMenu), pour qu'elle ne
    // se pose jamais par-dessus la première cellule de ressource.
    var leftMargin = 58, rightMargin = 6;
    var gap = 8, cw = (w - leftMargin - rightMargin - gap * 4) / 5, y = 58;
    this.cw = cw;
    E.ORDER.forEach((id, i) => {
      var def = E.RES[id];
      var x = leftMargin + cw / 2 + i * (cw + gap);
      var c = s.add.container(x, y).setDepth(1200);
      var bg = s.add.graphics();
      bg.fillGradientStyle(0x151d33, 0x151d33, 0x0b1224, 0x0b1224, 0.95);
      bg.fillRoundedRect(-cw / 2, -46, cw, 92, 16);
      bg.lineStyle(2, def.color, 0.55);
      bg.strokeRoundedRect(-cw / 2, -46, cw, 92, 16);
      var icon = s.add.image(-cw / 2 + 24, -16, 'tex_icon_' + id).setDisplaySize(36, 36);
      var val = s.add.text(-cw / 2 + 46, -16, '0', { fontFamily: 'Arial, sans-serif', fontSize: '26px', fontStyle: 'bold', color: '#eaf2ff' }).setOrigin(0, 0.5);
      var rate = s.add.text(-cw / 2 + 12, 12, '+0/s', { fontFamily: 'Arial, sans-serif', fontSize: '20px', fontStyle: 'bold', color: def.hex }).setOrigin(0, 0.5);
      var bar = s.add.graphics();
      c.add([bg, icon, val, rate, bar]);
      this.cells[id] = { c: c, bg: bg, icon: icon, val: val, rate: rate, bar: bar, lastVal: '', lastRate: '', lastPct: -1, lastState: '' };
    });

    // Zone tactile sur toute la barre → panneau de production
    var zone = s.add.zone(w / 2, y, w, 96).setDepth(1201).setInteractive({ useHandCursor: true });
    zone.on('pointerdown', () => { this.togglePanel(); });
    this.zone = zone;
  }

  _onGainEvent(ev) {
    if (ev.source === 'passive' || ev.source === 'offline') return;
    var cell = this.cells[ev.id];
    if (!cell) return;
    var s = this.scene;
    s.tweens.add({ targets: cell.c, scale: 1.09, duration: 90, yoyo: true, ease: 'Sine.easeOut', onComplete: function () { cell.c.setScale(1); } });
    if (cell.flash) cell.flash.destroy();
    var f = s.add.image(cell.c.x, cell.c.y, 'tex_glow_' + ev.id).setDisplaySize(this.cw + 20, 110).setBlendMode(Phaser.BlendModes.ADD).setDepth(1199).setAlpha(0.7);
    cell.flash = f;
    s.tweens.add({ targets: f, alpha: 0, duration: 380, onComplete: function () { f.destroy(); if (cell.flash === f) cell.flash = null; } });
  }

  update(delta) {
    this._acc += delta;
    if (this._acc < 100) return;
    this._acc = 0;
    this.refresh();
    if (this._panelOpen) this._refreshPanel();
  }

  refresh() {
    var E = this.E, R = this.R;
    E.ORDER.forEach((id) => {
      var cell = this.cells[id], def = E.RES[id];
      var v = R.get(id), cap = R.cap(id);
      var str = E.fmt(v, def.decimals);
      if (str !== cell.lastVal) {
        cell.val.setText(str);
        cell.val.setScale(Math.min(1, (this.cw - 54) / Math.max(1, cell.val.width)));
        cell.lastVal = str;
      }
      var full = R.isFull(id);
      var rstr = full ? 'PLEIN' : '+' + E.fmtRate(R.rate(id)) + '/s';
      if (rstr !== cell.lastRate) {
        cell.rate.setText(rstr);
        cell.rate.setColor(full ? '#ff8fa3' : def.hex);
        cell.rate.setScale(Math.min(1, (this.cw - 18) / Math.max(1, cell.rate.width)));
        cell.lastRate = rstr;
      }
      var pct = cap > 0 ? Math.min(1, v / cap) : 0;
      var state = full ? 'full' : (pct >= 0.9 ? 'high' : 'ok');
      if (Math.abs(pct - cell.lastPct) > 0.004 || state !== cell.lastState) {
        var bw = this.cw - 24;
        cell.bar.clear();
        cell.bar.fillStyle(0x1c2b4a, 1); cell.bar.fillRoundedRect(-bw / 2, 34, bw, 5, 2);
        var col = state === 'full' ? 0xff4d6d : (state === 'high' ? 0xffb84d : def.color);
        cell.bar.fillStyle(col, 1); cell.bar.fillRoundedRect(-bw / 2, 34, Math.max(2, bw * pct), 5, 2);
        cell.lastPct = pct; cell.lastState = state;
      }
    });
  }

  // ---------- Panneau de production ----------
  _buildPanel() {
    var s = this.scene, w = s.scale.width, E = this.E;
    var pw = w - 24, ph = 700;
    var panel = s.add.container(w / 2, -ph).setDepth(1250);
    this.panelH = ph; this.panelOpenY = 112 + ph / 2; this.panelClosedY = -ph;
    var bg = s.add.graphics();
    bg.fillGradientStyle(0x111b36, 0x111b36, 0x090f20, 0x090f20, 0.985);
    bg.fillRoundedRect(-pw / 2, -ph / 2, pw, ph, 22);
    bg.lineStyle(2, 0x2e9eff, 0.7); bg.strokeRoundedRect(-pw / 2, -ph / 2, pw, ph, 22);
    panel.add(bg);
    // Bloque les taps qui traverseraient le panneau vers les gisements situés dessous
    panel.add(s.add.rectangle(0, 0, pw, ph, 0x000000, 0.001).setInteractive());
    panel.add(s.add.text(-pw / 2 + 24, -ph / 2 + 34, 'PRODUCTION', { fontFamily: 'Arial, sans-serif', fontSize: '28px', fontStyle: '900', color: '#eaf2ff' }).setOrigin(0, 0.5));
    var close = s.add.text(pw / 2 - 30, -ph / 2 + 34, '✕', { fontFamily: 'Arial, sans-serif', fontSize: '32px', color: '#a9b8dc' }).setOrigin(0.5).setInteractive({ useHandCursor: true });
    close.on('pointerdown', () => this.togglePanel(false));
    panel.add(close);

    this.rows = {};
    E.ORDER.forEach((id, i) => {
      var def = E.RES[id], y = -ph / 2 + 108 + i * 74;
      var line = s.add.graphics(); line.lineStyle(1, 0x1c2b4a, 1); line.lineBetween(-pw / 2 + 16, y + 36, pw / 2 - 16, y + 36); panel.add(line);
      var icon = s.add.image(-pw / 2 + 44, y, 'tex_icon_' + id).setDisplaySize(44, 44);
      var name = s.add.text(-pw / 2 + 82, y - 14, def.short, { fontFamily: 'Arial, sans-serif', fontSize: '26px', fontStyle: 'bold', color: '#eaf2ff' }).setOrigin(0, 0.5);
      var stock = s.add.text(-pw / 2 + 82, y + 16, '', { fontFamily: 'Arial, sans-serif', fontSize: '20px', color: '#9fb0d6' }).setOrigin(0, 0.5);
      var ps = s.add.text(pw / 2 - 24, y - 14, '', { fontFamily: 'Arial, sans-serif', fontSize: '26px', fontStyle: 'bold', color: def.hex }).setOrigin(1, 0.5);
      var pm = s.add.text(pw / 2 - 24, y + 16, '', { fontFamily: 'Arial, sans-serif', fontSize: '21px', color: '#c8d4f0' }).setOrigin(1, 0.5);
      panel.add([icon, name, stock, ps, pm]);
      this.rows[id] = { stock: stock, ps: ps, pm: pm };
    });

    // Amélioration du Stockage (capacité de toutes les ressources) : sans elle, les gros coûts dépassent la capacité
    var sy = -ph / 2 + 470;
    this.stTitle = s.add.text(-pw / 2 + 24, sy, 'STOCKAGE', { fontFamily: 'Arial, sans-serif', fontSize: '24px', fontStyle: 'bold', color: '#eaf2ff' }).setOrigin(0, 0.5);
    this.stEffect = s.add.text(pw / 2 - 24, sy, '', { fontFamily: 'Arial, sans-serif', fontSize: '19px', fontStyle: 'bold', color: '#7dffb0' }).setOrigin(1, 0.5);
    panel.add([this.stTitle, this.stEffect]);
    this.stBtn = new NEBUSTION.Button(s, 0, sy + 52, { width: pw - 48, height: 64, label: 'AMÉLIORER', fontSize: '19px', accentColor: 0x7dffb0, onClick: () => this._onUpgradeStorage() });
    panel.add(this.stBtn);
    this._stFlash = 0; this._stLast = {};

    this.footer = s.add.text(0, ph / 2 - 92, '', { fontFamily: 'Arial, sans-serif', fontSize: '19px', color: '#8ea0c8', align: 'center', wordWrap: { width: pw - 40 } }).setOrigin(0.5);
    panel.add(this.footer);

    var btnY = ph / 2 - 36;
    this.resetBtn = new NEBUSTION.Button(s, NEBUSTION.DEBUG ? 150 : 0, btnY, { width: 300, height: 48, label: 'Réinitialiser la partie', fontSize: '18px', accentColor: 0xff4d6d, onClick: () => this._onReset2() });
    panel.add(this.resetBtn);
    if (NEBUSTION.DEBUG) {
      var away = new NEBUSTION.Button(s, -150, btnY, { width: 300, height: 48, label: 'TEST : +1 h hors ligne', fontSize: '18px', accentColor: 0xffd166, onClick: () => { this.R.debugAway(3600); this.togglePanel(false); } });
      panel.add(away);
    }
    this.panel = panel;
  }

  _onReset2() {
    var now = Date.now();
    if (now - this._resetArmed < 4000) {
      this._resetArmed = 0;
      this.R.reset(now);
      this.resetBtn.labelText.setText('Réinitialiser la partie');
      this.togglePanel(false);
    } else {
      this._resetArmed = now;
      this.resetBtn.labelText.setText('Toucher encore pour confirmer');
      var self = this;
      this.scene.time.delayedCall(4000, function () { if (self.resetBtn && self.resetBtn.labelText && self.resetBtn.labelText.active && self._resetArmed) { self._resetArmed = 0; self.resetBtn.labelText.setText('Réinitialiser la partie'); } });
    }
  }

  _onUpgradeStorage() {
    var R = this.R, E = this.E, s = this.scene, res = R.upgradeBuilding('storage');
    this._stFlash = Date.now() + 1400;
    this._stFlashText = res.ok ? 'Stockage amélioré ✓  Niv. ' + res.level : (res.reason === 'max' ? 'Niveau maximum atteint' : 'Ressources insuffisantes');
    this._stFlashOk = !!res.ok;
    if (res.ok) {
      s.tweens.add({ targets: this.stBtn, scale: 1.05, duration: 120, yoyo: true });
      try { var st=NEBUSTION.Settings.get(); if (st.vibrationOn && !st.batterySaver && navigator.vibrate) navigator.vibrate(30); } catch (e) { /* ignore */ }
    } else if (res.reason === 'cost') {
      s.tweens.add({ targets: this.stBtn, x: 8, duration: 45, yoyo: true, repeat: 2, onComplete: () => { this.stBtn.x = 0; } });
    }
    this._refreshPanel();
  }

  _setSt(obj, str, key) {
    if (this._stLast[key] === str) return;
    this._stLast[key] = str;
    obj.setText(str);
  }

  _refreshStorage() {
    var R = this.R, E = this.E, lvl = R.level('storage'), max = lvl >= E.CFG.MAX_LEVEL;
    this._setSt(this.stTitle, 'STOCKAGE  •  Niv. ' + lvl, 'title');
    this._setSt(this.stEffect, E.effectText('storage', lvl), 'eff');
    var cost = max ? null : E.upgradeCost('storage', lvl), afford = !!cost && R.canAfford(cost), label, look;
    if (Date.now() < this._stFlash) { label = this._stFlashText; look = this._stFlashOk ? 'y' : 'n'; }
    else if (max) { label = 'NIVEAU MAXIMUM'; look = 'm'; }
    else {
      label = 'AMÉLIORER  —  ' + Object.keys(cost).map(function (id) { return E.RES[id].short + ' ' + E.fmt(cost[id], 0); }).join('  •  ');
      look = afford ? 'y' : 'n';
    }
    this._setSt(this.stBtn.labelText, label, 'btn');
    if (this._stLast.look !== look) {
      this._stLast.look = look;
      if (look === 'y') this.stBtn.setLook(0x7dffb0, '#eaf2ff');
      else this.stBtn.setLook(0x394869, look === 'm' ? '#7dffb0' : '#ff8fa3');
    }
  }

  togglePanel(force) {
    var open = force === undefined ? !this._panelOpen : !!force;
    if (open === this._panelOpen) return;
    this._panelOpen = open;
    if (open) this._refreshPanel();
    this.scene.tweens.add({ targets: this.panel, y: open ? this.panelOpenY : this.panelClosedY, duration: 280, ease: open ? 'Back.easeOut' : 'Sine.easeIn' });
  }

  _refreshPanel() {
    var E = this.E, R = this.R, now = Date.now();
    E.ORDER.forEach((id) => {
      var row = this.rows[id], def = E.RES[id], r = R.rate(id);
      row.stock.setText(E.fmt(R.get(id), def.decimals) + ' / ' + E.fmt(R.cap(id)) + '   •   ' + R.droneCount(id) + ' drone' + (R.droneCount(id) > 1 ? 's' : '') + ' • Nv.' + R.extractorLevel(id));
      row.ps.setText('+' + E.fmtRate(r) + ' /s');
      var rec = R.recent(id, now);
      var real = rec.seconds >= 10 ? '   (réel 60 s : ' + E.fmtRate(rec.total * 60 / Math.max(rec.seconds, 1)) + ')' : '';
      row.pm.setText('+' + E.fmtRate(r * 60) + ' /min' + real);
    });
    this._refreshStorage();
    var ok = R.lastSaveOk && NEBUSTION.Save.isPersistent();
    this.footer.setText('Hors ligne : ' + Math.round(E.CFG.OFFLINE_EFFICIENCY * 100) + ' % du rendement, jusqu\'à ' + (E.CFG.OFFLINE_MAX_SEC / 3600) + ' h.\n' +
      (ok ? 'Sauvegarde automatique active ✓' : '⚠ Sauvegarde locale indisponible : la progression sera perdue à la fermeture.'));
    this.footer.setColor(ok ? '#8ea0c8' : '#ff8fa3');
  }

  // ---------- Fenêtre « bon retour » ----------
  _showOffline() {
    if (this._destroyed || this._modalOpen) return;
    var report = this.R.consumeOfflineReport();
    if (!report) return;
    this._modalOpen = true;
    var self = this;
    NEBUSTION.OfflineModal.show(this.scene, report, function () { self._modalOpen = false; });
  }

  // ---------- Raids ennemis contre le QG (module 12) ----------
  _showRaidReport() {
    if (this._destroyed || !NEBUSTION.QGRaidManager) return;
    var rep = NEBUSTION.QGRaidManager.consumeReport();
    if (!rep || !rep.raids.length) return;
    var raids = rep.raids, last = raids[raids.length - 1];
    var lost = raids.filter(function (r) { return r.victory; }).length;
    var fx = this.scene.fx || (this.scene.fx = new NEBUSTION.FX(this.scene));
    if (last.victory) {
      var pct = Math.round(last.lossPct * 100);
      fx.toast('QG attaqué pendant votre absence', (lost > 1 ? lost + ' raids réussis' : 'Raid ennemi réussi') + ' — -' + pct + ' % de ressources pillées', null);
    } else {
      fx.toast('QG attaqué pendant votre absence', raids.length > 1 ? raids.length + ' raids repoussés' : 'Raid ennemi repoussé', null);
    }
  }
};
