/**
 * NEBUSTION - BottomNav
 * Barre de navigation persistante en bas de l'écran, présente sur toutes
 * les scènes de jeu (pas sur le Boot/Splash). Met en évidence la section active.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.NAV_ITEMS = [
  { key: 'planet', label: 'Planète', scene: 'PlanetScene', icon: 'planet' },
  { key: 'galaxy', label: 'Galaxie', scene: 'GalaxyScene', icon: 'galaxy' },
  { key: 'heroes', label: 'Héros', scene: 'HeroesScene', icon: 'heroes' },
  { key: 'combat', label: 'Combat', scene: 'CombatPrepScene', icon: 'combat' },
  { key: 'shop', label: 'Boutique', scene: 'ShopScene', icon: 'shop' },
  { key: 'pass', label: 'Pass', scene: 'PassScene', icon: 'pass' }
];

NEBUSTION.BottomNav = class BottomNav extends Phaser.GameObjects.Container {
  /**
   * @param {Phaser.Scene} scene
   * @param {string} activeKey - clé de la section actuellement affichée
   */
  constructor(scene, activeKey) {
    var w = scene.scale.width;
    var h = scene.scale.height;
    var barHeight = 116;
    super(scene, 0, h - barHeight);
    this.activeKey = activeKey;

    var bg = scene.add.graphics();
    bg.fillGradientStyle(0x0a1020, 0x0a1020, 0x05070f, 0x05070f, 0.96, 0.96, 0.98, 0.98);
    bg.fillRect(0, 0, w, barHeight);
    bg.lineStyle(2, 0x1c2b4a, 1);
    bg.lineBetween(0, 0, w, 0);
    this.add(bg);

    var count = NEBUSTION.NAV_ITEMS.length;
    var slotW = w / count;

    NEBUSTION.NAV_ITEMS.forEach((item, i) => {
      var cx = slotW * i + slotW / 2;
      var cy = barHeight / 2;
      var isActive = item.key === activeKey;

      var icon = scene.add.graphics();
      this._drawIcon(icon, item.icon, isActive);
      icon.x = cx;
      icon.y = cy - 16;
      this.add(icon);

      var label = scene.add.text(cx, cy + 26, item.label, {
        fontFamily: 'Arial, sans-serif',
        fontSize: '15px',
        color: isActive ? '#00e5ff' : '#7a89ad',
        fontStyle: isActive ? 'bold' : 'normal'
      }).setOrigin(0.5);
      this.add(label);

      if (isActive) {
        var underline = scene.add.graphics();
        underline.fillStyle(0x00e5ff, 1);
        underline.fillRoundedRect(cx - 14, cy - 38, 28, 3, 2);
        this.add(underline);
      }

      var hitZone = scene.add.zone(cx, cy, slotW, barHeight).setOrigin(0.5).setInteractive({ useHandCursor: true });
      hitZone.on('pointerdown', () => {
        scene.tweens.add({ targets: icon, scale: 0.85, duration: 60, yoyo: true });
        if (item.key !== this.activeKey) {
          scene.scene.start(item.scene, { navKey: item.key, title: item.label });
        }
      });
      this.add(hitZone);
    });

    scene.add.existing(this);
    this.setDepth(1000);
  }

  _drawIcon(g, type, isActive) {
    var color = isActive ? 0x00e5ff : 0x7a89ad;
    g.lineStyle(2.5, color, 1);
    g.fillStyle(color, isActive ? 0.25 : 0);

    switch (type) {
      case 'planet':
        g.strokeCircle(0, 0, 11);
        g.fillCircle(0, 0, 11);
        g.lineStyle(2, color, 0.8);
        g.strokeEllipse(0, 0, 24, 8);
        break;
      case 'galaxy':
        for (var i = 0; i < 3; i++) {
          g.lineStyle(2, color, 1 - i * 0.25);
          g.strokeCircle(0, 0, 6 + i * 6);
        }
        break;
      case 'heroes':
        g.fillCircle(0, -6, 6);
        g.fillStyle(color, isActive ? 0.25 : 0);
        g.fillTriangle(-10, 12, 10, 12, 0, -3);
        g.lineStyle(2, color, 1);
        g.strokeCircle(0, -6, 6);
        g.strokeTriangle(-10, 12, 10, 12, 0, -3);
        break;
      case 'combat':
        g.lineStyle(3, color, 1);
        g.lineBetween(-9, 9, 9, -9);
        g.lineBetween(-9, -9, 9, 9);
        break;
      case 'shop':
        g.strokeRoundedRect(-11, -6, 22, 16, 3);
        g.lineBetween(-11, -6, -6, -13);
        g.lineBetween(11, -6, 6, -13);
        break;
      case 'pass':
        g.strokeRoundedRect(-12, -9, 24, 18, 4);
        g.lineBetween(-12, -1, 12, -1);
        break;
    }
  }
};
