/**
 * NEBUSTION - BottomNav (menu de navigation latéral rétractable)
 * Présent sur toutes les scènes de jeu (pas sur le Boot/Splash). Anciennement une barre fixe en bas de
 * l'écran : c'est maintenant un petit onglet collé au bord droit, toujours visible mais quasi sans
 * encombrement. Un tap l'ouvre en colonne verticale (icône + libellé par section, section active
 * surlignée) ; un tap sur une section, sur la croix, sur l'onglet ou en dehors du panneau le referme.
 * L'API (constructeur `new NEBUSTION.BottomNav(scene, activeKey)`) est inchangée : aucune scène à modifier.
 * Le tutoriel (TutorialOverlay) s'appuie sur NEBUSTION.BottomNav.HANDLE et NEBUSTION.BottomNav.current.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.NAV_ITEMS = [
  { key: 'planet', label: 'Planète', scene: 'PlanetScene', icon: 'planet' },
  { key: 'galaxy', label: 'Galaxie', scene: 'GalaxyScene', icon: 'galaxy' },
  { key: 'heroes', label: 'Héros', scene: 'HeroesScene', icon: 'heroes' },
  { key: 'combat', label: 'Combat', scene: 'CombatPrepScene', icon: 'combat' },
  { key: 'shop', label: 'Boutique', scene: 'ShopScene', icon: 'shop' },
  { key: 'pass', label: 'Pass', scene: 'PassScene', icon: 'pass' }
];

NEBUSTION.BottomNav = class BottomNav extends Phaser.GameObjects.Container {
  /**
   * @param {Phaser.Scene} scene
   * @param {string} activeKey - clé de la section actuellement affichée (null : aucune)
   */
  constructor(scene, activeKey) {
    var w = scene.scale.width;
    var h = scene.scale.height;
    super(scene, 0, 0);
    this.activeKey = activeKey;
    this.isOpen = false;
    this._w = w;
    this._h = h;
    this._items = NEBUSTION.NAV_ITEMS;
    this._panelW = 214;
    this._itemH = 76;
    this._cy = Math.round(h * NEBUSTION.BottomNav.HANDLE.cyRatio);   // zone naturelle du pouce, pas au centre exact

    // Voile de fond : capte les taps (rien ne passe en dessous) et ferme le menu
    this.dim = scene.add.rectangle(w / 2, h / 2, w, h, 0x02040a, 0.6);
    this.dim.setAlpha(0);
    this.dim.setVisible(false);
    this.dim.on('pointerup', () => this.toggle(false));
    this.add(this.dim);

    // Panneau déroulant (repère local : bord droit du panneau = x 0, centré verticalement sur y 0)
    this.panel = scene.add.container(w + this._panelW + 40, this._cy);
    this.add(this.panel);
    this._buildPanel();

    // Onglet toujours visible (repère local : bord droit de l'écran = x 0)
    this.handle = scene.add.container(w, this._cy);
    this.add(this.handle);
    this._buildHandle();

    scene.add.existing(this);
    this.setDepth(1000);
    NEBUSTION.BottomNav.current = this;

    // L'onglet « respire » doucement pour signaler qu'il est là
    this._pulse = scene.tweens.add({ targets: this.handleTab, scaleX: { from: 1, to: 1.12 }, duration: 1200, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    scene.events.once('shutdown', () => {
      try { this._pulse.stop(); } catch (e) { /* ignore */ }
      if (NEBUSTION.BottomNav.current === this) NEBUSTION.BottomNav.current = null;
    });
  }

  /** Ouvre (true), ferme (false) ou inverse (rien) le menu. */
  toggle(open) {
    var scene = this.scene;
    if (!scene || !this.panel || !this.panel.scene) return;
    this.isOpen = (open === undefined) ? !this.isOpen : !!open;
    var self = this, opening = this.isOpen, w = this._w;
    if (opening) { this.dim.setVisible(true); this.dim.setInteractive(); this._handleZone.disableInteractive(); }
    else { this.dim.disableInteractive(); this._handleZone.setInteractive({ useHandCursor: true }); }
    scene.tweens.add({ targets: this.dim, alpha: opening ? 1 : 0, duration: 180, onComplete: function () { if (!self.isOpen) self.dim.setVisible(false); } });
    scene.tweens.add({ targets: this.panel, x: opening ? w : w + this._panelW + 40, duration: 240, ease: opening ? 'Cubic.easeOut' : 'Cubic.easeIn' });
    scene.tweens.add({ targets: this.handle, alpha: opening ? 0 : 1, duration: 160 });
  }

  // ---------- Onglet compact (bord droit) ----------
  _buildHandle() {
    var scene = this.scene, hW = NEBUSTION.BottomNav.HANDLE.w, hH = NEBUSTION.BottomNav.HANDLE.h;
    var rad = { tl: 16, bl: 16, tr: 0, br: 0 };
    var g = scene.add.graphics();
    g.fillStyle(0x0a1020, 0.94);
    g.fillRoundedRect(-hW, -hH / 2, hW, hH, rad);
    g.lineStyle(2, 0x2a3d6e, 1);
    g.strokeRoundedRect(-hW, -hH / 2, hW, hH, rad);
    g.fillStyle(0x00e5ff, 0.9);
    g.fillRoundedRect(-hW, -hH / 2 + 10, 3, hH - 20, 2);
    this.handleTab = g;
    this.handle.add(g);

    // Icône de la section active (ou « menu » à trois traits) + petit chevron « ouvrir »
    var active = this._items.filter((it) => it.key === this.activeKey)[0];
    var ic = scene.add.graphics();
    if (active) { this._drawIcon(ic, active.icon, true); ic.setScale(0.72); }
    else {
      ic.lineStyle(2.5, 0x7a89ad, 1);
      ic.lineBetween(-8, -7, 8, -7); ic.lineBetween(-8, 0, 8, 0); ic.lineBetween(-8, 7, 8, 7);
      ic.setScale(0.9);
    }
    ic.setPosition(-hW / 2 + 1, -14);
    this.handle.add(ic);
    var ch = scene.add.graphics();
    ch.lineStyle(2.5, 0x00e5ff, 1);
    ch.lineBetween(-hW / 2 + 4, 24, -hW / 2 - 3, 31); ch.lineBetween(-hW / 2 - 3, 31, -hW / 2 + 4, 38);
    this.handle.add(ch);

    // Zone de tap un peu plus large que l'onglet (confort du pouce)
    var z = scene.add.zone(-hW / 2 - 6, 0, hW + 12, hH + 24).setOrigin(0.5).setInteractive({ useHandCursor: true });
    z.on('pointerup', () => {
      scene.tweens.add({ targets: this.handleTab, scaleX: 0.8, duration: 60, yoyo: true });
      this.toggle(true);
    });
    this._handleZone = z;
    this.handle.add(z);
  }

  // ---------- Panneau déroulant (colonne verticale) ----------
  _buildPanel() {
    var scene = this.scene, pw = this._panelW, itemH = this._itemH, items = this._items, self = this;
    var headerH = 46, padTop = 10, padBottom = 18;
    var panelH = headerH + padTop + items.length * itemH + padBottom;
    var top = -panelH / 2;
    var rad = { tl: 22, bl: 22, tr: 0, br: 0 };

    var g = scene.add.graphics();
    g.fillGradientStyle(0x0d1730, 0x0d1730, 0x05070f, 0x05070f, 0.98, 0.98, 0.99, 0.99);
    g.fillRoundedRect(-pw, top, pw, panelH, rad);
    g.lineStyle(2.5, 0x2a3d6e, 1);
    g.strokeRoundedRect(-pw, top, pw, panelH, rad);
    this.panel.add(g);

    // Fond capteur : les taps dans le panneau (hors lignes) ne ferment pas le menu
    var block = scene.add.zone(-pw / 2, 0, pw, panelH).setOrigin(0.5).setInteractive();
    this.panel.add(block);

    this.panel.add(scene.add.text(-pw + 22, top + headerH / 2, 'MENU', {
      fontFamily: 'Arial, sans-serif', fontSize: '15px', fontStyle: 'bold', color: '#5f7bb0'
    }).setOrigin(0, 0.5));
    var cx = scene.add.graphics();
    cx.lineStyle(2.6, 0x9fb0d6, 1);
    cx.lineBetween(-36, top + headerH / 2 - 7, -22, top + headerH / 2 + 7);
    cx.lineBetween(-36, top + headerH / 2 + 7, -22, top + headerH / 2 - 7);
    this.panel.add(cx);
    var closeZone = scene.add.zone(-29, top + headerH / 2, 60, headerH).setOrigin(0.5).setInteractive({ useHandCursor: true });
    closeZone.on('pointerup', () => this.toggle(false));
    this.panel.add(closeZone);

    var hr = scene.add.graphics();
    hr.lineStyle(1.5, 0x1c2b4a, 0.95);
    hr.lineBetween(-pw + 14, top + headerH, -14, top + headerH);
    this.panel.add(hr);

    items.forEach(function (item, i) {
      var ry = top + headerH + padTop + i * itemH + itemH / 2;
      var isActive = item.key === self.activeKey;
      if (isActive) {
        var hi = scene.add.graphics();
        hi.fillStyle(0x00e5ff, 0.14);
        hi.fillRoundedRect(-pw + 8, ry - itemH / 2 + 5, pw - 16, itemH - 10, 14);
        hi.fillStyle(0x00e5ff, 1);
        hi.fillRoundedRect(-pw + 8, ry - itemH / 2 + 12, 4, itemH - 24, 2);
        self.panel.add(hi);
      }
      var icon = scene.add.graphics();
      self._drawIcon(icon, item.icon, isActive);
      icon.setPosition(-pw + 46, ry);
      icon.setScale(1.15);
      self.panel.add(icon);
      self.panel.add(scene.add.text(-pw + 80, ry, item.label, {
        fontFamily: 'Arial, sans-serif', fontSize: '20px', fontStyle: isActive ? 'bold' : 'normal',
        color: isActive ? '#eaf2ff' : '#a9b8dc'
      }).setOrigin(0, 0.5));
      var z = scene.add.zone(-pw / 2, ry, pw - 8, itemH).setOrigin(0.5).setInteractive({ useHandCursor: true });
      z.on('pointerup', function () {
        scene.tweens.add({ targets: icon, scale: 1.0, duration: 60, yoyo: true });
        if (item.key !== self.activeKey) scene.scene.start(item.scene, { navKey: item.key, title: item.label });
        else self.toggle(false);
      });
      self.panel.add(z);
    });
  }

  _drawIcon(g, type, isActive) {
    var color = isActive ? 0x00e5ff : 0x7a89ad;
    g.lineStyle(2.5, color, 1);
    g.fillStyle(color, isActive ? 0.25 : 0);

    switch (type) {
      case 'planet':
        g.strokeCircle(0, 0, 11);
        g.fillCircle(0, 0, 11);
        g.lineStyle(2, color, 0.8);
        g.strokeEllipse(0, 0, 24, 8);
        break;
      case 'galaxy':
        for (var i = 0; i < 3; i++) {
          g.lineStyle(2, color, 1 - i * 0.25);
          g.strokeCircle(0, 0, 6 + i * 6);
        }
        break;
      case 'heroes':
        g.fillCircle(0, -6, 6);
        g.fillStyle(color, isActive ? 0.25 : 0);
        g.fillTriangle(-10, 12, 10, 12, 0, -3);
        g.lineStyle(2, color, 1);
        g.strokeCircle(0, -6, 6);
        g.strokeTriangle(-10, 12, 10, 12, 0, -3);
        break;
      case 'combat':
        g.lineStyle(3, color, 1);
        g.lineBetween(-9, 9, 9, -9);
        g.lineBetween(-9, -9, 9, 9);
        break;
      case 'shop':
        g.strokeRoundedRect(-11, -6, 22, 16, 3);
        g.lineBetween(-11, -6, -6, -13);
        g.lineBetween(11, -6, 6, -13);
        break;
      case 'pass':
        g.strokeRoundedRect(-12, -9, 24, 18, 4);
        g.lineBetween(-12, -1, 12, -1);
        break;
    }
  }
};

/** Géométrie de l'onglet (partagée avec le tutoriel) : bord droit de l'écran, à `cyRatio` de la hauteur. */
NEBUSTION.BottomNav.HANDLE = { w: 30, h: 104, cyRatio: 0.6 };
/** Instance du menu de la scène en cours (null si aucune). */
NEBUSTION.BottomNav.current = null;
