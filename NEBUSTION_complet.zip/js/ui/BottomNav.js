/**
 * NEBUSTION - BottomNav (barre de menu, fixe en bas de l'écran)
 * Présente sur toutes les scènes de jeu (pas sur le Boot/Splash). Barre horizontale toujours dépliée,
 * ancrée en bas de l'écran : chaque section (icône + libellé) est visible en permanence, plus besoin de
 * l'ouvrir. Un tap sur une section (autre que la section active) y navigue directement.
 * L'API (constructeur `new NEBUSTION.BottomNav(scene, activeKey)`) est inchangée : aucune scène à modifier.
 * Le tutoriel (TutorialOverlay) s'appuie sur NEBUSTION.BottomNav.HANDLE (géométrie de la barre) et
 * NEBUSTION.BottomNav.current.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.NAV_ITEMS = [
  { key: 'planet', label: 'Planète', scene: 'PlanetScene', icon: 'planet' },
  { key: 'galaxy', label: 'Galaxie', scene: 'GalaxyScene', icon: 'galaxy' },
  { key: 'heroes', label: 'Héros', scene: 'HeroesScene', icon: 'heroes' },
  { key: 'combat', label: 'Combat', scene: 'CombatPrepScene', icon: 'combat' },
  { key: 'shop', label: 'Boutique', scene: 'ShopScene', icon: 'shop' },
  { key: 'pass', label: 'Pass', scene: 'PassScene', icon: 'pass' }
];

NEBUSTION.BottomNav = class BottomNav extends Phaser.GameObjects.Container {
  /**
   * @param {Phaser.Scene} scene
   * @param {string} activeKey - clé de la section actuellement affichée (null : aucune)
   */
  constructor(scene, activeKey) {
    var w = scene.scale.width;
    var h = scene.scale.height;
    super(scene, 0, 0);
    this.activeKey = activeKey;
    this.isOpen = true;   // toujours dépliée ; conservé pour compatibilité avec le code existant
    this._w = w;
    this._h = h;
    this._items = NEBUSTION.NAV_ITEMS;
    this._barH = NEBUSTION.BottomNav.HANDLE.h;

    this._buildBar();

    scene.add.existing(this);
    this.setDepth(1000);
    NEBUSTION.BottomNav.current = this;

    scene.events.once('shutdown', () => {
      if (NEBUSTION.BottomNav.current === this) NEBUSTION.BottomNav.current = null;
    });
  }

  /** Conservée pour compatibilité (ex. TutorialOverlay) : la barre est toujours ouverte, donc no-op. */
  toggle() { /* rien à faire : la barre ne se replie plus */ }

  // ---------- Barre horizontale fixe (bord bas) ----------
  _buildBar() {
    var scene = this.scene, w = this._w, h = this._h, barH = this._barH, items = this._items, self = this;
    var y0 = h - barH;

    var bg = scene.add.graphics();
    bg.fillGradientStyle(0x0d1730, 0x0d1730, 0x05070f, 0x05070f, 0.98, 0.98, 1, 1);
    bg.fillRect(0, y0, w, barH);
    bg.lineStyle(2, 0x2a3d6e, 1);
    bg.lineBetween(0, y0, w, y0);
    this.add(bg);

    var cellW = w / items.length;
    items.forEach(function (item, i) {
      var cx = cellW * i + cellW / 2, cy = y0 + barH / 2;
      var isActive = item.key === self.activeKey;

      if (isActive) {
        var hi = scene.add.graphics();
        hi.fillStyle(0x00e5ff, 0.14);
        hi.fillRoundedRect(cx - cellW / 2 + 5, y0 + 5, cellW - 10, barH - 10, 12);
        hi.fillStyle(0x00e5ff, 1);
        hi.fillRoundedRect(cx - 16, y0 + 3, 32, 3, 2);
        self.add(hi);
      }

      var icon = scene.add.graphics();
      self._drawIcon(icon, item.icon, isActive);
      icon.setPosition(cx, cy - 13);
      icon.setScale(1.02);
      self.add(icon);

      self.add(scene.add.text(cx, cy + 21, item.label, {
        fontFamily: 'Arial, sans-serif', fontSize: '11px', fontStyle: isActive ? 'bold' : 'normal',
        color: isActive ? '#eaf2ff' : '#8391b5'
      }).setOrigin(0.5));

      var z = scene.add.zone(cx, cy, cellW, barH).setOrigin(0.5).setInteractive({ useHandCursor: true });
      z.on('pointerup', function () {
        scene.tweens.add({ targets: icon, scale: 0.85, duration: 60, yoyo: true });
        if (item.key !== self.activeKey) scene.scene.start(item.scene, { navKey: item.key, title: item.label });
      });
      self.add(z);
    });
  }

  _drawIcon(g, type, isActive) {
    var color = isActive ? 0x00e5ff : 0x7a89ad;
    g.lineStyle(2.5, color, 1);
    g.fillStyle(color, isActive ? 0.25 : 0);

    switch (type) {
      case 'planet':
        g.strokeCircle(0, 0, 11);
        g.fillCircle(0, 0, 11);
        g.lineStyle(2, color, 0.8);
        g.strokeEllipse(0, 0, 24, 8);
        break;
      case 'galaxy':
        for (var i = 0; i < 3; i++) {
          g.lineStyle(2, color, 1 - i * 0.25);
          g.strokeCircle(0, 0, 6 + i * 6);
        }
        break;
      case 'heroes':
        g.fillCircle(0, -6, 6);
        g.fillStyle(color, isActive ? 0.25 : 0);
        g.fillTriangle(-10, 12, 10, 12, 0, -3);
        g.lineStyle(2, color, 1);
        g.strokeCircle(0, -6, 6);
        g.strokeTriangle(-10, 12, 10, 12, 0, -3);
        break;
      case 'combat':
        g.lineStyle(3, color, 1);
        g.lineBetween(-9, 9, 9, -9);
        g.lineBetween(-9, -9, 9, 9);
        break;
      case 'shop':
        g.strokeRoundedRect(-11, -6, 22, 16, 3);
        g.lineBetween(-11, -6, -6, -13);
        g.lineBetween(11, -6, 6, -13);
        break;
      case 'pass':
        g.strokeRoundedRect(-12, -9, 24, 18, 4);
        g.lineBetween(-12, -1, 12, -1);
        break;
    }
  }
};

/** Géométrie de la barre (partagée avec le tutoriel) : hauteur fixée en bas de l'écran. */
NEBUSTION.BottomNav.HANDLE = { w: 0, h: 92, cyRatio: 1 };
/** Instance du menu de la scène en cours (null si aucune). */
NEBUSTION.BottomNav.current = null;
