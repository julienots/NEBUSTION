/**
 * NEBUSTION - SettingsMenu
 * Paramètres persistants : musique, volume musique, sons, volume sons,
 * vibration, effets réduits, économie de batterie, réinitialisation, accès au tutoriel (« Revoir le tutoriel »).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.SettingsMenu = class SettingsMenu {
  static attach(scene) {
    var old = scene._nebuSettingsMenu;
    if (old && !old._destroyed && old.gear && old.gear.scene) return old;
    if (old) old.destroy();
    return (scene._nebuSettingsMenu = new NEBUSTION.SettingsMenu(scene));
  }

  constructor(scene) {
    this.scene = scene; this.open = false;
    this.VOL_STEPS = [0, 0.02, 0.045, 0.07, 0.10, 0.14, 0.18];
    this.SFX_STEPS = [0, 0.04, 0.08, 0.12, 0.16, 0.22, 0.30];
    this._build();
    var self = this;
    this._offSettings = NEBUSTION.Settings.onChange(function () { self._refresh(); });
    this._offAuth = (NEBUSTION.CloudSave && NEBUSTION.CloudSave.isReady()) ? NEBUSTION.CloudSave.onAuthChange(function () { self._refresh(); }) : null;
    this._offAdmin = (NEBUSTION.AdminMode) ? NEBUSTION.AdminMode.onChange(function () { self._refresh(); }) : null;
    scene.events.once('shutdown', function () { self.destroy(); });
  }
  destroy() {
    this._destroyed = true;
    if (this._offSettings) this._offSettings(); if (this._offAuth) this._offAuth(); if (this._offAdmin) this._offAdmin();
    this._offSettings = this._offAuth = this._offAdmin = null;
    if (this.scene && this.scene._nebuSettingsMenu === this) this.scene._nebuSettingsMenu = null;
  }
  _build() {
    var s=this.scene,w=s.scale.width,h=s.scale.height,DEPTH=1620;
    this.backdrop=s.add.zone(w/2,h/2,w,h).setDepth(DEPTH-2);
    var gear=s.add.container(30,58).setDepth(DEPTH);
    var gbg=s.add.circle(0,0,19,0x0b1224,.92).setStrokeStyle(2,0x00e5ff,.7);
    var gicon=s.add.text(0,1,'⚙',{fontFamily:'Arial, sans-serif',fontSize:'20px',color:'#eaf2ff'}).setOrigin(.5);
    var ghit=s.add.zone(0,0,44,44).setInteractive({useHandCursor:true}); gear.add([gbg,gicon,ghit]); ghit.on('pointerdown',()=>this.toggle());
    this.gear=gear; this.gearBg=gbg;

    var pw=286,ph=546;
    var panel=s.add.container(30+pw/2-19,58+26).setDepth(DEPTH).setAlpha(0).setVisible(false);
    var pbg=s.add.graphics(); pbg.fillGradientStyle(0x111b36,0x111b36,0x090f20,0x090f20,.98); pbg.fillRoundedRect(-pw/2,0,pw,ph,16); pbg.lineStyle(2,0x00e5ff,.55); pbg.strokeRoundedRect(-pw/2,0,pw,ph,16); panel.add(pbg);
    panel.add(s.add.rectangle(0,ph/2,pw,ph,0,0.001).setInteractive());
    panel.add(s.add.text(-pw/2+16,16,'PARAMÈTRES',{fontFamily:'Arial, sans-serif',fontSize:'15px',fontStyle:'900',color:'#eaf2ff'}).setOrigin(0,.5));

    this._label(panel,pw,50,'Musique de fond');
    this.musicToggle=this._makeToggle(panel,pw/2-44,50,()=>{var st=NEBUSTION.Settings.get();NEBUSTION.Settings.set({musicOn:!st.musicOn});});
    this.volMinus=this._makeStep(panel,pw/2-92,78,'−',()=>this._bumpVolume(-1,false));
    this.volLabel=s.add.text(pw/2-58,78,'',{fontFamily:'Arial, sans-serif',fontSize:'12px',fontStyle:'bold',color:'#7dffb0'}).setOrigin(.5); panel.add(this.volLabel);
    this.volPlus=this._makeStep(panel,pw/2-26,78,'+',()=>this._bumpVolume(1,false));

    this._label(panel,pw,110,'Sons / bruitages');
    this.sfxToggle=this._makeToggle(panel,pw/2-44,110,()=>{var st=NEBUSTION.Settings.get();NEBUSTION.Settings.set({sfxOn:!st.sfxOn});});
    this.sfxMinus=this._makeStep(panel,pw/2-92,138,'−',()=>this._bumpVolume(-1,true));
    this.sfxLabel=s.add.text(pw/2-58,138,'',{fontFamily:'Arial, sans-serif',fontSize:'12px',fontStyle:'bold',color:'#7dffb0'}).setOrigin(.5); panel.add(this.sfxLabel);
    this.sfxPlus=this._makeStep(panel,pw/2-26,138,'+',()=>this._bumpVolume(1,true));

    this.vibrationToggle=this._settingRow(panel,pw,178,'📳 Vibration','vibrationOn');
    this.fxToggle=this._settingRow(panel,pw,218,'✨ Effets réduits','reducedFX');
    this.batteryToggle=this._settingRow(panel,pw,258,'🔋 Économie batterie','batterySaver');

    var reset=s.add.container(0,304), rbg=s.add.graphics(); rbg.fillStyle(0x2b1930,1); rbg.fillRoundedRect(-pw/2+16,-18,pw-32,36,10); rbg.lineStyle(1.5,0xff6b8a,.65); rbg.strokeRoundedRect(-pw/2+16,-18,pw-32,36,10); reset.add(rbg);
    reset.add(s.add.text(-pw/2+28,0,'Réinitialiser les paramètres',{fontFamily:'Arial, sans-serif',fontSize:'13px',fontStyle:'bold',color:'#ffb7c6'}).setOrigin(0,.5));
    var rh=s.add.zone(0,0,pw-32,36).setInteractive({useHandCursor:true}); reset.add(rh); rh.on('pointerdown',()=>{NEBUSTION.Settings.reset();}); panel.add(reset);

    var acctY=350, acctBtn=s.add.container(0,acctY), abg=s.add.graphics(); abg.fillStyle(0x101a33,1); abg.fillRoundedRect(-pw/2+16,-16,pw-32,32,9); abg.lineStyle(1.5,0x394869,.9); abg.strokeRoundedRect(-pw/2+16,-16,pw-32,32,9); acctBtn.add(abg);
    this.acctLabel=s.add.text(-pw/2+28,0,'Compte',{fontFamily:'Arial, sans-serif',fontSize:'13px',fontStyle:'bold',color:'#c8d4f0'}).setOrigin(0,.5); acctBtn.add(this.acctLabel); acctBtn.add(s.add.text(pw/2-28,0,'›',{fontFamily:'Arial, sans-serif',fontSize:'18px',color:'#7dffb0'}).setOrigin(1,.5));
    var ahit=s.add.zone(0,0,pw-32,32).setInteractive({useHandCursor:true}); acctBtn.add(ahit); ahit.on('pointerdown',()=>{this.toggle(false);if(!s.scene.manager.keys['AccountScene'])return;var key=s.scene.key;s.cameras.main.fadeOut(200,5,7,15);s.cameras.main.once('camerafadeoutcomplete',()=>s.scene.start('AccountScene',{returnTo:key}));}); panel.add(acctBtn);

    var modsY=404, modsBtn=s.add.container(0,modsY), mbg=s.add.graphics(); mbg.fillStyle(0x1a1233,1); mbg.fillRoundedRect(-pw/2+16,-16,pw-32,32,9); mbg.lineStyle(1.5,0x7a2cff,.9); mbg.strokeRoundedRect(-pw/2+16,-16,pw-32,32,9); modsBtn.add(mbg);
    modsBtn.add(s.add.text(-pw/2+28,0,'\uD83E\uDDE9 Mods et plugins',{fontFamily:'Arial, sans-serif',fontSize:'13px',fontStyle:'bold',color:'#c9a8ff'}).setOrigin(0,.5));
    modsBtn.add(s.add.text(pw/2-28,0,'\u203a',{fontFamily:'Arial, sans-serif',fontSize:'18px',color:'#c9a8ff'}).setOrigin(1,.5));
    var mhit=s.add.zone(0,0,pw-32,32).setInteractive({useHandCursor:true}); modsBtn.add(mhit);
    mhit.on('pointerdown',()=>{this.toggle(false);if(!s.scene.manager.keys['ModsScene'])return;var key=s.scene.key;s.cameras.main.fadeOut(200,5,7,15);s.cameras.main.once('camerafadeoutcomplete',()=>s.scene.start('ModsScene',{returnTo:key}));});
    panel.add(modsBtn);

    var tutoY=458, tutoBtn=s.add.container(0,tutoY), tubg=s.add.graphics(); tubg.fillStyle(0x2a2210,1); tubg.fillRoundedRect(-pw/2+16,-16,pw-32,32,9); tubg.lineStyle(1.5,0xffd166,.9); tubg.strokeRoundedRect(-pw/2+16,-16,pw-32,32,9); tutoBtn.add(tubg);
    tutoBtn.add(s.add.text(-pw/2+28,0,'\uD83C\uDF93 Revoir le tutoriel',{fontFamily:'Arial, sans-serif',fontSize:'13px',fontStyle:'bold',color:'#ffd166'}).setOrigin(0,.5));
    tutoBtn.add(s.add.text(pw/2-28,0,'\u203a',{fontFamily:'Arial, sans-serif',fontSize:'18px',color:'#ffd166'}).setOrigin(1,.5));
    var tuhit=s.add.zone(0,0,pw-32,32).setInteractive({useHandCursor:true}); tutoBtn.add(tuhit);
    tuhit.on('pointerdown',()=>{this.toggle(false);if(!NEBUSTION.TutorialOverlay)return;s.time.delayedCall(180,()=>{NEBUSTION.TutorialOverlay.show(s);});});
    panel.add(tutoBtn);

    var atelierY=512, atelierBtn=s.add.container(0,atelierY), telbg=s.add.graphics(); telbg.fillStyle(0x142418,1); telbg.fillRoundedRect(-pw/2+16,-16,pw-32,32,9); telbg.lineStyle(1.5,0x2fbf6a,.9); telbg.strokeRoundedRect(-pw/2+16,-16,pw-32,32,9); atelierBtn.add(telbg);
    atelierBtn.add(s.add.text(-pw/2+28,0,'\uD83D\uDEE0 Mode Atelier',{fontFamily:'Arial, sans-serif',fontSize:'13px',fontStyle:'bold',color:'#7dffb0'}).setOrigin(0,.5));
    atelierBtn.add(s.add.text(pw/2-28,0,'\u203a',{fontFamily:'Arial, sans-serif',fontSize:'18px',color:'#7dffb0'}).setOrigin(1,.5));
    var telhit=s.add.zone(0,0,pw-32,32).setInteractive({useHandCursor:true}); atelierBtn.add(telhit);
    telhit.on('pointerdown',()=>{this.toggle(false);if(!s.scene.manager.keys['AtelierScene'])return;var key=s.scene.key;s.cameras.main.fadeOut(200,5,7,15);s.cameras.main.once('camerafadeoutcomplete',()=>s.scene.start('AtelierScene',{returnTo:key}));});
    panel.add(atelierBtn); this.atelierBtn=atelierBtn;

    panel.add(s.add.text(0,ph-12,'NEBUSTION',{fontFamily:'Arial, sans-serif',fontSize:'10px',color:'#4a5a80'}).setOrigin(.5));
    this.panel=panel;this.panelW=pw;this.panelH=ph;this._refresh();this.backdrop.on('pointerdown',()=>this.toggle(false));
  }
  _label(panel,pw,y,text){panel.add(this.scene.add.text(-pw/2+16,y,text,{fontFamily:'Arial, sans-serif',fontSize:'14px',color:'#c8d4f0'}).setOrigin(0,.5));}
  _settingRow(panel,pw,y,label,key){var s=this.scene; this._label(panel,pw,y,label); var t=this._makeToggle(panel,pw/2-44,y,()=>{var st=NEBUSTION.Settings.get();var p={};p[key]=!st[key];NEBUSTION.Settings.set(p);}); this[key+'Toggle']=t; return t;}
  _makeToggle(panel,x,y,onClick){var s=this.scene,track=s.add.graphics(),pill=s.add.container(x,y),knob=s.add.circle(0,0,10,0xffffff,1);pill.add([track,knob]);var hit=s.add.zone(0,0,56,30).setInteractive({useHandCursor:true});pill.add(hit);hit.on('pointerdown',onClick);panel.add(pill);return {pill,track,knob};}
  _drawToggle(t,on){var w=44,h=22;t.track.clear();t.track.fillStyle(on?0x2ee6a6:0x2a3557,1);t.track.fillRoundedRect(-w/2,-h/2,w,h,h/2);var tx=on?(w/2-h/2):-(w/2-h/2);this.scene.tweens.add({targets:t.knob,x:tx,duration:140,ease:'Sine.easeOut'});}
  _makeStep(panel,x,y,label,onClick){var s=this.scene,c=s.add.container(x,y),bg=s.add.circle(0,0,13,0x1c2b4a,1).setStrokeStyle(1,0x2e9eff,.6),t=s.add.text(0,-1,label,{fontFamily:'Arial, sans-serif',fontSize:'16px',fontStyle:'bold',color:'#eaf2ff'}).setOrigin(.5);c.add([bg,t]);var hit=s.add.zone(0,0,30,30).setInteractive({useHandCursor:true});c.add(hit);hit.on('pointerdown',onClick);panel.add(c);return c;}
  _bumpVolume(dir,sfx){var st=NEBUSTION.Settings.get(),steps=sfx?this.SFX_STEPS:this.VOL_STEPS,key=sfx?'sfxVolume':'musicVolume',idx=0,best=999;steps.forEach((v,i)=>{var d=Math.abs(v-st[key]);if(d<best){best=d;idx=i;}});idx=Math.max(0,Math.min(steps.length-1,idx+dir));var v=steps[idx],p={};p[key]=v;p[sfx?'sfxOn':'musicOn']=v>0;NEBUSTION.Settings.set(p);}
  _refresh(){var st=NEBUSTION.Settings.get();this._drawToggle(this.musicToggle,st.musicOn);this._drawToggle(this.sfxToggle,st.sfxOn);this._drawToggle(this.vibrationToggle,st.vibrationOn);this._drawToggle(this.fxToggle,st.reducedFX);this._drawToggle(this.batteryToggle,st.batterySaver);var max=this.VOL_STEPS[this.VOL_STEPS.length-1],smax=this.SFX_STEPS[this.SFX_STEPS.length-1];this.volLabel.setText(st.musicOn?Math.round(st.musicVolume/max*100)+'%':'Coupé');this.sfxLabel.setText(st.sfxOn?Math.round(st.sfxVolume/smax*100)+'%':'Coupé');if(this.acctLabel){var user=(NEBUSTION.CloudSave&&NEBUSTION.CloudSave.isReady())?NEBUSTION.CloudSave.currentUser():null;var pend=user&&NEBUSTION.CloudSave.getPendingConflict&&NEBUSTION.CloudSave.getPendingConflict();this.acctLabel.setText(pend?'Compte ⚠ choix requis':(user?'Compte connecté':'Compte'));}if(this.atelierBtn){var adminOn=!!(NEBUSTION.AdminMode&&NEBUSTION.AdminMode.isActive());this.atelierBtn.setVisible(adminOn);var tz=this.atelierBtn.list&&this.atelierBtn.list[3];if(tz){if(adminOn)tz.setInteractive({useHandCursor:true});else tz.disableInteractive();}}}
  toggle(force){var open=force===undefined?!this.open:!!force;if(open===this.open)return;this.open=open;this.panel.setVisible(true);if(open)this.backdrop.setInteractive();else this.backdrop.disableInteractive();this.scene.tweens.add({targets:this.panel,alpha:open?1:0,duration:160,ease:'Sine.easeOut',onComplete:()=>{if(!open)this.panel.setVisible(false);}});}
};
