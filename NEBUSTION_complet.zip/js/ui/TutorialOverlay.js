/**
 * NEBUSTION - TutorialOverlay
 * Rendu du tutoriel d'accueil (données/état : NEBUSTION.TutorialManager) : cartes plein écran avec
 * icône, titre, texte, pastilles de progression et boutons Précédent / Suivant / Passer. L'étape « menu »
 * met en évidence l'onglet du menu latéral (NEBUSTION.BottomNav.HANDLE) avec un anneau et une flèche.
 * Utilisation : NEBUSTION.TutorialOverlay.show(scene [, { onClose }]) — depuis n'importe quelle scène.
 * Terminer OU passer marque le tutoriel comme vu (TutorialManager.markDone).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.TutorialOverlay = (function () {
  'use strict';

  var FONT = 'Arial, sans-serif';

  function txt(scene, x, y, s, size, color, extra) {
    var st = { fontFamily: FONT, fontSize: size + 'px', color: color };
    if (extra) for (var k in extra) if (Object.prototype.hasOwnProperty.call(extra, k)) st[k] = extra[k];
    return scene.add.text(x, y, s, st);
  }

  function show(scene, opts) {
    var TM = NEBUSTION.TutorialManager;
    if (!TM || !scene || !scene.add || scene._tutorialOverlay) return null;
    opts = opts || {};
    var steps = TM.steps(), n = steps.length, idx = 0;
    var w = scene.scale.width, h = scene.scale.height;

    var ov = scene.add.container(0, 0).setDepth(2000);
    var api = { container: ov, closed: false };
    scene._tutorialOverlay = api;
    scene.events.once('shutdown', function () { api.closed = true; scene._tutorialOverlay = null; });

    var dim = scene.add.rectangle(w / 2, h / 2, w, h, 0x02040a, 0.84).setInteractive();   // capte les taps : rien ne passe en dessous
    ov.add(dim);
    var nav = NEBUSTION.BottomNav && NEBUSTION.BottomNav.current;
    if (nav && nav.isOpen) nav.toggle(false);

    var content = null, tweens = [];

    function clear() {
      tweens.forEach(function (t) { try { t.stop(); } catch (e) { /* ignore */ } });
      tweens = [];
      if (content) { content.destroy(); content = null; }
    }

    function finish() {
      if (api.closed) return;
      api.closed = true;
      try { TM.markDone(); } catch (e) { /* ignore */ }
      clear();
      scene._tutorialOverlay = null;
      scene.tweens.add({ targets: ov, alpha: 0, duration: 200, onComplete: function () { ov.destroy(); if (typeof opts.onClose === 'function') opts.onClose(); } });
    }

    function button(x, y, bw, bh, label, accent, txtCol, fn) {
      var g = scene.add.graphics();
      g.fillGradientStyle(accent, accent, accentDark(accent), accentDark(accent), 1);
      g.fillRoundedRect(x - bw / 2, y - bh / 2, bw, bh, 18);
      g.lineStyle(2.5, 0xffffff, 0.5);
      g.strokeRoundedRect(x - bw / 2, y - bh / 2, bw, bh, 18);
      content.add(g);
      content.add(txt(scene, x, y, label, 24, txtCol, { fontStyle: '900' }).setOrigin(0.5));
      var z = scene.add.zone(x, y, bw, bh).setOrigin(0.5).setInteractive({ useHandCursor: true });
      z.on('pointerup', fn);
      content.add(z);
    }
    function accentDark(c) {
      var r = ((c >> 16) & 255) * 0.45, gg = ((c >> 8) & 255) * 0.45, b = (c & 255) * 0.45;
      return (Math.round(r) << 16) | (Math.round(gg) << 8) | Math.round(b);
    }

    function render() {
      clear();
      var step = steps[idx], last = idx === n - 1, spotNav = step.spot === 'nav';
      content = scene.add.container(0, 0);
      ov.add(content);
      var pw = w - 60, ph = 610, px = 30, py = spotNav ? 70 : Math.round(h / 2 - ph / 2);
      var cx = w / 2;

      // Carte
      var g = scene.add.graphics();
      g.fillGradientStyle(0x14213f, 0x14213f, 0x070b18, 0x070b18, 1);
      g.fillRoundedRect(px, py, pw, ph, 26);
      g.lineStyle(3.5, 0x00e5ff, 0.95);
      g.strokeRoundedRect(px, py, pw, ph, 26);
      g.lineStyle(1.5, 0xffd166, 0.5);
      g.strokeRoundedRect(px + 7, py + 7, pw - 14, ph - 14, 21);
      content.add(g);

      content.add(txt(scene, cx, py + 92, step.icon, 84, '#ffffff').setOrigin(0.5));
      var title = txt(scene, cx, py + 190, step.title, 36, '#ffd166', { fontStyle: '900', align: 'center', wordWrap: { width: pw - 60 } }).setOrigin(0.5);
      title.setShadow(0, 0, '#ffd166', 10, true, true);
      content.add(title);
      content.add(txt(scene, cx, py + 232, step.text, 24, '#dbe6ff', { align: 'center', wordWrap: { width: pw - 80 }, lineSpacing: 7 }).setOrigin(0.5, 0));

      // Pastilles de progression
      var dotsY = py + ph - 138, dg = scene.add.graphics();
      for (var i = 0; i < n; i++) {
        var dx = cx + (i - (n - 1) / 2) * 26;
        dg.fillStyle(i === idx ? 0x00e5ff : 0x394869, 1);
        dg.fillCircle(dx, dotsY, i === idx ? 7 : 5);
      }
      content.add(dg);

      // Boutons
      var by = py + ph - 64;
      if (idx > 0) button(cx - 150, by, 220, 62, 'Précédent', 0x3a4a78, '#ffffff', function () { idx--; render(); });
      button(idx > 0 ? cx + 120 : cx, by, idx > 0 ? 260 : 340, 62, last ? 'Terminer' : 'Suivant', last ? 0x3fe07f : 0x00e5ff, '#04101c', function () {
        if (last) finish(); else { idx++; render(); }
      });
      if (!last) {
        content.add(txt(scene, px + pw - 26, py + 30, 'Passer ✕', 21, '#9fb0d6', { fontStyle: 'bold' }).setOrigin(1, 0.5));
        var sz = scene.add.zone(px + pw - 90, py + 30, 190, 56).setOrigin(0.5).setInteractive({ useHandCursor: true });
        sz.on('pointerup', finish);
        content.add(sz);
      }
      content.add(txt(scene, px + 28, py + 30, (idx + 1) + ' / ' + n, 20, '#7a89ad', { fontStyle: 'bold' }).setOrigin(0, 0.5));

      // Étape « menu » : met en évidence la barre de menu, désormais toujours déployée en bas de l'écran
      if (spotNav && NEBUSTION.BottomNav && NEBUSTION.BottomNav.HANDLE) {
        var H = NEBUSTION.BottomNav.HANDLE, by0 = h - H.h;
        var rg = scene.add.graphics();
        rg.lineStyle(3, 0x00e5ff, 1); rg.strokeRect(0, by0, w, H.h);
        content.add(rg);
        var ring = scene.add.graphics();
        ring.lineStyle(4, 0xffd166, 1); ring.strokeRoundedRect(-w / 2 + 8, -H.h / 2 + 6, w - 16, H.h - 12, 14);
        ring.setPosition(w / 2, by0 + H.h / 2);
        content.add(ring);
        tweens.push(scene.tweens.add({ targets: ring, alpha: 0.25, duration: 800, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' }));
        var ax = w / 2, ay = by0 - 50;
        var ar = scene.add.graphics();
        ar.fillStyle(0xffd166, 1);
        ar.fillRect(ax - 7, ay - 30, 14, 60);
        ar.fillTriangle(ax - 20, ay + 30, ax + 20, ay + 30, ax, ay + 64);
        content.add(ar);
        content.add(txt(scene, ax, ay - 46, 'Le menu est ici', 24, '#ffd166', { fontStyle: 'bold' }).setOrigin(0.5));
        tweens.push(scene.tweens.add({ targets: ar, y: 10, duration: 600, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' }));
      }

      content.setAlpha(0);
      scene.tweens.add({ targets: content, alpha: 1, duration: 200 });
    }

    render();
    ov.setAlpha(0);
    scene.tweens.add({ targets: ov, alpha: 1, duration: 220 });
    return api;
  }

  return { show: show };
})();
