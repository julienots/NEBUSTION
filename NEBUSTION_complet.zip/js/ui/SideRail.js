/**
 * NEBUSTION - SideRail (menu latéral déroulant, réutilisable)
 * Rail vertical de raccourcis collé à un bord de l'écran, pensé pour ne pas gêner la vue :
 *  - fin et translucide (on voit le décor à travers), compact (hauteur = celle de son contenu) ;
 *  - DÉROULANT : une languette sur son bord intérieur le fait glisser hors de l'écran (et le
 *    ressortir). Le choix du joueur est mémorisé (par écran) d'une visite à l'autre ;
 *  - SCROLLABLE : s'il y a plus de raccourcis que de place, on fait glisser au doigt (avec inertie)
 *    ou à la molette ; une barre fine et des flèches montrent qu'il reste du contenu ;
 *  - un tap (sans glissement) sur un raccourci l'ouvre : UNE seule zone gère glissement ET tap, donc
 *    faire défiler ne déclenche jamais un raccourci par erreur.
 *
 * Usage :
 *   new NEBUSTION.SideRail(this, [
 *     { key: 'heroes', label: 'Héros', color: 0xff4d9e, iconDraw: function (g) { ... }, onClick: function () { ... } }
 *   ], { id: 'accueil', side: 'left', top: 214 });
 *
 * Options : id (clé de mémorisation), side ('left' | 'right'), top, bottom (limite basse, en px de
 * jeu), width, cell (hauteur d'un raccourci), depth, collapsed (état initial si rien n'est mémorisé).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.SideRail = class SideRail {
  constructor(scene, items, opts) {
    opts = opts || {};
    var w = scene.scale.width, h = scene.scale.height;
    this.scene = scene;
    this.items = items || [];
    this.id = opts.id || (scene.sys && scene.sys.settings && scene.sys.settings.key) || 'scene';
    this.side = opts.side === 'right' ? 'right' : 'left';
    this.railW = opts.width || 66;
    this.cell = opts.cell || 76;
    this.pad = 8;
    this.top = opts.top !== undefined ? opts.top : 214;
    this.depth = opts.depth !== undefined ? opts.depth : 50;
    this.tabW = 26;
    this.tabH = 76;

    var bottom = opts.bottom !== undefined ? opts.bottom : h - 100;
    this.contentH = this.items.length * this.cell + this.pad * 2;
    this.viewH = Math.max(this.cell + this.pad * 2, Math.min(this.contentH, bottom - this.top));
    this.maxScroll = Math.max(0, this.contentH - this.viewH);

    // Positions horizontales : ouvert (dans l'écran) / replié (entièrement hors écran, seule la languette dépasse)
    this.openX = this.side === 'left' ? 0 : w - this.railW;
    this.closedX = this.side === 'left' ? -this.railW : w;

    this._scroll = 0;
    this._vel = 0;
    this._down = null;
    this._coast = false;
    this._dead = false;
    this._collapsed = this._loadState(opts.collapsed);
    var x0 = this._collapsed ? this.closedX : this.openX;

    var W = this.railW, V = this.viewH;

    // --- Fond (derrière) : translucide pour laisser voir le décor ---
    this.back = scene.add.container(x0, this.top).setDepth(this.depth - 1);
    var bg = scene.add.graphics();
    bg.fillGradientStyle(0x0d1730, 0x0d1730, 0x05070f, 0x05070f, 0.6, 0.6, 0.78, 0.78);
    bg.fillRoundedRect(0, 0, W, V, this.side === 'left' ? { tl: 0, tr: 16, bl: 0, br: 16 } : { tl: 16, tr: 0, bl: 16, br: 0 });
    bg.lineStyle(2, 0x2a3d6e, 0.85);
    var ex = this.side === 'left' ? W : 0;
    bg.lineBetween(ex, 0, ex, V);
    this.back.add(bg);

    // --- Liste des raccourcis (masquée à la hauteur visible, défile dans son masque) ---
    this.list = scene.add.container(x0, this.top).setDepth(this.depth);
    this._cells = [];
    for (var i = 0; i < this.items.length; i++) this._cells.push(this._buildCell(this.items[i], i));
    this._maskG = scene.make.graphics({ x: 0, y: 0, add: false });
    this._maskG.fillStyle(0xffffff, 1);
    this._maskG.fillRect(0, 0, W, V);
    this._maskG.setPosition(x0, this.top);
    this.list.setMask(this._maskG.createGeometryMask());

    // --- Devant : indicateurs de défilement, zone tactile, languette ---
    this.front = scene.add.container(x0, this.top).setDepth(this.depth + 1);
    this.ind = scene.add.graphics();
    this.front.add(this.ind);

    this.zone = scene.add.zone(W / 2, V / 2, W, V).setInteractive();
    this.front.add(this.zone);

    var tabX = this.side === 'left' ? W + this.tabW / 2 : -this.tabW / 2;
    this.tab = scene.add.container(tabX, Math.min(V / 2, 200));
    this.tabG = scene.add.graphics();
    this.tab.add(this.tabG);
    this.front.add(this.tab);
    // Zone tactile de la languette : un peu plus large que son dessin (gros doigts)
    this.tabZone = scene.add.zone(tabX, this.tab.y, this.tabW + 8, this.tabH + 24).setInteractive();
    this.front.add(this.tabZone);

    this._drawTab();
    this._drawIndicators();
    this._applyPulse();
    this.zone.input.enabled = !this._collapsed;

    this._bindInput();
    scene.events.once('shutdown', this.destroy, this);
    scene.events.once('destroy', this.destroy, this);
  }

  // ---------- État (replié / déplié), mémorisé ----------
  _key() { return 'nebustion_siderail_' + this.id; }

  _loadState(initial) {
    var S = NEBUSTION.SideRail._session;
    if (S.hasOwnProperty(this._key())) return S[this._key()];
    var v = !!initial;
    try {
      var raw = window.localStorage.getItem(this._key());
      if (raw === '1') v = true; else if (raw === '0') v = false;
    } catch (_) {}
    S[this._key()] = v;
    return v;
  }

  _saveState() {
    NEBUSTION.SideRail._session[this._key()] = this._collapsed;
    try { window.localStorage.setItem(this._key(), this._collapsed ? '1' : '0'); } catch (_) {}
  }

  isCollapsed() { return this._collapsed; }
  toggle() { this.setCollapsed(!this._collapsed); }

  setCollapsed(collapsed, instant) {
    if (this._dead) return;
    collapsed = !!collapsed;
    this._collapsed = collapsed;
    this._saveState();
    this._down = null; this._coast = false; this._vel = 0;
    if (this.zone && this.zone.input) this.zone.input.enabled = !collapsed;
    this._drawTab();
    this._applyPulse();

    var self = this, target = collapsed ? this.closedX : this.openX;
    if (this._slide) { this._slide.stop(); this._slide = null; }
    if (instant) { this._moveTo(target); return; }
    var state = { x: this.list.x };
    this._slide = this.scene.tweens.add({
      targets: state, x: target, duration: 240, ease: 'Cubic.easeOut',
      onUpdate: function () { self._moveTo(state.x); },
      onComplete: function () { self._moveTo(target); self._slide = null; }
    });
  }

  /** Déplace d'un bloc toutes les pièces du rail (le masque de la liste suit). */
  _moveTo(x) {
    if (this._dead) return;
    this.back.x = x; this.list.x = x; this.front.x = x;
    this._maskG.x = x;
  }

  /** La languette pulse doucement quand le rail est replié (pour qu'on le retrouve). */
  _applyPulse() {
    if (this._pulse) { this._pulse.stop(); this._pulse = null; }
    this.tab.setAlpha(1);
    if (this._collapsed) {
      this._pulse = this.scene.tweens.add({ targets: this.tab, alpha: 0.55, duration: 900, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    }
  }

  // ---------- Dessin ----------
  _buildCell(item, i) {
    var sc = this.scene, bw = this.railW - 10, bh = this.cell - 8, col = item.color !== undefined ? item.color : 0x00e5ff;
    var c = sc.add.container(this.railW / 2, this.pad + this.cell * i + this.cell / 2);

    var g = sc.add.graphics();
    g.fillGradientStyle(0x151d33, 0x151d33, 0x0b1224, 0x0b1224, 0.92);
    g.fillRoundedRect(-bw / 2, -bh / 2, bw, bh, 14);
    g.lineStyle(2, col, 0.75);
    g.strokeRoundedRect(-bw / 2, -bh / 2, bw, bh, 14);
    c.add(g);

    var ic = sc.add.graphics();
    ic.setPosition(0, -9);
    if (item.iconDraw) item.iconDraw(ic);
    c.add(ic);

    if (item.label) {
      var t = sc.add.text(0, bh / 2 - 15, item.label, {
        fontFamily: 'Arial, sans-serif', fontSize: '10px', fontStyle: 'bold', color: '#b9c6e6'
      }).setOrigin(0.5);
      if (t.width > bw - 6) t.setScale((bw - 6) / t.width);   // « Expéditions » tient dans le rail
      c.add(t);
    }
    this.list.add(c);
    return c;
  }

  _drawTab() {
    var g = this.tabG, tw = this.tabW, th = this.tabH;
    g.clear();
    var r = this.side === 'left' ? { tl: 0, tr: 12, bl: 0, br: 12 } : { tl: 12, tr: 0, bl: 12, br: 0 };
    g.fillStyle(0x0d1730, 0.92);
    g.fillRoundedRect(-tw / 2, -th / 2, tw, th, r);
    g.lineStyle(2, this._collapsed ? 0x00e5ff : 0x2a3d6e, 1);
    g.strokeRoundedRect(-tw / 2, -th / 2, tw, th, r);
    // Chevron : vers le bord de l'écran quand le rail est ouvert (« replier »), vers l'intérieur quand il est replié
    var toLeft = (this.side === 'left') !== this._collapsed;
    var d = toLeft ? -1 : 1;
    g.lineStyle(3, 0x00e5ff, 1);
    g.lineBetween(d * 4, 0, -d * 4, -9);
    g.lineBetween(d * 4, 0, -d * 4, 9);
  }

  _drawIndicators() {
    var g = this.ind, W = this.railW, V = this.viewH;
    g.clear();
    if (this.maxScroll <= 0) return;
    var s = this._scroll, edge = this.side === 'left' ? W - 4 : 4;

    // Barre de défilement fine sur le bord intérieur
    var trackTop = 22, trackH = V - 44;
    var thumbH = Math.max(22, trackH * V / this.contentH);
    var ty = trackTop + (trackH - thumbH) * (s / this.maxScroll);
    g.fillStyle(0xffffff, 0.08);
    g.fillRoundedRect(edge - 1.5, trackTop, 3, trackH, 1.5);
    g.fillStyle(0x00e5ff, 0.75);
    g.fillRoundedRect(edge - 1.5, ty, 3, thumbH, 1.5);

    // Dégradé + flèche là où il reste du contenu caché
    if (s > 2) {
      g.fillGradientStyle(0x05070f, 0x05070f, 0x05070f, 0x05070f, 0.95, 0.95, 0, 0);
      g.fillRect(0, 0, W, 24);
      g.fillStyle(0x00e5ff, 0.9);
      g.fillTriangle(W / 2 - 6, 13, W / 2 + 6, 13, W / 2, 6);
    }
    if (s < this.maxScroll - 2) {
      g.fillGradientStyle(0x05070f, 0x05070f, 0x05070f, 0x05070f, 0, 0, 0.95, 0.95);
      g.fillRect(0, V - 24, W, 24);
      g.fillStyle(0x00e5ff, 0.9);
      g.fillTriangle(W / 2 - 6, V - 13, W / 2 + 6, V - 13, W / 2, V - 6);
    }
  }

  // ---------- Défilement ----------
  _setScroll(v) {
    var c = Phaser.Math.Clamp(v, 0, this.maxScroll);
    var hitEdge = (c !== v);
    this._scroll = c;
    this.list.y = this.top - c;
    this._drawIndicators();
    return hitEdge;
  }

  // ---------- Toucher : UNE zone pour glisser ET taper ----------
  _bindInput() {
    var self = this, sc = this.scene;

    this.tabZone.on('pointerup', function () {
      self._click();
      self.toggle();
    });

    this.zone.on('pointerdown', function (p) {
      if (self._collapsed) return;
      self._down = { x: p.x, y: p.y, scroll: self._scroll, moved: false };
      self._vel = 0; self._coast = false;
      self._lastY = p.y; self._lastT = sc.time.now;
    });

    this._onMove = function (p) {
      var d = self._down;
      if (!d || !p.isDown) return;
      var dy = p.y - d.y;
      if (!d.moved && Math.abs(dy) > 10) d.moved = true;
      if (d.moved && self.maxScroll > 0) {
        self._setScroll(d.scroll - dy);
        var now = sc.time.now, dt = Math.max(1, now - self._lastT);
        self._vel = 0.75 * self._vel + 0.25 * ((self._lastY - p.y) / dt);   // px/ms
        self._lastY = p.y; self._lastT = now;
      }
    };

    this._onUp = function () {
      var d = self._down;
      self._down = null;
      if (!d) return;
      if (d.moved) {
        if (self.maxScroll > 0 && Math.abs(self._vel) > 0.05) self._coast = true;   // inertie après un lancer
        return;
      }
      self._tapAt(d.x, d.y);   // le tap vise là où le doigt a TOUCHÉ
    };

    this._onWheel = function (p, objs, dx, dy) {
      if (self._collapsed || self.maxScroll <= 0) return;
      var lx = p.x - self.list.x, ly = p.y - self.top;
      if (lx < 0 || lx > self.railW || ly < 0 || ly > self.viewH) return;
      self._coast = false;
      self._setScroll(self._scroll + dy * 0.6);
    };

    this._update = function (time, delta) {
      if (!self._coast || self._down) return;
      var hit = self._setScroll(self._scroll + self._vel * delta);
      self._vel *= Math.pow(0.94, delta / 16.7);
      if (hit || Math.abs(self._vel) < 0.02) { self._coast = false; self._vel = 0; }
    };

    sc.input.on('pointermove', this._onMove);
    sc.input.on('pointerup', this._onUp);
    sc.input.on('pointerupoutside', this._onUp);
    sc.input.on('wheel', this._onWheel);
    sc.events.on('update', this._update);
  }

  _tapAt(px, py) {
    var ly = py - this.top;
    var idx = Math.floor((ly + this._scroll - this.pad) / this.cell);
    if (idx < 0 || idx >= this.items.length) return;
    var item = this.items[idx], cellObj = this._cells[idx], self = this;
    this._click();
    this.scene.tweens.add({
      targets: cellObj, scale: 0.9, duration: 70, yoyo: true, ease: 'Sine.easeOut',
      onComplete: function () { if (!self._dead && item.onClick) item.onClick(item); }
    });
  }

  _click() {
    try { if (window.nebustionExtraAudio) window.nebustionExtraAudio.clickSound(1); } catch (_) {}
  }

  destroy() {
    if (this._dead) return;
    this._dead = true;
    var sc = this.scene;
    try {
      if (sc && sc.input) {
        sc.input.off('pointermove', this._onMove);
        sc.input.off('pointerup', this._onUp);
        sc.input.off('pointerupoutside', this._onUp);
        sc.input.off('wheel', this._onWheel);
      }
      if (sc && sc.events) sc.events.off('update', this._update);
      if (this._slide) this._slide.stop();
      if (this._pulse) this._pulse.stop();
      if (this._maskG) this._maskG.destroy();
    } catch (_) {}
  }
};

NEBUSTION.SideRail._session = {};   // état replié/déplié pendant la session (repli si localStorage indisponible)
