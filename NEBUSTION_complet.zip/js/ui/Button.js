/**
 * NEBUSTION - Button
 * Bouton générique réutilisable dans toutes les scènes : fond arrondi,
 * bordure lumineuse, icône vectorielle optionnelle, label, retour tactile animé.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Button = class Button extends Phaser.GameObjects.Container {
  /**
   * @param {Phaser.Scene} scene
   * @param {number} x
   * @param {number} y
   * @param {object} config
   *   width, height, label, iconDraw(graphics) callback, onClick, disabled, accentColor
   */
  constructor(scene, x, y, config) {
    super(scene, x, y);
    config = config || {};

    this.width = config.width || 200;
    this.height = config.height || 64;
    this.accentColor = config.accentColor !== undefined ? config.accentColor : 0x00e5ff;
    this.disabled = !!config.disabled;
    this.onClick = config.onClick || function () {};

    this.bg = scene.add.graphics();
    this.add(this.bg);
    this._drawBackground(1);

    if (config.iconDraw) {
      this.iconGfx = scene.add.graphics();
      config.iconDraw(this.iconGfx, this);
      this.add(this.iconGfx);
    }

    if (config.label) {
      this.labelText = scene.add.text(0, config.iconDraw ? this.height * 0.22 : 0, config.label, {
        fontFamily: 'Arial, sans-serif',
        fontSize: config.fontSize || '22px',
        color: this.disabled ? '#5c6b8a' : '#eaf2ff',
        fontStyle: 'bold'
      }).setOrigin(0.5);
      this.add(this.labelText);
    }

    this.setSize(this.width, this.height);
    // Zone tactile = TOUT le bouton (+ une petite marge pour les gros doigts).
    // ATTENTION : pour un Container, Phaser teste la zone dans un repère dont l'origine est le coin
    // HAUT-GAUCHE du bouton (coordonnées 0..width / 0..height), pas son centre. L'ancienne zone était
    // définie autour du centre (-w/2..w/2) : elle était donc décalée d'une demi-taille vers le haut
    // et la gauche, et seul le bord haut-gauche du bouton répondait au toucher.
    var padX = config.hitPad !== undefined ? config.hitPad : 6;
    var padY = Math.max(padX, (48 - this.height) / 2);   // au moins ~48 px de haut tactile
    this.setInteractive({
      useHandCursor: true,
      hitArea: new Phaser.Geom.Rectangle(-padX, -padY, this.width + padX * 2, this.height + padY * 2),
      hitAreaCallback: Phaser.Geom.Rectangle.Contains
    });

    if (!this.disabled) {
      this.on('pointerover', this._onOver, this);
      this.on('pointerout', this._onOut, this);
      this.on('pointerdown', this._onDown, this);
      this.on('pointerup', this._onUp, this);
      this.on('pointerupoutside', this._onOut, this);   // doigt relâché hors du bouton : il reprend sa taille
    }

    scene.add.existing(this);
  }

  _drawBackground(scaleFactor, hover) {
    var g = this.bg;
    var w = this.width, h = this.height;
    g.clear();

    var fillTop = this.disabled ? 0x1a2233 : 0x151d33;
    var fillBottom = this.disabled ? 0x11172a : 0x0b1224;

    g.fillGradientStyle(fillTop, fillTop, fillBottom, fillBottom, 1);
    g.fillRoundedRect(-w / 2, -h / 2, w, h, h * 0.3);

    var lineColor = this.disabled ? 0x394869 : (hover ? 0xffffff : this.accentColor);
    g.lineStyle(hover ? 3 : 2, lineColor, this.disabled ? 0.4 : (hover ? 1 : 0.75));
    g.strokeRoundedRect(-w / 2, -h / 2, w, h, h * 0.3);

    if (!this.disabled && hover) {
      g.lineStyle(6, this.accentColor, 0.18);
      g.strokeRoundedRect(-w / 2 - 3, -h / 2 - 3, w + 6, h + 6, h * 0.32);
    }
  }

  _onOver() {
    this._drawBackground(1, true);
    this.scene.tweens.add({ targets: this, scale: 1.04, duration: 120, ease: 'Sine.easeOut' });
  }

  _onOut() {
    this._drawBackground(1, false);
    this.scene.tweens.add({ targets: this, scale: 1, duration: 120, ease: 'Sine.easeOut' });
  }

  _onDown() {
    // User-provided quiet button sound. Existing gameplay sounds remain untouched.
    try {
      if (window.nebustionExtraAudio) {
        window.nebustionExtraAudio.clickSound(this._buttonSoundIndex || 1);
        this._buttonSoundIndex = this._buttonSoundIndex === 1 ? 2 : 1;
      }
    } catch (_) {}
    this.scene.tweens.add({ targets: this, scale: 0.94, duration: 70, ease: 'Sine.easeOut' });
  }

  _onUp() {
    this.scene.tweens.add({
      targets: this, scale: 1, duration: 90, ease: 'Sine.easeOut',
      onComplete: () => { this.onClick(); }
    });
  }

  /** Change l'apparence sans changer le comportement (le bouton reste cliquable) : couleur d'accent + couleur du texte. */
  setLook(accentColor, textColor) {
    this.accentColor = accentColor;
    this._drawBackground(1, false);
    if (this.labelText && textColor) this.labelText.setColor(textColor);
  }

  setDisabled(disabled) {
    this.disabled = disabled;
    this._drawBackground(1, false);
    if (this.labelText) this.labelText.setColor(disabled ? '#5c6b8a' : '#eaf2ff');
  }
};
