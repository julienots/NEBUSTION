/**
 * NEBUSTION - FX
 * Effets visuels partagés d'une scène : particules colorées par ressource, textes/gains flottants,
 * anneaux lumineux, notifications (toasts). Une instance par scène : new NEBUSTION.FX(scene).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.FX = class FX {
  constructor(scene) {
    this.scene = scene;
    this.emitters = {};
    this.toasts = [];
    var E = NEBUSTION.Economy;
    E.ORDER.forEach((id) => {
      this.emitters[id] = scene.add.particles(0, 0, 'tex_glow_' + id, {
        emitting: false,
        lifespan: { min: 450, max: 950 },
        speed: { min: 40, max: 170 },
        angle: { min: 0, max: 360 },
        scale: { start: 0.55, end: 0 },
        alpha: { start: 1, end: 0 },
        gravityY: 70,
        blendMode: 'ADD'
      }).setDepth(1055);
    });
  }

  burst(id, x, y, count) { var st=NEBUSTION.Settings.get(); if(st.batterySaver || st.reducedFX) count=Math.max(2, Math.ceil((count || 10)*0.35)); var e = this.emitters[id]; if (e) e.explode(count || 10, x, y); }
  sparkle(id, x, y) { var st=NEBUSTION.Settings.get(); if(st.batterySaver || st.reducedFX) return; var e = this.emitters[id]; if (e) e.emitParticleAt(x, y, 1); }

  ring(x, y, color, size) {
    var st=NEBUSTION.Settings.get(); if(st.batterySaver || st.reducedFX) return;
    var s = this.scene;
    var r = s.add.image(x, y, 'tex_ring_soft').setTint(color).setBlendMode(Phaser.BlendModes.ADD).setDepth(1056).setScale(0.15).setAlpha(0.95);
    s.tweens.add({ targets: r, scale: (size || 1.2), alpha: 0, duration: 550, ease: 'Cubic.easeOut', onComplete: function () { r.destroy(); } });
  }

  /** Texte flottant simple. */
  text(x, y, label, hex, size, rise) {
    var s = this.scene;
    var t = s.add.text(x, y, label, {
      fontFamily: 'Arial, sans-serif', fontSize: (size || 26) + 'px', fontStyle: 'bold', color: hex,
      stroke: '#05070f', strokeThickness: 5
    }).setOrigin(0.5).setDepth(1060);
    s.tweens.add({ targets: t, y: y - (rise || 60), duration: 950, ease: 'Cubic.easeOut' });
    s.tweens.add({ targets: t, alpha: 0, delay: 450, duration: 500, onComplete: function () { t.destroy(); } });
    return t;
  }

  /** Gain de ressource : icône + « +N » qui monte et s'estompe. */
  gain(id, amount, x, y, crit) {
    var s = this.scene, E = NEBUSTION.Economy, def = E.RES[id];
    var label = (crit ? '×3 ' : '') + '+' + E.fmtGain(amount);
    var txt = s.add.text(0, 0, label, {
      fontFamily: 'Arial, sans-serif', fontSize: (crit ? 34 : 28) + 'px', fontStyle: 'bold', color: crit ? '#ffffff' : def.hex,
      stroke: '#05070f', strokeThickness: 5
    }).setOrigin(0, 0.5);
    var icon = s.add.image(0, 0, 'tex_icon_' + id).setDisplaySize(34, 34);
    var total = 34 + 6 + txt.width;
    icon.x = -total / 2 + 17;
    txt.x = -total / 2 + 40;
    var c = s.add.container(x, y, [icon, txt]).setDepth(1060);
    s.tweens.add({ targets: c, y: y - (crit ? 90 : 64), duration: 950, ease: 'Cubic.easeOut' });
    s.tweens.add({ targets: c, alpha: 0, delay: 500, duration: 450, onComplete: function () { c.destroy(); } });
    return c;
  }

  shake(ms, amp) { try { var st=NEBUSTION.Settings.get(); if(st.batterySaver) return; if(st.reducedFX){ ms=Math.round((ms||90)*0.45); amp=(amp||0.003)*0.45; } this.scene.cameras.main.shake(ms || 90, amp || 0.003); } catch (e) { /* ignore */ } }
  vibrate(ms) { try { var st=NEBUSTION.Settings.get(); if(!st.vibrationOn || st.batterySaver) return; navigator.vibrate && navigator.vibrate(ms || 15); } catch (e) { /* ignore */ } }

  /** Notification en haut de l'écran (max 3 empilées). */
  toast(title, sub, id) {
    var s = this.scene, w = s.scale.width;
    var E = NEBUSTION.Economy;
    var color = id ? E.RES[id].color : 0xffd166;
    while (this.toasts.length >= 3) this._dropToast(this.toasts[0], true);

    var c = s.add.container(w / 2, 0).setDepth(1300).setAlpha(0);
    var bg = s.add.graphics();
    bg.fillStyle(0x0b1224, 0.94); bg.fillRoundedRect(-290, -38, 580, 76, 18);
    bg.lineStyle(2, color, 0.9); bg.strokeRoundedRect(-290, -38, 580, 76, 18);
    c.add(bg);
    if (id) c.add(s.add.image(-256, 0, 'tex_icon_' + id).setDisplaySize(44, 44));
    c.add(s.add.text(id ? -222 : -270, sub ? -12 : 0, title, { fontFamily: 'Arial, sans-serif', fontSize: '25px', fontStyle: 'bold', color: '#eaf2ff' }).setOrigin(0, 0.5));
    if (sub) c.add(s.add.text(id ? -222 : -270, 16, sub, { fontFamily: 'Arial, sans-serif', fontSize: '21px', color: '#a9b8dc' }).setOrigin(0, 0.5));

    var t = { c: c };
    this.toasts.push(t);
    this._layoutToasts();
    s.tweens.add({ targets: c, alpha: 1, duration: 220 });
    t.timer = s.time.delayedCall(2800, () => this._dropToast(t, false));
    return c;
  }

  _layoutToasts() {
    var s = this.scene, baseY = 215;
    this.toasts.forEach((t, i) => {
      s.tweens.add({ targets: t.c, y: baseY + i * 88, duration: 220, ease: 'Sine.easeOut' });
    });
  }

  _dropToast(t, instant) {
    var i = this.toasts.indexOf(t);
    if (i < 0) return;
    this.toasts.splice(i, 1);
    if (t.timer) t.timer.remove(false);
    var c = t.c, s = this.scene;
    if (instant) { c.destroy(); }
    else { s.tweens.add({ targets: c, alpha: 0, duration: 250, onComplete: function () { c.destroy(); } }); }
    this._layoutToasts();
  }
};
