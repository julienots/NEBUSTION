/**
 * NEBUSTION - OfflineModal
 * Fenêtre « Bon retour » : récapitulatif de la production hors ligne.
 * Les gains sont DÉJÀ crédités au moment du retour (rien à « réclamer » : impossible de les perdre ou de les doubler).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.OfflineModal = {
  show: function (scene, report, onClose) {
    var E = NEBUSTION.Economy, w = scene.scale.width, h = scene.scale.height;
    var items = [];
    var lines = E.ORDER.filter(function (id) { return report.gains[id] > 0.0001; });
    var anyLost = E.ORDER.some(function (id) { return report.lost[id] > 0.5; });

    var dim = scene.add.rectangle(w / 2, h / 2, w, h, 0x000000, 0.75).setDepth(2000).setInteractive();
    items.push(dim);
    var ch = 250 + lines.length * 62 + (anyLost ? 40 : 0) + (report.truncated ? 40 : 0) + 96;
    var cw = w - 60, cy = h / 2 - 20;
    var c = scene.add.container(w / 2, cy).setDepth(2001).setScale(0.85).setAlpha(0);
    items.push(c);
    var bg = scene.add.graphics();
    bg.fillGradientStyle(0x14204a, 0x14204a, 0x0a1128, 0x0a1128, 1);
    bg.fillRoundedRect(-cw / 2, -ch / 2, cw, ch, 26);
    bg.lineStyle(3, 0x00e5ff, 0.8); bg.strokeRoundedRect(-cw / 2, -ch / 2, cw, ch, 26);
    c.add(bg);

    var top = -ch / 2;
    c.add(scene.add.text(0, top + 48, 'BON RETOUR, COMMANDANT', { fontFamily: 'Arial, sans-serif', fontSize: '32px', fontStyle: '900', color: '#eaf2ff' }).setOrigin(0.5).setShadow(0, 0, '#00e5ff', 12, true, true));
    c.add(scene.add.text(0, top + 98, 'Vos drones ont travaillé pendant ' + E.fmtDuration(report.seconds), { fontFamily: 'Arial, sans-serif', fontSize: '24px', color: '#a9b8dc' }).setOrigin(0.5));
    c.add(scene.add.text(0, top + 130, 'Rendement hors ligne : ' + Math.round(report.efficiency * 100) + ' %', { fontFamily: 'Arial, sans-serif', fontSize: '21px', color: '#7a89ad' }).setOrigin(0.5));

    var counters = [];
    lines.forEach(function (id, i) {
      var def = E.RES[id], y = top + 190 + i * 62;
      c.add(scene.add.image(-cw / 2 + 60, y, 'tex_icon_' + id).setDisplaySize(46, 46));
      c.add(scene.add.text(-cw / 2 + 100, y, def.name, { fontFamily: 'Arial, sans-serif', fontSize: '26px', color: '#eaf2ff' }).setOrigin(0, 0.5));
      var t = scene.add.text(cw / 2 - 36, y, '+0', { fontFamily: 'Arial, sans-serif', fontSize: '32px', fontStyle: 'bold', color: def.hex }).setOrigin(1, 0.5);
      c.add(t);
      counters.push({ t: t, id: id, target: report.gains[id] });
    });
    if (!lines.length) c.add(scene.add.text(0, top + 210, 'Stockage plein : rien à ajouter.', { fontFamily: 'Arial, sans-serif', fontSize: '24px', color: '#ff8fa3' }).setOrigin(0.5));

    var noteY = top + 190 + Math.max(lines.length, 1) * 62 + 8;
    if (report.truncated) { c.add(scene.add.text(0, noteY, 'Absence limitée à ' + (E.CFG.OFFLINE_MAX_SEC / 3600) + ' h de production.', { fontFamily: 'Arial, sans-serif', fontSize: '21px', color: '#ffd166' }).setOrigin(0.5)); noteY += 36; }
    if (anyLost) c.add(scene.add.text(0, noteY, '⚠ Stockage plein : une partie de la production a été perdue.', { fontFamily: 'Arial, sans-serif', fontSize: '21px', color: '#ff8fa3' }).setOrigin(0.5));

    var closed = false;
    function close() {
      if (closed) return; closed = true;
      scene.tweens.add({ targets: c, alpha: 0, scale: 0.9, duration: 200, onComplete: function () { items.forEach(function (o) { if (o && o.destroy) o.destroy(); }); if (onClose) onClose(); } });
      dim.destroy();
    }
    var btn = new NEBUSTION.Button(scene, 0, ch / 2 - 56, { width: 300, height: 68, label: 'CONTINUER', fontSize: '26px', accentColor: 0x00e5ff, onClick: close });
    c.add(btn);

    scene.tweens.add({ targets: c, alpha: 1, scale: 1, duration: 320, ease: 'Back.easeOut' });
    scene.tweens.addCounter({
      from: 0, to: 1, duration: 1300, ease: 'Cubic.easeOut',
      onUpdate: function (tw) {
        var k = tw.getValue();
        counters.forEach(function (o) { if (o.t.active) o.t.setText('+' + E.fmtGain(o.target * k)); });
      },
      onComplete: function () { counters.forEach(function (o) { if (o.t.active) o.t.setText('+' + E.fmtGain(o.target)); }); }
    });
  }
};
