/**
 * NEBUSTION - EmpireEvolutionManager
 * Module IA 3/3 : fait évoluer les 5 empires dans le temps, à partir de l'existant :
 *  - posture/effets : EmpireAIManager.decide()/intents()  (aucune décision recréée ici)
 *  - planètes/conquêtes : Galaxy + GalaxyManager
 *  - persistance : `NEBUSTION.Resources.state.empires` (validé par SaveManager → EmpireEvolution.normalizeState)
 *
 * Impact réel sur la galaxie :
 *  - battleSpec(pid) : défense évoluée (bouclier, tourelles, unités de renfort) + posture appliquée, à
 *    utiliser à la place de Galaxy.battleSpec() par le module d'invasion ;
 *  - contre-offensive : un empire offensif et assez fort peut reprendre une planète conquise depuis
 *    longtemps (GalaxyManager.setConquered(pid, false)), au plus une fois / 24 h et jamais une capitale ;
 *  - ses revenus disparaissent avec ses planètes (capitale tombée = −50 %, empire vaincu = plus rien).
 *
 * Idempotent : update() ne rejoue jamais un pas déjà simulé (lastAt), start() ne crée qu'un seul minuteur.
 * 100 % hors ligne. Non chargé par index.html tant que la scène Galaxie n'existe pas (comme les modules 1 et 2).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.EmpireEvolutionManager = (function () {
  'use strict';

  var EE = function () { return NEBUSTION.EmpireEvolution; };
  var G = function () { return NEBUSTION.Galaxy; };
  var GM = function () { return NEBUSTION.GalaxyManager; };
  var AIM = function () { return NEBUSTION.EmpireAIManager; };
  var AI = function () { return NEBUSTION.EmpireAI; };
  var DR = function () { return NEBUSTION.EmpireDoctrine || null; };
  var DAY = 24 * 3600 * 1000;
  function r2(x) { return Math.round(x * 100) / 100; }
  function r4(x) { return Math.round(x * 10000) / 10000; }
  function clamp01(x) { return Math.max(0, Math.min(1, x)); }

  var listeners = {};
  function on(evt, fn) { (listeners[evt] = listeners[evt] || []).push(fn); return function () { off(evt, fn); }; }
  function off(evt, fn) { if (listeners[evt]) listeners[evt] = listeners[evt].filter(function (f) { return f !== fn; }); }
  function emit(evt, data) { (listeners[evt] || []).slice().forEach(function (f) { try { f(data); } catch (e) { console.error('EmpireEvolutionManager listener', e); } }); }

  var timer = null;
  function nowOf(now) { return (typeof now === 'number' && isFinite(now)) ? now : Date.now(); }
  function root() { return NEBUSTION.Resources && NEBUSTION.Resources.state; }
  function state(now) {
    var r = root();
    if (!r) return EE().defaultState(nowOf(now));
    if (!r.empires) r.empires = EE().normalizeState(null, nowOf(now));
    return r.empires;
  }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }

  function planetsCtx(eid) {
    return G().planetsOfEmpire(eid).map(function (p) {
      return { id: p.id, tier: p.tier, threat: p.threat, isCapital: p.isCapital, deposits: p.deposits, owned: !GM().isConquered(p.id) };
    });
  }
  function targetsOf(eid, now) {
    var t = {};
    try {
      AIM().intents(eid, now).forEach(function (i) {
        if (i.target && (i.type === 'reinforceDefense' || i.type === 'fortifyBorder' || i.type === 'counterOffensive')) t[i.target] = Math.max(t[i.target] || 0, i.priority * 0.5);
      });
    } catch (e) { /* IA indisponible : on garde la dépense neutre */ }
    return t;
  }
  /** Décision de l'IA + évolution : la stratégie se renforce avec le développement et l'élan de l'empire (bornée ensuite par les plafonds de planetView). */
  function decisionOf(eid, now) {
    try {
      var d = AIM().decide(eid, now);
      if (!d) return d;
      var es = state(now).e[eid], k = 1 + 0.015 * es.evo, mo = es.mom || 0, ef = d.effects, o = {};
      Object.keys(d).forEach(function (key) { o[key] = d[key]; });
      o.effects = { shieldMult: r2(ef.shieldMult * k), turretMult: r2(ef.turretMult * k), reinforceRate: r2(ef.reinforceRate * (1 + 0.15 * mo)), counterChance: r2(Math.min(1, ef.counterChance * (1 + 0.3 * mo))) };
      return o;
    } catch (e) { return null; }
  }

  // ---------- Carte : distances par les routes, revendications ----------
  /** Distance (en routes) entre un monde et la planète NON conquise la plus proche de l'empire ; -1 si hors de portée. */
  function reachFrom(eid, pid) {
    var seen = {}, front = [pid], depth = 0;
    seen[pid] = true;
    while (front.length && depth <= EE().CLAIM.reach) {
      for (var i = 0; i < front.length; i++) {
        var p = G().planet(front[i]);
        if (p && p.empire === eid && !GM().isConquered(p.id)) return depth;
      }
      var next = [];
      front.forEach(function (id) { G().neighbors(id).forEach(function (n) { if (!seen[n]) { seen[n] = true; next.push(n); } }); });
      front = next; depth += 1;
    }
    return -1;
  }
  function claimedBy(pid) {
    var st = state(), hit = null;
    G().EMPIRE_ORDER.forEach(function (eid) { if (st.e[eid] && st.e[eid].claims[pid] !== undefined) hit = eid; });
    return hit;
  }

  // ---------- Mémoire des pertes (idempotent : une planète perdue n'est comptée qu'UNE fois) ----------
  /**
   * Compare la carte (GalaxyManager.conquered) à la mémoire des empires : nouvelle perte → traumatisme (`hurt`)
   * proportionnel à la fraîcheur de la conquête (une conquête ancienne ne « choque » plus), planète reprise → oubliée,
   * revendications invalides (monde conquis par le joueur, plus d'ancrage) → retirées.
   */
  function reconcile(now) {
    now = nowOf(now);
    var st = state(now), conq = GM().state().conquered, changed = false;
    G().EMPIRE_ORDER.forEach(function (eid) {
      var es = st.e[eid];
      G().planetsOfEmpire(eid).forEach(function (p) {
        var c = conq[p.id], known = es.lostAt[p.id] !== undefined;
        if (c && !known) {
          es.lostAt[p.id] = c; es.lost = Math.min(1e6, es.lost + 1);
          var fresh = clamp01(1 - (now - c) / DAY);
          es.hurt = r4(Math.min(1, es.hurt + (0.25 + 0.06 * p.tier + (p.isCapital ? 0.3 : 0)) * fresh));
          changed = true;
        } else if (!c && known) { delete es.lostAt[p.id]; changed = true; }
      });
      Object.keys(es.claims).forEach(function (pid) {
        if (conq[pid] || reachFrom(eid, pid) < 0) { delete es.claims[pid]; changed = true; }
      });
    });
    if (changed) { try { AIM().invalidate(); } catch (e) { /* ignore */ } }
    return changed;
  }

  // ---------- Revendication de mondes neutres (expansion) ----------
  function tryClaim(eid, es, st, dec, now) {
    var C = EE().CLAIM, perso = AI().PERSONALITY[eid] || {};
    if (!dec || es.evo < C.minEvo || dec.posture === 'defensive' || (perso.expansion || 0) < C.minExpansion) return null;
    if (Object.keys(es.claims).length >= C.maxPerEmpire || (es.lastClaim && now - es.lastClaim < C.cooldownMs)) return null;
    var cand = G().PLANETS.filter(function (p) {
      return p.kind === 'neutral' && !GM().isConquered(p.id) && !claimedBy(p.id) && reachFrom(eid, p.id) >= 0;
    }).map(function (p) { return { p: p, d: reachFrom(eid, p.id) }; }).sort(function (a, b) { return a.d - b.d || b.p.tier - a.p.tier; });
    if (!cand.length) return null;
    var chance = C.chanceK * AI().difficultyProfile(AIM().difficultyId()).reactivity * (0.5 + (perso.expansion || 0));
    if (EE().rand01(st.seed, st.n, eid.length * 17 + eid.charCodeAt(1) + 977) >= chance) return null;
    if (!EE().pay(es, eid, C.cost)) return null;
    es.claims[cand[0].p.id] = now; es.lastClaim = now; es.spent = Math.min(1e15, es.spent + C.cost);
    return cand[0].p.id;
  }

  // ---------- Contre-offensive ----------
  function tryRecapture(eid, es, st, decision, now) {
    var R = EE().RECAPTURE;
    if (!decision || es.evo < R.minEvo || (es.lastRec && now - es.lastRec < R.cooldownMs)) return null;
    var conq = GM().state().conquered, team = GM().teamLevel();
    var cand = G().planetsOfEmpire(eid).filter(function (p) {
      if (p.isCapital || !GM().isConquered(p.id)) return false;
      if (now - (conq[p.id] || now) < R.graceMs) return false;                       // trop récente : le joueur a le temps de la tenir
      var v = EE().planetView(eid, p.id, es);
      return v && v.recLevel >= R.powerGate * team;                                  // trop faible face au joueur : pas de riposte
    }).sort(function (a, b) { return b.tier - a.tier; });
    if (!cand.length) return null;
    var chance = decision.effects.counterChance * R.chanceK * (decision.posture === 'defensive' ? 0.25 : 1);
    if (EE().rand01(st.seed, st.n, eid.length * 31 + eid.charCodeAt(0)) >= chance) return null;
    var target = cand[0], cost = EE().recaptureCost(target.threat);
    if (!EE().pay(es, eid, cost)) return null;
    GM().setConquered(target.id, false, now);
    var d = es.def[target.id];
    if (d) { d.sh = Math.floor(d.sh / 2); d.tu = Math.floor(d.tu / 2); d.fl = Math.floor(d.fl / 2); if (!(d.sh || d.tu || d.fl)) delete es.def[target.id]; }
    es.lastRec = now; es.rec += 1; es.spent = Math.min(1e15, es.spent + cost); es.mom = r4(Math.min(1, es.mom + 0.3));
    return target.id;
  }

  // ---------- Simulation ----------
  /**
   * Fait avancer les empires jusqu'à `now`. Rattrape au plus 24 h ; l'excédent est abandonné.
   * @returns {{steps:number, truncated:boolean, upgrades:number, recaptured:string[]}}
   */
  function update(now) {
    now = nowOf(now);
    var st = state(now), out = { steps: 0, truncated: false, upgrades: 0, recaptured: [], claimed: [] };
    reconcile(now);                                           // les pertes récentes du joueur sont prises en compte avant toute simulation
    if (!(now > st.lastAt)) return out;                       // même instant ou horloge reculée : rien à rejouer
    var steps = Math.floor((now - st.lastAt) / EE().STEP_MS);
    if (steps < 1) return out;
    var n = Math.min(steps, EE().MAX_CATCHUP_STEPS);
    out.truncated = steps > n; out.steps = n;
    var diff = AIM().difficultyId(), ceiling = EE().ceilingFor(GM().teamLevel(), diff);
    var ids = AI().empireIds(), dec = {}, tg = {};
    ids.forEach(function (eid) { dec[eid] = decisionOf(eid, now); tg[eid] = targetsOf(eid, now); });   // la posture ne change pas pendant une absence
    for (var i = 0; i < n; i++) {
      st.n += 1;
      ids.forEach(function (eid) {
        var es = st.e[eid], d = dec[eid], pl = planetsCtx(eid), tNow = st.lastAt + (i + 1) * EE().STEP_MS;
        var sit = AIM().lastSituation(eid) || {};
        var rep = EE().stepEmpire(es, {
          eid: eid, planets: pl, posture: d ? d.posture : 'balanced', reinforceRate: d ? d.effects.reinforceRate : 1,
          targets: tg[eid], ceiling: ceiling, pressure: sit.pressure || 0,
          lossRatio: pl.length ? pl.filter(function (p) { return !p.owned; }).length / pl.length : 0,
          capitalLost: pl.some(function (p) { return p.isCapital && !p.owned; })
        });
        out.upgrades += rep.upgrades.length;
        var back = tryRecapture(eid, es, st, d, tNow);
        if (back) {
          out.recaptured.push(back); emit('recapture', { empire: eid, planet: back });
          reconcile(tNow); dec[eid] = decisionOf(eid, now); tg[eid] = targetsOf(eid, now);      // la carte a changé : l'empire réévalue sa situation
        }
        var claim = tryClaim(eid, es, st, dec[eid], tNow);
        if (claim) { out.claimed.push(claim); emit('claim', { empire: eid, planet: claim }); }
      });
    }
    st.lastAt = out.truncated ? now : st.lastAt + n * EE().STEP_MS;
    save();
    emit('evolve', out);
    if (out.recaptured.length || out.claimed.length) AIM().invalidate();
    return out;
  }

  // ---------- Lecture (synchronise d'abord : jamais de vue périmée) ----------
  /** Défense évoluée + récompenses d'une planète d'empire, ou d'un monde neutre revendiqué (sinon null). */
  function planetInfo(pid, now) {
    now = nowOf(now); update(now);
    var p = G().planet(pid);
    if (!p) return null;
    if (p.empire) {
      var d = decisionOf(p.empire, now);
      return EE().planetView(p.empire, pid, state(now).e[p.empire], d ? d.effects : null);
    }
    var cb = p.kind === 'neutral' ? claimedBy(pid) : null;
    return cb ? EE().claimView(cb, pid, state(now).e[cb]) : null;
  }

  /** Remplace Galaxy.battleSpec() : mêmes champs + capacités/bonus/posture (défense évoluée ; monde libre non revendiqué : spec d'origine). */
  function battleSpec(pid, now) {
    now = nowOf(now);
    var spec = G().battleSpec(pid), v = planetInfo(pid, now);
    if (!spec || !v) return spec;
    var list = [];
    v.fleet.forEach(function (g) {
      var u = G().unitDef(g.unit); if (u && DR()) u = DR().rankedDef(u, g.rank || 0);
      if (u) for (var i = 0; i < g.count; i++) list.push(u);
    });
    var waves = [];
    for (var i = 0; i < list.length; i += 3) waves.push(list.slice(i, i + 3));
    var rewards = {};
    Object.keys(spec.rewards).forEach(function (k) {
      var x = spec.rewards[k];
      rewards[k] = (k === 'first' || typeof x !== 'number') ? x : (k === 'core' ? Math.max(1, Math.round(x * v.rewardMult)) : Math.round(x * v.rewardMult));
    });
    spec.waves = waves; spec.scale = v.scale; spec.recLevel = v.recLevel; spec.rewards = rewards; spec.shield = v.shield; spec.turrets = v.turrets;
    var eid = v.empire || v.claimedBy, es = eid ? state(now).e[eid] : null, d = eid ? decisionOf(eid, now) : null;
    spec.bonus = v.bonus || {}; spec.capabilities = v.capabilities || [];
    spec.claimedBy = v.claimedBy || null; spec.evo = es ? es.evo : 0;
    spec.posture = d ? d.posture : null; spec.strategy = d ? d.name : null; spec.alert = eid ? alertOf(eid, now) : 0;
    return spec;
  }

  /** Bilan d'un empire : développement, plafond, puissance actuelle vs d'origine, stock, posture. */
  function empireStatus(eid, now) {
    now = nowOf(now); update(now);
    var E = G().empire(eid); if (!E) return null;
    var es = state(now).e[eid], d = decisionOf(eid, now), power = 0, base = 0, owned = 0;
    G().planetsOfEmpire(eid).forEach(function (p) {
      if (GM().isConquered(p.id)) return;
      owned += 1; base += p.power;
      power += EE().planetView(eid, p.id, es, d ? d.effects : null).power;
    });
    return {
      empire: eid, evo: es.evo, maxEvo: EE().MAX_EVO, ceiling: EE().ceilingFor(GM().teamLevel(), AIM().difficultyId()),
      owned: owned, total: G().planetsOfEmpire(eid).length, power: power, basePower: base,
      growth: base > 0 ? Math.round(power / base * 100) / 100 : 0,
      wealth: Math.round(EE().wealth(es, eid)), res: JSON.parse(JSON.stringify(es.res)),
      upgrades: es.ups, recaptures: es.rec,
      strategy: d ? d.name : null, posture: d ? d.posture : null,
      focus: focusOf(eid, es, d), alert: alertOf(eid, now), hurt: es.hurt, momentum: es.mom, lost: es.lost, held: es.held,
      ranks: JSON.parse(JSON.stringify(es.rank)), claims: Object.keys(es.claims),
      capabilities: DR() ? DR().capabilities(eid, es.evo, es.hurt).list.map(function (c) { return c.id; }) : []
    };
  }

  function focusOf(eid, es, d) {
    if (!DR()) return 'growth';
    var pl = planetsCtx(eid), sit = AIM().lastSituation(eid) || {};
    return DR().adaptation({ posture: d ? d.posture : 'balanced', lossRatio: pl.length ? pl.filter(function (p) { return !p.owned; }).length / pl.length : 0,
      capitalLost: pl.some(function (p) { return p.isCapital && !p.owned; }), hurt: es.hurt, pressure: sit.pressure || 0, momentum: es.mom, stockRatio: EE().stockRatio(es, G().empire(eid)) }).focus;
  }
  /** Niveau d'alerte 0..3 d'un empire (pour colorer/annoter son secteur sur la carte). */
  function alertOf(eid, now) {
    var es = state(now).e[eid], sit = AIM().assess(eid, nowOf(now));
    return Math.round(clamp01(Math.max(es.hurt, sit.pressure * 0.6, sit.lossRatio * 0.5)) * 3);
  }

  // ---------- Carte galactique / invasions ----------
  /** Une planète est atteignable si une route la relie à Nexus-01 ou à un monde déjà conquis. */
  function isReachable(pid) {
    var p = G().planet(pid);
    if (!p || p.kind === 'home') return false;
    return G().neighbors(pid).some(function (n) { var q = G().planet(n); return q && (q.kind === 'home' || GM().isConquered(n)); });
  }
  /** Vue complète pour la scène Galaxie : chaque planète (état, défense évoluée, alerte) + bilan des empires. */
  function mapView(now) {
    now = nowOf(now); update(now);
    var out = { at: now, difficulty: AIM().difficultyId(), teamLevel: Math.round(GM().teamLevel() * 10) / 10, empires: {}, planets: [] };
    G().EMPIRE_ORDER.forEach(function (eid) {
      var es = state(now).e[eid], d = decisionOf(eid, now);
      out.empires[eid] = { evo: es.evo, posture: d ? d.posture : null, strategy: d ? d.name : null, focus: focusOf(eid, es, d), alert: alertOf(eid, now), hurt: es.hurt,
        owned: G().planetsOfEmpire(eid).filter(function (p) { return !GM().isConquered(p.id); }).length, total: G().planetsOfEmpire(eid).length, claims: Object.keys(es.claims) };
    });
    G().PLANETS.forEach(function (p) {
      if (p.kind === 'home') return;
      var v = planetInfo(p.id, now), eid = p.empire || (v && v.claimedBy) || null, conq = GM().isConquered(p.id);
      out.planets.push({
        id: p.id, name: p.name, sector: p.sector, kind: p.kind, empire: p.empire, claimedBy: v ? v.claimedBy || null : null,
        conquered: conq, unlocked: GM().isSectorUnlocked(p.sector), scanned: GM().isScanned(p.id, now), reachable: isReachable(p.id),
        frontier: !conq && isReachable(p.id), canInvade: GM().canInvade(p.id, now).ok,
        power: v ? v.power : p.power, recLevel: v ? v.recLevel : p.recLevel, shield: v ? v.shield : p.defense.shield, turrets: v ? v.turrets : p.defense.turrets,
        levels: v ? v.levels : null, alert: eid ? out.empires[eid] ? out.empires[eid].alert : 0 : 0, posture: eid && out.empires[eid] ? out.empires[eid].posture : null
      });
    });
    return out;
  }
  /** Tout ce que le module d'invasion doit savoir avant d'attaquer une planète (lecture seule). */
  function invasionPlan(pid, now) {
    now = nowOf(now);
    var p = G().planet(pid);
    if (!p || p.kind === 'home') return null;
    var spec = battleSpec(pid, now), can = GM().canInvade(pid, now), team = GM().teamLevel();
    var ratio = r2(team / Math.max(1, spec.recLevel));
    var eid = p.empire || spec.claimedBy || null, d = eid ? decisionOf(eid, now) : null;
    return {
      planet: pid, name: p.name, empire: p.empire, claimedBy: spec.claimedBy, canInvade: can.ok, reason: can.ok ? null : can.reason,
      reachable: isReachable(pid), frontier: !GM().isConquered(pid) && isReachable(pid), spec: spec, recLevel: spec.recLevel, teamLevel: Math.round(team * 10) / 10,
      ratio: ratio, verdict: ratio < 0.75 ? 'deconseille' : ratio < 1 ? 'risque' : ratio < 1.3 ? 'equilibre' : 'favorable',
      posture: d ? d.posture : null, strategy: d ? d.name : null, alert: spec.alert, capabilities: spec.capabilities, bonus: spec.bonus, rewards: spec.rewards
    };
  }
  /**
   * Résultat d'une invasion (point d'entrée UNIQUE pour le futur module d'invasion). Idempotent.
   * victoire : conquête enregistrée (si scan valide, non déjà conquise) + traumatisme de l'empire ;
   * défaite  : l'empire « a tenu » → élan (renfort/entraînement accrus, borné) et traumatisme atténué.
   */
  function resolveInvasion(pid, victory, now) {
    now = nowOf(now); update(now);
    var p = G().planet(pid);
    if (!p || p.kind === 'home') return { ok: false, reason: 'invalid' };
    var eid = p.empire || claimedBy(pid);
    if (victory) {
      var c = GM().canInvade(pid, now);
      if (!c.ok) { reconcile(now); return { ok: false, reason: c.reason }; }
      GM().setConquered(pid, true, now);
      reconcile(now); save();
      return { ok: true, conquered: true, empire: eid || null };
    }
    if (!eid) return { ok: true, conquered: false, empire: null };
    var es = state(now).e[eid];
    es.held = Math.min(1e6, es.held + 1); es.mom = r4(Math.min(1, es.mom + 0.25)); es.hurt = r4(Math.max(0, es.hurt - 0.1));
    try { AIM().invalidate(eid); } catch (e) { /* ignore */ }
    save(); emit('held', { empire: eid, planet: pid });
    return { ok: true, conquered: false, empire: eid, held: es.held };
  }

  var wired = false;
  /** Réagit immédiatement aux conquêtes (pas d'attente du prochain pas). Un seul abonnement, quel que soit le nombre d'appels. */
  function wire() {
    if (wired || !GM() || !GM().on) return;
    wired = true;
    GM().on('conquest', function () { if (reconcile(Date.now())) save(); });
  }

  /** Démarre l'évolution : rattrapage immédiat + un seul minuteur (rappels multiples sans effet). */
  function start(opts) {
    wire(); update(Date.now());
    if (!timer && typeof setInterval === 'function') {
      timer = setInterval(function () { update(Date.now()); }, (opts && opts.everyMs) || 60000);
      if (timer && timer.unref) timer.unref();
    }
    return true;
  }
  function stop() { if (timer) { clearInterval(timer); timer = null; } }
  function isRunning() { return !!timer; }

  return {
    on: on, off: off, state: state, update: update, start: start, stop: stop, isRunning: isRunning,
    planetInfo: planetInfo, battleSpec: battleSpec, empireStatus: empireStatus,
    reconcile: reconcile, wire: wire, mapView: mapView, invasionPlan: invasionPlan, resolveInvasion: resolveInvasion, isReachable: isReachable, alertOf: alertOf, claimedBy: claimedBy
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.EmpireEvolutionManager; }
