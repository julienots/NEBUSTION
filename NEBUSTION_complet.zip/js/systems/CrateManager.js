/**
 * NEBUSTION - CrateManager
 * Glue entre NEBUSTION.Crates (données pures) et la sauvegarde / économie / skins / équipement / héros.
 * État dans NEBUSTION.Resources.state.crates (couvert par la sauvegarde automatique).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.CrateManager = (function () {
  'use strict';

  var K = function () { return NEBUSTION.Crates; };
  var root = function () { return NEBUSTION.Resources && NEBUSTION.Resources.state; };

  function state() {
    var r = root();
    if (!r) return K().defaultState();
    if (!r.crates) r.crates = K().normalizeState(null);
    return r.crates;
  }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }

  // ---------- Lecture ----------
  function crates(tier) { return state().crates[tier] || 0; }
  function keys(tier) { return state().keys[tier] || 0; }
  function shards() { return state().shards || 0; }
  function pity() { return Object.assign({}, state().pity); }
  function opened() { return state().opened || 0; }
  function history() { return state().history.slice(); }
  function totalCrates() { return K().TIERS.reduce(function (n, t) { return n + crates(t); }, 0); }
  function totalKeys() { return K().TIERS.reduce(function (n, t) { return n + keys(t); }, 0); }
  function canOpen(tier) { return crates(tier) > 0 && keys(tier) > 0; }
  /** Nombre de tirages prêts (caisse + clé) — sert à la pastille de notification. */
  function readyCount() { return K().TIERS.reduce(function (n, t) { return n + Math.min(crates(t), keys(t)); }, 0); }

  // ---------- Ajout ----------
  function addCrate(tier, n) {
    if (!K().CRATES[tier]) return 0;
    var s = state(), before = s.crates[tier];
    s.crates[tier] = Math.min(K().MAX_STACK, before + Math.max(0, Math.floor(n || 0)));
    return s.crates[tier] - before;
  }
  function addKey(tier, n) {
    if (!K().CRATES[tier]) return 0;
    var s = state(), before = s.keys[tier];
    s.keys[tier] = Math.min(K().MAX_STACK, before + Math.max(0, Math.floor(n || 0)));
    return s.keys[tier] - before;
  }
  function addShards(n) {
    n = Math.max(0, Math.floor(n || 0));
    var s = state(); s.shards = Math.min(9999999, s.shards + n);
    return n;
  }

  // ---------- Paiement (ressources + Prismes) ----------
  function payCost(cost) {
    var SM = NEBUSTION.ShopManager;
    if (SM && SM.canAfford) { if (!SM.canAfford(cost)) return false; return SM.spend(cost); }
    return NEBUSTION.Resources.canAfford(cost) && NEBUSTION.Resources.spendMany(cost) !== false;
  }
  function canPay(cost) {
    var SM = NEBUSTION.ShopManager;
    return SM && SM.canAfford ? SM.canAfford(cost) : NEBUSTION.Resources.canAfford(cost);
  }

  function buyCrate(tier) {
    var c = K().CRATES[tier];
    if (!c) return { ok: false, reason: 'invalide' };
    if (crates(tier) >= K().MAX_STACK) return { ok: false, reason: 'plein' };
    if (!payCost(c.crateCost)) return { ok: false, reason: 'ressources', cost: c.crateCost };
    addCrate(tier, 1); save();
    return { ok: true, cost: c.crateCost };
  }
  function buyKey(tier) {
    var c = K().CRATES[tier];
    if (!c) return { ok: false, reason: 'invalide' };
    if (keys(tier) >= K().MAX_STACK) return { ok: false, reason: 'plein' };
    if (!payCost(c.keyCost)) return { ok: false, reason: 'ressources', cost: c.keyCost };
    addKey(tier, 1); save();
    return { ok: true, cost: c.keyCost };
  }

  // ---------- Forge d'Éclats ----------
  function forgeKey(tier) {
    var c = K().CRATES[tier];
    if (!c) return { ok: false, reason: 'invalide' };
    if (shards() < c.keyShards) return { ok: false, reason: 'eclats', cost: c.keyShards };
    if (keys(tier) >= K().MAX_STACK) return { ok: false, reason: 'plein' };
    state().shards -= c.keyShards;
    addKey(tier, 1); save();
    return { ok: true, cost: c.keyShards };
  }
  /** Fabrique directement un skin précis (Caisses ou Boutique, jamais les exclusivités du Pass). */
  function forgeSkin(skinId) {
    var cost = K().forgeSkinCost(skinId);
    if (cost === null || cost === undefined) return { ok: false, reason: 'invalide' };
    if (NEBUSTION.SkinManager.isOwned(skinId)) return { ok: false, reason: 'deja' };
    if (shards() < cost) return { ok: false, reason: 'eclats', cost: cost };
    var g = NEBUSTION.SkinManager.grant(skinId);
    if (!g.ok) return { ok: false, reason: 'invalide' };
    state().shards -= cost;
    save();
    return { ok: true, skin: g.skin, cost: cost };
  }
  /** Skins que la Forge peut fabriquer (non possédés), classés par rareté puis nom. */
  function forgeList() {
    var SKM = NEBUSTION.SkinManager;
    var out = NEBUSTION.Skins.SKINS.filter(function (s) { return (s.crate || !s.exclusive) && !SKM.isOwned(s.id); });
    out.sort(function (a, b) { return K().RARITY_ORDER.indexOf(a.rarity) - K().RARITY_ORDER.indexOf(b.rarity) || a.name.localeCompare(b.name); });
    return out;
  }

  // ---------- Ouverture ----------
  function _unlockedHeroes() {
    var C = NEBUSTION.Combat;
    return NEBUSTION.Heroes.all().filter(function (h) { return !C || C.isUnlocked(h.id); });
  }

  function _resolve(outcome, tier) {
    var K0 = K(), rarity = outcome.rarity, kind = outcome.kind, res = { kind: kind, rarity: rarity, tier: tier };
    var SKM = NEBUSTION.SkinManager;

    if (kind === 'skin') {
      var owned = {}; SKM.owned().forEach(function (s) { owned[s.id] = true; });
      var skin = K0.pickSkin(rarity, owned);
      if (skin) {
        var g = SKM.grant(skin.id);
        res.skin = skin; res.dup = !!g.dup;
        res.label = skin.name;
        res.detail = NEBUSTION.Skins.TARGET_NAMES[skin.target] + ' · ' + NEBUSTION.Skins.FX[skin.fx];
        if (res.dup) { res.dupShards = K0.DUP_SHARDS[rarity]; addShards(res.dupShards); }
        return res;
      }
      kind = res.kind = 'equipment';   // aucune skin de cette rareté (ne devrait pas arriver) : repli
    }
    if (kind === 'equipment') {
      var E = NEBUSTION.Equipment, EM = NEBUSTION.EquipmentManager;
      if (E && EM) {
        var slot = E.SLOT_ORDER[Math.floor(Math.random() * E.SLOT_ORDER.length)];
        var er = E.RARITIES[rarity] ? rarity : 'rare';
        var g2 = EM.grant(slot, er);
        if (g2.ok) {
          res.item = g2.item; res.label = E.itemName(slot, er); res.detail = 'Équipement · ' + K0.RARITY_NAMES[rarity];
          return res;
        }
      }
      kind = res.kind = 'resources';
    }
    if (kind === 'fragments') {
      var heroes = _unlockedHeroes();
      if (heroes.length) {
        var hero = heroes[Math.floor(Math.random() * heroes.length)];
        var amount = K0.FRAGMENTS[rarity];
        var f = NEBUSTION.Combat.addFragments(hero.id, amount);
        if (f && f.ok !== false) {
          res.hero = hero; res.amount = amount; res.label = amount + ' fragments — ' + hero.name; res.detail = 'Fragments de héros';
          return res;
        }
      }
      kind = res.kind = 'resources';
    }
    if (kind === 'gems') {
      var gm = K0.GEMS[rarity];
      if (NEBUSTION.ShopManager) { NEBUSTION.ShopManager.addGems(gm); res.amount = gm; res.label = gm + ' Prismes'; res.detail = 'Monnaie premium'; return res; }
      kind = res.kind = 'resources';
    }
    // ressources
    var bundle = K0.RESOURCE_BUNDLES[rarity], got = [];
    Object.keys(bundle).forEach(function (id) {
      var added = NEBUSTION.Resources.add(id, bundle[id], 'crate');
      got.push({ id: id, amount: (added !== undefined && added !== null) ? added : bundle[id], requested: bundle[id] });
    });
    res.kind = 'resources'; res.bundle = got;
    res.label = 'Lot de ressources'; res.detail = got.map(function (b) {
      var d = NEBUSTION.Economy.RES[b.id]; return '+' + NEBUSTION.Economy.fmt(b.requested) + ' ' + (d ? d.short : b.id);
    }).join(' · ');
    return res;
  }

  /** Ouvre une caisse : consomme 1 caisse + 1 clé du palier. */
  function open(tier) {
    var c = K().CRATES[tier];
    if (!c) return { ok: false, reason: 'invalide' };
    var s = state();
    if (crates(tier) <= 0) return { ok: false, reason: 'caisse' };
    if (keys(tier) <= 0) return { ok: false, reason: 'cle' };
    var outcome = K().rollOutcome(tier, s.pity);
    s.crates[tier] -= 1; s.keys[tier] -= 1;
    s.pity = outcome.pity; s.opened += 1;
    var reward = _resolve(outcome, tier);
    var bonus = K().BONUS_SHARDS[outcome.rarity];
    bonus = Math.round(bonus * (1 + ((NEBUSTION.PlanetBuild && NEBUSTION.Resources && NEBUSTION.Resources.state && NEBUSTION.Resources.state.planetBuild) ? NEBUSTION.PlanetBuild.effectSum(NEBUSTION.Resources.state.planetBuild, 'shardsPct') : 0)));   // Forges d'éclats (Nexus-01)
    addShards(bonus);
    s.history.unshift({ t: Date.now(), tier: tier, rarity: reward.rarity, kind: reward.kind, label: String(reward.label || ''), dup: !!reward.dup });
    if (s.history.length > K().HISTORY_MAX) s.history.length = K().HISTORY_MAX;
    save();
    return { ok: true, tier: tier, reward: reward, bonusShards: bonus, pityTriggered: outcome.pityTriggered };
  }

  // ---------- Cadeau quotidien ----------
  function dailyAvailable(now) { return state().lastDaily !== K().dayIndex(now); }
  function claimDaily(now) {
    if (!dailyAvailable(now)) return { ok: false, reason: 'deja' };
    var G = K().DAILY_GIFT, s = state();
    addCrate(G.crate, G.crates); addKey(G.key, G.keys);
    s.lastDaily = K().dayIndex(now);
    save();
    return { ok: true, gift: G };
  }

  // ---------- Butin passif (combat, caisses de ravitaillement) ----------
  /** Après une victoire : petite chance de trouver une caisse ou une clé. Retourne [{type:'crate'|'key', tier}] . */
  function dropFromCombat(stars) {
    var D = K().DROPS.combat, out = [];
    if (!stars || stars <= 0) return out;
    var chance = D.base + stars * D.perStar;
    if (Math.random() * 100 < chance) {
      var tier = (Math.random() * 100 < D.nebula) ? 'nebula' : 'astral';
      var isCrate = Math.random() < 0.5;
      if (isCrate) addCrate(tier, 1); else addKey(tier, 1);
      out.push({ type: isCrate ? 'crate' : 'key', tier: tier });
      save();
    }
    return out;
  }
  function dropFromPod() {
    if (Math.random() * 100 >= K().DROPS.pod.chance) return null;
    var isCrate = Math.random() < 0.5;
    if (isCrate) addCrate('astral', 1); else addKey('astral', 1);
    save();
    return { type: isCrate ? 'crate' : 'key', tier: 'astral' };
  }

  function stats() { var s = state(); return { opened: s.opened, shards: s.shards, pity: pity() }; }

  return {
    crates: crates, keys: keys, shards: shards, pity: pity, opened: opened, history: history,
    totalCrates: totalCrates, totalKeys: totalKeys, canOpen: canOpen, readyCount: readyCount, canPay: canPay,
    addCrate: addCrate, addKey: addKey, addShards: addShards,
    buyCrate: buyCrate, buyKey: buyKey, forgeKey: forgeKey, forgeSkin: forgeSkin, forgeList: forgeList,
    open: open, dailyAvailable: dailyAvailable, claimDaily: claimDaily,
    dropFromCombat: dropFromCombat, dropFromPod: dropFromPod, stats: stats
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.CrateManager; }
