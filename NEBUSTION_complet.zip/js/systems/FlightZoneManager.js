/**
 * NEBUSTION - FlightZoneManager
 * État des zones découvertes en vol libre (module Exploration spatiale). Suit exactement le schéma
 * de ShipManager/GalaxyManager : état dans NEBUSTION.Resources.state.flightZones, couvert par la
 * sauvegarde automatique déjà en place. Aucune dépendance à Phaser ici.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.FlightZoneManager = (function () {
  'use strict';

  var FZ = function () { return NEBUSTION.FlightZones; };
  var root = function () { return NEBUSTION.Resources && NEBUSTION.Resources.state; };

  function state() {
    var r = root();
    if (!r) return FZ().defaultState();
    if (!r.flightZones) r.flightZones = FZ().normalizeState(null);
    return r.flightZones;
  }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }

  function isUnlocked(zid) { return !!state().unlocked[zid]; }
  function unlockedCount() { return Object.keys(state().unlocked).length; }
  function totalCount() { return FZ().ZONES.length; }

  /** Débloque une zone (première visite) et verse sa récompense. No-op (ok:false) si déjà débloquée ou zone inconnue. */
  function unlock(zid) {
    var z = FZ().zone(zid);
    if (!z) return { ok: false, reason: 'invalide' };
    var s = state();
    if (s.unlocked[zid]) return { ok: false, reason: 'deja' };
    s.unlocked[zid] = true;
    s.stats.unlocks += 1;
    Object.keys(z.reward).forEach(function (rid) {
      try { NEBUSTION.Resources.add(rid, z.reward[rid], 'flightZone', { zone: zid }); } catch (e) { /* ignore */ }
    });
    save();
    return { ok: true, zone: z, reward: z.reward };
  }

  /** Le vaisseau a-t-il été « construit » (au moins un vaisseau possédé au Hangar) ? Condition d'accès à l'écran de vol. */
  function hasShip() {
    try { return !!(NEBUSTION.ShipManager && NEBUSTION.ShipManager.list().length > 0); } catch (e) { return false; }
  }

  return {
    isUnlocked: isUnlocked, unlockedCount: unlockedCount, totalCount: totalCount,
    unlock: unlock, hasShip: hasShip
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.FlightZoneManager; }
