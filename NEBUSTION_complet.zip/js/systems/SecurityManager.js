/**
 * NEBUSTION - SecurityManager
 * Glue entre NEBUSTION.Security (données pures) et NEBUSTION.Resources (économie/sauvegarde).
 * État dans NEBUSTION.Resources.state.security : { level }.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.SecurityManager = (function () {
  'use strict';

  function D() { return NEBUSTION.Security; }
  function root() { return NEBUSTION.Resources && NEBUSTION.Resources.state; }

  function state() {
    var r = root();
    if (!r) return D().defaultState();
    if (!r.security) r.security = D().defaultState();
    return r.security;
  }

  function level() { return state().level; }
  function maxed() { return level() >= D().MAX_LEVEL; }
  /** Niveau affiché dans QGScene : niveau manuel + bonus des Tourelles (module 11C) + bâtiment Défense (module 27B). */
  function effectiveLevel() {
    var qm = NEBUSTION.QGGridManager;
    var bonus = qm ? Math.round(qm.bonusValue('security')) : 0;
    var R = NEBUSTION.Resources, E = NEBUSTION.Economy;
    var defBonus = (R && E) ? Math.round(E.defenseBonus(R.level('defense'))) : 0;
    var pb = ((NEBUSTION.PlanetBuild && NEBUSTION.Resources && NEBUSTION.Resources.state && NEBUSTION.Resources.state.planetBuild) ? NEBUSTION.PlanetBuild.effectSum(NEBUSTION.Resources.state.planetBuild, 'security') : 0);   // Générateurs de bouclier (Nexus-01)
    return Math.min(D().MAX_LEVEL, level() + bonus + defBonus + Math.round(pb));
  }
  function cost() { return D().upgradeCost(level()); }
  function effectText() { return D().effectText(level()); }

  function canAfford() {
    var R = NEBUSTION.Resources;
    if (!R) return false;
    var c = cost();
    return Object.keys(c).every(function (id) { return R.get(id) >= c[id]; });
  }

  /** Paie et applique une amélioration du niveau de sécurité. */
  function upgrade() {
    var R = NEBUSTION.Resources;
    if (!R) return { ok: false, reason: 'unavailable' };
    if (maxed()) return { ok: false, reason: 'max' };
    var c = cost();
    if (!R.spendMany(c)) return { ok: false, reason: 'cost', cost: c };
    state().level += 1;
    R.saveNow(Date.now());
    return { ok: true, level: level(), cost: c };
  }

  return {
    level: level, maxed: maxed, effectiveLevel: effectiveLevel, cost: cost, effectText: effectText,
    canAfford: canAfford, upgrade: upgrade
  };
})();
