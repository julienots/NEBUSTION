/**
 * NEBUSTION - EquipmentManager
 * Glue entre NEBUSTION.Equipment (données pures) et la sauvegarde/économie existantes,
 * suivant exactement le même schéma que GalaxyManager : l'état vit dans
 * NEBUSTION.Resources.state.equipment (couvert par la sauvegarde automatique déjà en place).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.EquipmentManager = (function () {
  'use strict';

  var Q = function () { return NEBUSTION.Equipment; };
  var root = function () { return NEBUSTION.Resources && NEBUSTION.Resources.state; };

  function state() {
    var r = root();
    if (!r) return Q().defaultState();
    if (!r.equipment) r.equipment = Q().normalizeState(null);
    return r.equipment;
  }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }

  // ---------- Inventaire ----------
  // Un objet fabriqué depuis un modèle personnalisé (Atelier créateur, onglet Équipement) porte
  // un templateId : displayName/portrait viennent du modèle, mais bonus/coûts/niveaux restent
  // calculés par les formules de NEBUSTION.Equipment, exactement comme un objet générique.
  function _view(uid, it) {
    var E = Q();
    var tpl = it.templateId ? E.template(it.templateId) : null;
    return Object.assign({ uid: uid }, it, {
      displayName: tpl ? tpl.name : E.itemName(it.slot, it.rarity),
      portrait: tpl ? (tpl.portrait || null) : null,
      custom: !!tpl
    });
  }

  function list() {
    var s = state();
    return Object.keys(s.items).map(function (uid) { return _view(uid, s.items[uid]); });
  }

  function get(uid) {
    var s = state();
    return s.items[uid] ? _view(uid, s.items[uid]) : null;
  }

  function equippedOn(heroId) { return Object.assign({}, state().equipped[heroId] || {}); }

  function equippedItem(heroId, slot) {
    var uid = (state().equipped[heroId] || {})[slot];
    return uid ? get(uid) : null;
  }

  function isEquipped(uid) {
    var eq = state().equipped;
    return Object.keys(eq).some(function (hid) {
      return Object.keys(eq[hid]).some(function (slot) { return eq[hid][slot] === uid; });
    });
  }

  // ---------- Fabrication (remplace, pour cette première version, le farm/combat/expéditions) ----------
  function craft(slot, rarityId) {
    var E = Q();
    if (E.SLOT_ORDER.indexOf(slot) < 0 || !E.RARITIES[rarityId]) return { ok: false, reason: 'invalide' };
    var cost = E.craftCost(slot, rarityId);
    if (!NEBUSTION.Resources.canAfford(cost)) return { ok: false, reason: 'ressources' };
    NEBUSTION.Resources.spendMany(cost);
    var s = state();
    var uid = 'eq' + (s.nextSeq++);
    s.items[uid] = { slot: slot, rarity: rarityId, level: 1 };
    save();
    return { ok: true, uid: uid, item: get(uid) };
  }

  /** Modèles d'objets créés dans l'Atelier (tools/studio.html, onglet Équipement), prêts à fabriquer. */
  function templates() {
    var CC = window.NEBUSTION.CustomContent;
    return (CC && CC.items) ? CC.items() : [];
  }

  /** Fabrique un objet neuf (niveau 1) à partir d'un modèle personnalisé : même coût que le générique de son emplacement/rareté. */
  function craftTemplate(templateId) {
    var E = Q();
    var tpl = E.template(templateId);
    if (!tpl) return { ok: false, reason: 'invalide' };
    var cost = E.craftCost(tpl.slot, tpl.rarity);
    if (!NEBUSTION.Resources.canAfford(cost)) return { ok: false, reason: 'ressources' };
    NEBUSTION.Resources.spendMany(cost);
    var s = state();
    var uid = 'eq' + (s.nextSeq++);
    s.items[uid] = { slot: tpl.slot, rarity: tpl.rarity, level: 1, templateId: tpl.id };
    save();
    return { ok: true, uid: uid, item: get(uid) };
  }

  function _rollDrop(slot) {
    var E = Q();
    slot = slot || E.SLOT_ORDER[Math.floor(Math.random() * E.SLOT_ORDER.length)];
    var roll = Math.random();
    var rarityId = roll > 0.97 ? 'legendaire' : roll > 0.85 ? 'epique' : roll > 0.55 ? 'rare' : 'commun';
    var s = state();
    var uid = 'eq' + (s.nextSeq++);
    s.items[uid] = { slot: slot, rarity: rarityId, level: 1 };
    save();
    return get(uid);
  }

  /** Utilisé par CombatManager après une victoire (combat ou invasion) : petite chance de récompense. */
  function maybeDropFromCombat(stars) {
    if (!stars || stars <= 0) return null;
    var chance = 0.18 + stars * 0.07;
    if (Math.random() > chance) return null;
    return _rollDrop();
  }

  /** Utilisé par le farm passif (ex. caisses de ravitaillement) : chance plus faible, sans étoiles. */
  function maybeDropFromFarm() {
    if (Math.random() > 0.15) return null;
    return _rollDrop();
  }

  // ---------- Équiper / déséquiper ----------
  function equip(heroId, uid) {
    var item = get(uid);
    if (!heroId || !item) return { ok: false, reason: 'invalide' };
    var s = state();
    // Retire l'objet de tout autre héros qui le porterait déjà.
    Object.keys(s.equipped).forEach(function (hid) {
      var slots = s.equipped[hid];
      Object.keys(slots).forEach(function (sl) { if (slots[sl] === uid) delete slots[sl]; });
    });
    s.equipped[heroId] = s.equipped[heroId] || {};
    s.equipped[heroId][item.slot] = uid;
    save();
    return { ok: true };
  }

  function unequip(heroId, slot) {
    var s = state();
    if (s.equipped[heroId]) delete s.equipped[heroId][slot];
    save();
    return { ok: true };
  }

  // ---------- Amélioration / démantèlement ----------
  function upgrade(uid) {
    var E = Q();
    var s = state();
    var it = s.items[uid];
    if (!it) return { ok: false, reason: 'invalide' };
    if (it.level >= E.MAX_LEVEL) return { ok: false, reason: 'niveau_max' };
    var cost = E.upgradeCost(it.rarity, it.level);
    if (!NEBUSTION.Resources.canAfford(cost)) return { ok: false, reason: 'ressources' };
    NEBUSTION.Resources.spendMany(cost);
    it.level += 1;
    save();
    return { ok: true, item: get(uid) };
  }

  function dismantle(uid) {
    var E = Q();
    var s = state();
    var it = s.items[uid];
    if (!it) return { ok: false, reason: 'invalide' };
    if (isEquipped(uid)) return { ok: false, reason: 'equipe' };
    var refund = E.dismantleRefund(it.slot, it.rarity, it.level);
    delete s.items[uid];
    Object.keys(refund).forEach(function (rid) { if (refund[rid]) NEBUSTION.Resources.add(rid, refund[rid], 'equipment_dismantle'); });
    save();
    return { ok: true, refund: refund };
  }

  /** Octroie directement un objet neuf (niveau 1) sans coût — utilisé par la Boutique (achat déjà payé par l'appelant). */
  function grant(slot, rarityId) {
    var E = Q();
    if (E.SLOT_ORDER.indexOf(slot) < 0 || !E.RARITIES[rarityId]) return { ok: false, reason: 'invalide' };
    var s = state();
    var uid = 'eq' + (s.nextSeq++);
    s.items[uid] = { slot: slot, rarity: rarityId, level: 1 };
    save();
    return { ok: true, uid: uid, item: get(uid) };
  }

  // ---------- Fusion ----------
  /** Fusionne 2 objets identiques (même emplacement/rareté/niveau) en 1 objet de rareté supérieure (niveau 1). */
  function fuse(uidA, uidB) {
    var E = Q();
    var s = state();
    if (!uidA || !uidB || uidA === uidB) return { ok: false, reason: 'invalide' };
    var a = s.items[uidA], b = s.items[uidB];
    if (!a || !b) return { ok: false, reason: 'invalide' };
    if (a.slot !== b.slot || a.rarity !== b.rarity || a.level !== b.level) return { ok: false, reason: 'incompatible' };
    if (isEquipped(uidA) || isEquipped(uidB)) return { ok: false, reason: 'equipe' };
    var next = E.nextRarity(a.rarity);
    if (!next) return { ok: false, reason: 'rarete_max' };
    delete s.items[uidA];
    delete s.items[uidB];
    var uid = 'eq' + (s.nextSeq++);
    s.items[uid] = { slot: a.slot, rarity: next, level: 1 };
    save();
    return { ok: true, uid: uid, item: get(uid) };
  }

  /** Premier autre objet identique (même slot/rareté/niveau, non équipé) trouvé dans l'inventaire, pour proposer une fusion. */
  function findFusionMatch(uid) {
    var it = get(uid);
    if (!it || isEquipped(uid)) return null;
    var s = state();
    var found = null;
    Object.keys(s.items).forEach(function (other) {
      if (found || other === uid) return;
      var o = s.items[other];
      if (o.slot === it.slot && o.rarity === it.rarity && o.level === it.level && !isEquipped(other)) found = other;
    });
    return found;
  }

  // ---------- Bonus de combat ----------
  /** Bonus cumulé {hp,atk,def,spd,critChance} des objets équipés par un héros (0 si rien). */
  function bonusForHero(heroId) {
    var E = Q();
    var eq = equippedOn(heroId);
    var out = { hp: 0, atk: 0, def: 0, spd: 0, critChance: 0 };
    Object.keys(eq).forEach(function (slot) {
      var it = get(eq[slot]);
      if (!it) return;
      var b = E.bonusFor(it.slot, it.rarity, it.level);
      Object.keys(b).forEach(function (k) { out[k] = (out[k] || 0) + b[k]; });
    });
    return out;
  }

  return {
    list: list, get: get, equippedOn: equippedOn, equippedItem: equippedItem, isEquipped: isEquipped,
    craft: craft, craftTemplate: craftTemplate, templates: templates,
    grant: grant, maybeDropFromCombat: maybeDropFromCombat, maybeDropFromFarm: maybeDropFromFarm,
    equip: equip, unequip: unequip, upgrade: upgrade, dismantle: dismantle,
    fuse: fuse, findFusionMatch: findFusionMatch,
    bonusForHero: bonusForHero
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.EquipmentManager; }
