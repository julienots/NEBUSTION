/**
 * NEBUSTION - ModManager (système de mods/plugins)
 * Permet d'ajouter du contenu ou du comportement au jeu sans modifier les fichiers du jeu
 * lui-même : un mod est un simple fichier .js posé dans mods/ et listé dans mods/manifest.js.
 *
 * Cycle de vie d'un mod :
 *   1. Son fichier est chargé (voir index.html) APRÈS toutes les données/managers du jeu,
 *      donc NEBUSTION.Shop, NEBUSTION.Heroes, NEBUSTION.Resources, etc. existent déjà.
 *   2. Il s'enregistre avec NEBUSTION.Mods.register({ id, name, version, init, onGameReady, onTick, scenes }).
 *      -> init(NEBUSTION) est appelé immédiatement (avant le démarrage de Phaser).
 *   3. Une fois Phaser.Game créé, onGameReady(game, NEBUSTION) est appelé pour chaque mod.
 *   4. onTick(t, NEBUSTION) est ensuite appelé en continu (même rythme que les autres managers
 *      hors-écran, voir js/main.js), si le mod définit cette fonction.
 *   5. scenes (optionnel) : tableau de classes de scène Phaser à ajouter au jeu.
 *
 * Aucune étape n'est obligatoire à part id + au moins un des callbacks. Un mod manquant, mal
 * formé, ou qui lève une exception est signalé en console (voir NEBUSTION.Mods.errors()) mais
 * NE FAIT JAMAIS planter le jeu ni les autres mods.
 * Voir LISEZMOI_MODS.md pour le guide complet, et mods/exemple_mod.js pour un exemple fonctionnel.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Mods = (function () {
  'use strict';

  var registry = [];   // [{ id, name, version, mod }]
  var errorLog = [];   // [{ id, phase, error }]

  function safeCall(id, phase, fn, args) {
    try {
      fn.apply(null, args || []);
    } catch (err) {
      errorLog.push({ id: id, phase: phase, error: err });
      console.error('NEBUSTION.Mods: erreur dans ' + phase + '() du mod "' + id + '"', err);
    }
  }

  /** Enregistre un mod. À appeler depuis le fichier du mod lui-même. */
  function register(mod) {
    if (!mod || typeof mod !== 'object') {
      console.warn('NEBUSTION.Mods.register() attend un objet { id, ... }.');
      return null;
    }
    var id = String(mod.id || '').trim();
    if (!id) {
      console.warn('NEBUSTION.Mods: mod sans "id" ignoré.', mod);
      return null;
    }
    if (registry.some(function (e) { return e.id === id; })) {
      console.warn('NEBUSTION.Mods: id de mod déjà utilisé, ignoré : "' + id + '"');
      return null;
    }
    var entry = { id: id, name: mod.name || id, version: mod.version || '?', mod: mod };
    registry.push(entry);
    if (typeof mod.init === 'function') safeCall(id, 'init', mod.init, [NEBUSTION]);
    console.log('NEBUSTION.Mods: mod chargé — ' + entry.name + ' (v' + entry.version + ')');
    return entry;
  }

  /** Liste des mods actifs (copie, pour affichage/debug). */
  function list() {
    return registry.map(function (e) { return { id: e.id, name: e.name, version: e.version }; });
  }

  /** Erreurs rencontrées depuis le démarrage (copie, pour affichage/debug). */
  function errors() { return errorLog.slice(); }

  /** Classes de scène Phaser fournies par les mods (voir mod.scenes). */
  function getExtraScenes() {
    var out = [];
    registry.forEach(function (e) {
      if (Array.isArray(e.mod.scenes)) {
        e.mod.scenes.forEach(function (s) { if (s) out.push(s); });
      }
    });
    return out;
  }

  /** Appelé une fois par js/main.js, juste après la création de Phaser.Game. */
  function onGameReady(game) {
    registry.forEach(function (e) {
      if (typeof e.mod.onGameReady === 'function') safeCall(e.id, 'onGameReady', e.mod.onGameReady, [game, NEBUSTION]);
    });
  }

  /** Appelé en continu par js/main.js (voir l'événement 'step' du jeu). */
  function onTick(t) {
    registry.forEach(function (e) {
      if (typeof e.mod.onTick === 'function') safeCall(e.id, 'onTick', e.mod.onTick, [t, NEBUSTION]);
    });
  }

  return {
    register: register,
    list: list,
    errors: errors,
    getExtraScenes: getExtraScenes,
    onGameReady: onGameReady,
    onTick: onTick
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.Mods; }
