/**
 * NEBUSTION - CombatManager
 * Glue entre le moteur de combat pur (CombatEngine), les données (Heroes/Enemies) et
 * la sauvegarde. Ne dépend PAS de Phaser. Réutilise la sauvegarde/économie déjà en place :
 * les informations de combat vivent dans `NEBUSTION.Resources.state.combat` (ajouté par
 * SaveManager à l'étape 4), donc les sauvegardes automatiques déjà en place (toutes les 5 s,
 * mise en veille, fermeture...) couvrent aussi la progression du combat sans rien changer
 * à ResourceManager.
 *
 * Hypothèse assumée (documentée dans LISEZMOI_ETAPE4.md) : aucun système d'invocation
 * n'existe encore, donc les 16 héros sont utilisables dès maintenant pour composer une
 * équipe de combat. Les fragments gagnés en récompense sont stockés dès maintenant
 * (par héros) pour un futur module de montée en niveau, qui utilisera les formules déjà
 * prêtes dans js/data/Heroes.js (statsAtLevel, MAX_LEVEL).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Combat = (function () {
  'use strict';

  var FRAGMENTS_PER_LEVEL = 8;
  var INVASION_SHIELD_SHARE = 0.12;   // part du bouclier d'une planète convertie en absorption réelle pour ses défenseurs

  function state() { return NEBUSTION.Resources.state.combat; }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }

  // ---------- Héros exclusifs de la Boutique (étape 9) : à recruter avant de pouvoir combattre ----------
  /**
   * Un héros est utilisable :
   *  - immédiatement s'il n'est pas vendu en Boutique (`shop`) ;
   *  - après recrutement payant (Prismes) s'il porte `shop.cost` ;
   *  - automatiquement dès que ses fragments atteignent `shop.fragmentsToUnlock` (héros obtenu
   *    uniquement par fragments, ex. Aetherion) : aucun état séparé à maintenir, le seuil est
   *    comparé directement au compteur de fragments déjà utilisé pour le niveau.
   */
  function isUnlocked(heroId) {
    var h = NEBUSTION.Heroes.get(heroId);
    if (!h) return false;
    if (!h.shop) return true;
    if (h.shop.fragmentsToUnlock) {
      var frags = state().fragments[heroId] || 0;
      return frags >= h.shop.fragmentsToUnlock;
    }
    var u = state().unlockedHeroes;
    return !!(u && u[heroId] === true);
  }
  /** Marque un héros comme recruté (achat déjà payé par l'appelant : ShopManager.buyHero). */
  function unlockHero(heroId) {
    var h = NEBUSTION.Heroes.get(heroId);
    if (!h || !h.shop) return { ok: false, reason: 'invalide' };
    var st = state();
    if (!st.unlockedHeroes) st.unlockedHeroes = {};
    if (st.unlockedHeroes[heroId] === true) return { ok: false, reason: 'deja' };
    st.unlockedHeroes[heroId] = true;
    save();
    return { ok: true, hero: h };
  }

  function defaultTeam() {
    // Équipe de démarrage raisonnable : 5 premiers héros de la liste (rôles variés).
    return NEBUSTION.Heroes.all().filter(function (h) { return isUnlocked(h.id); }).slice(0, 5).map(function (h) { return h.id; });
  }

  function getTeam() {
    var t = state().team;
    if (!t || t.length === 0) return defaultTeam();
    return t.filter(function (id) { return !!NEBUSTION.Heroes.get(id) && isUnlocked(id); });
  }

  function setTeam(ids) {
    var clean = (ids || []).filter(function (id) { return !!NEBUSTION.Heroes.get(id) && isUnlocked(id); }).slice(0, 5);
    state().team = clean;
    save();
    return clean;
  }

  // ---------- Formation (positionnement avant/arrière) ----------
  /** Ligne d'un héros : 'front' (mêlée, ciblé en priorité, dégâts +) ou 'back' (soutien, protégé, dégâts -). */
  function getFormationRow(heroId) {
    var f = state().formation || {};
    return f[heroId] === 'back' ? 'back' : 'front';
  }
  function setFormationRow(heroId, row) {
    if (!NEBUSTION.Heroes.get(heroId)) return { ok: false, reason: 'invalide' };
    var st = state();
    if (!st.formation) st.formation = {};
    st.formation[heroId] = (row === 'back') ? 'back' : 'front';
    save();
    return { ok: true, row: st.formation[heroId] };
  }
  function getFormation() {
    var out = {};
    getTeam().forEach(function (hid) { out[hid] = getFormationRow(hid); });
    return out;
  }

  function getDifficulty() { return state().difficulty; }
  function setDifficulty(id) {
    if (!NEBUSTION.Enemies.DIFFICULTIES[id]) return;
    state().difficulty = id;
    save();
  }

  function heroLevel(heroId) {
    // Pas encore de système de montée en niveau séparé : niveau dérivé du nombre de
    // fragments accumulés (1 niveau tous les FRAGMENTS_PER_LEVEL fragments), plafonné à MAX_LEVEL.
    var frags = state().fragments[heroId] || 0;
    var lvl = 1 + Math.floor(frags / FRAGMENTS_PER_LEVEL);
    return Math.min(NEBUSTION.Heroes.MAX_LEVEL, lvl);
  }

  /** Ajoute directement des fragments à un héros — utilisé par la Boutique (achat déjà payé par l'appelant). */
  function addFragments(heroId, amount) {
    amount = Math.floor(Number(amount) || 0);
    if (!NEBUSTION.Heroes.get(heroId) || amount <= 0) return { ok: false, reason: 'invalide' };
    var st = state();
    st.fragments[heroId] = (st.fragments[heroId] || 0) + amount;
    save();
    return { ok: true, total: st.fragments[heroId], level: heroLevel(heroId) };
  }

  /** Combine le bonus d'équipement d'un héros (additif) et le bonus de flotte actuel (pourcentage). */
  function combinedBonus(heroId) {
    var EQ = NEBUSTION.EquipmentManager, SM = NEBUSTION.ShipManager;
    var g = EQ ? EQ.bonusForHero(heroId) : {};
    var f = SM ? SM.fleetBonus() : {};
    var out = Object.assign({}, g, f);
    // Bonus permanent « Bénédiction stellaire » (Renaissance, étape 10) : + x % de PV / attaque / défense pour toute l'équipe.
    var pm = NEBUSTION.PrestigeManager, pb = (pm && pm.bonusValue) ? pm.bonusValue('combatPower') : 0;
    if (pb > 0) { out.hpPct = (out.hpPct || 0) + pb; out.atkPct = (out.atkPct || 0) + pb; out.defPct = (out.defPct || 0) + pb; }
    out.row = getFormationRow(heroId);
    return out;
  }

  function stageStars(stageId) { return state().stageStars[stageId] || 0; }

  function isStageUnlocked(stageId) {
    var stages = NEBUSTION.Enemies.allStages();
    var idx = NEBUSTION.Enemies.stageIndex(stageId);
    if (idx <= 0) return true;
    var prev = stages[idx - 1];
    return stageStars(prev.id) > 0;
  }

  /** Construit les unités de combat prêtes pour CombatEngine à partir de l'équipe et du stage. */
  function buildBattle(stageId, difficultyId, mode) {
    var CE = NEBUSTION.CombatEngine;
    var stageDef = NEBUSTION.Enemies.stage(stageId);
    if (!stageDef) return null;
    var team = getTeam();
    var playerUnits = team.map(function (heroId) {
      var hero = NEBUSTION.Heroes.get(heroId);
      return CE.makeHeroUnit(hero, heroLevel(heroId), heroId, combinedBonus(heroId));
    });
    // Module Nebustion : les avant-postes corrompus durcissent avec la jauge de corruption galactique
    // (voir Nebustion.js/NebustionManager.outpostScaleBonus). Module absent (tests isolés) => bonus neutre.
    var scale = stageDef.scale;
    if (stageDef.nebustionOutpost && NEBUSTION.NebustionManager) {
      try { scale = scale * NEBUSTION.NebustionManager.outpostScaleBonus(); } catch (e) { /* ignore */ }
    }
    var enemyUnits = stageDef.enemies.map(function (enemyId, i) {
      return CE.makeEnemyUnit(NEBUSTION.Enemies.get(enemyId), difficultyId, i, scale);
    });
    var engine = new CE.CombatEngine(playerUnits, enemyUnits, { mode: mode || 'auto' });
    return { engine: engine, stageDef: stageDef, playerUnits: playerUnits, enemyUnits: enemyUnits };
  }

  function starsFromResult(result) {
    if (!result || !result.win) return 0;
    var lost = result.totalPlayers - result.survivors;
    if (lost === 0) return 3;
    if (lost <= 2) return 2;
    return 1;
  }

  /** Applique les récompenses d'un combat terminé (ressources + XP + fragments) et sauvegarde. */
  function grantRewards(stageDef, difficultyId, result) {
    var stars = starsFromResult(result);
    var rewards = NEBUSTION.Enemies.rewardsFor(stageDef, difficultyId, stars);
    var st = state();

    if (result.win) {
      st.battlesWon += 1;
      var prevStars = st.stageStars[stageDef.id] || 0;
      if (stars > prevStars) st.stageStars[stageDef.id] = stars;
    } else {
      st.battlesLost += 1;
    }

    var granted = {}; // quantité réellement créditée (le stockage plafonné peut en refuser une partie)
    ['crystal', 'metal', 'energy', 'core', 'dust'].forEach(function (rid) {
      if (rewards[rid]) granted[rid] = NEBUSTION.Resources.add(rid, rewards[rid], 'combat', { stage: stageDef.id }) || 0;
    });
    st.playerXP += rewards.xp;

    // Les fragments reviennent à TOUS les héros qui ont combattu (chacun reçoit la quantité indiquée).
    var fragHeroes = [];
    var levelUps = [];
    if (rewards.fragments > 0) {
      getTeam().forEach(function (hid) {
        var before = heroLevel(hid);
        st.fragments[hid] = (st.fragments[hid] || 0) + rewards.fragments;
        fragHeroes.push(hid);
        var after = heroLevel(hid);
        if (after > before) levelUps.push({ heroId: hid, level: after });
      });
    }

    save();
    // Équipement (module ajouté) : petite chance de récompense après une victoire étoilée.
    var equipDrop = (result.win && NEBUSTION.EquipmentManager) ? NEBUSTION.EquipmentManager.maybeDropFromCombat(stars) : null;
    // Module Nebustion : Éclat Souillé + purification de la jauge (avant-postes), grosse récompense (boss final).
    var nebustion = null;
    if (result.win && NEBUSTION.NebustionManager) {
      try {
        if (stageDef.nebustionOutpost) nebustion = { purified: NEBUSTION.NebustionManager.rewardOutpostVictory() };
        else if (stageDef.nebustionBoss) { NEBUSTION.NebustionManager.rewardBossVictory(); nebustion = { bossDefeated: true }; }
      } catch (e) { /* ignore */ }
    }
    return { stars: stars, rewards: rewards, granted: granted, xp: rewards.xp, fragmentHero: fragHeroes[0] || null, fragmentHeroes: fragHeroes, levelUps: levelUps, equipDrop: equipDrop, nebustion: nebustion };
  }

  // =====================================================================
  // Module 5C — Invasions galactiques : combat contre la défense d'une planète.
  // Réutilise EXACTEMENT le même CombatEngine (mêmes unités héros, même moteur) que le module
  // Combat : seule la source des ennemis change (défense de planète au lieu d'un stage), en
  // plusieurs vagues successives de 3 ennemis maximum (voir Galaxy.battleSpec/EmpireEvolutionManager.battleSpec).
  // =====================================================================

  /** Prépare une invasion : équipe actuelle + vagues de la défense (évoluée si le module IA 3/3 est chargé). */
  function buildInvasionBattle(pid, mode) {
    var CE = NEBUSTION.CombatEngine, G = NEBUSTION.Galaxy;
    var EEM = NEBUSTION.EmpireEvolutionManager;
    var spec = EEM ? EEM.battleSpec(pid, Date.now()) : (G.battleSpec ? G.battleSpec(pid) : null);
    if (!spec || !spec.waves || !spec.waves.length) return null;
    var planet = G.planet(pid);
    var team = getTeam();
    var playerUnits = team.map(function (heroId) {
      var hero = NEBUSTION.Heroes.get(heroId);
      return CE.makeHeroUnit(hero, heroLevel(heroId), heroId, combinedBonus(heroId));
    });
    // Bouclier d'orbite : une part (INVASION_SHIELD_SHARE) du bouclier de la planète devient une couche d'absorption
    // réelle répartie sur les défenseurs de chaque vague (elle s'épuise avant les PV ; pas d'expiration).
    var shieldPool = Math.round((spec.shield || 0) * INVASION_SHIELD_SHARE);
    function buildWave(i) {
      var units = spec.waves[i].map(function (def, idx) { return CE.makeEnemyUnit(def, 'normal', 'inv' + i + '_' + idx, spec.scale || 1); });
      var per = Math.round(shieldPool / spec.waves.length / Math.max(1, units.length));
      if (per > 0) units.forEach(function (u) { u.shield = per; });
      return units;
    }
    var enemyUnits = buildWave(0);
    var engine = new CE.CombatEngine(playerUnits, enemyUnits, { mode: mode || 'auto' });
    return {
      engine: engine, planet: planet, planetId: pid, spec: spec,
      waveIndex: 0, waveCount: spec.waves.length,
      playerUnits: playerUnits, enemyUnits: enemyUnits, buildWave: buildWave
    };
  }

  /** Récompenses d'une invasion (même forme que grantRewards, pour réutiliser l'écran de résultat) + résolution de la conquête. */
  function grantInvasionRewards(spec, result, pid) {
    var stars = starsFromResult(result);
    var starMult = stars <= 0 ? 0.25 : (stars === 1 ? 0.6 : (stars === 2 ? 0.85 : 1.0));
    var mult = result.win ? starMult : 0.2; // défaite : petite compensation, l'empire a quand même été affaibli
    var src = spec.rewards || {};
    var rewards = { xp: Math.round((src.xp || 0) * mult), fragments: Math.max(0, Math.round((src.fragments || 0) * mult)) };
    ['crystal', 'metal', 'energy', 'core', 'dust'].forEach(function (rid) {
      var base = src[rid] || 0;
      if (result.win && src.first && src.first[rid]) base += src.first[rid];   // bonus de première conquête
      if (base) rewards[rid] = Math.round(base * mult);
    });

    var st = state();
    if (result.win) st.battlesWon += 1; else st.battlesLost += 1;

    var granted = {};
    ['crystal', 'metal', 'energy', 'core', 'dust'].forEach(function (rid) {
      if (rewards[rid]) granted[rid] = NEBUSTION.Resources.add(rid, rewards[rid], 'invasion', { planet: pid }) || 0;
    });
    st.playerXP += rewards.xp;

    var fragHeroes = [], levelUps = [];
    if (rewards.fragments > 0) {
      getTeam().forEach(function (hid) {
        var before = heroLevel(hid);
        st.fragments[hid] = (st.fragments[hid] || 0) + rewards.fragments;
        fragHeroes.push(hid);
        var after = heroLevel(hid);
        if (after > before) levelUps.push({ heroId: hid, level: after });
      });
    }
    save();

    // Point d'entrée UNIQUE pour enregistrer la conquête / la résistance de l'empire (idempotent).
    var EEM = NEBUSTION.EmpireEvolutionManager;
    var res = EEM ? EEM.resolveInvasion(pid, !!result.win, Date.now()) : null;

    return {
      stars: stars, rewards: rewards, granted: granted, xp: rewards.xp,
      fragmentHero: fragHeroes[0] || null, fragmentHeroes: fragHeroes, levelUps: levelUps,
      conquered: !!(res && res.conquered), empire: res ? res.empire : null
    };
  }

  return {
    getTeam: getTeam, setTeam: setTeam, defaultTeam: defaultTeam,
    getFormationRow: getFormationRow, setFormationRow: setFormationRow, getFormation: getFormation,
    getDifficulty: getDifficulty, setDifficulty: setDifficulty,
    heroLevel: heroLevel, FRAGMENTS_PER_LEVEL: FRAGMENTS_PER_LEVEL, addFragments: addFragments, isUnlocked: isUnlocked, unlockHero: unlockHero, stageStars: stageStars, isStageUnlocked: isStageUnlocked,
    buildBattle: buildBattle, starsFromResult: starsFromResult, grantRewards: grantRewards,
    buildInvasionBattle: buildInvasionBattle, grantInvasionRewards: grantInvasionRewards
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.Combat; }
