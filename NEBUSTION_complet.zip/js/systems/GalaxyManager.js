/**
 * NEBUSTION - GalaxyManager
 * Logique du module Galaxie (SANS Phaser) : déblocage des secteurs, scan des planètes, visites,
 * conquêtes (renseignées par le futur module d'invasion). L'état vit dans
 * `NEBUSTION.Resources.state.galaxy` : il est donc couvert par la sauvegarde automatique existante.
 *
 *  - Déblocage d'un secteur : conditions cumulatives (stages du module Combat, planètes scannées dans le
 *    secteur précédent, ressources). Dépense ATOMIQUE (tout ou rien), jamais deux fois.
 *  - Scan : coûte de l'énergie, dure quelques secondes (job persistant, il se termine même hors ligne),
 *    un seul scan à la fois, valable SCAN_TTL_MS. Aucune invasion possible sans scan valide.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.GalaxyManager = (function () {
  'use strict';

  var G = function () { return NEBUSTION.Galaxy; };
  var listeners = {};
  var providers = {};   // sectorId → [fn(sectorId) → {id,label,cur,need,ok}] : conditions ajoutées par d'autres modules

  function on(evt, fn) { (listeners[evt] = listeners[evt] || []).push(fn); return function () { off(evt, fn); }; }
  function off(evt, fn) { if (listeners[evt]) listeners[evt] = listeners[evt].filter(function (f) { return f !== fn; }); }
  function emit(evt, data) { (listeners[evt] || []).slice().forEach(function (f) { try { f(data); } catch (e) { console.error('GalaxyManager listener', e); } }); }

  function root() { return NEBUSTION.Resources && NEBUSTION.Resources.state; }
  function state() {
    var r = root();
    if (!r) return G().defaultState();
    if (!r.galaxy) r.galaxy = G().normalizeState(null, Date.now());
    return r.galaxy;
  }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }
  function nowOf(now) { return (typeof now === 'number' && isFinite(now)) ? now : Date.now(); }

  // ---------- Secteurs ----------
  function isSectorUnlocked(sid) {
    var s = G().sector(sid);
    if (!s) return false;
    return !s.unlock || state().unlocked[sid] === true;
  }
  function stagesCleared() {
    var r = root(), ss = (r && r.combat && r.combat.stageStars) || {};
    return Object.keys(ss).filter(function (k) { return ss[k] > 0; }).length;
  }
  function totalStages() { return (NEBUSTION.Enemies && NEBUSTION.Enemies.allStages) ? NEBUSTION.Enemies.allStages().length : 13; }
  function scannedCount(sid, now) {
    // Une planète déjà conquise a forcément été scannée (condition requise pour l'invasion) :
    // elle doit donc compter pour toujours, même si son scan de 12h a expiré depuis.
    return G().planetsOf(sid).filter(function (p) { return isScanned(p.id, now) || isConquered(p.id); }).length;
  }
  function addRequirementProvider(sid, fn) { (providers[sid] = providers[sid] || []).push(fn); }

  /** Détail des conditions de déblocage d'un secteur. */
  function sectorStatus(sid, now) {
    var sec = G().sector(sid);
    if (!sec) return null;
    now = nowOf(now);
    var unlocked = isSectorUnlocked(sid);
    var out = { id: sid, unlocked: unlocked, reqs: [], cost: [], allMet: true, canAfford: true, canUnlock: false };
    if (!sec.unlock || unlocked) { out.allMet = true; out.canUnlock = false; return out; }
    var u = sec.unlock;
    if (u.stages != null) {
      var cur = stagesCleared();
      out.reqs.push({ id: 'stages', label: 'Terminer ' + u.stages + ' stage' + (u.stages > 1 ? 's' : '') + ' de combat', cur: Math.min(cur, u.stages), need: u.stages, ok: cur >= u.stages });
    }
    if (u.scans) {
      var prev = G().sector(u.scans.sector), sc = scannedCount(u.scans.sector, now);
      out.reqs.push({ id: 'scans', label: 'Scanner ' + u.scans.n + ' planètes · ' + (prev ? prev.name : u.scans.sector), cur: Math.min(sc, u.scans.n), need: u.scans.n, ok: sc >= u.scans.n });
    }
    (providers[sid] || []).forEach(function (fn) { try { var r = fn(sid); if (r) out.reqs.push(r); } catch (e) { /* ignore */ } });
    out.allMet = out.reqs.every(function (r) { return r.ok; });
    var R = NEBUSTION.Resources;
    Object.keys(u.cost || {}).forEach(function (rid) {
      var have = R ? R.get(rid) : 0, ok = have + 1e-9 >= u.cost[rid];
      out.cost.push({ res: rid, amount: u.cost[rid], have: have, ok: ok });
      if (!ok) out.canAfford = false;
    });
    out.canUnlock = out.allMet && out.canAfford;
    return out;
  }

  /** Débloque un secteur : vérifie les conditions puis dépense les ressources de façon atomique. */
  function unlockSector(sid, now) {
    var sec = G().sector(sid);
    if (!sec) return { ok: false, reason: 'unknown' };
    if (isSectorUnlocked(sid)) return { ok: false, reason: 'already' };
    var st = sectorStatus(sid, now);
    if (!st.allMet) return { ok: false, reason: 'requirements' };
    if (!NEBUSTION.Resources.spendMany(sec.unlock.cost || {})) return { ok: false, reason: 'cost' };
    state().unlocked[sid] = true;
    state().stats.unlocks += 1;
    save();
    emit('unlock', { sector: sid });
    return { ok: true };
  }

  // ---------- Scan ----------
  function scanCost(pid) { var p = G().planet(pid); return (p && p.scan) ? p.scan.cost : null; }
  function scanDuration(pid) { var p = G().planet(pid); return (p && p.scan) ? p.scan.durationMs : 0; }
  function activeJob() {
    var j = state().jobs, k = Object.keys(j);
    return k.length ? k[0] : null;
  }

  /** @returns {{status:'none'|'scanning'|'scanned'|'expired', progress:number, remainingMs:number, validMs:number}} */
  function scanState(pid, now) {
    now = nowOf(now);
    var st = state(), out = { status: 'none', progress: 0, remainingMs: 0, validMs: 0 };
    var job = st.jobs[pid];
    if (job) {
      out.status = 'scanning';
      var dur = Math.max(1, job.end - job.start);
      out.progress = Math.min(1, Math.max(0, (now - job.start) / dur));
      out.remainingMs = Math.max(0, job.end - now);
      return out;
    }
    var sc = st.scans[pid];
    if (sc) {
      var age = Math.max(0, now - sc.at);
      if (age < G().SCAN_TTL_MS) { out.status = 'scanned'; out.progress = 1; out.validMs = G().SCAN_TTL_MS - age; }
      else out.status = 'expired';
    }
    return out;
  }
  function isScanned(pid, now) { return scanState(pid, now).status === 'scanned'; }

  function canScan(pid, now) {
    var p = G().planet(pid);
    if (!p) return { ok: false, reason: 'unknown' };
    if (p.kind === 'home') return { ok: false, reason: 'home' };
    if (!isSectorUnlocked(p.sector)) return { ok: false, reason: 'locked' };
    var s = scanState(pid, now);
    if (s.status === 'scanning') return { ok: false, reason: 'scanning' };
    if (s.status === 'scanned') return { ok: false, reason: 'scanned' };
    if (activeJob()) return { ok: false, reason: 'busy' };
    if (!NEBUSTION.Resources.canAfford(p.scan.cost)) return { ok: false, reason: 'cost' };
    return { ok: true };
  }

  function startScan(pid, now) {
    now = nowOf(now);
    var c = canScan(pid, now);
    if (!c.ok) return c;
    var p = G().planet(pid);
    if (!NEBUSTION.Resources.spendMany(p.scan.cost)) return { ok: false, reason: 'cost' };
    state().jobs[pid] = { start: now, end: now + p.scan.durationMs };
    save();
    emit('scanStart', { planet: pid });
    return { ok: true, endsAt: now + p.scan.durationMs };
  }

  /** Termine les scans arrivés à échéance (aussi après une absence). Retourne les planètes terminées. */
  function update(now) {
    now = nowOf(now);
    var st = state(), done = [];
    Object.keys(st.jobs).forEach(function (pid) {
      var j = st.jobs[pid];
      if (now >= j.end) {
        delete st.jobs[pid];
        st.scans[pid] = { at: now };
        st.stats.scans += 1;
        done.push(pid);
      }
    });
    if (done.length) { save(); done.forEach(function (pid) { emit('scanDone', { planet: pid }); }); }
    return done;
  }

  // ---------- Visites / conquêtes ----------
  function visit(pid, now) {
    var p = G().planet(pid);
    if (!p || !isSectorUnlocked(p.sector)) return false;
    var st = state();
    if (!st.visited[pid]) { st.visited[pid] = nowOf(now); save(); emit('visit', { planet: pid }); return true; }
    return false;
  }
  function isVisited(pid) { return !!state().visited[pid]; }
  function isConquered(pid) { return !!state().conquered[pid]; }
  /** Point d'entrée pour le futur module d'invasion. */
  function setConquered(pid, value, now) {
    var p = G().planet(pid);
    if (!p || p.kind === 'home') return false;
    collectColonies(now, true);   // règle d'abord les revenus de l'ancien territoire (jamais rétroactif sur une nouvelle conquête)
    if (value) state().conquered[pid] = nowOf(now); else delete state().conquered[pid];
    save(); emit('conquest', { planet: pid, value: !!value });
    return true;
  }

  // ---------- Colonies (module Invasions 5C) : une planète conquise rejoint l'empire du joueur ----------
  var COLONY_MAX_MS = 12 * 3600 * 1000;   // au plus 12 h de revenus versées d'un coup (absence longue)
  var COLONY_MIN_MS = 30 * 1000;          // versements groupés : pas plus d'un toutes les 30 s
  /** Revenus par HEURE de toutes les planètes conquises (gisements de Galaxy.deposits), par ressource. */
  function colonyRates() {
    var out = {}, conq = state().conquered;
    G().RES_IDS.forEach(function (rid) { out[rid] = 0; });
    Object.keys(conq).forEach(function (pid) {
      var p = G().planet(pid);
      if (!p || !p.deposits) return;
      Object.keys(p.deposits).forEach(function (rid) { if (out[rid] !== undefined) out[rid] += p.deposits[rid]; });
    });
    return out;
  }
  function colonyIncomeOf(pid) { var p = G().planet(pid); return (p && p.deposits) ? p.deposits : {}; }
  /** Verse les revenus accumulés depuis le dernier versement (hors ligne compris). Retourne les gains crédités ou null. */
  function collectColonies(now, force) {
    now = nowOf(now);
    var st = state(), R = NEBUSTION.Resources;
    if (!R || typeof R.add !== 'function' || !root()) return null;
    var last = st.colonyAt;
    if (!last || last > now) { st.colonyAt = now; return null; }   // premier appel, ou horloge reculée : on repart de maintenant
    var el = now - last;
    if (el < COLONY_MIN_MS && !force) return null;
    var rates = colonyRates(), hours = Math.min(el, COLONY_MAX_MS) / 3600000, gains = {}, any = false;
    G().RES_IDS.forEach(function (rid) {
      if (!(rates[rid] > 0)) return;
      var got = R.add(rid, rates[rid] * hours, 'colony') || 0;
      if (got > 0) { gains[rid] = got; any = true; }
    });
    st.colonyAt = now;
    if (any) { save(); emit('colonyIncome', { gains: gains, hours: hours }); }
    return any ? gains : null;
  }

  /** Une invasion exige : planète ennemie/neutre accessible, non conquise, scan valide. */
  function canInvade(pid, now) {
    var p = G().planet(pid);
    if (!p || p.kind === 'home') return { ok: false, reason: 'invalid' };
    if (!isSectorUnlocked(p.sector)) return { ok: false, reason: 'locked' };
    if (isConquered(pid)) return { ok: false, reason: 'conquered' };
    if (!isScanned(pid, now)) return { ok: false, reason: 'scan' };
    return { ok: true };
  }

  // ---------- Aides ----------
  /** Niveau moyen de l'équipe de combat (pour comparer au niveau conseillé d'une planète). */
  function teamLevel() {
    try {
      var C = NEBUSTION.Combat, team = C.getTeam();
      if (!team.length) return 1;
      return team.reduce(function (s, h) { return s + C.heroLevel(h); }, 0) / team.length;
    } catch (e) { return 1; }
  }
  function saveView(v) {
    if (v && isFinite(v.x) && isFinite(v.y) && isFinite(v.z)) state().view = { x: Math.round(v.x), y: Math.round(v.y), z: Math.round(v.z * 1000) / 1000 };
  }
  function getView() { return state().view; }
  function currentSector() {
    var best = 's1';
    G().SECTORS.forEach(function (s) { if (isSectorUnlocked(s.id)) best = s.id; });
    return best;
  }

  return {
    on: on, off: off, state: state,
    isSectorUnlocked: isSectorUnlocked, sectorStatus: sectorStatus, unlockSector: unlockSector, addRequirementProvider: addRequirementProvider,
    stagesCleared: stagesCleared, totalStages: totalStages, scannedCount: scannedCount, currentSector: currentSector,
    scanCost: scanCost, scanDuration: scanDuration, scanState: scanState, isScanned: isScanned, canScan: canScan, startScan: startScan, activeJob: activeJob, update: update,
    visit: visit, isVisited: isVisited, isConquered: isConquered, setConquered: setConquered, canInvade: canInvade,
    colonyRates: colonyRates, colonyIncomeOf: colonyIncomeOf, collectColonies: collectColonies, COLONY_MAX_MS: COLONY_MAX_MS,
    teamLevel: teamLevel, saveView: saveView, getView: getView
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.GalaxyManager; }
