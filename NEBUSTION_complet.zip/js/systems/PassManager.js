/**
 * NEBUSTION - PassManager
 * Glue entre NEBUSTION.Pass (données pures) et la sauvegarde/économie existantes (même schéma que
 * ShopManager/SkinManager). État dans NEBUSTION.Resources.state.pass (couvert par la sauvegarde
 * automatique). Gère : saison (rotation + compte à rebours), XP Pass, missions quotidiennes/hebdomadaires,
 * réclamation des récompenses (ressources, Prismes, fragments, héros, skins) et branchement (wire) sur les
 * événements du jeu pour faire avancer les missions sans modifier les autres systèmes.
 *
 * Le Premium ne s'obtient QUE via grantPremium() et le Pass Doré (palier supérieur, inclut le Premium) QUE via
 * grantGolden() — toutes deux appelées par PassBilling après un achat confirmé.
 * Colonne de droite du Pass : piste « golden » si le Pass Doré est possédé, sinon piste « premium » (rightTrack()).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.PassManager = (function () {
  'use strict';

  var P = function () { return NEBUSTION.Pass; };
  var root = function () { return NEBUSTION.Resources && NEBUSTION.Resources.state; };
  var fallback = null;   // état de secours quand l'économie n'est pas chargée (tests isolés)

  function state() {
    var r = root(), now = Date.now(), cur;
    if (r) cur = r.pass; else cur = fallback;
    var p = P();
    if (!cur || cur.season !== Math.max(cur.season, p.seasonIndex(now)) || cur.daily.day !== p.dayIndex(now) || cur.weekly.week !== p.weekIndex(now)) {
      cur = p.normalizeState(cur, now);   // nouveau jour / semaine / saison (ou première utilisation)
      if (r) r.pass = cur; else fallback = cur;
    }
    if (cur.claimed && !cur.claimed.golden) cur.claimed.golden = {};   // sauvegardes antérieures au Pass Doré
    return cur;
  }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }

  // ---------- Saison / niveau ----------
  function season() { return P().seasonInfo(Date.now(), state().season); }
  function level() { return P().levelFromXp(state().xp); }
  function isPremium() { return state().premium === true; }
  function isGolden() { return state().golden === true; }
  /** Piste affichée dans la colonne de droite du Pass : « golden » si Pass Doré possédé, sinon « premium ». */
  function rightTrack() { return isGolden() ? 'golden' : 'premium'; }
  function levels() { return P().levelsFor(state().season); }

  function addXp(n) {
    n = Math.floor(Number(n) || 0);
    if (n > 0) n = Math.floor(n * (1 + ((NEBUSTION.PlanetBuild && NEBUSTION.Resources && NEBUSTION.Resources.state && NEBUSTION.Resources.state.planetBuild) ? NEBUSTION.PlanetBuild.effectSum(NEBUSTION.Resources.state.planetBuild, 'passXp') : 0)));   // Centres de formation (Nexus-01)
    var s = state(), from = P().levelFromXp(s.xp).level;
    if (n > 0) s.xp = Math.min(P().MAX_XP, s.xp + n);
    return { from: from, to: P().levelFromXp(s.xp).level, gained: Math.max(0, n) };
  }

  // ---------- Récompenses ----------
  function status(lv, track) {
    var s = state();
    if (s.claimed[track] && s.claimed[track][lv]) return 'claimed';
    if (lv > level().level) return 'locked';
    if (track === 'premium' && !s.premium) return 'premium_locked';
    if (track === 'golden' && !s.golden) return 'golden_locked';
    return 'available';
  }

  function _deliver(rw) {
    var R = NEBUSTION.Resources;
    if (rw.kind === 'res') {
      var room = R.cap(rw.res) - R.state.res[rw.res];
      if (room < rw.amount - 1e-9) return { ok: false, reason: 'stockage', res: rw.res };
      R.add(rw.res, rw.amount, 'pass');
      return { ok: true };
    }
    if (rw.kind === 'chest') {   // Coffret cosmique : tout ou rien (il faut de la place pour chaque ressource)
      for (var ci = 0; ci < rw.items.length; ci++) {
        var it = rw.items[ci], cr = R.cap(it.res) - R.state.res[it.res];
        if (cr < it.amount - 1e-9) return { ok: false, reason: 'stockage', res: it.res };
      }
      rw.items.forEach(function (it2) { R.add(it2.res, it2.amount, 'pass'); });
      return { ok: true };
    }
    if (rw.kind === 'gems') { NEBUSTION.ShopManager.addGems(rw.amount); return { ok: true }; }
    if (rw.kind === 'frag' || rw.kind === 'hero') {
      var f = NEBUSTION.Combat.addFragments(rw.heroId, rw.amount);
      return f.ok ? { ok: true, heroLevel: f.level } : { ok: false, reason: 'invalide' };
    }
    if (rw.kind === 'troop') {
      var tg = NEBUSTION.TroopManager ? NEBUSTION.TroopManager.grant(rw.troopId, rw.amount) : { ok: false };
      return tg.ok ? { ok: true } : { ok: false, reason: 'invalide' };
    }
    if (rw.kind === 'skin') {
      var k = NEBUSTION.SkinManager.grant(rw.skinId);
      if (!k.ok) return { ok: false, reason: 'invalide' };
      if (k.dup) {
        var g = P().DUP_GEMS[k.skin.rarity] || 10;
        NEBUSTION.ShopManager.addGems(g);
        return { ok: true, dup: true, convertedGems: g };
      }
      return { ok: true };
    }
    return { ok: false, reason: 'invalide' };
  }

  function claim(lv, track) {
    lv = Math.floor(lv);
    if (track !== 'free' && track !== 'premium' && track !== 'golden') return { ok: false, reason: 'invalide' };
    var st = status(lv, track);
    if (st === 'claimed') return { ok: false, reason: 'deja' };
    if (st === 'locked') return { ok: false, reason: 'verrouille' };
    if (st === 'premium_locked') return { ok: false, reason: 'premium' };
    if (st === 'golden_locked') return { ok: false, reason: 'golden' };
    var rw = P().reward(state().season, lv, track);
    if (!rw) return { ok: false, reason: 'invalide' };
    var d = _deliver(rw);
    if (!d.ok) return d;
    var s = state();
    s.claimed[track][lv] = true;
    s.stats.claims += 1;
    save();
    return { ok: true, level: lv, track: track, reward: rw, dup: !!d.dup, convertedGems: d.convertedGems || 0 };
  }

  function claimableList() {
    var out = [], lv = level().level;
    var tracks = ['free', rightTrack()];
    for (var i = 1; i <= lv; i++) tracks.forEach(function (t) { if (status(i, t) === 'available') out.push({ level: i, track: t }); });
    return out;
  }
  function claimAll() {
    var done = [], blocked = [];
    claimableList().forEach(function (c) {
      var r = claim(c.level, c.track);
      if (r.ok) done.push(r); else blocked.push({ level: c.level, track: c.track, reason: r.reason, res: r.res });
    });
    return { ok: done.length > 0, claimed: done, blocked: blocked };
  }

  // ---------- Missions ----------
  function _list(kind) { var s = state(); return kind === 'weekly' ? s.weekly.list : s.daily.list; }
  function missions(kind) {
    return _list(kind).map(function (m) {
      var d = P().mission(m.id);
      return { id: m.id, kind: kind, label: d.label, metric: d.metric, target: d.target, xp: d.xp, p: m.p, claimed: m.c,
        status: m.c ? 'claimed' : (m.p >= d.target ? 'ready' : 'progress') };
    });
  }
  function msUntilReset(kind) { return kind === 'weekly' ? P().msUntilNextWeek(Date.now()) : P().msUntilNextDay(Date.now()); }

  function claimMission(kind, id) {
    var m = _list(kind).filter(function (x) { return x.id === id; })[0], d = P().mission(id);
    if (!m || !d) return { ok: false, reason: 'invalide' };
    if (m.c) return { ok: false, reason: 'deja' };
    if (m.p < d.target) return { ok: false, reason: 'incomplete' };
    m.c = true;
    state().stats.missions += 1;
    var x = addXp(d.xp);
    save();
    return { ok: true, id: id, xp: d.xp, from: x.from, to: x.to };
  }
  function claimAllMissions() {
    var total = 0, from = level().level, n = 0;
    ['daily', 'weekly'].forEach(function (k) {
      missions(k).forEach(function (m) { if (m.status === 'ready') { var r = claimMission(k, m.id); if (r.ok) { total += r.xp; n++; } } });
    });
    return { ok: n > 0, count: n, xp: total, from: from, to: level().level };
  }
  function readyMissionCount() {
    return missions('daily').concat(missions('weekly')).filter(function (m) { return m.status === 'ready'; }).length;
  }

  /** Fait avancer les missions d'une métrique (login, tap, pod, upgrade, battle, win, purchase, gift). */
  function track(metric, amount) {
    amount = Math.floor(Number(amount) || 1);
    if (amount <= 0) return;
    var changed = false;
    ['daily', 'weekly'].forEach(function (k) {
      _list(k).forEach(function (m) {
        var d = P().mission(m.id);
        if (d && d.metric === metric && !m.c && m.p < d.target) { m.p = Math.min(d.target, m.p + amount); changed = true; }
      });
    });
    return changed;
  }

  /** Compte un jour de connexion (une fois par jour). Appelé au démarrage et à l'ouverture du Pass. */
  function touch() {
    var s = state(), d = P().dayIndex(Date.now());
    if (s.lastLoginDay !== d) { s.lastLoginDay = d; track('login', 1); }
  }

  // ---------- Premium (activé uniquement par PassBilling après un achat confirmé) ----------
  function grantPremium(info) {
    var s = state();
    s.premium = true;
    s.premiumSource = (info && typeof info.source === 'string') ? info.source.slice(0, 40) : 'inconnu';
    save();
    return true;
  }

  /** Pass Doré : inclut aussi le Premium. Les niveaux déjà passés deviennent réclamables sur la piste dorée. */
  function grantGolden(info) {
    var s = state();
    s.golden = true;
    s.goldenSource = (info && typeof info.source === 'string') ? info.source.slice(0, 40) : 'inconnu';
    if (!s.premium) { s.premium = true; s.premiumSource = s.goldenSource; }
    save();
    return true;
  }

  // ---------- Branchement sur le jeu existant (sans toucher aux autres systèmes) ----------
  var wired = false;
  function wire() {
    if (wired) return;
    wired = true;
    var R = NEBUSTION.Resources;
    if (R) {
      if (typeof R.on === 'function') R.on('upgrade', function () { track('upgrade', 1); });
      if (typeof R.tap === 'function') { var oTap = R.tap.bind(R); R.tap = function (id, now) { var r = oTap(id, now); if (r && r.ok) track('tap', 1); return r; }; }
      if (typeof R.claimPod === 'function') { var oPod = R.claimPod.bind(R); R.claimPod = function (now) { var r = oPod(now); track('pod', 1); return r; }; }
    }
    var C = NEBUSTION.Combat;
    if (C) {
      [['grantRewards', 2], ['grantInvasionRewards', 1]].forEach(function (pair) {
        var name = pair[0], idx = pair[1], orig = C[name];
        if (typeof orig !== 'function') return;
        C[name] = function () { var out = orig.apply(C, arguments), res = arguments[idx]; track('battle', 1); if (res && res.win) track('win', 1); return out; };
      });
    }
    var SM = NEBUSTION.ShopManager;
    if (SM) {
      ['buyDaily', 'buyHeroPack', 'buyHero', 'buyEquipment', 'buyEvent', 'buyTroop'].forEach(function (n) {
        var o = SM[n]; if (typeof o !== 'function') return;
        SM[n] = function () { var r = o.apply(SM, arguments); if (r && r.ok) track('purchase', 1); return r; };
      });
      var oGift = SM.claimDailyGift;
      if (typeof oGift === 'function') SM.claimDailyGift = function () { var r = oGift.apply(SM, arguments); if (r && r.ok) track('gift', 1); return r; };
    }
    var KM = NEBUSTION.SkinManager;
    if (KM && typeof KM.buy === 'function') { var oBuy = KM.buy; KM.buy = function () { var r = oBuy.apply(KM, arguments); if (r && r.ok) track('purchase', 1); return r; }; }
    try { touch(); } catch (e) { /* ignore */ }
  }

  // ---------- Outils de test (?debug=1 uniquement ; ne simulent PAS un paiement) ----------
  function debugSetPremium(v) { if (!NEBUSTION.DEBUG) return false; var s = state(); s.premium = !!v; s.premiumSource = v ? 'debug' : null; save(); return true; }
  function debugSetGolden(v) { if (!NEBUSTION.DEBUG) return false; var s = state(); s.golden = !!v; s.goldenSource = v ? 'debug' : null; if (v) s.premium = true; save(); return true; }
  function debugAddXp(n) { if (!NEBUSTION.DEBUG) return null; var r = addXp(n); save(); return r; }
  function _reset() { fallback = null; wired = false; }

  return {
    state: state, season: season, level: level, levels: levels, isPremium: isPremium, isGolden: isGolden, rightTrack: rightTrack, addXp: addXp,
    status: status, claim: claim, claimAll: claimAll, claimableList: claimableList,
    missions: missions, msUntilReset: msUntilReset, claimMission: claimMission, claimAllMissions: claimAllMissions, readyMissionCount: readyMissionCount,
    track: track, touch: touch, grantPremium: grantPremium, grantGolden: grantGolden, wire: wire,
    debugSetPremium: debugSetPremium, debugSetGolden: debugSetGolden, debugAddXp: debugAddXp, _reset: _reset
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.PassManager; }
