/**
 * NEBUSTION - ColonyManager
 * Glue entre NEBUSTION.Colonies (données) et la sauvegarde / économie. État : NEBUSTION.Resources.state.colonies.
 * La production s'accumule dans la colonie (plafonnée à CAP_HOURS d'avance, hors ligne compris) puis se récolte.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.ColonyManager = (function () {
  'use strict';
  var C = function () { return NEBUSTION.Colonies; };
  var root = function () { return NEBUSTION.Resources && NEBUSTION.Resources.state; };

  function state() {
    var r = root();
    if (!r) return C().defaultState();
    if (!r.colonies || !r.colonies.colonies) r.colonies = C().normalizeState(r.colonies, Date.now());
    return r.colonies;
  }
  function col(pid) { return state().colonies[pid] || null; }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }
  function pay(cost) {
    var R = NEBUSTION.Resources;
    return R.canAfford(cost) && R.spendMany(cost) !== false;
  }

  function isColonized(pid) { var c = col(pid); return !!(c && c.on); }
  function count() { return C().IDS.filter(isColonized).length; }
  function level(pid, iid) { var c = col(pid); return (c && c.lv[iid]) || 0; }
  /** Multiplicateur global : +5 % par colonie fondée. */
  function bonusMult() { return 1 + C().COLONY_BONUS * count(); }
  function rates(pid) {
    var out = {}, c = col(pid); if (!c || !c.on) return out;
    var m = bonusMult();
    C().get(pid).inst.forEach(function (d) {
      var r = C().rateAt(pid, d.id, c.lv[d.id]) * m;
      if (r > 0) out[d.res] = (out[d.res] || 0) + r;
    });
    return out;
  }
  /** Production en attente (déjà plafonnée à la fenêtre max). */
  function pending(pid, now) {
    var c = col(pid), out = {}; if (!c || !c.on) return out;
    var sec = Math.max(0, Math.min(C().CAP_SEC, ((now || Date.now()) - c.last) / 1000)), r = rates(pid);
    Object.keys(r).forEach(function (k) { out[k] = r[k] * sec; });
    return out;
  }
  function pendingTotal(pid, now) { var p = pending(pid, now); return Object.keys(p).reduce(function (n, k) { return n + p[k]; }, 0); }
  function isFull(pid, now) { var c = col(pid); return !!(c && c.on && ((now || Date.now()) - c.last) / 1000 >= C().CAP_SEC); }

  function colonize(pid, now) {
    var d = C().get(pid), c = col(pid);
    if (!d || !c) return { ok: false, reason: 'invalide' };
    if (c.on) return { ok: false, reason: 'deja' };
    if (!pay(d.colonize)) return { ok: false, reason: 'ressources', cost: d.colonize };
    c.on = true; c.last = now || Date.now(); c.lv = {};
    d.inst.forEach(function (i) { c.lv[i.id] = 1; });     // la fondation offre le niveau 1 de chaque installation
    save();
    return { ok: true, cost: d.colonize };
  }
  function upgrade(pid, iid, now) {
    var c = col(pid), d = C().instDef(pid, iid);
    if (!c || !c.on || !d) return { ok: false, reason: 'invalide' };
    var lv = c.lv[iid] || 0;
    if (lv >= C().MAX_LEVEL) return { ok: false, reason: 'max' };
    var cost = C().upgradeCost(pid, iid, lv);
    // Encaisse d'abord la production au taux actuel : améliorer ne « réécrit » pas le passé.
    var got = collect(pid, now, true);
    if (!pay(cost)) return { ok: false, reason: 'ressources', cost: cost };
    c.lv[iid] = lv + 1; save();
    return { ok: true, level: lv + 1, cost: cost, collected: got.gained };
  }
  /** Récolte. Ce qui ne rentre pas dans le stockage du QG reste dans la colonie (rien n'est perdu sauf le plafond de temps). */
  function collect(pid, now, silent) {
    var c = col(pid); now = now || Date.now();
    if (!c || !c.on) return { ok: false, reason: 'invalide', gained: {} };
    var p = pending(pid, now), gained = {}, any = false, leftover = false, R = NEBUSTION.Resources;
    Object.keys(p).forEach(function (k) {
      var a = R.add(k, p[k], 'colony');
      if (a > 0) { gained[k] = a; any = true; }
      if (a < p[k] - 1e-6) leftover = true;
    });
    if (!any && Object.keys(p).length) return { ok: false, reason: 'plein', gained: {} };
    if (!leftover) c.last = now;                       // tout est entré : on repart de zéro
    else {                                             // stockage plein : on ne consomme que la part récoltée (approximation proportionnelle au temps)
      var tot = 0, took = 0; Object.keys(p).forEach(function (k) { tot += p[k]; took += (gained[k] || 0); });
      var sec = (now - c.last) / 1000, used = tot > 0 ? sec * (took / tot) : 0;
      c.last = Math.min(now, c.last + used * 1000);
    }
    if (!silent) save();
    return { ok: any, gained: gained, partial: leftover };
  }
  function collectAll(now) {
    var total = {}, ok = false;
    C().IDS.forEach(function (pid) {
      if (!isColonized(pid)) return;
      var r = collect(pid, now, true);
      Object.keys(r.gained || {}).forEach(function (k) { total[k] = (total[k] || 0) + r.gained[k]; ok = true; });
    });
    if (ok) save();
    return { ok: ok, gained: total };
  }
  /** Pastille de notification : une colonie a atteint son plafond de stockage. */
  function anyFull(now) { return C().IDS.some(function (p) { return isFull(p, now); }); }

  return { state: state, isColonized: isColonized, count: count, level: level, bonusMult: bonusMult, rates: rates, pending: pending,
    pendingTotal: pendingTotal, isFull: isFull, colonize: colonize, upgrade: upgrade, collect: collect, collectAll: collectAll, anyFull: anyFull };
})();
