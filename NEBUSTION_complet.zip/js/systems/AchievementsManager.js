/**
 * NEBUSTION - AchievementsManager
 * Glue entre NEBUSTION.Achievements (données pures) et le reste du jeu déjà en place :
 * lit les valeurs courantes (niveau de bâtiment, victoires, étoiles, planètes conquises,
 * héros recrutés, reliques...) directement dans les autres systèmes, sans les modifier.
 * État dans NEBUSTION.Resources.state.achievements : { claimed:{id:tier}, daily:{streak,
 * lastClaimDay, bestStreak, totalClaims} }. RIEN ici n'est réinitialisé par une Renaissance.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.AchievementsManager = (function () {
  'use strict';

  var A = function () { return NEBUSTION.Achievements; };
  var DAY_MS = 86400000;

  function root() { return NEBUSTION.Resources && NEBUSTION.Resources.state; }
  function _localDay(now) { now = now || Date.now(); return Math.floor((now - new Date(now).getTimezoneOffset() * 60000) / DAY_MS); }

  function defaultState() { return { v: 2, claimed: {}, peak: {}, daily: { streak: 0, lastClaimDay: -1, bestStreak: 0, totalClaims: 0 } }; }
  function normalizeState(raw) {
    var s = defaultState();
    if (!raw || typeof raw !== 'object') return s;
    var rc = raw.claimed || {};
    A().all().forEach(function (def) {
      var v = Math.max(0, Math.min(def.tiers.length, Math.floor(Number(rc[def.id]) || 0)));
      if (v > 0) s.claimed[def.id] = v;
    });
    var rp = raw.peak || {};
    Object.keys(METRICS).forEach(function (m) { var v = Number(rp[m]); if (isFinite(v) && v > 0) s.peak[m] = Math.min(1e12, Math.floor(v)); });
    var rd = raw.daily || {};
    s.daily = {
      streak: Math.max(0, Math.floor(Number(rd.streak) || 0)),
      lastClaimDay: isFinite(rd.lastClaimDay) ? Math.floor(rd.lastClaimDay) : -1,
      bestStreak: Math.max(0, Math.floor(Number(rd.bestStreak) || 0)),
      totalClaims: Math.max(0, Math.floor(Number(rd.totalClaims) || 0))
    };
    return s;
  }
  function state() {
    var r = root();
    if (!r) return defaultState();
    if (!r.achievements) r.achievements = defaultState();
    return r.achievements;
  }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }

  // ---------- Lecture des métriques (délègue aux systèmes déjà en place) ----------
  function _sumStageStars() {
    var r = root(), ss = (r && r.combat && r.combat.stageStars) || {};
    return Object.keys(ss).reduce(function (s, k) { return s + (ss[k] || 0); }, 0);
  }
  function _conqueredPlanets() {
    var r = root(), c = (r && r.galaxy && r.galaxy.conquered) || {};
    return Object.keys(c).filter(function (k) { return c[k]; }).length;
  }
  function _heroesUnlocked() {
    var H = NEBUSTION.Heroes, C = NEBUSTION.Combat;
    if (!H || !C) return 0;
    return H.all().filter(function (h) { return C.isUnlocked(h.id); }).length;
  }
  var METRICS = {
    commandLevel: function () { var r = root(); return (r && r.buildings && r.buildings.command && r.buildings.command.level) || 0; },
    battlesWon: function () { var r = root(); return (r && r.combat && r.combat.battlesWon) || 0; },
    totalStars: _sumStageStars,
    conqueredPlanets: _conqueredPlanets,
    expeditionsCompleted: function () { return NEBUSTION.ExpeditionManager ? NEBUSTION.ExpeditionManager.stats().completed : 0; },
    heroesUnlocked: _heroesUnlocked,
    eventBossKills: function () { var r = root(); return (r && r.events && r.events.stats && r.events.stats.bossKills) || 0; },
    prestigeCount: function () { return NEBUSTION.PrestigeManager ? NEBUSTION.PrestigeManager.count() : 0; },
    relicsTotal: function () { return NEBUSTION.PrestigeManager ? NEBUSTION.PrestigeManager.totalEarned() : 0; }
  };
  /** Valeur d'une métrique = meilleure valeur JAMAIS atteinte (une Renaissance remet la progression à zéro, pas les succès). */
  function valueOf(metric) {
    var fn = METRICS[metric];
    if (!fn) return 0;
    var v = Math.max(0, Math.floor(Number(fn()) || 0));
    var r = root();
    if (!r) return v;
    var s = state();
    if (!s.peak) s.peak = {};
    if (v > (s.peak[metric] || 0)) s.peak[metric] = v;
    return Math.max(v, s.peak[metric] || 0);
  }
  /** Mémorise toutes les valeurs actuelles (appelé juste avant une Renaissance). */
  function snapshot() { Object.keys(METRICS).forEach(function (m) { valueOf(m); }); }

  // ---------- Succès / objectifs long terme ----------
  function list(category) {
    var s = state();
    return A().all().filter(function (d) { return !category || d.category === category; }).map(function (def) {
      var value = valueOf(def.metric);
      var reached = A().tierReached(def, value);
      var claimed = s.claimed[def.id] || 0;
      var nextTier = Math.min(def.tiers.length - 1, claimed);
      return {
        id: def.id, name: def.name, unit: def.unit, category: def.category,
        value: value, tiers: def.tiers, rewards: def.rewards,
        reached: reached, claimed: claimed, claimable: reached > claimed,
        nextTarget: claimed < def.tiers.length ? def.tiers[nextTier] : null,
        maxed: claimed >= def.tiers.length
      };
    });
  }
  /** Récompense générique : { gem: N } et/ou ressources — soit à plat ({dust:N}, succès), soit sous res:{} (calendrier quotidien). */
  function _deliverReward(rw) {
    rw = rw || {};
    var granted = {};
    if (rw.gem) { if (NEBUSTION.ShopManager) NEBUSTION.ShopManager.addGems(rw.gem); granted.gems = rw.gem; }
    if (rw.xon) { if (NEBUSTION.ShopManager) NEBUSTION.ShopManager.addXon(rw.xon); granted.xon = rw.xon; }
    var resObj = rw.res || rw;
    Object.keys(resObj).forEach(function (k) {
      if (NEBUSTION.Economy.RES[k]) granted[k] = NEBUSTION.Resources.add(k, resObj[k], 'reward') || 0;
    });
    return granted;
  }
  function claim(id) {
    var def = A().get(id);
    if (!def) return { ok: false, reason: 'invalide' };
    var s = state(), claimed = s.claimed[id] || 0;
    var reached = A().tierReached(def, valueOf(def.metric));
    if (reached <= claimed) return { ok: false, reason: 'verrouille' };
    var tier = claimed; // index du palier à réclamer (0-based)
    var rw = def.rewards[tier];
    var granted = _deliverReward(rw);
    s.claimed[id] = claimed + 1;
    save();
    return { ok: true, tier: tier + 1, tierName: A().TIERS[tier] || null, reward: rw, granted: granted };
  }
  function claimableCount() { return list().filter(function (a) { return a.claimable; }).length; }

  // ---------- Récompense quotidienne (calendrier 7 jours) ----------
  function dailyStatus(now) {
    now = now || Date.now();
    var s = state(), day = _localDay(now);
    // Strictement APRÈS le dernier jour réclamé : reculer l'horloge ne redonne jamais de récompense quotidienne.
    var available = day > s.daily.lastClaimDay;
    var nextStreak = (s.daily.lastClaimDay === day - 1 || !available) ? s.daily.streak + 1 : 1;   // réclamé aujourd'hui : on annonce la récompense de demain
    var n = A().DAILY_REWARDS.length;
    return {
      available: available, streak: s.daily.streak, nextStreak: nextStreak, bestStreak: s.daily.bestStreak,
      reward: A().dailyReward(nextStreak), cycleDay: ((nextStreak - 1) % n) + 1, cycleLength: n,
      // jours du cycle de 7 déjà réclamés (série active uniquement)
      doneInCycle: !available ? (((Math.max(1, s.daily.streak) - 1) % n) + 1) : (nextStreak === 1 ? 0 : (s.daily.streak % n))
    };
  }
  function claimDaily(now) {
    now = now || Date.now();
    var st = dailyStatus(now);
    if (!st.available) return { ok: false, reason: 'deja' };
    var s = state(), day = _localDay(now);
    s.daily.streak = st.nextStreak;
    s.daily.lastClaimDay = day;
    s.daily.bestStreak = Math.max(s.daily.bestStreak, s.daily.streak);
    s.daily.totalClaims += 1;
    var granted = _deliverReward(st.reward);
    save();
    return { ok: true, streak: s.daily.streak, reward: st.reward, granted: granted };
  }

  return {
    defaultState: defaultState, normalizeState: normalizeState,
    valueOf: valueOf, snapshot: snapshot, list: list, claim: claim, claimableCount: claimableCount,
    dailyStatus: dailyStatus, claimDaily: claimDaily
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.AchievementsManager; }
