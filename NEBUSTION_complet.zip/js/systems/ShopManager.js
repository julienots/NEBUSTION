/**
 * NEBUSTION - ShopManager
 * Glue entre NEBUSTION.Shop (données pures) et la sauvegarde/économie existantes, même schéma
 * que SkinManager/EquipmentManager. État dans NEBUSTION.Resources.state.shop (couvert par la
 * sauvegarde automatique déjà en place). Gère la monnaie premium (Prismes), les achats
 * mixtes (ressources + Prismes), la rotation quotidienne et la livraison des récompenses.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.ShopManager = (function () {
  'use strict';

  var S = function () { return NEBUSTION.Shop; };
  var root = function () { return NEBUSTION.Resources && NEBUSTION.Resources.state; };

  function state() {
    var r = root();
    if (!r) return S().defaultState(Date.now());
    if (!r.shop) r.shop = S().normalizeState(null, Date.now());
    _rollDay(r.shop);
    return r.shop;
  }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }

  /** Change de jour : la rotation d'offres et les achats "aujourd'hui" repartent à zéro. */
  function _rollDay(s) {
    var idx = S().dayIndex(Date.now());
    if (s.dayIndex !== idx) { s.dayIndex = idx; s.purchasedToday = {}; }
  }

  function gems() { return state().gems; }
  function xon() { return state().xon; }

  // ---------- Coûts mixtes (ressources classiques + Prismes) ----------
  function canAfford(cost) {
    cost = cost || {};
    if (cost.gem && gems() < cost.gem) return false;
    if (cost.xon && xon() < cost.xon) return false;
    var resCost = Object.assign({}, cost);
    delete resCost.gem;
    delete resCost.xon;
    if (Object.keys(resCost).length && !NEBUSTION.Resources.canAfford(resCost)) return false;
    return true;
  }
  function spend(cost) {
    if (!canAfford(cost)) return false;
    var s = state();
    var resCost = Object.assign({}, cost);
    delete resCost.gem;
    delete resCost.xon;
    if (Object.keys(resCost).length) NEBUSTION.Resources.spendMany(resCost);
    if (cost.gem) s.gems -= cost.gem;
    if (cost.xon) s.xon -= cost.xon;
    return true;
  }
  function addGems(amount) {
    amount = Math.floor(Number(amount) || 0);
    if (amount <= 0) return;
    state().gems += amount;
  }

  /** Jetons Xon : monnaie ultra-rare, conservée par les resets et plafonnée par Shop.XON.max. */
  function addXon(amount) {
    amount = Math.floor(Number(amount) || 0);
    if (amount <= 0) return 0;
    var s = state(), before = s.xon;
    s.xon = Math.min(S().XON.max, before + amount);
    return s.xon - before;
  }

  // ---------- Cadeau quotidien de Prismes ----------
  function giftAvailable() { return state().lastGiftDay !== S().dayIndex(Date.now()); }
  function claimDailyGift() {
    var s = state();
    if (!giftAvailable()) return { ok: false, reason: 'deja' };
    s.lastGiftDay = S().dayIndex(Date.now());
    addGems(S().DAILY_GIFT_GEMS);
    save();
    return { ok: true, amount: S().DAILY_GIFT_GEMS };
  }

  // ---------- Livraison d'une récompense d'offre ----------
  function _deliver(offer) {
    if (offer.kind === 'resource' || offer.kind === 'bundle') {
      Object.keys(offer.res).forEach(function (rid) { NEBUSTION.Resources.add(rid, offer.res[rid], 'shop'); });
      return { res: offer.res };
    }
    if (offer.kind === 'gems') {
      addGems(offer.amount);
      return { gems: offer.amount };
    }
    if (offer.kind === 'equipment') {
      var res = NEBUSTION.EquipmentManager.grant(offer.slot, offer.rarity);
      return { item: res.item };
    }
    return {};
  }

  // ---------- Boutique quotidienne ----------
  function dailyOffers() { return S().dailyOffers(Date.now()); }
  function isPurchasedToday(offerId) { return !!state().purchasedToday[offerId]; }
  function msUntilRefresh() { return S().msUntilNextDay(Date.now()); }

  function buyDaily(offerId) {
    var offer = dailyOffers().filter(function (o) { return o.id === offerId; })[0];
    if (!offer) return { ok: false, reason: 'invalide' };
    var s = state();
    if (s.purchasedToday[offerId]) return { ok: false, reason: 'deja' };
    if (!canAfford(offer.cost)) return { ok: false, reason: 'ressources', cost: offer.cost };
    spend(offer.cost);
    var delivered = _deliver(offer);
    s.purchasedToday[offerId] = true;
    save();
    return { ok: true, offer: offer, delivered: delivered };
  }

  // ---------- Boutique de héros (paquets de fragments) ----------
  function buyHeroPack(packId, heroId) {
    var pack = S().HERO_PACKS.filter(function (p) { return p.id === packId; })[0];
    if (!pack) return { ok: false, reason: 'invalide' };
    var heroForPack = NEBUSTION.Heroes.get(heroId);
    if (!heroForPack) return { ok: false, reason: 'heros' };
    // Un héros obtenu uniquement par fragments (shop.fragmentsToUnlock, ex. Aetherion) peut recevoir
    // des fragments même verrouillé : c'est justement ce qui le déverrouille. Les autres héros de
    // Boutique (shop.cost) doivent d'abord être recrutés avant que leurs fragments ne s'achètent.
    var fragmentGated = !!(heroForPack.shop && heroForPack.shop.fragmentsToUnlock);
    if (!fragmentGated && !NEBUSTION.Combat.isUnlocked(heroId)) return { ok: false, reason: 'verrouille' };
    if (!canAfford(pack.cost)) return { ok: false, reason: 'ressources', cost: pack.cost };
    spend(pack.cost);
    var res = NEBUSTION.Combat.addFragments(heroId, pack.amount);
    save();
    return { ok: true, pack: pack, heroId: heroId, total: res.total, level: res.level };
  }

  // ---------- Recrutement des héros exclusifs de la Boutique (étape 9) ----------
  function heroOffers() { return NEBUSTION.Heroes.shopHeroes(); }
  function buyHero(heroId) {
    var hero = NEBUSTION.Heroes.get(heroId);
    // Les héros obtenus uniquement par fragments (shop.fragmentsToUnlock) n'ont pas de `cost` :
    // ils ne se recrutent jamais directement contre des Prismes, uniquement via buyHeroPack.
    if (!hero || !hero.shop || !hero.shop.cost) return { ok: false, reason: 'invalide' };
    if (NEBUSTION.Combat.isUnlocked(heroId)) return { ok: false, reason: 'deja' };
    var cost = hero.shop.cost;
    if (!canAfford(cost)) return { ok: false, reason: 'ressources', cost: cost };
    spend(cost);
    NEBUSTION.Combat.unlockHero(heroId);
    save();
    return { ok: true, hero: hero, cost: cost };
  }

  // ---------- Boutique d'équipements ----------
  // ---------- Cartes personnalisées / Atelier de cartes ----------
  function customCards() {
    return (NEBUSTION.NebustionCustomCards && NEBUSTION.NebustionCustomCards.all)
      ? NEBUSTION.NebustionCustomCards.all() : [];
  }
  function isCustomCardOwned(cardId) {
    return !!state().customCards[String(cardId)];
  }
  function buyCustomCard(cardId) {
    var card = customCards().filter(function (c) { return c.id === cardId; })[0];
    if (!card) return { ok: false, reason: 'invalide' };
    var s = state();
    if (s.customCards[cardId]) return { ok: false, reason: 'deja' };
    var cost = card.cost || {};
    if (!canAfford(cost)) return { ok: false, reason: 'ressources', cost: cost };
    spend(cost);
    s.customCards[cardId] = true;
    save();
    return { ok: true, card: card, cost: cost };
  }

  function buyEquipment(slot, rarityId) {
    var Q = NEBUSTION.Equipment;
    if (Q.SLOT_ORDER.indexOf(slot) < 0 || S().EQUIPMENT_RARITIES.indexOf(rarityId) < 0) return { ok: false, reason: 'invalide' };
    var cost = S().EQUIPMENT_PRICE[rarityId];
    if (!canAfford(cost)) return { ok: false, reason: 'ressources', cost: cost };
    spend(cost);
    var res = NEBUSTION.EquipmentManager.grant(slot, rarityId);
    save();
    return { ok: true, item: res.item, cost: cost };
  }

  // ---------- Troupes de combat (module 18) : achat en boutique, onglet « Troupes » ----------
  function troopCost(troopId, qty) {
    if (NEBUSTION.TroopManager) return NEBUSTION.TroopManager.cost(troopId, qty || 1);   // prix réel : remise des Ateliers incluse
    return NEBUSTION.Troops ? NEBUSTION.Troops.cost(troopId, qty || 1) : {};
  }
  function buyTroop(troopId, qty) {
    var T = NEBUSTION.Troops, TM = NEBUSTION.TroopManager;
    qty = Math.max(1, Math.floor(Number(qty) || 1));
    if (!T || !TM || !T.get(troopId) || qty > 50) return { ok: false, reason: 'invalide' };
    if (T.get(troopId).space * qty > TM.free()) return { ok: false, reason: 'capacite' };
    var cost = TM.cost(troopId, qty);
    if (!canAfford(cost)) return { ok: false, reason: 'ressources', cost: cost };
    var r = TM.buy(troopId, qty);
    return r.ok ? { ok: true, cost: cost, count: r.count } : { ok: false, reason: r.reason, cost: cost };
  }

  // ---------- Boutique événementielle ----------
  function eventOffer() { return S().EVENT_OFFER; }
  function isEventBought() { return state().eventBought; }
  function buyEvent() {
    var s = state(), offer = S().EVENT_OFFER;
    if (s.eventBought) return { ok: false, reason: 'deja' };
    if (!canAfford(offer.cost)) return { ok: false, reason: 'ressources', cost: offer.cost };
    spend(offer.cost);
    Object.keys(offer.contents).forEach(function (id) {
      if (id === 'gem') addGems(offer.contents.gem);
      else NEBUSTION.Resources.add(id, offer.contents[id], 'shop');
    });
    s.eventBought = true;
    save();
    return { ok: true, contents: offer.contents };
  }

  return {
    gems: gems, addGems: addGems, xon: xon, addXon: addXon, canAfford: canAfford,
    giftAvailable: giftAvailable, claimDailyGift: claimDailyGift,
    dailyOffers: dailyOffers, isPurchasedToday: isPurchasedToday, msUntilRefresh: msUntilRefresh, buyDaily: buyDaily,
    buyHeroPack: buyHeroPack, heroOffers: heroOffers, buyHero: buyHero,
    buyEquipment: buyEquipment, buyTroop: buyTroop, troopCost: troopCost,
    customCards: customCards, isCustomCardOwned: isCustomCardOwned, buyCustomCard: buyCustomCard,
    eventOffer: eventOffer, isEventBought: isEventBought, buyEvent: buyEvent
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.ShopManager; }
