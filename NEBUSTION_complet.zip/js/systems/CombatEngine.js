/**
 * NEBUSTION - CombatEngine
 * Simulation de combat en temps réel à jauges (ATB), AUCUNE dépendance à Phaser :
 * JavaScript pur, testable sous Node (comme Economy.js / Heroes.js). La scène Phaser
 * (CombatScene) appelle update(dt) puis lit consumeEvents() pour les traduire en animations.
 *
 * Principes
 *  - Chaque unité a une jauge d'action qui se remplit selon sa VITESSE ; à 100 elle agit :
 *    attaque de base automatique, ou compétence active si elle est prête (mode AUTO).
 *  - L'ultime se charge en attaquant / en subissant des dégâts ; à 100 il part tout seul
 *    (mode AUTO) ou attend un ordre du joueur (mode MANUEL, requestUltimate).
 *  - En MANUEL, la compétence active ne part que sur ordre du joueur (requestSkill) ; en
 *    AUTO, le joueur peut aussi la déclencher à la main. Un ordre est exécuté immédiatement.
 *  - Chaque héros a son propre KIT (HERO_KIT ci-dessous) qui traduit fidèlement ses 3
 *    compétences décrites dans js/data/Heroes.js : passif, active, ultime (multi-coups,
 *    boucliers, étourdissements, poisons/brûlures, provocation, buffs, action supplémentaire,
 *    réanimation...). Un héros ajouté plus tard SANS kit reste jouable : deriveHeroSkill()
 *    déduit alors un comportement générique depuis son rôle et la cible de sa compétence.
 *  - Les ennemis/boss (js/data/Enemies.js) définissent directement kind / power / cooldown.
 *
 * Événements produits (consumeEvents) : attack, skill, ultimate, damage, miss, heal, shield,
 * buff, debuff, stun, taunt, cleanse, extra, revive, death, phase, bossNova, victory, defeat,
 * focus, combo, comboReset, break, reaction.
 * Mécaniques avancées : verrouillage de cible, combo d'équipe (+20 % max), jauge de rupture
 * des ennemis/boss et réactions élémentaires (Combustion, Corrosion, Choc thermique).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.CombatEngine = (function () {
  'use strict';

  // ---------- Constantes d'équilibrage (tout se règle ICI) ----------
  var CFG = {
    GAUGE_MAX: 100,
    GAUGE_RATE: 24,               // vitesse 100 -> 24 de jauge/s -> une action toutes les ~4 s
    ENERGY_MAX: 100,
    ENERGY_PER_BASIC: 9,
    ENERGY_PER_SKILL: 14,
    ENERGY_FROM_DAMAGE: 300,      // énergie gagnée = (PV perdus / PV max) x 300
    DAMAGE_SCALE: 0.26,           // rythme global : allonge les combats sans toucher aux stats affichées
    ENEMY_DAMAGE: 2.4,            // les ennemis frappent plus fort (sinon les héros, bien plus forts, ne risquent rien)
    HEAL_SCALE: 1.25,             // soins et boucliers, relativement aux dégâts
    ENRAGE_START: 100,            // après N secondes, les ennemis entrent en RAGE (évite les combats sans fin)
    ENRAGE_STEP: 0.2,             // +20 % de dégâts ennemis toutes les 10 s de rage
    BASE_CRIT_CHANCE: 0.06,
    BASE_CRIT_MULT: 1.7,
    STUN_DURATION: 1.6,
    DOT_TICK: 1.0,
    ENEMY_FOCUS_LOWEST: 0.55,      // part des attaques ennemies visant l'allié le plus faible (sinon au hasard)
    COMBO_WINDOW: 4.0,             // secondes sans impact joueur avant rupture du combo
    COMBO_MAX: 10,                  // +2 % dégâts / combo, plafonné à +20 %
    BREAK_MAX: 100,                 // jauge de rupture des ennemis
    BREAK_PER_SKILL: 18,            // rupture gagnée par une compétence
    BREAK_PER_ULT: 34,              // rupture gagnée par un ultime
    BREAK_DURATION: 3.0,             // vulnérabilité après rupture
    BREAK_DAMAGE_MULT: 1.22,
    // ---- Formation (positionnement avant/arrière) ----
    FRONT_ATK_MULT: 1.08,           // avant : dégâts infligés +8 %
    FRONT_TAKEN_MULT: 1.0,          // avant : dégâts subis normaux (mais ciblé en priorité)
    BACK_ATK_MULT: 0.90,            // arrière : dégâts infligés -10 %
    BACK_TAKEN_MULT: 0.80,          // arrière : dégâts subis -20 %
    FRONT_AGGRO: 0.72,               // part des attaques ennemies sans provocation visant la ligne avant
    // ---- Frappe du Commandant (attaque spéciale activable par le joueur, hors héros) ----
    STRIKE_MAX: 100,
    STRIKE_GAIN: 34,                 // gain = (dégâts / PV max cible) x STRIKE_GAIN
    STRIKE_POWER: 2.6,               // puissance de la frappe, basée sur l'ATQ moyenne de l'équipe
    STRIKE_STUN: 0.8
  };
  var GAUGE_MAX = CFG.GAUGE_MAX, ENERGY_MAX = CFG.ENERGY_MAX;

  // ---------- Passifs de repli par rôle (héros sans kit dédié) ----------
  var ROLE_PASSIVE = {
    assassin: { critChance: 0.15 },
    tank: { hpHalfDR: 0.12 },
    healer: { regenAllies: 0.01 },
    damage: { reflect: 0.08 },
    sniper: { isolated: 0.20 },
    control: { slowOnHit: 0.05 },
    support: { teamDR: 0.05 },
    dps: { atkMult: 1.05 },
    god: { teamDR: 0.10 }
  };

  // ---------- Kits de compétences : un par héros (fidèles à Heroes.js) ----------
  // Opérations : dmg{tgt,power,count,gap,forceCrit} heal{tgt,power|pctMax} shield{tgt,base,power,dur}
  //   stun{tgt,dur} buff{tgt,stats:{atk,def,spd},dur} slow{tgt,mult,dur} dot{tgt,kind,power,dur}
  //   taunt{dur} cleanse{tgt} extra{tgt} miss{tgt,chance,dur}
  // Cibles : primary, second (ennemi derrière la cible), all, self, lowestAlly, allAllies, bestAlly
  var HERO_KIT = {
    // Aetherion (Dieu Supérieur, Céleste) : Origine cosmique protège toute l'équipe en continu ;
    // Rupture stellaire frappe et ralentit tous les ennemis ; Absorption cosmique donne à toute
    // l'équipe un bouclier massif (quasi-total pendant 3 s) puis restaure entièrement ses PV.
    aetherion: {
      passive: { teamDR: 0.10 },
      active: [{ op: 'dmg', tgt: 'all', power: 1.15 }, { op: 'slow', tgt: 'all', mult: 0.85, dur: 3 }],
      ultimate: [{ op: 'shield', tgt: 'allAllies', base: 'def', power: 3.2, dur: 3 }, { op: 'heal', tgt: 'allAllies', pctMax: 1.0 }]
    },
    zyra: {
      passive: { critChance: 0.15, critCdRefund: 1 },
      active: [{ op: 'dmg', tgt: 'primary', power: 0.66, count: 3, gap: 0.18 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 1.25, forceCrit: true }]
    },
    korvax: {
      passive: { hpHalfDR: 0.12 },
      active: [{ op: 'shield', tgt: 'self', base: 'def', power: 1.5, dur: 4 }, { op: 'taunt', dur: 4 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 0.7 }, { op: 'stun', tgt: 'all', dur: 1.6 }, { op: 'heal', tgt: 'self', pctMax: 0.20 }]
    },
    lumina: {
      passive: { regenAllies: 0.01 },
      active: [{ op: 'heal', tgt: 'lowestAlly', power: 1.7 }, { op: 'shield', tgt: 'lowestAlly', base: 'atk', power: 0.7, dur: 3 }],
      ultimate: [{ op: 'heal', tgt: 'allAllies', power: 1.6 }, { op: 'cleanse', tgt: 'allAllies' }]
    },
    drakor: {
      passive: { reflect: 0.08 },
      active: [{ op: 'dmg', tgt: 'primary', power: 1.5 }, { op: 'dot', tgt: 'primary', kind: 'bleed', power: 0.3, dur: 3 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 1.9 }]
    },
    selene: {
      passive: { isolated: 0.20 },
      active: [{ op: 'dmg', tgt: 'primary', power: 1.5 }, { op: 'dmg', tgt: 'second', power: 1.0 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 0.75, count: 3, gap: 1.0 }]
    },
    vortex: {
      passive: { surge: 0.03, surgeMax: 5 },
      active: [{ op: 'dmg', tgt: 'all', power: 1.05 }],
      ultimate: [{ op: 'buff', tgt: 'self', stats: { atk: 2, spd: 2 }, dur: 4 }]
    },
    nyx: {
      passive: { slowOnHit: 0.05 },
      active: [{ op: 'dmg', tgt: 'primary', power: 1.3 }, { op: 'stun', tgt: 'primary', dur: 1.5 }],
      ultimate: [{ op: 'miss', tgt: 'all', chance: 0.45, dur: 4 }, { op: 'dmg', tgt: 'all', power: 0.6 }]
    },
    rexar: {
      passive: { regenAllies: 0.005 },
      active: [{ op: 'buff', tgt: 'self', stats: { def: 1.25 }, dur: 4 }, { op: 'taunt', dur: 4 }],
      ultimate: [{ op: 'buff', tgt: 'self', stats: { atk: 1.6, def: 1.4 }, dur: 5 }]
    },
    vega: {
      passive: { teamSpd: 0.04 },
      active: [{ op: 'buff', tgt: 'bestAlly', stats: { atk: 1.25, def: 1.25 }, dur: 4 }],
      ultimate: [{ op: 'extra', tgt: 'allAllies' }]
    },
    orion: {
      passive: { ignoreDef: 0.10 },
      active: [{ op: 'dmg', tgt: 'all', power: 1.15 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 2.5 }]
    },
    kael: {
      passive: { perEnemy: 0.02 },
      active: [{ op: 'dmg', tgt: 'primary', power: 0.42, count: 5, gap: 0.12 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 1.3 }]
    },
    soraya: {
      passive: { vsBurning: 0.15 },
      active: [{ op: 'dmg', tgt: 'all', power: 0.6 }, { op: 'dot', tgt: 'all', kind: 'burn', power: 0.25, dur: 3 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 0.5 }, { op: 'dot', tgt: 'all', kind: 'burn', power: 0.4, dur: 4 }]
    },
    targon: {
      passive: { stunImmuneAbove: 0.30 },
      active: [{ op: 'taunt', dur: 3 }, { op: 'buff', tgt: 'self', stats: { def: 1.3 }, dur: 3 }],
      ultimate: [{ op: 'dmg', tgt: 'primary', power: 2.6 }, { op: 'stun', tgt: 'primary', dur: 2.0 }]
    },
    elys: {
      passive: { firstCrit: true },
      active: [{ op: 'dmg', tgt: 'primary', power: 1.4 }, { op: 'slow', tgt: 'primary', mult: 0.85, dur: 3 }],
      ultimate: [{ op: 'dmg', tgt: 'primary', power: 0.75, count: 5, gap: 0.12 }]
    },
    xanor: {
      passive: { teamDR: 0.05 },
      active: [{ op: 'heal', tgt: 'allAllies', power: 0.75 }],
      ultimate: [{ op: 'heal', tgt: 'allAllies', power: 1.6 }, { op: 'cleanse', tgt: 'allAllies' }]
    },
    aeon: {
      passive: { revive: 0.30 },
      active: [{ op: 'extra', tgt: 'bestAlly' }],
      ultimate: [{ op: 'heal', tgt: 'allAllies', power: 1.0 }, { op: 'cleanse', tgt: 'allAllies' },
        { op: 'buff', tgt: 'allAllies', stats: { spd: 1.3 }, dur: 4 }]
    },
    // ---- Étape 9 : héros exclusifs de la Boutique ----
    auraxis: {
      passive: { hpHalfDR: 0.14 },
      active: [{ op: 'shield', tgt: 'self', base: 'def', power: 1.6, dur: 4 }, { op: 'taunt', dur: 4 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 1.15 }, { op: 'heal', tgt: 'self', pctMax: 0.22 }]
    },
    ravnor: {
      passive: { critChance: 0.12, vsBurning: 0.15 },
      active: [{ op: 'dmg', tgt: 'primary', power: 0.95, count: 2, gap: 0.16 }, { op: 'dot', tgt: 'primary', kind: 'burn', power: 0.28, dur: 3 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 1.9 }, { op: 'dot', tgt: 'all', kind: 'burn', power: 0.35, dur: 3 }]
    },
    kythar: {
      passive: { slowOnHit: 0.08 },
      active: [{ op: 'dmg', tgt: 'primary', power: 1.25 }, { op: 'slow', tgt: 'primary', mult: 0.70, dur: 3 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 0.9 }, { op: 'stun', tgt: 'all', dur: 1.5 }]
    },
    glacivor: {
      passive: { hpHalfDR: 0.15 },
      active: [{ op: 'shield', tgt: 'self', base: 'def', power: 1.8, dur: 4 }, { op: 'taunt', dur: 4 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 1.0 }, { op: 'slow', tgt: 'all', mult: 0.78, dur: 3 }, { op: 'shield', tgt: 'self', base: 'def', power: 1.2, dur: 4 }]
    },
    nymora: {
      passive: { regenAllies: 0.015 },
      active: [{ op: 'heal', tgt: 'lowestAlly', power: 1.75 }, { op: 'buff', tgt: 'lowestAlly', stats: { spd: 1.25 }, dur: 4 }],
      ultimate: [{ op: 'heal', tgt: 'allAllies', power: 1.5 }, { op: 'cleanse', tgt: 'allAllies' }, { op: 'shield', tgt: 'allAllies', base: 'def', power: 0.8, dur: 4 }]
    },
    necravion: {
      passive: { teamDR: 0.08 },
      active: [{ op: 'dmg', tgt: 'all', power: 1.15 }, { op: 'slow', tgt: 'all', mult: 0.82, dur: 3 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 2.25 }, { op: 'stun', tgt: 'all', dur: 2.0 }]
    },
    symbioroth: {
      passive: { atkMult: 1.08, surge: 0.03, surgeMax: 5 },
      active: [{ op: 'heal', tgt: 'self', pctMax: 0.20 }, { op: 'buff', tgt: 'self', stats: { atk: 1.25 }, dur: 4 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 2.0 }, { op: 'heal', tgt: 'self', pctMax: 0.30 }]
    },
    aqualith: {
      passive: { hpHalfDR: 0.15 },
      active: [{ op: 'dmg', tgt: 'all', power: 0.85 }, { op: 'slow', tgt: 'all', mult: 0.78, dur: 3 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 1.45 }, { op: 'stun', tgt: 'all', dur: 1.6 }, { op: 'shield', tgt: 'self', base: 'def', power: 1.5, dur: 4 }]
    },
    umbrielle: {
      passive: { firstCrit: true, critChance: 0.10 },
      active: [{ op: 'dmg', tgt: 'primary', power: 0.85, count: 2, gap: 0.14 }, { op: 'slow', tgt: 'primary', mult: 0.80, dur: 3 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 1.35, forceCrit: true }]
    },
    terraxis: {
      passive: { hpHalfDR: 0.18 },
      active: [{ op: 'dmg', tgt: 'all', power: 0.8 }, { op: 'taunt', dur: 4 }, { op: 'buff', tgt: 'self', stats: { def: 1.25 }, dur: 4 }],
      ultimate: [{ op: 'shield', tgt: 'allAllies', base: 'def', power: 1.8, dur: 4 }, { op: 'dmg', tgt: 'all', power: 1.15 }]
    },
    stellaris: {
      passive: { slowOnHit: 0.08 },
      active: [{ op: 'dmg', tgt: 'all', power: 1.15 }, { op: 'slow', tgt: 'all', mult: 0.82, dur: 3 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 1.75 }, { op: 'stun', tgt: 'all', dur: 1.6 }]
    },
    virulom: {
      passive: { slowOnHit: 0.04 },
      active: [{ op: 'dmg', tgt: 'all', power: 0.7 }, { op: 'dot', tgt: 'all', kind: 'poison', power: 0.35, dur: 3 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 1.25 }, { op: 'dot', tgt: 'all', kind: 'poison', power: 0.55, dur: 4 }]
    },
    zentihar: {
      passive: { teamDR: 0.06 },
      active: [{ op: 'dmg', tgt: 'primary', power: 1.35 }, { op: 'buff', tgt: 'bestAlly', stats: { atk: 1.30 }, dur: 4 }],
      ultimate: [{ op: 'heal', tgt: 'allAllies', power: 1.55 }, { op: 'cleanse', tgt: 'allAllies' }, { op: 'buff', tgt: 'allAllies', stats: { atk: 1.35, def: 1.25 }, dur: 5 }]
    },
    outsiderz: {
      passive: { critChance: 0.08 },
      active: [{ op: 'dmg', tgt: 'primary', power: 1.5 }, { op: 'dot', tgt: 'primary', kind: 'poison', power: 0.35, dur: 3 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 1.1 }, { op: 'dot', tgt: 'all', kind: 'poison', power: 0.4, dur: 3 }]
    },
    velmora: {
      passive: { regenAllies: 0.012 },
      active: [{ op: 'heal', tgt: 'lowestAlly', power: 1.9 }, { op: 'cleanse', tgt: 'lowestAlly' }],
      ultimate: [{ op: 'heal', tgt: 'allAllies', power: 1.7 }, { op: 'shield', tgt: 'allAllies', base: 'atk', power: 0.9, dur: 4 }]
    },
    zephyrax: {
      passive: { firstCrit: true, critChance: 0.10 },
      active: [{ op: 'dmg', tgt: 'primary', power: 0.85, count: 2, gap: 0.15, forceCrit: true }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 1.15, forceCrit: true }, { op: 'buff', tgt: 'self', stats: { spd: 1.4 }, dur: 4 }]
    },
    drakathor: {
      passive: { reflect: 0.10 },
      active: [{ op: 'dmg', tgt: 'primary', power: 1.65 }, { op: 'dot', tgt: 'primary', kind: 'burn', power: 0.35, dur: 3 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 2.1 }, { op: 'dot', tgt: 'all', kind: 'burn', power: 0.3, dur: 3 }]
    },
    selenia: {
      passive: { isolated: 0.22 },
      active: [{ op: 'dmg', tgt: 'primary', power: 1.6 }, { op: 'dmg', tgt: 'second', power: 0.9 }],
      ultimate: [{ op: 'dmg', tgt: 'primary', power: 2.4, forceCrit: true }, { op: 'dmg', tgt: 'second', power: 1.2 }]
    },
    krakenis: {
      passive: { hpHalfDR: 0.14 },
      active: [{ op: 'shield', tgt: 'self', base: 'def', power: 1.4, dur: 4 }, { op: 'taunt', dur: 4 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 0.8 }, { op: 'slow', tgt: 'all', mult: 0.8, dur: 3 }, { op: 'heal', tgt: 'self', pctMax: 0.15 }]
    },
    nythera: {
      passive: { vsBurning: 0.20 },
      active: [{ op: 'dmg', tgt: 'all', power: 0.7 }, { op: 'dot', tgt: 'all', kind: 'burn', power: 0.3, dur: 3 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 1.2 }, { op: 'dot', tgt: 'all', kind: 'burn', power: 0.5, dur: 4 }]
    },
    arcanis: {
      passive: { slowOnHit: 0.06 },
      active: [{ op: 'dmg', tgt: 'primary', power: 1.2 }, { op: 'stun', tgt: 'primary', dur: 1.6 }],
      ultimate: [{ op: 'stun', tgt: 'all', dur: 1.5 }, { op: 'dmg', tgt: 'all', power: 0.7 }]
    },
    vulkar: {
      passive: { hpHalfDR: 0.10 },
      active: [{ op: 'shield', tgt: 'self', base: 'def', power: 1.3, dur: 4 }, { op: 'heal', tgt: 'self', pctMax: 0.12 }, { op: 'taunt', dur: 3 }],
      ultimate: [{ op: 'dmg', tgt: 'all', power: 0.9 }, { op: 'heal', tgt: 'self', pctMax: 0.30 }]
    }
  };

  // Comportement générique d'un héros SANS kit (futurs héros) : rôle + cible de la compétence.
  function deriveHeroSkill(target, isUltimate) {
    var base;
    switch (target) {
      case 'enemy': base = { kind: 'singleDamage', power: 1.55 }; break;
      case 'allEnemies': case 'zone': base = { kind: 'aoeDamage', power: 0.85 }; break;
      case 'ally': base = { kind: 'singleHeal', power: 1.3 }; break;
      case 'allAllies': base = { kind: 'aoeHeal', power: 0.8 }; break;
      case 'self': default: base = { kind: 'selfBuff', power: 1.0 }; break;
    }
    if (isUltimate) base.power *= 1.7;
    return base;
  }

  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }

  // ---------- Fabrique d'unités ----------
  var uidCounter = 1;
  function nextUid() { return 'u' + (uidCounter++); }

  function baseUnit(fields) {
    return Object.assign({
      uid: nextUid(), side: 'player', name: '?', role: 'dps', isBoss: false,
      maxHp: 100, hp: 100, atk: 10, def: 10, spd: 100,
      gauge: Math.random() * 30, energy: 0,
      skillCooldown: 0, skillCooldownMax: 8,
      alive: true, shield: 0, shieldUntil: 0,
      dmgTakenMult: 1, teamShieldMult: 1, critChance: CFG.BASE_CRIT_CHANCE, critMult: CFG.BASE_CRIT_MULT,
      atkMult: 1, permSpd: 1, surge: 0, stunTime: 0, tauntUntil: 0, missUntil: 0, missChance: 0,
      mods: [], dots: [], passive: {}, phase: 0, breakGauge: 100, breakUntil: 0, focusTargetUid: null,
      row: 'front'   // formation : 'front' (mêlée, ciblé en priorité) ou 'back' (soutien, protégé)
    }, fields);
  }

  /**
   * Unité joueur à partir d'un héros de js/data/Heroes.js (stats réelles au niveau donné).
   * `gearBonus` (optionnel) : bonus d'équipement/flotte combiné {hp,atk,def,spd,critChance} en
   * valeurs additives + {hpPct,atkPct,defPct,spdPct} en pourcentage (flotte) — voir CombatManager.
   */
  function makeHeroUnit(hero, level, heroId, gearBonus) {
    var H = NEBUSTION.Heroes;
    var stats = H.statsAtLevel(hero, level || 1);
    var g = gearBonus || {};
    var kit = HERO_KIT[hero.id];
    var passive = (kit && kit.passive) || ROLE_PASSIVE[hero.role] || {};
    var hp = Math.round((stats.hp + (g.hp || 0)) * (1 + (g.hpPct || 0)));
    var atk = Math.round((stats.atk + (g.atk || 0)) * (1 + (g.atkPct || 0)));
    var def = Math.round((stats.def + (g.def || 0)) * (1 + (g.defPct || 0)));
    var spd = Math.round((stats.spd + (g.spd || 0)) * (1 + (g.spdPct || 0)));
    return baseUnit({
      side: 'player', name: hero.name, role: hero.role, heroId: heroId || hero.id,
      rarity: hero.rarity, portraitKey: H.portraitKey(hero.id), hasKit: !!kit, level: level || 1,
      maxHp: hp, hp: hp, atk: atk, def: def, spd: spd,
      skillCooldownMax: (hero.skills.active && hero.skills.active.cooldown) || 8,
      critChance: CFG.BASE_CRIT_CHANCE + (passive.critChance || 0) + (g.critChance || 0),
      atkMult: passive.atkMult || 1,
      passive: passive,
      activeTarget: hero.skills.active ? hero.skills.active.target : 'enemy',
      ultimateTarget: hero.skills.ultimate ? hero.skills.ultimate.target : 'allEnemies',
      activeName: hero.skills.active ? hero.skills.active.name : 'Compétence',
      ultimateName: hero.skills.ultimate ? hero.skills.ultimate.name : 'Ultime',
      passiveName: hero.skills.passive ? hero.skills.passive.name : '',
      row: (g.row === 'back') ? 'back' : 'front'
    });
  }

  /** Unité ennemie/boss à partir de js/data/Enemies.js. */
  function makeEnemyUnit(def, difficultyId, tag, stageScale) {
    var EN = NEBUSTION.Enemies;
    var stats = EN.statsForEnemy(def, difficultyId, stageScale);
    var u = baseUnit({
      side: 'enemy', name: def.name, role: def.role, enemyId: def.id, tag: tag,
      isBoss: !!def.isBoss, textureKey: 'tex_enemy_' + def.id,
      maxHp: stats.hp, hp: stats.hp, atk: stats.atk, def: stats.def, spd: stats.spd,
      skillCooldownMax: def.skill ? def.skill.cooldown : 999,
      skillDef: def.skill || null,
      phaseThresholds: def.phaseThresholds || [],
      phaseBonus: def.phaseBonus || null,
      novaPower: def.novaPower || 0
    });
    u.skillCooldown = u.skillCooldownMax * 0.5; // pas de compétence prête dès la première seconde
    return u;
  }

  // ---------- Moteur ----------
  function CombatEngine(playerUnits, enemyUnits, opts) {
    opts = opts || {};
    this.player = playerUnits;
    this.enemy = enemyUnits;
    this.all = playerUnits.concat(enemyUnits);
    this.mode = opts.mode === 'manual' ? 'manual' : 'auto';
    this.time = opts.startTime || 0;
    this.over = false;
    this.result = null;
    this.events = [];
    this._sched = [];
    this._manualSkillRequests = {};
    this._manualUltimateRequests = {};
    this._reviveUsed = {};
    // Mécaniques tactiques : cible verrouillée + combo d'équipe.
    this.focusTargetUid = null;
    this.combo = 0;
    this.comboUntil = 0;
    // Frappe du Commandant : jauge alimentée par les dégâts de l'équipe, activable manuellement,
    // indépendante des compétences/ultimes de héros (c'est le joueur lui-même qui frappe).
    this.strikeCharge = 0;
    this._commanderStrikeRequested = false;
    // Objets/consommables utilisables en combat (charges limitées pour ce combat).
    this.items = {};
    var itemDefs = (NEBUSTION.CombatItems && NEBUSTION.CombatItems.DEFS) || {};
    var loadout = opts.items || {};
    Object.keys(itemDefs).forEach(function (id) {
      var charges = (loadout[id] !== undefined) ? loadout[id] : itemDefs[id].defaultCharges;
      this.items[id] = { charges: charges };
    }, this);
    // Une invasion multi-vagues enchaîne plusieurs CombatEngine sur la MÊME équipe : les passifs
    // d'équipe (Vega, Xanor...) ne doivent s'appliquer qu'une fois, pas à chaque nouvelle vague.
    if (!opts.skipPassiveInit) this._initPassives();
  }

  // Passifs d'équipe (Vega : vitesse, Xanor : dégâts réduits) appliqués une fois au début.
  CombatEngine.prototype._initPassives = function () {
    var self = this;
    this.all.forEach(function (u) {
      var P = u.passive || {};
      if (!P.teamSpd && !P.teamDR) return;
      self.all.forEach(function (a) {
        if (a.side !== u.side) return;
        if (P.teamSpd) a.permSpd *= (1 + P.teamSpd);
        if (P.teamDR) a.teamShieldMult *= (1 - P.teamDR);
      });
    });
  };

  CombatEngine.prototype.setMode = function (mode) { this.mode = (mode === 'manual') ? 'manual' : 'auto'; };
  CombatEngine.prototype.requestSkill = function (uid) { this._manualSkillRequests[uid] = true; };
  CombatEngine.prototype.requestUltimate = function (uid) { this._manualUltimateRequests[uid] = true; };

  // ---------- Frappe du Commandant (attaque spéciale activable par le joueur) ----------
  CombatEngine.prototype.strikeProgress = function () { return this.strikeCharge / CFG.STRIKE_MAX; };
  CombatEngine.prototype.strikeReady = function () { return !this.over && this.strikeCharge >= CFG.STRIKE_MAX; };
  /** Demande la frappe ; exécutée au prochain update() si la jauge est pleine (comme les ultimes). */
  CombatEngine.prototype.requestCommanderStrike = function () { this._commanderStrikeRequested = true; };
  CombatEngine.prototype._teamAtkAvg = function () {
    var list = this.aliveOf('player');
    if (!list.length) return 1;
    var sum = 0;
    for (var i = 0; i < list.length; i++) sum += list[i].atk * (list[i].atkMult || 1);
    return sum / list.length;
  };
  CombatEngine.prototype._doCommanderStrike = function () {
    var self = this;
    var pseudo = { uid: 'commander', side: 'player', atk: this._teamAtkAvg(), atkMult: 1, critChance: 0, passive: {}, alive: true, mods: [], row: null };
    this.emit('commanderStrike', { power: CFG.STRIKE_POWER });
    this.aliveOf('enemy').forEach(function (e) {
      self.applyDamage(pseudo, e, CFG.STRIKE_POWER, { noCrit: true, skill: true, ultimate: true, commanderStrike: true });
      if (e.alive) self._stun(pseudo, e, CFG.STRIKE_STUN);
    });
    this.strikeCharge = 0;
  };
  /** Utilise un objet/consommable de combat (charges limitées) : voir js/data/CombatItems.js. */
  CombatEngine.prototype.useItem = function (itemId) {
    var it = this.items[itemId];
    var def = NEBUSTION.CombatItems && NEBUSTION.CombatItems.get(itemId);
    if (this.over || !it || !def || it.charges <= 0) return false;
    it.charges--;
    var self = this;
    var pseudo = { uid: 'item_' + itemId, side: 'player', atk: this._teamAtkAvg(), def: this._teamAtkAvg(), atkMult: 1, critChance: 0, passive: {}, alive: true, mods: [], row: null };
    switch (def.effect) {
      case 'heal':
        this.aliveOf('player').forEach(function (a) { self.applyHeal(pseudo, a, 0, { pctMax: def.power }); });
        break;
      case 'shield':
        this.aliveOf('player').forEach(function (a) { self.applyShield(pseudo, a, def.power, { base: 'atk', dur: def.duration }); });
        break;
      case 'buffAtk':
        this.aliveOf('player').forEach(function (a) { self._addMod(a, 'item_' + itemId, 'atk', 1 + def.power, def.duration); });
        break;
      case 'stunAoe':
        this.aliveOf('enemy').forEach(function (e) {
          self._stun(pseudo, e, def.duration);
          self.applyDamage(pseudo, e, def.power, { noCrit: true, noMiss: true, skill: true });
        });
        break;
      default: break;
    }
    this.emit('item', { item: itemId, chargesLeft: it.charges });
    return true;
  };
  CombatEngine.prototype.setFocusTarget = function (uid) {
    var t = this.all.find(function (u) { return u.uid === uid && u.side === 'enemy' && u.alive; });
    if (!t) return false;
    this.focusTargetUid = t.uid;
    this.player.forEach(function (u) { u.focusTargetUid = t.uid; });
    this.emit('focus', { targetUid: t.uid });
    return true;
  };
  CombatEngine.prototype.clearFocusTarget = function () { this.focusTargetUid = null; this.player.forEach(function (u) { u.focusTargetUid = null; }); };
  CombatEngine.prototype.comboMultiplier = function () { return 1 + Math.min(CFG.COMBO_MAX, this.combo) * 0.02; };
  CombatEngine.prototype.breakActive = function (u) { return !!u && u.breakUntil > this.time; };
  CombatEngine.prototype.consumeEvents = function () { var e = this.events; this.events = []; return e; };
  CombatEngine.prototype.isOver = function () { return this.over; };
  CombatEngine.prototype.getResult = function () { return this.result; };
  /** Multiplicateur de rage des ennemis (1 avant ENRAGE_START, puis croissant). */
  CombatEngine.prototype.enrageMult = function () {
    if (this.time <= CFG.ENRAGE_START) return 1;
    return 1 + CFG.ENRAGE_STEP * (this.time - CFG.ENRAGE_START) / 10;
  };
  CombatEngine.prototype.isEnraged = function () { return this.time > CFG.ENRAGE_START; };
  CombatEngine.prototype.skillReady = function (u) { return !!u && u.alive && u.skillCooldown <= 0 && u.stunTime <= 0 && !this.over; };
  CombatEngine.prototype.ultReady = function (u) { return !!u && u.alive && u.energy >= ENERGY_MAX && u.stunTime <= 0 && !this.over; };

  CombatEngine.prototype.emit = function (type, data) {
    data = data || {};
    data.type = type;
    this.events.push(data);
  };

  CombatEngine.prototype.aliveOf = function (side) {
    return this.all.filter(function (u) { return u.side === side && u.alive; });
  };

  function opposite(side) { return side === 'player' ? 'enemy' : 'player'; }
  function hpFrac(u) { return u.hp / Math.max(1, u.maxHp); }

  CombatEngine.prototype.lowestHpTarget = function (side) {
    var list = this.aliveOf(side);
    if (!list.length) return null;
    var best = list[0];
    for (var i = 1; i < list.length; i++) { if (hpFrac(list[i]) < hpFrac(best)) best = list[i]; }
    return best;
  };

  CombatEngine.prototype.randomTarget = function (side) {
    var list = this.aliveOf(side);
    if (!list.length) return null;
    return list[Math.floor(Math.random() * list.length)];
  };

  /** Cible d'une attaque : les héros visent le plus faible ; les ennemis respectent la provocation. */
  CombatEngine.prototype._pickTarget = function (unit, forceLowest) {
    var side = opposite(unit.side);
    if (unit.side === 'player') {
      var focused = this.all.find(function (u) { return u.uid === unit.focusTargetUid && u.side === 'enemy' && u.alive; });
      if (focused) return focused;
      return this.lowestHpTarget(side);
    }
    var time = this.time;
    var taunters = this.aliveOf(side).filter(function (u) { return u.tauntUntil > time; });
    if (taunters.length) return taunters[Math.floor(Math.random() * taunters.length)];
    // Formation : sans provocation active, les ennemis visent surtout la ligne AVANT ; la ligne
    // ARRIÈRE (soutien/dégâts fragiles) n'est exposée que si aucun front n'est disponible.
    var pool = this.aliveOf(side);
    var front = pool.filter(function (u) { return u.row !== 'back'; });
    var back = pool.filter(function (u) { return u.row === 'back'; });
    if (front.length && back.length) pool = (Math.random() < CFG.FRONT_AGGRO) ? front : back;
    if (forceLowest || Math.random() < CFG.ENEMY_FOCUS_LOWEST) return this._lowestOf(pool);
    return pool[Math.floor(Math.random() * pool.length)] || null;
  };

  CombatEngine.prototype._lowestOf = function (list) {
    if (!list.length) return null;
    var best = list[0];
    for (var i = 1; i < list.length; i++) { if (hpFrac(list[i]) < hpFrac(best)) best = list[i]; }
    return best;
  };

  // ---------- Modificateurs temporaires (buffs / débuffs) ----------
  CombatEngine.prototype._m = function (u, stat) {
    var m = 1, t = this.time;
    for (var i = 0; i < u.mods.length; i++) { if (u.mods[i].stat === stat && u.mods[i].until > t) m *= u.mods[i].mult; }
    return m;
  };
  CombatEngine.prototype._addMod = function (u, src, stat, mult, dur) {
    for (var i = 0; i < u.mods.length; i++) {
      if (u.mods[i].src === src && u.mods[i].stat === stat) { u.mods[i].mult = mult; u.mods[i].until = this.time + dur; return; }
    }
    u.mods.push({ src: src, stat: stat, mult: mult, until: this.time + dur });
  };
  CombatEngine.prototype._effSpeed = function (u) {
    var P = u.passive || {};
    var surge = P.surge ? (1 + P.surge * u.surge) : 1;
    return (u.spd || 60) * (u.permSpd || 1) * surge * this._m(u, 'spd');
  };
  CombatEngine.prototype._isBurning = function (u) {
    var t = this.time;
    return u.dots.some(function (d) { return d.kind === 'burn' && d.until > t; });
  };

  // ---------- Dégâts / soins ----------
  CombatEngine.prototype.applyDamage = function (attacker, target, power, opts) {
    opts = opts || {};
    if (!target || !target.alive) return null;

    if (!opts.noMiss && attacker.missUntil > this.time && Math.random() < attacker.missChance) {
      this.emit('miss', { uid: attacker.uid, targetUid: target.uid });
      return { amount: 0, crit: false, absorbed: 0, miss: true };
    }

    var AP = attacker.passive || {}, TP = target.passive || {};
    var atk = attacker.atk * (attacker.atkMult || 1) * this._m(attacker, 'atk');
    if (AP.perEnemy) atk *= 1 + AP.perEnemy * this.aliveOf(opposite(attacker.side)).length;
    if (AP.isolated && this.aliveOf(target.side).length === 1) atk *= 1 + AP.isolated;
    if (AP.vsBurning && this._isBurning(target)) atk *= 1 + AP.vsBurning;
    // Formation (héros joueur uniquement) : la ligne AVANT frappe plus fort, la ligne ARRIÈRE moins.
    if (attacker.side === 'player' && attacker.row) atk *= (attacker.row === 'back') ? CFG.BACK_ATK_MULT : CFG.FRONT_ATK_MULT;

    var def = target.def * this._m(target, 'def') * (1 - (AP.ignoreDef || 0));
    var raw = atk * power;
    var mitigated = Math.max(raw * 0.35, raw - def * 0.5);
    var taken = (target.dmgTakenMult || 1) * (target.teamShieldMult || 1) * this._m(target, 'taken');
    if (target.side === 'player' && target.row) taken *= (target.row === 'back') ? CFG.BACK_TAKEN_MULT : CFG.FRONT_TAKEN_MULT;
    if (target.breakUntil > this.time) taken *= CFG.BREAK_DAMAGE_MULT;
    if (attacker.side === 'player' && !opts.dot && !opts.reflect) taken *= this.comboMultiplier();
    if (TP.hpHalfDR && hpFrac(target) > 0.5) taken *= (1 - TP.hpHalfDR);
    var amount = mitigated * taken * CFG.DAMAGE_SCALE * (attacker.side === 'enemy' ? CFG.ENEMY_DAMAGE * this.enrageMult() : 1);

    var crit = false;
    if (!opts.noCrit) {
      var first = AP.firstCrit && !attacker._firstDone;
      if (opts.forceCrit || first || Math.random() < (attacker.critChance || CFG.BASE_CRIT_CHANCE)) {
        amount *= (attacker.critMult || CFG.BASE_CRIT_MULT);
        crit = true;
      }
      if (AP.firstCrit) attacker._firstDone = true;
      if (crit && AP.critCdRefund) attacker.skillCooldown = Math.max(0, attacker.skillCooldown - AP.critCdRefund);
    }
    amount = Math.max(1, Math.round(amount));

    var absorbed = 0;
    if (target.shield > 0) {
      absorbed = Math.min(target.shield, amount);
      target.shield -= absorbed;
      amount -= absorbed;
    }
    target.hp = clamp(target.hp - amount, 0, target.maxHp);

    var ev = { uid: attacker.uid, targetUid: target.uid, amount: amount, absorbed: absorbed, crit: crit };
    if (opts.skill) ev.skill = true;
    if (opts.dot) ev.dot = true;
    if (opts.reflect) ev.reflect = true;
    if (opts.late) ev.late = true;
    this.emit('damage', ev);
    if (attacker.side === 'player' && amount > 0 && !opts.reflect) {
      var previousCombo = this.combo;
      this.combo = Math.min(CFG.COMBO_MAX, this.combo + 1);
      this.comboUntil = this.time + CFG.COMBO_WINDOW;
      if (this.combo !== previousCombo) this.emit('combo', { combo: this.combo, multiplier: this.comboMultiplier(), uid: attacker.uid });
    }
    // Frappe du Commandant : toute l'équipe alimente la jauge en tapant des ennemis (hors reflet/DoT/frappe elle-même).
    if (attacker.side === 'player' && target.side === 'enemy' && amount > 0 && !opts.reflect && !opts.dot && !opts.commanderStrike) {
      this.strikeCharge = clamp(this.strikeCharge + (amount / Math.max(1, target.maxHp)) * CFG.STRIKE_GAIN, 0, CFG.STRIKE_MAX);
    }
    if (attacker.side === 'player' && target.side === 'enemy' && opts.skill && amount > 0 && target.alive) {
      this._addBreak(target, opts.ultimate ? CFG.BREAK_PER_ULT : CFG.BREAK_PER_SKILL, attacker);
    }
    this.gainEnergyFromDamage(target, amount);

    // Reflet de dégâts (Drakor) : ne se redéclenche jamais lui-même.
    if (TP.reflect && !opts.reflect && !opts.dot && attacker.alive && attacker !== target && amount > 0) {
      var back = Math.max(1, Math.round(amount * TP.reflect));
      attacker.hp = clamp(attacker.hp - back, 0, attacker.maxHp);
      this.emit('damage', { uid: target.uid, targetUid: attacker.uid, amount: back, absorbed: 0, crit: false, reflect: true });
      if (attacker.hp <= 0) this._kill(attacker);
    }

    if (target.hp <= 0 && target.alive) this._kill(target);
    if (target.isBoss && target.alive) this._checkBossPhase(target);
    return { amount: amount, crit: crit, absorbed: absorbed };
  };

  // Mort d'une unité, avec la réanimation unique d'Aeon (« Éternité »).
  CombatEngine.prototype._kill = function (target) {
    var self = this;
    if (target.side === 'player') {
      var savior = null;
      this.player.forEach(function (a) {
        if (a.alive && a !== target && a.passive && a.passive.revive && !self._reviveUsed[a.uid]) savior = a;
      });
      if (savior) {
        this._reviveUsed[savior.uid] = true;
        target.hp = Math.max(1, Math.round(target.maxHp * savior.passive.revive));
        this.emit('revive', { uid: savior.uid, targetUid: target.uid });
        return;
      }
    }
    target.alive = false;
    target.hp = 0;
    if (this.focusTargetUid === target.uid) { this.focusTargetUid = null; this.player.forEach(function (u) { u.focusTargetUid = null; }); this.emit('focus', { targetUid: null }); }
    target.dots = [];
    this.emit('death', { uid: target.uid });
  };

  CombatEngine.prototype._addBreak = function (target, amount, attacker) {
    if (!target || !target.alive || target.side !== 'enemy' || target.isBoss && target.breakImmune) return;
    target.breakGauge = Math.max(0, (target.breakGauge == null ? CFG.BREAK_MAX : target.breakGauge) - amount);
    this.emit('break', { uid: attacker.uid, targetUid: target.uid, gauge: target.breakGauge });
    if (target.breakGauge <= 0 && target.breakUntil <= this.time) {
      target.breakUntil = this.time + CFG.BREAK_DURATION;
      target.breakGauge = CFG.BREAK_MAX;
      target.stunTime = Math.max(target.stunTime || 0, CFG.BREAK_DURATION);
      this.emit('break', { uid: attacker.uid, targetUid: target.uid, gauge: 0, broken: true, duration: CFG.BREAK_DURATION });
    }
  };

  CombatEngine.prototype._reaction = function (attacker, target, kind) {
    if (!target || !target.alive) return;
    var power = kind === 'combustion' ? 0.75 : (kind === 'corrosion' ? 0.55 : 0.65);
    var res = this.applyDamage(attacker, target, power, { noCrit: true, noMiss: true, reaction: true });
    if (kind === 'combustion') this._addMod(target, 'reaction', 'taken', 1.12, 4);
    if (kind === 'corrosion') this._addMod(target, 'reaction', 'def', 0.78, 4);
    if (kind === 'thermal') this._stun(attacker, target, 0.9);
    this.emit('reaction', { uid: attacker.uid, targetUid: target.uid, kind: kind, amount: res ? res.amount : 0 });
  };

  CombatEngine.prototype.applyHeal = function (caster, target, power, opts) {
    opts = opts || {};
    if (!target || !target.alive) return null;
    var amount = (opts.pctMax !== undefined)
      ? target.maxHp * opts.pctMax
      : caster.atk * (caster.atkMult || 1) * this._m(caster, 'atk') * power * CFG.DAMAGE_SCALE * CFG.HEAL_SCALE;
    amount = Math.max(1, Math.round(amount));
    var before = target.hp;
    target.hp = clamp(target.hp + amount, 0, target.maxHp);
    var healed = target.hp - before;
    var ev = { uid: caster.uid, targetUid: target.uid, amount: healed };
    if (opts.passive) ev.passive = true;
    this.emit('heal', ev);
    return healed;
  };

  CombatEngine.prototype.applyShield = function (caster, target, power, opts) {
    opts = opts || {};
    var stat = opts.base === 'def' ? caster.def : caster.atk;
    var amount = Math.max(1, Math.round(stat * power * CFG.DAMAGE_SCALE * CFG.HEAL_SCALE));
    target.shield = (target.shield || 0) + amount;
    if (opts.dur) target.shieldUntil = Math.max(target.shieldUntil || 0, this.time + opts.dur);
    this.emit('shield', { uid: caster.uid, targetUid: target.uid, amount: amount });
  };

  CombatEngine.prototype.gainEnergyFromDamage = function (unit, amount) {
    if (!unit.alive && unit.hp <= 0) return;
    var pct = amount / Math.max(1, unit.maxHp);
    unit.energy = clamp(unit.energy + pct * CFG.ENERGY_FROM_DAMAGE, 0, ENERGY_MAX);
  };

  CombatEngine.prototype._stun = function (caster, target, dur) {
    if (!target || !target.alive) return;
    var TP = target.passive || {};
    if (TP.stunImmuneAbove && hpFrac(target) > TP.stunImmuneAbove) return; // Rempart (Targon)
    target.stunTime = Math.max(target.stunTime || 0, dur);
    this.emit('stun', { uid: caster.uid, targetUid: target.uid, duration: dur });
  };

  CombatEngine.prototype._cleanse = function (caster, target) {
    var t = this.time;
    target.stunTime = 0;
    target.dots = [];
    target.missUntil = 0;
    target.mods = target.mods.filter(function (m) { return m.mult >= 1 || m.until <= t; });
    this.emit('cleanse', { uid: caster.uid, targetUid: target.uid });
  };

  CombatEngine.prototype._checkBossPhase = function (boss) {
    var thresholds = boss.phaseThresholds || [];
    if (boss.phase >= thresholds.length) return;
    var pct = boss.hp / boss.maxHp;
    if (pct <= thresholds[boss.phase]) {
      boss.phase++;
      var bonus = boss.phaseBonus || {};
      boss.atk = Math.round(boss.atk * (bonus.atkMult || 1));
      boss.spd = Math.round(boss.spd * (bonus.spdMult || 1));
      boss.skillCooldownMax = Math.max(2, boss.skillCooldownMax * (bonus.cooldownMult || 1));
      this.emit('phase', { uid: boss.uid, phase: boss.phase, total: thresholds.length + 1 });
      if (boss.novaPower) {
        var self = this;
        this.aliveOf('player').forEach(function (p) { self.applyDamage(boss, p, boss.novaPower, { noCrit: true, noMiss: true, skill: true }); });
        this.emit('bossNova', { uid: boss.uid, power: boss.novaPower });
      }
    }
  };

  // ---------- Actions planifiées (coups multiples, salves) ----------
  CombatEngine.prototype._schedule = function (delay, fn, owner) {
    this._sched.push({ at: this.time + delay, fn: fn, owner: owner || null });
    this._sched.sort(function (a, b) { return a.at - b.at; });
  };

  // ---------- Actions ----------
  CombatEngine.prototype._onAction = function (unit) {
    var P = unit.passive || {};
    if (P.regenAllies) { // Aura bienveillante (Lumina) / Cœur du clan (Rexar) : à chaque tour
      var self = this;
      this.aliveOf(unit.side).forEach(function (a) {
        if (a.hp < a.maxHp) self.applyHeal(unit, a, 0, { pctMax: P.regenAllies, passive: true });
      });
    }
  };

  CombatEngine.prototype._basicAttack = function (unit) {
    var target = this._pickTarget(unit);
    if (!target) return;
    this.emit('attack', { uid: unit.uid, targetUid: target.uid });
    var res = this.applyDamage(unit, target, 1.0);
    var P = unit.passive || {};
    if (P.surge && unit.surge < (P.surgeMax || 5)) unit.surge++;                  // Surcharge (Vortex)
    if (P.slowOnHit && res && !res.miss && target.alive) {                         // Voile toxique (Nyx)
      this._addMod(target, 'nyx' + unit.uid, 'spd', 1 - P.slowOnHit, 3);
    }
    unit.energy = clamp(unit.energy + CFG.ENERGY_PER_BASIC, 0, ENERGY_MAX);
    this._onAction(unit);
  };

  // Cibles d'une opération de kit.
  CombatEngine.prototype._targets = function (unit, tgt, ctx) {
    var foes = opposite(unit.side), self = this;
    switch (tgt) {
      case 'primary':
        if (!ctx.primary || !ctx.primary.alive) ctx.primary = this._pickTarget(unit, true);
        return ctx.primary ? [ctx.primary] : [];
      case 'second': {
        var list = this.aliveOf(foes), p = ctx.primary;
        var idx = list.indexOf(p);
        var other = list.filter(function (u) { return u !== p; });
        return other.length ? [other[Math.max(0, Math.min(idx, other.length - 1))]] : [];
      }
      case 'all': return this.aliveOf(foes);
      case 'self': return [unit];
      case 'lowestAlly': { var a = this._lowestHpAlly(unit); return a ? [a] : []; }
      case 'allAllies': return this.aliveOf(unit.side);
      case 'bestAlly': {
        var mates = this.aliveOf(unit.side).filter(function (u) { return u !== unit; });
        if (!mates.length) return [unit];
        return [mates.reduce(function (b, u) { return u.atk > b.atk ? u : b; }, mates[0])];
      }
      default: return [];
    }
  };

  CombatEngine.prototype._runOp = function (unit, op, ctx, isUlt) {
    var self = this, ts;
    switch (op.op) {
      case 'dmg': {
        var count = op.count || 1, gap = op.gap || 0.16;
        var hit = function (late) {
          self._targets(unit, op.tgt, ctx).forEach(function (t) {
            self.applyDamage(unit, t, op.power, { skill: true, ultimate: isUlt, forceCrit: !!op.forceCrit, late: late });
          });
        };
        hit(false);
        for (var i = 1; i < count; i++) this._schedule(i * gap, function () { hit(true); }, unit);
        break;
      }
      case 'heal':
        this._targets(unit, op.tgt, ctx).forEach(function (t) {
          if (op.pctMax !== undefined) self.applyHeal(unit, t, 0, { pctMax: op.pctMax });
          else self.applyHeal(unit, t, op.power);
        });
        break;
      case 'shield':
        this._targets(unit, op.tgt, ctx).forEach(function (t) { self.applyShield(unit, t, op.power, { base: op.base, dur: op.dur }); });
        break;
      case 'stun':
        this._targets(unit, op.tgt, ctx).forEach(function (t) {
          var wasSlowed = self._m(t, 'spd') < 1;
          self._stun(unit, t, op.dur || CFG.STUN_DURATION);
          if (wasSlowed && !self._reactionLock) self._reaction(unit, t, 'thermal');
        });
        break;
      case 'buff':
        this._targets(unit, op.tgt, ctx).forEach(function (t) {
          Object.keys(op.stats).forEach(function (stat) { self._addMod(t, 'buff' + unit.uid + (isUlt ? 'u' : 'a'), stat, op.stats[stat], op.dur); });
          self.emit('buff', { uid: unit.uid, targetUid: t.uid, stat: Object.keys(op.stats).join(','), up: true });
        });
        break;
      case 'slow':
        this._targets(unit, op.tgt, ctx).forEach(function (t) {
          self._addMod(t, 'slow' + unit.uid, 'spd', op.mult, op.dur);
          self.emit('debuff', { uid: unit.uid, targetUid: t.uid, stat: 'spd' });
        });
        break;
      case 'dot':
        this._targets(unit, op.tgt, ctx).forEach(function (t) {
          var hadBurn = t.dots.some(function (d) { return d.kind === 'burn' && d.until > self.time; });
          var hadPoison = t.dots.some(function (d) { return d.kind === 'poison' && d.until > self.time; });
          var hadBleed = t.dots.some(function (d) { return d.kind === 'bleed' && d.until > self.time; });
          t.dots = t.dots.filter(function (d) { return !(d.kind === op.kind && d.src === unit); });
          t.dots.push({ kind: op.kind, src: unit, power: op.power, until: self.time + op.dur + 0.001, next: self.time + CFG.DOT_TICK });
          self.emit('debuff', { uid: unit.uid, targetUid: t.uid, stat: op.kind });
          if (!self._reactionLock) {
            if ((op.kind === 'poison' && hadBurn) || (op.kind === 'burn' && hadPoison)) self._reaction(unit, t, 'combustion');
            else if ((op.kind === 'poison' && hadBleed) || (op.kind === 'bleed' && hadPoison)) self._reaction(unit, t, 'corrosion');
          }
        });
        break;
      case 'taunt':
        unit.tauntUntil = this.time + op.dur;
        this.emit('taunt', { uid: unit.uid, duration: op.dur });
        break;
      case 'cleanse':
        this._targets(unit, op.tgt, ctx).forEach(function (t) { self._cleanse(unit, t); });
        break;
      case 'extra':
        this._targets(unit, op.tgt, ctx).forEach(function (t) {
          if (t.stunTime > 0) return;
          t.gauge = GAUGE_MAX;
          self.emit('extra', { uid: unit.uid, targetUid: t.uid });
        });
        break;
      case 'miss':
        this._targets(unit, op.tgt, ctx).forEach(function (t) {
          t.missUntil = self.time + op.dur; t.missChance = op.chance;
          self.emit('debuff', { uid: unit.uid, targetUid: t.uid, stat: 'miss' });
        });
        break;
      default: break;
    }
  };

  // Compétences génériques (ennemis/boss, ou héros sans kit).
  CombatEngine.prototype._resolveSkillEffect = function (unit, skill) {
    var self = this, oppSide = opposite(unit.side);
    switch (skill.kind) {
      case 'singleDamage': {
        var t = this._pickTarget(unit, true);
        if (t) this.applyDamage(unit, t, skill.power, { skill: true });
        break;
      }
      case 'aoeDamage':
        this.aliveOf(oppSide).forEach(function (t) { self.applyDamage(unit, t, skill.power, { skill: true }); });
        break;
      case 'stun': {
        var st = this._pickTarget(unit, true);
        if (st) { this.applyDamage(unit, st, skill.power, { skill: true }); this._stun(unit, st, CFG.STUN_DURATION); }
        break;
      }
      case 'drain': {
        var dt = this._pickTarget(unit, true);
        if (dt) {
          var res = this.applyDamage(unit, dt, skill.power, { skill: true });
          if (res && res.amount > 0) this.applyHeal(unit, unit, 0, { pctMax: Math.min(0.12, res.amount / Math.max(1, unit.maxHp)) });
        }
        break;
      }
      case 'selfShield': this.applyShield(unit, unit, skill.power, { base: 'atk', dur: 6 }); break;
      case 'selfBuff':
        this.applyShield(unit, unit, skill.power * 0.7, { base: 'atk', dur: 4 });
        this._addMod(unit, 'gbuff' + unit.uid, 'atk', 1.15, 5);
        this.emit('buff', { uid: unit.uid, targetUid: unit.uid, stat: 'atk', up: true });
        break;
      case 'singleHeal': { var al = this._lowestHpAlly(unit); if (al) this.applyHeal(unit, al, skill.power); break; }
      case 'aoeHeal':
        this.aliveOf(unit.side).forEach(function (a) { self.applyHeal(unit, a, skill.power * 0.65); });
        break;
      default: break;
    }
  };

  CombatEngine.prototype._lowestHpAlly = function (unit) {
    var list = this.aliveOf(unit.side);
    if (!list.length) return null;
    var best = list[0];
    for (var i = 1; i < list.length; i++) { if (hpFrac(list[i]) < hpFrac(best)) best = list[i]; }
    return best;
  };

  CombatEngine.prototype._getGenericSkill = function (unit, isUltimate) {
    if (unit.side === 'enemy') {
      if (!unit.skillDef) return null;
      return { name: isUltimate ? 'Déchaînement' : unit.skillDef.name, kind: unit.skillDef.kind, power: unit.skillDef.power * (isUltimate ? 1.6 : 1) };
    }
    var derived = deriveHeroSkill(isUltimate ? unit.ultimateTarget : unit.activeTarget, isUltimate);
    return { name: isUltimate ? unit.ultimateName : unit.activeName, kind: derived.kind, power: derived.power };
  };

  CombatEngine.prototype._cast = function (unit, isUlt) {
    var kit = unit.side === 'player' ? HERO_KIT[unit.heroId] : null;
    if (kit && (isUlt ? kit.ultimate : kit.active)) {
      this.emit(isUlt ? 'ultimate' : 'skill', { uid: unit.uid, name: isUlt ? unit.ultimateName : unit.activeName });
      var ctx = { primary: null }, self = this;
      (isUlt ? kit.ultimate : kit.active).forEach(function (op) { self._runOp(unit, op, ctx, isUlt); });
      return true;
    }
    var skill = this._getGenericSkill(unit, isUlt);
    if (!skill) return false;
    this.emit(isUlt ? 'ultimate' : 'skill', { uid: unit.uid, name: skill.name });
    this._resolveSkillEffect(unit, skill);
    return true;
  };

  CombatEngine.prototype._doSkill = function (unit) {
    if (!this._cast(unit, false)) { this._basicAttack(unit); return; }
    unit.skillCooldown = unit.skillCooldownMax;
    unit.energy = clamp(unit.energy + CFG.ENERGY_PER_SKILL, 0, ENERGY_MAX);
    this._onAction(unit);
  };

  CombatEngine.prototype._doUltimate = function (unit) {
    if (!this._cast(unit, true)) return;
    unit.energy = 0;
  };

  // ---------- Boucle principale ----------
  CombatEngine.prototype.update = function (dt) {
    if (this.over || dt <= 0) return;
    this.time += dt;
    var self = this, t = this.time;

    if (this.combo > 0 && this.comboUntil <= t) {
      this.combo = 0;
      this.emit('comboReset', {});
    }

    // Actions planifiées (coups multiples)
    while (this._sched.length && this._sched[0].at <= t) {
      var job = this._sched.shift();
      if (this.over) break;
      if (job.owner && !job.owner.alive) continue;
      job.fn();
    }

    // Statuts : dégâts sur la durée, expiration des boucliers/buffs
    this.all.forEach(function (u) {
      if (!u.alive) return;
      if (u.shield > 0 && u.shieldUntil && u.shieldUntil <= t) { u.shield = 0; u.shieldUntil = 0; }
      if (u.mods.length) u.mods = u.mods.filter(function (m) { return m.until > t; });
      for (var i = u.dots.length - 1; i >= 0 && u.alive; i--) {
        var d = u.dots[i];
        if (d.until <= t) { u.dots.splice(i, 1); continue; }
        if (d.next <= t) {
          d.next += CFG.DOT_TICK;
          self.applyDamage(d.src, u, d.power, { noCrit: true, noMiss: true, dot: true, reflect: true });
        }
      }
    });

    // Frappe du Commandant : action du joueur, indépendante des héros, exécutée dès que possible.
    if (this._commanderStrikeRequested) {
      this._commanderStrikeRequested = false;
      if (this.strikeReady()) this._doCommanderStrike();
    }

    // Ordres du joueur : compétence immédiate si prête (modes AUTO et MANUEL)
    this.player.forEach(function (u) {
      if (!self._manualSkillRequests[u.uid]) return;
      delete self._manualSkillRequests[u.uid];
      if (self.skillReady(u)) self._doSkill(u);
    });

    this.all.forEach(function (u) {
      if (!u.alive) return;
      if (u.skillCooldown > 0) u.skillCooldown = Math.max(0, u.skillCooldown - dt);
      if (u.stunTime > 0) { u.stunTime = Math.max(0, u.stunTime - dt); return; } // étourdi : jauge gelée

      u.gauge += self._effSpeed(u) * dt * (CFG.GAUGE_RATE / 100);
      if (u.gauge >= GAUGE_MAX) {
        u.gauge -= GAUGE_MAX;
        var wantsSkill = u.skillCooldown <= 0;
        if (wantsSkill && u.side === 'player' && self.mode === 'manual') wantsSkill = false; // MANUEL : attend l'ordre du joueur
        if (wantsSkill) self._doSkill(u); else self._basicAttack(u);
      }
    });

    // Ultimes : dès que l'énergie est pleine (AUTO / boss) ou sur ordre du joueur (MANUEL)
    this.all.forEach(function (u) {
      if (!u.alive || u.energy < ENERGY_MAX || u.stunTime > 0) return;
      if (u.side === 'enemy' && !u.isBoss) return;  // seuls les boss ont un ultime (« Déchaînement »)
      var autoFire = (u.side === 'enemy') || (self.mode === 'auto');
      var manualFire = u.side === 'player' && self._manualUltimateRequests[u.uid];
      if (autoFire || manualFire) {
        if (manualFire) delete self._manualUltimateRequests[u.uid];
        self._doUltimate(u);
      }
    });

    this._checkVictory();
  };

  CombatEngine.prototype._checkVictory = function () {
    if (this.over) return;
    var playerAlive = this.aliveOf('player').length;
    var enemyAlive = this.aliveOf('enemy').length;
    if (playerAlive === 0 || enemyAlive === 0) {
      this.over = true;
      var win = enemyAlive === 0 && playerAlive > 0;
      this.result = { win: win, survivors: playerAlive, totalPlayers: this.player.length, timeSec: this.time };
      this.emit(win ? 'victory' : 'defeat', this.result);
    }
  };

  return {
    CombatEngine: CombatEngine,
    makeHeroUnit: makeHeroUnit,
    makeEnemyUnit: makeEnemyUnit,
    deriveHeroSkill: deriveHeroSkill,
    HERO_KIT: HERO_KIT, CFG: CFG,
    GAUGE_MAX: GAUGE_MAX, ENERGY_MAX: ENERGY_MAX
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.CombatEngine; }
