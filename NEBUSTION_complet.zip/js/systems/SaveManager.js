/**
 * NEBUSTION - SaveManager
 * Sauvegarde locale (localStorage) robuste, sans dépendance à Phaser :
 *  - enveloppe { h: somme de contrôle, d: données } → détecte les sauvegardes tronquées/corrompues
 *  - copie de secours (_bak) rafraîchie au plus une fois par minute
 *  - une sauvegarde illisible est conservée à part (_corrupt) au lieu d'être écrasée en silence
 *  - normalize() reconstruit un état VALIDE à partir de n'importe quoi (NaN, négatifs, valeurs absurdes)
 *  - si localStorage est indisponible (navigation privée...), repli en mémoire (isPersistent() = false)
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Save = (function () {
  'use strict';

  var KEY = 'nebustion_save_v2';
  var KEY_BAK = KEY + '_bak';
  var KEY_BAD = KEY + '_corrupt';
  var VERSION = 9; // v9 : exploration du Trou Noir (profondeurs, Fragments, améliorations) ; v7 : expéditions, événements, Prestige (Renaissance galactique), succès/récompenses quotidiennes ; v6 : boutique ; v5 : skins ; v4 : vaisseaux/flotte — rétrocompatible avec v2..v8
  var BACKUP_EVERY_MS = 60000;

  var memory = {};
  var memStore = {
    getItem: function (k) { return Object.prototype.hasOwnProperty.call(memory, k) ? memory[k] : null; },
    setItem: function (k, v) { memory[k] = String(v); },
    removeItem: function (k) { delete memory[k]; }
  };
  var store = null;
  var persistent = false;
  var lastBackupAt = 0;

  function detect() {
    try {
      var ls = window.localStorage;
      if (!ls) throw new Error('no localStorage');
      ls.setItem('__nb_probe__', '1');
      ls.removeItem('__nb_probe__');
      store = ls; persistent = true;
    } catch (e) {
      store = memStore; persistent = false;
    }
  }
  function st() { if (!store) detect(); return store; }

  function hash(str) {
    var h = 5381;
    for (var i = 0; i < str.length; i++) { h = (((h << 5) + h) + str.charCodeAt(i)) | 0; }
    return (h >>> 0).toString(36);
  }
  function encode(state) {
    var body = JSON.stringify(state);
    return JSON.stringify({ h: hash(body), d: body });
  }
  function decode(text) {
    try {
      var env = JSON.parse(text);
      if (!env || typeof env.d !== 'string' || hash(env.d) !== env.h) return null;
      var obj = JSON.parse(env.d);
      return (obj && typeof obj === 'object') ? obj : null;
    } catch (e) { return null; }
  }

  // ---------- Validation ----------
  function num(x, min, max, def) {
    x = Number(x);
    if (!isFinite(x)) return def;
    return x < min ? min : (x > max ? max : x);
  }
  function int(x, min, max, def) { return Math.floor(num(x, min, max, def)); }

  function randomId() {
    return 's' + Math.floor(Math.random() * 1e9).toString(36) + Date.now().toString(36);
  }

  function defaultState(now) {
    var E = NEBUSTION.Economy;
    var s = {
      v: VERSION, sid: randomId(),
      createdAt: now, savedAt: now, lastSeen: now,
      res: {}, life: {}, buildings: {}, drones: {}, nodes: {},
      stats: { taps: 0, crits: 0, pods: 0, sessions: 1, playSec: 0, offlineSec: 0, lastPod: now - 60000 },
      combat: {
        difficulty: 'normal', team: [], stageStars: {}, playerXP: 0, fragments: {}, unlockedHeroes: {},
        battlesWon: 0, battlesLost: 0,
        formation: {}   // positionnement héros -> 'front' | 'back' (Frappe du Commandant / formation)
      },
      // Module Galaxie (étape 5) : secteurs débloqués, scans, visites, conquêtes, vue de la carte
      galaxy: { unlocked: { s1: true }, scans: {}, jobs: {}, visited: {}, conquered: {}, view: null, colonyAt: 0, stats: { scans: 0, unlocks: 0 } },
      // Module IA 3 : évolution des empires (ressources, développement, défenses) — voir EmpireEvolution.js
      empires: (NEBUSTION.EmpireEvolution && NEBUSTION.Galaxy) ? NEBUSTION.EmpireEvolution.defaultState(now) : null,
      // Module Équipement (étape 6) : inventaire, objets équipés par héros — voir Equipment.js
      equipment: NEBUSTION.Equipment ? NEBUSTION.Equipment.defaultState() : null,
      // Module Vaisseaux (étape 6, partie 2) : hangar, flotte sélectionnée — voir Ships.js
      ships: NEBUSTION.Ships ? NEBUSTION.Ships.defaultState() : null,
      // Module Personnalisation (étape 6, partie 3) : skins possédés / équipés — voir Skins.js
      skins: NEBUSTION.Skins ? NEBUSTION.Skins.defaultState() : null,
      // Module Caisses & Clés : caisses/clés possédées, Éclats stellaires, pitié, historique — voir Crates.js
      crates: NEBUSTION.Crates ? NEBUSTION.Crates.defaultState() : null,
      // Module Boutique (étape 7) : Prismes (monnaie premium), rotation quotidienne — voir Shop.js
      shop: NEBUSTION.Shop ? NEBUSTION.Shop.defaultState(now) : null,
      // Module Pass de saison (étape 8) : saison, XP Pass, récompenses réclamées, missions — voir Pass.js
      pass: NEBUSTION.Pass ? NEBUSTION.Pass.defaultState(now) : null,
      // Module Expéditions (étape 10) : missions temporisées en cours, historique — voir Expeditions.js
      expeditions: NEBUSTION.ExpeditionManager ? NEBUSTION.ExpeditionManager.defaultState() : null,
      // Module Événements (étape 10) : cycle horaire local, boss, missions, boutique événementielle — voir Events.js
      events: NEBUSTION.EventManager ? NEBUSTION.EventManager.defaultState(now) : null,
      // Module Prestige (étape 10) : Reliques cosmiques (jamais réinitialisées), arbre de bonus permanents — voir Prestige.js
      prestige: NEBUSTION.PrestigeManager ? NEBUSTION.PrestigeManager.defaultState() : null,
      // Module Succès / récompenses quotidiennes / objectifs long terme (étape 10) — voir Achievements.js
      achievements: NEBUSTION.AchievementsManager ? NEBUSTION.AchievementsManager.defaultState() : null,
      // Module Sécurité du QG (étape 11B) : niveau de sécurité de la zone intérieure — voir Security.js
      security: NEBUSTION.Security ? NEBUSTION.Security.defaultState() : null,
      // Module Grille constructible du QG (étape 11C) : parcelles déverrouillées + structures posées — voir QGGrid.js
      qgGrid: NEBUSTION.QGGrid ? NEBUSTION.QGGrid.defaultState() : null,
      // Module Raids ennemis contre le QG (étape 12) : historique, dernier raid, seed déterministe — voir QGRaid.js
      qgRaid: NEBUSTION.QGRaid ? NEBUSTION.QGRaid.defaultState(now) : null,
      // Module Attaques du joueur contre le QG des empires (étape 17) : cooldowns, historique — voir QGAttack.js
      qgAttack: NEBUSTION.QGAttack ? NEBUSTION.QGAttack.defaultState() : null,
      // Module 18 : armée du joueur (troupes achetées à la Caserne, déployées en mode combat) — voir Troops.js
      troops: NEBUSTION.Troops ? NEBUSTION.Troops.defaultState() : null,
      // Module Symtor / Symbiote : créature évolutive de la base.
      symbiote: NEBUSTION.Symbiote ? NEBUSTION.Symbiote.defaultState() : null,
      // Module Nebustion : jauge de corruption galactique, Sanctuaire, Éclat Souillé (grand méchant).
      nebustion: NEBUSTION.Nebustion ? NEBUSTION.Nebustion.defaultState(now) : null,
      // Module Matchmaking QG (étape 27) : adversaire actuellement proposé — voir QGMatchmaking.js
      qgMatch: { current: null },
      // Module Trou Noir : exploration à profondeurs, Fragments de Singularité, améliorations — voir BlackHole.js
      blackhole: NEBUSTION.BlackHoleManager ? NEBUSTION.BlackHoleManager.defaultState(now) : null,
      // Constructions à placement libre sur la planète Nexus-01 — voir PlanetBuild.js
      planetBuild: NEBUSTION.PlanetBuild ? NEBUSTION.PlanetBuild.defaultState() : null,
      // Colonies des planètes de la Nouvelle Galaxie (installations, production, hors ligne) — voir Colonies.js
      colonies: NEBUSTION.Colonies ? NEBUSTION.Colonies.defaultState() : null,
      // Parcelles à acheter sur les planètes (Nexus-01 + mondes de la Nouvelle Galaxie) — voir Parcels.js
      parcels: NEBUSTION.Parcels ? NEBUSTION.Parcels.normalizeState(null, null) : null
    };
    E.ORDER.forEach(function (id) {
      s.res[id] = E.PROD[id].start;
      s.life[id] = 0;
      s.drones[id] = E.CFG.START_DRONES;
      s.nodes[id] = { ch: E.CFG.MAX_CHARGES, t: now };
    });
    E.BUILDING_ORDER.forEach(function (bid) { s.buildings[bid] = { level: E.BUILDINGS[bid].start }; });
    return s;
  }

  /** Construit un état valide à partir de données brutes (ou d'une sauvegarde absente/abîmée). */
  function normalize(raw, now) {
    var E = NEBUSTION.Economy;
    var s = defaultState(now);
    if (!raw || typeof raw !== 'object') return s;

    s.createdAt = num(raw.createdAt, 0, now, now);
    s.savedAt = num(raw.savedAt, 0, now, now);
    s.lastSeen = num(raw.lastSeen, 0, now, now);   // une date future (horloge modifiée) est ramenée à « maintenant »

    var rb = raw.buildings || {};
    E.BUILDING_ORDER.forEach(function (bid) {
      var l = rb[bid] && rb[bid].level;
      s.buildings[bid] = { level: int(l, 1, E.CFG.MAX_LEVEL, E.BUILDINGS[bid].start) };
    });

    var storageLvl = s.buildings.storage.level;
    var rr = raw.res || {}, rl = raw.life || {}, rd = raw.drones || {}, rn = raw.nodes || {};
    E.ORDER.forEach(function (id) {
      var cap = E.storageCap(id, storageLvl);
      s.res[id] = num(rr[id], 0, cap, E.PROD[id].start);
      s.life[id] = num(rl[id], 0, 1e15, 0);
      s.drones[id] = int(rd[id], 0, E.CFG.MAX_DRONES, E.CFG.START_DRONES);
      var n = rn[id] || {};
      s.nodes[id] = {
        ch: num(n.ch, 0, E.CFG.MAX_CHARGES, E.CFG.MAX_CHARGES),
        t: num(n.t, 0, now, now)
      };
    });

    var rs = raw.stats || {};
    s.stats = {
      taps: int(rs.taps, 0, 1e12, 0), crits: int(rs.crits, 0, 1e12, 0), pods: int(rs.pods, 0, 1e12, 0),
      sessions: int(rs.sessions, 1, 1e9, 1),
      playSec: num(rs.playSec, 0, 1e12, 0), offlineSec: num(rs.offlineSec, 0, 1e12, 0),
      lastPod: num(rs.lastPod, 0, now, now - 60000)
    };
    if (typeof raw.sid === 'string' && raw.sid.length > 0 && raw.sid.length < 40) s.sid = raw.sid;

    // ---------- Combat (module ajouté à l'étape 4 ; absent des sauvegardes plus anciennes) ----------
    var rc = raw.combat || {};
    var VALID_DIFF = { facile: 1, normal: 1, difficile: 1, cauchemar: 1 };
    s.combat = {
      difficulty: (typeof rc.difficulty === 'string' && VALID_DIFF[rc.difficulty]) ? rc.difficulty : 'normal',
      team: Array.isArray(rc.team) ? rc.team.filter(function (id) { return typeof id === 'string'; }).slice(0, 5) : [],
      stageStars: {}, fragments: {}, unlockedHeroes: {},   // unlockedHeroes : héros exclusifs de la Boutique recrutés (étape 9)
      playerXP: int(rc.playerXP, 0, 1e12, 0),
      battlesWon: int(rc.battlesWon, 0, 1e12, 0),
      battlesLost: int(rc.battlesLost, 0, 1e12, 0),
      formation: {}
    };
    var rfm = rc.formation || {};
    Object.keys(rfm).forEach(function (hid) {
      if (typeof hid === 'string' && (rfm[hid] === 'front' || rfm[hid] === 'back')) s.combat.formation[hid] = rfm[hid];
    });
    var rss = rc.stageStars || {};
    Object.keys(rss).forEach(function (sid) {
      if (typeof sid === 'string') s.combat.stageStars[sid] = int(rss[sid], 0, 3, 0);
    });
    var ruh = rc.unlockedHeroes || {};
    Object.keys(ruh).forEach(function (hid) {
      if (typeof hid === 'string' && ruh[hid] === true) s.combat.unlockedHeroes[hid] = true;
    });
    var rf = rc.fragments || {};
    Object.keys(rf).forEach(function (hid) {
      if (typeof hid === 'string') s.combat.fragments[hid] = int(rf[hid], 0, 1e9, 0);
    });

    // ---------- Galaxie (module ajouté à l'étape 5 ; absent des sauvegardes plus anciennes) ----------
    if (NEBUSTION.Galaxy && NEBUSTION.Galaxy.normalizeState) {
      s.galaxy = NEBUSTION.Galaxy.normalizeState(raw.galaxy, now);
    } else if (raw.galaxy && typeof raw.galaxy === 'object') {
      s.galaxy = JSON.parse(JSON.stringify(raw.galaxy));   // module de données absent (tests isolés) : on conserve sans perte
    }

    // ---------- Empires (module IA 3 ; absent des sauvegardes plus anciennes → état neuf, aucun rattrapage) ----------
    if (NEBUSTION.EmpireEvolution && NEBUSTION.Galaxy) {
      s.empires = NEBUSTION.EmpireEvolution.normalizeState(raw.empires, now);
    } else if (raw.empires && typeof raw.empires === 'object') {
      s.empires = JSON.parse(JSON.stringify(raw.empires));   // module absent (tests isolés) : conservé sans perte
    }

    // ---------- Équipement (module ajouté à l'étape 6 ; absent des sauvegardes v2 et antérieures) ----------
    if (NEBUSTION.Equipment) {
      s.equipment = NEBUSTION.Equipment.normalizeState(raw.equipment);
    } else if (raw.equipment && typeof raw.equipment === 'object') {
      s.equipment = JSON.parse(JSON.stringify(raw.equipment));   // module absent (tests isolés) : conservé sans perte
    }

    // ---------- Vaisseaux (module ajouté à l'étape 6, partie 2 ; absent des sauvegardes v3 et antérieures) ----------
    if (NEBUSTION.Ships) {
      s.ships = NEBUSTION.Ships.normalizeState(raw.ships);
    } else if (raw.ships && typeof raw.ships === 'object') {
      s.ships = JSON.parse(JSON.stringify(raw.ships));   // module absent (tests isolés) : conservé sans perte
    }

    // ---------- Skins (module ajouté à l'étape 6, partie 3 ; absent des sauvegardes v4 et antérieures) ----------
    if (NEBUSTION.Skins) {
      s.skins = NEBUSTION.Skins.normalizeState(raw.skins);
    } else if (raw.skins && typeof raw.skins === 'object') {
      s.skins = JSON.parse(JSON.stringify(raw.skins));   // module absent (tests isolés) : conservé sans perte
    }

    // ---------- Caisses & Clés (module ajouté ensuite ; absent des sauvegardes antérieures : repart d'un état vide) ----------
    if (NEBUSTION.Crates) {
      s.crates = NEBUSTION.Crates.normalizeState(raw.crates);
    } else if (raw.crates && typeof raw.crates === 'object') {
      s.crates = JSON.parse(JSON.stringify(raw.crates));   // module absent (tests isolés) : conservé sans perte
    }

    // ---------- Boutique (module ajouté à l'étape 7 ; absent des sauvegardes v5 et antérieures) ----------
    if (NEBUSTION.Shop) {
      s.shop = NEBUSTION.Shop.normalizeState(raw.shop, now);
    } else if (raw.shop && typeof raw.shop === 'object') {
      s.shop = JSON.parse(JSON.stringify(raw.shop));   // module absent (tests isolés) : conservé sans perte
    }

    // ---------- Pass de saison (module ajouté à l'étape 8 ; absent des sauvegardes v6 et antérieures) ----------
    if (NEBUSTION.Pass) {
      s.pass = NEBUSTION.Pass.normalizeState(raw.pass, now);
    } else if (raw.pass && typeof raw.pass === 'object') {
      s.pass = JSON.parse(JSON.stringify(raw.pass));   // module absent (tests isolés) : conservé sans perte
    }

    // ---------- Expéditions / Événements / Prestige / Succès (module ajouté à l'étape 10 ; absents des sauvegardes v6 et antérieures) ----------
    if (NEBUSTION.ExpeditionManager) {
      s.expeditions = NEBUSTION.ExpeditionManager.normalizeState(raw.expeditions, now);
    } else if (raw.expeditions && typeof raw.expeditions === 'object') {
      s.expeditions = JSON.parse(JSON.stringify(raw.expeditions));
    }
    if (NEBUSTION.EventManager) {
      s.events = NEBUSTION.EventManager.normalizeState(raw.events, now);
    } else if (raw.events && typeof raw.events === 'object') {
      s.events = JSON.parse(JSON.stringify(raw.events));
    }
    if (NEBUSTION.PrestigeManager) {
      s.prestige = NEBUSTION.PrestigeManager.normalizeState(raw.prestige);
    } else if (raw.prestige && typeof raw.prestige === 'object') {
      s.prestige = JSON.parse(JSON.stringify(raw.prestige));
    }
    if (NEBUSTION.AchievementsManager) {
      s.achievements = NEBUSTION.AchievementsManager.normalizeState(raw.achievements);
    } else if (raw.achievements && typeof raw.achievements === 'object') {
      s.achievements = JSON.parse(JSON.stringify(raw.achievements));
    }
    if (NEBUSTION.Security) {
      s.security = NEBUSTION.Security.normalizeState(raw.security);
    } else if (raw.security && typeof raw.security === 'object') {
      s.security = JSON.parse(JSON.stringify(raw.security));
    }
    if (NEBUSTION.QGGrid) {
      s.qgGrid = NEBUSTION.QGGrid.normalizeState(raw.qgGrid, now);
    } else if (raw.qgGrid && typeof raw.qgGrid === 'object') {
      s.qgGrid = JSON.parse(JSON.stringify(raw.qgGrid));
    }
    if (NEBUSTION.QGRaid) {
      s.qgRaid = NEBUSTION.QGRaid.normalizeState(raw.qgRaid, now);
    } else if (raw.qgRaid && typeof raw.qgRaid === 'object') {
      s.qgRaid = JSON.parse(JSON.stringify(raw.qgRaid));
    }
    if (NEBUSTION.QGAttack) {
      s.qgAttack = NEBUSTION.QGAttack.normalizeState(raw.qgAttack);
    } else if (raw.qgAttack && typeof raw.qgAttack === 'object') {
      s.qgAttack = JSON.parse(JSON.stringify(raw.qgAttack));
    }
    if (NEBUSTION.Troops) {
      s.troops = NEBUSTION.Troops.normalizeState(raw.troops);
    } else if (raw.troops && typeof raw.troops === 'object') {
      s.troops = JSON.parse(JSON.stringify(raw.troops));
    }
    if (NEBUSTION.Symbiote) {
      s.symbiote = NEBUSTION.Symbiote.normalizeState(raw.symbiote);
    } else if (raw.symbiote && typeof raw.symbiote === 'object') {
      s.symbiote = JSON.parse(JSON.stringify(raw.symbiote));
    }
    if (NEBUSTION.Nebustion) {
      s.nebustion = NEBUSTION.Nebustion.normalizeState(raw.nebustion, now);
    } else if (raw.nebustion && typeof raw.nebustion === 'object') {
      s.nebustion = JSON.parse(JSON.stringify(raw.nebustion));
    }
    s.qgMatch = { current: null };
    if (raw.qgMatch && typeof raw.qgMatch === 'object' && raw.qgMatch.current && typeof raw.qgMatch.current === 'object') {
      var mc = raw.qgMatch.current, eid = String(mc.eid || '');
      if (eid) s.qgMatch.current = { eid: eid, variant: int(mc.variant, 0, 999999999, 0), foundAt: int(mc.foundAt, 0, 8.64e15, now) };
    }
    // ---------- Trou Noir (module ajouté à l'étape 29 ; absent des sauvegardes v8 et antérieures) ----------
    if (NEBUSTION.BlackHoleManager) {
      s.blackhole = NEBUSTION.BlackHoleManager.normalizeState(raw.blackhole, now);
    } else if (raw.blackhole && typeof raw.blackhole === 'object') {
      s.blackhole = JSON.parse(JSON.stringify(raw.blackhole));   // module absent (tests isolés) : conservé sans perte
    }
    // ---------- Constructions libres sur la planète (absent des sauvegardes antérieures) ----------
    if (NEBUSTION.PlanetBuild) {
      s.planetBuild = NEBUSTION.PlanetBuild.normalizeState(raw.planetBuild);
    } else if (raw.planetBuild && typeof raw.planetBuild === 'object') {
      s.planetBuild = JSON.parse(JSON.stringify(raw.planetBuild));   // module absent (tests isolés) : conservé sans perte
    }
    // ---------- Parcelles des planètes (absent des sauvegardes antérieures) : territoire de départ + parcelle de chaque construction déjà posée ----------
    if (NEBUSTION.Parcels) {
      s.parcels = NEBUSTION.Parcels.normalizeState(raw.parcels, s.planetBuild);
    } else if (raw.parcels && typeof raw.parcels === 'object') {
      s.parcels = JSON.parse(JSON.stringify(raw.parcels));   // module absent (tests isolés) : conservé sans perte
    }
    // ---------- Colonies de la Nouvelle Galaxie (absent des sauvegardes antérieures) ----------
    if (NEBUSTION.Colonies) {
      s.colonies = NEBUSTION.Colonies.normalizeState(raw.colonies, now);
    } else if (raw.colonies && typeof raw.colonies === 'object') {
      s.colonies = JSON.parse(JSON.stringify(raw.colonies));   // module absent (tests isolés) : conservé sans perte
    }
    // ---------- Tutoriel d'accueil (ajouté avec le Pass Doré ; absent des sauvegardes antérieures) ----------
    if (NEBUSTION.TutorialManager) {
      s.tutorial = NEBUSTION.TutorialManager.normalizeState(raw.tutorial);
    } else if (raw.tutorial && typeof raw.tutorial === 'object') {
      s.tutorial = { v: 1, done: raw.tutorial.done === true };   // module absent (tests isolés) : conservé
    }
    return s;
  }

  // ---------- Lecture / écriture ----------
  function write(state, now) {
    try {
      var text = encode(state);
      var s = st();
      s.setItem(KEY, text);
      now = now || Date.now();
      if (!lastBackupAt || now - lastBackupAt >= BACKUP_EVERY_MS || now < lastBackupAt) {
        s.setItem(KEY_BAK, text);
        lastBackupAt = now;
      }
      return true;
    } catch (e) {
      return false;   // quota dépassé, stockage bloqué... le jeu continue en mémoire
    }
  }

  /** @returns {{state:object|null, source:'primary'|'backup'|null, corrupted:boolean}} */
  function load() {
    var out = { state: null, source: null, corrupted: false };
    var s = st();
    var text = null, bak = null;
    try { text = s.getItem(KEY); bak = s.getItem(KEY_BAK); } catch (e) { return out; }
    if (text) {
      var o = decode(text);
      if (o) { out.state = o; out.source = 'primary'; return out; }
      out.corrupted = true;
      try { s.setItem(KEY_BAD, text); } catch (e) { /* ignore */ }
    }
    if (bak) {
      var ob = decode(bak);
      if (ob) { out.state = ob; out.source = 'backup'; return out; }
      out.corrupted = true;
    }
    return out;
  }

  /** Décode un texte de sauvegarde (utilisé pour l'événement `storage` d'un autre onglet). */
  function parseText(text) { return text ? decode(text) : null; }

  function wipe() {
    try { var s = st(); s.removeItem(KEY); s.removeItem(KEY_BAK); s.removeItem(KEY_BAD); } catch (e) { /* ignore */ }
    lastBackupAt = 0;
  }

  return {
    KEY: KEY, VERSION: VERSION,
    defaultState: defaultState, normalize: normalize,
    load: load, write: write, wipe: wipe, parseText: parseText,
    isPersistent: function () { st(); return persistent; },
    _useStorage: function (s) { store = s; persistent = s !== memStore; lastBackupAt = 0; },   // tests
    _hash: hash, _encode: encode
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.Save; }
