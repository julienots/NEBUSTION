/**
 * NEBUSTION - CodexManager
 * Glue entre NEBUSTION.Codex (données pures) et l'état réel du jeu : lit les victoires de
 * Combat (NEBUSTION.Combat.stageStars) et l'état du module Nebustion/Renaissance
 * (NEBUSTION.Resources.state) pour savoir quelles entrées sont débloquées. NE MODIFIE AUCUN
 * état de jeu existant (aucune écriture dans NEBUSTION.Resources.state) : le Codex est un
 * journal de lecture seule.
 *
 * Le suivi des entrées déjà lues (pour la pastille « nouveau ») est stocké dans une clé
 * localStorage séparée de la sauvegarde principale (nebustion_save_v2) : perdre ce suivi
 * (autre appareil, navigation privée...) ne fait réapparaître que des pastilles, jamais de
 * perte de progression.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.CodexManager = (function () {
  'use strict';

  var SEEN_KEY = 'nebustion_codex_seen_v1';

  function _loadSeen() {
    try {
      var raw = window.localStorage ? window.localStorage.getItem(SEEN_KEY) : null;
      var arr = raw ? JSON.parse(raw) : [];
      return Array.isArray(arr) ? arr : [];
    } catch (e) { return []; }
  }
  function _saveSeen(arr) {
    try { if (window.localStorage) window.localStorage.setItem(SEEN_KEY, JSON.stringify(arr)); } catch (e) { /* ignore */ }
  }

  function _ctx() {
    var R = NEBUSTION.Resources, C = NEBUSTION.Combat;
    var st = (R && R.state) || {};
    return {
      stageStars: function (id) { try { return (C && C.stageStars) ? C.stageStars(id) : 0; } catch (e) { return 0; } },
      nebustion: st.nebustion || {},
      prestigeCount: (st.prestige && st.prestige.count) || 0,
      blackHoleMaxDepth: (st.blackhole && st.blackhole.maxDepth) || 0
    };
  }

  /** Entrées du récit (chronologie gagnée par la progression), annotées `unlocked` + `chapterLabel`. */
  function story() {
    var ctx = _ctx();
    return NEBUSTION.Codex.story(ctx).map(function (e) {
      return {
        id: e.id, chapter: e.chapter, title: e.title, hint: e.hint, unlocked: e.unlocked, body: e.body,
        chapterLabel: NEBUSTION.Codex.chapterName(e.chapter)
      };
    });
  }
  /** Entrées « Connexions » (toujours visibles). */
  function connections() { return NEBUSTION.Codex.connections(); }

  function progress() { var ctx = _ctx(); return { unlocked: NEBUSTION.Codex.storyUnlockedCount(ctx), total: NEBUSTION.Codex.storyTotalCount() }; }

  /** Nombre d'entrées débloquées jamais consultées (pastille de la barre de navigation). */
  function unseenCount() {
    var seen = _loadSeen();
    return story().filter(function (e) { return e.unlocked && seen.indexOf(e.id) < 0; }).length;
  }
  /** Marque une entrée comme lue. */
  function markSeen(id) {
    var seen = _loadSeen();
    if (seen.indexOf(id) < 0) { seen.push(id); _saveSeen(seen); }
  }
  /** Marque toutes les entrées actuellement débloquées comme lues (appelé à l'ouverture de l'écran). */
  function markAllSeen() {
    var seen = _loadSeen(), changed = false;
    story().forEach(function (e) {
      if (e.unlocked && seen.indexOf(e.id) < 0) { seen.push(e.id); changed = true; }
    });
    if (changed) _saveSeen(seen);
  }

  return { story: story, connections: connections, progress: progress, unseenCount: unseenCount, markSeen: markSeen, markAllSeen: markAllSeen };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = NEBUSTION.CodexManager;
