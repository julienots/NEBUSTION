/**
 * NEBUSTION - QGAttackManager
 * Glue entre NEBUSTION.QGAttack (données pures) et le reste du jeu :
 *  - puissance d'attaque : ShipManager.fleetPower() (flotte de « bots » du Hangar, module 6) ;
 *  - défense visée : mémoire de l'empire (EmpireEvolutionManager) — LUE, et MODIFIÉE (traumatisme/élan)
 *    en retour de l'attaque, exactement comme EmpireEvolutionManager.resolveInvasion() le fait déjà
 *    pour les invasions de planètes ;
 *  - butin : crédité via NEBUSTION.Resources.add(), jamais les Noyaux antiques (`core`) ;
 *  - sauvegarde : NEBUSTION.Resources.state.qgAttack (branché SaveManager, comme qgRaid).
 *
 * Action manuelle du joueur (pas de simulation hors ligne à rattraper) : l'issue est tirée
 * immédiatement au moment de l'appel, comme les autres tirages ponctuels du jeu (Equipment, CombatEngine).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.QGAttackManager = (function () {
  'use strict';

  var D = function () { return NEBUSTION.QGAttack; };
  var G = function () { return NEBUSTION.Galaxy; };
  var GM = function () { return NEBUSTION.GalaxyManager; };
  var EM = function () { return NEBUSTION.EmpireEvolutionManager; };
  var SH = function () { return NEBUSTION.ShipManager; };

  var listeners = {};
  function on(evt, fn) { (listeners[evt] = listeners[evt] || []).push(fn); return function () { off(evt, fn); }; }
  function off(evt, fn) { if (listeners[evt]) listeners[evt] = listeners[evt].filter(function (f) { return f !== fn; }); }
  function emit(evt, data) { (listeners[evt] || []).slice().forEach(function (f) { try { f(data); } catch (e) { console.error('QGAttackManager listener', e); } }); }

  function nowOf(now) { return (typeof now === 'number' && isFinite(now)) ? now : Date.now(); }
  function root() { return NEBUSTION.Resources && NEBUSTION.Resources.state; }
  function state() {
    var r = root();
    if (!r) return D().defaultState();
    if (!r.qgAttack) r.qgAttack = D().normalizeState(null);
    return r.qgAttack;
  }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }
  function ready() { return !!(EM() && G() && GM() && SH()); }

  /** L'empire tient-il encore au moins une planète non conquise ? (sinon : déjà vaincu, rien à attaquer). */
  function isAlive(eid) {
    return ready() && G().EMPIRE_ORDER.indexOf(eid) >= 0 &&
      G().planetsOfEmpire(eid).some(function (p) { return !GM().isConquered(p.id); });
  }

  function qgBonus(type) {
    try { var qm = NEBUSTION.QGGridManager; return qm ? qm.bonusValue(type) : 0; } catch (e) { return 0; }
  }
  /** Recharge effective entre deux attaques de flotte : réduite par les Radars du QG (max −60 %). */
  function cooldownMs() { return Math.round(D().COOLDOWN_MS * (1 - Math.min(0.6, qgBonus('attackCooldown')))); }
  /** Multiplicateur de butin : Raffineries du QG (+5 % chacune). */
  function lootMult() { return 1 + qgBonus('loot'); }

  function cooldownRemaining(eid, now) {
    now = nowOf(now);
    var last = state().cooldowns[eid] || 0;
    return Math.max(0, cooldownMs() - (now - last));
  }

  /** Empires que le joueur peut cibler dans l'ordre du jeu (uniquement ceux encore en jeu). */
  function targets() {
    if (!ready()) return [];
    return G().EMPIRE_ORDER.filter(isAlive);
  }

  /** Peut-on lancer une attaque contre le QG de cet empire maintenant ? */
  function canAttack(eid, now) {
    if (!ready()) return { ok: false, reason: 'indisponible' };
    if (!isAlive(eid)) return { ok: false, reason: 'vaincu' };
    if (!SH().getFleet().length) return { ok: false, reason: 'flotte_vide' };
    if (cooldownRemaining(eid, now) > 0) return { ok: false, reason: 'recharge' };
    return { ok: true };
  }

  /** Lance l'attaque : tirage immédiat, effets appliqués (butin, cooldown, mémoire de l'empire). */
  function attack(eid, now) {
    now = nowOf(now);
    var can = canAttack(eid, now);
    if (!can.ok) return can;
    var Dm = D(), st = state();
    var es = EM().state(now).e[eid];
    var atk = Dm.attackPower(SH().fleetPower());
    var def = Dm.defensePower(es.evo, es.hurt || 0);
    var margin = Math.max(0, (atk - def) / Math.max(1, atk));
    var victory = Math.random() < Dm.victoryChance(atk, def);
    var entry = { at: now, empire: eid, victory: victory, attack: atk, defense: def, loot: {}, trophies: 0 };
    if (victory) {
      entry.loot = Dm.lootFor(es.evo, margin);
      var lm = lootMult();
      if (lm !== 1) Object.keys(entry.loot).forEach(function (rid) { entry.loot[rid] = Math.round(entry.loot[rid] * lm); });
      var R = NEBUSTION.Resources;
      Object.keys(entry.loot).forEach(function (rid) { if (R && typeof R.add === 'function') R.add(rid, entry.loot[rid], 'qgAttack'); });
      es.hurt = Math.round(Math.min(1, (es.hurt || 0) + 0.12) * 10000) / 10000;
      es.mom = Math.round(Math.max(0, (es.mom || 0) - 0.15) * 10000) / 10000;
      entry.trophies = Dm.trophyGain(margin);
    } else {
      es.mom = Math.round(Math.min(1, (es.mom || 0) + 0.1) * 10000) / 10000;
      entry.trophies = -Dm.trophyLoss(Dm.victoryChance(atk, def));
    }
    st.trophies = Math.max(0, Math.min(Dm.TROPHIES_MAX, st.trophies + entry.trophies));
    st.cooldowns[eid] = now;
    st.log.push(entry);
    if (st.log.length > Dm.LOG_MAX) st.log.shift();
    save();
    emit('attack', entry);
    return { ok: true, result: entry };
  }

  /**
   * Module 18 : applique le résultat d'un MODE COMBAT manuel (QGBattleScene / QGBattle.js) contre un QG ennemi.
   * Pas de recharge (le vrai coût, ce sont les troupes consommées). Butin selon les étoiles et le % détruit ;
   * l'empire encaisse un traumatisme proportionnel aux étoiles, ou reprend de l'élan si tu échoues.
   * @param res {{stars:number, pct:number, victory:boolean}}
   */
  function applyBattle(eid, res, now) {
    now = nowOf(now);
    if (!ready() || !isAlive(eid)) return { ok: false, reason: 'vaincu' };
    res = res || {};
    var stars = Math.max(0, Math.min(3, Math.floor(Number(res.stars) || 0)));
    var pct = Math.max(0, Math.min(1, Number(res.pct) || 0));
    var Dm = D(), st = state();
    var es = EM().state(now).e[eid];
    var victory = stars >= 1;
    var entry = { at: now, empire: eid, victory: victory, attack: stars, defense: 3, loot: {}, trophies: 0 };
    if (victory) {
      var raw = Dm.lootFor(es.evo, stars / 3), k = 0.6 + 0.4 * pct, R = NEBUSTION.Resources;
      Object.keys(raw).forEach(function (rid) {
        entry.loot[rid] = Math.round(raw[rid] * k * lootMult());
        if (R && typeof R.add === 'function') R.add(rid, entry.loot[rid], 'qgAttack');
      });
      es.hurt = Math.round(Math.min(1, (es.hurt || 0) + 0.05 * stars) * 10000) / 10000;
      es.mom = Math.round(Math.max(0, (es.mom || 0) - 0.05 * stars) * 10000) / 10000;
      entry.trophies = Dm.trophyGain(Math.min(1, (stars / 3) * 0.6 + pct * 0.4));
    } else {
      es.mom = Math.round(Math.min(1, (es.mom || 0) + 0.05) * 10000) / 10000;
      entry.trophies = -Dm.trophyLoss(Math.min(1, pct * 2));
    }
    st.trophies = Math.max(0, Math.min(Dm.TROPHIES_MAX, st.trophies + entry.trophies));
    st.log.push(entry);
    if (st.log.length > Dm.LOG_MAX) st.log.shift();
    save();
    emit('attack', entry);
    return { ok: true, result: entry };
  }

  /** Historique complet (le plus récent en dernier). */
  function log() { return state().log.slice(); }
  /** Dernière attaque connue, ou null si le joueur n'en a encore lancé aucune. */
  function lastResult() { var l = log(); return l.length ? l[l.length - 1] : null; }
  /** Total de Trophées de QG accumulés (récompense de progression, séparée des ressources). */
  function trophies() { return state().trophies || 0; }

  return {
    on: on, off: off, state: state, targets: targets, isAlive: isAlive,
    canAttack: canAttack, attack: attack, applyBattle: applyBattle, cooldownRemaining: cooldownRemaining, cooldownMs: cooldownMs, lootMult: lootMult,
    log: log, lastResult: lastResult, trophies: trophies
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.QGAttackManager; }
