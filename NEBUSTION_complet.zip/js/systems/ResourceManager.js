/**
 * NEBUSTION - ResourceManager
 * Cœur de l'économie : stock, production passive en temps réel, récolte manuelle,
 * caisses de ravitaillement, production hors-ligne, sauvegarde automatique.
 * AUCUNE dépendance à Phaser (testable sous Node). Instance unique : NEBUSTION.Resources.
 *
 * Garanties :
 *  - un stock n'est jamais négatif, NaN ou supérieur à la capacité de stockage ;
 *  - toute dépense est atomique (tout est payé, ou rien) ;
 *  - une absence n'est créditée qu'UNE fois (le « dernier instant vu » est enregistré immédiatement) ;
 *  - la production passive est calculée avec l'horloge réelle (Date.now), donc indépendante des FPS.
 *
 * Événements (on/off) : 'gain' {id, amount, source, crit}, 'full' {id}, 'offline' {report},
 *                       'upgrade' {id, level, cost}, 'saved', 'reset', 'external'
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.ResourceManager = class ResourceManager {
  constructor(deps) {
    deps = deps || {};
    this.E = deps.Economy || NEBUSTION.Economy;
    this.S = deps.Save || NEBUSTION.Save;
    this.rng = deps.rng || Math.random;
    this.sid = 'i' + Math.floor(Math.random() * 1e9).toString(36) + Date.now().toString(36);
    this.listeners = {};
    this.state = null;
    this.lastTick = 0;
    this.sessionStart = 0;
    this.pendingReport = null;
    this.isNewGame = false;
    this.loadInfo = null;
    this.lastSaveOk = true;
    this.lastSaveAt = 0;
    this._rates = null;
    this._sinceSave = 0;
    this._resetBuckets();
  }

  // ---------- Événements ----------
  on(evt, fn) {
    (this.listeners[evt] = this.listeners[evt] || []).push(fn);
    return () => this.off(evt, fn);
  }
  off(evt, fn) {
    var l = this.listeners[evt];
    if (!l) return;
    var i = l.indexOf(fn);
    if (i >= 0) l.splice(i, 1);
  }
  emit(evt, data) {
    var l = this.listeners[evt];
    if (!l) return;
    l.slice().forEach(function (fn) {
      try { fn(data); } catch (e) { if (typeof console !== 'undefined') console.error('NEBUSTION listener error (' + evt + ')', e); }
    });
  }

  // ---------- Initialisation ----------
  init(now) {
    now = now || Date.now();
    var loaded = this.S.load();
    this.loadInfo = loaded;
    this.isNewGame = !loaded.state;
    this.state = this.S.normalize(loaded.state, now);
    this.state.sid = this.sid;
    if (!this.isNewGame) this.state.stats.sessions += 1;
    this.sessionStart = now;
    this.lastTick = now;
    this._rates = null;
    this._resetBuckets();
    var gap = (now - this.state.lastSeen) / 1000;
    if (!this.isNewGame && gap >= this.E.CFG.GAP_THRESHOLD_SEC) this._applyOffline(gap, now);
    this.saveNow(now);
    return this;
  }

  /** Sauvegarde/rechargement à la fermeture, mise en veille, changement d'onglet, autre onglet. */
  installLifecycle(win, doc) {
    var self = this;
    win = win || window; doc = doc || document;
    function flush() {
      var now = Date.now();
      self.tick(now);
      self.saveNow(now);
    }
    doc.addEventListener('visibilitychange', function () { if (doc.hidden) flush(); });
    win.addEventListener('pagehide', flush);
    win.addEventListener('beforeunload', flush);
    win.addEventListener('storage', function (e) {
      if (e && e.key === self.S.KEY && e.newValue) self._adoptExternal(e.newValue);
    });
  }

  /** Un autre onglet a sauvegardé : on adopte son état pour ne jamais dupliquer de ressources. */
  _adoptExternal(text) {
    var raw = this.S.parseText(text);
    if (!raw || raw.sid === this.sid) return false;
    var now = Date.now();
    this.state = this.S.normalize(raw, now);
    this.state.sid = this.sid;
    this._rates = null;
    this.emit('external', {});
    return true;
  }

  // ---------- Lecture ----------
  get(id) { return this.state.res[id]; }
  level(bid) { return this.state.buildings[bid].level; }
  cap(id) {
    var base = this.E.storageCap(id, this.level('storage'));
    var qm = NEBUSTION.QGGridManager;
    var bonus = qm ? qm.bonusValue('storage') : 0;
    return Math.floor(base * (1 + bonus));
  }
  isFull(id) { return this.state.res[id] >= this.cap(id) - 1e-9; }
  droneCount(id) { return this.state.drones[id]; }
  extractorLevel(id) { return this.level('ext_' + id); }
  /** Production passive par seconde (extracteur + drones). */
  rate(id) { return this.rates()[id]; }
  ratePerMin(id) { return this.rate(id) * 60; }
  rates() {
    if (!this._rates) {
      var E = this.E, st = this.state, r = {};
      // Bonus permanent de Renaissance « Flux cosmique » (module Prestige, étape 10) : multiplie la production passive ET hors ligne.
      var pm = NEBUSTION.PrestigeManager, qm = NEBUSTION.QGGridManager;
      var sy = NEBUSTION.SymbioteManager;
      var mult = 1 + ((pm && pm.bonusValue) ? pm.bonusValue('production') : 0) + (qm ? qm.bonusValue('production') : 0) + (sy && sy.bonus ? sy.bonus('production') : 0)
        + E.labBonus(st.buildings.lab.level) + E.amplifierBonus(st.buildings.amplifier.level);
      E.ORDER.forEach(function (id) {
        r[id] = E.totalRate(id, st.buildings['ext_' + id].level, st.drones[id], st.buildings.hangar.level) * mult;
      });
      this._rates = r;
    }
    return this._rates;
  }
  /** Part de production d'UN drone (par seconde) — utilisé pour la cargaison affichée. */
  droneRate(id) { return this.E.droneRate(id, this.level('hangar')); }

  // ---------- Ajout / dépense ----------
  /** Ajoute une ressource (plafonnée au stockage). Retourne le montant réellement ajouté (≥ 0). */
  add(id, amount, source, meta) { return this._add(id, amount, source || 'other', meta, true); }

  _add(id, amount, source, meta, doEmit, now) {
    if (!this.E.RES[id]) return 0;
    amount = Number(amount);
    if (!isFinite(amount) || amount <= 0) return 0;
    var cur = this.state.res[id];
    var room = this.cap(id) - cur;
    if (room <= 1e-9) { if (doEmit) this.emit('full', { id: id }); return 0; }
    var added = Math.min(amount, room);
    this.state.res[id] = cur + added;
    this.state.life[id] += added;
    if (source !== 'offline') this._bucketAdd(id, added, now || Date.now());
    if (doEmit) {
      this.emit('gain', { id: id, amount: added, requested: amount, source: source, crit: !!(meta && meta.crit) });
      if (added < amount - 1e-9) this.emit('full', { id: id });
    }
    return added;
  }

  canAfford(cost) {
    var E = this.E, st = this.state;
    var keys = Object.keys(cost || {});
    for (var i = 0; i < keys.length; i++) {
      var amt = Number(cost[keys[i]]);
      if (!E.RES[keys[i]] || !isFinite(amt) || amt < 0) return false;
      if (st.res[keys[i]] + 1e-9 < amt) return false;
    }
    return true;
  }
  /** Dépense atomique : tout ou rien. Refuse les montants négatifs/NaN. */
  spendMany(cost) {
    if (!this.canAfford(cost)) return false;
    var st = this.state;
    Object.keys(cost).forEach(function (id) {
      st.res[id] = Math.max(0, st.res[id] - Number(cost[id]));
    });
    this._dirtyNow();
    return true;
  }
  spend(id, amount) { var c = {}; c[id] = amount; return this.spendMany(c); }

  // ---------- Temps réel ----------
  /** À appeler à chaque frame avec Date.now(). */
  tick(now) {
    if (!this.state) return;
    var dt = (now - this.lastTick) / 1000;
    if (!(dt > 0)) { if (dt < 0) this.lastTick = now; return; }   // même milliseconde ou horloge reculée
    this.lastTick = now;
    if (dt >= this.E.CFG.GAP_THRESHOLD_SEC) { this._applyOffline(dt, now); return; }

    var E = this.E, st = this.state, rates = this.rates();
    for (var i = 0; i < E.ORDER.length; i++) {
      var id = E.ORDER[i], r = rates[id];
      if (r > 0) this._add(id, r * dt, 'passive', null, false, now);
    }
    st.stats.playSec += dt;
    this._sinceSave += dt;
    if (this._sinceSave >= E.CFG.AUTOSAVE_SEC) this.saveNow(now);
  }

  /** Crédite une absence de `gapSec` secondes (plafonnée, à rendement réduit). */
  _applyOffline(gapSec, now) {
    var E = this.E, st = this.state;
    var secs = Math.min(gapSec, E.CFG.OFFLINE_MAX_SEC);
    // Bonus permanent « Réacteurs dormants » (Renaissance) + Observatoire(s) stellaire(s) du QG (module 28) :
    // meilleure efficacité hors ligne, jamais au-delà de 100 %.
    var pm = NEBUSTION.PrestigeManager, qm = NEBUSTION.QGGridManager;
    var eff = Math.min(1, E.CFG.OFFLINE_EFFICIENCY + ((pm && pm.bonusValue) ? pm.bonusValue('offlineEff') : 0) + (qm ? qm.bonusValue('offlineEff') : 0));
    var rates = this.rates();
    var gains = {}, lost = {};
    E.ORDER.forEach((id) => {
      var raw = rates[id] * secs * eff;
      var added = this._add(id, raw, 'offline', null, false, now);
      gains[id] = added;
      lost[id] = Math.max(0, raw - added);
    });
    st.stats.offlineSec += secs;
    st.lastSeen = now;
    this.sessionStart = now;   // la fenêtre des « gains récents » repart de zéro au retour
    if (gapSec >= E.CFG.OFFLINE_REPORT_MIN_SEC) {
      var prev = this.pendingReport;
      var report = {
        seconds: gapSec, credited: secs, efficiency: eff, at: now,
        truncated: gapSec > E.CFG.OFFLINE_MAX_SEC, gains: gains, lost: lost
      };
      if (prev) {   // deux absences non affichées : on additionne
        report.seconds += prev.seconds; report.credited += prev.credited;
        report.truncated = report.truncated || prev.truncated;
        E.ORDER.forEach(function (id) { report.gains[id] += prev.gains[id]; report.lost[id] += prev.lost[id]; });
      }
      this.pendingReport = report;
      this.saveNow(now);
      this.emit('offline', report);
    } else {
      this.saveNow(now);
    }
    return this.pendingReport;
  }

  /** Récupère (et efface) le rapport d'absence à afficher. Un seul appelant le reçoit : pas de doublon. */
  consumeOfflineReport() {
    var r = this.pendingReport;
    this.pendingReport = null;
    return r;
  }

  // ---------- Récolte manuelle ----------
  /** Charges disponibles d'un gisement (0..MAX, fractionnaire : se recharge avec le temps). */
  charges(id, now) {
    var n = this.state.nodes[id], E = this.E;
    var c = n.ch + Math.max(0, (now || Date.now()) - n.t) / 1000 / E.CFG.CHARGE_REGEN_SEC;
    return Math.min(E.CFG.MAX_CHARGES, Math.max(0, c));
  }

  /** Un tap sur un gisement. @returns {{ok:boolean, reason?:string, amount?:number, crit?:boolean}} */
  tap(id, now) {
    var E = this.E;
    if (!E.RES[id]) return { ok: false, reason: 'invalid' };
    now = now || Date.now();
    var charges = this.charges(id, now);
    if (charges < 1 - 1e-9) return { ok: false, reason: 'empty', wait: (1 - charges) * E.CFG.CHARGE_REGEN_SEC };
    if (this.isFull(id)) { this.emit('full', { id: id }); return { ok: false, reason: 'full' }; }
    var crit = this.rng() < E.CFG.CRIT_CHANCE;
    var y = E.tapYield(id, this.extractorLevel(id)) * (crit ? E.CFG.CRIT_MULT : 1);
    var added = this._add(id, y, 'tap', { crit: crit }, true, now);
    var n = this.state.nodes[id];
    n.ch = charges - 1;
    n.t = now;
    this.state.stats.taps += 1;
    if (crit) this.state.stats.crits += 1;
    return { ok: true, amount: added, requested: y, crit: crit, charges: n.ch };
  }

  // ---------- Caisses de ravitaillement ----------
  claimPod(now) {
    now = now || Date.now();
    var picks = this.E.rollPodReward(this.rates(), this.rng);
    var results = picks.map((p) => ({ id: p.id, requested: p.amount, amount: this._add(p.id, p.amount, 'pod', null, true, now) }));
    this.state.stats.pods += 1;
    this.state.stats.lastPod = now;
    this.saveNow(now);
    return results;
  }
  markPod(now) { this.state.stats.lastPod = now || Date.now(); }

  // ---------- Bâtiments (API prête pour l'étape suivante) ----------
  /** Paie et applique une amélioration. @returns {{ok:boolean, reason?:string, level?:number, cost?:object}} */
  upgradeBuilding(bid) {
    var E = this.E, def = E.BUILDINGS[bid];
    if (!def) return { ok: false, reason: 'unknown' };
    var b = this.state.buildings[bid];
    if (b.level >= E.CFG.MAX_LEVEL) return { ok: false, reason: 'max' };
    var cost = E.upgradeCost(bid, b.level);
    if (!this.spendMany(cost)) return { ok: false, reason: 'cost', cost: cost };
    b.level += 1;
    this._rates = null;
    this.saveNow(Date.now());
    this.emit('upgrade', { id: bid, level: b.level, cost: cost });
    return { ok: true, level: b.level, cost: cost };
  }
  /** Ajoute un drone minier sur une ressource (le coût sera géré par le Hangar à l'étape suivante). */
  addDrone(id) {
    if (!this.E.RES[id] || this.state.drones[id] >= this.E.CFG.MAX_DRONES) return false;
    this.state.drones[id] += 1;
    this._rates = null;
    this.saveNow(Date.now());
    return true;
  }

  // ---------- Gains récents (fenêtre glissante de 60 s) ----------
  _resetBuckets() {
    this._buckets = {};
    var self = this;
    this.E.ORDER.forEach(function (id) { self._buckets[id] = new Array(60).fill(0); });
    this._bucketSec = 0;
  }
  _advance(sec) {
    if (!this._bucketSec) { this._bucketSec = sec; return; }
    var d = sec - this._bucketSec;
    if (d <= 0) return;
    var self = this;
    if (d >= 60) { this._resetBuckets(); this._bucketSec = sec; return; }
    for (var k = 1; k <= d; k++) {
      var idx = (this._bucketSec + k) % 60;
      self.E.ORDER.forEach(function (id) { self._buckets[id][idx] = 0; });
    }
    this._bucketSec = sec;
  }
  _bucketAdd(id, amount, now) {
    var sec = Math.floor(now / 1000);
    this._advance(sec);
    this._buckets[id][sec % 60] += amount;
  }
  /** Total réellement gagné sur la fenêtre récente + durée couverte (≤ 60 s). */
  recent(id, now) {
    this._advance(Math.floor((now || Date.now()) / 1000));
    var sum = 0, b = this._buckets[id];
    for (var i = 0; i < 60; i++) sum += b[i];
    var covered = Math.min(60, Math.max(0, ((now || Date.now()) - this.sessionStart) / 1000));
    return { total: sum, seconds: covered };
  }

  // ---------- Sauvegarde ----------
  _dirtyNow() { this._sinceSave = Math.max(this._sinceSave, this.E.CFG.AUTOSAVE_SEC - 1); }
  /** Verrouille toute sauvegarde locale (restauration du compte en cours : l'état en mémoire est périmé et ne doit
   *  surtout pas réécrire la sauvegarde restaurée à la fermeture/au rechargement de la page). */
  lockSaves() { this.saveLocked = true; }
  saveNow(now) {
    if (!this.state || this.saveLocked) return false;
    now = now || Date.now();
    this.state.savedAt = now;
    this.state.lastSeen = now;
    this.state.sid = this.sid;
    this.lastSaveOk = this.S.write(this.state, now);
    this.lastSaveAt = now;
    this._sinceSave = 0;
    this.emit('saved', { ok: this.lastSaveOk });
    return this.lastSaveOk;
  }
  reset(now) {
    now = now || Date.now();
    this.S.wipe();
    this.state = this.S.normalize(null, now);
    this.state.sid = this.sid;
    this.pendingReport = null;
    this.lastTick = now;
    this.sessionStart = now;
    this._rates = null;
    this._resetBuckets();
    this.saveNow(now);
    this.emit('reset', {});
  }

  /** Outil de test : simule `sec` secondes d'absence (crédité au prochain tick, fenêtre « bon retour » incluse). */
  debugAway(sec) { this.lastTick -= Math.max(0, Number(sec) || 0) * 1000; }
};

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.ResourceManager; }
