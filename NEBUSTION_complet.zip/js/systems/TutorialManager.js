/**
 * NEBUSTION - TutorialManager
 * Tutoriel d'accueil : suite de cartes expliquant le jeu (ressources, bâtiments, galaxie/héros/combat, nouveau
 * menu latéral, Pass de saison / Pass Doré). Affiché automatiquement une seule fois (à la première visite de
 * l'accueil), puis rejouable à volonté depuis les Paramètres (bouton « Revoir le tutoriel »).
 * État dans NEBUSTION.Resources.state.tutorial = { v, done } (couvert par la sauvegarde automatique).
 * Le rendu est dans js/ui/TutorialOverlay.js ; ici uniquement les données et l'état (aucune dépendance Phaser).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.TutorialManager = (function () {
  'use strict';

  var VERSION = 1;
  var fallback = null;   // état de secours quand l'économie n'est pas chargée (tests isolés)

  // spot : 'nav' = l'écran met en évidence l'onglet du menu latéral (voir TutorialOverlay)
  var STEPS = [
    { id: 'welcome', icon: '🪐', title: 'Bienvenue sur Nebustion', text: 'Vous dirigez la base spatiale Nexus-01. Développez-la, recrutez des héros et explorez la galaxie. Ce petit guide vous montre l\'essentiel en quelques cartes.' },
    { id: 'resources', icon: '💎', title: 'Récolter des ressources', text: 'Touchez les gisements de la planète pour récolter. Les ressources arrivent aussi toutes seules, même quand vous êtes hors ligne : pensez à revenir les collecter, votre stockage est limité.' },
    { id: 'build', icon: '🏗️', title: 'Améliorer vos bâtiments', text: 'Dépensez vos ressources pour améliorer les bâtiments : plus de production, plus de stockage, de nouvelles capacités. Chaque amélioration fait aussi progresser vos missions.' },
    { id: 'explore', icon: '🌌', title: 'Galaxie, héros et combat', text: 'Explorez la galaxie depuis l\'accueil, recrutez et faites monter vos héros avec des fragments, puis préparez vos troupes pour les combats. Les raccourcis colorés de l\'accueil vous mènent aux expéditions, événements, prestige et succès.' },
    { id: 'menu', icon: '☰', title: 'Votre nouveau menu', spot: 'nav', text: 'La barre du bas a laissé place à un onglet sur le bord droit de l\'écran. Touchez-le pour ouvrir la liste des sections (Planète, Galaxie, Héros, Combat, Boutique, Pass) : il est toujours là, sans jamais gêner.' },
    { id: 'pass', icon: '👑', title: 'Pass de saison et Pass Doré', text: 'Les missions du jour et de la semaine donnent de l\'XP Pass : 30 niveaux de récompenses gratuites. Le Premium ajoute une piste de bonus ; le Pass Doré, au-dessus, offre coffrets cosmiques et skins exclusifs.' },
    { id: 'go', icon: '🚀', title: 'À vous de jouer !', text: 'Vous pouvez rouvrir ce tutoriel à tout moment depuis les Paramètres (roue dentée), bouton « Revoir le tutoriel ». Bon voyage, commandant !' }
  ];

  function defaultState() { return { v: VERSION, done: false }; }
  function normalizeState(raw) {
    var s = defaultState();
    if (raw && typeof raw === 'object') s.done = raw.done === true;
    return s;
  }

  function root() { return NEBUSTION.Resources && NEBUSTION.Resources.state; }
  function state() {
    var r = root(), cur = r ? r.tutorial : fallback;
    if (!cur || typeof cur !== 'object' || cur.v !== VERSION) {
      cur = normalizeState(cur);
      if (r) r.tutorial = cur; else fallback = cur;
    }
    return cur;
  }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }

  function steps() { return STEPS.slice(); }
  function isDone() { return state().done === true; }
  function shouldShow() { return !isDone(); }
  function markDone() { state().done = true; save(); }
  /** Réinitialise (pour « Revoir le tutoriel ») : le tutoriel sera de nouveau considéré comme non terminé. */
  function reset() { state().done = false; save(); }
  function _reset() { fallback = null; }

  return { STEPS: STEPS, steps: steps, defaultState: defaultState, normalizeState: normalizeState, state: state, isDone: isDone, shouldShow: shouldShow, markDone: markDone, reset: reset, _reset: _reset };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.TutorialManager; }
