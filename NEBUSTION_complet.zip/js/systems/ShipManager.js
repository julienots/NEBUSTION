/**
 * NEBUSTION - ShipManager
 * Glue entre NEBUSTION.Ships (données pures) et la sauvegarde/économie existantes,
 * suivant exactement le même schéma que EquipmentManager. État dans
 * NEBUSTION.Resources.state.ships (couvert par la sauvegarde automatique déjà en place).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.ShipManager = (function () {
  'use strict';

  var S = function () { return NEBUSTION.Ships; };
  var root = function () { return NEBUSTION.Resources && NEBUSTION.Resources.state; };

  function state() {
    var r = root();
    if (!r) return S().defaultState();
    if (!r.ships) r.ships = S().normalizeState(null);
    return r.ships;
  }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }

  // ---------- Hangar ----------
  function list() {
    var s = state();
    return Object.keys(s.ships).map(function (uid) { return Object.assign({ uid: uid }, s.ships[uid]); });
  }

  function get(uid) {
    var s = state();
    return s.ships[uid] ? Object.assign({ uid: uid }, s.ships[uid]) : null;
  }

  function getFleet() { return state().fleet.slice(); }
  function isInFleet(uid) { return state().fleet.indexOf(uid) >= 0; }

  // ---------- Acquisition ----------
  function acquire(classId, rarityId) {
    var Sh = S();
    if (Sh.CLASS_ORDER.indexOf(classId) < 0 || !Sh.RARITIES[rarityId]) return { ok: false, reason: 'invalide' };
    var cost = Sh.acquireCost(rarityId);
    if (!NEBUSTION.Resources.canAfford(cost)) return { ok: false, reason: 'ressources' };
    NEBUSTION.Resources.spendMany(cost);
    var s = state();
    var uid = 'sh' + (s.nextSeq++);
    s.ships[uid] = { classId: classId, rarity: rarityId, level: 1 };
    save();
    return { ok: true, uid: uid, ship: get(uid) };
  }

  // ---------- Amélioration ----------
  function upgrade(uid) {
    var Sh = S();
    var s = state();
    var sh = s.ships[uid];
    if (!sh) return { ok: false, reason: 'invalide' };
    if (sh.level >= Sh.MAX_LEVEL) return { ok: false, reason: 'niveau_max' };
    var cost = Sh.upgradeCost(sh.rarity, sh.level);
    if (!NEBUSTION.Resources.canAfford(cost)) return { ok: false, reason: 'ressources' };
    NEBUSTION.Resources.spendMany(cost);
    sh.level += 1;
    save();
    return { ok: true, ship: get(uid) };
  }

  // ---------- Sélection de la flotte (avant combat) ----------
  function setFleet(uids) {
    var Sh = S();
    var s = state();
    var clean = (uids || []).filter(function (uid) { return !!s.ships[uid]; }).slice(0, Sh.FLEET_MAX);
    // Retire les doublons en conservant la première occurrence.
    var seen = {};
    clean = clean.filter(function (uid) { if (seen[uid]) return false; seen[uid] = true; return true; });
    s.fleet = clean;
    save();
    return s.fleet.slice();
  }

  function toggleFleet(uid) {
    var Sh = S();
    var s = state();
    if (!s.ships[uid]) return getFleet();
    var idx = s.fleet.indexOf(uid);
    if (idx >= 0) { s.fleet.splice(idx, 1); }
    else if (s.fleet.length < Sh.FLEET_MAX) { s.fleet.push(uid); }
    save();
    return s.fleet.slice();
  }

  // ---------- Bonus de flotte (appliqué à toute l'équipe de héros en combat) ----------
  /** Bonus cumulé en pourcentage {hpPct,atkPct,defPct,spdPct} de la flotte actuelle (0 si vide). */
  function fleetBonus() {
    var Sh = S();
    var out = { hpPct: 0, atkPct: 0, defPct: 0, spdPct: 0 };
    var map = { hp: 'hpPct', atk: 'atkPct', def: 'defPct', spd: 'spdPct' };
    getFleet().forEach(function (uid) {
      var sh = get(uid);
      if (!sh) return;
      var b = Sh.bonusFor(sh.classId, sh.rarity, sh.level);
      Object.keys(b).forEach(function (stat) { out[map[stat]] = (out[map[stat]] || 0) + b[stat]; });
    });
    return out;
  }

  // ---------- Puissance d'attaque de la flotte (module 17, attaques du QG ennemi) ----------
  /** Somme de la puissance d'attaque des vaisseaux actuellement dans la flotte (0 si vide). */
  function fleetPower() {
    var Sh = S();
    return getFleet().reduce(function (sum, uid) {
      var sh = get(uid);
      return sh ? sum + Sh.attackPower(sh.classId, sh.rarity, sh.level) : sum;
    }, 0);
  }

  return {
    list: list, get: get, getFleet: getFleet, isInFleet: isInFleet,
    acquire: acquire, upgrade: upgrade, setFleet: setFleet, toggleFleet: toggleFleet,
    fleetBonus: fleetBonus, fleetPower: fleetPower
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.ShipManager; }
