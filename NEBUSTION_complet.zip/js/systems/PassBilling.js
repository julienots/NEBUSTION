/**
 * NEBUSTION - PassBilling
 * Point d'extension pour les ACHATS INTÉGRÉS ANDROID du Pass Premium.
 *
 * ⚠ AUCUN PAIEMENT N'EST IMPLÉMENTÉ NI SIMULÉ ICI. Le fournisseur par défaut (« none ») est indisponible :
 * toute tentative d'achat renvoie { ok:false, reason:'billing_unavailable' } et n'active RIEN.
 * Le Premium ne peut être activé que par PassManager.grantPremium(), appelé UNIQUEMENT ici, après qu'un
 * fournisseur réel a confirmé un achat.
 *
 * Pour brancher Google Play Billing plus tard (aucun autre fichier à modifier) :
 *   NEBUSTION.PassBilling.registerProvider({
 *     id: 'google_play',
 *     isAvailable: function () { ... },                       // true seulement dans l'app installée depuis Google Play
 *     getProduct: function (sku) { return Promise.resolve({ sku, title, price }); },   // prix localisé fourni par Google
 *     purchase: function (sku) { return Promise.resolve({ ok: true, token: '...' }); }, // ou { ok:false, reason:'annule'|'erreur' }
 *     restore: function () { return Promise.resolve({ ok: true, skus: ['nebustion_pass_premium_s1'] }); }
 *   });
 * Pistes d'intégration : Trusted Web Activity + Digital Goods API / Payment Request (Play Billing), ou un plugin
 * Capacitor. Recommandé : valider le jeton d'achat côté serveur (Google Play Developer API) et l'acquitter
 * (acknowledge) avant d'appeler grantPremium ; ici le jeu est 100 % hors ligne, donc sans validation serveur
 * la sauvegarde locale reste modifiable par le joueur.
 * Un SKU par saison : « nebustion_pass_premium_s<N> » (voir skuForSeason) ; le Premium expire avec la saison.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.PassBilling = (function () {
  'use strict';

  var SKU_PREFIX = 'nebustion_pass_premium_s';
  var REQUIRED = ['isAvailable', 'getProduct', 'purchase', 'restore'];

  var NullProvider = {
    id: 'none',
    isAvailable: function () { return false; },
    getProduct: function () { return Promise.resolve(null); },
    purchase: function () { return Promise.resolve({ ok: false, reason: 'billing_unavailable' }); },
    restore: function () { return Promise.resolve({ ok: false, reason: 'billing_unavailable' }); }
  };
  var provider = NullProvider;

  function skuForSeason(seasonNumber) { return SKU_PREFIX + Math.max(1, Math.floor(seasonNumber) || 1); }

  function registerProvider(p) {
    if (!p || typeof p !== 'object' || typeof p.id !== 'string') return false;
    for (var i = 0; i < REQUIRED.length; i++) if (typeof p[REQUIRED[i]] !== 'function') return false;
    provider = p;
    return true;
  }
  function resetProvider() { provider = NullProvider; }
  function providerId() { return provider.id; }
  function isAvailable() { try { return !!provider.isAvailable(); } catch (e) { return false; } }

  /** Lance l'achat du Premium de la saison en cours ; n'active le Premium que si le fournisseur confirme. */
  function purchasePremium() {
    var PM = NEBUSTION.PassManager;
    if (!PM) return Promise.resolve({ ok: false, reason: 'indisponible' });
    if (PM.isPremium()) return Promise.resolve({ ok: false, reason: 'deja' });
    if (!isAvailable()) return Promise.resolve({ ok: false, reason: 'billing_unavailable' });
    var sku = skuForSeason(PM.season().number);
    return Promise.resolve().then(function () { return provider.purchase(sku); }).then(function (res) {
      if (res && res.ok === true) {
        PM.grantPremium({ source: provider.id, sku: sku, token: res.token || null });
        return { ok: true, sku: sku };
      }
      return { ok: false, reason: (res && res.reason) || 'erreur' };
    }, function () { return { ok: false, reason: 'erreur' }; });
  }

  /** Restaure un achat déjà effectué (changement d'appareil) — même règle : rien n'est activé sans confirmation du fournisseur. */
  function restore() {
    var PM = NEBUSTION.PassManager;
    if (!PM || !isAvailable()) return Promise.resolve({ ok: false, reason: 'billing_unavailable' });
    var sku = skuForSeason(PM.season().number);
    return Promise.resolve().then(function () { return provider.restore(); }).then(function (res) {
      if (res && res.ok === true && Array.isArray(res.skus) && res.skus.indexOf(sku) >= 0) {
        PM.grantPremium({ source: provider.id, sku: sku, token: null });
        return { ok: true, sku: sku };
      }
      return { ok: false, reason: 'rien' };
    }, function () { return { ok: false, reason: 'erreur' }; });
  }

  // ---------- Paiement en ressources du jeu (provisoire, en attendant Google Play) ----------
  // Ce n'est PAS un paiement réel : le Premium de la saison en cours s'obtient contre des ressources (une fois par saison, comme le SKU).
  // Montants dans la capacité de stockage de base (cristaux 15 000, métal 12 000, énergie 6 000, noyaux 300, poussière 30 000).
  var RESOURCE_PRICE = { crystal: 8000, metal: 6000, energy: 3000, core: 60, dust: 15000 };
  function resourcePrice() { return Object.assign({}, RESOURCE_PRICE); }
  function canPayWithResources() {
    var R = NEBUSTION.Resources;
    return !!(R && R.canAfford(RESOURCE_PRICE));
  }
  /** Débite les ressources (atomique : tout ou rien) puis active le Premium. { ok } ou { ok:false, reason:'deja'|'ressources'|'indisponible' }. */
  function payWithResources() {
    var PM = NEBUSTION.PassManager, R = NEBUSTION.Resources;
    if (!PM || !R) return { ok: false, reason: 'indisponible' };
    if (PM.isPremium()) return { ok: false, reason: 'deja' };
    if (!R.spendMany(RESOURCE_PRICE)) return { ok: false, reason: 'ressources' };
    PM.grantPremium({ source: 'resources', sku: skuForSeason(PM.season().number), token: null });
    return { ok: true, price: resourcePrice() };
  }

  return {
    skuForSeason: skuForSeason, registerProvider: registerProvider, resetProvider: resetProvider,
    providerId: providerId, isAvailable: isAvailable, purchasePremium: purchasePremium, restore: restore,
    resourcePrice: resourcePrice, canPayWithResources: canPayWithResources, payWithResources: payWithResources
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.PassBilling; }
