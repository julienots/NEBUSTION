/**
 * NEBUSTION - CloudSave
 * Système de compte (e-mail/mot de passe, via Firebase Auth) + sauvegarde en ligne (Firestore),
 * pour que la progression existe toujours (nouvel appareil, réinstallation, changement de
 * téléphone). Entièrement OPTIONNEL et sans dépendance dure :
 *  - si Firebase n'a pas pu se charger (pas de réseau, bloqueur...) ou si js/data/FirebaseConfig.js
 *    n'a pas été rempli, isConfigured()/init() renvoient false et le jeu continue en local
 *    uniquement, exactement comme avant (voir SaveManager.js) ;
 *  - aucune donnée n'est jamais envoyée sans qu'un compte soit connecté.
 *
 * La sauvegarde envoyée en ligne est le même objet d'état que SaveManager (js/systems/SaveManager.js) :
 * aucun format supplémentaire à maintenir. Firestore stocke un document JSON par joueur,
 * à l'emplacement saves/{uid}, protégé par des règles qui n'autorisent que son propriétaire
 * (voir js/data/FirebaseConfig.js pour les règles à publier).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.CloudSave = (function () {
  'use strict';

  var app = null, auth = null, db = null;
  var ready = false;              // SDK Firebase chargé + configuré + initialisé avec succès
  var user = null;                // { uid, email } ou null (invité / déconnecté)
  var authListeners = [];
  var PUSH_MIN_INTERVAL_MS = 20000;   // au plus une écriture Firestore toutes les 20 s (sauf push forcé)
  var lastPushAt = 0;
  var pushTimer = null;
  // --- Garde-fous anti-perte (voir sync()) ---
  var gateOpen = false;           // les envois automatiques ne partent qu'après une réconciliation réussie avec le compte
  var pendingConflict = null;     // sauvegarde du compte en attente d'un choix du joueur (ou null)
  var known = 0;                  // savedAt de la dernière version du compte que CET appareil a vue/envoyée
  var TOL_MS = 2000;
  var MAX_DOC_CHARS = 900000;     // limite Firestore = 1 Mo par document
  var lastSync = { at: 0, ok: null, error: null };
  var conflictListeners = [];
  var deviceId = (function () {   // identifiant d'appareil (partagé entre onglets) pour détecter un 2e appareil qui joue en parallèle
    try {
      var k = 'nebustion_device_id', v = window.localStorage.getItem(k);
      if (!v) { v = 'd' + Math.random().toString(36).slice(2) + Date.now().toString(36); window.localStorage.setItem(k, v); }
      return v;
    } catch (e) { return 'd' + Math.random().toString(36).slice(2) + Date.now().toString(36); }
  })();

  function isConfigured() {
    var c = NEBUSTION.FirebaseConfig;
    return !!(c && c.apiKey && c.projectId && String(c.apiKey).indexOf('REMPLACE_MOI') === -1);
  }

  /** À appeler une fois au démarrage (main.js). Ne lève jamais d'exception. */
  function init() {
    if (ready) return true;
    if (typeof firebase === 'undefined') return false;   // SDK non chargé (hors ligne, bloqueur...)
    if (!isConfigured()) return false;                    // js/data/FirebaseConfig.js pas encore rempli
    try {
      app = firebase.initializeApp(NEBUSTION.FirebaseConfig);
      auth = firebase.auth();
      db = firebase.firestore();
      auth.onAuthStateChanged(function (u) {
        user = u ? { uid: u.uid, email: u.email } : null;
        try {
          if (user) window.localStorage.setItem('nebustion_last_account_email', user.email || '');
          else window.localStorage.removeItem('nebustion_last_account_email');
        } catch (e) { /* ignore */ }
        authListeners.slice().forEach(function (fn) { try { fn(user); } catch (e) { /* ignore */ } });
      });
      ready = true;
    } catch (e) {
      console.error('NEBUSTION CloudSave: initialisation impossible', e);
      ready = false;
    }
    return ready;
  }

  /** S'abonne aux changements d'état de connexion ; appelle fn(user|null) à l'inscription ET à chaque changement. */
  function onAuthChange(fn) {
    authListeners.push(fn);
    return function () { var i = authListeners.indexOf(fn); if (i >= 0) authListeners.splice(i, 1); };
  }

  function currentUser() { return user; }
  function isReady() { return ready; }
  /** Dernier compte connecté sur cet appareil (survit à une session hors ligne où Firebase
   *  n'a pas pu charger : voir index.html/loadFirebase). Purement informatif pour l'affichage
   *  (« Connecté (hors ligne) ») ; ne permet jamais d'accéder aux données du compte sans réseau. */
  function lastKnownEmail() { try { return window.localStorage.getItem('nebustion_last_account_email') || null; } catch (e) { return null; } }

  // ---------- Messages d'erreur Firebase → français ----------
  function friendlyError(err) {
    var code = err && err.code;
    var map = {
      'auth/invalid-email': 'Adresse e-mail invalide.',
      'auth/missing-email': 'Adresse e-mail manquante.',
      'auth/email-already-in-use': 'Un compte existe déjà avec cet e-mail.',
      'auth/weak-password': 'Mot de passe trop court (6 caractères minimum).',
      'auth/user-not-found': 'Aucun compte avec cet e-mail.',
      'auth/wrong-password': 'Mot de passe incorrect.',
      'auth/invalid-credential': 'E-mail ou mot de passe incorrect.',
      'auth/invalid-login-credentials': 'E-mail ou mot de passe incorrect.',
      'auth/too-many-requests': 'Trop de tentatives : réessaie dans quelques minutes.',
      'auth/network-request-failed': 'Pas de connexion internet.'
    };
    return (code && map[code]) || (err && err.message) || 'Une erreur est survenue.';
  }

  // ---------- Authentification ----------
  function signUp(email, pass) {
    if (!ready) return Promise.reject(new Error('Firebase non configuré'));
    return auth.createUserWithEmailAndPassword(email, pass).catch(function (e) { throw new Error(friendlyError(e)); });
  }
  function signIn(email, pass) {
    if (!ready) return Promise.reject(new Error('Firebase non configuré'));
    return auth.signInWithEmailAndPassword(email, pass).catch(function (e) { throw new Error(friendlyError(e)); });
  }
  function signOut() {
    if (!ready) { try { window.localStorage.removeItem('nebustion_last_account_email'); } catch (e) { /* ignore */ } return Promise.resolve(); }
    gateOpen = false; pendingConflict = null; known = 0;
    if (pushTimer) { clearTimeout(pushTimer); pushTimer = null; }
    return auth.signOut();
  }
  function resetPassword(email) {
    if (!ready) return Promise.reject(new Error('Firebase non configuré'));
    return auth.sendPasswordResetEmail(email).catch(function (e) { throw new Error(friendlyError(e)); });
  }

  // ---------- Sauvegarde en ligne (Firestore) ----------
  function docRef() { return db.collection('saves').doc(user.uid); }

  function parseDoc(d) {
    if (!d || typeof d.data !== 'string') return null;
    try { return JSON.parse(d.data); } catch (e) { return null; }
  }

  function enterConflict(cloudState) {
    gateOpen = false;
    if (pushTimer) { clearTimeout(pushTimer); pushTimer = null; }
    pendingConflict = cloudState || null;
    conflictListeners.slice().forEach(function (fn) { try { fn(pendingConflict); } catch (e) { /* ignore */ } });
  }

  /** Envoie l'état actuel vers Firestore. Limité à un envoi/20s (sauf {force:true}) ; ne part que si la garde est
   *  ouverte (réconciliation faite, voir sync()) sauf {override:true}. Écriture en transaction : si un AUTRE appareil
   *  a enregistré une version plus récente entre-temps, rien n'est écrasé → conflit signalé au joueur. */
  function pushSave(state, opts) {
    opts = opts || {};
    if (!ready || !user || !state) return Promise.resolve(false);
    if (!gateOpen && !opts.override) return Promise.resolve(false);
    var now = Date.now();
    if (!opts.force && !opts.override && now - lastPushAt < PUSH_MIN_INTERVAL_MS) {
      if (pushTimer) clearTimeout(pushTimer);
      pushTimer = setTimeout(function () { pushTimer = null; pushSave(state, { force: true }); }, PUSH_MIN_INTERVAL_MS - (now - lastPushAt));
      return Promise.resolve(false);
    }
    if (pushTimer) { clearTimeout(pushTimer); pushTimer = null; }
    lastPushAt = now;
    var payload;
    try { payload = { data: JSON.stringify(state), v: state.v || 0, savedAt: state.savedAt || now, updatedAt: now, by: deviceId }; }
    catch (e) { return Promise.resolve(false); }
    if (payload.data.length > MAX_DOC_CHARS) {
      lastSync = { at: now, ok: false, error: 'Sauvegarde trop volumineuse' };
      console.error('NEBUSTION CloudSave: sauvegarde trop volumineuse pour Firestore');
      return Promise.resolve(false);
    }
    var ref = docRef();
    return db.runTransaction(function (tx) {
      return tx.get(ref).then(function (snap) {
        if (!opts.override && snap && snap.exists) {
          var d = snap.data();
          if (d && d.by && d.by !== deviceId && (d.savedAt || 0) > known + TOL_MS) return { conflict: true, cloud: parseDoc(d) };
        }
        tx.set(ref, payload);
        return { conflict: false };
      });
    }).then(function (res) {
      if (res && res.conflict) { enterConflict(res.cloud); return false; }
      known = Math.max(known, payload.savedAt);
      lastSync = { at: Date.now(), ok: true, error: null };
      return true;
    }).catch(function (e) {
      lastSync = { at: Date.now(), ok: false, error: friendlyError(e) };
      console.error('NEBUSTION CloudSave: envoi impossible', e);
      return false;
    });
  }

  /** Lit la sauvegarde du compte. @returns {Promise<{status:'ok'|'none'|'error', state:object|null, savedAt:number}>}
   *  ('none' = le compte n'a pas encore de sauvegarde ; 'error' = lecture impossible, à ne JAMAIS confondre avec 'none'). */
  function fetchCloud() {
    if (!ready || !user) return Promise.resolve({ status: 'error', state: null, savedAt: 0 });
    return docRef().get().then(function (snap) {
      if (!snap || !snap.exists) return { status: 'none', state: null, savedAt: 0 };
      var d = snap.data(), st = parseDoc(d);
      if (!st) return { status: 'error', state: null, savedAt: 0 };   // document illisible : on ne l'écrase pas
      return { status: 'ok', state: st, savedAt: Number(d.savedAt) || Number(st.savedAt) || 0 };
    }).catch(function (e) {
      lastSync = { at: Date.now(), ok: false, error: friendlyError(e) };
      console.error('NEBUSTION CloudSave: lecture impossible', e);
      return { status: 'error', state: null, savedAt: 0 };
    });
  }

  /** Compatibilité : état brut du compte ou null. */
  function pullSave() { return fetchCloud().then(function (r) { return r.state; }); }

  /** Résumé lisible d'une sauvegarde (écran de choix en cas de conflit). */
  function summarize(st) {
    st = st || {};
    var stars = 0, lv = 0, conq = 0, k;
    var ss = (st.combat && st.combat.stageStars) || {};
    for (k in ss) if (Object.prototype.hasOwnProperty.call(ss, k)) stars += Number(ss[k]) || 0;
    var bl = st.buildings || {};
    for (k in bl) if (Object.prototype.hasOwnProperty.call(bl, k)) lv += Number(bl[k] && bl[k].level) || 0;
    if (st.galaxy && st.galaxy.conquered) conq = Object.keys(st.galaxy.conquered).length;
    return { savedAt: Number(st.savedAt) || 0, playSec: Number(st.stats && st.stats.playSec) || 0, stars: stars, buildingLevels: lv, conquered: conq };
  }

  /** Décision pure (testable) : que faire entre la sauvegarde locale et celle du compte ?
   *  local = { createdAt, baseline (savedAt de la dernière sauvegarde locale AVANT cette session), isNew }
   *  @returns 'push' | 'adopt' | 'conflict' */
  function decide(local, cloudRes, atStart) {
    if (!cloudRes || cloudRes.status === 'none') return 'push';
    if (local.isNew) return 'adopt';
    var cst = cloudRes.state || {};
    if (Number(cst.createdAt) !== Number(local.createdAt)) return 'conflict';   // deux parties différentes
    var base = Math.max(Number(local.baseline) || 0, known);
    if (cloudRes.savedAt > base + TOL_MS) return atStart ? 'adopt' : 'conflict';   // le compte a avancé ailleurs
    return 'push';
  }

  function openGate(cloudSavedAt) { gateOpen = true; pendingConflict = null; known = Math.max(known, Number(cloudSavedAt) || 0); }

  /** Remplace la partie locale par celle du compte (l'ancienne est gardée à part : nebustion_save_v2_before_cloud).
   *  Verrouille les sauvegardes locales : sinon la sauvegarde de fermeture du jeu en cours (rechargement) écraserait
   *  aussitôt la sauvegarde restaurée par l'ancien état en mémoire. Le joueur doit recharger la page ensuite. */
  function adopt(cloudState) {
    var now = Date.now(), Sv = NEBUSTION.Save;
    if (pushTimer) { clearTimeout(pushTimer); pushTimer = null; }
    gateOpen = false;
    if (NEBUSTION.Resources && NEBUSTION.Resources.lockSaves) NEBUSTION.Resources.lockSaves();
    try { var cur = window.localStorage.getItem(Sv.KEY); if (cur) window.localStorage.setItem(Sv.KEY + '_before_cloud', cur); } catch (e) { /* ignore */ }
    var n = Sv.normalize(cloudState, now);
    Sv.write(n, now);
    return n;
  }

  /** Réconciliation complète appareil ↔ compte. À appeler à la connexion et au démarrage (session déjà ouverte).
   *  opts = { baseline, isNew, atStart }. Ne perd jamais de progression en silence :
   *   'pushed' (la garde s'ouvre, l'appareil est envoyé) | 'adopted' (compte restauré, recharger la page)
   *   | 'conflict' (choix du joueur requis, rien n'est écrasé ; voir keepLocal/useCloud) | 'error' (lecture impossible, garde fermée). */
  function sync(state, opts) {
    opts = opts || {};
    if (!ready || !user || !state) return Promise.resolve({ action: 'error' });
    return fetchCloud().then(function (res) {
      if (res.status === 'error') return { action: 'error' };
      var d = decide({ createdAt: state.createdAt, baseline: opts.baseline, isNew: !!opts.isNew }, res, !!opts.atStart);
      if (d === 'push') {
        openGate(res.savedAt);
        return pushSave(state, { override: true }).then(function (ok) { return { action: ok ? 'pushed' : 'error' }; });
      }
      if (d === 'adopt') { adopt(res.state); return { action: 'adopted', cloud: res.state }; }
      enterConflict(res.state);
      return { action: 'conflict', cloud: res.state };
    });
  }

  /** Conflit résolu : on garde la partie de cet appareil et on écrase celle du compte. */
  function keepLocal(state) {
    var c = pendingConflict;
    openGate(c ? (Number(c.savedAt) || 0) : 0);
    return pushSave(state, { override: true });
  }
  /** Conflit résolu : on prend la partie du compte (voir adopt()). */
  function useCloud() { var c = pendingConflict; if (!c) return null; pendingConflict = null; return adopt(c); }

  /** Sauvegarde automatique en ligne : envoi périodique (même si aucun événement de sauvegarde locale ne part),
   *  reprise dès le retour du réseau après un échec, et envoi immédiat sur demande (autoSave.now()).
   *  getState() renvoie l'état courant. Sans effet tant que la garde est fermée ou qu'aucun compte n'est connecté. */
  function startAutoSave(getState, opts) {
    opts = opts || {};
    var every = opts.everyMs || 30000, timer = null;
    function tick() {
      if (!ready || !user || !gateOpen) return Promise.resolve(false);
      return pushSave(getState(), { force: true });
    }
    function onOnline() { if (lastSync.ok === false) tick(); }
    timer = setInterval(tick, every);
    if (typeof window.addEventListener === 'function') window.addEventListener('online', onOnline);
    return {
      now: tick,
      stop: function () { clearInterval(timer); if (typeof window.removeEventListener === 'function') window.removeEventListener('online', onOnline); }
    };
  }

  function onConflict(fn) {
    conflictListeners.push(fn);
    return function () { var i = conflictListeners.indexOf(fn); if (i >= 0) conflictListeners.splice(i, 1); };
  }

  return {
    init: init, isConfigured: isConfigured, isReady: isReady,
    onAuthChange: onAuthChange, currentUser: currentUser, lastKnownEmail: lastKnownEmail,
    signUp: signUp, signIn: signIn, signOut: signOut, resetPassword: resetPassword,
    pushSave: pushSave, pullSave: pullSave, fetchCloud: fetchCloud,
    sync: sync, decide: decide, adopt: adopt, keepLocal: keepLocal, useCloud: useCloud, summarize: summarize,
    startAutoSave: startAutoSave, onConflict: onConflict, getPendingConflict: function () { return pendingConflict; },
    getLastSync: function () { return { at: lastSync.at, ok: lastSync.ok, error: lastSync.error }; },
    isGateOpen: function () { return gateOpen; },
    /** Envoi immédiat (mise en veille / fermeture) — sans effet si la garde est fermée. */
    flush: function (state) { return pushSave(state, { force: true }); },
    _reset: function () { gateOpen = false; pendingConflict = null; known = 0; lastPushAt = 0; lastSync = { at: 0, ok: null, error: null }; if (pushTimer) { clearTimeout(pushTimer); pushTimer = null; } },
    _deviceId: function () { return deviceId; }
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.CloudSave; }
