/**
 * NEBUSTION - QGRaidManager
 * Glue entre NEBUSTION.QGRaid (données pures) et le reste du jeu :
 *  - mémoire/élan des empires : EmpireEvolutionManager (module IA 3) — LU seulement, jamais modifié ;
 *  - défense du joueur : SecurityManager.effectiveLevel() (niveau manuel + Tourelles de la grille QG) ;
 *  - sauvegarde : NEBUSTION.Resources.state.qgRaid (validé par QGRaid.normalizeState, branché SaveManager).
 *
 * Idempotent, rattrapage hors ligne borné (même patron que EmpireEvolutionManager.update) : recharger
 * la sauvegarde ne rejoue jamais un pas déjà simulé, et ne change jamais un résultat déjà tiré (seed).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.QGRaidManager = (function () {
  'use strict';

  var D = function () { return NEBUSTION.QGRaid; };
  var G = function () { return NEBUSTION.Galaxy; };
  var GM = function () { return NEBUSTION.GalaxyManager; };
  var EM = function () { return NEBUSTION.EmpireEvolutionManager; };
  var SM = function () { return NEBUSTION.SecurityManager; };
  var Econ = function () { return NEBUSTION.Economy; };
  var QGGM = function () { return NEBUSTION.QGGridManager; };

  /** Bouclier du Coffre-fort (0..0.5) : réduit la fraction de ressources réellement perdue lors d'un raid réussi. */
  function raidShield() {
    var qm = QGGM();
    return qm ? Math.min(0.5, qm.bonusValue('raidShield')) : 0;
  }

  var listeners = {};
  function on(evt, fn) { (listeners[evt] = listeners[evt] || []).push(fn); return function () { off(evt, fn); }; }
  function off(evt, fn) { if (listeners[evt]) listeners[evt] = listeners[evt].filter(function (f) { return f !== fn; }); }
  function emit(evt, data) { (listeners[evt] || []).slice().forEach(function (f) { try { f(data); } catch (e) { console.error('QGRaidManager listener', e); } }); }

  function nowOf(now) { return (typeof now === 'number' && isFinite(now)) ? now : Date.now(); }
  function root() { return NEBUSTION.Resources && NEBUSTION.Resources.state; }
  function state(now) {
    var r = root();
    if (!r) return D().defaultState(nowOf(now));
    if (!r.qgRaid) r.qgRaid = D().normalizeState(null, nowOf(now));
    return r.qgRaid;
  }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }
  function ready() { return !!(EM() && G() && GM() && SM()); }

  /** Empires assez développés pour raider, ET encore en jeu (au moins une planète non conquise), triés par élan décroissant. */
  function candidates(now) {
    if (!ready()) return [];
    var es = EM().state(now).e;
    return G().EMPIRE_ORDER.filter(function (eid) {
      var e = es[eid];
      return e && e.evo >= D().MIN_EVO && G().planetsOfEmpire(eid).some(function (p) { return !GM().isConquered(p.id); });
    }).sort(function (a, b) { return (es[b].mom || 0) - (es[a].mom || 0); });
  }

  /** Choisit le raider : parmi les 2 empires les plus motivés, un tirage déterministe tranche (jamais toujours le même). */
  function pickRaider(now, st) {
    var cand = candidates(now);
    if (!cand.length) return null;
    if (cand.length === 1) return cand[0];
    var r = D().rand01(st.seed, st.n, 401);
    return r < 0.7 ? cand[0] : cand[1];
  }

  /** Ressources pillables par un raid : toutes sauf les Noyaux antiques (`core`), laissés intacts. */
  function raidableIds() {
    var E = Econ();
    return E ? E.ORDER.filter(function (id) { return id !== 'core'; }) : [];
  }

  function applyLoss(fraction) {
    var R = NEBUSTION.Resources;
    if (!R || !R.state || !R.state.res) return;
    var real = fraction * (1 - raidShield());
    raidableIds().forEach(function (id) {
      var cur = R.state.res[id] || 0;
      R.state.res[id] = Math.max(0, Math.round(cur * (1 - real) * 100) / 100);
    });
  }

  function attempt(now, st) {
    var eid = pickRaider(now, st);
    if (!eid) return null;
    var es = EM().state(now).e[eid];
    var attack = D().attackPower(es.evo, es.mom || 0, es.hurt || 0);
    var defense = SM().effectiveLevel() + (NEBUSTION.SymbioteManager ? NEBUSTION.SymbioteManager.defense() : 0);
    var rWin = D().rand01(st.seed, st.n, 907);
    var victory = rWin >= D().defenseChance(defense, attack);   // victoire = raid RÉUSSI (l'empire gagne, le joueur perd)
    var entry = { at: now, empire: eid, victory: victory, attack: attack, defense: defense, lossPct: 0 };
    if (victory) {
      var nominal = D().lossFraction(defense, attack);
      entry.lossPct = nominal * (1 - raidShield());
      applyLoss(nominal);
    }
    st.log.push(entry);
    if (st.log.length > D().LOG_MAX) st.log.shift();
    st.lastRaidAt = now;
    return entry;
  }

  /** Avance la simulation jusqu'à `now` (idempotent, rattrapage borné à 24 h). @returns {{steps:number, raids:Array}} */
  function update(now) {
    now = nowOf(now);
    var st = state(now), out = { steps: 0, raids: [] };
    if (!ready()) return out;                                 // modules requis pas encore chargés (tests isolés) : rien à faire
    if (!(now > st.lastAt)) return out;
    var steps = Math.floor((now - st.lastAt) / D().STEP_MS);
    if (steps < 1) return out;
    var n = Math.min(steps, D().MAX_CATCHUP_STEPS);
    out.steps = n;
    for (var i = 0; i < n; i++) {
      st.n += 1;
      var tNow = st.lastAt + (i + 1) * D().STEP_MS;
      if (tNow - st.lastRaidAt < D().MIN_GAP_MS) continue;
      if (D().rand01(st.seed, st.n, 233) >= D().BASE_CHANCE) continue;
      var res = attempt(tNow, st);
      if (res) { out.raids.push(res); emit('raid', res); }
    }
    st.lastAt = st.lastAt + n * D().STEP_MS;
    save();
    return out;
  }

  /** Historique complet (le plus récent en dernier), synchronisé d'abord (jamais une vue périmée). */
  function log(now) { update(nowOf(now)); return state().log.slice(); }

  /** Dernier raid connu, ou null si aucun n'a encore eu lieu. */
  function lastRaid(now) { var l = log(now); return l.length ? l[l.length - 1] : null; }

  /**
   * Raids survenus depuis la dernière consultation (ex. pendant une absence) — consommé UNE SEULE fois,
   * même patron que ResourceManager.consumeOfflineReport(). Renvoie null s'il n'y a rien de neuf.
   */
  function consumeReport(now) {
    now = nowOf(now);
    update(now);
    var st = state(now);
    var unseen = st.log.filter(function (e) { return e.at > st.lastSeenAt; });
    if (!unseen.length) return null;
    st.lastSeenAt = st.log[st.log.length - 1].at;
    save();
    return { raids: unseen };
  }

  /** Menace actuelle, en lecture seule (sans effet) : le raider le plus probable et sa puissance estimée. */
  function threat(now) {
    now = nowOf(now);
    update(now);
    if (!ready()) return null;
    var st = state(now), eid = pickRaider(now, st);
    if (!eid) return null;
    var es = EM().state(now).e[eid];
    return { empire: eid, attack: D().attackPower(es.evo, es.mom || 0, es.hurt || 0) };
  }

  var timer = null;
  /** Démarre le suivi : rattrapage immédiat + un seul minuteur (rappels multiples sans effet). */
  function start(opts) {
    update(Date.now());
    if (!timer && typeof setInterval === 'function') {
      timer = setInterval(function () { update(Date.now()); }, (opts && opts.everyMs) || 60000);
      if (timer && timer.unref) timer.unref();
    }
    return true;
  }
  function stop() { if (timer) { clearInterval(timer); timer = null; } }
  function isRunning() { return !!timer; }

  return {
    on: on, off: off, state: state, update: update, log: log, lastRaid: lastRaid,
    consumeReport: consumeReport, threat: threat, start: start, stop: stop, isRunning: isRunning
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.QGRaidManager; }
