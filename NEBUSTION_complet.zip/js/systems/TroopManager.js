/**
 * NEBUSTION - TroopManager
 * Glue entre NEBUSTION.Troops (données pures) et NEBUSTION.Resources (économie / sauvegarde).
 * État : NEBUSTION.Resources.state.troops = { stock: { id: n }, bought, deployed }.
 * Achat en Caserne (ressources), don de récompense (Pass) via grant(), consommation au déploiement en combat.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.TroopManager = (function () {
  'use strict';

  function D() { return NEBUSTION.Troops; }
  function root() { return NEBUSTION.Resources && NEBUSTION.Resources.state; }
  function state() {
    var r = root();
    if (!r) return D().defaultState();
    if (!r.troops) r.troops = D().defaultState();
    if (!r.troops.upgrades) r.troops.upgrades = {};
    return r.troops;
  }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }

  function hangarLevel() {
    try { return NEBUSTION.Resources.level('hangar'); } catch (e) { return 0; }
  }
  function qgBonus(type) {
    try { var qm = NEBUSTION.QGGridManager; return qm ? qm.bonusValue(type) : 0; } catch (e) { return 0; }
  }
  /** Places d'armée bonus apportées par les Casernes du QG. */
  function armyBonus() { return Math.round(qgBonus('army')); }
  /** Remise sur le prix des troupes apportée par les Ateliers du QG (0..0.5). */
  function discount() { return Math.min(0.5, qgBonus('troopDiscount')); }
  /** Coût réel (remise incluse) de `n` unités : c'est CE prix que la boutique affiche et débite. */
  function cost(id, n) { return D().cost(id, n, discount()); }
  function capacity() { return D().capacity(hangarLevel(), armyBonus()); }
  function used() { return D().usedSpace(state().stock); }
  function free() { return Math.max(0, capacity() - used()); }
  function count(id) { return state().stock[id] || 0; }
  function stock() { return JSON.parse(JSON.stringify(state().stock)); }
  function total() { return Object.keys(state().stock).reduce(function (a, id) { return a + state().stock[id]; }, 0); }

  function canBuy(id, n) {
    var R = NEBUSTION.Resources, t = D().get(id);
    n = Math.max(1, Math.floor(n || 1));
    if (!R || !t) return false;
    if (t.space * n > free()) return false;
    var c = cost(id, n);
    return Object.keys(c).every(function (r) { return R.get(r) >= c[r]; });
  }

  function buy(id, n) {
    var R = NEBUSTION.Resources, t = D().get(id);
    n = Math.max(1, Math.floor(n || 1));
    if (!R || !t) return { ok: false, reason: 'unavailable' };
    if (t.space * n > free()) return { ok: false, reason: 'capacite' };
    var c = cost(id, n);
    if (!R.spendMany(c)) return { ok: false, reason: 'cost', cost: c };
    var s = state();
    s.stock[id] = (s.stock[id] || 0) + n;
    s.bought += n;
    save();
    return { ok: true, cost: c, count: s.stock[id] };
  }

  /** Récompense (Pass, événement…) : ignore la capacité (un cadeau n'est jamais refusé). */
  function grant(id, n) {
    var t = D().get(id);
    n = Math.max(1, Math.floor(n || 1));
    if (!t) return { ok: false, reason: 'unavailable' };
    var s = state();
    s.stock[id] = Math.min(9999, (s.stock[id] || 0) + n);
    save();
    return { ok: true, count: s.stock[id] };
  }

  function upgradeState(id) {
    var s = state();
    if (!s.upgrades[id]) s.upgrades[id] = D().defaultUpgrades();
    s.upgrades[id] = D().normalizeUpgrades(s.upgrades[id]);
    return s.upgrades[id];
  }
  function upgrades(id) { return JSON.parse(JSON.stringify(upgradeState(id))); }
  function level(id) { var u = upgradeState(id); return 1 + u.assault + u.armor + u.mobility; }
  function branchLevel(id, branch) { return upgradeState(id)[branch] || 0; }
  function upgradeCostMult() {
    try {
      if (NEBUSTION.CustomContent && NEBUSTION.CustomContent.GameConfig) {
        var v = NEBUSTION.CustomContent.GameConfig.get('troop_upgrade_cost_mult');
        if (v > 0) return v;
      }
    } catch (e) {}
    return 1;
  }
  function upgradeCost(id, branch) {
    var t = D().get(id), b = D().UPGRADE_BRANCHES[branch], lvl = branchLevel(id, branch);
    if (!t || !b || lvl >= b.max) return null;
    var scale = Math.max(1, t.space) * (1 + lvl * 0.35) * upgradeCostMult();
    var cost = { crystal: Math.ceil(45 * scale), metal: Math.ceil(35 * scale), energy: Math.ceil(25 * scale), dust: Math.ceil(30 * scale) };
    // À partir du rang 3, chaque palier coûte aussi des Noyaux antiques, de plus en plus cher :
    // rang 3 → ×1,5, rang 4 → ×2, ... rang 9 (dernier rang, 10/10) → ×4,5.
    if (lvl >= 3) cost.core = Math.max(1, Math.ceil(0.35 * scale * (1 + (lvl - 2) * 0.5)));
    return cost;
  }
  function canUpgrade(id, branch) {
    var c = upgradeCost(id, branch), R = NEBUSTION.Resources;
    return !!(c && R && R.canAfford(c));
  }
  function upgrade(id, branch) {
    var t = D().get(id), c = upgradeCost(id, branch), R = NEBUSTION.Resources;
    if (!t || !D().UPGRADE_BRANCHES[branch]) return { ok: false, reason: 'invalide' };
    if (!c) return { ok: false, reason: 'max' };
    if (!R || !R.spendMany(c)) return { ok: false, reason: 'cost', cost: c };
    var u = upgradeState(id); u[branch] += 1;
    save();
    return { ok: true, id: id, branch: branch, branchLevel: u[branch], level: level(id), cost: c, stats: stats(id) };
  }
  function stats(id) {
    var t = D().get(id);
    return t ? D().deriveStats(id, upgradeState(id)) : null;
  }

  /** Une unité déployée en combat est consommée. */
  function consume(id, n) {
    n = Math.max(1, Math.floor(n || 1));
    var s = state();
    if ((s.stock[id] || 0) < n) return false;
    s.stock[id] -= n;
    if (s.stock[id] <= 0) delete s.stock[id];
    s.deployed += n;
    save();
    return true;
  }

  return { state: state, capacity: capacity, armyBonus: armyBonus, discount: discount, cost: cost, used: used, free: free, count: count, stock: stock, total: total,
    upgrades: upgrades, level: level, branchLevel: branchLevel, upgradeCost: upgradeCost, canUpgrade: canUpgrade, upgrade: upgrade, stats: stats,
    canBuy: canBuy, buy: buy, grant: grant, consume: consume };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.TroopManager; }
