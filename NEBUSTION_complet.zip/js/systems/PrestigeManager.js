/**
 * NEBUSTION - PrestigeManager
 * Glue entre NEBUSTION.Prestige (données pures) et la sauvegarde/économie existantes.
 * État dans NEBUSTION.Resources.state.prestige : { v, relics, spent:{nodeId:level}, count,
 * bestRelicsGain, history:[{at,relics,count}] } — les Reliques et les paliers achetés dans
 * l'arbre NE SONT JAMAIS réinitialisés par perform().
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.PrestigeManager = (function () {
  'use strict';

  var PR = function () { return NEBUSTION.Prestige; };
  var HISTORY_MAX = 12;

  function root() { return NEBUSTION.Resources && NEBUSTION.Resources.state; }
  function defaultState() { return { v: 1, relics: 0, totalEarned: 0, spent: {}, count: 0, bestRelicsGain: 0, history: [] }; }

  function normalizeState(raw) {
    var s = defaultState();
    if (!raw || typeof raw !== 'object') return s;
    s.relics = Math.max(0, Math.floor(Number(raw.relics) || 0));
    s.totalEarned = Math.max(0, Math.floor(Number(raw.totalEarned) || 0));
    s.count = Math.max(0, Math.floor(Number(raw.count) || 0));
    s.bestRelicsGain = Math.max(0, Math.floor(Number(raw.bestRelicsGain) || 0));
    var sp = raw.spent || {};
    PR().TREE.forEach(function (t) {
      var lv = Math.max(0, Math.floor(Number(sp[t.id]) || 0));
      s.spent[t.id] = Math.min(t.maxLevel, lv);
    });
    s.history = (Array.isArray(raw.history) ? raw.history : []).slice(-HISTORY_MAX).filter(function (h) { return h && typeof h === 'object'; });
    return s;
  }

  function state() {
    var r = root();
    if (!r) return defaultState();
    if (!r.prestige) r.prestige = defaultState();
    return r.prestige;
  }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }

  function relics() { return state().relics; }
  function totalEarned() { return state().totalEarned; }
  function count() { return state().count; }
  function tierName() { return PR().tierName(state().count); }
  function nodeLevel(id) { return state().spent[id] || 0; }
  function bonusValue(id) { return PR().nodeValue(id, nodeLevel(id)); }

  // ---------- Aperçu du gain avant réinitialisation ----------
  function _lifeTotals() {
    var r = root();
    return (r && r.life) || {};
  }
  function _totalStars() {
    var r = root();
    var ss = (r && r.combat && r.combat.stageStars) || {};
    return Object.keys(ss).reduce(function (s, k) { return s + (ss[k] || 0); }, 0);
  }
  function previewPoints() {
    var r = root();
    return PR().pointsFor(_lifeTotals(), _totalStars(), (r && r.combat && r.combat.playerXP) || 0);
  }
  function previewRelics() { return PR().relicsFor(previewPoints()); }

  function canPrestige() {
    var r = root();
    var req = PR().requirementsFor(state().count);   // les objectifs montent à chaque Renaissance
    var cmdLv = (r && r.buildings && r.buildings.command && r.buildings.command.level) || 0;
    var ok = cmdLv >= req.commandLevel && _totalStars() >= req.totalStars;
    return { ok: ok, commandLevel: cmdLv, needCommandLevel: req.commandLevel, totalStars: _totalStars(), needStars: req.totalStars };
  }

  // ---------- Arbre de bonus ----------
  function treeStatus() {
    return PR().TREE.map(function (t) {
      var lv = nodeLevel(t.id);
      var cost = PR().nodeCost(t.id, lv);
      return { id: t.id, name: t.name, desc: t.desc, level: lv, maxLevel: t.maxLevel, value: bonusValue(t.id), cost: cost, maxed: lv >= t.maxLevel };
    });
  }
  function buyNode(id) {
    var t = PR().node(id);
    if (!t) return { ok: false, reason: 'invalide' };
    var s = state(), lv = s.spent[id] || 0;
    if (lv >= t.maxLevel) return { ok: false, reason: 'max' };
    var cost = PR().nodeCost(id, lv);
    if (s.relics < cost) return { ok: false, reason: 'reliques', cost: cost };
    s.relics -= cost;
    s.spent[id] = lv + 1;
    _refreshEconomy();   // la production/efficacité mises en cache tiennent compte du nouveau palier
    save();
    return { ok: true, level: lv + 1, cost: cost, remaining: s.relics };
  }

  function _refreshEconomy() { try { NEBUSTION.Resources._rates = null; } catch (e) { /* ignore */ } }

  // ---------- Renaissance galactique ----------
  /** Réinitialise l'économie/le combat/la galaxie du cycle en cours ; crédite les Reliques ; garde héros/équipement/skins/Pass/Prismes/succès. */
  function perform(now) {
    now = now || Date.now();
    var chk = canPrestige();
    if (!chk.ok) return { ok: false, reason: 'condition', detail: chk };
    var r = root();
    if (!r) return { ok: false, reason: 'indisponible' };
    var E = NEBUSTION.Economy;
    var gain = previewRelics();
    var s = state();
    // Les succès gardent leur meilleure valeur atteinte (niveaux, victoires, étoiles...) même si la progression est remise à zéro.
    try { if (NEBUSTION.AchievementsManager) NEBUSTION.AchievementsManager.snapshot(); } catch (e) { /* ignore */ }

    // Étoiles/victoires/difficulté de combat : réinitialisées (équipe, fragments, héros recrutés, niveaux : conservés).
    r.combat.stageStars = {};
    r.combat.battlesWon = 0;
    r.combat.battlesLost = 0;
    r.combat.difficulty = 'normal';
    r.combat.playerXP = 0;

    // Bâtiments : reviennent au niveau de départ (+ bonus "Fondations gravées" acheté dans l'arbre).
    var headStart = Math.floor(bonusValue('headStart'));
    E.BUILDING_ORDER.forEach(function (bid) {
      r.buildings[bid] = { level: Math.min(E.CFG.MAX_LEVEL, E.BUILDINGS[bid].start + headStart) };
    });
    var storageLvl = r.buildings.storage.level;
    E.ORDER.forEach(function (id) {
      r.res[id] = Math.min(E.storageCap(id, storageLvl), E.PROD[id].start);
      r.life[id] = 0;
      r.drones[id] = E.CFG.START_DRONES;
      r.nodes[id] = { ch: E.CFG.MAX_CHARGES, t: now };
    });

    // Galaxie / empires : repartent de zéro (nouveaux scans, nouvelles conquêtes à refaire).
    if (NEBUSTION.Galaxy) r.galaxy = NEBUSTION.Galaxy.defaultState ? NEBUSTION.Galaxy.defaultState() : r.galaxy;
    if (NEBUSTION.EmpireEvolution && NEBUSTION.Galaxy) r.empires = NEBUSTION.EmpireEvolution.defaultState(now);

    // Reliques (jamais réinitialisées) + historique.
    s.relics += gain;
    s.totalEarned += gain;
    s.count += 1;
    if (gain > s.bestRelicsGain) s.bestRelicsGain = gain;
    s.history.push({ at: now, relics: gain, count: s.count });
    if (s.history.length > HISTORY_MAX) s.history = s.history.slice(-HISTORY_MAX);

    _refreshEconomy();
    try { NEBUSTION.Resources.lastTick = now; NEBUSTION.Resources.emit('prestige', { relics: gain, cycle: s.count }); } catch (e) { /* ignore */ }
    save();
    return { ok: true, relicsGained: gain, totalRelics: s.relics, cycle: s.count, tier: PR().tierName(s.count) };
  }

  return {
    normalizeState: normalizeState, defaultState: defaultState,
    relics: relics, totalEarned: totalEarned, count: count, tierName: tierName, nodeLevel: nodeLevel, bonusValue: bonusValue,
    previewPoints: previewPoints, previewRelics: previewRelics, canPrestige: canPrestige,
    treeStatus: treeStatus, buyNode: buyNode, perform: perform, requirements: function () { return PR().requirementsFor(state().count); }
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.PrestigeManager; }
