/**
 * NEBUSTION - EmpireAIManager
 * Module IA 2/2 : branche NEBUSTION.EmpireAI (personnalité/stratégies pures) sur l'état réel du jeu
 * (Galaxy + GalaxyManager + Resources) pour produire, empire par empire, une DÉCISION (stratégie
 * choisie + effets numériques) et des INTENTIONS (actions suggérées, lisibles par le futur module
 * d'invasion : renforcer telle planète, viser telle cible...).
 *
 * Portée volontaire de cette étape : la décision est recalculée à la demande à partir de l'état de
 * sauvegarde EXISTANT (secteurs débloqués, planètes scannées/visitées/conquises, niveau d'équipe) —
 * aucun nouvel état persistant n'est ajouté à la sauvegarde ici. Les empires n'ont pas encore de
 * ressources/territoires qui évoluent tout seuls avec le temps : c'est le sujet du prochain module
 * (évolution + réactions post-combat + sauvegarde de la progression des empires), qui pourra
 * consommer decide()/intents() tels quels et y ajouter un état persistant sans rien casser ici.
 *
 * Hors ligne, sans serveur : tout tourne en mémoire locale, recalculé à partir de la sauvegarde.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.EmpireAIManager = (function () {
  'use strict';

  var AI = function () { return NEBUSTION.EmpireAI; };
  var G = function () { return NEBUSTION.Galaxy; };
  var GM = function () { return NEBUSTION.GalaxyManager; };

  var listeners = {};
  function on(evt, fn) { (listeners[evt] = listeners[evt] || []).push(fn); return function () { off(evt, fn); }; }
  function off(evt, fn) { if (listeners[evt]) listeners[evt] = listeners[evt].filter(function (f) { return f !== fn; }); }
  function emit(evt, data) { (listeners[evt] || []).slice().forEach(function (f) { try { f(data); } catch (e) { console.error('EmpireAIManager listener', e); } }); }

  // Cache mémoire (non sauvegardé) : { eid: { at, situation, decision } } — évite de recalculer à chaque frame
  // et évite l'oscillation de posture (thinkDelayMs de EmpireAI.DIFFICULTY protège les allers-retours rapides).
  var cache = {};
  var wired = false;

  function difficultyId() {
    var r = NEBUSTION.Resources && NEBUSTION.Resources.state;
    var d = r && r.combat && r.combat.difficulty;
    return (AI().DIFFICULTY_ORDER.indexOf(d) >= 0) ? d : 'normal';
  }

  /** Mémoire d'adaptation de l'empire (lecture seule, sans effet de bord ; zéros si le module d'évolution est absent). */
  function memoryOf(eid) {
    try {
      var EM = NEBUSTION.EmpireEvolutionManager, es = EM && NEBUSTION.Resources && NEBUSTION.Resources.state && NEBUSTION.Resources.state.empires;
      var e = es && es.e && es.e[eid];
      if (e) return { hurt: e.hurt || 0, mom: e.mom || 0, evo: e.evo || 0 };
    } catch (err) { /* ignore */ }
    return { hurt: 0, mom: 0, evo: 0 };
  }

  /**
   * Situation réelle d'un empire, normalisée 0..1 pour EmpireAI.chooseStrategy().
   * @returns {{empire,total,conquered,scanned,visited,sectorUnlocked,lossRatio,pressure,dominance,recAvg,teamLevel,capitalLost}}
   */
  function assess(eid, now) {
    var g = G(), gm = GM();
    var e = g.empire(eid);
    var planets = g.planetsOfEmpire(eid);
    var total = planets.length || 1;
    var conquered = planets.filter(function (p) { return gm.isConquered(p.id); });
    var scanned = planets.filter(function (p) { return gm.isScanned(p.id, now); }).length;
    var visited = planets.filter(function (p) { return gm.isVisited(p.id); }).length;
    var sectorUnlocked = e ? gm.isSectorUnlocked(e.sector) : false;
    var lossRatio = AI().clamp01(conquered.length / total);
    var pressure = AI().clamp01((scanned + visited) / (total * 2) + (sectorUnlocked ? 0.3 : 0));
    var recAvg = planets.reduce(function (s, p) { return s + p.recLevel; }, 0) / total;
    var team = gm.teamLevel();
    var dominance = AI().clamp01(recAvg > 0 ? (team - recAvg) / recAvg : 0);
    var capitalLost = planets.some(function (p) { return p.isCapital && gm.isConquered(p.id); }) ? 1 : 0;
    var mem = memoryOf(eid);
    return {
      empire: eid, total: total, conquered: conquered.length, scanned: scanned, visited: visited,
      sectorUnlocked: sectorUnlocked, lossRatio: lossRatio, pressure: pressure, dominance: dominance,
      recAvg: Math.round(recAvg * 10) / 10, teamLevel: Math.round(team * 10) / 10, capitalLost: capitalLost,
      hurt: mem.hurt, momentum: mem.mom, evo: mem.evo
    };
  }

  /** Décision d'un empire (stratégie + effets), recalculée si le cache est absent/périmé. */
  function decide(eid, now) {
    now = (typeof now === 'number' && isFinite(now)) ? now : Date.now();
    var diffId = difficultyId();
    var profile = AI().difficultyProfile(diffId);
    var hit = cache[eid];
    if (hit && (now - hit.at) < profile.thinkDelayMs && hit.decision) return hit.decision;
    var situation = assess(eid, now);
    var decision = AI().chooseStrategy(eid, situation, diffId);
    var prevStrategy = hit && hit.decision ? hit.decision.strategy : null;
    cache[eid] = { at: now, situation: situation, decision: decision };
    if (decision && decision.strategy !== prevStrategy) emit('strategyChange', { empire: eid, decision: decision, situation: situation });
    return decision;
  }

  /** Décision de tous les empires (ordre stable de Galaxy.EMPIRE_ORDER). */
  function decideAll(now) {
    var out = {};
    AI().empireIds().forEach(function (eid) { out[eid] = decide(eid, now); });
    return out;
  }

  function lastSituation(eid) { var hit = cache[eid]; return hit ? hit.situation : null; }

  /**
   * Intentions suggérées pour le futur module d'invasion : liste d'actions PROPOSÉES (jamais
   * exécutées ici — aucune mutation de l'état de jeu). Chaque intention porte une priorité 0..1.
   */
  function intents(eid, now) {
    var g = G(), gm = GM();
    var decision = decide(eid, now);
    var situation = lastSituation(eid) || assess(eid, now);
    if (!decision) return [];
    var planets = g.planetsOfEmpire(eid);
    var capital = planets.filter(function (p) { return p.isCapital; })[0];
    var frontier = planets
      .filter(function (p) { return !gm.isConquered(p.id); })
      .sort(function (a, b) { return a.tier - b.tier; })[0];
    var deepest = planets
      .filter(function (p) { return gm.isConquered(p.id); })
      .sort(function (a, b) { return b.tier - a.tier; })[0];
    var out = [];
    if (decision.posture === 'defensive') {
      if (capital) out.push({ type: 'reinforceDefense', target: capital.id, priority: 0.65 + situation.lossRatio * 0.35, reason: decision.name });
      if (frontier) out.push({ type: 'fortifyBorder', target: frontier.id, priority: 0.4 + situation.pressure * 0.3, reason: decision.name });
    } else if (decision.posture === 'offensive') {
      if (deepest) out.push({ type: 'counterOffensive', target: deepest.id, priority: 0.5 + situation.lossRatio * 0.4, reason: decision.name });
      if (frontier) out.push({ type: 'expandInfluence', target: frontier.id, priority: 0.3 + situation.dominance * 0.3, reason: decision.name });
    } else {
      if (frontier) out.push({ type: 'expandInfluence', target: frontier.id, priority: 0.25, reason: decision.name });
      out.push({ type: 'holdPosition', target: capital ? capital.id : null, priority: 0.5, reason: decision.name });
    }
    out.sort(function (a, b) { return b.priority - a.priority; });
    out.forEach(function (i) { i.priority = Math.round(i.priority * 100) / 100; });
    return out;
  }

  function invalidate(eid) { if (eid) delete cache[eid]; else cache = {}; }

  /** Branche le recalcul sur les événements du module Galaxie (conquête, fin de scan, déblocage). */
  function wire() {
    if (wired || !GM()) return;
    wired = true;
    GM().on('conquest', function (d) {
      var e = G().planet(d.planet); if (!e || !e.empire) return;
      invalidate(e.empire); var dec = decide(e.empire, Date.now()); emit('react', { empire: e.empire, event: 'conquest', planet: d.planet, decision: dec });
    });
    GM().on('scanDone', function (d) {
      var e = G().planet(d.planet); if (!e || !e.empire) return;
      invalidate(e.empire); emit('react', { empire: e.empire, event: 'scanDone', planet: d.planet, decision: decide(e.empire, Date.now()) });
    });
    GM().on('unlock', function (d) {
      var s = G().sector(d.sector); if (!s || !s.empire) return;
      invalidate(s.empire); emit('react', { empire: s.empire, event: 'unlock', decision: decide(s.empire, Date.now()) });
    });
  }

  return {
    on: on, off: off, wire: wire, assess: assess, decide: decide, decideAll: decideAll,
    lastSituation: lastSituation, intents: intents, invalidate: invalidate, difficultyId: difficultyId
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.EmpireAIManager; }
