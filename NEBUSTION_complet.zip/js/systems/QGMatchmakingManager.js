/**
 * NEBUSTION - QGMatchmakingManager
 * Glue entre NEBUSTION.QGMatchmaking (données pures) et le reste du jeu : trouve un adversaire
 * pour le panneau « Attaquer » du QG (module QGScene / EnemyQGScene), au lieu de la liste figée
 * des 5 commandants. État dans NEBUSTION.Resources.state.qgMatch : { eid, variant, foundAt }.
 *
 * Le pool d'adversaires reste les empires réels (NEBUSTION.Galaxy / QGAttackManager.targets()) :
 * l'issue d'une attaque, le butin et le traumatisme de l'empire viennent toujours, sans changement,
 * de QGAttackManager.attack(). Ce module ne fait que CHOISIR lequel proposer, et avec quelle variante
 * visuelle (NEBUSTION.BotBases.layout(eid, evo, hurt, variant)).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.QGMatchmakingManager = (function () {
  'use strict';

  var MM = function () { return NEBUSTION.QGMatchmaking; };
  var AM = function () { return NEBUSTION.QGAttackManager; };
  var BB = function () { return NEBUSTION.BotBases; };
  var EM = function () { return NEBUSTION.EmpireEvolutionManager; };
  var GM = function () { return NEBUSTION.QGGridManager; };
  var QGrid = function () { return NEBUSTION.QGGrid; };

  function root() { return NEBUSTION.Resources && NEBUSTION.Resources.state; }
  function state() {
    var r = root();
    if (!r) return { current: null };
    if (!r.qgMatch || typeof r.qgMatch !== 'object') r.qgMatch = { current: null };
    return r.qgMatch;
  }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }
  function ready() { return !!(MM() && AM() && BB() && EM() && GM() && QGrid()); }

  /** Niveau du joueur (échelle comparable aux profils d'empires), déduit du développement de son QG. */
  function playerLevel() {
    if (!ready()) return 5;
    return MM().playerLevel(GM().unlockedCount(), QGrid().MAX_CELLS);
  }

  /** Adversaire actuellement proposé (ou null si aucune recherche n'a encore été faite / cible invalide). */
  function current(now) {
    if (!ready()) return null;
    var c = state().current;
    if (!c || !c.eid) return null;
    if (!AM().isAlive(c.eid)) { state().current = null; save(); return null; }
    var es = EM().state(now || Date.now()).e[c.eid];
    var prof = BB().profile(c.eid, es.evo);
    return { eid: c.eid, variant: c.variant || 0, foundAt: c.foundAt || 0, profile: prof, es: es };
  }

  /** Lance une recherche : tire un nouvel adversaire pondéré par niveau, avec une nouvelle variante visuelle. */
  function search(now) {
    now = now || Date.now();
    if (!ready()) return null;
    var pool = AM().targets();
    if (!pool.length) { state().current = null; save(); return null; }
    var lvl = playerLevel();
    var candidates = pool.map(function (eid) {
      var es = EM().state(now).e[eid];
      return { eid: eid, level: BB().profile(eid, es.evo).level };
    });
    var seed = (now ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
    var eid = MM().pickTarget(candidates, lvl, seed);
    if (!eid) { state().current = null; save(); return null; }
    state().current = { eid: eid, variant: MM().rollVariant(seed ^ 0x9e3779b9), foundAt: now };
    save();
    return current(now);
  }

  /** Efface l'adversaire proposé (par exemple après un combat) : il faudra rechercher à nouveau. */
  function clearCurrent() { state().current = null; save(); }

  return {
    playerLevel: playerLevel, current: current, search: search, clearCurrent: clearCurrent
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.QGMatchmakingManager; }
