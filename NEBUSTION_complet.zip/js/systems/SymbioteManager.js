/** NEBUSTION - SymbioteManager */
window.NEBUSTION = window.NEBUSTION || {};
NEBUSTION.SymbioteManager = (function () {
  'use strict';
  function D() { return NEBUSTION.Symbiote; }
  function root() { return NEBUSTION.Resources && NEBUSTION.Resources.state; }
  function state() { var r = root(); if (!r) return D().defaultState(); if (!r.symbiote) r.symbiote = D().defaultState(); return r.symbiote; }
  function save() { if (NEBUSTION.Resources) NEBUSTION.Resources.saveNow(Date.now()); }
  function buildingCost() { return { crystal: 900, metal: 1200, energy: 700 }; }
  function buy() {
    var s = state(), R = NEBUSTION.Resources, c = buildingCost();
    if (s.built) return { ok: false, reason: 'built' };
    if (!R || !R.spendMany(c)) return { ok: false, reason: 'cost', cost: c };
    s.built = true; save(); return { ok: true, cost: c };
  }
  function openCapsule() { var s = state(); if (!s.built || s.capsuleOpened) return { ok: false, reason: 'already' }; s.capsuleOpened = true; ensureClocks(Date.now()); resetRates(); save(); return { ok: true }; }
  function qgBonus(type) {
    try { var qm = NEBUSTION.QGGridManager; return qm ? qm.bonusValue(type) : 0; } catch (e) { return 0; }
  }
  function resetRates() { try { if (NEBUSTION.Resources) NEBUSTION.Resources._rates = null; } catch (e) { /* ignore */ } }
  // Démarre les horloges (sécrétion / couvée) à l'ouverture de la capsule — et sur les anciennes sauvegardes, sans cadeau rétroactif.
  function ensureClocks(now) {
    var s = state();
    if (!s.capsuleOpened) return s;
    if (!s.lastCollectAt) s.lastCollectAt = now;
    if (!s.lastHatchAt) s.lastHatchAt = now;
    return s;
  }
  function feed(resourceId) {
    var s = state(), R = NEBUSTION.Resources, f = D().feed(s, resourceId);
    if (!f.ok) return { ok: false, reason: 'invalid' };
    if (!s.capsuleOpened) return { ok: false, reason: 'capsule' };
    if (!R || !R.spendMany(f.cost)) return { ok: false, reason: 'cost', cost: f.cost };
    // Bio-labo du QG : +8 % d'XP par labo.
    var xp = Math.round(f.xp * (1 + qgBonus('symbiote')));
    var before = s.level; var levels = D().gainXP(s, xp); s.totalFed += 1; s.lastFedAt = Date.now();
    if (s.level > before) resetRates();   // le bonus de production dépend du niveau
    save();
    return { ok: true, xp: xp, levels: levels, level: s.level, leveled: s.level > before };
  }
  /** Stade d'évolution (Larve → Primordial). */
  function stage() { return D().stageOf(state().level); }
  /** Bonus donné à la base : 'production' (+0,2 %/niveau, max 10 %) — actif une fois la capsule ouverte. */
  function bonus(type) {
    var s = state();
    if (type === 'production') return (s.built && s.capsuleOpened) ? D().productionBonus(s.level) : 0;
    return 0;
  }
  // ---------- Sécrétion : le Symtor produit des ressources pendant que tu es absent ----------
  function pending(now) {
    now = now || Date.now();
    var s = ensureClocks(now), out = { hours: 0, res: {}, any: false };
    if (!s.capsuleOpened) return out;
    var hours = Math.max(0, Math.min(D().SECRETION_CAP_HOURS, (now - s.lastCollectAt) / 3600000));
    var rate = D().secretionPerHour(s.level);
    out.hours = hours; out.full = hours >= D().SECRETION_CAP_HOURS - 1e-9;
    Object.keys(rate).forEach(function (id) { var n = Math.floor(rate[id] * hours); out.res[id] = n; if (n > 0) out.any = true; });
    return out;
  }
  function collect(now) {
    now = now || Date.now();
    var s = state(), p = pending(now), R = NEBUSTION.Resources;
    if (!s.capsuleOpened) return { ok: false, reason: 'capsule' };
    if (!p.any || !R) return { ok: false, reason: 'empty' };
    Object.keys(p.res).forEach(function (id) { if (p.res[id] > 0) R.add(id, p.res[id], 'symbiote'); });
    s.lastCollectAt = now; save();
    return { ok: true, res: p.res, hours: p.hours };
  }
  // ---------- Couvée : le Symtor pond des Rejetons (troupes) toutes les 6 h ----------
  function hatchRemaining(now) {
    now = now || Date.now();
    var s = ensureClocks(now);
    if (!s.capsuleOpened) return Infinity;
    return Math.max(0, D().HATCH_MS - (now - s.lastHatchAt));
  }
  function hatchReady(now) { var s = state(); return s.capsuleOpened && s.level >= D().HATCH_MIN_LEVEL && hatchRemaining(now) <= 0; }
  function hatchCount() { return D().hatchCount(state().level); }
  function hatch(now) {
    now = now || Date.now();
    var s = state(), TM = NEBUSTION.TroopManager;
    if (!s.capsuleOpened) return { ok: false, reason: 'capsule' };
    if (s.level < D().HATCH_MIN_LEVEL) return { ok: false, reason: 'level' };
    if (hatchRemaining(now) > 0) return { ok: false, reason: 'wait' };
    if (!TM) return { ok: false, reason: 'unavailable' };
    var n = hatchCount();
    TM.grant('spawn', n);
    s.lastHatchAt = now; save();
    return { ok: true, count: n };
  }
  function power() { var s = state(); return D().power(s.level, s.xp) + s.mutations * 8; }
  function defense() { var s = state(); return D().defense(s.level, s.mutations); }
  function growth() { return D().growth(state().level); }
  function canEnter() { return state().built; }
  // Prépare un duel : calcule l'adversaire et simule le combat complet (tour par tour, HP réelles)
  // SANS toucher à l'état (pas de récompense distribuée) — permet à la scène de combat de rejouer
  // l'affrontement à l'écran avant que le résultat ne soit appliqué (voir resolveBattle).
  function prepareBattle(type) {
    var s = state(); if (!s.capsuleOpened) return { ok: false, reason: 'capsule' };
    var seed = s.genome.seed + s.totalFed * 97 + s.level * 31 + Date.now();
    var enemyLevel = type === 'symbiote' ? Math.max(1, s.level + Math.floor((Math.random() - 0.5) * 8)) : Math.max(1, s.level + Math.floor((Math.random() - 0.35) * 12));
    var enemyPower = D().opponentPower(seed, enemyLevel, type);
    var enemyDefense = D().opponentDefense(seed, enemyLevel, type);
    var ownPower = power(), ownDefense = defense();
    var sim = D().simulateBattle(seed, { power: ownPower, defense: ownDefense }, { power: enemyPower, defense: enemyDefense });
    return { ok: true, type: type, seed: seed, enemyLevel: enemyLevel, enemyPower: enemyPower, enemyDefense: enemyDefense,
      ownPower: ownPower, ownDefense: ownDefense, level: s.level, sim: sim, win: sim.win };
  }
  // Applique le résultat d'un combat déjà préparé/joué (récompenses, statistiques, XP éventuelle).
  function resolveBattle(prepared) {
    var s = state(), type = prepared.type, win = prepared.win;
    var reward = win ? { crystal: type === 'symbiote' ? 70 : 120, energy: type === 'symbiote' ? 40 : 80 } : { dust: 15 };
    var rm = D().rewardMult(s.level); Object.keys(reward).forEach(function (id) { reward[id] = Math.round(reward[id] * rm); });
    if (win) { if (type === 'symbiote') s.battles.symbioteWon++; else s.battles.galaxyWon++; }
    else { if (type === 'symbiote') s.battles.symbioteLost++; else s.battles.galaxyLost++; }
    Object.keys(reward).forEach(function (id) { if (NEBUSTION.Resources) NEBUSTION.Resources.add(id, reward[id], 'symbioteBattle'); });
    if (win && Math.random() < 0.25) D().gainXP(s, type === 'symbiote' ? 18 : 26);
    save();
    return { ok: true, win: win, type: type, reward: reward, level: s.level };
  }
  // Ancienne API synchrone (conservée pour compatibilité/tests) : prépare et résout d'un coup, sans animation.
  function battle(type) {
    var prepared = prepareBattle(type);
    if (!prepared.ok) return prepared;
    var r = resolveBattle(prepared);
    r.own = prepared.ownPower; r.enemy = prepared.enemyPower; r.enemyLevel = prepared.enemyLevel;
    return r;
  }
  return { state: state, buildingCost: buildingCost, buy: buy, openCapsule: openCapsule, feed: feed, power: power, defense: defense, growth: growth, canEnter: canEnter, battle: battle,
    prepareBattle: prepareBattle, resolveBattle: resolveBattle,
    stage: stage, bonus: bonus, pending: pending, collect: collect, hatchRemaining: hatchRemaining, hatchReady: hatchReady, hatchCount: hatchCount, hatch: hatch };
})();
