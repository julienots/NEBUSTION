/**
 * NEBUSTION - NebustionManager
 * Glue entre NEBUSTION.Nebustion (données pures) et le reste du jeu :
 *  - sauvegarde : NEBUSTION.Resources.state.nebustion (validé par Nebustion.normalizeState, branché SaveManager) ;
 *  - déblocage : la victoire sur 'boss_omega_krell' (Combat.stageStars) révèle le module ;
 *  - combat : lu par CombatManager (bonus de difficulté des avant-postes, récompenses d'Éclat Souillé,
 *    marquage de victoire) — voir les petits ajouts dans CombatManager.js, chacun protégé par
 *    `if (NEBUSTION.NebustionManager) { try {...} catch(e){} }` pour ne jamais faire planter un
 *    combat normal si ce module venait à manquer (tests isolés, etc.), comme le reste du code.
 *
 * Idempotent, rattrapage hors ligne borné (même patron que QGRaidManager/EmpireEvolutionManager) :
 * recharger la sauvegarde ne fait jamais avancer la jauge deux fois pour le même intervalle.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.NebustionManager = (function () {
  'use strict';

  var D = function () { return NEBUSTION.Nebustion; };
  var C = function () { return NEBUSTION.Combat; };

  var listeners = {};
  function on(evt, fn) { (listeners[evt] = listeners[evt] || []).push(fn); return function () { off(evt, fn); }; }
  function off(evt, fn) { if (listeners[evt]) listeners[evt] = listeners[evt].filter(function (f) { return f !== fn; }); }
  function emit(evt, data) { (listeners[evt] || []).slice().forEach(function (f) { try { f(data); } catch (e) { console.error('NebustionManager listener', e); } }); }

  function root() { return NEBUSTION.Resources && NEBUSTION.Resources.state; }
  function nowOf(now) { return (typeof now === 'number' && isFinite(now)) ? now : Date.now(); }
  function state(now) {
    var r = root();
    if (!r) return D().defaultState(nowOf(now));
    if (!r.nebustion) r.nebustion = D().normalizeState(null, nowOf(now));
    return r.nebustion;
  }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }

  /** Vrai une fois OMEGA-KRELL vaincu (voir Nebustion.CFG.UNLOCK_STAGE_ID) : révèle le module au joueur. */
  function checkUnlock(now) {
    var st = state(now), c = C();
    if (!st.unlocked && c && c.stageStars && c.stageStars(D().CFG.UNLOCK_STAGE_ID) > 0) {
      st.unlocked = true;
      emit('unlocked', {});
    }
    return st.unlocked;
  }
  function isUnlocked(now) { return checkUnlock(now); }

  /** À appeler périodiquement (boucle principale) : fait avancer la jauge depuis la dernière visite. */
  function tick(now) {
    now = nowOf(now);
    var st = state(now);
    if (!checkUnlock(now)) { st.lastAt = now; return 0; }   // pas encore débloqué : la jauge n'existe pas encore
    var delta = D().tick(st, now);
    if (delta > 0) emit('tick', { pct: st.pct, delta: delta });
    return delta;
  }

  function pct(now) { checkUnlock(now); return state(now).pct; }
  function rateInfo(now) { var st = state(now); return { pct: st.pct, perHour: D().ratePerHour(st) }; }

  /** Réduit la jauge (victoire sur un avant-poste, activation du Sanctuaire...). */
  function purify(amountPct) {
    var st = state();
    var applied = D().purify(st, amountPct);
    if (applied > 0) { save(); emit('purify', { amount: applied, pct: st.pct }); }
    return applied;
  }

  /** Ajoute de l'Éclat Souillé (récompense de combat). */
  function addShards(n) {
    var st = state();
    st.shards = Math.max(0, st.shards + (Number(n) || 0));
    save();
    emit('shards', { total: st.shards });
    return st.shards;
  }
  function shards() { return state().shards; }

  // ---------- Sanctuaire ----------
  function sanctuaryLevel() { return state().sanctuaryLevel; }
  function sanctuaryCost() { return D().sanctuaryCost(sanctuaryLevel()); }
  function sanctuaryDecayPct() { return D().sanctuaryDecayPct(sanctuaryLevel()); }
  function upgradeSanctuary() {
    var st = state();
    if (!st.unlocked) return { ok: false, reason: 'locked' };
    if (st.sanctuaryLevel >= D().CFG.SANCTUARY_MAX_LEVEL) return { ok: false, reason: 'max' };
    var cost = D().sanctuaryCost(st.sanctuaryLevel);
    var R = NEBUSTION.Resources;
    if (!R || !R.spendMany(cost)) return { ok: false, reason: 'cost', cost: cost };
    st.sanctuaryLevel += 1;
    save();
    emit('sanctuary', { level: st.sanctuaryLevel, cost: cost });
    return { ok: true, level: st.sanctuaryLevel, cost: cost };
  }
  function canActivateSanctuary(now) { return D().canActivateSanctuary(state(nowOf(now)), nowOf(now)); }
  function sanctuaryCooldownRemainingMs(now) { return D().sanctuaryCooldownRemainingMs(state(nowOf(now)), nowOf(now)); }
  function activateSanctuary(now) {
    now = nowOf(now);
    if (!canActivateSanctuary(now)) return { ok: false, reason: 'cooldown' };
    var st = state(now);
    st.sanctuaryUsedAt = now;
    var applied = D().purify(st, D().CFG.SANCTUARY_PURIFY_PCT);
    save();
    emit('purify', { amount: applied, pct: st.pct, manual: true });
    return { ok: true, amount: applied, pct: st.pct };
  }

  // ---------- Combat (utilisé par CombatManager) ----------
  /** Multiplicateur de difficulté à appliquer aux stages 'corruption_outpost_*' (voir Enemies.js). */
  function outpostScaleBonus() { return D().outpostScaleBonus(pct()); }
  /** Un avant-poste vient d'être vaincu : Éclat Souillé + purification de la jauge. */
  function rewardOutpostVictory() {
    addShards(D().CFG.OUTPOST_SHARD_REWARD);
    return purify(D().CFG.OUTPOST_PURIFY_PCT);
  }
  /** Le boss final vient d'être vaincu : grosse récompense d'Éclat Souillé. */
  function rewardBossVictory() {
    addShards(D().CFG.BOSS_SHARD_REWARD);
  }
  function isBossReachable() {
    var c = C();
    return !!(c && c.isStageUnlocked && c.isStageUnlocked(D().CFG.BOSS_STAGE_ID));
  }
  function bossDefeated() {
    var c = C();
    return !!(c && c.stageStars && c.stageStars(D().CFG.BOSS_STAGE_ID) > 0);
  }

  // ---------- Dilemme du Symtor ----------
  function resonance() { return state().resonance; }
  function symtorCorrupted() { return state().symtorCorrupted; }
  function feedTaintedToSymtor() {
    var st = state();
    var res = D().feedTainted(st);
    if (res.ok) { save(); emit('symtorFeed', res); }
    return res;
  }
  function purifySymtor() {
    var st = state();
    var did = D().purifySymtor(st);
    if (did) { save(); emit('symtorPurified', {}); }
    return did;
  }

  return {
    on: on, off: off,
    state: state, tick: tick, isUnlocked: isUnlocked, pct: pct, rateInfo: rateInfo, purify: purify,
    addShards: addShards, shards: shards,
    sanctuaryLevel: sanctuaryLevel, sanctuaryCost: sanctuaryCost, sanctuaryDecayPct: sanctuaryDecayPct,
    upgradeSanctuary: upgradeSanctuary, canActivateSanctuary: canActivateSanctuary,
    sanctuaryCooldownRemainingMs: sanctuaryCooldownRemainingMs, activateSanctuary: activateSanctuary,
    outpostScaleBonus: outpostScaleBonus, rewardOutpostVictory: rewardOutpostVictory, rewardBossVictory: rewardBossVictory,
    isBossReachable: isBossReachable, bossDefeated: bossDefeated,
    resonance: resonance, symtorCorrupted: symtorCorrupted, feedTaintedToSymtor: feedTaintedToSymtor, purifySymtor: purifySymtor
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = NEBUSTION.NebustionManager;
