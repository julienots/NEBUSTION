/**
 * NEBUSTION - SkinManager
 * Glue entre NEBUSTION.Skins (données pures) et la sauvegarde/économie existantes, même schéma que
 * ShipManager/EquipmentManager. État dans NEBUSTION.Resources.state.skins (couvert par la sauvegarde
 * automatique déjà en place). Purement cosmétique : ne touche jamais aux statistiques de combat.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.SkinManager = (function () {
  'use strict';

  var K = function () { return NEBUSTION.Skins; };
  var root = function () { return NEBUSTION.Resources && NEBUSTION.Resources.state; };

  function state() {
    var r = root();
    if (!r) return K().defaultState();
    if (!r.skins) r.skins = K().normalizeState(null);
    return r.skins;
  }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }

  // ---------- Cibles valides ----------
  function validTarget(type, id) {
    if (typeof id !== 'string' || !id) return false;
    if (type === 'hero') return !!(NEBUSTION.Heroes && NEBUSTION.Heroes.get(id));
    if (type === 'building') return K().BUILDING_TARGETS.indexOf(id) >= 0;
    if (type === 'ship') return NEBUSTION.ShipManager ? !!NEBUSTION.ShipManager.get(id) : /^sh\d+$/.test(id);
    return false;
  }

  // ---------- Inventaire de cosmétiques ----------
  function isOwned(skinId) { return !!K().get(skinId) && state().owned[skinId] === true; }

  /** Skins possédés (tous types, ou d'un type donné). */
  function owned(type) {
    var s = state();
    return K().SKINS.filter(function (k) { return s.owned[k.id] && (!type || k.target === type); });
  }

  /** Collection : { owned, total, byType: { hero: {owned,total}, ... } }. */
  function collection() {
    var s = state(), out = { owned: 0, total: K().SKINS.length, byType: {} };
    K().TARGET_TYPES.forEach(function (t) {
      var all = K().forTarget(t), o = all.filter(function (k) { return s.owned[k.id]; }).length;
      out.byType[t] = { owned: o, total: all.length }; out.owned += o;
    });
    return out;
  }

  // ---------- Achat ----------
  function buy(skinId) {
    var skin = K().get(skinId);
    if (!skin) return { ok: false, reason: 'invalide' };
    if (skin.exclusive) return { ok: false, reason: 'exclusif' };
    var s = state();
    if (s.owned[skinId]) return { ok: false, reason: 'deja' };
    var cost = K().cost(skin.rarity);
    if (!NEBUSTION.Resources.canAfford(cost)) return { ok: false, reason: 'ressources', cost: cost };
    NEBUSTION.Resources.spendMany(cost);
    s.owned[skinId] = true;
    save();
    return { ok: true, skin: skin, cost: cost };
  }

  /** Offre un skin (récompense, sans coût) — utilisé par le Pass. `dup:true` si déjà possédé (rien n'est modifié). */
  function grant(skinId) {
    var skin = K().get(skinId);
    if (!skin) return { ok: false, reason: 'invalide' };
    var s = state();
    if (s.owned[skinId]) return { ok: true, dup: true, skin: skin };
    s.owned[skinId] = true;
    save();
    return { ok: true, dup: false, skin: skin };
  }

  // ---------- Équipement ----------
  function equippedId(type, targetId) { return state().equipped[K().key(type, targetId)] || null; }
  function equippedSkin(type, targetId) { var id = equippedId(type, targetId); return id ? K().get(id) : null; }

  function equip(type, targetId, skinId) {
    var skin = K().get(skinId);
    if (!skin || skin.target !== type) return { ok: false, reason: 'invalide' };
    if (!validTarget(type, targetId)) return { ok: false, reason: 'cible' };
    var s = state();
    if (!s.owned[skinId]) return { ok: false, reason: 'non_possede' };
    s.equipped[K().key(type, targetId)] = skinId;
    save();
    return { ok: true, skin: skin };
  }

  function unequip(type, targetId) {
    var s = state(), k = K().key(type, targetId);
    if (!s.equipped[k]) return { ok: false, reason: 'rien' };
    delete s.equipped[k];
    save();
    return { ok: true };
  }

  function equippedCount() { return Object.keys(state().equipped).length; }

  return {
    isOwned: isOwned, owned: owned, collection: collection, buy: buy, grant: grant,
    equippedId: equippedId, equippedSkin: equippedSkin, equip: equip, unequip: unequip,
    equippedCount: equippedCount, validTarget: validTarget
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.SkinManager; }
