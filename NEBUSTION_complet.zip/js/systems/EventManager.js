/**
 * NEBUSTION - EventManager
 * Glue entre NEBUSTION.Events (données pures) et la sauvegarde/économie existantes (même
 * schéma que PassManager/ShopManager). État dans NEBUSTION.Resources.state.events, couvert
 * par la sauvegarde automatique. Aucun serveur : tout est calculé sur l'heure locale de
 * l'appareil (voir js/data/Events.js), avec des vérifications raisonnables :
 *  - « plancher d'horloge » : si l'horloge est reculée, l'événement ne revient jamais en arrière
 *    (pas de tentatives de boss regagnées en changeant la date) ; le plancher ne peut pas
 *    dépasser de plus de 2 jours l'heure réelle (une date lointaine puis rétablie ne bloque pas le jeu) ;
 *  - un nouveau cycle convertit la monnaie restante en Prismes (jamais perdue), sans jamais toucher
 *    au reste de la sauvegarde pendant le chargement (la conversion est réglée après coup : _settle).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.EventManager = (function () {
  'use strict';

  var EV = function () { return NEBUSTION.Events; };
  var root = function () { return NEBUSTION.Resources && NEBUSTION.Resources.state; };
  var fallback = null;
  var CLOCK_AHEAD_MAX = 2 * 86400000;

  function _prestigeTier() { return NEBUSTION.PrestigeManager ? NEBUSTION.PrestigeManager.count() : 0; }

  /** Heure de référence des événements : jamais en arrière du plus récent instant vu. */
  function _now() {
    var t = Date.now(), r = root(), ev = r && r.events;
    if (ev && isFinite(ev.clockFloor)) {
      if (t < ev.clockFloor) return ev.clockFloor;
      ev.clockFloor = t;
    }
    return t;
  }

  function _int(x) { return Math.max(0, Math.floor(Number(x) || 0)); }

  function defaultState(now) {
    now = now || Date.now();
    var cIdx = EV().cycleIndex(now);
    var maxHp = EV().currentEvent(now, _prestigeTier()).bossMaxHp;
    return {
      v: 2, cycleIndex: cIdx, currency: 0, pendingGems: 0, clockFloor: now,
      missions: EV().MISSION_POOL.map(function (m) { return { id: m.id, p: 0, c: false }; }),
      attemptsUsedDay: EV().dayIndex(now), attemptsUsed: 0,
      boss: { hp: maxHp, max: maxHp, defeated: false },
      damageTotal: 0, lastLoginDay: -1, purchased: {}, stats: { attacks: 0, bossKills: 0 }
    };
  }

  function normalizeState(raw, now) {
    now = now || Date.now();
    var s = defaultState(now);
    if (!raw || typeof raw !== 'object') return s;
    var cur = EV().cycleIndex(now);
    s.clockFloor = Math.max(now, Math.min(Number(raw.clockFloor) || now, now + CLOCK_AHEAD_MAX));
    s.pendingGems = _int(raw.pendingGems);
    var rs = raw.stats || {};
    var keptStats = { attacks: _int(rs.attacks), bossKills: _int(rs.bossKills) };
    if (raw.cycleIndex === cur) {
      // Même occurrence d'événement : la progression est conservée telle quelle.
      s.currency = _int(raw.currency);
      var rm = Array.isArray(raw.missions) ? raw.missions : [];
      s.missions = EV().MISSION_POOL.map(function (def) {
        var found = rm.filter(function (m) { return m && m.id === def.id; })[0];
        var p = found ? Math.max(0, Math.min(def.target, _int(found.p))) : 0;
        return { id: def.id, p: p, c: !!(found && found.c && p >= def.target) };
      });
      var day = EV().dayIndex(now);
      var rday = isFinite(raw.attemptsUsedDay) ? Math.floor(raw.attemptsUsedDay) : day;
      s.attemptsUsed = rday === day ? _int(raw.attemptsUsed) : 0;
      s.attemptsUsedDay = day;
      var rb = raw.boss || {};
      var freshMax = s.boss.max;
      var max = (isFinite(Number(rb.max)) && Number(rb.max) > 0) ? Math.min(Number(rb.max), freshMax * 3) : freshMax;
      var hp = (rb.hp !== undefined && isFinite(Number(rb.hp))) ? Number(rb.hp) : max;
      s.boss = { hp: Math.max(0, Math.min(max, hp)), max: max, defeated: rb.defeated === true };
      if (s.boss.defeated) s.boss.hp = 0;
      s.damageTotal = _int(raw.damageTotal);
      s.lastLoginDay = isFinite(raw.lastLoginDay) ? Math.floor(raw.lastLoginDay) : -1;
      var rp = raw.purchased || {};
      Object.keys(rp).forEach(function (id) { if (EV().shopItem(id)) s.purchased[id] = _int(rp[id]); });
      s.stats = keptStats;
    } else if (isFinite(raw.cycleIndex) && raw.cycleIndex < cur) {
      // Nouvelle occurrence (ou plusieurs sautées hors ligne) : la monnaie restante du thème précédent
      // est convertie en Prismes (jamais perdue) — réglée après le chargement par _settle().
      s.pendingGems += EV().convertLeftover(_int(raw.currency));
      s.stats = keptStats;
    } else {
      s.stats = keptStats;   // cycle futur (horloge reculée avant le chargement) : état neuf, statistiques cumulées conservées
    }
    return s;
  }

  /** Verse les Prismes en attente (conversion de monnaie d'un cycle terminé) : nécessite la Boutique, donc jamais pendant le chargement. */
  function _settle(s) {
    if (s && s.pendingGems > 0 && NEBUSTION.ShopManager && root()) {
      try { NEBUSTION.ShopManager.addGems(s.pendingGems); s.pendingGems = 0; } catch (e) { /* réessaiera */ }
    }
  }

  function state() {
    var r = root(), now = _now(), cur;
    if (r) cur = r.events; else cur = fallback;
    if (!cur || cur.cycleIndex !== EV().cycleIndex(now) || cur.attemptsUsedDay !== EV().dayIndex(now)) {
      cur = normalizeState(cur, now);
      if (r) r.events = cur; else fallback = cur;
    }
    if (cur.pendingGems > 0) _settle(cur);
    return cur;
  }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }

  // ---------- Aperçu de l'événement courant ----------
  function info() { return EV().currentEvent(_now(), _prestigeTier()); }
  function isActive() { return info().active; }
  function currentNow() { return _now(); }

  // ---------- Missions ----------
  function missions() {
    var s = state();
    return s.missions.map(function (m) {
      var def = EV().missionDef(m.id);
      return { id: m.id, label: def.label, metric: def.metric, target: def.target, currency: def.currency, p: m.p, claimed: m.c, status: m.c ? 'claimed' : (m.p >= def.target ? 'ready' : 'progress') };
    });
  }
  function claimableCount() { return isActive() ? missions().filter(function (m) { return m.status === 'ready'; }).length : 0; }
  function track(metric, amount) {
    if (!isActive()) return false;
    amount = Math.floor(Number(amount) || 1);
    if (amount <= 0) return false;
    var s = state(), changed = false;
    s.missions.forEach(function (m) {
      var def = EV().missionDef(m.id);
      if (def && def.metric === metric && !m.c && m.p < def.target) { m.p = Math.min(def.target, m.p + amount); changed = true; }
    });
    if (metric === 'damage') { s.damageTotal += amount; changed = true; }
    if (changed) save();
    return changed;
  }
  function claimMission(id) {
    if (!isActive()) return { ok: false, reason: 'inactif' };
    var s = state();
    var m = s.missions.filter(function (x) { return x.id === id; })[0];
    var def = EV().missionDef(id);
    if (!m || !def) return { ok: false, reason: 'invalide' };
    if (m.c) return { ok: false, reason: 'deja' };
    if (m.p < def.target) return { ok: false, reason: 'incomplete' };
    m.c = true;
    s.currency += def.currency;
    save();
    return { ok: true, currency: def.currency, total: s.currency };
  }
  function touch() {
    if (!isActive()) return;
    var s = state(), d = EV().dayIndex(_now());
    if (s.lastLoginDay !== d) { s.lastLoginDay = d; track('login', 1); }
  }

  // ---------- Boss ----------
  function bossStatus() {
    var s = state(), ev = info();
    return { hp: s.boss.hp, maxHp: s.boss.max, defeated: s.boss.defeated, name: ev.theme.boss.name, theme: ev.theme };
  }
  function attemptsLeft() {
    var s = state();
    return Math.max(0, EV().maxAttempts(_prestigeTier()) - s.attemptsUsed);
  }
  /** Puissance de l'équipe de combat actuelle, hors héros partis en expédition. */
  function teamPower() {
    var XM = NEBUSTION.ExpeditionManager;
    if (!XM || !NEBUSTION.Combat) return 0;
    var ids = NEBUSTION.Combat.getTeam().filter(function (id) { return !XM.isBusy(id); });
    return XM.teamPowerOf(ids);
  }
  function attackBoss(now) {
    now = now || Date.now();
    if (!isActive()) return { ok: false, reason: 'inactif' };
    var s = state();
    if (s.boss.defeated) return { ok: false, reason: 'vaincu' };
    if (attemptsLeft() <= 0) return { ok: false, reason: 'tentatives' };
    var power = teamPower();
    if (power <= 0) return { ok: false, reason: 'equipe' };
    var atk = EV().resolveAttack(power, (now % 1e9) | 0);
    s.attemptsUsed += 1;
    s.boss.hp = Math.max(0, s.boss.hp - atk.damage);
    s.stats.attacks += 1;
    track('attack', 1);
    track('damage', atk.damage);
    var defeated = false, reward = null;
    if (s.boss.hp <= 0 && !s.boss.defeated) {
      s.boss.defeated = true;
      defeated = true;
      s.stats.bossKills += 1;
      reward = _grantBossReward();
    }
    save();
    return { ok: true, damage: atk.damage, crit: atk.crit, hp: s.boss.hp, maxHp: s.boss.max, defeated: defeated, reward: reward, power: power };
  }
  function _grantBossReward() {
    var ev = info(), rw = EV().bossDefeatReward(ev.theme, ev.cycleIndex);
    var granted = {};
    Object.keys(rw.res).forEach(function (id) { granted[id] = NEBUSTION.Resources.add(id, rw.res[id], 'event') || 0; });
    if (rw.gems > 0 && NEBUSTION.ShopManager) NEBUSTION.ShopManager.addGems(rw.gems);
    var levelUps = [];
    if (rw.fragments > 0 && NEBUSTION.Combat) {
      NEBUSTION.Combat.getTeam().forEach(function (hid) {
        var before = NEBUSTION.Combat.heroLevel(hid);
        NEBUSTION.Combat.addFragments(hid, rw.fragments);
        var after = NEBUSTION.Combat.heroLevel(hid);
        if (after > before) levelUps.push({ heroId: hid, level: after });
      });
    }
    state().currency += rw.currency;
    return { granted: granted, gems: rw.gems, fragments: rw.fragments, currency: rw.currency, levelUps: levelUps };
  }

  // ---------- Boutique événementielle ----------
  function currency() { return state().currency; }
  function shopStatus() {
    var s = state();
    return EV().SHOP_ITEMS.map(function (it) { return Object.assign({ owned: s.purchased[it.id] || 0, left: Math.max(0, it.limit - (s.purchased[it.id] || 0)) }, it); });
  }
  function buyShopItem(id) {
    if (!isActive()) return { ok: false, reason: 'inactif' };
    var it = EV().shopItem(id);
    if (!it) return { ok: false, reason: 'invalide' };
    var s = state();
    if ((s.purchased[id] || 0) >= it.limit) return { ok: false, reason: 'limite' };
    if (s.currency < it.cost) return { ok: false, reason: 'monnaie', cost: it.cost };
    s.currency -= it.cost;
    s.purchased[id] = (s.purchased[id] || 0) + 1;
    var out = { ok: true, item: it };
    if (it.kind === 'res') {
      out.granted = {};
      Object.keys(it.res).forEach(function (rid) { out.granted[rid] = NEBUSTION.Resources.add(rid, it.res[rid], 'event_shop') || 0; });
    } else if (it.kind === 'gems') {
      if (NEBUSTION.ShopManager) NEBUSTION.ShopManager.addGems(it.amount);
      out.granted = { gems: it.amount };
    } else if (it.kind === 'frag_choice') {
      var team = NEBUSTION.Combat ? NEBUSTION.Combat.getTeam() : [];
      var hid = team[0];
      if (hid && NEBUSTION.Combat) NEBUSTION.Combat.addFragments(hid, it.amount);
      out.granted = { heroId: hid, fragments: it.amount };
    }
    save();
    return out;
  }

  // ---------- Branchement sur le jeu existant (sans toucher aux autres systèmes) ----------
  var wired = false;
  function wire() {
    if (wired) return;
    wired = true;
    var C = NEBUSTION.Combat;
    if (C) {
      [['grantRewards', 2], ['grantInvasionRewards', 1]].forEach(function (pair) {
        var name = pair[0], idx = pair[1], orig = C[name];
        if (typeof orig !== 'function') return;
        C[name] = function () { var out = orig.apply(C, arguments), res = arguments[idx]; if (res && res.win) track('win', 1); return out; };
      });
    }
    var XM = NEBUSTION.ExpeditionManager;
    if (XM && typeof XM.claim === 'function') {
      var oClaim = XM.claim;
      XM.claim = function () { var r = oClaim.apply(XM, arguments); if (r && r.ok) track('expedition', 1); return r; };
    }
    try { state(); touch(); } catch (e) { /* ignore */ }
  }

  return {
    defaultState: defaultState, normalizeState: normalizeState,
    info: info, isActive: isActive, now: currentNow, missions: missions, claimableCount: claimableCount, track: track, claimMission: claimMission, touch: touch,
    bossStatus: bossStatus, attemptsLeft: attemptsLeft, attackBoss: attackBoss, teamPower: teamPower,
    currency: currency, shopStatus: shopStatus, buyShopItem: buyShopItem, wire: wire,
    _reset: function () { fallback = null; wired = false; }
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.EventManager; }
