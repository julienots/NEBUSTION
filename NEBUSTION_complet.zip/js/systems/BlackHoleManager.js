/**
 * NEBUSTION - BlackHoleManager
 * Glue entre NEBUSTION.BlackHole (données pures) et la sauvegarde/économie existantes (même
 * schéma que ExpeditionManager/ShopManager). État dans NEBUSTION.Resources.state.blackhole
 * (couvert par la sauvegarde automatique déjà en place).
 *
 * Une plongée en cours (`state().dive`) ne stocke QUE {seed, depth, integrity, lastKind} : les
 * options offertes à chaque profondeur sont recalculées à la demande via BlackHole.choiceOptions
 * (fonction pure) — rien à corrompre, rien à perdre si la page se ferme au milieu d'une descente.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.BlackHoleManager = (function () {
  'use strict';

  var BH = function () { return NEBUSTION.BlackHole; };
  var DAY_MS = 86400000;

  function root() { return NEBUSTION.Resources && NEBUSTION.Resources.state; }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }
  function dayIndex(now) { return Math.floor((Number(now) || Date.now()) / DAY_MS); }

  function defaultState(now) {
    now = now || Date.now();
    return {
      v: 1,
      fragments: 0,
      talents: { hull: 0, prod: 0, luck: 0 },
      charge: { ch: BH().CFG.MAX_CHARGES, t: now },
      exchangeDaily: { day: dayIndex(now), gem: 0 },
      dive: null,
      maxDepth: 0,
      stats: { divesStarted: 0, divesCompleted: 0, divesForced: 0, nodesResolved: 0 }
    };
  }

  function _num(x, min, max, def) { x = Number(x); if (!isFinite(x)) return def; return x < min ? min : (x > max ? max : x); }
  function _int(x, min, max, def) { return Math.floor(_num(x, min, max, def)); }

  function normalizeState(raw, now) {
    now = now || Date.now();
    var s = defaultState(now);
    if (!raw || typeof raw !== 'object') return s;
    s.fragments = _num(raw.fragments, 0, 1e12, 0);
    var rt = raw.talents || {};
    NEBUSTION.BlackHole.TALENT_ORDER.forEach(function (id) {
      s.talents[id] = _int(rt[id], 0, NEBUSTION.BlackHole.TALENTS[id].maxLevel, 0);
    });
    var rc = raw.charge || {};
    s.charge = { ch: _num(rc.ch, 0, BH().CFG.MAX_CHARGES, BH().CFG.MAX_CHARGES), t: _num(rc.t, 0, now, now) };
    var red = raw.exchangeDaily || {};
    var day = _int(red.day, 0, 1e9, dayIndex(now));
    s.exchangeDaily = day === dayIndex(now) ? { day: day, gem: _int(red.gem, 0, 1e6, 0) } : { day: dayIndex(now), gem: 0 };
    s.maxDepth = _int(raw.maxDepth, 0, 1e9, 0);
    var rs = raw.stats || {};
    s.stats = {
      divesStarted: _int(rs.divesStarted, 0, 1e9, 0), divesCompleted: _int(rs.divesCompleted, 0, 1e9, 0),
      divesForced: _int(rs.divesForced, 0, 1e9, 0), nodesResolved: _int(rs.nodesResolved, 0, 1e12, 0)
    };
    var rd = raw.dive;
    if (rd && typeof rd === 'object' && isFinite(Number(rd.seed))) {
      var depth = _int(rd.depth, 0, 1e9, 0);
      var maxI = NEBUSTION.BlackHole.maxIntegrity(s.talents);
      s.dive = {
        seed: (Number(rd.seed) >>> 0), depth: depth,
        integrity: _num(rd.integrity, 0, maxI, maxI),
        lastKind: (typeof rd.lastKind === 'string') ? rd.lastKind : null
      };
    } else { s.dive = null; }
    return s;
  }

  function state() {
    var r = root();
    if (!r) return defaultState();
    if (!r.blackhole) r.blackhole = defaultState();
    return r.blackhole;
  }

  // ---------- Lecture ----------
  function fragments() { return state().fragments; }
  function talents() { return state().talents; }
  function talentLevel(id) { return NEBUSTION.BlackHole.talentLevel(talents(), id); }
  function talentCost(id) { return NEBUSTION.BlackHole.talentCost(id, talentLevel(id)); }
  function maxIntegrity() { return NEBUSTION.BlackHole.maxIntegrity(talents()); }
  function maxDepthReached() { return state().maxDepth; }
  function bestZone() { return state().maxDepth > 0 ? NEBUSTION.BlackHole.zoneForDepth(state().maxDepth) : null; }
  function stats() { return state().stats; }

  // ---------- Charges (plongées "fraîches") ----------
  function _availableFloat(now) {
    var c = state().charge, cfg = NEBUSTION.BlackHole.CFG;
    var v = c.ch + Math.max(0, (now || Date.now()) - c.t) / cfg.CHARGE_REGEN_MS;
    return Math.min(cfg.MAX_CHARGES, Math.max(0, v));
  }
  function chargesAvailable(now) { return Math.floor(_availableFloat(now)); }
  function msToNextCharge(now) {
    now = now || Date.now();
    var av = _availableFloat(now), cfg = NEBUSTION.BlackHole.CFG;
    if (av >= cfg.MAX_CHARGES - 1e-9) return 0;
    var frac = av - Math.floor(av);
    return Math.round(cfg.CHARGE_REGEN_MS * (1 - frac));
  }
  function _spendCharge(now) {
    var av = _availableFloat(now);
    if (av < 1 - 1e-9) return false;
    var c = state().charge;
    c.ch = av - 1; c.t = now;
    return true;
  }

  // ---------- Puissance d'équipe actuelle (réutilise ExpeditionManager, déjà testé) ----------
  function teamPower() {
    try {
      if (NEBUSTION.ExpeditionManager && NEBUSTION.Combat) return NEBUSTION.ExpeditionManager.teamPowerOf(NEBUSTION.Combat.getTeam());
    } catch (e) { /* ignore */ }
    return 0;
  }
  function currentRates() {
    try { return (NEBUSTION.Resources && NEBUSTION.Resources.rates) ? NEBUSTION.Resources.rates() : {}; } catch (e) { return {}; }
  }

  // ---------- Plongée ----------
  function hasActiveDive() { return !!state().dive; }
  function diveSnapshot() {
    var d = state().dive;
    if (!d) return null;
    return {
      depth: d.depth, integrity: d.integrity, maxIntegrity: maxIntegrity(), lastKind: d.lastKind,
      zone: NEBUSTION.BlackHole.zoneForDepth(Math.max(1, d.depth || 1))
    };
  }
  /** Options pour la PROCHAINE profondeur, annotées d'un libellé de danger pour l'écran. */
  function currentOptions() {
    var d = state().dive;
    if (!d) return [];
    var nextDepth = d.depth + 1;
    return NEBUSTION.BlackHole.choiceOptions(d.seed, nextDepth).map(function (o) {
      var label = o.forced === 'abime' ? { label: 'Seuil de la Singularité', hex: '#ffd166' } : NEBUSTION.BlackHole.DANGER_LABELS[o.danger];
      return { idx: o.idx, danger: o.danger, forced: o.forced, label: label.label, hex: label.hex };
    });
  }

  function startOrResumeDive(now) {
    now = now || Date.now();
    if (state().dive) return { ok: true, resumed: true, dive: diveSnapshot() };
    if (chargesAvailable(now) < 1) return { ok: false, reason: 'no_charge', msLeft: msToNextCharge(now) };
    _spendCharge(now);
    var s = state();
    s.dive = { seed: ((now ^ Math.floor(Math.random() * 0x7fffffff)) >>> 0), depth: 0, integrity: maxIntegrity(), lastKind: null };
    s.stats.divesStarted += 1;
    save();
    return { ok: true, resumed: false, dive: diveSnapshot() };
  }

  /** Choisit l'option `optionIdx` parmi currentOptions() et applique le résultat (une seule fois, atomique). */
  function chooseNode(optionIdx, now) {
    now = now || Date.now();
    var s = state(), d = s.dive;
    if (!d) return { ok: false, reason: 'aucune_plongee' };
    var opts = NEBUSTION.BlackHole.choiceOptions(d.seed, d.depth + 1);
    var chosen = null;
    for (var i = 0; i < opts.length; i++) { if (opts[i].idx === optionIdx) { chosen = opts[i]; break; } }
    if (!chosen) return { ok: false, reason: 'option_invalide' };

    var nextDepth = d.depth + 1;
    var outcome = NEBUSTION.BlackHole.resolveChoice({
      seed: d.seed, depth: nextDepth, option: chosen, teamPower: teamPower(), rates: currentRates(), talents: s.talents
    });

    // Application atomique : tout est calculé AVANT toute mutation de state/dive.
    var R = NEBUSTION.Resources, granted = {};
    Object.keys(outcome.resources).forEach(function (id) { if (R) granted[id] = R.add(id, outcome.resources[id], 'blackhole') || 0; });
    if (outcome.fragments > 0) s.fragments += outcome.fragments;
    if (outcome.gems > 0 && NEBUSTION.ShopManager) NEBUSTION.ShopManager.addGems(outcome.gems);

    var newIntegrity = Math.max(0, Math.min(maxIntegrity(), d.integrity + outcome.integrityDelta));
    d.depth = nextDepth; d.integrity = newIntegrity; d.lastKind = outcome.kind;
    s.stats.nodesResolved += 1;
    if (nextDepth > s.maxDepth) s.maxDepth = nextDepth;

    var forcedEnd = newIntegrity <= 0;
    if (forcedEnd) { s.dive = null; s.stats.divesForced += 1; }
    save();

    return {
      ok: true, outcome: { kind: outcome.kind, title: outcome.title, body: outcome.body, resources: granted, fragments: outcome.fragments, gems: outcome.gems, success: outcome.success, ratio: outcome.ratio },
      depth: nextDepth, integrity: newIntegrity, maxIntegrity: maxIntegrity(), forcedEnd: forcedEnd,
      zone: NEBUSTION.BlackHole.zoneForDepth(nextDepth)
    };
  }

  /** Remontée volontaire : ne coûte jamais rien de ce qui a déjà été gagné. Bonus si le dernier nœud était un point d'ancrage. */
  function retreat() {
    var s = state(), d = s.dive;
    if (!d) return { ok: false, reason: 'aucune_plongee' };
    var bonus = 0;
    if (d.lastKind === 'sanctuaire') {
      bonus = Math.max(1, Math.round(2 + NEBUSTION.BlackHole.zoneMultAt(Math.max(1, d.depth))));
      s.fragments += bonus;
    }
    var reachedDepth = d.depth;
    s.dive = null;
    s.stats.divesCompleted += 1;
    save();
    return { ok: true, depth: reachedDepth, bonus: bonus };
  }

  // ---------- Améliorations permanentes ----------
  function buyTalent(id) {
    var cost = talentCost(id);
    if (cost === null) return { ok: false, reason: 'max_ou_invalide' };
    if (fragments() < cost) return { ok: false, reason: 'fragments', cost: cost };
    var s = state();
    s.fragments -= cost;
    s.talents[id] = talentLevel(id) + 1;
    // La coque renforcée peut agrandir l'intégrité max pendant une plongée en cours : jamais de perte relative.
    if (id === 'hull' && s.dive) s.dive.integrity = Math.min(maxIntegrity(), s.dive.integrity + NEBUSTION.BlackHole.TALENTS.hull.perLevel);
    save();
    return { ok: true, level: s.talents[id], cost: cost };
  }

  // ---------- Comptoir de l'Abîme ----------
  function _dailyGem(now) {
    var s = state(), idx = dayIndex(now || Date.now());
    if (s.exchangeDaily.day !== idx) s.exchangeDaily = { day: idx, gem: 0 };
    return s.exchangeDaily;
  }
  function exchangeOffers(now) {
    now = now || Date.now();
    var rates = currentRates(), gemLeft = Math.max(0, 3 - _dailyGem(now).gem);
    return NEBUSTION.BlackHole.EXCHANGE_OFFERS.map(function (o) {
      var isGem = !!o.gem;
      return {
        id: o.id, resId: o.resId || null, gem: o.gem || 0, cost: o.cost,
        amount: isGem ? o.gem : NEBUSTION.BlackHole.exchangeAmount(o, rates),
        afford: fragments() >= o.cost && (!isGem || gemLeft > 0),
        dailyLeft: isGem ? gemLeft : null
      };
    });
  }
  function buyExchange(id, now) {
    now = now || Date.now();
    var offer = NEBUSTION.BlackHole.exchangeOffer(id);
    if (!offer) return { ok: false, reason: 'invalide' };
    if (fragments() < offer.cost) return { ok: false, reason: 'fragments' };
    var s = state();
    if (offer.gem) {
      var gd = _dailyGem(now);
      if (gd.gem >= 3) return { ok: false, reason: 'limite_quotidienne' };
      s.fragments -= offer.cost;
      gd.gem += 1;
      if (NEBUSTION.ShopManager) NEBUSTION.ShopManager.addGems(offer.gem);
      save();
      return { ok: true, gem: offer.gem };
    }
    var amount = NEBUSTION.BlackHole.exchangeAmount(offer, currentRates());
    s.fragments -= offer.cost;
    var granted = NEBUSTION.Resources ? (NEBUSTION.Resources.add(offer.resId, amount, 'blackhole_exchange') || 0) : amount;
    save();
    return { ok: true, resId: offer.resId, amount: granted };
  }

  return {
    defaultState: defaultState, normalizeState: normalizeState,
    fragments: fragments, talents: talents, talentLevel: talentLevel, talentCost: talentCost, buyTalent: buyTalent,
    maxIntegrity: maxIntegrity, maxDepthReached: maxDepthReached, bestZone: bestZone, stats: stats,
    chargesAvailable: chargesAvailable, msToNextCharge: msToNextCharge,
    hasActiveDive: hasActiveDive, diveSnapshot: diveSnapshot, currentOptions: currentOptions,
    startOrResumeDive: startOrResumeDive, chooseNode: chooseNode, retreat: retreat,
    exchangeOffers: exchangeOffers, buyExchange: buyExchange, teamPower: teamPower
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.BlackHoleManager; }
