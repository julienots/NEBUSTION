/**
 * NEBUSTION - SocialManager
 * Interactions entre joueurs : VRAIS joueurs (Firebase Firestore, si compte connecté) + faux joueurs (bots uniques,
 * voir js/data/Social.js) + clans (vrais clans Firestore et clans de bots). Tout est facultatif et sans risque :
 *  - sans compte / sans réseau / sans règles Firestore publiées : seuls les bots sont visibles, le jeu reste intact ;
 *  - l'état local (pseudo, amis, clan, limites du jour, boîte de cadeaux) est dans la sauvegarde (clé `social`).
 * Collections Firestore utilisées : players, clans (+ clans/{id}/messages), chat_global, gifts — règles dans FIRESTORE_RULES_SOCIAL.txt.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.SocialManager = (function () {
  'use strict';
  var S = function () { return NEBUSTION.Social; };
  var timer = null, lastPublish = 0, pending = [], seq = 0;   // pending : cadeaux de bots programmés { at, msg }

  function R() { return NEBUSTION.Resources; }
  function now() { return Date.now(); }

  // ---------------------------------------------------------------- État local
  function state() {
    var r = R(); if (!r || !r.state) return S().defaultState();
    if (!r.state.social || r.state.social.v !== 1 || !r.state.social.gifts) r.state.social = S().normalizeState(r.state.social);
    var st = r.state.social;
    if (!st.name) st.name = S().defaultName((cloudUser() && cloudUser().uid) || (NEBUSTION.CloudSave && NEBUSTION.CloudSave._deviceId && NEBUSTION.CloudSave._deviceId()) || 'x');
    return st;
  }
  function touch() { try { var r = R(); if (r && r._dirtyNow) r._dirtyNow(); } catch (e) { /* ignore */ } }
  function dayReset(o) { var d = S().dayOf(now()); if (o.day !== d) { o.day = d; o.n = 0; } return o; }

  // ---------------------------------------------------------------- Joueur local
  function playerStats() {
    var lvl = 1, power = 0;
    try { lvl = Math.max(1, R().level('command') || 1); } catch (e) { /* ignore */ }
    try { if (NEBUSTION.ShipManager) power += NEBUSTION.ShipManager.fleetPower() || 0; } catch (e) { /* ignore */ }
    try { if (NEBUSTION.EventManager && NEBUSTION.EventManager.teamPower) power += NEBUSTION.EventManager.teamPower() || 0; } catch (e) { /* ignore */ }
    return { level: lvl, power: Math.round(power) };
  }
  function me() {
    var st = state(), ps = playerStats(), u = cloudUser();
    return { uid: u ? u.uid : null, name: st.name, level: ps.level, power: ps.power, clan: st.clan };
  }
  function setName(name) {
    if (!S().validName(name)) return { ok: false, error: 'Pseudo invalide (3 à 16 caractères, lettres/chiffres).' };
    state().name = S().cleanName(name, 16); touch(); publishProfile(true);
    return { ok: true };
  }

  // ---------------------------------------------------------------- Firebase (facultatif)
  function db() { try { return NEBUSTION.CloudSave && NEBUSTION.CloudSave.getDb ? NEBUSTION.CloudSave.getDb() : null; } catch (e) { return null; } }
  function cloudUser() { try { return NEBUSTION.CloudSave && NEBUSTION.CloudSave.currentUser ? NEBUSTION.CloudSave.currentUser() : null; } catch (e) { return null; } }
  function online() { return !!(db() && cloudUser()); }
  function fs() { return (typeof firebase !== 'undefined' && firebase.firestore) ? firebase.firestore : null; }
  function err(e) {
    var c = e && e.code;
    if (c === 'permission-denied') return 'Règles Firestore non publiées (voir LISEZMOI_SOCIAL.md).';
    if (c === 'unavailable' || c === 'failed-precondition') return 'Pas de connexion.';
    return (e && e.message) || 'Erreur réseau.';
  }

  /** Publie le profil public (nom, niveau, puissance, clan) — au plus 1 fois / 45 s sauf force. */
  function publishProfile(force) {
    if (!online()) return Promise.resolve(false);
    var t = now(); if (!force && t - lastPublish < 45000) return Promise.resolve(false);
    lastPublish = t;
    var m = me(), st = state();
    return db().collection('players').doc(m.uid).set({
      uid: m.uid, name: m.name, level: m.level, power: m.power, clanId: st.clan ? st.clan.id : '', clanTag: st.clan ? st.clan.tag : '', updatedAt: t
    }).then(function () { return true; }).catch(function () { return false; });
  }

  function start() {
    if (timer) return;
    var ticks = 0;
    timer = setInterval(function () { publishProfile(false); flushPending(); if (++ticks % 10 === 0) pullRealGifts(); }, 30000);
    publishProfile(true);
  }
  function stop() { if (timer) { clearInterval(timer); timer = null; } }

  // ---------------------------------------------------------------- Joueurs (vrais + bots)
  function botEntry(b, ctx, t) {
    var st = S().botStats(b, ctx, t), s = S().botStatus(b, t);
    var c = b.clanId ? S().botClanById(b.clanId) : null;
    return { id: b.id, uid: null, name: b.name, isBot: true, level: st.level, power: st.power, status: s.state, lastSeen: s.lastSeen, bio: b.bio, arch: S().ARCH[b.arch].label,
      avatar: b.avatar, clanId: b.clanId, clanTag: c ? c.tag : '', clanName: c ? c.name : '' };
  }
  function realEntry(d, t) {
    var on = t - (d.updatedAt || 0) < S().CFG.ONLINE_MS;
    var h = S().hash(d.uid || d.name);
    return { id: d.uid, uid: d.uid, name: d.name || 'Joueur', isBot: false, level: d.level || 1, power: d.power || 0, status: on ? 'online' : 'offline', lastSeen: d.updatedAt || 0, bio: '',
      arch: 'Joueur réel', avatar: { hue: h % 360, glyph: '★', shape: h % 3 }, clanId: d.clanId || '', clanTag: d.clanTag || '', clanName: '' };
  }
  var ORDER = { online: 0, away: 1, offline: 2 };

  /** Liste combinée : vrais joueurs d'abord (s'il y en a), puis bots. Promesse → { list, realOk, realError }. */
  function listPlayers(opts) {
    opts = opts || {};
    var t = now(), m = me(), ctx = { power: m.power, level: m.level }, filter = opts.filter || 'all';
    var botsL = S().bots().map(function (b) { return botEntry(b, ctx, t); });
    function finish(real, realOk, realError) {
      var all = real.concat(botsL);
      if (filter === 'online') all = all.filter(function (p) { return p.status === 'online'; });
      if (filter === 'friends') { var fr = state().friends; all = all.filter(function (p) { return fr.indexOf(p.id) >= 0; }); }
      if (opts.query) { var q = String(opts.query).toLowerCase(); all = all.filter(function (p) { return p.name.toLowerCase().indexOf(q) >= 0; }); }
      all.sort(function (a, b) {
        if (a.isBot !== b.isBot && a.status === 'online' && b.status === 'online') return a.isBot ? 1 : -1;
        return (ORDER[a.status] - ORDER[b.status]) || (b.power - a.power);
      });
      return { list: all, realOk: realOk, realError: realError, realCount: real.length };
    }
    if (!online()) return Promise.resolve(finish([], false, cloudUser() ? null : 'Connecte-toi (Paramètres → Compte) pour voir les vrais joueurs.'));
    return db().collection('players').orderBy('updatedAt', 'desc').limit(60).get().then(function (snap) {
      var real = []; snap.forEach(function (d) { var x = d.data(); if (x && x.uid && x.uid !== m.uid) real.push(realEntry(x, t)); });
      return finish(real, true, null);
    }).catch(function (e) { return finish([], false, err(e)); });
  }

  function playerById(id) {
    var b = S().botById(id); if (b) { var m = me(); return Promise.resolve(botEntry(b, { power: m.power, level: m.level }, now())); }
    if (!online()) return Promise.resolve(null);
    return db().collection('players').doc(id).get().then(function (d) { return d.exists ? realEntry(d.data(), now()) : null; }).catch(function () { return null; });
  }

  // ---------------------------------------------------------------- Amis
  function isFriend(id) { return state().friends.indexOf(id) >= 0; }
  function toggleFriend(id) {
    var st = state(), i = st.friends.indexOf(id);
    if (i >= 0) st.friends.splice(i, 1); else { if (st.friends.length >= 100) return { ok: false, error: 'Liste d\'amis pleine (100).' }; st.friends.push(id); }
    touch(); return { ok: true, friend: i < 0 };
  }

  // ---------------------------------------------------------------- Cadeaux
  function giftsLeft() { var g = dayReset(state().gifts); return Math.max(0, S().CFG.GIFT_DAILY - g.n); }
  function sendGift(target) {
    var C = S().CFG, st = state();
    if (giftsLeft() <= 0) return Promise.resolve({ ok: false, error: 'Limite de ' + C.GIFT_DAILY + ' cadeaux par jour atteinte.' });
    if (!R().canAfford({ crystal: C.GIFT_COST })) return Promise.resolve({ ok: false, error: 'Il faut ' + C.GIFT_COST + ' cristaux.' });
    function done() { R().spend('crystal', C.GIFT_COST); st.gifts.n++; st.sentTotal++; touch(); }
    if (target.isBot) {
      done();
      var b = S().botById(target.id), back = b && S().giftBack(b.seed, S().dayOf(now()) + st.gifts.n);
      if (back) pending.push({ at: now() + back.delayMs, msg: { id: 'g' + now() + '_' + (++seq) + '_' + b.id, from: b.id, name: b.name, res: 'crystal', amount: back.crystal, t: now() + back.delayMs, real: false } });
      return Promise.resolve({ ok: true, back: !!back });
    }
    if (!online()) return Promise.resolve({ ok: false, error: 'Connecte-toi pour envoyer un cadeau à un vrai joueur.' });
    var m = me();
    return db().collection('gifts').add({ to: target.uid, from: m.uid, fromName: m.name, res: 'crystal', amount: C.GIFT_COST, t: now() })
      .then(function () { done(); return { ok: true, back: false }; }).catch(function (e) { return { ok: false, error: err(e) }; });
  }
  function flushPending() {
    var t = now(), st = state(), moved = false;
    pending = pending.filter(function (p) { if (p.at <= t) { st.inbox.push(p.msg); moved = true; return false; } return true; });
    if (st.inbox.length > 30) st.inbox = st.inbox.slice(-30);
    if (moved) touch();
    return moved;
  }
  /** Cadeaux de vrais joueurs en attente → boîte locale (une seule fois : le document est supprimé avant crédit). */
  function pullRealGifts() {
    if (!online()) return Promise.resolve(0);
    var m = me();
    return db().collection('gifts').where('to', '==', m.uid).limit(20).get().then(function (snap) {
      var jobs = [];
      snap.forEach(function (d) {
        var x = d.data();
        jobs.push(d.ref.delete().then(function () {
          state().inbox.push({ id: 'r' + d.id, from: x.from, name: S().cleanName(x.fromName, 16), res: 'crystal', amount: Math.max(0, Math.min(500, Number(x.amount) || 0)), t: x.t || now(), real: true });
          return 1;
        }).catch(function () { return 0; }));
      });
      return Promise.all(jobs).then(function (a) { var n = a.reduce(function (s, v) { return s + v; }, 0); if (n) touch(); return n; });
    }).catch(function () { return 0; });
  }
  function inbox() { flushPending(); return state().inbox.slice(); }
  function claimGift(id) {
    var st = state(), i = st.inbox.findIndex(function (m) { return m.id === id; });
    if (i < 0) return { ok: false, error: 'Cadeau introuvable.' };
    var g = st.inbox[i], got = R().add(g.res || 'crystal', g.amount, 'gift');
    if (!(got > 0) && R().isFull(g.res || 'crystal')) return { ok: false, error: 'Stockage plein : libère de la place.' };
    st.inbox.splice(i, 1); touch();
    return { ok: true, amount: Math.round(got), res: g.res || 'crystal', name: g.name };
  }

  // ---------------------------------------------------------------- Duel amical (contre un bot ou le profil d'un vrai joueur)
  function duelsLeft() { var d = dayReset(state().duels); return Math.max(0, S().CFG.DUEL_DAILY - d.n); }
  function duel(target) {
    var st = state(); if (duelsLeft() <= 0) return { ok: false, error: 'Limite de ' + S().CFG.DUEL_DAILY + ' duels par jour atteinte.' };
    var m = me(), seed = S().hash(target.id + ':' + S().dayOf(now()) + ':' + st.duels.n + ':' + Math.floor(now() / 60000));
    var res = S().duel(m.power, target.power, seed);
    st.duels.n++; if (res.win) st.wins++;
    var rw = S().duelReward(target.level, res.win), got = {};
    Object.keys(rw).forEach(function (k) { got[k] = Math.round(R().add(k, rw[k], 'duel') || 0); });
    touch();
    return { ok: true, win: res.win, chance: res.chance, reward: got, myPower: m.power, theirPower: target.power };
  }

  // ---------------------------------------------------------------- Chat
  var lastSend = 0;
  function canSend(text) {
    if (!S().chatAllowed(text)) return { ok: false, error: 'Message vide ou non autorisé.' };
    if (now() - lastSend < 1500) return { ok: false, error: 'Doucement… un message toutes les 2 secondes.' };
    return { ok: true };
  }
  /** Historique combiné (bots + vrais) d'un canal ; onUpdate(list) rappelé à chaque nouveau message réel. Renvoie une fonction d'arrêt. */
  function watchChat(channel, opts, onUpdate) {
    opts = opts || {};
    var real = [], stopped = false, unsub = null, localExtra = [];   // localExtra : messages du joueur + réponses de bots (pour les canaux 100 % bots)
    var col = null;
    if (online()) {
      try { col = channel === 'global' ? db().collection('chat_global') : (opts.realClanId ? db().collection('clans').doc(opts.realClanId).collection('messages') : null); } catch (e) { col = null; }
    }
    function compose() {
      var pool = opts.pool || S().bots();
      var botsMsgs = opts.noBots ? [] : S().chatHistory(channel, now(), { pool: pool, kind: opts.kind || 'global', density: opts.density !== undefined ? opts.density : 0.5 });
      var all = botsMsgs.concat(real).concat(localExtra).sort(function (a, b) { return a.t - b.t; });
      return all.slice(-60);
    }
    function push() { if (!stopped && onUpdate) onUpdate(compose()); }
    if (col) {
      try {
        unsub = col.orderBy('t', 'desc').limit(40).onSnapshot(function (snap) {
          real = []; snap.forEach(function (d) { var x = d.data(); real.push({ id: d.id, t: x.t || 0, from: x.uid, name: S().cleanName(x.name, 16), text: S().cleanText(x.text), isBot: false, real: true }); });
          push();
        }, function () { /* règles absentes : bots seuls */ });
      } catch (e) { unsub = null; }
    }
    var iv = setInterval(push, 8000);
    setTimeout(push, 0);   // différé : l'appelant doit d'abord recevoir le contrôleur
    return {
      stop: function () { stopped = true; clearInterval(iv); if (unsub) { try { unsub(); } catch (e) { /* ignore */ } } },
      refresh: push,
      send: function (text) {
        var c = canSend(text); if (!c.ok) return Promise.resolve(c);
        lastSend = now(); text = S().cleanText(text); var m = me();
        function afterSend() {
          var pool = opts.pool || S().bots(), rp = S().chatReply(channel, text, now(), pool);
          if (rp) setTimeout(function () { localExtra.push({ id: 'r' + now(), t: now(), from: rp.bot.id, name: rp.bot.name, text: rp.text, isBot: true }); if (localExtra.length > 10) localExtra.shift(); push(); }, rp.delayMs);
        }
        if (col) {
          return col.add({ uid: m.uid, name: m.name, text: text, t: now() }).then(function () { afterSend(); return { ok: true }; }).catch(function (e) { return { ok: false, error: err(e) }; });
        }
        localExtra.push({ id: 'me' + now(), t: now(), from: 'me', name: m.name, text: text, isBot: false, mine: true }); afterSend(); push();
        return Promise.resolve({ ok: true });
      }
    };
  }

  // ---------------------------------------------------------------- Clans
  function myClan() { return state().clan; }
  function clanLine(c) { return { id: c.id, name: c.name, tag: c.tag, motto: c.motto || '', color: c.color, glyph: c.glyph, isBot: !!c.isBot, level: c.level, size: c.size, power: c.power, open: c.open !== false, minLevel: c.minLevel || 1, online: c.online || 0, xp: c.xp || 0 }; }

  function realClanView(d, id) {
    var members = (d.members || []).map(function (x) {
      return { id: x.uid, uid: x.uid, name: x.name, isBot: false, power: x.power || 0, level: x.level || 1, role: x.uid === d.leader ? 'leader' : (x.role || 'member'), status: 'offline' };
    });
    var total = members.reduce(function (s, m) { return s + m.power; }, 0), xp = d.xp || 0;
    return { id: id, name: d.name, tag: d.tag, motto: d.motto || '', color: d.color || 0x4fc3ff, glyph: d.glyph || '★', isBot: false, minLevel: d.minLevel || 1, open: d.open !== false,
      members: members, size: members.length, power: total, xp: xp, level: S().clanLevel(xp), online: 0, leader: d.leader };
  }

  function listClans() {
    var m = me(), ctx = { power: m.power, level: m.level };
    var botL = S().botClans().map(function (c) { return clanLine(S().botClanView(c.id, ctx, now())); });
    function finish(real, ok, e) {
      var all = real.concat(botL).sort(function (a, b) { return (b.isBot ? 0 : 1) - (a.isBot ? 0 : 1) || b.level - a.level || b.power - a.power; });
      return { list: all, realOk: ok, realError: e, realCount: real.length };
    }
    if (!online()) return Promise.resolve(finish([], false, 'Connecte-toi pour voir les clans de vrais joueurs.'));
    return db().collection('clans').orderBy('xp', 'desc').limit(30).get().then(function (snap) {
      var real = []; snap.forEach(function (d) { real.push(clanLine(realClanView(d.data(), d.id))); });
      return finish(real, true, null);
    }).catch(function (e) { return finish([], false, err(e)); });
  }
  function clanView(id, isBot) {
    var m = me();
    if (isBot || S().botClanById(id)) return Promise.resolve(S().botClanView(id, { power: m.power, level: m.level }, now()));
    if (!online()) return Promise.resolve(null);
    return db().collection('clans').doc(id).get().then(function (d) { return d.exists ? realClanView(d.data(), d.id) : null; }).catch(function () { return null; });
  }

  function setClanLocal(v, role) {
    var st = state();
    st.clan = v ? { id: v.id, kind: v.isBot ? 'bot' : 'real', name: v.name, tag: v.tag, role: role || 'member', joinedAt: now() } : null;
    touch(); publishProfile(true);
  }

  function createClan(name, tag, motto) {
    var st = state(), m = me();
    if (st.clan) return Promise.resolve({ ok: false, error: 'Tu es déjà dans un clan.' });
    name = S().cleanName(name, 20); tag = String(tag || '').toUpperCase();
    if (!S().validName(name)) return Promise.resolve({ ok: false, error: 'Nom de clan invalide (3 à 20 caractères).' });
    if (!S().validTag(tag)) return Promise.resolve({ ok: false, error: 'Tag invalide : 2 à 4 lettres/chiffres.' });
    if (!online()) return Promise.resolve({ ok: false, error: 'Connecte-toi pour créer un vrai clan.' });
    if (!R().canAfford({ crystal: S().CFG.CLAN_CREATE_COST })) return Promise.resolve({ ok: false, error: 'Il faut ' + S().CFG.CLAN_CREATE_COST + ' cristaux.' });
    var F = fs(), ref = db().collection('clans').doc(), color = [0xff4d6d, 0x4fc3ff, 0xffd166, 0x5fd97a, 0xb28dff, 0x00e5ff][S().hash(tag) % 6];
    return db().collection('clans').where('tag', '==', tag).limit(1).get().then(function (snap) {
      if (!snap.empty) return { ok: false, error: 'Ce tag est déjà pris.' };
      return ref.set({ name: name, tag: tag, motto: S().cleanText(motto || '').slice(0, 60), color: color, glyph: '★', leader: m.uid, open: true, minLevel: 1, xp: 0, createdAt: now(),
        members: [{ uid: m.uid, name: m.name, power: m.power, level: m.level, role: 'leader' }], memberUids: [m.uid] }).then(function () {
        R().spend('crystal', S().CFG.CLAN_CREATE_COST);
        setClanLocal({ id: ref.id, name: name, tag: tag, isBot: false }, 'leader');
        return { ok: true, id: ref.id };
      });
    }).catch(function (e) { return { ok: false, error: err(e) }; });
  }

  function joinClan(view) {
    var st = state(), m = me();
    if (st.clan) return Promise.resolve({ ok: false, error: 'Quitte d\'abord ton clan actuel.' });
    if (view.minLevel > m.level) return Promise.resolve({ ok: false, error: 'Niveau ' + view.minLevel + ' requis (tu es niveau ' + m.level + ').' });
    if (view.open === false) return Promise.resolve({ ok: false, error: 'Clan sur invitation uniquement.' });
    if (view.size >= S().CLAN_MAX) return Promise.resolve({ ok: false, error: 'Clan complet (' + S().CLAN_MAX + ').' });
    if (view.isBot) { setClanLocal(view, 'member'); return Promise.resolve({ ok: true }); }
    if (!online()) return Promise.resolve({ ok: false, error: 'Connecte-toi pour rejoindre ce clan.' });
    var ref = db().collection('clans').doc(view.id);
    return db().runTransaction(function (tx) {
      return tx.get(ref).then(function (d) {
        if (!d.exists) throw { code: 'gone' };
        var x = d.data(), mem = (x.members || []).slice();
        if (mem.length >= S().CLAN_MAX) throw { code: 'full' };
        if (!mem.some(function (o) { return o.uid === m.uid; })) mem.push({ uid: m.uid, name: m.name, power: m.power, level: m.level, role: 'member' });
        tx.update(ref, { members: mem, memberUids: mem.map(function (o) { return o.uid; }) });
      });
    }).then(function () { setClanLocal(view, 'member'); return { ok: true }; })
      .catch(function (e) { return { ok: false, error: e && e.code === 'gone' ? 'Ce clan n\'existe plus.' : (e && e.code === 'full' ? 'Clan complet.' : err(e)) }; });
  }

  function leaveClan() {
    var st = state(), c = st.clan; if (!c) return Promise.resolve({ ok: true });
    if (c.kind === 'bot' || !online()) { setClanLocal(null); return Promise.resolve({ ok: true }); }
    var m = me(), ref = db().collection('clans').doc(c.id);
    return db().runTransaction(function (tx) {
      return tx.get(ref).then(function (d) {
        if (!d.exists) return;
        var x = d.data(), mem = (x.members || []).filter(function (o) { return o.uid !== m.uid; });
        if (!mem.length) { tx.delete(ref); return; }
        tx.update(ref, { members: mem, memberUids: mem.map(function (o) { return o.uid; }), leader: x.leader === m.uid ? mem[0].uid : x.leader });
      });
    }).then(function () { setClanLocal(null); return { ok: true }; }).catch(function (e) { return { ok: false, error: err(e) }; });
  }

  function donateLeft() { var d = dayReset(state().donate); return Math.max(0, S().CFG.CLAN_DONATE_DAILY - d.n); }
  function donate() {
    var st = state(), c = st.clan, C = S().CFG; if (!c) return Promise.resolve({ ok: false, error: 'Pas de clan.' });
    if (donateLeft() <= 0) return Promise.resolve({ ok: false, error: 'Limite de ' + C.CLAN_DONATE_DAILY + ' dons par jour atteinte.' });
    if (!R().canAfford({ crystal: C.CLAN_DONATE })) return Promise.resolve({ ok: false, error: 'Il faut ' + C.CLAN_DONATE + ' cristaux.' });
    function paid() { R().spend('crystal', C.CLAN_DONATE); st.donate.n++; touch(); return { ok: true, xp: C.CLAN_DONATE_XP }; }
    if (c.kind === 'bot' || !online()) { return Promise.resolve(paid()); }
    return db().collection('clans').doc(c.id).update({ xp: fs().FieldValue.increment(C.CLAN_DONATE_XP) }).then(paid).catch(function (e) { return { ok: false, error: err(e) }; });
  }
  function chestReady() { var st = state(); return !!st.clan && S().dayOf(now()) !== S().dayOf(st.lastChest || 0); }
  function claimChest(level) {
    var st = state(); if (!st.clan) return { ok: false, error: 'Pas de clan.' };
    if (!chestReady()) return { ok: false, error: 'Coffre déjà récupéré aujourd\'hui.' };
    var rw = S().clanChest(level || 1), got = {}, any = false;
    Object.keys(rw).forEach(function (k) { got[k] = Math.round(R().add(k, rw[k], 'clan') || 0); if (got[k] > 0) any = true; });
    if (!any) return { ok: false, error: 'Stockage plein : libère de la place.' };
    st.lastChest = now(); touch(); return { ok: true, reward: got };
  }
  function clanChannel() { var c = state().clan; return c ? 'clan:' + c.id : null; }
  function clanChatOpts(view) {
    var c = state().clan; if (!c) return null;
    if (c.kind === 'bot') return { pool: S().botClanById(c.id).members.map(S().botById), kind: 'clan', density: 0.7 };
    return { realClanId: c.id, noBots: true, kind: 'clan' };
  }

  return {
    state: state, me: me, setName: setName, playerStats: playerStats, start: start, stop: stop, online: online, publishProfile: publishProfile,
    listPlayers: listPlayers, playerById: playerById, isFriend: isFriend, toggleFriend: toggleFriend,
    giftsLeft: giftsLeft, sendGift: sendGift, inbox: inbox, pullRealGifts: pullRealGifts, claimGift: claimGift, flushPending: flushPending,
    duelsLeft: duelsLeft, duel: duel, watchChat: watchChat,
    myClan: myClan, listClans: listClans, clanView: clanView, createClan: createClan, joinClan: joinClan, leaveClan: leaveClan,
    donateLeft: donateLeft, donate: donate, chestReady: chestReady, claimChest: claimChest, clanChannel: clanChannel, clanChatOpts: clanChatOpts,
    _pending: function () { return pending; }, _resetThrottle: function () { lastSend = 0; }
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.SocialManager; }
