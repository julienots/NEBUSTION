/**
 * NEBUSTION - ExpeditionManager
 * Glue entre NEBUSTION.Expeditions (données pures) et la sauvegarde/économie existantes
 * (même schéma que ShopManager/PassManager). État dans NEBUSTION.Resources.state.expeditions
 * (couvert par la sauvegarde automatique déjà en place : hors ligne, une expédition continue
 * de « courir » car ses dates sont absolues, et se réclame au retour).
 *
 * Un héros envoyé en expédition est marqué "occupé" jusqu'à réclamation : il reste dans
 * l'équipe de combat/la sauvegarde, mais isBusy(heroId) permet aux autres écrans (Combat,
 * Galaxie, autre expédition, boss d'événement) de ne pas l'utiliser deux fois en même temps.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.ExpeditionManager = (function () {
  'use strict';

  var EX = function () { return NEBUSTION.Expeditions; };
  var BASE_SLOTS = 2;
  var MAX_SLOTS = 5;
  var HISTORY_MAX = 20;

  function root() { return NEBUSTION.Resources && NEBUSTION.Resources.state; }
  function defaultState() { return { v: 2, active: [], cooldowns: {}, history: [], stats: { sent: 0, completed: 0 } }; }

  function normalizeState(raw, nowArg) {
    var s = defaultState();
    if (!raw || typeof raw !== 'object') return s;
    var now = nowArg || Date.now();
    (Array.isArray(raw.active) ? raw.active : []).forEach(function (a) {
      if (!a || typeof a !== 'object') return;
      var m = EX().mission(a.missionId);
      if (!m) return;
      var heroIds = [];
      (Array.isArray(a.heroIds) ? a.heroIds : []).forEach(function (h) { if (typeof h === 'string' && heroIds.indexOf(h) < 0) heroIds.push(h); });
      heroIds = heroIds.slice(0, m.maxHeroes);
      if (!heroIds.length) return;
      var startedAt = Math.min(now, Number(a.startedAt) || now);
      // Une date de fin plus lointaine que la durée de la mission (horloge modifiée) est ramenée à sa valeur légitime.
      var endsAt = Math.min(Math.max(0, Number(a.endsAt) || now), startedAt + m.durationSec * 1000);
      s.active.push({
        id: typeof a.id === 'string' && a.id.length < 60 ? a.id : ('exp' + Math.floor(Math.random() * 1e9).toString(36)),
        missionId: a.missionId, heroIds: heroIds, startedAt: startedAt, endsAt: endsAt,
        seed: Number(a.seed) || 1, teamPower: Math.max(0, Number(a.teamPower) || 0), roleMatch: a.roleMatch === true
      });
    });
    var rcd = raw.cooldowns || {};
    Object.keys(rcd).forEach(function (mid) {
      var t = Number(rcd[mid]), m = EX().mission(mid);
      // Recharge d'une mission Éclair : jamais plus longue que sa durée maximale (horloge modifiée).
      if (m && isFinite(t) && t > now) s.cooldowns[mid] = Math.min(t, now + m.cooldownSec * 1000);
    });
    s.history = (Array.isArray(raw.history) ? raw.history : []).slice(-HISTORY_MAX).filter(function (h) { return h && typeof h === 'object'; });
    var st = raw.stats || {};
    s.stats = { sent: Math.max(0, Math.floor(Number(st.sent) || 0)), completed: Math.max(0, Math.floor(Number(st.completed) || 0)) };
    return s;
  }

  function state() {
    var r = root();
    if (!r) return defaultState();
    if (!r.expeditions) r.expeditions = defaultState();
    if (!r.expeditions.cooldowns) r.expeditions.cooldowns = {};
    return r.expeditions;
  }
  function save() { try { NEBUSTION.Resources.saveNow(Date.now()); } catch (e) { /* ignore */ } }

  function prestigeCount() { return NEBUSTION.PrestigeManager ? NEBUSTION.PrestigeManager.count() : 0; }
  function qgLevel() {
    var r = root();
    return (r && r.buildings && r.buildings.qg && r.buildings.qg.level) || 1;
  }

  // ---------- Emplacements ----------
  function maxSlots() {
    var bonus = (NEBUSTION.PrestigeManager && NEBUSTION.PrestigeManager.bonusValue) ? NEBUSTION.PrestigeManager.bonusValue('expeditionSlot') : 0;
    return Math.min(MAX_SLOTS, BASE_SLOTS + Math.floor(bonus));
  }
  function usedSlots() { return state().active.length; }
  function freeSlots() { return Math.max(0, maxSlots() - usedSlots()); }

  // ---------- Héros occupés ----------
  function busyHeroIds() {
    var out = {};
    state().active.forEach(function (a) { a.heroIds.forEach(function (h) { out[h] = true; }); });
    return out;
  }
  function isBusy(heroId) { return !!busyHeroIds()[heroId]; }
  /** Membres de l'équipe de combat actuelle qui sont en expédition. */
  function busyTeamMembers() {
    var b = busyHeroIds();
    return (NEBUSTION.Combat ? NEBUSTION.Combat.getTeam() : []).filter(function (id) { return b[id]; });
  }

  // ---------- Puissance d'équipe (via Combat/Heroes déjà en place + bonus permanent de Renaissance) ----------
  function powerBonus() { return ((NEBUSTION.PrestigeManager && NEBUSTION.PrestigeManager.bonusValue) ? NEBUSTION.PrestigeManager.bonusValue('combatPower') : 0) + ((NEBUSTION.PlanetBuild && NEBUSTION.Resources && NEBUSTION.Resources.state && NEBUSTION.Resources.state.planetBuild) ? NEBUSTION.PlanetBuild.effectSum(NEBUSTION.Resources.state.planetBuild, 'combatPower') : 0); }
  /** Durée réelle d'une mission (s) : réduite par les Spatioports de Nexus-01 (jamais plus de −60 %, les missions Éclair restent instantanées). */
  function effectiveDuration(m) {
    var red = Math.min(0.6, ((NEBUSTION.PlanetBuild && NEBUSTION.Resources && NEBUSTION.Resources.state && NEBUSTION.Resources.state.planetBuild) ? NEBUSTION.PlanetBuild.effectSum(NEBUSTION.Resources.state.planetBuild, 'expDur') : 0));
    return m.durationSec > 0 ? Math.max(1, Math.round(m.durationSec * (1 - red))) : 0;
  }
  function heroPower(heroId) {
    var H = NEBUSTION.Heroes, C = NEBUSTION.Combat;
    var hero = H.get(heroId);
    if (!hero || !C) return 0;
    return Math.round(H.statsAtLevel(hero, C.heroLevel(heroId)).power * (1 + powerBonus()));
  }
  function teamPowerOf(heroIds) { return (heroIds || []).reduce(function (s, id) { return s + heroPower(id); }, 0); }

  // ---------- Catalogue visible ----------
  function totalStars() {
    var r = root();
    var ss = (r && r.combat && r.combat.stageStars) || {};
    return Object.keys(ss).reduce(function (s, k) { return s + (ss[k] || 0); }, 0);
  }
  function cooldownLeft(missionId, now) {
    var t = state().cooldowns[missionId] || 0;
    return Math.max(0, t - (now || Date.now()));
  }
  function availableMissions(now) {
    var stars = totalStars(), pc = prestigeCount(), qg = qgLevel();
    return EX().allMissions().map(function (m) {
      return Object.assign({}, m, { unlocked: EX().isUnlocked(m, stars, pc, qg), cooldownLeft: cooldownLeft(m.id, now) });
    });
  }
  /** Pourquoi une mission est verrouillée (texte joueur), ou null. */
  function lockReason(m) {
    var stars = totalStars(), pc = prestigeCount(), qg = qgLevel();
    if (qg < (m.unlockQG || 1)) return 'Quartier Général niveau ' + (m.unlockQG || 1) + ' requis (' + qg + ')';
    if (pc < (m.unlockPrestige || 0)) return 'Renaissance ' + m.unlockPrestige + ' requise';
    if (stars < m.unlockStars) return m.unlockStars + ' étoiles de Combat requises (' + stars + ')';
    return null;
  }

  /** Un héros peut-il partir sur cette mission ? { ok, reason: 'inconnu'|'occupe'|'niveau', need } */
  function heroEligibility(heroId, m) {
    var C = NEBUSTION.Combat;
    if (!NEBUSTION.Heroes.get(heroId) || !C.isUnlocked(heroId)) return { ok: false, reason: 'inconnu' };
    if (isBusy(heroId)) return { ok: false, reason: 'occupe' };
    if (C.heroLevel(heroId) < m.minLevel) return { ok: false, reason: 'niveau', need: m.minLevel };
    return { ok: true };
  }

  // ---------- Lancement ----------
  function canLaunch(missionId, heroIds, now) {
    now = now || Date.now();
    var m = EX().mission(missionId);
    if (!m) return { ok: false, reason: 'invalide' };
    if (!EX().isUnlocked(m, totalStars(), prestigeCount(), qgLevel())) return { ok: false, reason: 'verrouille' };
    if (cooldownLeft(missionId, now) > 0) return { ok: false, reason: 'recharge', msLeft: cooldownLeft(missionId, now) };
    if (freeSlots() <= 0) return { ok: false, reason: 'emplacements' };
    var seen = {}, ids = [];
    (heroIds || []).forEach(function (id) { if (!seen[id]) { seen[id] = true; ids.push(id); } });
    for (var i = 0; i < ids.length; i++) {
      var el = heroEligibility(ids[i], m);
      if (!el.ok) return { ok: false, reason: el.reason === 'niveau' ? 'niveau' : (el.reason === 'occupe' ? 'occupe' : 'invalide'), heroId: ids[i], need: el.need };
    }
    if (ids.length < m.minHeroes) return { ok: false, reason: 'heros_min', need: m.minHeroes };
    if (ids.length > m.maxHeroes) return { ok: false, reason: 'heros_max', need: m.maxHeroes };
    return { ok: true, heroIds: ids };
  }

  function _roleMatch(m, ids) {
    return ids.some(function (id) { var h = NEBUSTION.Heroes.get(id); return h && h.role === m.favoredRole; });
  }

  function launch(missionId, heroIds, now) {
    now = now || Date.now();
    var chk = canLaunch(missionId, heroIds, now);
    if (!chk.ok) return chk;
    var m = EX().mission(missionId);
    var ids = chk.heroIds;
    var entry = {
      id: 'exp' + Math.floor(Math.random() * 1e9).toString(36) + now.toString(36),
      missionId: missionId, heroIds: ids, startedAt: now,
      endsAt: now + effectiveDuration(m) * 1000, seed: (now % 1e9) | 0, teamPower: teamPowerOf(ids), roleMatch: _roleMatch(m, ids)
    };
    var s = state();
    s.active.push(entry);
    s.stats.sent += 1;
    if (m.cooldownSec > 0) s.cooldowns[missionId] = now + m.cooldownSec * 1000;
    save();
    // Éclair (durée 0) : résolue tout de suite, pas d'attente à afficher (api.claim : passe par les branchements Événements/Succès).
    if (m.durationSec === 0) return api.claim(entry.id, now);
    return { ok: true, entry: entry, instant: false };
  }

  // ---------- État / réclamation ----------
  function timeLeft(entry, now) { return Math.max(0, entry.endsAt - (now || Date.now())); }
  function isReady(entry, now) { return timeLeft(entry, now) <= 0; }

  function listActive(now) {
    now = now || Date.now();
    return state().active.map(function (a) {
      var m = EX().mission(a.missionId);
      return { entry: a, mission: m, ready: isReady(a, now), msLeft: timeLeft(a, now) };
    });
  }
  function readyCount(now) { return listActive(now).filter(function (x) { return x.ready; }).length; }

  function _currentRates() {
    var R = NEBUSTION.Resources;
    try { return R && R.rates ? R.rates() : null; } catch (e) { return null; }
  }

  function _deliver(res, gems, xon, fragments, xp, heroIds) {
    var R = NEBUSTION.Resources;
    var granted = {};
    Object.keys(res).forEach(function (id) { if (res[id] > 0) granted[id] = R.add(id, res[id], 'expedition') || 0; });
    if (gems > 0 && NEBUSTION.ShopManager) NEBUSTION.ShopManager.addGems(gems);
    if (xon > 0 && NEBUSTION.ShopManager) NEBUSTION.ShopManager.addXon(xon);
    var levelUps = [];
    if (fragments > 0 && NEBUSTION.Combat) {
      heroIds.forEach(function (hid) {
        var before = NEBUSTION.Combat.heroLevel(hid);
        NEBUSTION.Combat.addFragments(hid, fragments);
        var after = NEBUSTION.Combat.heroLevel(hid);
        if (after > before) levelUps.push({ heroId: hid, level: after });
      });
    }
    var r = root();
    if (xp > 0 && r && r.combat) r.combat.playerXP = (r.combat.playerXP || 0) + xp;
    return { granted: granted, gems: gems, xon: xon, fragments: fragments, xp: xp, levelUps: levelUps };
  }

  /** Réclame une expédition terminée (ou l'Éclair, résolue instantanément). */
  function claim(entryId, now) {
    now = now || Date.now();
    var s = state();
    var idx = -1;
    for (var i = 0; i < s.active.length; i++) { if (s.active[i].id === entryId) { idx = i; break; } }
    if (idx < 0) return { ok: false, reason: 'introuvable' };
    var entry = s.active[idx];
    var m = EX().mission(entry.missionId);
    if (!m) { s.active.splice(idx, 1); save(); return { ok: false, reason: 'invalide' }; }
    if (!isReady(entry, now)) return { ok: false, reason: 'en_cours', msLeft: timeLeft(entry, now) };
    var rw = EX().rewardsFor(m, entry.teamPower, entry.seed, _currentRates(), { heroCount: entry.heroIds.length, roleMatch: entry.roleMatch });
    // L'entrée est retirée AVANT la livraison : une réclamation ne peut jamais être versée deux fois.
    s.active.splice(idx, 1);
    var d = _deliver(rw.res, rw.gems, rw.xon, rw.fragments, rw.xp, entry.heroIds);
    s.stats.completed += 1;
    s.history.push({ missionId: entry.missionId, at: now, success: rw.success, scale: Math.round(rw.scale * 100) });
    if (s.history.length > HISTORY_MAX) s.history = s.history.slice(-HISTORY_MAX);
    save();
    return { ok: true, mission: m, reward: rw, delivered: d, heroIds: entry.heroIds };
  }

  /** Réclame toutes les expéditions terminées. */
  function claimAll(now) {
    now = now || Date.now();
    var out = [];
    listActive(now).forEach(function (x) { if (x.ready) { var r = api.claim(x.entry.id, now); if (r && r.ok) out.push(r); } });
    return out;
  }

  /** Annule une expédition en cours AVANT son terme : les héros sont libérés, aucune récompense (aucun coût n'ayant été prélevé). */
  function cancel(entryId) {
    var s = state();
    var idx = -1;
    for (var i = 0; i < s.active.length; i++) { if (s.active[i].id === entryId) { idx = i; break; } }
    if (idx < 0) return { ok: false, reason: 'introuvable' };
    s.active.splice(idx, 1);
    save();
    return { ok: true };
  }

  var api = {
    effectiveDuration: effectiveDuration,
    normalizeState: normalizeState, defaultState: defaultState,
    maxSlots: maxSlots, usedSlots: usedSlots, freeSlots: freeSlots,
    isBusy: isBusy, busyHeroIds: busyHeroIds, busyTeamMembers: busyTeamMembers, heroPower: heroPower, teamPowerOf: teamPowerOf,
    availableMissions: availableMissions, totalStars: totalStars, qgLevel: qgLevel, lockReason: lockReason, cooldownLeft: cooldownLeft,
    heroEligibility: heroEligibility, canLaunch: canLaunch, launch: launch, listActive: listActive, readyCount: readyCount,
    isReady: isReady, timeLeft: timeLeft,
    claim: claim, claimAll: claimAll, cancel: cancel, stats: function () { return state().stats; }
  };
  return api;
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.ExpeditionManager; }
