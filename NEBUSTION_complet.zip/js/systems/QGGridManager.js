/**
 * NEBUSTION - QGGridManager
 * Glue entre NEBUSTION.QGGrid (données pures) et NEBUSTION.Resources (économie/sauvegarde).
 * État dans NEBUSTION.Resources.state.qgGrid : { unlocked: {...}, cells: {...} }.
 * Suit exactement le patron de SecurityManager.js / ExpeditionManager.js.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.QGGridManager = (function () {
  'use strict';

  function D() { return NEBUSTION.QGGrid; }
  function root() { return NEBUSTION.Resources && NEBUSTION.Resources.state; }

  function state() {
    var r = root();
    if (!r) return D().defaultState();
    if (!r.qgGrid) r.qgGrid = D().defaultState();
    return r.qgGrid;
  }

  function isUnlocked(x, y) { return !!state().unlocked[D().key(x, y)]; }
  function structureAt(x, y) { return state().cells[D().key(x, y)] || null; }
  function pendingAt(x, y) { return D().pendingAt(state(), x, y); }
  function isPending(x, y) { return !!pendingAt(x, y); }
  function remainingMs(x, y) { return D().remainingMs(state(), x, y, Date.now()); }
  /** Coordonnées {x,y} de tous les chantiers en cours (pour le rafraîchissement périodique de la scène). */
  function pendingKeys() { return Object.keys(state().building || {}).map(function (k) { return D().parseKey(k); }); }
  function counts() { return D().counts(state()); }
  function countsPending() { return D().countsPending(state()); }
  function unlockedCount() { return D().unlockedCount(state()); }
  function unlockCost() { return D().unlockCost(unlockedCount()); }
  function gridFull() { return unlockedCount() >= D().MAX_CELLS; }

  function canUnlock(x, y) {
    var R = NEBUSTION.Resources;
    if (!R || !D().inBounds(x, y) || isUnlocked(x, y) || gridFull()) return false;
    var c = unlockCost();
    return Object.keys(c).every(function (id) { return R.get(id) >= c[id]; });
  }

  function unlockCell(x, y) {
    var R = NEBUSTION.Resources;
    if (!R) return { ok: false, reason: 'unavailable' };
    if (!D().inBounds(x, y)) return { ok: false, reason: 'bounds' };
    if (isUnlocked(x, y)) return { ok: false, reason: 'already' };
    if (gridFull()) return { ok: false, reason: 'full' };
    var c = unlockCost();
    if (!R.spendMany(c)) return { ok: false, reason: 'cost', cost: c };
    state().unlocked[D().key(x, y)] = true;
    R.saveNow(Date.now());
    return { ok: true, cost: c };
  }

  function buildCost(structureId) {
    var def = D().STRUCTURES[structureId];
    if (!def) return {};
    return D().buildCost(structureId, counts()[structureId] || 0);
  }

  function canBuild(x, y, structureId) {
    var R = NEBUSTION.Resources, def = D().STRUCTURES[structureId];
    if (!R || !def || !isUnlocked(x, y) || structureAt(x, y) || pendingAt(x, y)) return false;
    var already = (counts()[structureId] || 0) + (countsPending()[structureId] || 0);
    if (already >= def.maxCount) return false;
    var c = buildCost(structureId);
    return Object.keys(c).every(function (id) { return R.get(id) >= c[id]; });
  }

  /**
   * Achète et construit une structure. Les bâtiments SANS `buildTimeSec` (les 12 d'origine) restent posés
   * instantanément ; ceux AVEC `buildTimeSec` (module 28 : Observatoire, Balise, Arsenal, Citadelle) entrent
   * en chantier — la structure ne devient active (comptée dans bonusValue) qu'à la fin du décompte, voir tick().
   */
  function build(x, y, structureId) {
    var R = NEBUSTION.Resources, def = D().STRUCTURES[structureId];
    if (!R || !def) return { ok: false, reason: 'unavailable' };
    if (!isUnlocked(x, y)) return { ok: false, reason: 'locked' };
    if (structureAt(x, y) || pendingAt(x, y)) return { ok: false, reason: 'occupied' };
    var already = (counts()[structureId] || 0) + (countsPending()[structureId] || 0);
    if (already >= def.maxCount) return { ok: false, reason: 'max' };
    var c = buildCost(structureId);
    if (!R.spendMany(c)) return { ok: false, reason: 'cost', cost: c };
    var now = Date.now();
    if (def.buildTimeSec) {
      D().startBuild(state(), x, y, structureId, now);
    } else {
      state().cells[D().key(x, y)] = structureId;
      R._rates = null; // un Générateur change le taux de production en cache
    }
    R.saveNow(now);
    return { ok: true, cost: c, buildTimeSec: def.buildTimeSec || 0 };
  }

  /** Appelé environ 1x/s par la scène : fait avancer les chantiers, active ceux qui sont terminés. */
  function tick() {
    var now = Date.now();
    var done = D().completePending(state(), now);
    if (done.length) {
      var R = NEBUSTION.Resources;
      if (R) { R._rates = null; R.saveNow(now); }
    }
    return done;
  }

  /** Annule un chantier en cours : remboursement à 50 % du coût payé (même taux que la revente). */
  function cancelBuild(x, y) {
    var R = NEBUSTION.Resources, job = pendingAt(x, y);
    if (!R || !job) return { ok: false, reason: 'empty' };
    var paid = D().buildCost(job.id, counts()[job.id] || 0);
    var refund = {};
    Object.keys(paid).forEach(function (id) { refund[id] = Math.floor(paid[id] * 0.5); });
    D().cancelBuild(state(), x, y);
    Object.keys(refund).forEach(function (id) { R.add(id, refund[id], 'qgCancelBuild'); });
    R.saveNow(Date.now());
    return { ok: true, refund: refund };
  }

  function sellRefund(x, y) {
    var sid = structureAt(x, y);
    if (!sid) return {};
    return D().sellRefund(sid, counts()[sid] || 0);
  }

  function sell(x, y) {
    var R = NEBUSTION.Resources, sid = structureAt(x, y);
    if (!R || !sid) return { ok: false, reason: 'empty' };
    var refund = sellRefund(x, y);
    delete state().cells[D().key(x, y)];
    R._rates = null; // idem à la construction
    Object.keys(refund).forEach(function (id) { R.add(id, refund[id], 'qgSell'); });
    R.saveNow(Date.now());
    return { ok: true, refund: refund };
  }

  /** Bonus total ('production' | 'storage' | 'security'), consommé par ResourceManager / QGScene. */
  function bonusValue(type) { return D().bonusValue(type, state()); }

  return {
    isUnlocked: isUnlocked, structureAt: structureAt, counts: counts,
    pendingAt: pendingAt, isPending: isPending, remainingMs: remainingMs, pendingKeys: pendingKeys, countsPending: countsPending,
    unlockedCount: unlockedCount, unlockCost: unlockCost, gridFull: gridFull, canUnlock: canUnlock, unlockCell: unlockCell,
    buildCost: buildCost, canBuild: canBuild, build: build, tick: tick, cancelBuild: cancelBuild,
    sellRefund: sellRefund, sell: sell, bonusValue: bonusValue
  };
})();
