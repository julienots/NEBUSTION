/**
 * NEBUSTION - SceneBackground
 * Construit le décor spatial commun à toutes les scènes de jeu :
 * champ d'étoiles en parallaxe (2 couches), nébuleuses animées,
 * poussière lumineuse, vignette, et en option la planète Nexus-01.
 * Ajoute aussi un handler de scroll léger sur pointermove pour renforcer
 * la sensation de profondeur (parallaxe interactive).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.SceneBackground = {
  /**
   * Peuple un container avec des bras de galaxie en spirale logarithmique (poussière + étoiles),
   * centrés sur (0,0) du container passé. Le container entier est ensuite tourné par un tween
   * dans build() : les points eux-mêmes restent fixes les uns par rapport aux autres.
   * opts.starsOnly : n'ajoute que les points « étoiles » (fins), sans les halos de poussière
   *   (utilisé pour la couche de parallaxe la plus proche, plus légère).
   * opts.seedOffset : décale la génération pseudo-aléatoire pour que deux couches ne se
   *   superposent pas à l'identique.
   */
  _buildSpiralArms: function (scene, container, opts) {
    opts = opts || {};
    var arms = 3, maxRadius = 340, turns = 2.3;
    var dustColors = [0x00e5ff, 0x6c3ce9, 0xff6ec7];
    var seed = (opts.seedOffset || 0) + 1;
    function rnd() { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; }

    for (var a = 0; a < arms; a++) {
      var armOffset = (a / arms) * Math.PI * 2;

      // --- Poussière de l'arme : quelques grands halos doux, additifs, peu nombreux ---
      if (!opts.starsOnly) {
        var dustCount = 6;
        for (var d = 0; d < dustCount; d++) {
          var td = (d + 0.5) / dustCount;
          var thetaD = armOffset + td * turns * Math.PI * 2 + (rnd() - 0.5) * 0.3;
          var radD = maxRadius * (0.14 + td * 0.86) * (0.9 + rnd() * 0.2);
          var x = Math.cos(thetaD) * radD, y = Math.sin(thetaD) * radD * 0.62; // aplati (vue en angle)
          var img = scene.add.image(x, y, 'tex_glow_' + (td < 0.4 ? 'cyan' : (td < 0.75 ? 'purple' : 'white')))
            .setTint(dustColors[a % dustColors.length])
            .setScale(1.1 - td * 0.5 + rnd() * 0.3)
            .setAlpha((0.16 - td * 0.09) * (0.8 + rnd() * 0.4))
            .setBlendMode(Phaser.BlendModes.ADD);
          container.add(img);
        }
      }

      // --- Étoiles de l'arme : nombreux points fins, teinte dégradée du cœur (cyan/blanc) au bord (bleu sombre) ---
      var starCount = opts.starsOnly ? 30 : 22;
      for (var i = 0; i < starCount; i++) {
        var t = (i + 0.5) / starCount;
        var theta = armOffset + t * turns * Math.PI * 2 + (rnd() - 0.5) * (0.15 + t * 0.35);
        var rad = maxRadius * (0.1 + t * 0.9) * (0.92 + rnd() * 0.16);
        var sx = Math.cos(theta) * rad, sy = Math.sin(theta) * rad * 0.62;
        var tint = t < 0.2 ? 0xdff6ff : (t < 0.55 ? 0x9fd4ff : (t < 0.8 ? 0xb47bff : 0x4a5a8a));
        var star = scene.add.image(sx, sy, rnd() > 0.7 ? 'tex_star_big' : 'tex_star_small')
          .setTint(tint)
          .setScale(0.4 + (1 - t) * 0.7 + rnd() * 0.35)
          .setAlpha(Math.max(0.15, 0.85 - t * 0.55 + rnd() * 0.2));
        container.add(star);
      }
    }
  },

  build: function (scene, opts) {
    opts = opts || {};
    var w = scene.scale.width, h = scene.scale.height;
    var layers = {};

    // Fond d'espace peint (nébuleuse, sans shader GPU) — ignoré en économie de batterie. Toujours la variante 'space' :
    // les scènes Univers/Galaxie dessinent déjà leur propre galaxie, une seconde ferait doublon (fond délavé).
    try {
      layers.shader = NEBUSTION.Shaders ? NEBUSTION.Shaders.space(scene, 'space') : null;
    } catch (e) { layers.shader = null; }

    // Couche 0 : voile de poussière spatiale répétable sans couture (dérive très lente)
    layers.dust = scene.add.tileSprite(0, 0, w, h, 'tex_space_dust').setOrigin(0).setAlpha(0.85).setDepth(-110);

    // Couche 1 : étoiles lointaines, très lentes
    layers.starsFar = scene.add.tileSprite(0, 0, w, h, 'tex_starfield_far').setOrigin(0).setDepth(-100);

    // Nébuleuses (glow additif, légèrement animées)
    var nebulaConfigs = [
      { key: 'tex_nebula_purple', x: w * 0.2, y: h * 0.18, alpha: 0.32, scale: 1.1 },
      { key: 'tex_nebula_cyan', x: w * 0.85, y: h * 0.32, alpha: 0.24, scale: 0.9 },
      { key: 'tex_nebula_pink', x: w * 0.5, y: h * 0.75, alpha: 0.18, scale: 1.0 }
    ];
    layers.nebulae = nebulaConfigs.map(function (cfg) {
      var img = scene.add.image(cfg.x, cfg.y, cfg.key)
        .setAlpha(cfg.alpha)
        .setScale(cfg.scale)
        .setBlendMode(Phaser.BlendModes.ADD)
        .setDepth(-90);
      scene.tweens.add({
        targets: img,
        alpha: cfg.alpha * 1.4,
        duration: 4000 + Math.random() * 2000,
        yoyo: true,
        repeat: -1,
        ease: 'Sine.easeInOut'
      });
      scene.tweens.add({
        targets: img,
        angle: img.angle + (Math.random() > 0.5 ? 20 : -20),
        duration: 20000 + Math.random() * 8000,
        yoyo: true,
        repeat: -1,
        ease: 'Sine.easeInOut'
      });
      return img;
    });

    // Couche 2 : étoiles proches, plus rapides (parallaxe)
    layers.starsNear = scene.add.tileSprite(0, 0, w, h, 'tex_starfield_near').setOrigin(0).setAlpha(0.9).setDepth(-80);

    // Poussière lumineuse flottante (particules lentes)
    scene.add.particles(w / 2, h / 2, 'tex_glow_white', {
      x: { min: 0, max: w },
      y: { min: 0, max: h },
      scale: { start: 0.15, end: 0 },
      alpha: { start: 0.35, end: 0 },
      lifespan: { min: 4000, max: 8000 },
      speedY: { min: -6, max: -18 },
      speedX: { min: -4, max: 4 },
      frequency: 350,
      blendMode: 'ADD'
    }).setDepth(-70);

    if (opts.withPlanet) {
      // --- Cœur galactique : Nexus-01, fixe, entouré du halo et des bras spiraux qui tournent ---
      var gcx = w / 2, gcy = h * 0.435;

      // Lueur de fond du cœur galactique (grand halo doux, additif, pulse lente)
      var coreGlow = scene.add.image(gcx, gcy, 'tex_nebula_cyan')
        .setScale(1.35).setAlpha(0.22).setBlendMode(Phaser.BlendModes.ADD).setDepth(-96);
      scene.tweens.add({ targets: coreGlow, alpha: 0.34, scale: 1.5, duration: 3400, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });

      var GB = NEBUSTION.GalaxyBackdrop, ADD = Phaser.BlendModes.ADD;
      var spiralArms, spiralArms2;
      if (GB && GB.ensureHome) {
        // Vraie galaxie spirale : disque incliné à 4 bras (poussière sombre, régions HII, milliers d'étoiles),
        // noyau incandescent, seconde couche fantôme en contre-rotation pour la profondeur.
        var gkey = GB.ensureHome(scene);
        var halo = scene.add.image(gcx, gcy, 'tex_nebula_purple').setScale(2.1).setAlpha(0.2).setBlendMode(ADD).setDepth(-97);
        scene.tweens.add({ targets: halo, alpha: 0.32, duration: 5200, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
        spiralArms = scene.add.container(gcx, gcy).setDepth(-94).setRotation(-0.32).setScale(1, 0.72);
        var back = scene.add.image(0, 0, gkey).setDisplaySize(1380, 1380).setAlpha(0.26).setBlendMode(ADD).setRotation(1.1);
        var disk = scene.add.image(0, 0, gkey).setDisplaySize(1040, 1040).setBlendMode(ADD);
        spiralArms.add([back, disk]);
        scene.tweens.add({ targets: disk, rotation: Math.PI * 2, duration: 320000, repeat: -1, ease: 'Linear' });
        scene.tweens.add({ targets: back, rotation: 1.1 - Math.PI * 2, duration: 450000, repeat: -1, ease: 'Linear' });
        spiralArms2 = scene.add.image(gcx, gcy, 'tex_glow_gold').setDisplaySize(560, 420).setAlpha(0.42).setBlendMode(ADD).setDepth(-93);
        scene.tweens.add({ targets: spiralArms2, alpha: 0.6, scaleX: spiralArms2.scaleX * 1.08, scaleY: spiralArms2.scaleY * 1.08, duration: 3000, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
        // étoiles brillantes qui scintillent par-dessus la galaxie
        var sd = 7;
        var rr = function () { sd = (sd * 1664525 + 1013904223) >>> 0; return sd / 4294967296; };
        for (var ts = 0; ts < 22; ts++) {
          var st = scene.add.image(rr() * w, 190 + rr() * (h - 420), 'tex_star_big').setBlendMode(ADD).setDepth(-92)
            .setScale(0.5 + rr() * 0.9).setAlpha(0.2).setTint(rr() > 0.5 ? 0xbfe0ff : 0xffe2b8);
          scene.tweens.add({ targets: st, alpha: 0.95, duration: 900 + rr() * 2200, delay: rr() * 2000, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
        }
      } else {
        // Repli (sans GalaxyBackdrop) : anciens bras en points
        spiralArms = scene.add.container(gcx, gcy).setDepth(-94);
        NEBUSTION.SceneBackground._buildSpiralArms(scene, spiralArms);
        scene.tweens.add({ targets: spiralArms, angle: 360, duration: 260000, repeat: -1, ease: 'Linear' });
        spiralArms2 = scene.add.container(gcx, gcy).setDepth(-93).setAlpha(0.6).setScale(0.7);
        NEBUSTION.SceneBackground._buildSpiralArms(scene, spiralArms2, { seedOffset: 7, starsOnly: true });
        scene.tweens.add({ targets: spiralArms2, angle: -360, duration: 190000, repeat: -1, ease: 'Linear' });
      }

      // Nexus-01 : cœur d'énergie rouge, en fondu pur (blend ADD) pour se fondre dans le fond
      // spatial au lieu de se découper comme une boule plate. Légère pulsation d'intensité et
      // rotation lente du grain de plasma pour un rendu vivant.
      var planet = scene.add.image(gcx, gcy, 'tex_planet_nexus')
        .setScale(0.5)
        .setDepth(-60)
        .setBlendMode(Phaser.BlendModes.ADD);
      scene.tweens.add({
        targets: planet,
        angle: 360,
        duration: 240000,
        repeat: -1,
        ease: 'Linear'
      });
      scene.tweens.add({
        targets: planet,
        alpha: 0.82,
        scaleX: planet.scaleX * 1.05,
        scaleY: planet.scaleY * 1.05,
        duration: 2600,
        yoyo: true,
        repeat: -1,
        ease: 'Sine.easeInOut'
      });

      var ring = scene.add.image(planet.x, planet.y, 'tex_planet_ring')
        .setScale(0.5)
        .setAlpha(0.4)
        .setBlendMode(Phaser.BlendModes.ADD)
        .setDepth(-61)
        .setAngle(-8);

      // Balise centrale : cœur incandescent au centre du fondu rouge
      var beacon = scene.add.image(gcx, gcy, 'tex_glow_white').setScale(0.45).setAlpha(0.85)
        .setBlendMode(Phaser.BlendModes.ADD).setDepth(-59).setTint(0xffcdb0);
      scene.tweens.add({ targets: beacon, alpha: 0.4, scale: 0.32, duration: 900, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });

      layers.planet = planet;
      layers.ring = ring;
      layers.spiralArms = spiralArms;
      layers.spiralArms2 = spiralArms2;
      layers.coreGlow = coreGlow;
    }

    // Vignette pour renforcer la profondeur sur les bords
    scene.add.image(w / 2, h / 2, 'tex_vignette').setDisplaySize(w, h).setDepth(-50);

    // Parallaxe légère au déplacement du doigt / souris. La dérive automatique et la parallaxe
    // sont additionnées (et non écrasées l'une par l'autre) : aucun saut visible du fond.
    var drift = { far: 0, near: 0, dust: 0 };
    var par = { x: 0, y: 0 };
    function apply() {
      layers.starsNear.tilePositionX = drift.near + par.x * 20;
      layers.starsNear.tilePositionY = par.y * 20;
      layers.starsFar.tilePositionX = drift.far + par.x * 8;
      layers.starsFar.tilePositionY = par.y * 8;
      layers.dust.tilePositionX = drift.dust + par.x * 4;
      layers.dust.tilePositionY = par.y * 4;
    }
    scene.input.on('pointermove', function (pointer) {
      par.x = (pointer.x / w - 0.5);
      par.y = (pointer.y / h - 0.5);
      apply();
    });

    // Dérive automatique continue des étoiles pour un fond jamais figé
    scene.time.addEvent({
      delay: 16,
      loop: true,
      callback: function () {
        drift.far += 0.02;
        drift.near += 0.06;
        drift.dust += 0.008;
        apply();
      }
    });

    return layers;
  }
};
