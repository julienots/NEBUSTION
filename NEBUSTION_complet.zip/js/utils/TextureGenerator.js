/**
 * NEBUSTION - TextureGenerator
 * Génère toutes les textures du jeu à la volée via Canvas 2D,
 * pour ne dépendre d'aucun fichier image externe (plus léger, plus flexible).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.TextureGenerator = {

  /**
   * Génère toutes les textures utilisées par le jeu. Appelé une seule fois
   * depuis PreloadScene, avant que les autres scènes n'en aient besoin.
   */
  generateAll: function (scene) {
    this.generateGlowParticle(scene, 'tex_glow_white', '#ffffff');
    this.generateGlowParticle(scene, 'tex_glow_cyan', '#00e5ff');
    this.generateGlowParticle(scene, 'tex_glow_gold', '#ffd166');
    this.generateGlowParticle(scene, 'tex_glow_purple', '#6c3ce9');

    this.generateStar(scene, 'tex_star_small', 4);
    this.generateStar(scene, 'tex_star_big', 8);

    this.generateNebula(scene, 'tex_nebula_purple', ['#6c3ce9', '#2e9eff'], 640);
    this.generateNebula(scene, 'tex_nebula_cyan', ['#00e5ff', '#2e9eff'], 560);
    this.generateNebula(scene, 'tex_nebula_pink', ['#ff4d9e', '#6c3ce9'], 520);

    this.generateEnergyCore(scene, 'tex_planet_nexus', {
      radius: 220,
      coreColor: '#fff2e8',
      midColor: '#ff3b1e',
      outerColor: '#7a0a05'
    });

    this.generatePlanetRing(scene, 'tex_planet_ring', 260, '#ff5a3a');

    this.generateVignette(scene, 'tex_vignette', 720, 1280);

    // Fond spatial SANS COUTURE : toutes ces tuiles sont dessinées avec repli (wrap) sur leurs
    // bords, donc elles se raccordent parfaitement quand le TileSprite les répète.
    this.generateSpaceDustTile(scene, 'tex_space_dust', 1024);
    this.generateStarfieldTile(scene, 'tex_starfield_far', 1024, 1024, 220, 0.35);
    this.generateStarfieldTile(scene, 'tex_starfield_near', 512, 512, 35, 0.7);
  },

  /**
   * Appelle draw(x, y) à la position voulue ET à ses copies décalées de ±w / ±h quand l'élément
   * (de rayon r) déborde d'un bord : ce qui sort à droite réapparaît à gauche, etc.
   * C'est ce qui rend une tuile parfaitement répétable (seamless).
   */
  _drawWrapped: function (w, h, x, y, r, draw) {
    var xs = [0], ys = [0];
    if (x - r < 0) xs.push(w);
    if (x + r > w) xs.push(-w);
    if (y - r < 0) ys.push(h);
    if (y + r > h) ys.push(-h);
    for (var i = 0; i < xs.length; i++) {
      for (var j = 0; j < ys.length; j++) draw(x + xs[i], y + ys[j]);
    }
  },

  /** Petit point lumineux avec halo dégradé - utilisé pour particules et poussière d'espace */
  generateGlowParticle: function (scene, key, colorHex) {
    if (scene.textures.exists(key)) return;
    var size = 64;
    var canvasTex = scene.textures.createCanvas(key, size, size);
    var ctx = canvasTex.context;
    var grad = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
    grad.addColorStop(0, this._hexToRgba(colorHex, 1));
    grad.addColorStop(0.4, this._hexToRgba(colorHex, 0.6));
    grad.addColorStop(1, this._hexToRgba(colorHex, 0));
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);
    canvasTex.refresh();
  },

  /** Étoile ponctuelle nette avec un léger halo, pour le champ d'étoiles */
  generateStar: function (scene, key, size) {
    if (scene.textures.exists(key)) return;
    var canvasSize = size * 4;
    var canvasTex = scene.textures.createCanvas(key, canvasSize, canvasSize);
    var ctx = canvasTex.context;
    var cx = canvasSize / 2, cy = canvasSize / 2;
    var grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, canvasSize / 2);
    grad.addColorStop(0, 'rgba(255,255,255,1)');
    grad.addColorStop(0.25, 'rgba(200,225,255,0.8)');
    grad.addColorStop(1, 'rgba(200,225,255,0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, canvasSize, canvasSize);
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(cx, cy, size / 2, 0, Math.PI * 2);
    ctx.fill();
    canvasTex.refresh();
  },

  /** Grand nuage de nébuleuse, formé de plusieurs taches radiales superposées */
  generateNebula: function (scene, key, colors, size) {
    if (scene.textures.exists(key)) return;
    var canvasTex = scene.textures.createCanvas(key, size, size);
    var ctx = canvasTex.context;
    var blobs = 6;
    for (var i = 0; i < blobs; i++) {
      var cx = size * (0.25 + Math.random() * 0.5);
      var cy = size * (0.25 + Math.random() * 0.5);
      var r = size * (0.25 + Math.random() * 0.25);
      // Le dégradé doit atteindre 0 avant le bord de la texture : sinon on voit un carré net.
      r = Math.min(r, cx, cy, size - cx, size - cy);
      var color = colors[i % colors.length];
      var grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
      grad.addColorStop(0, this._hexToRgba(color, 0.35));
      grad.addColorStop(0.5, this._hexToRgba(color, 0.16));
      grad.addColorStop(1, this._hexToRgba(color, 0));
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, size, size);
    }
    // Sécurité : fondu circulaire final, les bords de la texture sont toujours 100 % transparents.
    var half = size / 2;
    var mask = ctx.createRadialGradient(half, half, half * 0.55, half, half, half);
    mask.addColorStop(0, 'rgba(0,0,0,1)');
    mask.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.globalCompositeOperation = 'destination-in';
    ctx.fillStyle = mask;
    ctx.fillRect(0, 0, size, size);
    ctx.globalCompositeOperation = 'source-over';
    canvasTex.refresh();
  },

  /** Planète sphérique avec ombrage, relief simple et anneau lumineux d'atmosphère */
  generatePlanet: function (scene, key, opts) {
    if (scene.textures.exists(key)) return;
    var size = opts.radius * 2 + 40;
    var canvasTex = scene.textures.createCanvas(key, size, size);
    var ctx = canvasTex.context;
    var cx = size / 2, cy = size / 2, r = opts.radius;

    // Base sphérique (lumière venant du haut-gauche)
    var baseGrad = ctx.createRadialGradient(cx - r * 0.4, cy - r * 0.4, r * 0.1, cx, cy, r);
    baseGrad.addColorStop(0, opts.baseColorInner);
    baseGrad.addColorStop(1, opts.baseColorOuter);
    ctx.fillStyle = baseGrad;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fill();

    // Reliefs / continents (taches irrégulières plus sombres)
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.clip();
    for (var i = 0; i < 10; i++) {
      var bx = cx + (Math.random() - 0.5) * r * 1.6;
      var by = cy + (Math.random() - 0.5) * r * 1.6;
      var br = r * (0.12 + Math.random() * 0.22);
      ctx.fillStyle = 'rgba(255,255,255,0.05)';
      ctx.beginPath();
      ctx.ellipse(bx, by, br, br * 0.6, Math.random() * Math.PI, 0, Math.PI * 2);
      ctx.fill();
    }
    // Bandes lumineuses (style planète-cité / anneaux d'énergie)
    for (var b = 0; b < 3; b++) {
      ctx.strokeStyle = opts.bandColor;
      ctx.lineWidth = 2 + Math.random() * 3;
      ctx.beginPath();
      var by2 = cy - r * 0.4 + b * r * 0.4;
      ctx.ellipse(cx, by2, r * 0.95, r * 0.12, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    // Ombre (côté nuit)
    var shadowGrad = ctx.createRadialGradient(cx + r * 0.5, cy + r * 0.5, r * 0.1, cx + r * 0.3, cy + r * 0.3, r * 1.3);
    shadowGrad.addColorStop(0, 'rgba(0,0,0,0)');
    shadowGrad.addColorStop(1, this._hexToRgba(opts.shadowColor, 0.85));
    ctx.fillStyle = shadowGrad;
    ctx.fillRect(0, 0, size, size);
    ctx.restore();

    // Halo d'atmosphère
    var haloGrad = ctx.createRadialGradient(cx, cy, r * 0.96, cx, cy, r * 1.15);
    haloGrad.addColorStop(0, this._hexToRgba(opts.baseColorInner, 0.5));
    haloGrad.addColorStop(1, this._hexToRgba(opts.baseColorInner, 0));
    ctx.fillStyle = haloGrad;
    ctx.beginPath();
    ctx.arc(cx, cy, r * 1.15, 0, Math.PI * 2);
    ctx.fill();

    canvasTex.refresh();
  },

  /**
   * Cœur d'énergie : sphère en fondu pur (aucun contour net), du blanc-chaud au centre au rouge
   * profond puis totalement transparent avant le bord de la texture. Pensée pour un rendu en
   * blend mode ADD : elle se fond dans le fond spatial au lieu de se découper comme une boule plate.
   * Un léger bruit radial casse la symétrie parfaite du dégradé pour un aspect plasma vivant.
   */
  generateEnergyCore: function (scene, key, opts) {
    if (scene.textures.exists(key)) return;
    var r = opts.radius, size = r * 2 + 40;
    var canvasTex = scene.textures.createCanvas(key, size, size);
    var ctx = canvasTex.context;
    var cx = size / 2, cy = size / 2;

    // Dégradé principal : blanc-chaud → rouge vif → rouge sombre → transparent, bien avant le bord.
    var grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
    grad.addColorStop(0, this._hexToRgba(opts.coreColor, 1));
    grad.addColorStop(0.22, this._hexToRgba(opts.midColor, 0.95));
    grad.addColorStop(0.55, this._hexToRgba(opts.outerColor, 0.55));
    grad.addColorStop(0.85, this._hexToRgba(opts.outerColor, 0.12));
    grad.addColorStop(1, this._hexToRgba(opts.outerColor, 0));
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);

    // Volutes de plasma : quelques taches douces décalées du centre, additives, pour rompre
    // la symétrie parfaite d'un simple dégradé radial.
    var seed = 11;
    function rnd() { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; }
    ctx.globalCompositeOperation = 'lighter';
    for (var i = 0; i < 5; i++) {
      var ang = rnd() * Math.PI * 2, dist = rnd() * r * 0.35;
      var bx = cx + Math.cos(ang) * dist, by = cy + Math.sin(ang) * dist;
      var br = r * (0.35 + rnd() * 0.3);
      var bg = ctx.createRadialGradient(bx, by, 0, bx, by, br);
      bg.addColorStop(0, this._hexToRgba(opts.midColor, 0.22));
      bg.addColorStop(1, this._hexToRgba(opts.midColor, 0));
      ctx.fillStyle = bg;
      ctx.beginPath(); ctx.arc(bx, by, br, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalCompositeOperation = 'source-over';

    canvasTex.refresh();
  },

  /** Anneau fin lumineux (utilisé comme halo d'orbite / atmosphère additionnelle) */
  generatePlanetRing: function (scene, key, radius, colorHex) {
    if (scene.textures.exists(key)) return;
    var size = radius * 2 + 20;
    var canvasTex = scene.textures.createCanvas(key, size, size);
    var ctx = canvasTex.context;
    var cx = size / 2, cy = size / 2;
    ctx.strokeStyle = this._hexToRgba(colorHex, 0.5);
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(cx, cy, radius, radius * 0.32, 0, 0, Math.PI * 2);
    ctx.stroke();
    canvasTex.refresh();
  },

  /** Vignette sombre pour renforcer la profondeur sur les bords de l'écran */
  generateVignette: function (scene, key, w, h) {
    if (scene.textures.exists(key)) return;
    var canvasTex = scene.textures.createCanvas(key, w, h);
    var ctx = canvasTex.context;
    var grad = ctx.createRadialGradient(w / 2, h / 2, h * 0.35, w / 2, h / 2, h * 0.75);
    grad.addColorStop(0, 'rgba(0,0,0,0)');
    grad.addColorStop(1, 'rgba(0,0,0,0.55)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);
    canvasTex.refresh();
  },

  /** Tuile de champ d'étoiles répétable sans couture (repli sur les bords), pour la parallaxe */
  generateStarfieldTile: function (scene, key, w, h, count, maxAlpha) {
    if (scene.textures.exists(key)) return;
    var self = this;
    var canvasTex = scene.textures.createCanvas(key, w, h);
    var ctx = canvasTex.context;
    var tints = ['255,255,255', '255,255,255', '200,225,255', '255,236,205'];
    for (var i = 0; i < count; i++) {
      var x = Math.random() * w;
      var y = Math.random() * h;
      var r = Math.random() * 1.6 + 0.4;
      var a = Math.random() * maxAlpha + 0.1;
      var tint = tints[Math.floor(Math.random() * tints.length)];
      var glow = r > 1.6 && Math.random() < 0.5;   // quelques étoiles plus brillantes avec halo doux
      var R = glow ? r * 5 : r;
      self._drawWrapped(w, h, x, y, R, function (px, py) {
        if (glow) {
          var g = ctx.createRadialGradient(px, py, 0, px, py, R);
          g.addColorStop(0, 'rgba(' + tint + ',' + Math.min(1, a + 0.2).toFixed(2) + ')');
          g.addColorStop(1, 'rgba(' + tint + ',0)');
          ctx.fillStyle = g;
          ctx.beginPath();
          ctx.arc(px, py, R, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.fillStyle = 'rgba(' + tint + ',' + a.toFixed(2) + ')';
        ctx.beginPath();
        ctx.arc(px, py, r, 0, Math.PI * 2);
        ctx.fill();
      });
    }
    canvasTex.refresh();
  },

  /**
   * Voile de poussière / nuages d'espace répétable sans couture : gros nuages diffus dessinés avec
   * repli sur les bords. Utilisé en TileSprite au fond de toutes les scènes.
   */
  generateSpaceDustTile: function (scene, key, size) {
    if (scene.textures.exists(key)) return;
    var self = this;
    var canvasTex = scene.textures.createCanvas(key, size, size);
    var ctx = canvasTex.context;
    var palette = ['#3a1f8f', '#123a7a', '#0c5a86', '#5a1f6e', '#1b2f8a'];
    ctx.globalCompositeOperation = 'lighter';
    for (var i = 0; i < 16; i++) {
      var cx = Math.random() * size;
      var cy = Math.random() * size;
      var r = size * (0.12 + Math.random() * 0.2);
      var color = palette[i % palette.length];
      self._drawWrapped(size, size, cx, cy, r, function (px, py) {
        var g = ctx.createRadialGradient(px, py, 0, px, py, r);
        g.addColorStop(0, self._hexToRgba(color, 0.22));
        g.addColorStop(0.5, self._hexToRgba(color, 0.09));
        g.addColorStop(1, self._hexToRgba(color, 0));
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(px, py, r, 0, Math.PI * 2);
        ctx.fill();
      });
    }
    ctx.globalCompositeOperation = 'source-over';
    canvasTex.refresh();
  },

  _hexToRgba: function (hex, alpha) {
    hex = hex.replace('#', '');
    if (hex.length === 3) {
      hex = hex.split('').map(function (c) { return c + c; }).join('');
    }
    var r = parseInt(hex.substring(0, 2), 16);
    var g = parseInt(hex.substring(2, 4), 16);
    var b = parseInt(hex.substring(4, 6), 16);
    return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
  }
};
