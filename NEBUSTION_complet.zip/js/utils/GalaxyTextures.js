/**
 * NEBUSTION - GalaxyTextures
 * Textures procédurales (Canvas 2D, aucun fichier image) des planètes de la carte galactique :
 * une par type de Galaxy.PLANET_TYPES (palette + `feature`). Clé : 'tex_gplanet_' + type.
 * Tirages pseudo-aléatoires DÉTERMINISTES (le même monde a toujours le même aspect).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.GalaxyTextures = {
  SIZE: 168,        // texture carrée ; la sphère occupe ~ 128 px au centre, le reste est le halo d'atmosphère
  R: 64,

  generateAll: function (scene) {
    var G = NEBUSTION.Galaxy, self = this;
    if (!G) return;
    Object.keys(G.PLANET_TYPES).forEach(function (type) { self._make(scene, type, G.PLANET_TYPES[type]); });
    self._makeHome(scene);
  },

  key: function (type) { return 'tex_gplanet_' + type; },
  /** Clé dédiée de Nexus-01 (notre monde) : rendu à part, plus détaillé qu'une planète générique. */
  homeKey: function () { return 'tex_gplanet_home'; },

  _rng: function (seed) {
    var s = seed >>> 0;
    return function () { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  },

  _make: function (scene, type, def) {
    var key = this.key(type);
    if (scene.textures.exists(key)) return;
    var S = this.SIZE, R = this.R, cx = S / 2, cy = S / 2;
    var tex = scene.textures.createCanvas(key, S, S), ctx = tex.context;
    var seed = 0; for (var i = 0; i < type.length; i++) seed = (seed * 31 + type.charCodeAt(i)) >>> 0;
    var rnd = this._rng(seed + 7);

    // halo d'atmosphère
    var halo = ctx.createRadialGradient(cx, cy, R * 0.9, cx, cy, R * 1.28);
    halo.addColorStop(0, this._rgba(def.atmo, 0.55)); halo.addColorStop(1, this._rgba(def.atmo, 0));
    ctx.fillStyle = halo; ctx.beginPath(); ctx.arc(cx, cy, R * 1.28, 0, Math.PI * 2); ctx.fill();

    // sphère (lumière en haut à gauche)
    var g = ctx.createRadialGradient(cx - R * 0.38, cy - R * 0.4, R * 0.08, cx, cy, R);
    g.addColorStop(0, def.inner); g.addColorStop(1, def.outer);
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.fill();

    // relief selon le type
    ctx.save();
    ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.clip();
    var k, a, x, y, r;
    switch (def.feature) {
      case 'continents':
        for (k = 0; k < 9; k++) {
          x = cx + (rnd() - 0.5) * R * 1.7; y = cy + (rnd() - 0.5) * R * 1.7; r = R * (0.14 + rnd() * 0.2);
          ctx.fillStyle = 'rgba(20,60,40,0.30)'; ctx.beginPath(); ctx.ellipse(x, y, r, r * 0.62, rnd() * 3, 0, Math.PI * 2); ctx.fill();
        }
        break;
      case 'bands':
        for (k = 0; k < 6; k++) {
          y = cy - R + (k + 0.5) * (R * 2 / 6);
          ctx.strokeStyle = 'rgba(255,255,255,' + (0.10 + rnd() * 0.12) + ')'; ctx.lineWidth = 3 + rnd() * 5;
          ctx.beginPath(); ctx.ellipse(cx, y, R * 1.02, R * 0.16, 0, 0, Math.PI * 2); ctx.stroke();
        }
        break;
      case 'cracks':
        ctx.strokeStyle = def.inner; ctx.lineWidth = 2.2; ctx.globalAlpha = 0.85;
        for (k = 0; k < 8; k++) {
          x = cx + (rnd() - 0.5) * R * 1.5; y = cy + (rnd() - 0.5) * R * 1.5; ctx.beginPath(); ctx.moveTo(x, y);
          for (a = 0; a < 4; a++) { x += (rnd() - 0.5) * R * 0.55; y += (rnd() - 0.5) * R * 0.55; ctx.lineTo(x, y); }
          ctx.stroke();
        }
        ctx.globalAlpha = 1;
        break;
      case 'grid':
        ctx.strokeStyle = 'rgba(255,255,255,0.20)'; ctx.lineWidth = 1.5;
        for (k = -3; k <= 3; k++) {
          ctx.beginPath(); ctx.moveTo(cx - R, cy + k * R * 0.28); ctx.lineTo(cx + R, cy + k * R * 0.28); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(cx + k * R * 0.28, cy - R); ctx.lineTo(cx + k * R * 0.28, cy + R); ctx.stroke();
        }
        ctx.fillStyle = def.atmo; ctx.globalAlpha = 0.6;
        for (k = 0; k < 10; k++) ctx.fillRect(cx + (rnd() - 0.5) * R * 1.6, cy + (rnd() - 0.5) * R * 1.6, 4, 4);
        ctx.globalAlpha = 1;
        break;
      case 'swirl':
        ctx.lineWidth = 3;
        for (k = 0; k < 4; k++) {
          ctx.strokeStyle = 'rgba(200,150,255,' + (0.18 + k * 0.05) + ')'; ctx.beginPath();
          for (a = 0; a < 40; a++) { var t = a / 39, ang = t * 6.5 + k * 1.6; ctx.lineTo(cx + Math.cos(ang) * R * t * 1.05, cy + Math.sin(ang) * R * t * 1.05); }
          ctx.stroke();
        }
        break;
      case 'craters':
        for (k = 0; k < 10; k++) {
          x = cx + (rnd() - 0.5) * R * 1.6; y = cy + (rnd() - 0.5) * R * 1.6; r = R * (0.06 + rnd() * 0.12);
          ctx.fillStyle = 'rgba(0,0,0,0.28)'; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
          ctx.strokeStyle = 'rgba(255,255,255,0.18)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(x - 1, y - 1, r, 0, Math.PI * 2); ctx.stroke();
        }
        break;
      default: break;
    }
    // côté nuit
    var sh = ctx.createRadialGradient(cx + R * 0.5, cy + R * 0.5, R * 0.1, cx + R * 0.3, cy + R * 0.3, R * 1.3);
    sh.addColorStop(0, 'rgba(0,0,0,0)'); sh.addColorStop(1, 'rgba(2,4,12,0.82)');
    ctx.fillStyle = sh; ctx.fillRect(0, 0, S, S);
    ctx.restore();
    tex.refresh();
  },

  /**
   * Nexus-01, notre planète-mère : un rendu dédié et plus réaliste qu'une planète procédurale
   * générique — continents dessinés à la main (pas des taches), calottes polaires, bandes
   * nuageuses courbes + tourbillons, terminateur jour/nuit rectiligne, lumières de villes côté
   * nuit, reflet du soleil sur l'océan et liseré atmosphérique sur le limbe. Graine fixe :
   * Nexus-01 a toujours le même visage.
   */
  _makeHome: function (scene) {
    var key = this.homeKey();
    if (scene.textures.exists(key)) return;
    var S = this.SIZE, R = this.R, cx = S / 2, cy = S / 2;
    var tex = scene.textures.createCanvas(key, S, S), ctx = tex.context;
    var rnd = this._rng(20260927);

    // direction de la lumière (haut-gauche) : réutilisée pour l'océan, le terminateur, le reflet
    var lx = -0.5, ly = -0.56, ll = Math.sqrt(lx * lx + ly * ly); lx /= ll; ly /= ll;

    // halo d'atmosphère à deux couches (diffusion large + liseré serré, teinte Rayleigh)
    var haloOut = ctx.createRadialGradient(cx, cy, R * 0.92, cx, cy, R * 1.34);
    haloOut.addColorStop(0, 'rgba(110,190,255,0.50)'); haloOut.addColorStop(1, 'rgba(110,190,255,0)');
    ctx.fillStyle = haloOut; ctx.beginPath(); ctx.arc(cx, cy, R * 1.34, 0, Math.PI * 2); ctx.fill();
    var haloIn = ctx.createRadialGradient(cx, cy, R * 0.97, cx, cy, R * 1.1);
    haloIn.addColorStop(0, 'rgba(180,225,255,0)'); haloIn.addColorStop(0.6, 'rgba(180,225,255,0.32)'); haloIn.addColorStop(1, 'rgba(180,225,255,0)');
    ctx.fillStyle = haloIn; ctx.beginPath(); ctx.arc(cx, cy, R * 1.1, 0, Math.PI * 2); ctx.fill();

    ctx.save();
    ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.clip();

    // océan : dégradé profond -> turquoise côté éclairé
    var ocean = ctx.createRadialGradient(cx + lx * R * 0.4, cy + ly * R * 0.4, R * 0.05, cx, cy, R * 1.05);
    ocean.addColorStop(0, '#57cbdb'); ocean.addColorStop(0.45, '#1f7fa8'); ocean.addColorStop(0.8, '#0c3d5e'); ocean.addColorStop(1, '#051c30');
    ctx.fillStyle = ocean; ctx.fillRect(0, 0, S, S);

    // continents : masses organiques (polygones à coins arrondis), pas de simples taches
    function landmass(x0, y0, scale, tone) {
      var n = 10, pts = [], i;
      for (i = 0; i < n; i++) {
        var a = (i / n) * Math.PI * 2, rr = scale * (0.55 + rnd() * 0.55);
        pts.push([x0 + Math.cos(a) * rr, y0 + Math.sin(a) * rr * 0.85]);
      }
      ctx.fillStyle = tone; ctx.beginPath();
      ctx.moveTo((pts[0][0] + pts[n - 1][0]) / 2, (pts[0][1] + pts[n - 1][1]) / 2);
      for (i = 0; i < n; i++) {
        var p2 = pts[(i + 1) % n], mx = (pts[i][0] + p2[0]) / 2, my = (pts[i][1] + p2[1]) / 2;
        ctx.quadraticCurveTo(pts[i][0], pts[i][1], mx, my);
      }
      ctx.closePath(); ctx.fill();
    }
    [
      { x: cx - R * 0.32, y: cy - R * 0.28, s: R * 0.5 },
      { x: cx + R * 0.38, y: cy - R * 0.05, s: R * 0.4 },
      { x: cx - R * 0.05, y: cy + R * 0.42, s: R * 0.36 },
      { x: cx + R * 0.18, y: cy + R * 0.55, s: R * 0.22 }
    ].forEach(function (c) {
      landmass(c.x, c.y, c.s * 1.05, 'rgba(40,82,40,0.9)');       // relief / ombre de base
      landmass(c.x - R * 0.02, c.y - R * 0.02, c.s, '#4c8a3f');    // plaines
      landmass(c.x - R * 0.05, c.y - R * 0.05, c.s * 0.5, '#8a7a45'); // plateaux / montagnes
    });
    for (var isl = 0; isl < 6; isl++) {
      landmass(cx + (rnd() - 0.5) * R * 1.5, cy + (rnd() - 0.5) * R * 1.5, R * (0.04 + rnd() * 0.06), '#4c8a3f');
    }

    // calottes polaires
    ctx.fillStyle = 'rgba(235,248,255,0.92)';
    ctx.beginPath(); ctx.ellipse(cx, cy - R * 0.88, R * 0.62, R * 0.28, 0, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(cx, cy + R * 0.9, R * 0.55, R * 0.25, 0, 0, Math.PI * 2); ctx.fill();

    // bandes nuageuses incurvées + tourbillons cycloniques
    for (var band = 0; band < 5; band++) {
      var by = cy - R * 0.7 + band * (R * 1.4 / 4);
      ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = 4 + rnd() * 5;
      ctx.globalAlpha = 0.14 + rnd() * 0.18;
      ctx.beginPath();
      ctx.moveTo(cx - R, by + (rnd() - 0.5) * R * 0.2);
      ctx.bezierCurveTo(cx - R * 0.3, by - R * 0.18, cx + R * 0.3, by + R * 0.18, cx + R, by + (rnd() - 0.5) * R * 0.2);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
    for (var sw = 0; sw < 2; sw++) {
      var swx = cx + (rnd() - 0.5) * R * 1.1, swy = cy + (rnd() - 0.5) * R * 1.1;
      for (var t = 0; t < 3; t++) {
        ctx.strokeStyle = 'rgba(255,255,255,' + (0.22 - t * 0.06) + ')'; ctx.lineWidth = 3 - t * 0.6;
        ctx.beginPath();
        for (var a2 = 0; a2 < 22; a2++) {
          var tt = a2 / 21, ang = tt * 5 + t * 0.6, rr2 = R * 0.22 * tt;
          var px2 = swx + Math.cos(ang) * rr2, py2 = swy + Math.sin(ang) * rr2 * 0.7;
          if (a2 === 0) ctx.moveTo(px2, py2); else ctx.lineTo(px2, py2);
        }
        ctx.stroke();
      }
    }

    // terminateur jour/nuit : dégradé rectiligne le long de l'axe lumière → ombre (pas radial)
    var term = ctx.createLinearGradient(cx + lx * R, cy + ly * R, cx - lx * R, cy - ly * R);
    term.addColorStop(0, 'rgba(2,4,14,0)'); term.addColorStop(0.52, 'rgba(2,4,14,0.06)');
    term.addColorStop(0.68, 'rgba(2,6,18,0.55)'); term.addColorStop(1, 'rgba(1,3,10,0.92)');
    ctx.fillStyle = term; ctx.fillRect(0, 0, S, S);

    // lumières de villes, uniquement du côté nuit
    for (var city = 0; city < 55; city++) {
      var ang3 = rnd() * Math.PI * 2, rad3 = Math.sqrt(rnd()) * R * 0.94;
      var px3 = cx + Math.cos(ang3) * rad3, py3 = cy + Math.sin(ang3) * rad3;
      var side = (px3 - cx) * lx + (py3 - cy) * ly; // > 0 : côté jour ; < 0 : côté nuit
      if (side > -R * 0.12) continue;
      ctx.fillStyle = 'rgba(255,224,150,' + (0.4 + rnd() * 0.5) + ')';
      ctx.beginPath(); ctx.arc(px3, py3, 0.5 + rnd() * 0.8, 0, Math.PI * 2); ctx.fill();
    }

    // reflet du soleil sur l'océan (glint), côté jour
    var gx = cx + lx * R * 0.42, gy = cy + ly * R * 0.42;
    var glint = ctx.createRadialGradient(gx, gy, 0, gx, gy, R * 0.22);
    glint.addColorStop(0, 'rgba(255,255,255,0.55)'); glint.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = glint; ctx.beginPath(); ctx.arc(gx, gy, R * 0.22, 0, Math.PI * 2); ctx.fill();

    // liseré atmosphérique lumineux sur le limbe (diffusion à l'horizon)
    ctx.globalCompositeOperation = 'lighter';
    var rim = ctx.createRadialGradient(cx, cy, R * 0.86, cx, cy, R);
    rim.addColorStop(0, 'rgba(140,210,255,0)'); rim.addColorStop(1, 'rgba(140,210,255,0.35)');
    ctx.fillStyle = rim; ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.fill();
    ctx.globalCompositeOperation = 'source-over';

    ctx.restore();
    tex.refresh();
  },

  _rgba: function (hex, a) {
    var h = String(hex).replace('#', '');
    var n = parseInt(h.length === 3 ? h.replace(/(.)/g, '$1$1') : h, 16);
    return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
};
