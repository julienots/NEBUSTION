/**
 * NEBUSTION - GalaxyTextures
 * Textures procédurales (Canvas 2D, aucun fichier image) des planètes de la carte galactique :
 * une par type de Galaxy.PLANET_TYPES (palette + `feature`). Clé : 'tex_gplanet_' + type.
 * Tirages pseudo-aléatoires DÉTERMINISTES (le même monde a toujours le même aspect).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.GalaxyTextures = {
  SIZE: 168,        // texture carrée ; la sphère occupe ~ 128 px au centre, le reste est le halo d'atmosphère
  R: 64,

  generateAll: function (scene) {
    var G = NEBUSTION.Galaxy, self = this;
    if (!G) return;
    Object.keys(G.PLANET_TYPES).forEach(function (type) { self._make(scene, type, G.PLANET_TYPES[type]); });
  },

  key: function (type) { return 'tex_gplanet_' + type; },

  _rng: function (seed) {
    var s = seed >>> 0;
    return function () { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  },

  _make: function (scene, type, def) {
    var key = this.key(type);
    if (scene.textures.exists(key)) return;
    var S = this.SIZE, R = this.R, cx = S / 2, cy = S / 2;
    var tex = scene.textures.createCanvas(key, S, S), ctx = tex.context;
    var seed = 0; for (var i = 0; i < type.length; i++) seed = (seed * 31 + type.charCodeAt(i)) >>> 0;
    var rnd = this._rng(seed + 7);

    // halo d'atmosphère
    var halo = ctx.createRadialGradient(cx, cy, R * 0.9, cx, cy, R * 1.28);
    halo.addColorStop(0, this._rgba(def.atmo, 0.55)); halo.addColorStop(1, this._rgba(def.atmo, 0));
    ctx.fillStyle = halo; ctx.beginPath(); ctx.arc(cx, cy, R * 1.28, 0, Math.PI * 2); ctx.fill();

    // sphère (lumière en haut à gauche)
    var g = ctx.createRadialGradient(cx - R * 0.38, cy - R * 0.4, R * 0.08, cx, cy, R);
    g.addColorStop(0, def.inner); g.addColorStop(1, def.outer);
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.fill();

    // relief selon le type
    ctx.save();
    ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.clip();
    var k, a, x, y, r;
    switch (def.feature) {
      case 'continents':
        for (k = 0; k < 9; k++) {
          x = cx + (rnd() - 0.5) * R * 1.7; y = cy + (rnd() - 0.5) * R * 1.7; r = R * (0.14 + rnd() * 0.2);
          ctx.fillStyle = 'rgba(20,60,40,0.30)'; ctx.beginPath(); ctx.ellipse(x, y, r, r * 0.62, rnd() * 3, 0, Math.PI * 2); ctx.fill();
        }
        break;
      case 'bands':
        for (k = 0; k < 6; k++) {
          y = cy - R + (k + 0.5) * (R * 2 / 6);
          ctx.strokeStyle = 'rgba(255,255,255,' + (0.10 + rnd() * 0.12) + ')'; ctx.lineWidth = 3 + rnd() * 5;
          ctx.beginPath(); ctx.ellipse(cx, y, R * 1.02, R * 0.16, 0, 0, Math.PI * 2); ctx.stroke();
        }
        break;
      case 'cracks':
        ctx.strokeStyle = def.inner; ctx.lineWidth = 2.2; ctx.globalAlpha = 0.85;
        for (k = 0; k < 8; k++) {
          x = cx + (rnd() - 0.5) * R * 1.5; y = cy + (rnd() - 0.5) * R * 1.5; ctx.beginPath(); ctx.moveTo(x, y);
          for (a = 0; a < 4; a++) { x += (rnd() - 0.5) * R * 0.55; y += (rnd() - 0.5) * R * 0.55; ctx.lineTo(x, y); }
          ctx.stroke();
        }
        ctx.globalAlpha = 1;
        break;
      case 'grid':
        ctx.strokeStyle = 'rgba(255,255,255,0.20)'; ctx.lineWidth = 1.5;
        for (k = -3; k <= 3; k++) {
          ctx.beginPath(); ctx.moveTo(cx - R, cy + k * R * 0.28); ctx.lineTo(cx + R, cy + k * R * 0.28); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(cx + k * R * 0.28, cy - R); ctx.lineTo(cx + k * R * 0.28, cy + R); ctx.stroke();
        }
        ctx.fillStyle = def.atmo; ctx.globalAlpha = 0.6;
        for (k = 0; k < 10; k++) ctx.fillRect(cx + (rnd() - 0.5) * R * 1.6, cy + (rnd() - 0.5) * R * 1.6, 4, 4);
        ctx.globalAlpha = 1;
        break;
      case 'swirl':
        ctx.lineWidth = 3;
        for (k = 0; k < 4; k++) {
          ctx.strokeStyle = 'rgba(200,150,255,' + (0.18 + k * 0.05) + ')'; ctx.beginPath();
          for (a = 0; a < 40; a++) { var t = a / 39, ang = t * 6.5 + k * 1.6; ctx.lineTo(cx + Math.cos(ang) * R * t * 1.05, cy + Math.sin(ang) * R * t * 1.05); }
          ctx.stroke();
        }
        break;
      case 'craters':
        for (k = 0; k < 10; k++) {
          x = cx + (rnd() - 0.5) * R * 1.6; y = cy + (rnd() - 0.5) * R * 1.6; r = R * (0.06 + rnd() * 0.12);
          ctx.fillStyle = 'rgba(0,0,0,0.28)'; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
          ctx.strokeStyle = 'rgba(255,255,255,0.18)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(x - 1, y - 1, r, 0, Math.PI * 2); ctx.stroke();
        }
        break;
      default: break;
    }
    // côté nuit
    var sh = ctx.createRadialGradient(cx + R * 0.5, cy + R * 0.5, R * 0.1, cx + R * 0.3, cy + R * 0.3, R * 1.3);
    sh.addColorStop(0, 'rgba(0,0,0,0)'); sh.addColorStop(1, 'rgba(2,4,12,0.82)');
    ctx.fillStyle = sh; ctx.fillRect(0, 0, S, S);
    ctx.restore();
    tex.refresh();
  },

  _rgba: function (hex, a) {
    var h = String(hex).replace('#', '');
    var n = parseInt(h.length === 3 ? h.replace(/(.)/g, '$1$1') : h, 16);
    return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
};
