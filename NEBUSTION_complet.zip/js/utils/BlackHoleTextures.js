/**
 * NEBUSTION - BlackHoleTextures
 * Textures procédurales (Canvas 2D, aucun fichier image) du Trou Noir visible dans l'écran Univers
 * et en gros plan dans BlackHoleScene :
 *   - horizon des événements (disque noir pur)
 *   - anneau de photons (fin cercle lumineux collé à l'horizon)
 *   - disque d'accrétion incliné, dégradé chaud → froid, asymétrique (effet Doppler : côté
 *     « qui s'approche » plus brillant/blanc, côté « qui s'éloigne » plus sombre/rouge)
 *   - arcs de lumière au-dessus/au-dessous de l'horizon : approximation simple de la lentille
 *     gravitationnelle qui replie la face cachée du disque autour de la sphère (effet « Interstellar »)
 *   - version « gros plan » uniquement : jets polaires + traînées de matière en train de tomber
 * Déterministe, généré une seule fois par taille (cache Phaser via scene.textures).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.BlackHoleTextures = {
  _rng: function (seed) {
    var s = seed >>> 0;
    return function () { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  },
  _c: function (r, g, b, a) { return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')'; },

  /** Petit nœud utilisé sur la carte Univers (discret, mêmes proportions que la version détaillée). */
  ensureIcon: function (scene) {
    var key = 'tex_bh_icon';
    if (!scene.textures.exists(key)) this._draw(scene, key, 300, false);
    return key;
  },

  /** Version détaillée pour le gros plan (BlackHoleScene) : plus de définition, jets, traînées. */
  ensureCloseup: function (scene) {
    var key = 'tex_bh_closeup';
    if (!scene.textures.exists(key)) this._draw(scene, key, 900, true);
    return key;
  },

  _draw: function (scene, key, px, big) {
    var self = this, rng = this._rng(7777), c = px / 2;
    var Rh = px * 0.155;                 // rayon de l'horizon des événements
    var tilt = -0.5, squash = 0.34;      // inclinaison du disque
    var tex = scene.textures.createCanvas(key, px, px), ctx = tex.context;
    ctx.clearRect(0, 0, px, px);

    // ---- Halo diffus d'ambiance (se fond avec le fond étoilé de la scène) ----
    ctx.globalCompositeOperation = 'lighter';
    var halo = ctx.createRadialGradient(c, c, Rh * 0.6, c, c, px * 0.5);
    halo.addColorStop(0, self._c(120, 90, 255, 0.16));
    halo.addColorStop(0.5, self._c(70, 40, 160, 0.07));
    halo.addColorStop(1, self._c(0, 0, 0, 0));
    ctx.fillStyle = halo; ctx.fillRect(0, 0, px, px);

    // ---- Jets polaires (perpendiculaires au disque), version détaillée seulement ----
    if (big) {
      ctx.save();
      ctx.translate(c, c); ctx.rotate(tilt + Math.PI / 2);
      [1, -1].forEach(function (side) {
        var jet = ctx.createLinearGradient(0, 0, 0, side * px * 0.5);
        jet.addColorStop(0, self._c(200, 225, 255, 0.5));
        jet.addColorStop(0.35, self._c(140, 190, 255, 0.16));
        jet.addColorStop(1, self._c(80, 140, 255, 0));
        ctx.fillStyle = jet;
        ctx.beginPath();
        ctx.moveTo(-Rh * 0.22, 0);
        ctx.quadraticCurveTo(side * px * 0.06, side * px * 0.25, 0, side * px * 0.5);
        ctx.quadraticCurveTo(-side * px * 0.06, side * px * 0.25, Rh * 0.22, 0);
        ctx.closePath(); ctx.fill();
      });
      ctx.restore();
    }

    // ---- Arcs de lumière repliés au-dessus/au-dessous de l'horizon (lentille gravitationnelle) ----
    // Représente la face arrière du disque, dont la lumière est courbée par la gravité et
    // apparaît « pliée » autour de la sphère plutôt que cachée derrière.
    [1, -1].forEach(function (side) {
      ctx.save();
      ctx.translate(c, c + side * Rh * 0.98);
      ctx.scale(1, 0.42 * side);
      var arc = ctx.createRadialGradient(0, 0, Rh * 0.78, 0, 0, Rh * 1.55);
      arc.addColorStop(0, self._c(255, 235, 205, 0));
      arc.addColorStop(0.55, self._c(255, 205, 150, 0.55));
      arc.addColorStop(0.8, self._c(255, 150, 90, 0.32));
      arc.addColorStop(1, self._c(255, 120, 70, 0));
      ctx.fillStyle = arc;
      ctx.beginPath(); ctx.arc(0, 0, Rh * 1.55, Math.PI, 0, false); ctx.fill();
      ctx.restore();
    });

    // ---- Disque d'accrétion principal (anneau incliné, dégradé chaud → froid vers l'extérieur) ----
    ctx.save();
    ctx.translate(c, c); ctx.rotate(tilt); ctx.scale(1, squash);
    var disk = ctx.createRadialGradient(0, 0, Rh * 0.95, 0, 0, Rh * 3.1);
    disk.addColorStop(0, self._c(255, 250, 240, 0));
    disk.addColorStop(0.06, self._c(255, 250, 240, 0.95));
    disk.addColorStop(0.18, self._c(255, 214, 160, 0.85));
    disk.addColorStop(0.42, self._c(255, 150, 90, 0.55));
    disk.addColorStop(0.72, self._c(200, 70, 60, 0.28));
    disk.addColorStop(1, self._c(90, 30, 50, 0));
    ctx.fillStyle = disk;
    ctx.beginPath(); ctx.arc(0, 0, Rh * 3.1, 0, Math.PI * 2); ctx.fill();
    // grain de matière (poussière chauffée) le long de l'anneau
    for (var i = 0; i < (big ? 900 : 260); i++) {
      var rr = Rh * (1.0 + Math.pow(rng(), 1.4) * 2.0), ang = rng() * Math.PI * 2;
      var x = Math.cos(ang) * rr, y = Math.sin(ang) * rr;
      var t = (rr - Rh) / (Rh * 2.1), warm = [255, 235 - t * 120, 200 - t * 170];
      ctx.fillStyle = self._c(Math.max(0, warm[0]), Math.max(0, warm[1]), Math.max(0, warm[2]), 0.10 + rng() * 0.22);
      ctx.beginPath(); ctx.arc(x, y, (big ? 1.4 : 1.8) + rng() * 2.4, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();

    // ---- Effet Doppler : côté gauche (matière qui approche) beaucoup plus brillant/blanc,
    //      côté droit (qui s'éloigne) plus sombre et rouge. ----
    ctx.save();
    ctx.translate(c, c); ctx.rotate(tilt);
    var bright = ctx.createRadialGradient(-Rh * 1.5, 0, Rh * 0.3, -Rh * 1.5, 0, Rh * 2.4);
    bright.addColorStop(0, self._c(255, 255, 250, 0.55));
    bright.addColorStop(1, self._c(255, 255, 250, 0));
    ctx.fillStyle = bright;
    ctx.beginPath(); ctx.ellipse(0, 0, Rh * 3.2, Rh * 3.2 * squash, 0, 0, Math.PI * 2); ctx.fill();
    ctx.globalCompositeOperation = 'multiply';
    var dim = ctx.createRadialGradient(Rh * 1.6, 0, Rh * 0.3, Rh * 1.6, 0, Rh * 2.6);
    dim.addColorStop(0, self._c(160, 60, 60, 0.75));
    dim.addColorStop(1, self._c(255, 255, 255, 1));
    ctx.fillStyle = dim;
    ctx.beginPath(); ctx.ellipse(0, 0, Rh * 3.2, Rh * 3.2 * squash, 0, 0, Math.PI * 2); ctx.fill();
    ctx.restore();

    // ---- Horizon des événements : noir absolu, rien n'en ressort ----
    ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = '#000000';
    ctx.beginPath(); ctx.arc(c, c, Rh, 0, Math.PI * 2); ctx.fill();

    // ---- Anneau de photons : fin cercle lumineux exactement au bord de l'horizon ----
    ctx.globalCompositeOperation = 'lighter';
    for (var ring = 0; ring < 3; ring++) {
      ctx.lineWidth = (big ? 3.5 : 2.2) - ring * 0.9;
      ctx.strokeStyle = self._c(255, 240 - ring * 20, 210 - ring * 40, 0.85 - ring * 0.22);
      ctx.beginPath(); ctx.arc(c, c, Rh * (1.015 + ring * 0.01), 0, Math.PI * 2); ctx.stroke();
    }

    // ---- Traînées de matière en chute libre (spirale vers l'horizon), version détaillée ----
    if (big) {
      for (var s = 0; s < 26; s++) {
        var a0 = rng() * Math.PI * 2, len = 0.5 + rng() * 1.1;
        ctx.save();
        ctx.translate(c, c); ctx.rotate(a0); ctx.scale(1, squash);
        var trail = ctx.createLinearGradient(Rh * (1.3 + len), 0, Rh * 1.05, 0);
        trail.addColorStop(0, self._c(255, 220, 180, 0));
        trail.addColorStop(1, self._c(255, 240, 220, 0.5 + rng() * 0.3));
        ctx.strokeStyle = trail; ctx.lineWidth = 1 + rng() * 1.6;
        ctx.beginPath(); ctx.moveTo(Rh * (1.3 + len), 0); ctx.lineTo(Rh * 1.05, 0); ctx.stroke();
        ctx.restore();
      }
    }

    ctx.globalCompositeOperation = 'source-over';
    tex.refresh();
  }
};

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.BlackHoleTextures; }
