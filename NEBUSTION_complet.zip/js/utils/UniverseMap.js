/**
 * NEBUSTION - UniverseMap
 * Logique commune de représentation des galaxies de l'Univers (au-delà de la Voie Aube), partagée
 * par MainMenuScene (aperçu autour de Nexus-01) et UniverseScene (carte complète) :
 *   - même style visuel qu'à l'accueil : disque spiral procédural (GalaxyBackdrop), halo, cœur
 *     incandescent — coloré et façonné (bras) selon g.theme / g.visual (NEBUSTION.Universe) ;
 *   - même geste tactile : un tap fait grossir la galaxie touchée (effet de zoom local, sans jamais
 *     toucher à la caméra de la scène — le HUD et les boutons fixes restent stables), puis :
 *       - si elle est débloquée, on fond au noir et on entre dedans (GalaxyScene) ;
 *       - sinon, elle revient à sa taille et un toast affiche sa condition de déblocage.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.UniverseMap = {
  /** Construit le nœud visuel d'une galaxie et l'attache à ses gestes tactiles. Renvoie le container. */
  buildNode: function (scene, g, x, y, opts) {
    opts = opts || {};
    var U = NEBUSTION.Universe, GB = NEBUSTION.GalaxyBackdrop, ADD = Phaser.BlendModes.ADD;
    var unlocked = U.isUnlocked(g.id);
    var coreInt = parseInt(g.theme.core.replace('#', '0x'));
    var midInt = parseInt(g.theme.mid.replace('#', '0x'));
    var size = opts.size || 150;
    var dim = unlocked ? 1 : 0.5;
    var depth = opts.depth != null ? opts.depth : 40;
    var seed = opts.seed != null ? opts.seed : (g.visual && g.visual.seed) || 1;
    var arms = opts.arms != null ? opts.arms : (g.visual && g.visual.arms) || 3;

    var node = scene.add.container(x, y).setDepth(depth);

    // Halo diffus (couleur cœur du thème)
    var halo = scene.add.image(0, 0, 'tex_nebula_purple').setTint(coreInt)
      .setDisplaySize(size * 1.9, size * 1.9).setAlpha(0.22 * dim).setBlendMode(ADD);
    node.add(halo);
    scene.tweens.add({ targets: halo, alpha: 0.34 * dim, duration: 3200 + Math.random() * 1400, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });

    // Disque spiral incliné (texture procédurale propre à la galaxie ; celle de l'accueil pour "aube")
    var diskKey = g.id === 'aube' ? GB.ensureHome(scene) : GB.ensureUniverseDisk(scene, g.id, midInt, seed, arms, opts.diskPx || 620);
    var tiltBox = scene.add.container(0, 0).setRotation(opts.tilt != null ? opts.tilt : -0.28).setScale(1, opts.squash != null ? opts.squash : 0.56);
    var back = scene.add.image(0, 0, diskKey).setDisplaySize(size * 1.32, size * 1.32).setAlpha(0.26 * dim).setBlendMode(ADD).setRotation(1.1);
    var disk = scene.add.image(0, 0, diskKey).setDisplaySize(size, size).setBlendMode(ADD).setAlpha(dim);
    tiltBox.add([back, disk]);
    node.add(tiltBox);
    scene.tweens.add({ targets: disk, rotation: Math.PI * 2, duration: 42000 + Math.random() * 20000, repeat: -1, ease: 'Linear' });
    scene.tweens.add({ targets: back, rotation: 1.1 - Math.PI * 2, duration: 60000 + Math.random() * 22000, repeat: -1, ease: 'Linear' });

    // Cœur incandescent
    var coreHot = scene.add.image(0, 0, 'tex_glow_white').setDisplaySize(size * 0.24, size * 0.16)
      .setAlpha(0.85 * dim).setBlendMode(ADD).setTint(0xffe2b8);
    node.add(coreHot);
    scene.tweens.add({ targets: coreHot, alpha: 0.5 * dim, duration: 1000 + Math.random() * 300, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });

    // Libellé
    if (opts.label !== false) {
      node.add(scene.add.text(0, size * 0.44, g.name, {
        fontFamily: 'Arial, sans-serif', fontSize: (opts.fontSize || (opts.big ? '16px' : '12px')), fontStyle: '900',
        color: unlocked ? '#eaf2ff' : '#7a89ad', align: 'center'
      }).setOrigin(0.5, 0));
      if (!unlocked) {
        node.add(scene.add.text(0, size * 0.44 + (opts.big ? 21 : 16), '🔒', { fontSize: '11px' }).setOrigin(0.5, 0));
      }
    }

    // Légère dérive flottante
    if (opts.float !== false) {
      scene.tweens.add({ targets: node, y: y - 7, duration: 2600 + Math.random() * 1400, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    }

    // Zone tactile (cercle, indépendante de la dérive)
    if (opts.interactive !== false) {
      var hr = size * 0.62;
      var hit = scene.add.circle(0, 0, hr, 0xffffff, 0.001)
        .setInteractive(new Phaser.Geom.Circle(hr, hr, hr), Phaser.Geom.Circle.Contains);
      hit.input.cursor = 'pointer';
      node.add(hit);
      hit.on('pointerup', function () { NEBUSTION.UniverseMap.enter(scene, g, node); });
    }

    return node;
  },

  /** Geste de sélection : grossit la galaxie touchée sur place, puis entre dedans (ou revient). */
  enter: function (scene, g, node) {
    if (scene._umBusy) return;
    scene._umBusy = true;
    var U = NEBUSTION.Universe, cam = scene.cameras.main;
    var unlocked = U.isUnlocked(g.id);
    var baseDepth = node.depth, baseX = node.scaleX, baseY = node.scaleY;
    var growth = unlocked ? 7 : 3.2;

    node.setDepth(9999);
    scene.tweens.add({
      targets: node, scaleX: baseX * growth, scaleY: baseY * growth,
      duration: unlocked ? 650 : 420, ease: 'Cubic.easeIn'
    });

    scene.time.delayedCall(unlocked ? 380 : 240, function () {
      if (unlocked) {
        cam.fadeOut(320, 5, 7, 15);
        cam.once('camerafadeoutcomplete', function () {
          if (g.kind === 'home') scene.scene.start('GalaxyScene');
          else scene.scene.start('GalaxyScene', { sector: g.enterSector });
        });
      } else {
        NEBUSTION.UniverseMap._showLocked(scene, g, node, baseDepth, baseX, baseY);
      }
    });
  },

  _showLocked: function (scene, g, node, baseDepth, baseX, baseY) {
    if (!scene.fx) scene.fx = new NEBUSTION.FX(scene);
    var label = (g.unlock && g.unlock.label) || 'Verrouillé';
    var sub = '🔒 ' + label;
    if (g.preview) sub += '  •  Aperçu : ' + g.preview[0].name + ', ' + g.preview[1].name + '…';
    scene.fx.toast(g.name, sub);
    scene.tweens.add({
      targets: node, scaleX: baseX, scaleY: baseY, duration: 380, ease: 'Cubic.easeOut',
      onComplete: function () { node.setDepth(baseDepth); scene._umBusy = false; }
    });
  }
};
