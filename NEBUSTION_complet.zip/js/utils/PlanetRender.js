/**
 * NEBUSTION - PlanetRender
 * Planète de Nexus-01 : océans, continents, calottes, nuages, lumières de villes côté nuit,
 * reflet du soleil sur l'eau et halo d'atmosphère. Aucune image à charger : la carte du monde
 * est générée une fois (bruit 3D, donc sans couture ni déformation aux pôles), puis la sphère est
 * recalculée sur un canvas à chaque fois que la rotation change (projection inverse pixel par pixel).
 *
 * Utilisation : var r = NEBUSTION.PlanetRender.create(scene, 256, anchors);
 *               r.render(yaw, pitch, cloudOffset);   // r.key = clé de texture, r.res = taille du canvas
 * create() renvoie null si le canvas n'est pas utilisable (la scène retombe sur le dessin vectoriel).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.PlanetRender = (function () {
  'use strict';

  var MW = 384, MH = 192, TAU = Math.PI * 2, INV_TAU = 1 / TAU, INV_PI = 1 / Math.PI;
  var world = null, texCache = {};

  function mulberry(seed) {
    return function () {
      seed |= 0; seed = seed + 0x6D2B79F5 | 0;
      var t = Math.imul(seed ^ seed >>> 15, 1 | seed);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }

  /** Bruit de valeur 3D (0..1), lissé, à partir d'une graine. */
  function makeNoise(seed) {
    var rnd = mulberry(seed), P = new Uint8Array(512), V = new Float32Array(256), i, j, t;
    for (i = 0; i < 256; i++) { P[i] = i; V[i] = rnd(); }
    for (i = 255; i > 0; i--) { j = (rnd() * (i + 1)) | 0; t = P[i]; P[i] = P[j]; P[j] = t; }
    for (i = 0; i < 256; i++) P[i + 256] = P[i];
    return function (x, y, z) {
      var xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
      var xf = x - xi, yf = y - yi, zf = z - zi;
      var u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf), w = zf * zf * (3 - 2 * zf);
      xi &= 255; yi &= 255; zi &= 255;
      var a = P[xi] + yi, b = P[xi + 1] + yi;
      var aa = P[a] + zi, ab = P[a + 1] + zi, ba = P[b] + zi, bb = P[b + 1] + zi;
      var x00 = V[P[aa]] + (V[P[ba]] - V[P[aa]]) * u, x01 = V[P[aa + 1]] + (V[P[ba + 1]] - V[P[aa + 1]]) * u;
      var x10 = V[P[ab]] + (V[P[bb]] - V[P[ab]]) * u, x11 = V[P[ab + 1]] + (V[P[bb + 1]] - V[P[ab + 1]]) * u;
      var y0 = x00 + (x10 - x00) * v, y1 = x01 + (x11 - x01) * v;
      return y0 + (y1 - y0) * w;
    };
  }

  function fbm(n, x, y, z, oct) {
    var a = 0.5, f = 1, s = 0, norm = 0, i;
    for (i = 0; i < oct; i++) { s += a * n(x * f, y * f, z * f); norm += a; a *= 0.5; f *= 2.03; }
    return s / norm;
  }
  function sstep(a, b, x) { x = (x - a) / (b - a); x = x < 0 ? 0 : (x > 1 ? 1 : x); return x * x * (3 - 2 * x); }

  // Palette altitude → couleur (mers profondes → lagons → sable → forêts → roche → neige).
  var STOPS = [
    [0.00, 3, 8, 32], [0.28, 6, 26, 84], [0.42, 14, 84, 150], [0.50, 40, 170, 196], [0.518, 76, 208, 208],
    [0.524, 224, 212, 150], [0.545, 88, 170, 92], [0.60, 46, 128, 78], [0.68, 104, 116, 66],
    [0.76, 132, 98, 122], [0.86, 172, 162, 182], [1.00, 246, 248, 255]
  ];
  var SEA = 0.52;
  function buildRamp() {
    var ramp = new Uint8Array(256 * 3), i, k, h, s0, s1, t;
    for (i = 0; i < 256; i++) {
      h = i / 255;
      for (k = 0; k < STOPS.length - 2 && h > STOPS[k + 1][0]; k++) { /* cherche le segment */ }
      s0 = STOPS[k]; s1 = STOPS[k + 1];
      t = Math.max(0, Math.min(1, (h - s0[0]) / (s1[0] - s0[0])));
      ramp[i * 3] = s0[1] + (s1[1] - s0[1]) * t; ramp[i * 3 + 1] = s0[2] + (s1[2] - s0[2]) * t; ramp[i * 3 + 2] = s0[3] + (s1[3] - s0[3]) * t;
    }
    return ramp;
  }

  /**
   * Carte du monde (équirectangulaire) : albédo RGB + drapeau « eau » (reflet), nuages, lumières de villes.
   * `anchors` = [{lon, lat}] (degrés) : la base est toujours bâtie sur des terres émergées, et chaque
   * construction principale allume une petite ville visible côté nuit.
   */
  function buildWorld(anchors) {
    var t0 = Date.now();
    var alb = new Uint8ClampedArray(MW * MH * 4), cld = new Uint8Array(MW * MH), lit = new Uint8Array(MW * MH);
    var nH = makeNoise(11), nR = makeNoise(23), nM = makeNoise(37), nI = makeNoise(41), nC = makeNoise(59), nL = makeNoise(73);
    var ramp = buildRamp(), D2R = Math.PI / 180;
    var av = (anchors || []).map(function (a) {
      var lo = a.lon * D2R, la = a.lat * D2R;
      return [Math.cos(la) * Math.sin(lo), Math.sin(la), Math.cos(la) * Math.cos(lo)];
    });
    var u, v, lon, lat, cl, x, y, z, h, i, d, e, infl, ti, ai, rg, mo, ice, c, lv, mask, rc, gc, bc;
    for (v = 0; v < MH; v++) {
      lat = (0.5 - (v + 0.5) / MH) * Math.PI; cl = Math.cos(lat); y = Math.sin(lat);
      for (u = 0; u < MW; u++) {
        lon = ((u + 0.5) / MW * 2 - 1) * Math.PI;
        x = cl * Math.sin(lon); z = cl * Math.cos(lon);
        h = 0.5 + (fbm(nH, x * 1.5 + 3.1, y * 1.5 - 2.2, z * 1.5 + 1.7, 5) - 0.5) * 1.9;
        rg = 1 - Math.abs(2 * nR(x * 3.2 + 5, y * 3.2, z * 3.2 - 4) - 1);
        if (h > 0.55) h += (rg - 0.5) * 0.11;
        lv = 0; infl = 0;
        for (i = 0; i < av.length; i++) {
          d = x * av[i][0] + y * av[i][1] + z * av[i][2];
          if (d > 0.8) {
            e = Math.exp(-8 * (1 - d)); if (e > infl) infl = e;
            lv += 0.9 * Math.exp(-170 * (1 - d));
          }
        }
        if (infl > 0) {   // la base est posée sur des basses terres vertes (ni océan, ni sommets enneigés)
          h += 0.22 * infl;
          rg = 0.60 + (1 - infl) * (1 - infl) * 0.40; if (h > rg) h = rg;
        }
        h = h < 0 ? 0 : (h > 1 ? 1 : h);
        ti = v * MW + u; ai = ti * 4;
        i = (h * 255) | 0;
        rc = ramp[i * 3]; gc = ramp[i * 3 + 1]; bc = ramp[i * 3 + 2];
        if (h >= SEA) {
          mo = 0.88 + 0.24 * nM(x * 4 + 9, y * 4, z * 4 - 3);
          rc *= mo; gc *= mo; bc *= mo;
        }
        ice = sstep(58, 74, Math.abs(lat) / D2R + (nI(x * 5, y * 5, z * 5) - 0.5) * 22);
        if (ice > 0) { rc += (238 - rc) * ice; gc += (247 - gc) * ice; bc += (255 - bc) * ice; }
        alb[ai] = rc; alb[ai + 1] = gc; alb[ai + 2] = bc; alb[ai + 3] = h < SEA && ice < 0.5 ? 255 : 0;

        c = fbm(nC, x * 2.2 + 7, y * 3.1 + 1, z * 2.2 + 4, 4);
        cld[ti] = sstep(0.56, 0.78, c) * 200;

        mask = h > 0.53 && h < 0.67 ? 1 : 0;
        lv += mask * (1 - ice) * sstep(0.55, 0.75, fbm(nL, x * 6, y * 6, z * 6, 2)) * 0.85;
        lit[ti] = lv > 1 ? 255 : lv * 255;
      }
    }
    blur121(alb, 4, 3); blur121(alb, 4, 3); blur121(cld, 1, 1);   // côtes et nuages doux (l'indicateur d'eau, canal 4, reste net)
    return { alb: alb, cld: cld, lit: lit, ms: Date.now() - t0 };
  }

  /** Flou [1 2 1] séparable (longitude bouclée, latitude bornée) : adoucit les côtes en escalier de la carte. */
  function blur121(arr, stride, nch) {
    var tmp = new Uint8ClampedArray(arr.length), u, v, c, i, l, r, up, dn;
    for (v = 0; v < MH; v++) for (u = 0; u < MW; u++) {
      l = (v * MW + (u + MW - 1) % MW) * stride; i = (v * MW + u) * stride; r = (v * MW + (u + 1) % MW) * stride;
      for (c = 0; c < nch; c++) tmp[i + c] = (arr[l + c] + 2 * arr[i + c] + arr[r + c]) >> 2;
    }
    for (v = 0; v < MH; v++) for (u = 0; u < MW; u++) {
      up = (Math.max(0, v - 1) * MW + u) * stride; i = (v * MW + u) * stride; dn = (Math.min(MH - 1, v + 1) * MW + u) * stride;
      for (c = 0; c < nch; c++) arr[i + c] = (tmp[up + c] + 2 * tmp[i + c] + tmp[dn + c]) >> 2;
    }
  }

  function getWorld(anchors) { return world || (world = buildWorld(anchors)); }

  // Soleil fixe (haut-gauche, côté caméra) : la lumière ne tourne pas avec la planète.
  var LX = -0.52, LY = 0.48, LZ = 0.70;
  (function () { var n = Math.sqrt(LX * LX + LY * LY + LZ * LZ); LX /= n; LY /= n; LZ /= n; })();

  function nowMs() { return (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now(); }

  function create(scene, res, anchors) {
    var key = 'tex_planet_body_' + res, tex, ctx, img, px, W;
    try {
      W = getWorld(anchors);
      tex = texCache[key];
      if (!tex || !scene.textures.exists(key)) {
        tex = scene.textures.createCanvas(key, res, res);
        if (!tex || !tex.context) return null;
        texCache[key] = tex;
      }
      ctx = tex.context;
      img = ctx.createImageData(res, res);
      px = new Uint32Array(img.data.buffer);
    } catch (e) { return null; }

    // Pré-calcul par pixel (tout ce qui ne dépend pas de la rotation) : normale à l'écran, lumière, reflet, halo.
    var rr = res / 2 - 1.5, cx = res / 2, cy = res / 2, total = res * res;
    var idx = new Int32Array(total), nx = new Float32Array(total), ny = new Float32Array(total), nz = new Float32Array(total);
    var light = new Float32Array(total), spec = new Float32Array(total), rim = new Float32Array(total), alpha = new Uint8Array(total);
    var hx = LX, hy = LY, hz = LZ + 1, hn = Math.sqrt(hx * hx + hy * hy + hz * hz);
    hx /= hn; hy /= hn; hz /= hn;
    var M = 0, i, j, dx, dy, dd, cover, z, dot, s;
    for (j = 0; j < res; j++) {
      for (i = 0; i < res; i++) {
        dx = (i + 0.5 - cx) / rr; dy = -(j + 0.5 - cy) / rr;
        dd = Math.sqrt(dx * dx + dy * dy);
        cover = rr - dd * rr + 0.5;
        if (cover <= 0) continue;
        if (cover > 1) cover = 1;
        z = dd < 1 ? Math.sqrt(1 - dd * dd) : 0;
        if (dd > 1) { dx /= dd; dy /= dd; }
        idx[M] = j * res + i; nx[M] = dx; ny[M] = dy; nz[M] = z; alpha[M] = (cover * 255) | 0;
        dot = dx * LX + dy * LY + z * LZ;
        light[M] = sstep(-0.10, 0.42, dot);
        s = dx * hx + dy * hy + z * hz; spec[M] = s > 0 ? Math.pow(s, 55) * 0.9 : 0;
        rim[M] = Math.min(1, Math.pow(1 - z, 2.6) * 1.25);
        M++;
      }
    }

    var alb = W.alb, cld = W.cld, lit = W.lit;
    var api = {
      key: key, res: res, rr: rr, avgMs: 0,
      render: function (yaw, pitch, cloudOff) {
        var t0 = nowMs();
        var cyw = Math.cos(yaw), syw = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
        var cs = ((cloudOff * MW * INV_TAU) | 0) % MW; if (cs < 0) cs += MW;
        var k, x, y, z, y0, za, x0, z0, lon, lat, u, v, ti, ai, L, sh, R, G, B, ca, uc, e, rm, ar, n;
        for (k = 0; k < M; k++) {
          x = nx[k]; y = ny[k]; z = nz[k];
          y0 = y * cp + z * sp; za = z * cp - y * sp;
          x0 = x * cyw - za * syw; z0 = x * syw + za * cyw;
          if (y0 > 1) y0 = 1; else if (y0 < -1) y0 = -1;
          lon = Math.atan2(x0, z0); lat = Math.asin(y0);
          u = ((lon * INV_TAU + 0.5) * MW) | 0; if (u >= MW) u = MW - 1; else if (u < 0) u = 0;
          v = ((0.5 - lat * INV_PI) * MH) | 0; if (v >= MH) v = MH - 1; else if (v < 0) v = 0;
          ti = v * MW + u; ai = ti * 4;
          L = light[k]; sh = 0.07 + 0.93 * L;
          R = alb[ai] * sh; G = alb[ai + 1] * sh; B = alb[ai + 2] * sh + 7 * (1 - L);
          if (alb[ai + 3]) { n = spec[k]; R += 170 * n; G += 210 * n; B += 255 * n; }
          uc = u + cs; if (uc >= MW) uc -= MW;
          ca = cld[v * MW + uc] * 0.0039216;
          if (ca > 0.01) { e = 0.10 + 0.90 * L; R += (236 * e - R) * ca; G += (244 * e - G) * ca; B += (255 * e - B) * ca; }
          n = lit[ti];
          if (n && L < 0.5) { e = n * (0.5 - L) * 2 * (1 - ca * 0.85) * 0.0039216; R += 255 * e; G += 205 * e; B += 110 * e; }
          rm = rim[k];
          if (rm > 0.004) { ar = rm * (0.30 + 0.70 * L); R += 70 * ar; G += 170 * ar; B += 255 * ar; }
          if (R > 255) R = 255; if (G > 255) G = 255; if (B > 255) B = 255;
          px[idx[k]] = (alpha[k] << 24) | ((B | 0) << 16) | ((G | 0) << 8) | (R | 0);
        }
        ctx.putImageData(img, 0, 0);
        tex.refresh();
        var ms = nowMs() - t0;
        api.avgMs = api.avgMs ? api.avgMs * 0.9 + ms * 0.1 : ms;
      }
    };
    return api;
  }

  return { create: create, getWorld: getWorld, MW: MW, MH: MH };
})();
