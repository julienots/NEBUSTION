/**
 * NEBUSTION - PlanetRender
 * Planète de Nexus-01 : océans, continents, calottes, nuages, lumières de villes côté nuit,
 * reflet du soleil sur l'eau et halo d'atmosphère. Aucune image à charger : la carte du monde
 * est générée une fois (bruit 3D, donc sans couture ni déformation aux pôles), puis la sphère est
 * recalculée sur un canvas à chaque fois que la rotation change (projection inverse pixel par pixel).
 *
 * Utilisation : var r = NEBUSTION.PlanetRender.create(scene, 256, anchors);
 *               r.render(yaw, pitch, cloudOffset);   // r.key = clé de texture, r.res = taille du canvas
 * create() renvoie null si le canvas n'est pas utilisable (la scène retombe sur le dessin vectoriel).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.PlanetRender = (function () {
  'use strict';

  var MW = 384, MH = 192, TAU = Math.PI * 2, INV_TAU = 1 / TAU, INV_PI = 1 / Math.PI;
  var worlds = {}, texCache = {};

  /**
   * Réglages de rendu par biome. 'nexus' = la planète d'origine (inchangée). Les autres servent aux planètes du
   * système solaire (ExoPlanetScene) : rim = couleur de l'atmosphère au bord, cloud = couleur des nuages,
   * cloudK = opacité des nuages, lit = couleur des lumières (villes côté nuit, ou lave si emissive),
   * emissive = la lueur reste visible même de jour, spec = reflet du soleil sur l'eau/la glace (flag eau de la carte).
   */
  var BIOMES = {
    nexus:   { rim: [70, 170, 255],  cloud: [236, 244, 255], cloudK: 1,    lit: [255, 205, 110], emissive: false, spec: [170, 210, 255], night: 0.07 },
    ocean:   { rim: [90, 190, 255],  cloud: [240, 246, 255], cloudK: 1,    lit: [255, 215, 130], emissive: false, spec: [190, 225, 255], night: 0.07 },
    lava:    { rim: [255, 110, 40],  cloud: [70, 56, 52],    cloudK: 0.75, lit: [255, 140, 40],  emissive: true,  spec: [0, 0, 0],       night: 0.05 },
    desert:  { rim: [255, 160, 100], cloud: [236, 196, 150], cloudK: 0.55, lit: [255, 200, 120], emissive: false, spec: [0, 0, 0],       night: 0.06 },
    gas:     { rim: [255, 200, 140], cloud: [255, 236, 206], cloudK: 0.6,  lit: [0, 0, 0],       emissive: false, spec: [0, 0, 0],       night: 0.08 },
    ringgas: { rim: [255, 232, 170], cloud: [255, 246, 220], cloudK: 0.5,  lit: [0, 0, 0],       emissive: false, spec: [0, 0, 0],       night: 0.08 },
    ice:     { rim: [150, 230, 255], cloud: [244, 250, 255], cloudK: 0.8,  lit: [170, 240, 255], emissive: false, spec: [210, 240, 255], night: 0.09 }
  };

  function mulberry(seed) {
    return function () {
      seed |= 0; seed = seed + 0x6D2B79F5 | 0;
      var t = Math.imul(seed ^ seed >>> 15, 1 | seed);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }

  /** Bruit de valeur 3D (0..1), lissé, à partir d'une graine. */
  function makeNoise(seed) {
    var rnd = mulberry(seed), P = new Uint8Array(512), V = new Float32Array(256), i, j, t;
    for (i = 0; i < 256; i++) { P[i] = i; V[i] = rnd(); }
    for (i = 255; i > 0; i--) { j = (rnd() * (i + 1)) | 0; t = P[i]; P[i] = P[j]; P[j] = t; }
    for (i = 0; i < 256; i++) P[i + 256] = P[i];
    return function (x, y, z) {
      var xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
      var xf = x - xi, yf = y - yi, zf = z - zi;
      var u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf), w = zf * zf * (3 - 2 * zf);
      xi &= 255; yi &= 255; zi &= 255;
      var a = P[xi] + yi, b = P[xi + 1] + yi;
      var aa = P[a] + zi, ab = P[a + 1] + zi, ba = P[b] + zi, bb = P[b + 1] + zi;
      var x00 = V[P[aa]] + (V[P[ba]] - V[P[aa]]) * u, x01 = V[P[aa + 1]] + (V[P[ba + 1]] - V[P[aa + 1]]) * u;
      var x10 = V[P[ab]] + (V[P[bb]] - V[P[ab]]) * u, x11 = V[P[ab + 1]] + (V[P[bb + 1]] - V[P[ab + 1]]) * u;
      var y0 = x00 + (x10 - x00) * v, y1 = x01 + (x11 - x01) * v;
      return y0 + (y1 - y0) * w;
    };
  }

  function fbm(n, x, y, z, oct) {
    var a = 0.5, f = 1, s = 0, norm = 0, i;
    for (i = 0; i < oct; i++) { s += a * n(x * f, y * f, z * f); norm += a; a *= 0.5; f *= 2.03; }
    return s / norm;
  }
  function sstep(a, b, x) { x = (x - a) / (b - a); x = x < 0 ? 0 : (x > 1 ? 1 : x); return x * x * (3 - 2 * x); }

  // Palette altitude → couleur (mers profondes → lagons → sable → forêts → roche → neige).
  var STOPS = [
    [0.00, 3, 8, 32], [0.28, 6, 26, 84], [0.42, 14, 84, 150], [0.50, 40, 170, 196], [0.518, 76, 208, 208],
    [0.524, 224, 212, 150], [0.545, 88, 170, 92], [0.60, 46, 128, 78], [0.68, 104, 116, 66],
    [0.76, 132, 98, 122], [0.86, 172, 162, 182], [1.00, 246, 248, 255]
  ];
  var SEA = 0.52;
  function buildRamp() {
    var ramp = new Uint8Array(256 * 3), i, k, h, s0, s1, t;
    for (i = 0; i < 256; i++) {
      h = i / 255;
      for (k = 0; k < STOPS.length - 2 && h > STOPS[k + 1][0]; k++) { /* cherche le segment */ }
      s0 = STOPS[k]; s1 = STOPS[k + 1];
      t = Math.max(0, Math.min(1, (h - s0[0]) / (s1[0] - s0[0])));
      ramp[i * 3] = s0[1] + (s1[1] - s0[1]) * t; ramp[i * 3 + 1] = s0[2] + (s1[2] - s0[2]) * t; ramp[i * 3 + 2] = s0[3] + (s1[3] - s0[3]) * t;
    }
    return ramp;
  }

  /**
   * Carte du monde (équirectangulaire) : albédo RGB + drapeau « eau » (reflet), nuages, lumières de villes.
   * `anchors` = [{lon, lat}] (degrés) : la base est toujours bâtie sur des terres émergées, et chaque
   * construction principale allume une petite ville visible côté nuit.
   */
  function buildEarth(anchors, off, sea) {
    off = off || 0; sea = sea || 0;
    var t0 = Date.now();
    var alb = new Uint8ClampedArray(MW * MH * 4), cld = new Uint8Array(MW * MH), lit = new Uint8Array(MW * MH);
    var nH = makeNoise(11 + off), nR = makeNoise(23 + off), nM = makeNoise(37 + off), nI = makeNoise(41 + off), nC = makeNoise(59 + off), nL = makeNoise(73 + off);
    var ramp = buildRamp(), D2R = Math.PI / 180;
    var av = (anchors || []).map(function (a) {
      var lo = a.lon * D2R, la = a.lat * D2R;
      return [Math.cos(la) * Math.sin(lo), Math.sin(la), Math.cos(la) * Math.cos(lo)];
    });
    var u, v, lon, lat, cl, x, y, z, h, i, d, e, infl, ti, ai, rg, mo, ice, c, lv, mask, rc, gc, bc;
    for (v = 0; v < MH; v++) {
      lat = (0.5 - (v + 0.5) / MH) * Math.PI; cl = Math.cos(lat); y = Math.sin(lat);
      for (u = 0; u < MW; u++) {
        lon = ((u + 0.5) / MW * 2 - 1) * Math.PI;
        x = cl * Math.sin(lon); z = cl * Math.cos(lon);
        h = 0.5 + (fbm(nH, x * 1.5 + 3.1, y * 1.5 - 2.2, z * 1.5 + 1.7, 5) - 0.5) * 1.9 - sea;
        rg = 1 - Math.abs(2 * nR(x * 3.2 + 5, y * 3.2, z * 3.2 - 4) - 1);
        if (h > 0.55) h += (rg - 0.5) * 0.11;
        lv = 0; infl = 0;
        for (i = 0; i < av.length; i++) {
          d = x * av[i][0] + y * av[i][1] + z * av[i][2];
          if (d > 0.8) {
            e = Math.exp(-8 * (1 - d)); if (e > infl) infl = e;
            lv += 0.9 * Math.exp(-170 * (1 - d));
          }
        }
        if (infl > 0) {   // la base est posée sur des basses terres vertes (ni océan, ni sommets enneigés)
          h += 0.22 * infl;
          rg = 0.60 + (1 - infl) * (1 - infl) * 0.40; if (h > rg) h = rg;
        }
        h = h < 0 ? 0 : (h > 1 ? 1 : h);
        ti = v * MW + u; ai = ti * 4;
        i = (h * 255) | 0;
        rc = ramp[i * 3]; gc = ramp[i * 3 + 1]; bc = ramp[i * 3 + 2];
        if (h >= SEA) {
          mo = 0.88 + 0.24 * nM(x * 4 + 9, y * 4, z * 4 - 3);
          rc *= mo; gc *= mo; bc *= mo;
        }
        ice = sstep(58, 74, Math.abs(lat) / D2R + (nI(x * 5, y * 5, z * 5) - 0.5) * 22);
        if (ice > 0) { rc += (238 - rc) * ice; gc += (247 - gc) * ice; bc += (255 - bc) * ice; }
        alb[ai] = rc; alb[ai + 1] = gc; alb[ai + 2] = bc; alb[ai + 3] = h < SEA && ice < 0.5 ? 255 : 0;

        c = fbm(nC, x * 2.2 + 7, y * 3.1 + 1, z * 2.2 + 4, 4);
        cld[ti] = sstep(0.56, 0.78, c) * 200;

        mask = h > 0.53 && h < 0.67 ? 1 : 0;
        lv += mask * (1 - ice) * sstep(0.55, 0.75, fbm(nL, x * 6, y * 6, z * 6, 2)) * 0.85;
        lit[ti] = lv > 1 ? 255 : lv * 255;
      }
    }
    blur121(alb, 4, 3); blur121(alb, 4, 3); blur121(cld, 1, 1);   // côtes et nuages doux (l'indicateur d'eau, canal 4, reste net)
    return { alb: alb, cld: cld, lit: lit, ms: Date.now() - t0 };
  }

  /** Flou [1 2 1] séparable (longitude bouclée, latitude bornée) : adoucit les côtes en escalier de la carte. */
  function blur121(arr, stride, nch) {
    var tmp = new Uint8ClampedArray(arr.length), u, v, c, i, l, r, up, dn;
    for (v = 0; v < MH; v++) for (u = 0; u < MW; u++) {
      l = (v * MW + (u + MW - 1) % MW) * stride; i = (v * MW + u) * stride; r = (v * MW + (u + 1) % MW) * stride;
      for (c = 0; c < nch; c++) tmp[i + c] = (arr[l + c] + 2 * arr[i + c] + arr[r + c]) >> 2;
    }
    for (v = 0; v < MH; v++) for (u = 0; u < MW; u++) {
      up = (Math.max(0, v - 1) * MW + u) * stride; i = (v * MW + u) * stride; dn = (Math.min(MH - 1, v + 1) * MW + u) * stride;
      for (c = 0; c < nch; c++) arr[i + c] = (tmp[up + c] + 2 * tmp[i + c] + tmp[dn + c]) >> 2;
    }
  }

  // ------------------------------------------------------------------ autres mondes (planètes du système solaire)
  function newMaps() { return { alb: new Uint8ClampedArray(MW * MH * 4), cld: new Uint8Array(MW * MH), lit: new Uint8Array(MW * MH) }; }

  /** Parcourt la carte équirectangulaire : fn(ti, x, y, z, latRad) avec (x,y,z) = point de la sphère unité. */
  function eachTexel(fn) {
    var u, v, lat, cl, y, lon, x, z;
    for (v = 0; v < MH; v++) {
      lat = (0.5 - (v + 0.5) / MH) * Math.PI; cl = Math.cos(lat); y = Math.sin(lat);
      for (u = 0; u < MW; u++) {
        lon = ((u + 0.5) / MW * 2 - 1) * Math.PI;
        fn(v * MW + u, cl * Math.sin(lon), y, cl * Math.cos(lon), lat);
      }
    }
  }

  var _c = [0, 0, 0];
  /** Interpolation dans une palette [[r,g,b],…] (t de 0 à 1) → tableau partagé _c. */
  function ramp3(pal, t) {
    t = t < 0 ? 0 : (t > 1 ? 1 : t);
    var f = t * (pal.length - 1), i = Math.min(pal.length - 2, f | 0), k = f - i, a = pal[i], b = pal[i + 1];
    _c[0] = a[0] + (b[0] - a[0]) * k; _c[1] = a[1] + (b[1] - a[1]) * k; _c[2] = a[2] + (b[2] - a[2]) * k;
    return _c;
  }
  function put(M, ti, r, g, b, water) { var a = ti * 4; M.alb[a] = r; M.alb[a + 1] = g; M.alb[a + 2] = b; M.alb[a + 3] = water ? 255 : 0; }

  /** Pyros : croûte de basalte fissurée, rivières et lacs de lave incandescents (visibles aussi côté nuit). */
  function buildLava() {
    var M = newMaps(), nH = makeNoise(101), nR = makeNoise(103), nC = makeNoise(107), nA = makeNoise(109);
    eachTexel(function (ti, x, y, z) {
      var h = fbm(nH, x * 1.8 + 2, y * 1.8 - 1, z * 1.8 + 3, 5);
      var r = 1 - Math.abs(2 * fbm(nR, x * 3.2 + 1, y * 3.2, z * 3.2 - 2, 3) - 1);
      var crack = sstep(0.86, 0.955, r), lake = 1 - sstep(0.34, 0.41, h), lv = Math.max(crack * 0.95, lake);
      var core = Math.max(sstep(0.93, 0.985, r), lake * sstep(0.30, 0.20, h));
      var t = 0.20 + 0.80 * h, ash = nA(x * 6, y * 6, z * 6);
      var br = 30 + 52 * t + 14 * ash, bg = 22 + 32 * t + 8 * ash, bb = 20 + 26 * t + 6 * ash;
      var lr = 210 + 45 * core, lg = 70 + 120 * core, lb = 14 + 40 * core;
      put(M, ti, br + (lr * 0.85 - br) * lv, bg + (lg * 0.85 - bg) * lv, bb + (lb * 0.85 - bb) * lv, false);
      M.lit[ti] = Math.min(255, lv * (150 + 105 * core));
      M.cld[ti] = sstep(0.60, 0.84, fbm(nC, x * 2.4 + 7, y * 3 + 1, z * 2.4 + 4, 4)) * 150;
    });
    return finish(M, true);
  }

  /** Rubéa : dunes et plateaux rouille, canyons sombres, calottes de givre, tempêtes de poussière. */
  function buildDesert() {
    var M = newMaps(), nH = makeNoise(131), nD = makeNoise(137), nR = makeNoise(139), nI = makeNoise(149), nC = makeNoise(151);
    var pal = [[104, 48, 30], [170, 84, 48], [208, 122, 68], [232, 178, 116]];
    eachTexel(function (ti, x, y, z, lat) {
      var h = fbm(nH, x * 1.9 + 4, y * 1.9 - 3, z * 1.9 + 2, 5);
      var rip = 0.5 + 0.5 * Math.sin(h * 26 + fbm(nD, x * 5, y * 5, z * 5, 2) * 7);
      var c = ramp3(pal, (h - 0.25) * 1.9), can = sstep(0.90, 0.985, 1 - Math.abs(2 * fbm(nR, x * 3.6 + 2, y * 3.6, z * 3.6 - 1, 3) - 1));
      var k = (0.86 + 0.24 * rip) * (1 - 0.6 * can);
      var ice = sstep(74, 86, Math.abs(lat) * 57.2958 + (nI(x * 5, y * 5, z * 5) - 0.5) * 16);
      put(M, ti, c[0] * k + (238 - c[0] * k) * ice, c[1] * k + (232 - c[1] * k) * ice, c[2] * k + (228 - c[2] * k) * ice, false);
      M.cld[ti] = sstep(0.60, 0.82, fbm(nC, x * 2.1 + 5, y * 2.6 + 2, z * 2.1 + 3, 4)) * 120;
    });
    return finish(M, false);
  }

  /** Géantes gazeuses : bandes turbulentes, filaments clairs, grande tempête (pal = palette des bandes). */
  function buildGas(seed, pal, storm) {
    var M = newMaps(), nT = makeNoise(seed), nS = makeNoise(seed + 7), nS2 = makeNoise(seed + 13), nW = makeNoise(seed + 19);
    var sl = storm ? storm.lon * Math.PI / 180 : 0, sa = storm ? storm.lat * Math.PI / 180 : 0;
    eachTexel(function (ti, x, y, z, lat) {
      var warp = fbm(nT, x * 2.4 + 1, y * 2.4, z * 2.4 - 1, 4) - 0.5;
      var streak = nS(x * 1.6 + 3, y * 15, z * 1.6 - 2) - 0.5;
      var t = 0.5 + 0.5 * Math.sin(lat * 9 + warp * 5.5 + streak * 1.6);
      t = t * 0.85 + 0.15 * nW(x * 5, y * 5, z * 5);
      var c = ramp3(pal, t), r = c[0], g = c[1], b = c[2];
      if (storm) {   // tourbillon elliptique
        var dl = Math.atan2(x, z) - sl; dl = Math.atan2(Math.sin(dl), Math.cos(dl));
        var q = Math.sqrt((dl / 0.36) * (dl / 0.36) + ((lat - sa) / 0.17) * ((lat - sa) / 0.17));
        if (q < 1.15) {
          var k = 1 - sstep(0.72, 1.15, q), sw = 0.5 + 0.5 * Math.sin(q * 11 - Math.atan2(lat - sa, dl) * 2);
          r += (storm.color[0] * (0.8 + 0.3 * sw) - r) * k; g += (storm.color[1] * (0.8 + 0.3 * sw) - g) * k; b += (storm.color[2] * (0.8 + 0.3 * sw) - b) * k;
        }
      }
      var pole = sstep(66, 88, Math.abs(lat) * 57.2958);   // pôles plus sombres et froids
      put(M, ti, r * (1 - 0.30 * pole), g * (1 - 0.24 * pole), b * (1 - 0.10 * pole) + 14 * pole, false);
      M.cld[ti] = sstep(0.55, 0.82, nS2(x * 1.3 + 9, y * 22, z * 1.3 - 5)) * 120;
    });
    return finish(M, false);
  }

  /** Glacia : banquise blanc-bleu, crevasses profondes, mers gelées brillantes, voiles de givre. */
  function buildIce() {
    var M = newMaps(), nH = makeNoise(171), nR = makeNoise(173), nC = makeNoise(179), nL = makeNoise(181);
    eachTexel(function (ti, x, y, z, lat) {
      var h = fbm(nH, x * 1.7 + 6, y * 1.7 - 4, z * 1.7 + 1, 5);
      var cr = sstep(0.90, 0.975, 1 - Math.abs(2 * fbm(nR, x * 4 + 1, y * 4, z * 4 - 3, 3) - 1));
      var sea = 1 - sstep(0.34, 0.40, h), t = sstep(0.30, 0.85, h) * 0.8 + 0.2 * nL(x * 8, y * 8, z * 8);
      var r = 176 + 66 * t, g = 214 + 36 * t, b = 240 + 15 * t;
      r += (44 - r) * sea * 0.75; g += (108 - g) * sea * 0.75; b += (178 - b) * sea * 0.75;
      r += (70 - r) * cr * 0.7; g += (130 - g) * cr * 0.7; b += (190 - b) * cr * 0.7;
      var pole = sstep(62, 84, Math.abs(lat) * 57.2958);
      put(M, ti, r + (248 - r) * pole, g + (252 - g) * pole, b + (255 - b) * pole, sea > 0.5 && cr < 0.3 && pole < 0.4);
      M.cld[ti] = sstep(0.62, 0.84, fbm(nC, x * 2.3 + 3, y * 3 - 2, z * 2.3 + 6, 4)) * 150;
      M.lit[ti] = sea > 0.6 ? 34 : 0;   // aurore très faible sur les mers gelées, visible côté nuit
    });
    return finish(M, false);
  }

  function finish(M, softLit) {
    var t0 = Date.now();
    blur121(M.alb, 4, 3); blur121(M.cld, 1, 1);
    if (softLit) blur121(M.lit, 1, 1);
    M.ms = Date.now() - t0;
    return M;
  }

  var GAS_PAL = [[120, 76, 48], [196, 142, 96], [232, 200, 150], [176, 118, 78], [240, 216, 176]];
  var RING_PAL = [[168, 138, 92], [222, 198, 142], [244, 228, 178], [196, 168, 112], [236, 218, 168]];

  function buildWorld(anchors, biome) {
    switch (biome) {
      case 'ocean': return buildEarth(null, 200, 0.14);
      case 'lava': return buildLava();
      case 'desert': return buildDesert();
      case 'gas': return buildGas(211, GAS_PAL, { lon: 38, lat: -24, color: [178, 74, 44] });
      case 'ringgas': return buildGas(233, RING_PAL, null);
      case 'ice': return buildIce();
      default: return buildEarth(anchors, 0, 0);
    }
  }

  function getWorld(anchors, biome) {
    biome = BIOMES[biome] ? biome : 'nexus';
    return worlds[biome] || (worlds[biome] = buildWorld(anchors, biome));
  }

  // Soleil fixe (haut-gauche, côté caméra) : la lumière ne tourne pas avec la planète.
  var LX = -0.52, LY = 0.48, LZ = 0.70;
  (function () { var n = Math.sqrt(LX * LX + LY * LY + LZ * LZ); LX /= n; LY /= n; LZ /= n; })();

  function nowMs() { return (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now(); }

  function create(scene, res, anchors, biome) {
    biome = BIOMES[biome] ? biome : 'nexus';
    var B = BIOMES[biome], key = 'tex_planet_body_' + (biome === 'nexus' ? '' : biome + '_') + res, tex, ctx, img, px, W;
    try {
      W = getWorld(anchors, biome);
      tex = texCache[key];
      if (!tex || !scene.textures.exists(key)) {
        tex = scene.textures.createCanvas(key, res, res);
        if (!tex || !tex.context) return null;
        texCache[key] = tex;
      }
      ctx = tex.context;
      img = ctx.createImageData(res, res);
      px = new Uint32Array(img.data.buffer);
    } catch (e) { return null; }

    // Pré-calcul par pixel (tout ce qui ne dépend pas de la rotation) : normale à l'écran, lumière, reflet, halo.
    var rr = res / 2 - 1.5, cx = res / 2, cy = res / 2, total = res * res;
    var idx = new Int32Array(total), nx = new Float32Array(total), ny = new Float32Array(total), nz = new Float32Array(total);
    var light = new Float32Array(total), spec = new Float32Array(total), rim = new Float32Array(total), alpha = new Uint8Array(total);
    var hx = LX, hy = LY, hz = LZ + 1, hn = Math.sqrt(hx * hx + hy * hy + hz * hz);
    hx /= hn; hy /= hn; hz /= hn;
    var M = 0, i, j, dx, dy, dd, cover, z, dot, s;
    for (j = 0; j < res; j++) {
      for (i = 0; i < res; i++) {
        dx = (i + 0.5 - cx) / rr; dy = -(j + 0.5 - cy) / rr;
        dd = Math.sqrt(dx * dx + dy * dy);
        cover = rr - dd * rr + 0.5;
        if (cover <= 0) continue;
        if (cover > 1) cover = 1;
        z = dd < 1 ? Math.sqrt(1 - dd * dd) : 0;
        if (dd > 1) { dx /= dd; dy /= dd; }
        idx[M] = j * res + i; nx[M] = dx; ny[M] = dy; nz[M] = z; alpha[M] = (cover * 255) | 0;
        dot = dx * LX + dy * LY + z * LZ;
        light[M] = sstep(-0.10, 0.42, dot);
        s = dx * hx + dy * hy + z * hz; spec[M] = s > 0 ? Math.pow(s, 55) * 0.9 : 0;
        rim[M] = Math.min(1, Math.pow(1 - z, 2.6) * 1.25);
        M++;
      }
    }

    var alb = W.alb, cld = W.cld, lit = W.lit;
    var rimR = B.rim[0], rimG = B.rim[1], rimB = B.rim[2], clR = B.cloud[0], clG = B.cloud[1], clB = B.cloud[2], clK = 0.0039216 * B.cloudK;
    var ltR = B.lit[0], ltG = B.lit[1], ltB = B.lit[2], emis = B.emissive, spR = B.spec[0], spG = B.spec[1], spB = B.spec[2], nightK = B.night;
    var api = {
      key: key, res: res, rr: rr, avgMs: 0,
      render: function (yaw, pitch, cloudOff) {
        var t0 = nowMs();
        var cyw = Math.cos(yaw), syw = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
        var cs = ((cloudOff * MW * INV_TAU) | 0) % MW; if (cs < 0) cs += MW;
        var k, x, y, z, y0, za, x0, z0, lon, lat, u, v, ti, ai, L, sh, R, G, B, ca, uc, e, rm, ar, n;
        for (k = 0; k < M; k++) {
          x = nx[k]; y = ny[k]; z = nz[k];
          y0 = y * cp + z * sp; za = z * cp - y * sp;
          x0 = x * cyw - za * syw; z0 = x * syw + za * cyw;
          if (y0 > 1) y0 = 1; else if (y0 < -1) y0 = -1;
          lon = Math.atan2(x0, z0); lat = Math.asin(y0);
          u = ((lon * INV_TAU + 0.5) * MW) | 0; if (u >= MW) u = MW - 1; else if (u < 0) u = 0;
          v = ((0.5 - lat * INV_PI) * MH) | 0; if (v >= MH) v = MH - 1; else if (v < 0) v = 0;
          ti = v * MW + u; ai = ti * 4;
          L = light[k]; sh = nightK + (1 - nightK) * L;
          R = alb[ai] * sh; G = alb[ai + 1] * sh; B = alb[ai + 2] * sh + 7 * (1 - L);
          if (alb[ai + 3]) { n = spec[k]; R += spR * n; G += spG * n; B += spB * n; }
          uc = u + cs; if (uc >= MW) uc -= MW;
          ca = cld[v * MW + uc] * clK;
          if (ca > 0.01) { e = 0.10 + 0.90 * L; R += (clR * e - R) * ca; G += (clG * e - G) * ca; B += (clB * e - B) * ca; }
          n = lit[ti];
          if (n) {
            if (emis) { e = n * (1 - ca * 0.6) * 0.0039216; R += ltR * e; G += ltG * e; B += ltB * e; }   // lave : brille même de jour
            else if (L < 0.5) { e = n * (0.5 - L) * 2 * (1 - ca * 0.85) * 0.0039216; R += ltR * e; G += ltG * e; B += ltB * e; }
          }
          rm = rim[k];
          if (rm > 0.004) { ar = rm * (0.30 + 0.70 * L); R += rimR * ar; G += rimG * ar; B += rimB * ar; }
          if (R > 255) R = 255; if (G > 255) G = 255; if (B > 255) B = 255;
          px[idx[k]] = (alpha[k] << 24) | ((B | 0) << 16) | ((G | 0) << 8) | (R | 0);
        }
        ctx.putImageData(img, 0, 0);
        tex.refresh();
        var ms = nowMs() - t0;
        api.avgMs = api.avgMs ? api.avgMs * 0.9 + ms * 0.1 : ms;
      }
    };
    return api;
  }

  return { create: create, getWorld: getWorld, BIOMES: BIOMES, MW: MW, MH: MH };
})();
