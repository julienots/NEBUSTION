/**
 * NEBUSTION - GalaxyBackdrop
 * Textures procédurales (Canvas 2D, aucun fichier image) de la carte Galaxie :
 *   - 'gx_bg_<secteur>'   : fond du panneau (dégradé profond, nuages de nébuleuse, poussière d'étoiles, étoiles à aigrettes, vignette)
 *   - 'gx_disk_<secteur>' : disque galactique vu de face (bras spiraux, noyau incandescent, barre, régions HII, bandes de poussière)
 * Le disque est incliné et tourné lentement par GalaxyScene. Déterministe par secteur, généré une seule fois (cache).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.GalaxyBackdrop = {
  DISK: 760,
  DISK_R: 350,
  ARMS: { s1: 2, s2: 3, s3: 4, s4: 2, s5: 3, s6: 4, s7: 5 },

  _rng: function (seed) {
    var s = seed >>> 0;
    return function () { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  },
  _gauss: function (r) { return (r() + r() + r() + r() - 2) / 2; },
  _rgb: function (int) { return [(int >> 16) & 255, (int >> 8) & 255, int & 255]; },
  _mix: function (a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; },
  _c: function (c, a) { return 'rgba(' + Math.round(c[0]) + ',' + Math.round(c[1]) + ',' + Math.round(c[2]) + ',' + a + ')'; },

  /** Dégradé de couleur du cœur (chaud) vers le bord (teinte de l'empire, puis rose). */
  _armColor: function (rn, tint) {
    var stops = [
      [0, [255, 238, 205]], [0.22, [175, 215, 255]], [0.55, [110, 150, 255]],
      [0.8, this._mix([185, 120, 255], tint, 0.5)], [1, [255, 115, 190]]
    ];
    for (var i = 1; i < stops.length; i++) {
      if (rn <= stops[i][0]) {
        var a = stops[i - 1], b = stops[i];
        return this._mix(a[1], b[1], (rn - a[0]) / (b[0] - a[0]));
      }
    }
    return stops[stops.length - 1][1];
  },

  _puff: function (ctx, x, y, r, col, alpha) {
    var g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, this._c(col, alpha));
    g.addColorStop(1, this._c(col, 0));
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
  },

  _spike: function (ctx, x, y, len, col, alpha) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    var h = ctx.createLinearGradient(x - len, y, x + len, y);
    h.addColorStop(0, this._c(col, 0)); h.addColorStop(0.5, this._c(col, alpha)); h.addColorStop(1, this._c(col, 0));
    var v = ctx.createLinearGradient(x, y - len, x, y + len);
    v.addColorStop(0, this._c(col, 0)); v.addColorStop(0.5, this._c(col, alpha)); v.addColorStop(1, this._c(col, 0));
    ctx.fillStyle = h; ctx.fillRect(x - len, y - 0.6, len * 2, 1.2);
    ctx.fillStyle = v; ctx.fillRect(x - 0.6, y - len, 1.2, len * 2);
    this._puff(ctx, x, y, len * 0.32, [255, 255, 255], alpha * 0.9);
    ctx.restore();
  },

  /** Grande galaxie de l'écran d'accueil (texture 1024 px, dense). */
  ensureHome: function (scene) {
    var key = 'gx_disk_home';
    if (!scene.textures.exists(key)) this._makeDisk(scene, key, 0x4fd1ff, 7, 4, 1024, 1.7);
    return key;
  },

  /** Petite galaxie du starmap « Univers » (UniverseScene) : une texture dédiée par galaxie,
   *  mémorisée une seule fois (couleur + nombre de bras + graine propres à chaque galaxie). */
  ensureUniverseDisk: function (scene, id, colInt, seedIndex, arms, px) {
    var key = 'gx_disk_uni_' + id;
    if (!scene.textures.exists(key)) this._makeDisk(scene, key, colInt, 40 + (seedIndex || 1) * 17, arms || 3, px || 620, 1.25);
    return key;
  },

  keys: function (sid) { return { bg: 'gx_bg_' + sid, disk: 'gx_disk_' + sid }; },

  /** Crée (une seule fois) les deux textures du secteur. col = couleur d'empire (0xRRGGBB). */
  ensure: function (scene, sid, pw, ph, col) {
    var k = this.keys(sid), n = parseInt(String(sid).replace(/\D/g, ''), 10) || 1;
    if (!scene.textures.exists(k.bg)) this._makeBackground(scene, k.bg, pw, ph, col, n);
    if (!scene.textures.exists(k.disk)) this._makeDisk(scene, k.disk, col, n, this.ARMS[sid] || 3);
    return k;
  },

  _makeBackground: function (scene, key, pw, ph, colInt, n) {
    var self = this, rng = this._rng(9100 + n * 733), tint = this._rgb(colInt);
    var tex = scene.textures.createCanvas(key, pw, ph), ctx = tex.context;
    ctx.clearRect(0, 0, pw, ph);
    ctx.save();
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(0, 0, pw, ph, 18);
    else { ctx.moveTo(18, 0); ctx.arcTo(pw, 0, pw, ph, 18); ctx.arcTo(pw, ph, 0, ph, 18); ctx.arcTo(0, ph, 0, 0, 18); ctx.arcTo(0, 0, pw, 0, 18); }
    ctx.closePath(); ctx.clip();

    var g = ctx.createLinearGradient(0, 0, 0, ph);
    g.addColorStop(0, '#080c22'); g.addColorStop(0.55, '#04061a'); g.addColorStop(1, '#010208');
    ctx.fillStyle = g; ctx.fillRect(0, 0, pw, ph);
    self._puff(ctx, pw / 2, ph / 2, pw * 0.5, this._mix(tint, [40, 30, 110], 0.6), 0.22);

    // nuages de nébuleuse : amas de bouffées douces additives
    ctx.globalCompositeOperation = 'lighter';
    var palette = [tint, [108, 60, 233], [0, 190, 255], [255, 77, 158], this._mix(tint, [255, 255, 255], 0.3)];
    for (var c = 0; c < 8; c++) {
      var cx = rng() * pw, cy = rng() * ph, col = palette[c % palette.length], spread = 60 + rng() * 90;
      for (var i = 0; i < 16; i++) {
        var a = rng() * 6.283, d = Math.abs(self._gauss(rng)) * spread;
        self._puff(ctx, cx + Math.cos(a) * d * 1.5, cy + Math.sin(a) * d * 0.7, 40 + rng() * 80, col, 0.028 + rng() * 0.035);
      }
    }
    // poussière d'étoiles lointaines
    for (var s = 0; s < 420; s++) {
      var sx = rng() * pw, sy = rng() * ph, br = rng();
      var sc = br > 0.85 ? [255, 214, 170] : (br > 0.6 ? [170, 205, 255] : [235, 240, 255]);
      ctx.fillStyle = self._c(sc, 0.15 + rng() * 0.6);
      ctx.beginPath(); ctx.arc(sx, sy, 0.4 + rng() * (br > 0.93 ? 1.3 : 0.7), 0, 6.283); ctx.fill();
    }
    // quelques étoiles brillantes à aigrettes
    for (var b = 0; b < 9; b++) self._spike(ctx, 20 + rng() * (pw - 40), 16 + rng() * (ph - 32), 7 + rng() * 11, rng() > 0.5 ? [190, 220, 255] : [255, 225, 190], 0.55 + rng() * 0.35);

    // vignette
    ctx.globalCompositeOperation = 'source-over';
    var v = ctx.createRadialGradient(pw / 2, ph / 2, ph * 0.3, pw / 2, ph / 2, pw * 0.62);
    v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,0,4,0.62)');
    ctx.fillStyle = v; ctx.fillRect(0, 0, pw, ph);
    ctx.restore();
    tex.refresh();
  },

  /** px = taille réelle de la texture (le dessin reste en unités 760 : mise à l'échelle par le canvas) ; dens = densité d'étoiles. */
  _makeDisk: function (scene, key, colInt, n, arms, px, dens) {
    var self = this, rng = this._rng(4242 + n * 977), tint = this._rgb(colInt);
    var D = this.DISK, R = this.DISK_R, c = D / 2, k = (px || D) / D; dens = dens || 1;
    var tex = scene.textures.createCanvas(key, px || D, px || D), ctx = tex.context;
    ctx.clearRect(0, 0, px || D, px || D);
    if (k !== 1) ctx.scale(k, k);
    ctx.globalCompositeOperation = 'lighter';
    var twist = arms <= 2 ? 4.4 : (arms === 3 ? 3.9 : 3.5);
    function theta(a, rn) { return (a / arms) * 6.283 + twist * Math.log(1 + 6 * rn) / Math.log(7); }

    // halo diffus inter-bras
    for (var h = 0; h < 520; h++) {
      var hr = Math.pow(rng(), 0.75) * R, ha = rng() * 6.283;
      self._puff(ctx, c + Math.cos(ha) * hr, c + Math.sin(ha) * hr, 30 + rng() * 50, self._armColor(hr / R, tint), 0.012 + 0.02 * (1 - hr / R));
    }
    // bouffées lumineuses le long des bras
    var perArm = Math.round(1700 * dens / arms);
    for (var a = 0; a < arms; a++) {
      for (var i = 0; i < perArm; i++) {
        var rn = 0.05 + 0.95 * Math.pow(rng(), 0.92);
        var th = theta(a, rn) + self._gauss(rng) * (0.1 + 0.26 * rn), r = R * rn;
        var col = self._armColor(rn, tint);
        self._puff(ctx, c + Math.cos(th) * r, c + Math.sin(th) * r, 4 + rng() * 15 * (0.5 + rn), col, 0.05 + 0.1 * (1 - rn * 0.7));
      }
    }
    // régions HII (amas de jeunes étoiles rosés / cyan)
    for (var q = 0; q < 34; q++) {
      var qa = Math.floor(rng() * arms), qr = 0.28 + rng() * 0.66;
      var qt = theta(qa, qr) + self._gauss(rng) * 0.12;
      self._puff(ctx, c + Math.cos(qt) * R * qr, c + Math.sin(qt) * R * qr, 10 + rng() * 22, rng() > 0.45 ? [255, 110, 190] : [90, 220, 255], 0.14 + rng() * 0.16);
    }
    // étoiles individuelles
    for (var s = 0, sN = Math.round(1500 * dens); s < sN; s++) {
      var onArm = rng() < 0.82, sr, st;
      if (onArm) { var ar = Math.floor(rng() * arms); sr = Math.pow(rng(), 0.85); st = theta(ar, sr) + self._gauss(rng) * (0.08 + 0.3 * sr); }
      else { sr = Math.pow(rng(), 0.7); st = rng() * 6.283; }
      var sc = self._mix(self._armColor(sr, tint), [255, 255, 255], 0.55);
      ctx.fillStyle = self._c(sc, 0.3 + rng() * 0.65);
      ctx.beginPath(); ctx.arc(c + Math.cos(st) * R * sr, c + Math.sin(st) * R * sr, 0.45 + rng() * 1.0, 0, 6.283); ctx.fill();
    }
    // bandes de poussière sombre, sur le bord intérieur des bras
    ctx.globalCompositeOperation = 'destination-out';
    for (var d = 0; d < arms; d++) {
      for (var j = 0; j < 300; j++) {
        var dr = 0.13 + 0.82 * Math.pow(rng(), 0.9);
        var dt = theta(d, dr) - 0.17 - 0.05 * dr + self._gauss(rng) * 0.05;
        self._puff(ctx, c + Math.cos(dt) * R * dr, c + Math.sin(dt) * R * dr, 5 + rng() * 13, [0, 0, 0], 0.16);
      }
    }
    // noyau : bulbe incandescent + barre
    ctx.globalCompositeOperation = 'lighter';
    self._puff(ctx, c, c, R * 0.5, [255, 150, 90], 0.22);
    self._puff(ctx, c, c, R * 0.34, [255, 205, 140], 0.42);
    self._puff(ctx, c, c, R * 0.18, [255, 240, 210], 0.8);
    ctx.save(); ctx.translate(c, c); ctx.rotate(0.55); ctx.scale(1, 0.34);
    self._puff(ctx, 0, 0, R * 0.44, [255, 214, 160], 0.55);
    ctx.restore();
    self._puff(ctx, c, c, R * 0.06, [255, 255, 255], 1);

    // fondu doux vers le bord (aucune coupure nette)
    ctx.globalCompositeOperation = 'destination-in';
    var f = ctx.createRadialGradient(c, c, R * 0.5, c, c, R * 1.02);
    f.addColorStop(0, 'rgba(0,0,0,1)'); f.addColorStop(0.7, 'rgba(0,0,0,0.85)'); f.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = f; ctx.fillRect(0, 0, D, D);
    ctx.globalCompositeOperation = 'source-over';
    tex.refresh();
  }
};
