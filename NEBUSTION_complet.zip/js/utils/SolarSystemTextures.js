/**
 * NEBUSTION - SolarSystemTextures
 * Textures générées par code (aucune image à charger) pour le système solaire de la « Nouvelle Galaxie » :
 * soleil (surface + couronne + halo), planètes (rocheuse, lave, océanique, désert, géante gazeuse, glace),
 * anneaux, ombre portée des planètes et icône de la galaxie sur la carte Univers.
 * Chaque texture n'est créée qu'une fois (clé de texture vérifiée avant de dessiner).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.SolarTextures = {
  _rng: function (seed) {
    var s = seed >>> 0;
    return function () {
      s = (s + 0x6D2B79F5) >>> 0;
      var t = Math.imul(s ^ (s >>> 15), 1 | s);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  },
  _c: function (r, g, b, a) { return 'rgba(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ',' + a + ')'; },
  _canvas: function (scene, key, w, h) {
    var tex = scene.textures.createCanvas(key, w, h);
    tex.context.clearRect(0, 0, w, h);
    return tex;
  },
  _clipCircle: function (ctx, S) {
    ctx.beginPath(); ctx.arc(S / 2, S / 2, S / 2 - 1, 0, Math.PI * 2); ctx.closePath(); ctx.clip();
  },
  _blob: function (ctx, x, y, r, rgb, a) {
    var g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, this._c(rgb[0], rgb[1], rgb[2], a));
    g.addColorStop(1, this._c(rgb[0], rgb[1], rgb[2], 0));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
  },
  _poly: function (ctx, rnd, x, y, r, rgb, a) {
    var n = 14, i, ang, rr;
    ctx.fillStyle = this._c(rgb[0], rgb[1], rgb[2], a);
    ctx.beginPath();
    for (i = 0; i < n; i++) {
      ang = i / n * Math.PI * 2; rr = r * (0.55 + rnd() * 0.75);
      if (i === 0) ctx.moveTo(x + Math.cos(ang) * rr, y + Math.sin(ang) * rr);
      else ctx.lineTo(x + Math.cos(ang) * rr, y + Math.sin(ang) * rr);
    }
    ctx.closePath(); ctx.fill();
  },
  _mix: function (a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; },

  // ---------------------------------------------------------------- SOLEIL
  ensureSun: function (scene) {
    var key = 'tex_sol_sun';
    if (scene.textures.exists(key)) return key;
    var S = 256, c = S / 2, rnd = this._rng(4242), i, t, ctx;
    t = this._canvas(scene, key, S, S); ctx = t.context;
    ctx.save(); this._clipCircle(ctx, S);
    var g = ctx.createRadialGradient(c, c, 0, c, c, c);
    g.addColorStop(0, 'rgb(255,252,225)'); g.addColorStop(0.45, 'rgb(255,214,96)');
    g.addColorStop(0.82, 'rgb(255,150,36)'); g.addColorStop(1, 'rgb(226,84,12)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, S, S);
    for (i = 0; i < 380; i++) {   // granulation
      var x = rnd() * S, y = rnd() * S, hot = rnd() > 0.5;
      this._blob(ctx, x, y, 5 + rnd() * 13, hot ? [255, 236, 150] : [214, 78, 8], 0.10 + rnd() * 0.10);
    }
    for (i = 0; i < 7; i++) this._blob(ctx, c + (rnd() - 0.5) * 120, c + (rnd() - 0.5) * 120, 4 + rnd() * 6, [90, 24, 0], 0.45);   // taches
    var lim = ctx.createRadialGradient(c, c, c * 0.6, c, c, c);   // assombrissement du bord
    lim.addColorStop(0, 'rgba(120,30,0,0)'); lim.addColorStop(1, 'rgba(140,40,0,0.45)');
    ctx.fillStyle = lim; ctx.fillRect(0, 0, S, S);
    ctx.restore(); t.refresh();
    return key;
  },
  ensureGlow: function (scene) {
    var key = 'tex_sol_glow';
    if (scene.textures.exists(key)) return key;
    var S = 256, c = S / 2, t = this._canvas(scene, key, S, S), ctx = t.context;
    var g = ctx.createRadialGradient(c, c, 0, c, c, c);
    g.addColorStop(0, 'rgba(255,255,255,0.95)'); g.addColorStop(0.18, 'rgba(255,255,255,0.55)');
    g.addColorStop(0.5, 'rgba(255,255,255,0.14)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, S, S); t.refresh();
    return key;
  },
  ensureCorona: function (scene) {
    var key = 'tex_sol_corona';
    if (scene.textures.exists(key)) return key;
    var S = 512, c = S / 2, rnd = this._rng(99), t = this._canvas(scene, key, S, S), ctx = t.context, i;
    ctx.globalCompositeOperation = 'lighter';
    for (i = 0; i < 26; i++) {   // rayons
      var ang = i / 26 * Math.PI * 2 + rnd() * 0.15, len = c * (0.62 + rnd() * 0.36), wd = 0.05 + rnd() * 0.05;
      var g = ctx.createRadialGradient(c, c, c * 0.18, c, c, len);
      g.addColorStop(0, 'rgba(255,190,70,0.55)'); g.addColorStop(1, 'rgba(255,120,20,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(c, c);
      ctx.lineTo(c + Math.cos(ang - wd) * len, c + Math.sin(ang - wd) * len);
      ctx.lineTo(c + Math.cos(ang + wd) * len, c + Math.sin(ang + wd) * len);
      ctx.closePath(); ctx.fill();
    }
    t.refresh();
    return key;
  },

  // ---------------------------------------------------------------- PLANÈTES
  /** spec : { id, type: rock|lava|earth|desert|gas|ringgas|ice, seed, c1:[r,g,b], c2:[r,g,b] } */
  ensurePlanet: function (scene, spec) {
    var key = 'tex_sol_pl_' + spec.id;
    if (scene.textures.exists(key)) return key;
    var S = 192, c = S / 2, rnd = this._rng(spec.seed || 1), i, j, x, y, t, ctx, g;
    t = this._canvas(scene, key, S, S); ctx = t.context;
    ctx.save(); this._clipCircle(ctx, S);
    var c1 = spec.c1, c2 = spec.c2;
    ctx.fillStyle = this._c(c1[0], c1[1], c1[2], 1); ctx.fillRect(0, 0, S, S);

    if (spec.type === 'rock' || spec.type === 'desert') {
      for (i = 0; i < 70; i++) this._blob(ctx, rnd() * S, rnd() * S, 10 + rnd() * 32, this._mix(c1, c2, rnd()), 0.40);
      for (i = 0; i < 16; i++) {   // cratères
        x = rnd() * S; y = rnd() * S; var r = 4 + rnd() * 11;
        ctx.fillStyle = 'rgba(0,0,0,0.28)'; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = 'rgba(255,240,220,0.22)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(x - 1, y - 1, r, 0, Math.PI * 2); ctx.stroke();
      }
      if (spec.type === 'desert') {
        this._blob(ctx, c, 4, 34, [245, 240, 235], 0.75); this._blob(ctx, c, S - 4, 30, [245, 240, 235], 0.6);
      }
    } else if (spec.type === 'lava') {
      for (i = 0; i < 60; i++) this._blob(ctx, rnd() * S, rnd() * S, 8 + rnd() * 28, this._mix(c1, [70, 24, 14], rnd()), 0.55);
      ctx.globalCompositeOperation = 'lighter';
      ctx.shadowColor = 'rgba(255,120,20,0.9)'; ctx.shadowBlur = 8;
      for (i = 0; i < 34; i++) {   // fissures incandescentes
        x = rnd() * S; y = rnd() * S;
        ctx.strokeStyle = this._c(255, 110 + rnd() * 90, 20, 0.55 + rnd() * 0.35); ctx.lineWidth = 1 + rnd() * 2;
        ctx.beginPath(); ctx.moveTo(x, y);
        for (j = 0; j < 5; j++) { x += (rnd() - 0.5) * 34; y += (rnd() - 0.5) * 34; ctx.lineTo(x, y); }
        ctx.stroke();
      }
      ctx.shadowBlur = 0; ctx.globalCompositeOperation = 'source-over';
    } else if (spec.type === 'earth') {
      g = ctx.createLinearGradient(0, 0, 0, S);
      g.addColorStop(0, 'rgb(14,66,140)'); g.addColorStop(0.5, 'rgb(22,104,184)'); g.addColorStop(1, 'rgb(12,58,128)');
      ctx.fillStyle = g; ctx.fillRect(0, 0, S, S);
      for (i = 0; i < 9; i++) {   // continents
        var cxx = 20 + rnd() * (S - 40), cyy = 36 + rnd() * (S - 72), k;
        for (k = 0; k < 6; k++) {
          this._poly(ctx, rnd, cxx + (rnd() - 0.5) * 34, cyy + (rnd() - 0.5) * 26, 9 + rnd() * 16, [150, 132, 84], 0.95);
        }
        for (k = 0; k < 7; k++) {
          this._poly(ctx, rnd, cxx + (rnd() - 0.5) * 30, cyy + (rnd() - 0.5) * 22, 7 + rnd() * 13, [58, 142, 74], 0.95);
        }
      }
      this._blob(ctx, c, 3, 40, [250, 252, 255], 0.9); this._blob(ctx, c, S - 3, 36, [250, 252, 255], 0.85);
      for (i = 0; i < 46; i++) {   // nuages
        ctx.save(); ctx.translate(rnd() * S, rnd() * S); ctx.scale(2.4, 1);
        this._blob(ctx, 0, 0, 5 + rnd() * 9, [255, 255, 255], 0.30 + rnd() * 0.2); ctx.restore();
      }
    } else if (spec.type === 'ice') {
      for (i = 0; i < 60; i++) this._blob(ctx, rnd() * S, rnd() * S, 10 + rnd() * 30, this._mix(c1, c2, rnd()), 0.5);
      ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 1.2;
      for (i = 0; i < 22; i++) {
        x = rnd() * S; y = rnd() * S; ctx.beginPath(); ctx.moveTo(x, y);
        for (j = 0; j < 4; j++) { x += (rnd() - 0.3) * 40; y += (rnd() - 0.5) * 22; ctx.lineTo(x, y); }
        ctx.stroke();
      }
    } else {   // gas / ringgas : bandes ondulées
      var y0, bh, phase = rnd() * 6;
      for (y0 = 0; y0 < S; y0 += 4) {
        bh = 0.5 + 0.5 * Math.sin(y0 * 0.11 + phase) * Math.cos(y0 * 0.037 + phase * 1.7);
        var col = this._mix(c1, c2, Math.max(0, Math.min(1, bh)));
        ctx.fillStyle = this._c(col[0], col[1], col[2], 1);
        ctx.beginPath(); ctx.moveTo(0, y0);
        for (x = 0; x <= S; x += 8) ctx.lineTo(x, y0 + Math.sin(x * 0.05 + y0 * 0.09 + phase) * 1.8);
        ctx.lineTo(S, y0 + 5); ctx.lineTo(0, y0 + 5); ctx.closePath(); ctx.fill();
      }
      for (i = 0; i < 26; i++) {   // turbulences
        ctx.save(); ctx.translate(rnd() * S, rnd() * S); ctx.scale(3, 1);
        this._blob(ctx, 0, 0, 4 + rnd() * 6, this._mix(c1, c2, rnd()), 0.35); ctx.restore();
      }
      if (spec.type === 'gas') {   // grande tempête
        ctx.save(); ctx.translate(c + 22, c + 26); ctx.scale(1.7, 1);
        this._blob(ctx, 0, 0, 15, [170, 70, 40], 0.9); this._blob(ctx, 0, 0, 8, [220, 130, 80], 0.6); ctx.restore();
      }
    }

    // Assombrissement du limbe : donne le volume sphérique
    var lim = ctx.createRadialGradient(c, c, c * 0.35, c, c, c);
    lim.addColorStop(0, 'rgba(0,0,0,0)'); lim.addColorStop(0.75, 'rgba(0,0,0,0.10)'); lim.addColorStop(1, 'rgba(0,0,0,0.55)');
    ctx.fillStyle = lim; ctx.fillRect(0, 0, S, S);
    ctx.restore(); t.refresh();
    return key;
  },

  /** Ombre : sombre du côté droit (+x), à faire pivoter pour qu'elle pointe à l'opposé du soleil. */
  ensureShade: function (scene) {
    var key = 'tex_sol_shade';
    if (scene.textures.exists(key)) return key;
    var S = 192, t = this._canvas(scene, key, S, S), ctx = t.context;
    ctx.save(); this._clipCircle(ctx, S);
    var g = ctx.createLinearGradient(S * 0.22, 0, S * 0.98, 0);
    g.addColorStop(0, 'rgba(2,4,14,0)'); g.addColorStop(0.55, 'rgba(2,4,14,0.55)'); g.addColorStop(1, 'rgba(2,4,14,0.92)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, S, S);
    ctx.restore(); t.refresh();
    return key;
  },

  /** Anneaux : deux moitiés (arrière = haut, avant = bas) pour passer derrière / devant la planète. */
  ensureRing: function (scene) {
    var kb = 'tex_sol_ring_back', kf = 'tex_sol_ring_front';
    if (scene.textures.exists(kb) && scene.textures.exists(kf)) return [kb, kf];
    var W = 512, H = 160, cx = W / 2, cy = H / 2, rnd = this._rng(31337), i;
    var self = this;
    function draw(ctx, half) {
      ctx.save(); ctx.beginPath();
      if (half === 'back') ctx.rect(0, 0, W, cy); else ctx.rect(0, cy, W, H - cy);
      ctx.clip();
      for (i = 0; i < 46; i++) {
        var f = i / 45, rx = 168 + f * 84, ry = rx * 0.30;
        var a = (i % 7 === 3) ? 0.05 : 0.20 + rnd() * 0.42;
        var col = self._mix([236, 214, 168], [178, 150, 116], rnd());
        ctx.strokeStyle = self._c(col[0], col[1], col[2], a); ctx.lineWidth = 2.2;
        ctx.beginPath(); ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2); ctx.stroke();
      }
      ctx.restore();
    }
    var tb = this._canvas(scene, kb, W, H); draw(tb.context, 'back'); tb.refresh();
    rnd = this._rng(31337);
    var tf = this._canvas(scene, kf, W, H); draw(tf.context, 'front'); tf.refresh();
    return [kb, kf];
  },

  // ---------------------------------------------------------------- ICÔNE DE GALAXIE (carte Univers)
  ensureGalaxyIcon: function (scene) {
    var key = 'tex_sol_galaxy_icon';
    if (scene.textures.exists(key)) return key;
    var S = 300, c = S / 2, rnd = this._rng(2026), t = this._canvas(scene, key, S, S), ctx = t.context, i, arm;
    ctx.globalCompositeOperation = 'lighter';
    var halo = ctx.createRadialGradient(c, c, 4, c, c, c);
    halo.addColorStop(0, 'rgba(120,255,220,0.22)'); halo.addColorStop(0.5, 'rgba(40,150,170,0.08)'); halo.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = halo; ctx.fillRect(0, 0, S, S);
    for (arm = 0; arm < 3; arm++) {
      for (i = 0; i < 700; i++) {
        var tt = Math.pow(rnd(), 0.8), ang = arm / 3 * Math.PI * 2 + tt * 4.6 + (rnd() - 0.5) * 0.55;
        var rr = 8 + tt * (c - 16), sc = (rnd() - 0.5) * (6 + tt * 22);
        var px = c + Math.cos(ang) * rr + Math.cos(ang + 1.57) * sc, py = c + Math.sin(ang) * rr + Math.sin(ang + 1.57) * sc;
        var col = this._mix([255, 226, 150], [70, 220, 200], Math.min(1, tt * 1.3));
        if (tt > 0.7) col = this._mix(col, [90, 140, 255], (tt - 0.7) * 2);
        ctx.fillStyle = this._c(col[0], col[1], col[2], 0.25 + rnd() * 0.5);
        ctx.beginPath(); ctx.arc(px, py, 0.6 + rnd() * 1.7, 0, Math.PI * 2); ctx.fill();
      }
    }
    this._blob(ctx, c, c, 34, [255, 236, 170], 0.85); this._blob(ctx, c, c, 14, [255, 255, 255], 0.95);
    t.refresh();
    return key;
  }
};
