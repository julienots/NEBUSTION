/**
 * NEBUSTION - Fond d'espace / de galaxie (nom de fichier conservé : Shaders.js)
 *
 * Version SANS shader GPU : le fond est peint UNE fois sur un petit canvas (nébuleuse en bruit fbm + bras spiraux pour l'Univers
 * et la Galaxie), puis affiché comme une simple image lissée derrière le décor existant, avec une lente dérive.
 * Les shaders WebGL précédents (objet Shader plein écran + post-traitement des planètes) sont retirés : ils alourdissaient
 * les scènes (FPS bas → PlanetScene baissait la résolution de la planète) et rendaient l'affichage pixelisé.
 * Aucune dépendance à WebGL, aucun garde-fou FPS : coût nul après la génération (~50 ms, une fois par mode et par session).
 * API conservée pour ne rien casser : install() et planet() ne font plus rien.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Shaders = (function () {
  'use strict';

  var W = 180, H = 320;   // résolution du canvas (agrandi en lissé : la nébuleuse est floue par nature)

  function hash(x, y) { var s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453; return s - Math.floor(s); }
  function noise(x, y) {
    var ix = Math.floor(x), iy = Math.floor(y), fx = x - ix, fy = y - iy;
    fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
    var a = hash(ix, iy), b = hash(ix + 1, iy), c = hash(ix, iy + 1), d = hash(ix + 1, iy + 1);
    return a + (b - a) * fx + (c - a) * fy + (a - b - c + d) * fx * fy;
  }
  function fbm(x, y) { var v = 0, a = 0.5, i; for (i = 0; i < 4; i++) { v += a * noise(x, y); x = x * 2.03 + 17; y = y * 2.03 + 17; a *= 0.5; } return v; }
  function clamp01(v) { return v < 0 ? 0 : v > 1 ? 1 : v; }
  function smooth(a, b, x) { var t = clamp01((x - a) / (b - a)); return t * t * (3 - 2 * t); }

  /** Peint le fond dans ctx (W×H). galaxy = true : bras spiraux + cœur chaud. */
  function paint(ctx, galaxy) {
    var img = ctx.createImageData(W, H), px = img.data, asp = W / H, x, y, i = 0;
    for (y = 0; y < H; y++) {
      for (x = 0; x < W; x++, i += 4) {
        var u = x / W, v = 1 - y / H, p = u * asp, qx = p * 2.2, qy = v * 2.2;
        var n = fbm(qx + 1.6 * fbm(qx * 0.8, qy * 0.8), qy + 1.6 * fbm(qx * 0.8 + 5, qy * 0.8 + 5));
        var n2 = fbm(qx * 1.3 + 9, qy * 1.3 + 9);
        var r = 0.012, g = 0.018, b = 0.040;
        var m = smooth(0.35, 0.75, n2), pn = Math.pow(n, 2.2) * 0.34 * 1.6, pm = Math.pow(n2 * n, 3) * 0.34 * 1.2;
        r += (0.30 + (0.05 - 0.30) * m) * pn + 0.62 * pm;
        g += (0.13 + (0.42 - 0.13) * m) * pn + 0.14 * pm;
        b += (0.62 + (0.62 - 0.62) * m) * pn + 0.42 * pm;
        if (galaxy) {
          var cx = 0.5 * asp - p, cy = (0.5 - v) * 1.6, rad = Math.sqrt(cx * cx + cy * cy) + 0.001, ang = Math.atan2(cy, cx);
          var arms = 0.5 + 0.5 * Math.sin(ang * 2 - Math.log(rad) * 5.5);
          var disc = Math.exp(-rad * 2.4) * Math.pow(arms, 1.6) * (0.55 + 0.9 * fbm(ang * 2 + 3, rad * 9));
          var core = Math.exp(-rad * 7) * 0.55;
          r += 0.35 * disc * 0.42 + 1.0 * core; g += 0.55 * disc * 0.42 + 0.72 * core; b += 1.0 * disc * 0.42 + 0.42 * core;
        }
        var dx = u - 0.5, dy = (v - 0.5) * 0.8, vg = 0.55 + 0.45 * smooth(1.05, 0.25, Math.sqrt(dx * dx + dy * dy));
        px[i] = Math.min(255, r * vg * 255); px[i + 1] = Math.min(255, g * vg * 255); px[i + 2] = Math.min(255, b * vg * 255); px[i + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
  }

  function lowFX() {
    try { var st = NEBUSTION.Settings && NEBUSTION.Settings.get && NEBUSTION.Settings.get(); return !!(st && (st.batterySaver || st.reducedFX)); } catch (e) { return false; }
  }

  /** Fond d'espace derrière le décor. mode : 'space' | 'galaxy'. Retourne l'image ou null (jamais d'exception). */
  function space(scene, mode) {
    try {
      if (lowFX()) return null;
      var galaxy = mode === 'galaxy', key = 'neb_bg_' + (galaxy ? 'galaxy' : 'space'), tex;
      if (!scene.textures.exists(key)) {
        tex = scene.textures.createCanvas(key, W, H);
        paint(tex.getContext(), galaxy);
        tex.refresh();
        try { tex.setFilter(1); } catch (e) { /* lissage LINEAR par défaut */ }
      }
      var w = scene.scale.width, h = scene.scale.height;
      var im = scene.add.image(w / 2, h / 2, key).setDepth(-120).setDisplaySize(w * 1.08, h * 1.08);
      try {   // lente dérive (cheap : un seul tween sur une image)
        scene.tweens.add({ targets: im, x: w / 2 - 14, y: h / 2 + 10, duration: 26000, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
      } catch (e) { /* facultatif */ }
      return im;
    } catch (e) { return null; }
  }

  function install() { return false; }   // plus de pipeline GPU
  function planet() { return false; }    // plus d'effet de planète (source de ralentissement)

  return { install: install, space: space, planet: planet, _paint: paint, W: W, H: H };
})();
