/**
 * NEBUSTION - Shaders (WebGL)
 *  - Fond spatial animé (nébuleuse fbm + étoiles scintillantes ; variante « galaxie » avec bras spiraux et cœur lumineux) :
 *    un objet Shader plein écran placé derrière le décor existant (SceneBackground.build l'appelle : toutes les scènes en profitent).
 *  - Effet de planète (post-traitement sur la sphère) : liseré d'atmosphère à la couleur du monde, reflet, léger scintillement.
 * Sécurité : rien n'est fait en mode Canvas, en économie de batterie ou en effets réduits ; toute erreur => on ignore l'effet
 * (le décor classique reste affiché). Réglages : constantes GLSL ci-dessous (NEB_NEBULA, NEB_STARS...).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Shaders = (function () {
  'use strict';

  var SPACE_FRAG = [
    '#ifdef GL_FRAGMENT_PRECISION_HIGH', 'precision highp float;', '#else', 'precision mediump float;', '#endif',
    'uniform float time; uniform vec2 resolution; uniform float uMode;',
    'float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }',
    'float noise(vec2 p) { vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);',
    '  return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y); }',
    'float fbm(vec2 p) { float v = 0.0, a = 0.5; for (int i = 0; i < 3; i++) { v += a * noise(p); p = p * 2.03 + 17.0; a *= 0.5; } return v; }',
    'float stars(vec2 uv, float scale, float thr, float tw) {',
    '  vec2 g = uv * scale, id = floor(g), f = fract(g) - 0.5;',
    '  float h = hash(id); if (h < thr) return 0.0;',
    '  vec2 o = vec2(hash(id + 3.1), hash(id + 7.7)) - 0.5; float d = length(f - o * 0.6);',
    '  float b = smoothstep(0.09, 0.0, d) * (0.55 + 0.45 * sin(time * (0.8 + h * 2.4) + h * 40.0) * tw);',
    '  return b * (0.5 + 0.5 * h); }',
    'void main() {',
    '  vec2 uv = gl_FragCoord.xy / resolution; float asp = resolution.x / resolution.y;',
    '  vec2 p = vec2(uv.x * asp, uv.y);',
    '  float NEB = 0.34;',
    '  vec3 col = vec3(0.012, 0.018, 0.040);',
    '  vec2 q = p * 2.2 + vec2(time * 0.010, -time * 0.006);',
    '  float n = fbm(q + 1.6 * fbm(q * 0.8 + time * 0.018));',
    '  float n2 = fbm(q * 1.3 + 9.0 - time * 0.012);',
    '  vec3 c1 = vec3(0.30, 0.13, 0.62), c2 = vec3(0.05, 0.42, 0.62), c3 = vec3(0.62, 0.14, 0.42);',
    '  col += mix(c1, c2, smoothstep(0.35, 0.75, n2)) * pow(n, 2.2) * NEB * 1.6;',
    '  col += c3 * pow(n2 * n, 3.0) * NEB * 1.2;',
    '  if (uMode > 0.5) {',
    '    vec2 c = vec2(0.5 * asp, 0.5) - p; c.y *= 1.6; float r = length(c) + 0.001; float a = atan(c.y, c.x);',
    '    float arms = 0.5 + 0.5 * sin(a * 2.0 - log(r) * 5.5 + time * 0.06);',
    '    float disc = exp(-r * 2.4) * pow(arms, 1.6) * (0.55 + 0.9 * fbm(vec2(a * 2.0, r * 9.0) + time * 0.03));',
    '    col += vec3(0.35, 0.55, 1.0) * disc * 0.42 + vec3(1.0, 0.72, 0.42) * exp(-r * 7.0) * 0.55;',
    '  }',
    '  float s = stars(uv * vec2(asp, 1.0), 38.0, 0.955, 1.0) + stars(uv * vec2(asp, 1.0) + 4.2, 90.0, 0.975, 1.0) * 0.8;',
    '  col += vec3(0.82, 0.9, 1.0) * s;',
    '  float vg = smoothstep(1.05, 0.25, length((uv - 0.5) * vec2(1.0, 0.8)));',
    '  col *= 0.55 + 0.45 * vg;',
    '  gl_FragColor = vec4(col, 1.0);',
    '}'
  ].join('\n');

  var PLANET_FRAG = [
    'precision mediump float;',
    'uniform sampler2D uMainSampler; uniform float time; uniform vec3 rimColor;',
    'varying vec2 outTexCoord;',
    'void main() {',
    '  vec4 c = texture2D(uMainSampler, outTexCoord);',
    '  vec2 p = (outTexCoord - 0.5) * 2.0; float d = length(p);',
    '  float rim = smoothstep(0.50, 0.985, d);',
    '  float pulse = 0.88 + 0.12 * sin(time * 1.4);',
    '  vec3 col = c.rgb + rimColor * (rim * rim * 0.55 * pulse) * c.a;',
    '  float sheen = smoothstep(0.55, 0.0, length(p - vec2(-0.38, -0.42)));',
    '  col += vec3(1.0, 0.97, 0.9) * sheen * 0.07 * c.a;',
    '  gl_FragColor = vec4(col, c.a);',
    '}'
  ].join('\n');

  var enabled = null;   // pipeline enregistré ?

  function webgl(scene) {
    try { return !!(scene && scene.sys && scene.sys.game && scene.sys.game.renderer && scene.sys.game.renderer.type === Phaser.WEBGL && scene.sys.game.renderer.pipelines); } catch (e) { return false; }
  }
  function lowFX() {
    try { var st = NEBUSTION.Settings && NEBUSTION.Settings.get && NEBUSTION.Settings.get(); return !!(st && (st.batterySaver || st.reducedFX)); } catch (e) { return false; }
  }
  function rgb(hex) { return [((hex >> 16) & 255) / 255, ((hex >> 8) & 255) / 255, (hex & 255) / 255]; }

  /** À appeler une fois après la création du jeu : enregistre le post-traitement des planètes. */
  function install(game) {
    try {
      if (game && !game.renderer && game.events && Phaser.Core && Phaser.Core.Events) { game.events.once(Phaser.Core.Events.READY, function () { install(game); }); return false; }
      if (!game || !game.renderer || game.renderer.type !== Phaser.WEBGL || !game.renderer.pipelines) { enabled = false; return false; }
      var Post = Phaser.Renderer.WebGL.Pipelines.PostFXPipeline;
      var PlanetFX = class NebPlanetFX extends Post {
        constructor(g) { super({ game: g, name: 'NebPlanetFX', fragShader: PLANET_FRAG }); this.rim = [0.5, 0.8, 1.0]; }
        onPreRender() { this.set1f('time', this.game.loop.time / 1000); this.set3f('rimColor', this.rim[0], this.rim[1], this.rim[2]); }
      };
      game.renderer.pipelines.addPostPipeline('NebPlanetFX', PlanetFX);
      enabled = true; return true;
    } catch (e) { enabled = false; return false; }
  }

  /** Fond animé plein écran derrière le décor. mode : 'space' | 'galaxy'. Retourne l'objet ou null. */
  function space(scene, mode) {
    try {
      if (!webgl(scene) || lowFX()) return null;
      var key = 'neb_space_shader';
      if (!scene.cache.shader.exists(key)) {
        scene.cache.shader.add(key, new Phaser.Display.BaseShader(key, SPACE_FRAG, undefined, { uMode: { type: '1f', value: 0 } }));
      }
      var w = scene.scale.width, h = scene.scale.height;
      var sh = scene.add.shader(key, w / 2, h / 2, w, h).setDepth(-120);
      sh.setUniform('uMode.value', mode === 'galaxy' ? 1 : 0);
      return sh;
    } catch (e) { return null; }
  }

  /** Liseré d'atmosphère + reflet sur l'image d'une planète (couleur hex). */
  function planet(scene, img, colorHex) {
    try {
      if (!enabled || !img || !webgl(scene) || lowFX()) return false;
      if (!img.getPostPipeline('NebPlanetFX') || (Array.isArray(img.getPostPipeline('NebPlanetFX')) && !img.getPostPipeline('NebPlanetFX').length)) img.setPostPipeline('NebPlanetFX');
      var p = img.getPostPipeline('NebPlanetFX'); if (Array.isArray(p)) p = p[0];
      if (p) p.rim = rgb(colorHex === undefined ? 0x7fe6ff : colorHex);
      return !!p;
    } catch (e) { return false; }
  }

  return { install: install, space: space, planet: planet, _SPACE_FRAG: SPACE_FRAG, _PLANET_FRAG: PLANET_FRAG };
})();
