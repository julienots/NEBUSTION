/**
 * NEBUSTION - HeroTextures
 * Portraits des héros. Pour chaque héros, tente de charger une vraie image depuis
 * assets/heroes/<id>.png ; si le fichier n'existe pas, génère un portrait temporaire
 * distinct (Canvas 2D) à partir de son identité visuelle (silhouette + accessoire +
 * couleurs + cadre de rareté). Le reste du jeu ne fait AUCUNE différence entre les deux :
 * il utilise toujours la texture NEBUSTION.Heroes.portraitKey(id).
 *
 * => Remplacer un portrait plus tard = déposer le fichier image au bon endroit,
 *    sans modifier une seule ligne de code.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.HeroTextures = {
  PORTRAIT_W: 300,
  PORTRAIT_H: 380,

  /**
   * Génère (ou charge) les portraits de tous les héros.
   * @param {Phaser.Scene} scene
   * @param {Function} onDone appelé une fois toutes les textures prêtes
   */
  generateAll: function (scene, onDone) {
    var self = this;
    var heroes = NEBUSTION.Heroes.all();
    var missing = {};
    var finished = false;
    var guard = null;

    function finish() {
      if (finished) return;
      finished = true;
      if (guard) guard.stop();
      heroes.forEach(function (h) {
        var key = NEBUSTION.Heroes.portraitKey(h.id);
        if (missing[key] || !scene.textures.exists(key)) {
          self._generatePlaceholder(scene, key, h);
        }
      });
      if (onDone) onDone();
    }

    function onLoadError(file) {
      if (file && file.key) missing[file.key] = true;
    }

    var queued = 0;
    heroes.forEach(function (h) {
      var key = NEBUSTION.Heroes.portraitKey(h.id);
      if (!scene.textures.exists(key)) {
        scene.load.image(key, NEBUSTION.Heroes.portraitFile(h.id));
        queued++;
      }
    });

    if (queued === 0) { finish(); return; }

    scene.load.on('loaderror', onLoadError);
    scene.load.once('complete', function () {
      scene.load.off('loaderror', onLoadError);
      finish();
    });
    // Sécurité : si le loader est réellement bloqué (aucun octet reçu pendant 15 s), on ne bloque pas
    // indéfiniment le jeu sur l'écran de chargement. Un chargement lent mais actif n'est JAMAIS interrompu
    // (l'ancien délai fixe de 4 s remplaçait les vraies illustrations par des portraits générés).
    guard = NEBUSTION.LoaderGuard.watch(scene, finish);
    scene.load.start();
  },

  // ---------- Génération procédurale ----------
  _generatePlaceholder: function (scene, key, hero) {
    if (scene.textures.exists(key)) scene.textures.remove(key);
    var w = this.PORTRAIT_W, h = this.PORTRAIT_H;
    var tex = scene.textures.createCanvas(key, w, h);
    var ctx = tex.context;
    var v = hero.visual || {};
    var rarity = NEBUSTION.Heroes.RARITIES[hero.rarity] || NEBUSTION.Heroes.RARITIES.commun;

    this._drawBackdrop(ctx, w, h, v.accent2 || '#141b30', rarity.hex);
    this._drawBody(ctx, w, h, v.body || 'slim', v.accent || '#8fd8ff', v.accent2 || '#141b30', v.wingStyle);
    this._drawProp(ctx, w, h, v.prop || 'dual_blades', v.accent || '#8fd8ff');
    this._drawFrame(ctx, w, h, rarity);

    tex.refresh();
  },

  _hexToRgba: function (hex, a) {
    hex = hex.replace('#', '');
    if (hex.length === 3) hex = hex.split('').map(function (c) { return c + c; }).join('');
    var r = parseInt(hex.substring(0, 2), 16), g = parseInt(hex.substring(2, 4), 16), b = parseInt(hex.substring(4, 6), 16);
    return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
  },
  _lin: function (ctx, x0, y0, x1, y1, stops) {
    var g = ctx.createLinearGradient(x0, y0, x1, y1);
    stops.forEach(function (s) { g.addColorStop(s[0], s[1]); });
    return g;
  },
  _rad: function (ctx, x, y, r0, r1, stops) {
    var g = ctx.createRadialGradient(x, y, r0, x, y, r1);
    stops.forEach(function (s) { g.addColorStop(s[0], s[1]); });
    return g;
  },
  _poly: function (ctx, pts) {
    ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]);
    for (var i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
    ctx.closePath();
  },

  _drawBackdrop: function (ctx, w, h, dark, accentHex) {
    ctx.fillStyle = this._lin(ctx, 0, 0, 0, h, [[0, '#0b1020'], [1, dark]]);
    ctx.fillRect(0, 0, w, h);
    // halo derrière le personnage, teinté par la rareté
    ctx.fillStyle = this._rad(ctx, w / 2, h * 0.42, 10, w * 0.6, [[0, this._hexToRgba(accentHex, 0.30)], [1, this._hexToRgba(accentHex, 0)]]);
    ctx.beginPath(); ctx.arc(w / 2, h * 0.42, w * 0.6, 0, Math.PI * 2); ctx.fill();
    // socle
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    ctx.beginPath(); ctx.ellipse(w / 2, h - 26, w * 0.32, 14, 0, 0, Math.PI * 2); ctx.fill();
  },

  _drawFrame: function (ctx, w, h, rarity) {
    var hex = rarity.hex;
    ctx.save();
    ctx.shadowColor = hex; ctx.shadowBlur = 10;
    ctx.strokeStyle = hex; ctx.lineWidth = 5;
    ctx.strokeRect(4, 4, w - 8, h - 8);
    ctx.restore();
    // coins renforcés
    ctx.strokeStyle = hex; ctx.lineWidth = 3;
    var c = 22;
    [[4, 4, 1, 1], [w - 4, 4, -1, 1], [4, h - 4, 1, -1], [w - 4, h - 4, -1, -1]].forEach(function (p) {
      ctx.beginPath();
      ctx.moveTo(p[0], p[1] + c * p[3]);
      ctx.lineTo(p[0], p[1]);
      ctx.lineTo(p[0] + c * p[2], p[1]);
      ctx.stroke();
    });
    // étoiles de rareté en bas
    var n = rarity.stars, sx = w / 2 - (n - 1) * 12, sy = h - 20;
    ctx.fillStyle = hex; ctx.shadowColor = hex; ctx.shadowBlur = 6;
    for (var i = 0; i < n; i++) { this._star(ctx, sx + i * 24, sy, 7); }
  },
  _star: function (ctx, cx, cy, r) {
    ctx.beginPath();
    for (var i = 0; i < 10; i++) {
      var a = (Math.PI / 5) * i - Math.PI / 2;
      var rad = (i % 2 === 0) ? r : r * 0.45;
      var x = cx + Math.cos(a) * rad, y = cy + Math.sin(a) * rad;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.closePath(); ctx.fill();
  },

  // ---------- Silhouettes (corps) ----------
  _drawBody: function (ctx, w, h, type, accent, accent2, wingStyle) {
    var cx = w / 2, base = h - 46;
    var grad = this._lin(ctx, 0, base - 220, 0, base, [[0, this._hexToRgba(accent, 1)], [1, this._hexToRgba(accent2, 1)]]);
    ctx.save(); ctx.shadowColor = accent; ctx.shadowBlur = 16; ctx.fillStyle = grad;

    switch (type) {
      case 'bulky':
        this._poly(ctx, [[cx - 58, base], [cx - 66, base - 130], [cx - 40, base - 176], [cx, base - 192], [cx + 40, base - 176], [cx + 66, base - 130], [cx + 58, base]]);
        ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.14)';
        ctx.fillRect(cx - 30, base - 150, 60, 14);
        break;
      case 'robed':
        this._poly(ctx, [[cx - 20, base - 210], [cx + 20, base - 210], [cx + 74, base], [cx - 74, base]]);
        ctx.fill();
        ctx.fillStyle = this._hexToRgba(accent, 0.35);
        ctx.beginPath(); ctx.ellipse(cx, base - 226, 30, 30, 0, Math.PI, 0); ctx.fill();
        break;
      case 'winged':
        this._drawWings(ctx, cx, base - 150, accent, accent2, wingStyle);
        this._poly(ctx, [[cx - 34, base], [cx - 40, base - 140], [cx - 18, base - 182], [cx, base - 192], [cx + 18, base - 182], [cx + 40, base - 140], [cx + 34, base]]);
        ctx.fill();
        if (wingStyle === 'dragon') {
          ctx.fillStyle = accent2;
          this._poly(ctx, [[cx, base - 4], [cx + 30, base + 8], [cx + 54, base - 2]]);
          ctx.fill();
        }
        break;
      case 'armored_soldier':
        this._poly(ctx, [[cx - 46, base], [cx - 52, base - 150], [cx - 26, base - 186], [cx, base - 196], [cx + 26, base - 186], [cx + 52, base - 150], [cx + 46, base]]);
        ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.16)';
        ctx.fillRect(cx - 18, base - 170, 36, 8);
        break;
      case 'slim':
      default:
        this._poly(ctx, [[cx - 30, base], [cx - 34, base - 150], [cx - 14, base - 190], [cx, base - 200], [cx + 14, base - 190], [cx + 34, base - 150], [cx + 30, base]]);
        ctx.fill();
        break;
    }
    ctx.restore();

    // tête
    ctx.fillStyle = grad;
    ctx.beginPath(); ctx.arc(cx, base - (type === 'robed' ? 224 : (type === 'bulky' ? 200 : (type === 'winged' ? 196 : 206))), (type === 'bulky' ? 24 : 20), 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.85)';
    var eyeY = base - (type === 'robed' ? 224 : (type === 'bulky' ? 200 : (type === 'winged' ? 196 : 206)));
    ctx.beginPath(); ctx.arc(cx - 6, eyeY, 2.4, 0, Math.PI * 2); ctx.arc(cx + 6, eyeY, 2.4, 0, Math.PI * 2); ctx.fill();
  },

  _drawWings: function (ctx, cx, cy, accent, accent2, style) {
    ctx.save();
    var col = style === 'ice' ? this._hexToRgba(accent, 0.85) : this._hexToRgba(accent, 0.9);
    ctx.fillStyle = col;
    ctx.shadowColor = accent; ctx.shadowBlur = 14;
    var spikes = style === 'ice' ? 5 : 4;
    [-1, 1].forEach(function (side) {
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      for (var i = 0; i <= spikes; i++) {
        var t = i / spikes;
        var len = 90 + (i % 2 === 0 ? 30 : 0);
        var ang = (Math.PI / 2.6) * t * side;
        ctx.lineTo(cx + Math.sin(ang) * len * side, cy - Math.cos(ang) * len * 0.6 - t * 10);
      }
      ctx.lineTo(cx, cy + 30);
      ctx.closePath();
      ctx.fill();
    });
    ctx.restore();
  },

  // ---------- Accessoires ----------
  _drawProp: function (ctx, w, h, type, accent) {
    var cx = w / 2, base = h - 46;
    ctx.save();
    ctx.strokeStyle = accent; ctx.fillStyle = accent;
    ctx.shadowColor = accent; ctx.shadowBlur = 10;

    switch (type) {
      case 'dual_blades':
        ctx.lineWidth = 6;
        ctx.beginPath(); ctx.moveTo(cx - 70, base - 60); ctx.lineTo(cx - 20, base - 170); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(cx + 70, base - 60); ctx.lineTo(cx + 20, base - 170); ctx.stroke();
        break;
      case 'shield':
        this._poly(ctx, [[cx - 74, base - 90], [cx - 74, base - 150], [cx - 46, base - 172], [cx - 18, base - 150], [cx - 18, base - 90], [cx - 46, base - 66]]);
        ctx.globalAlpha = 0.85; ctx.fill(); ctx.globalAlpha = 1;
        ctx.lineWidth = 3; ctx.strokeStyle = '#ffffff'; ctx.stroke();
        break;
      case 'staff_orb':
        ctx.lineWidth = 6; ctx.strokeStyle = accent;
        ctx.beginPath(); ctx.moveTo(cx + 60, base + 4); ctx.lineTo(cx + 60, base - 210); ctx.stroke();
        ctx.beginPath(); ctx.arc(cx + 60, base - 224, 14, 0, Math.PI * 2); ctx.fill();
        break;
      case 'rifle':
        ctx.lineWidth = 10; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(cx - 60, base - 40); ctx.lineTo(cx + 66, base - 118); ctx.stroke();
        break;
      case 'claws_mane':
        ctx.lineWidth = 4;
        for (var i = -2; i <= 2; i++) {
          ctx.beginPath();
          ctx.moveTo(cx + i * 12, base - 196);
          ctx.lineTo(cx + i * 18, base - 226 - Math.abs(i) * 6);
          ctx.stroke();
        }
        break;
      case 'hologram_cards':
        ctx.globalAlpha = 0.75;
        [[-1, -30], [1, -70]].forEach(function (p) {
          ctx.strokeRect(cx + p[0] * 56 - 16, base + p[1], 32, 44);
        });
        ctx.globalAlpha = 1;
        break;
      case 'orbiting_orbs':
        [0, 2.1, 4.2].forEach(function (a) {
          var ox = cx + Math.cos(a) * 62, oy = (base - 130) + Math.sin(a) * 26;
          ctx.beginPath(); ctx.arc(ox, oy, 7, 0, Math.PI * 2); ctx.fill();
        });
        break;
      case 'fire_hands':
        [-1, 1].forEach(function (side) {
          ctx.beginPath();
          ctx.moveTo(cx + side * 44, base - 60);
          ctx.quadraticCurveTo(cx + side * 70, base - 100, cx + side * 46, base - 140);
          ctx.quadraticCurveTo(cx + side * 60, base - 100, cx + side * 44, base - 60);
          ctx.fill();
        });
        break;
      case 'hammer':
        ctx.lineWidth = 8;
        ctx.beginPath(); ctx.moveTo(cx, base + 4); ctx.lineTo(cx, base - 150); ctx.stroke();
        ctx.fillRect(cx - 34, base - 176, 68, 34);
        break;
      default:
        break;
    }
    ctx.restore();
  }
};
