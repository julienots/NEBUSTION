/**
 * NEBUSTION - BlackHoleRender
 * Rendu « réaliste » du Trou Noir, par pixel, dans un petit canvas (même principe que PlanetRender.js) :
 * pas de shader GPU, pas d'image — la lumière est réellement courbée.
 *
 * PHYSIQUE (unités G = c = M = 1 ; horizon r = 2 ; ombre b = 3√3 ≈ 5,196) :
 *  - Chaque pixel de l'écran est un rayon lumineux de paramètre d'impact b. Dans le plan de ce rayon, la trajectoire
 *    obéit à l'équation de Schwarzschild  u'' + u = 3u²  (u = 1/r, angle φ). Comme elle ne dépend QUE de b, elle est
 *    intégrée une seule fois (RK4) pour ~200 valeurs de b et stockée dans une table (buildTables) ; ensuite chaque
 *    pixel ne fait que des lectures de table → le rendu tient en quelques millisecondes.
 *  - Le disque d'accrétion est le plan équatorial : les angles de croisement d'un rayon avec ce plan sont analytiques
 *    (φk = φ0 + kπ). On lit donc, à chaque croisement, le rayon r où la lumière a traversé le disque :
 *    k = 0 image directe, k = 1 la face cachée repliée AU-DESSUS/AU-DESSOUS de l'ombre, k = 2 l'anneau fin de photons.
 *  - Effet Doppler + décalage gravitationnel : g = √(1−2,2/r) / (1 + Ω·x·sin i)  (matière qui s'approche = plus
 *    brillante, plus blanche/bleue ; qui s'éloigne = plus sombre, plus rouge). Intensité ∝ g³, teinte ∝ g.
 *  - Le fond d'étoiles est lu dans la direction où le rayon s'échappe : les étoiles proches de l'ombre sont étirées en arcs.
 *  - Les rayons captés (b < 3√3) ne ramènent rien : l'ombre est noire, et opaque devant le décor.
 *
 * DEUX PASSES (pour économiser la batterie) :
 *  - geometry(cam) : coûteuse, refaite seulement quand la caméra bouge (inclinaison, roulis, zoom, azimut).
 *  - shade(t, px)  : bon marché, refaite à chaque image ; ne fait que faire tourner le disque (turbulence à
 *    rotation différentielle, deux couches en fondu pour que les spirales ne s'enroulent jamais à l'infini).
 *
 * Le cœur (makeEngine) n'a aucune dépendance à Phaser → testable sous Node (tests/blackhole-render.test.js,
 * tools/bh-preview.js). create(scene) l'enveloppe dans une texture canvas Phaser.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.BlackHoleRender = (function () {
  'use strict';

  var PI = Math.PI, TAU = PI * 2, HALF_PI = PI / 2, INV_PI = 1 / PI, INV_TAU = 1 / TAU, INV_LN10 = 1 / Math.LN10;
  var BC = 3 * Math.sqrt(3);                 // rayon apparent de l'ombre (paramètre d'impact critique)
  var R_IN = 4.0, R_OUT = 15.5;              // bord interne / externe du disque (trou noir en rotation : ISCO rapprochée)
  var U_IN = 1 / R_IN, U_OUT = 1 / R_OUT;
  var K = 3;                                 // images du disque par rayon : directe, repliée, anneau
  var DPHI = 0.03, INV_DPHI = 1 / DPHI, NP = 532, PHI_MAX = (NP - 1) * DPHI;
  var NB = 220, LO = -4.2, HI_O = Math.log(((30 - BC) / BC)) * INV_LN10, KO = (NB - 1) / (HI_O - LO), KI = (NB - 1) / (0 - LO);
  var B_TAB = 30;                            // au-delà : pas de lentille calculée (le décor est déjà là)
  var B_DISK = 16.8;                         // au-delà de ce paramètre d'impact, aucun rayon ne peut toucher le disque (r ≤ R_OUT)
  var NR = 192, NA = 512;                    // carte de turbulence du disque : rayon × azimut
  var SW = 1024, SH = 512;                   // carte d'étoiles équirectangulaire
  var PERIOD = 16;                           // s : durée d'une couche de turbulence avant recyclage en fondu
  var W0 = 0.36;                             // rad/s : vitesse (visuelle) du bord interne du disque
  var DOPPLER = 0.62;                        // force de l'effet Doppler (1 = physique, trop violent à l'écran)

  function sstep(a, b, x) { var t = (x - a) / (b - a); t = t < 0 ? 0 : (t > 1 ? 1 : t); return t * t * (3 - 2 * t); }
  function clamp(x, a, b) { return x < a ? a : (x > b ? b : x); }
  function rngMake(seed) { var s = seed >>> 0; return function () { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; }; }
  function hash2(x, y, seed) {
    var n = (Math.imul(x, 374761393) + Math.imul(y, 668265263) + Math.imul(seed, 1442695041)) | 0;
    n = Math.imul(n ^ (n >>> 13), 1274126177); n = n ^ (n >>> 16);
    return (n >>> 0) / 4294967296;
  }
  function nowMs() { return (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now(); }

  // =====================================================================================================
  //  Tables partagées (construites une seule fois par session)
  // =====================================================================================================
  var TB = null, STARS = null, DISK = null;

  /** Intègre  u'' = −u + 3u²  depuis l'observateur (u=0, u'=1/b). Remplit U[off..off+NP) et renvoie φ de fuite/capture (ou −1). */
  function trace(b, U, off) {
    var u = 0, w = 1 / b, phi = 0, h = DPHI * 0.5, state = 0, endPhi = -1, m, s;
    U[off] = 0;
    for (m = 1; m < NP; m++) {
      if (state === 0) {
        for (s = 0; s < 2 && state === 0; s++) {
          var k1u = w, k1w = -u + 3 * u * u;
          var u2 = u + 0.5 * h * k1u, w2 = w + 0.5 * h * k1w;
          var k2u = w2, k2w = -u2 + 3 * u2 * u2;
          var u3 = u + 0.5 * h * k2u, w3 = w + 0.5 * h * k2w;
          var k3u = w3, k3w = -u3 + 3 * u3 * u3;
          var u4 = u + h * k3u, w4 = w + h * k3w;
          var k4u = w4, k4w = -u4 + 3 * u4 * u4;
          var un = u + h / 6 * (k1u + 2 * k2u + 2 * k3u + k4u), wn = w + h / 6 * (k1w + 2 * k2w + 2 * k3w + k4w);
          if (!(un === un) || un >= 0.5) { endPhi = phi + h * (0.5 - u) / ((un - u) || 1); if (endPhi < phi) endPhi = phi; state = 2; }
          else if (un <= 0 && phi > 0.02) { endPhi = phi + h * u / ((u - un) || 1); state = 1; }
          u = un; w = wn; phi += h;
        }
      }
      U[off + m] = state === 0 ? u : (state === 1 ? 0 : 0.5);
    }
    return endPhi;
  }

  function buildTables() {
    if (TB) return TB;
    var outer = new Float32Array(NB * NP), inner = new Float32Array(NB * NP);
    var phiEsc = new Float32Array(NB), phiCap = new Float32Array(NB), j, f, e, d, b, pe;
    for (j = 0; j < NB; j++) {
      f = j / (NB - 1);
      e = Math.pow(10, LO + (HI_O - LO) * f);
      pe = trace(BC * (1 + e), outer, j * NP);
      phiEsc[j] = pe > 0 ? pe : PHI_MAX;
      d = Math.pow(10, LO + (0 - LO) * f);
      b = BC * (1 - d); if (b < 0.03) b = 0.03;
      pe = trace(b, inner, j * NP);
      phiCap[j] = pe > 0 ? pe : PHI_MAX;
    }
    TB = { outer: outer, inner: inner, phiEsc: phiEsc, phiCap: phiCap };
    return TB;
  }

  /** Ciel : Voie lactée violette discrète + étoiles ponctuelles (carte lon/lat). Lue par la direction d'échappement du rayon. */
  function buildStars() {
    if (STARS) return STARS;
    var data = new Uint8Array(SW * SH * 3), rnd = rngMake(90210), x, y, i, lon, lat, cl, dx, dy, dz, band, mw, nz, k;
    var nX = 0.30, nY = -0.24, nZ = 0.92, nn = Math.sqrt(nX * nX + nY * nY + nZ * nZ); nX /= nn; nY /= nn; nZ /= nn;
    for (y = 0; y < SH; y++) {
      lat = (0.5 - (y + 0.5) / SH) * PI; cl = Math.cos(lat);
      for (x = 0; x < SW; x++) {
        lon = ((x + 0.5) / SW - 0.5) * TAU;
        dx = cl * Math.cos(lon); dy = cl * Math.sin(lon); dz = Math.sin(lat);
        band = Math.abs(dx * nX + dy * nY + dz * nZ);
        nz = 0.55 + 0.45 * Math.sin(lon * 5.0 + Math.sin(lat * 7.0) * 2.0) * Math.cos(lat * 9.0 + lon * 2.0);
        mw = Math.exp(-(band / 0.20) * (band / 0.20)) * nz;
        k = (y * SW + x) * 3;
        data[k] = clamp(mw * 34, 0, 255); data[k + 1] = clamp(mw * 24, 0, 255); data[k + 2] = clamp(mw * 52, 0, 255);
      }
    }
    var COLS = [[255, 255, 255], [190, 215, 255], [255, 236, 200], [255, 190, 140], [170, 200, 255]];
    for (i = 0; i < 3400; i++) {
      var zz = rnd() * 2 - 1, ph = rnd() * TAU, rr = Math.sqrt(1 - zz * zz);
      lat = Math.asin(zz); lon = ph - PI;
      var mag = Math.pow(rnd(), 3.4), br = 75 + mag * 180, sig = 0.62 + mag * 0.55, col = COLS[(rnd() * COLS.length) | 0];
      var cx = (lon / TAU + 0.5) * SW, cy = (0.5 - lat / PI) * SH, sxk = 1 / Math.max(0.25, Math.cos(lat));
      var rx = Math.min(8, Math.ceil(sig * 2.6 * sxk)), ry = Math.ceil(sig * 2.6), ix, iy, w;
      for (iy = -ry; iy <= ry; iy++) {
        var yy = Math.round(cy) + iy; if (yy < 0 || yy >= SH) continue;
        for (ix = -rx; ix <= rx; ix++) {
          var xx = ((Math.round(cx) + ix) % SW + SW) % SW;
          w = Math.exp(-(ix * ix / (sxk * sxk) + iy * iy) / (2 * sig * sig));
          if (w < 0.02) continue;
          k = (yy * SW + xx) * 3;
          data[k] = Math.min(255, data[k] + col[0] * w * br / 255);
          data[k + 1] = Math.min(255, data[k + 1] + col[1] * w * br / 255);
          data[k + 2] = Math.min(255, data[k + 2] + col[2] * w * br / 255);
        }
      }
    }
    STARS = data;
    return STARS;
  }

  /** Turbulence du disque : rayon × azimut (périodique en azimut), longues stries le long de l'orbite + fins anneaux concentriques. */
  function buildDisk() {
    if (DISK) return DISK;
    var noise = new Uint8Array(NR * NA), OCT = [[9, 14, 1.0, 11], [18, 31, 0.62, 23], [40, 66, 0.4, 37], [88, 134, 0.24, 41], [190, 270, 0.13, 53]];
    var sumA = 0, o, rb, ab, v, x, y, ix, iy, fx, fy, ix1, a, b, c, d, ca, cr, oc, n, lineNoise = new Float32Array(NR);
    for (o = 0; o < OCT.length; o++) sumA += OCT[o][2];
    for (rb = 0; rb < NR; rb++) lineNoise[rb] = 0.5 * hash2(rb >> 1, 7, 91) + 0.5 * hash2(rb, 3, 17);
    for (rb = 0; rb < NR; rb++) {
      for (ab = 0; ab < NA; ab++) {
        v = 0;
        for (o = 0; o < OCT.length; o++) {
          oc = OCT[o]; ca = oc[0]; cr = oc[1];
          x = ab / NA * ca; y = rb / NR * cr;
          ix = Math.floor(x); fx = x - ix; iy = Math.floor(y); fy = y - iy;
          fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
          ix = ix % ca; ix1 = (ix + 1) % ca;
          a = hash2(ix, iy, oc[3]); b = hash2(ix1, iy, oc[3]); c = hash2(ix, iy + 1, oc[3]); d = hash2(ix1, iy + 1, oc[3]);
          n = (a + (b - a) * fx) * (1 - fy) + (c + (d - c) * fx) * fy;
          v += n * oc[2];
        }
        v = v / sumA;
        v = clamp((v - 0.5) * 2.5 + 0.5, 0, 1);
        v *= 0.80 + 0.36 * lineNoise[rb];
        noise[rb * NA + ab] = clamp(v * 255, 0, 255);
      }
    }
    // Profil radial (par bin de rayon) : émissivité, bord adouci, vitesse angulaire visuelle, décalage gravitationnel, Ω physique
    var erad = new Float32Array(NR), erad0 = new Float32Array(NR), edge = new Float32Array(NR), trad = new Float32Array(NR),
        omb = new Float32Array(NR), omp = new Float32Array(NR), grav = new Float32Array(NR), r;
    for (rb = 0; rb < NR; rb++) {
      r = R_IN + (R_OUT - R_IN) * (rb + 0.5) / NR;
      edge[rb] = sstep(R_IN, R_IN + 0.85, r) * (1 - sstep(R_OUT - 4.2, R_OUT, r));
      erad0[rb] = Math.pow(R_IN / r, 1.55);
      erad[rb] = erad0[rb] * edge[rb];
      trad[rb] = Math.pow(R_IN / r, 0.72);
      omb[rb] = W0 * Math.pow(R_IN / r, 1.35) * NA * INV_TAU;
      omp[rb] = Math.pow(r, -1.5);
      grav[rb] = Math.sqrt(Math.max(0.05, 1 - 2.2 / r));
    }
    // Palette corps noir (indice 0..255 ↔ température relative 0..1,5) : brun sombre → orange → or → blanc → bleu pâle
    var lutR = new Float32Array(256), lutG = new Float32Array(256), lutB = new Float32Array(256);
    var ANC = [[0.00, 34, 8, 6], [0.16, 120, 28, 12], [0.34, 222, 78, 24], [0.54, 255, 146, 56], [0.74, 255, 196, 112], [0.94, 255, 232, 182], [1.14, 255, 250, 238], [1.34, 214, 232, 255], [1.50, 168, 204, 255]];
    var i, t, j;
    for (i = 0; i < 256; i++) {
      t = i / 255 * 1.5;
      for (j = 0; j < ANC.length - 1; j++) if (t <= ANC[j + 1][0]) break;
      if (j >= ANC.length - 1) j = ANC.length - 2;
      var A = ANC[j], Bc = ANC[j + 1], f = clamp((t - A[0]) / (Bc[0] - A[0]), 0, 1);
      lutR[i] = (A[1] + (Bc[1] - A[1]) * f) / 255; lutG[i] = (A[2] + (Bc[2] - A[2]) * f) / 255; lutB[i] = (A[3] + (Bc[3] - A[3]) * f) / 255;
    }
    DISK = { noise: noise, erad: erad, erad0: erad0, edge: edge, trad: trad, omb: omb, omp: omp, grav: grav, lutR: lutR, lutG: lutG, lutB: lutB };
    return DISK;
  }

  // =====================================================================================================
  //  Moteur (aucune dépendance à Phaser)
  // =====================================================================================================
  function makeEngine(res) {
    var tb = buildTables(), stars = buildStars(), dk = buildDisk();
    var N = res * res;
    var rI = new Float32Array(K * N), aI = new Float32Array(K * N), gI = new Float32Array(K * N), gT = new Float32Array(K * N);
    var addR = new Float32Array(N), addG = new Float32Array(N), addB = new Float32Array(N);
    var bgR = new Float32Array(N), bgG = new Float32Array(N), bgB = new Float32Array(N), fadeA = new Float32Array(N);
    var outR = new Float32Array(N), outG = new Float32Array(N), outB = new Float32Array(N);
    var BW = res >> 2, blA = new Float32Array(BW * BW * 3), blB = new Float32Array(BW * BW * 3);
    var outer = tb.outer, inner = tb.inner, phiEsc = tb.phiEsc;
    var noise = dk.noise, erad = dk.erad, erad0 = dk.erad0, edgeT = dk.edge, trad = dk.trad, omb = dk.omb, omp = dk.omp, grav = dk.grav;
    var lutR = dk.lutR, lutG = dk.lutG, lutB = dk.lutB;
    var eng = { res: res, N: N, geoMs: 0, shadeMs: 0, hasGeometry: false, lastCam: null };

    /** Passe géométrique : lentille, croisements du disque, Doppler, étoiles, anneau, halo, jets. */
    eng.geometry = function (cam) {
      var t0 = nowMs();
      var incl = cam.incl, roll = cam.roll || 0, W = cam.W, az = cam.az || 0;
      var ci = Math.cos(incl), si = Math.sin(incl), cr = Math.cos(roll), sr = Math.sin(roll), caz = Math.cos(az), saz = Math.sin(az);
      var half = res * 0.5, s = W / half, i, j, p, k, q;
      var jetAmp = 0.25 + 0.75 * si, jetLen = 0.45 + 0.55 * si;
      for (j = 0; j < res; j++) {
        for (i = 0; i < res; i++) {
          p = j * res + i;
          var xs = (i + 0.5 - half) * s, ys = (half - (j + 0.5)) * s;
          var x = xs * cr - ys * sr, y = xs * sr + ys * cr;
          var b = Math.sqrt(x * x + y * y); if (b < 1e-4) b = 1e-4;
          var cpsi = x / b, spsi = y / b;
          rI[p] = -1; rI[N + p] = -1; rI[2 * N + p] = -1;
          var ar = 0, ag = 0, ab = 0, br = 0, bg = 0, bb = 0;

          // ---- couverture : l'ombre est opaque devant le décor, puis fondu vers la transparence ----
          fadeA[p] = b <= 1.32 * BC ? 1 : 1 - sstep(1.32 * BC, 2.45 * BC, b);

          // ---- jets polaires (très discrets) : axe de rotation projeté à l'écran ----
          var ay = Math.abs(y) / jetLen - 1.02 * BC;
          if (ay > 0 && b > BC) {
            var jw = BC * 0.05 + ay * 0.085, jx = x / jw;
            var ja = Math.exp(-jx * jx) * Math.exp(-ay / (BC * 2.6)) * sstep(0, BC * 0.8, ay) * jetAmp * 0.15;
            ar += 120 / 255 * ja; ag += 190 / 255 * ja; ab += 255 / 255 * ja;
          }

          if (b < B_TAB) {
            var rowJ, f, tab, isOuter = b > BC;
            if (isOuter) {
              var e = (b - BC) / BC, pj = (Math.log(e) * INV_LN10 - LO) * KO;
              if (pj < 0) pj = 0; else if (pj > NB - 1.001) pj = NB - 1.001;
              rowJ = pj | 0; f = pj - rowJ; tab = outer;
            } else {
              var d = (BC - b) / BC; if (d < 1e-4) d = 1e-4;
              var pi2 = (Math.log(d) * INV_LN10 - LO) * KI;
              if (pi2 < 0) pi2 = 0; else if (pi2 > NB - 1.001) pi2 = NB - 1.001;
              rowJ = pi2 | 0; f = pi2 - rowJ; tab = inner;
            }
            var row0 = rowJ * NP, row1 = row0 + NP;

            // ---- croisements du plan du disque ----
            var zc = spsi * si, RR = Math.sqrt(ci * ci + zc * zc);
            if (RR > 2e-3 && b < B_DISK) {
              var phi0 = Math.atan2(zc, ci) + HALF_PI;
              phi0 -= PI * Math.floor(phi0 * INV_PI);
              if (phi0 < 0.03) phi0 += PI;
              var s0 = Math.sin(phi0), c0 = Math.cos(phi0);
              for (k = 0; k < K; k++) {
                var phik = phi0 + k * PI;
                if (phik >= PHI_MAX - DPHI) break;
                var pm = phik * INV_DPHI, m0 = pm | 0, fm = pm - m0, o0 = row0 + m0, o1 = row1 + m0;
                var u = (tab[o0] + (tab[o0 + 1] - tab[o0]) * fm) * (1 - f) + (tab[o1] + (tab[o1 + 1] - tab[o1]) * fm) * f;
                if (u > U_OUT && u < U_IN) {
                  var sg = (k & 1) ? -1 : 1, sphi = sg * s0, cphi = sg * c0;
                  var xw = cphi * si - sphi * spsi * ci, yw = sphi * cpsi;
                  var theta = Math.atan2(yw, xw) + az;
                  var r = 1 / u, rbf = (r - R_IN) / (R_OUT - R_IN) * NR, rb = rbf | 0;
                  if (rb >= NR) rb = NR - 1;
                  var den = 1 + DOPPLER * omp[rb] * x * si; if (den < 0.32) den = 0.32;
                  var g = grav[rb] / den;
                  q = k * N + p;
                  rI[q] = rbf;
                  var ang = theta * INV_TAU; ang -= Math.floor(ang);
                  aI[q] = ang * NA;
                  var g3 = g * g * g; if (g3 > 3.4) g3 = 3.4;
                  gI[q] = g3;
                  var sg4 = Math.sqrt(g); gT[q] = sg4 * Math.sqrt(sg4) ;
                }
              }
            }

            // ---- fond d'étoiles lentillé (rayons qui s'échappent) ----
            if (isOuter && b < 3.5 * BC) {
              var pe = phiEsc[rowJ] + (phiEsc[rowJ + 1] - phiEsc[rowJ]) * f;
              var cE = Math.cos(pe), sE = Math.sin(pe);
              var dx = cE * si - sE * spsi * ci, dy = sE * cpsi, dz = cE * ci + sE * spsi * si;
              var wx = dx * caz - dy * saz, wy = dx * saz + dy * caz;
              var lon = Math.atan2(wy, wx), lat = Math.asin(dz > 1 ? 1 : (dz < -1 ? -1 : dz));
              var su = (lon * INV_TAU + 0.5) * SW - 0.5, sv = (0.5 - lat * INV_PI) * SH - 0.5;
              var u0 = Math.floor(su), v0 = Math.floor(sv), fu = su - u0, fv = sv - v0;
              var ua = ((u0 % SW) + SW) % SW, ub = (ua + 1) % SW, va = v0 < 0 ? 0 : (v0 >= SH ? SH - 1 : v0), vb = va + 1 >= SH ? SH - 1 : va + 1;
              var i00 = (va * SW + ua) * 3, i01 = (va * SW + ub) * 3, i10 = (vb * SW + ua) * 3, i11 = (vb * SW + ub) * 3, sw = (1 - sstep(1.7 * BC, 3.5 * BC, b)) * 1.15 / 255;
              var w00 = (1 - fu) * (1 - fv), w01 = fu * (1 - fv), w10 = (1 - fu) * fv, w11 = fu * fv;
              br = (stars[i00] * w00 + stars[i01] * w01 + stars[i10] * w10 + stars[i11] * w11) * sw;
              bg = (stars[i00 + 1] * w00 + stars[i01 + 1] * w01 + stars[i10 + 1] * w10 + stars[i11 + 1] * w11) * sw;
              bb = (stars[i00 + 2] * w00 + stars[i01 + 2] * w01 + stars[i10 + 2] * w10 + stars[i11 + 2] * w11) * sw;
            }
          }

          // ---- anneau de photons (images d'ordre élevé, trop fines pour être résolues) + halo gravitationnel ----
          if (b > 0.9 * BC) {
            var dr = (b - BC * 1.006) / (BC * 0.030);
            var ring = Math.exp(-dr * dr) * (b < BC ? 0.0 : 1.0);
            var side = 1 - 0.55 * cpsi * si;               // côté qui s'approche (gauche) plus brillant
            var rg = ring * 0.85 * side;
            ar += rg; ag += rg * 0.90; ab += rg * 0.74;
            var halo = b > BC ? Math.exp(-(b - BC) / (BC * 0.40)) * 0.16 : 0;
            ar += halo * 1.0; ag += halo * 0.56; ab += halo * 0.26;
          }
          addR[p] = ar; addG[p] = ag; addB[p] = ab; bgR[p] = br; bgG[p] = bg; bgB[p] = bb;
        }
      }
      eng.lastCam = { incl: incl, roll: roll, W: W, az: az };
      eng.hasGeometry = true;
      eng.geoMs = nowMs() - t0;
    };

    /** Passe de teinte : fait tourner le disque au temps t (s) et écrit les pixels RGBA (Uint32, little-endian) dans px. */
    eng.shade = function (t, px) {
      var t0 = nowMs();
      var t1 = t % PERIOD, t2 = (t + PERIOD * 0.5) % PERIOD, wA = 1 - Math.abs(2 * t1 / PERIOD - 1), wB = 1 - wA;
      var p, k, q, R, G, B, Tr, ri, rb, ai, a1, a2, i0, i1, f, base, n1, n2, n, e, I, op, idx, ti;
      var GAIN = 1.75, EXPO = 1.30;
      for (p = 0; p < N; p++) {
        R = addR[p]; G = addG[p]; B = addB[p]; Tr = 1;
        for (k = 0; k < K; k++) {
          q = k * N + p; ri = rI[q];
          if (ri < 0) continue;
          rb = ri | 0; base = rb * NA;
          ai = aI[q];
          a1 = ai - omb[rb] * t1; a1 -= NA * Math.floor(a1 / NA); i0 = a1 | 0; f = a1 - i0; i1 = i0 + 1; if (i1 >= NA) i1 = 0;
          n1 = noise[base + i0] + (noise[base + i1] - noise[base + i0]) * f;
          a2 = ai - omb[rb] * t2; a2 -= NA * Math.floor(a2 / NA); i0 = a2 | 0; f = a2 - i0; i1 = i0 + 1; if (i1 >= NA) i1 = 0;
          n2 = noise[base + i0] + (noise[base + i1] - noise[base + i0]) * f;
          n = (n1 * wA + n2 * wB) * 0.0039216;
          e = erad[rb];
          I = e * (0.50 + 1.25 * n * n) * gI[q] * GAIN;
          ti = trad[rb] * gT[q];
          idx = (ti * 170) | 0; if (idx > 255) idx = 255;
          R += Tr * I * lutR[idx]; G += Tr * I * lutG[idx]; B += Tr * I * lutB[idx];
          op = edgeT[rb] * (0.24 + 0.85 * erad0[rb] * (0.35 + n)); if (op > 0.86) op = 0.86;
          Tr *= 1 - op;
        }
        R += Tr * bgR[p]; G += Tr * bgG[p]; B += Tr * bgB[p];
        // courbe de réponse douce (≈ 1 − e^−x) : les zones les plus chaudes tendent vers le blanc
        R *= EXPO; G *= EXPO; B *= EXPO;
        R = 1 - 1 / (1 + R + 0.5 * R * R + 0.1667 * R * R * R);
        G = 1 - 1 / (1 + G + 0.5 * G * G + 0.1667 * G * G * G);
        B = 1 - 1 / (1 + B + 0.5 * B * B + 0.1667 * B * B * B);
        outR[p] = R; outG[p] = G; outB[p] = B;
        var L = R > G ? (R > B ? R : B) : (G > B ? G : B), a = fadeA[p];
        if (L > a) a = L;
        if (a < 0.004) { px[p] = 0; continue; }
        var inv = 255 / a;
        px[p] = ((a * 255 + 0.5) << 24) | (((B * inv + 0.5) | 0) << 16) | (((G * inv + 0.5) | 0) << 8) | ((R * inv + 0.5) | 0);
      }
      eng.shadeMs = nowMs() - t0;
    };


    /**
     * Lueur (bloom) bon marché : les zones très lumineuses de la dernière teinte, réduites au quart, floutées, puis
     * écrites en RGBA opaque (bw × bw). À afficher par-dessus en fusion ADD, agrandie : le lissage fait le flou.
     */
    eng.bloomSize = BW;
    eng.bloom = function (out32) {
      var bi, bj, di, dj, p, c, R, G, B, n, pass, k, x, y, src, dst, tmp;
      for (bj = 0; bj < BW; bj++) {
        for (bi = 0; bi < BW; bi++) {
          R = 0; G = 0; B = 0;
          for (dj = 0; dj < 4; dj++) {
            p = (bj * 4 + dj) * res + bi * 4;
            for (di = 0; di < 4; di++, p++) {
              c = outR[p] - 0.40; if (c > 0) R += c;
              c = outG[p] - 0.40; if (c > 0) G += c;
              c = outB[p] - 0.40; if (c > 0) B += c;
            }
          }
          k = (bj * BW + bi) * 3; blA[k] = R * 0.0625; blA[k + 1] = G * 0.0625; blA[k + 2] = B * 0.0625;
        }
      }
      src = blA; dst = blB;
      for (pass = 0; pass < 2; pass++) {                       // 2 flous de boîte 3×3
        for (y = 0; y < BW; y++) {
          for (x = 0; x < BW; x++) {
            R = 0; G = 0; B = 0; n = 0;
            for (dj = -1; dj <= 1; dj++) {
              if (y + dj < 0 || y + dj >= BW) continue;
              for (di = -1; di <= 1; di++) {
                if (x + di < 0 || x + di >= BW) continue;
                k = ((y + dj) * BW + x + di) * 3; R += src[k]; G += src[k + 1]; B += src[k + 2]; n++;
              }
            }
            k = (y * BW + x) * 3; dst[k] = R / n; dst[k + 1] = G / n; dst[k + 2] = B / n;
          }
        }
        tmp = src; src = dst; dst = tmp;
      }
      for (p = 0; p < BW * BW; p++) {
        k = p * 3;
        R = src[k] * 2.4; G = src[k + 1] * 2.4; B = src[k + 2] * 2.4;
        if (R > 1) R = 1; if (G > 1) G = 1; if (B > 1) B = 1;
        out32[p] = 0xff000000 | (((B * 255) | 0) << 16) | (((G * 255) | 0) << 8) | ((R * 255) | 0);
      }
    };

    /** Raccourci : géométrie (si la caméra a changé) + teinte. Renvoie true si la géométrie a été recalculée. */
    eng.frame = function (cam, t, px) {
      var lc = eng.lastCam, dirty = !eng.hasGeometry || !lc || Math.abs(lc.incl - cam.incl) > 1e-4 || Math.abs(lc.roll - (cam.roll || 0)) > 1e-4 ||
        Math.abs(lc.W - cam.W) > 1e-3 || Math.abs(lc.az - (cam.az || 0)) > 2e-3;
      if (dirty) eng.geometry(cam);
      eng.shade(t, px);
      return dirty;
    };
    return eng;
  }

  // =====================================================================================================
  //  Enveloppe Phaser : texture canvas mise à jour à la volée
  // =====================================================================================================
  var texCache = {};

  function ensureCanvas(scene, key, size) {
    var tex = texCache[key];
    if (tex && scene.textures.exists(key)) return tex;
    tex = scene.textures.exists(key) && scene.textures.get ? scene.textures.get(key) : null;
    if (!tex || !tex.context) tex = scene.textures.createCanvas(key, size, size);
    if (!tex || !tex.context) throw new Error('canvas indisponible');
    texCache[key] = tex;
    return tex;
  }

  /**
   * handle = create(scene, { res: 192, key: 'tex_bh_live' })
   *   → { key, bloomKey, res, avgMs, geoMs, frame(cam, t), setRes(n) }.
   * Chaque résolution garde son moteur et ses textures (passer de 160 à 224 est instantané et sans allocation).
   * Renvoie null si le canvas n'est pas utilisable (la scène retombe alors sur l'image statique).
   */
  function create(scene, opts) {
    opts = opts || {};
    var baseKey = opts.key || 'tex_bh_live', handle = { res: 0, key: '', bloomKey: '', avgMs: 0, geoMs: 0, frames: 0 }, cache = {}, cur = null;
    function slot(res) {
      if (cache[res]) return cache[res];
      var key = baseKey + '_' + res, eng = makeEngine(res), bw = eng.bloomSize;
      var tex = ensureCanvas(scene, key, res), btex = ensureCanvas(scene, key + '_bloom', bw);
      var img = tex.context.createImageData(res, res), bimg = btex.context.createImageData(bw, bw);
      cache[res] = { res: res, key: key, bloomKey: key + '_bloom', eng: eng, tex: tex, btex: btex, img: img, bimg: bimg,
        px: new Uint32Array(img.data.buffer), bpx: new Uint32Array(bimg.data.buffer) };
      return cache[res];
    }
    function use(res) { cur = slot(res); handle.res = res; handle.key = cur.key; handle.bloomKey = cur.bloomKey; handle.avgMs = 0; }
    try { use(opts.res || 192); } catch (e) { return null; }
    handle.frame = function (cam, t) {
      var t0 = nowMs(), s = cur, dirty = s.eng.frame(cam, t, s.px);
      s.tex.context.putImageData(s.img, 0, 0); s.tex.refresh();
      s.eng.bloom(s.bpx);
      s.btex.context.putImageData(s.bimg, 0, 0); s.btex.refresh();
      var ms = nowMs() - t0;
      handle.avgMs = handle.avgMs ? handle.avgMs * 0.85 + ms * 0.15 : ms;
      if (dirty) handle.geoMs = s.eng.geoMs;
      handle.frames++;
      return dirty;
    };
    handle.setRes = function (res) { if (res !== handle.res) { try { use(res); } catch (e) { /* on garde la résolution actuelle */ } } return handle.res; };
    return handle;
  }

  /** Une seule image figée → texture canvas (icône de la carte Univers). */
  function renderStill(scene, key, res, cam, t) {
    if (scene.textures.exists(key)) return key;
    var eng = makeEngine(res), tex = scene.textures.createCanvas(key, res, res);
    if (!tex || !tex.context) return null;
    var img = tex.context.createImageData(res, res), px = new Uint32Array(img.data.buffer);
    eng.frame(cam, t || 0, px);
    tex.context.putImageData(img, 0, 0);
    tex.refresh();
    return key;
  }

  return {
    create: create, renderStill: renderStill, makeEngine: makeEngine,
    buildTables: buildTables, buildStars: buildStars, buildDisk: buildDisk,
    CONST: { BC: BC, R_IN: R_IN, R_OUT: R_OUT, K: K, NB: NB, NP: NP, DPHI: DPHI, PHI_MAX: PHI_MAX, NR: NR, NA: NA, B_TAB: B_TAB, PERIOD: PERIOD }
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.BlackHoleRender; }
