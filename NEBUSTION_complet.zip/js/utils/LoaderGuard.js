/**
 * NEBUSTION - LoaderGuard
 * Garde-fou du chargement des illustrations (héros, boss). Remplace l'ancien délai FIXE de 4 s, trop court dès que
 * la connexion est lente ou que les images sont nombreuses (8,4 Mo d'images) : passé ce délai, le jeu abandonnait
 * les vraies illustrations et affichait les portraits/boss générés (« les images ne s'affichent pas »).
 * Ici on ne déclare le chargement bloqué que si AUCUN octet n'arrive pendant `stallMs` (15 s par défaut), avec un
 * plafond absolu `maxMs` (120 s) : un chargement lent mais actif n'est jamais interrompu.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.LoaderGuard = {
  STALL_MS: 15000,
  MAX_MS: 120000,

  /** @returns {{stop:Function}} ; `onStall` est appelée au plus une fois si le chargement est bloqué. */
  watch: function (scene, onStall, opts) {
    opts = opts || {};
    var stallMs = opts.stallMs || this.STALL_MS, maxMs = opts.maxMs || this.MAX_MS;
    var start = Date.now(), last = start, done = false, ev = null;
    function touch() { last = Date.now(); }
    var events = ['fileprogress', 'filecomplete', 'progress'];
    events.forEach(function (n) { scene.load.on(n, touch); });
    function stop() {
      if (done) return;
      done = true;
      events.forEach(function (n) { try { scene.load.off(n, touch); } catch (e) { /* ignore */ } });
      try { if (ev && ev.remove) ev.remove(false); } catch (e2) { /* ignore */ }
    }
    function check() {
      if (done) return;
      var now = Date.now();
      if (now - last > stallMs || now - start > maxMs) { stop(); onStall(); }
    }
    if (scene.time && typeof scene.time.addEvent === 'function') {
      ev = scene.time.addEvent({ delay: 1000, loop: true, callback: check });
    } else if (typeof setInterval === 'function') {   // scène minimale (tests) : minuterie navigateur
      var iv = setInterval(check, 1000);
      ev = { remove: function () { clearInterval(iv); } };
    }
    return { stop: stop };
  }
};
