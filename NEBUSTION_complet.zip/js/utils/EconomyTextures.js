/**
 * NEBUSTION - EconomyTextures
 * Textures procédurales (Canvas 2D) de l'économie : icônes de ressources, gisements,
 * portiques d'extraction, engrenage, drone, rotor, caisse de ravitaillement, ombres, anneaux.
 * Aucun fichier image externe.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.EconomyTextures = {
  generateAll: function (scene) {
    var E = NEBUSTION.Economy, TG = NEBUSTION.TextureGenerator, self = this;
    E.ORDER.forEach(function (id) {
      TG.generateGlowParticle(scene, 'tex_glow_' + id, E.RES[id].hex);
      self._make(scene, 'tex_icon_' + id, 72, 72, function (ctx) { self['icon_' + id](ctx); });
      self._make(scene, 'tex_node_' + id, 180, 180, function (ctx) { self._pad(ctx, E.RES[id].hex); self['node_' + id](ctx); });
    });
    this._make(scene, 'tex_gantry', 180, 180, function (ctx) { self.gantry(ctx); });
    this._make(scene, 'tex_gear', 120, 120, function (ctx) { self.gear(ctx); });
    this._make(scene, 'tex_drone', 110, 76, function (ctx) { self.drone(ctx); });
    this._make(scene, 'tex_rotor', 44, 10, function (ctx) { self.rotor(ctx); });
    this._make(scene, 'tex_pod', 96, 120, function (ctx) { self.pod(ctx); });
    this._make(scene, 'tex_shadow', 80, 28, function (ctx) { self.shadow(ctx); });
    this._make(scene, 'tex_ring_soft', 128, 128, function (ctx) { self.ring(ctx); });
  },

  _make: function (scene, key, w, h, fn) {
    if (scene.textures.exists(key)) return;
    var tex = scene.textures.createCanvas(key, w, h);
    fn(tex.context);
    tex.refresh();
  },

  // ---------- Helpers ----------
  _poly: function (ctx, pts) {
    ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]);
    for (var i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
    ctx.closePath();
  },
  _lin: function (ctx, x0, y0, x1, y1, stops) {
    var g = ctx.createLinearGradient(x0, y0, x1, y1);
    stops.forEach(function (s) { g.addColorStop(s[0], s[1]); });
    return g;
  },
  _rad: function (ctx, x, y, r0, r1, stops) {
    var g = ctx.createRadialGradient(x, y, r0, x, y, r1);
    stops.forEach(function (s) { g.addColorStop(s[0], s[1]); });
    return g;
  },
  _star4: function (ctx, x, y, r) {
    ctx.beginPath();
    ctx.moveTo(x, y - r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.quadraticCurveTo(x, y, x, y + r);
    ctx.quadraticCurveTo(x, y, x - r, y);
    ctx.quadraticCurveTo(x, y, x, y - r);
    ctx.closePath();
  },
  _pad: function (ctx, hex) {
    ctx.save();
    ctx.fillStyle = this._lin(ctx, 0, 112, 0, 164, [[0, '#16213f'], [1, '#080d1c']]);
    ctx.beginPath(); ctx.ellipse(90, 138, 74, 27, 0, 0, Math.PI * 2); ctx.fill();
    ctx.shadowColor = hex; ctx.shadowBlur = 10;
    ctx.strokeStyle = hex; ctx.globalAlpha = 0.8; ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.ellipse(90, 138, 74, 27, 0, 0, Math.PI * 2); ctx.stroke();
    ctx.globalAlpha = 0.35; ctx.lineWidth = 1.5; ctx.shadowBlur = 0;
    ctx.beginPath(); ctx.ellipse(90, 138, 52, 18, 0, 0, Math.PI * 2); ctx.stroke();
    ctx.restore();
  },

  // ---------- Icônes 72×72 ----------
  icon_crystal: function (ctx) {
    ctx.save(); ctx.shadowColor = '#4fe3ff'; ctx.shadowBlur = 10;
    ctx.fillStyle = this._lin(ctx, 0, 4, 0, 68, [[0, '#e9fcff'], [0.5, '#4fe3ff'], [1, '#1a6fb0']]);
    this._poly(ctx, [[36, 5], [57, 22], [57, 50], [36, 67], [15, 50], [15, 22]]); ctx.fill(); ctx.restore();
    ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(15, 22); ctx.lineTo(36, 34); ctx.lineTo(57, 22); ctx.moveTo(36, 34); ctx.lineTo(36, 67); ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.35)'; this._poly(ctx, [[36, 5], [57, 22], [36, 34], [15, 22]]); ctx.fill();
  },
  icon_metal: function (ctx) {
    ctx.save(); ctx.shadowColor = '#c9d4ea'; ctx.shadowBlur = 8;
    ctx.fillStyle = '#7f8db0'; this._poly(ctx, [[10, 30], [36, 42], [36, 63], [10, 51]]); ctx.fill();
    ctx.fillStyle = '#aebbd8'; this._poly(ctx, [[62, 30], [36, 42], [36, 63], [62, 51]]); ctx.fill();
    ctx.fillStyle = '#eef3ff'; this._poly(ctx, [[10, 30], [36, 18], [62, 30], [36, 42]]); ctx.fill(); ctx.restore();
    ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(18, 30); ctx.lineTo(36, 23); ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.fillRect(40, 46, 16, 3);
  },
  icon_energy: function (ctx) {
    ctx.save(); ctx.shadowColor = '#b47bff'; ctx.shadowBlur = 12;
    ctx.fillStyle = this._rad(ctx, 30, 28, 2, 30, [[0, '#f0e0ff'], [0.5, '#b47bff'], [1, '#4a1fa0']]);
    ctx.beginPath(); ctx.arc(36, 36, 27, 0, Math.PI * 2); ctx.fill(); ctx.restore();
    ctx.save(); ctx.shadowColor = '#ffe066'; ctx.shadowBlur = 8; ctx.fillStyle = '#fff7c2';
    this._poly(ctx, [[41, 10], [24, 38], [35, 38], [30, 62], [50, 30], [38, 30]]); ctx.fill(); ctx.restore();
  },
  icon_core: function (ctx) {
    ctx.save(); ctx.shadowColor = '#ffd166'; ctx.shadowBlur = 12;
    ctx.fillStyle = this._rad(ctx, 30, 28, 2, 30, [[0, '#fff2c0'], [0.55, '#ffd166'], [1, '#8a5a12']]);
    ctx.beginPath(); ctx.arc(36, 36, 25, 0, Math.PI * 2); ctx.fill(); ctx.restore();
    ctx.strokeStyle = '#ffe9a8'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.ellipse(36, 36, 32, 10, -0.5, 0, Math.PI * 2); ctx.stroke();
    ctx.fillStyle = '#5a3a08'; this._poly(ctx, [[36, 25], [45, 43], [27, 43]]); ctx.fill();
    ctx.fillStyle = '#fff2c0'; ctx.beginPath(); ctx.arc(36, 37, 3, 0, Math.PI * 2); ctx.fill();
  },
  icon_dust: function (ctx) {
    ctx.save(); ctx.shadowColor = '#ff6ec7'; ctx.shadowBlur = 10; ctx.fillStyle = '#ff8fd6';
    this._star4(ctx, 36, 34, 24); ctx.fill();
    ctx.fillStyle = '#ffb3e6'; this._star4(ctx, 17, 56, 11); ctx.fill();
    this._star4(ctx, 57, 54, 12); ctx.fill();
    ctx.fillStyle = '#ffd1f0'; this._star4(ctx, 56, 14, 8); ctx.fill();
    this._star4(ctx, 15, 16, 7); ctx.fill(); ctx.restore();
  },

  // ---------- Gisements (180×180, pad au centre y=138) ----------
  node_crystal: function (ctx) {
    var spikes = [
      [[52, 62], [70, 90], [66, 134], [40, 134], [36, 92]],
      [[130, 54], [148, 92], [146, 134], [118, 134], [112, 86]],
      [[90, 18], [112, 70], [104, 136], [76, 136], [68, 70]]
    ];
    var self = this;
    spikes.forEach(function (p) {
      ctx.save(); ctx.shadowColor = '#4fe3ff'; ctx.shadowBlur = 14;
      ctx.fillStyle = self._lin(ctx, 0, p[0][1], 0, 136, [[0, '#f2feff'], [0.45, '#4fe3ff'], [1, '#155a99']]);
      self._poly(ctx, p); ctx.fill(); ctx.restore();
      ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.lineWidth = 1.3;
      ctx.beginPath(); ctx.moveTo(p[0][0], p[0][1]); ctx.lineTo((p[1][0] + p[4][0]) / 2, p[1][1] + 6);
      ctx.lineTo(p[1][0], p[1][1]); ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,0.28)';
      self._poly(ctx, [p[0], p[1], [(p[1][0] + p[4][0]) / 2, p[1][1] + 6], p[4]]); ctx.fill();
    });
  },
  node_metal: function (ctx) {
    var self = this;
    var rocks = [
      [[60, 134], [50, 100], [74, 76], [106, 84], [120, 112], [110, 134]],
      [[102, 134], [104, 98], [128, 86], [152, 102], [150, 134]],
      [[38, 134], [38, 112], [58, 102], [70, 120], [64, 134]]
    ];
    rocks.forEach(function (p) {
      ctx.fillStyle = self._lin(ctx, 0, p[1][1], 0, 134, [[0, '#6b7ba0'], [1, '#232b45']]);
      self._poly(ctx, p); ctx.fill();
      ctx.strokeStyle = '#dfe8ff'; ctx.globalAlpha = 0.75; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(p[1][0] + 4, p[1][1] + 12); ctx.lineTo(p[2][0] - 4, p[2][1] + 10); ctx.stroke();
      ctx.globalAlpha = 0.35; ctx.beginPath(); ctx.moveTo(p[3][0] - 8, p[3][1] + 4); ctx.lineTo(p[4][0] - 10, p[4][1] - 12); ctx.stroke();
      ctx.globalAlpha = 1;
    });
    ctx.fillStyle = 'rgba(223,232,255,0.9)';
    [[86, 92, 3], [124, 100, 2.5], [54, 112, 2]].forEach(function (s) { ctx.beginPath(); ctx.arc(s[0], s[1], s[2], 0, 7); ctx.fill(); });
  },
  node_energy: function (ctx) {
    ctx.strokeStyle = '#2a1f5c'; ctx.lineWidth = 8;
    ctx.beginPath(); ctx.ellipse(90, 126, 40, 14, 0, 0, Math.PI * 2); ctx.stroke();
    ctx.save(); ctx.shadowColor = '#b47bff'; ctx.shadowBlur = 24;
    ctx.fillStyle = this._rad(ctx, 82, 74, 2, 32, [[0, '#f5eaff'], [0.5, '#b47bff'], [1, '#3a1590']]);
    ctx.beginPath(); ctx.arc(90, 82, 30, 0, Math.PI * 2); ctx.fill(); ctx.restore();
    ctx.strokeStyle = '#e6ccff'; ctx.lineWidth = 2;
    [[-1, -0.6], [1, -0.3], [0.2, 1]].forEach(function (d, i) {
      var x = 90, y = 82;
      ctx.beginPath(); ctx.moveTo(x, y);
      for (var k = 1; k <= 4; k++) { x += d[0] * 9 + (k % 2 ? 4 : -4) * (i + 1) * 0.4; y += d[1] * 9 + (k % 2 ? -3 : 3); ctx.lineTo(x, y); }
      ctx.stroke();
    });
  },
  node_core: function (ctx) {
    ctx.save(); ctx.shadowColor = '#ffd166'; ctx.shadowBlur = 12;
    ctx.fillStyle = this._lin(ctx, 0, 34, 0, 136, [[0, '#8a6a34'], [1, '#2b1d0c']]);
    this._poly(ctx, [[62, 136], [68, 54], [90, 30], [112, 54], [118, 136]]); ctx.fill(); ctx.restore();
    ctx.strokeStyle = '#ffd166'; ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.arc(90, 78, 12, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(90, 90); ctx.lineTo(90, 120); ctx.moveTo(76, 104); ctx.lineTo(104, 104);
    ctx.moveTo(78, 60); ctx.lineTo(102, 60); ctx.stroke();
    ctx.fillStyle = '#fff2c0'; ctx.beginPath(); ctx.arc(90, 78, 4, 0, Math.PI * 2); ctx.fill();
  },
  node_dust: function (ctx) {
    ctx.fillStyle = this._rad(ctx, 90, 96, 4, 56, [[0, 'rgba(255,110,199,0.35)'], [1, 'rgba(255,110,199,0)']]);
    ctx.beginPath(); ctx.arc(90, 96, 56, 0, Math.PI * 2); ctx.fill();
    var seed = 7; function rnd() { seed = (seed * 16807) % 2147483647; return seed / 2147483647; }
    for (var i = 0; i < 90; i++) {
      var a = i * 0.55, r = 4 + i * 0.55 + rnd() * 6;
      var x = 90 + Math.cos(a) * r, y = 100 + Math.sin(a) * r * 0.75;
      ctx.fillStyle = 'rgba(255,' + (150 + Math.floor(rnd() * 80)) + ',220,' + (0.35 + rnd() * 0.6).toFixed(2) + ')';
      ctx.beginPath(); ctx.arc(x, y, 1 + rnd() * 2.4, 0, Math.PI * 2); ctx.fill();
    }
    ctx.fillStyle = '#ffd1f0'; this._star4(ctx, 90, 92, 12); ctx.fill();
    this._star4(ctx, 58, 76, 6); ctx.fill(); this._star4(ctx, 124, 112, 7); ctx.fill();
  },

  // ---------- Machines ----------
  gantry: function (ctx) {
    var self = this;
    [22, 158].forEach(function (x) {
      ctx.fillStyle = self._lin(ctx, x - 6, 0, x + 6, 0, [[0, '#2a3a63'], [1, '#141d38']]);
      ctx.fillRect(x - 6, 46, 12, 92);
      ctx.strokeStyle = '#3f9fff'; ctx.lineWidth = 1.5; ctx.strokeRect(x - 6, 46, 12, 92);
      ctx.fillStyle = '#00e5ff'; ctx.fillRect(x - 2, 60, 4, 6); ctx.fillRect(x - 2, 84, 4, 6);
    });
    ctx.fillStyle = this._lin(ctx, 0, 38, 0, 54, [[0, '#32456f'], [1, '#141d38']]);
    ctx.beginPath(); ctx.moveTo(14, 54); ctx.lineTo(14, 42); ctx.lineTo(24, 36); ctx.lineTo(156, 36); ctx.lineTo(166, 42); ctx.lineTo(166, 54); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = '#3f9fff'; ctx.lineWidth = 1.5; ctx.stroke();
    ctx.fillStyle = 'rgba(0,229,255,0.7)'; ctx.fillRect(34, 44, 112, 3);
    ctx.fillStyle = '#0a1224'; ctx.beginPath(); ctx.arc(90, 46, 14, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#8fa0c4'; ctx.lineWidth = 3; ctx.stroke();
  },
  gear: function (ctx) {
    var cx = 60, cy = 60;
    ctx.fillStyle = '#e4ecff';
    for (var i = 0; i < 12; i++) {
      ctx.save(); ctx.translate(cx, cy); ctx.rotate(i * Math.PI / 6);
      ctx.fillRect(-6, -54, 12, 16); ctx.restore();
    }
    ctx.beginPath(); ctx.arc(cx, cy, 44, 0, Math.PI * 2); ctx.fill();
    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath(); ctx.arc(cx, cy, 30, 0, Math.PI * 2); ctx.fill();
    ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = '#e4ecff';
    for (var j = 0; j < 4; j++) { ctx.save(); ctx.translate(cx, cy); ctx.rotate(j * Math.PI / 2); ctx.fillRect(-4, -32, 8, 32); ctx.restore(); }
    ctx.beginPath(); ctx.arc(cx, cy, 9, 0, Math.PI * 2); ctx.fill();
  },
  drone: function (ctx) {
    ctx.strokeStyle = '#8fa0c4'; ctx.lineWidth = 4; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(34, 40); ctx.lineTo(14, 30); ctx.moveTo(76, 40); ctx.lineTo(96, 30); ctx.stroke();
    ctx.fillStyle = '#5d6c92'; ctx.beginPath(); ctx.arc(14, 28, 4.5, 0, 7); ctx.arc(96, 28, 4.5, 0, 7); ctx.fill();
    ctx.strokeStyle = '#6a7aa0'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(40, 54); ctx.lineTo(70, 54); ctx.stroke();
    ctx.fillStyle = '#28324f'; this._poly(ctx, [[47, 52], [63, 52], [59, 65], [51, 65]]); ctx.fill();
    ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(55, 66, 2.5, 0, 7); ctx.fill();
    ctx.fillStyle = this._lin(ctx, 0, 28, 0, 56, [[0, '#dfe8ff'], [0.5, '#6a7aa0'], [1, '#28324f']]);
    ctx.beginPath(); ctx.ellipse(55, 42, 27, 14, 0, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 1.5; ctx.stroke();
    ctx.fillStyle = this._lin(ctx, 0, 27, 0, 45, [[0, '#d6f8ff'], [1, '#2a8fb8']]);
    ctx.beginPath(); ctx.ellipse(55, 36, 14, 9, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.beginPath(); ctx.ellipse(50, 33, 5, 2.5, -0.4, 0, Math.PI * 2); ctx.fill();
  },
  rotor: function (ctx) {
    ctx.fillStyle = this._lin(ctx, 0, 0, 44, 0, [[0, 'rgba(255,255,255,0)'], [0.5, 'rgba(230,240,255,0.85)'], [1, 'rgba(255,255,255,0)']]);
    ctx.beginPath(); ctx.ellipse(22, 5, 22, 4, 0, 0, Math.PI * 2); ctx.fill();
  },
  pod: function (ctx) {
    ctx.save(); ctx.shadowColor = '#ffd166'; ctx.shadowBlur = 16;
    ctx.fillStyle = this._lin(ctx, 20, 0, 76, 0, [[0, '#fff2c0'], [0.5, '#ffd166'], [1, '#b8791a']]);
    ctx.beginPath(); ctx.ellipse(48, 62, 30, 44, 0, 0, Math.PI * 2); ctx.fill(); ctx.restore();
    ctx.strokeStyle = '#5a3a08'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.ellipse(48, 62, 30, 44, 0, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(19, 62); ctx.lineTo(77, 62); ctx.stroke();
    ctx.fillStyle = this._rad(ctx, 46, 42, 1, 14, [[0, '#ffffff'], [1, '#2a8fb8']]);
    ctx.beginPath(); ctx.arc(48, 42, 13, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#5a3a08'; this._poly(ctx, [[30, 100], [18, 116], [36, 108]]); ctx.fill();
    this._poly(ctx, [[66, 100], [78, 116], [60, 108]]); ctx.fill();
    ctx.fillStyle = '#5a3a08'; ctx.font = 'bold 22px Arial'; ctx.textAlign = 'center'; ctx.fillText('★', 48, 88);
  },
  shadow: function (ctx) {
    ctx.save(); ctx.translate(40, 14); ctx.scale(1, 0.35);
    ctx.fillStyle = this._rad(ctx, 0, 0, 0, 40, [[0, 'rgba(0,0,0,0.8)'], [1, 'rgba(0,0,0,0)']]);
    ctx.beginPath(); ctx.arc(0, 0, 40, 0, Math.PI * 2); ctx.fill(); ctx.restore();
  },
  ring: function (ctx) {
    ctx.save(); ctx.shadowColor = '#ffffff'; ctx.shadowBlur = 8; ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 5;
    ctx.beginPath(); ctx.arc(64, 64, 52, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
  }
};
