/**
 * NEBUSTION - EnemyTextures
 * Silhouettes procédurales (Canvas 2D, aucun fichier image) des 10 ennemis et 3 boss du combat
 * + textures d'effets propres à l'arène (projectile, éclat d'impact, arc de coup, sol en
 * perspective, astéroïdes). Chaque ennemi a une silhouette réellement différente, pilotée par
 * le champ visual.shape de js/data/Enemies.js. Clé de texture : 'tex_enemy_' + id.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.EnemyTextures = {
  SIZE: 200,        // ennemi normal : 200x200
  BOSS_SIZE: 340,   // boss : 340x340 (même dessin, agrandi)

  generateAll: function (scene) {
    var self = this, EN = NEBUSTION.Enemies, TG = NEBUSTION.TextureGenerator;

    // Halos de particules supplémentaires (les 4 de base + ressources existent déjà)
    TG.generateGlowParticle(scene, 'tex_glow_red', '#ff4d5e');
    TG.generateGlowParticle(scene, 'tex_glow_green', '#5fd97a');
    TG.generateGlowParticle(scene, 'tex_glow_orange', '#ff8a3d');
    TG.generateGlowParticle(scene, 'tex_glow_ice', '#8fd8ff');

    EN.allEnemies().concat(EN.allBosses()).forEach(function (def) {
      var boss = !!def.isBoss;
      var size = boss ? self.BOSS_SIZE : self.SIZE;
      self._make(scene, 'tex_enemy_' + def.id, size, size, function (ctx) {
        var k = size / self.SIZE;
        ctx.scale(k, k);
        self._drawEnemy(ctx, def.visual.shape, def.visual.color, def.visual.accent);
      });
    });

    // Unités des 5 empires de la Galaxie (module Invasions/5C) : mêmes silhouettes procédurales,
    // même format de définition (id/visual.shape/color/accent) que les ennemis du module Combat.
    var GX = NEBUSTION.Galaxy;
    if (GX) {
      GX.EMPIRE_ORDER.forEach(function (eid) {
        GX.EMPIRES[eid].units.forEach(function (def) {
          self._make(scene, 'tex_enemy_' + def.id, self.SIZE, self.SIZE, function (ctx) {
            self._drawEnemy(ctx, def.visual.shape, def.visual.color, def.visual.accent);
          });
        });
      });
    }

    this._make(scene, 'tex_proj', 64, 26, function (ctx) { self._projectile(ctx); });
    this._make(scene, 'tex_spark', 96, 96, function (ctx) { self._spark(ctx); });
    this._make(scene, 'tex_slash', 128, 128, function (ctx) { self._slash(ctx); });
    this._make(scene, 'tex_arena_floor', 720, 420, function (ctx) { self._floor(ctx, 720, 420); });
    this._make(scene, 'tex_asteroid_a', 120, 120, function (ctx) { self._asteroid(ctx, 1); });
    this._make(scene, 'tex_asteroid_b', 120, 120, function (ctx) { self._asteroid(ctx, 2); });
    this._make(scene, 'tex_shield_bubble', 160, 160, function (ctx) { self._bubble(ctx); });
  },

  // ---------- Illustrations optionnelles ----------
  // Comme pour les héros : si assets/enemies/<id>.png existe, l'image remplace la silhouette
  // procédurale ; sinon la silhouette reste, sans erreur. L'image est dessinée DANS la texture
  // existante (carrée : 200x200 ennemi, 340x340 boss) : le reste du jeu ne voit aucune différence.
  // Mise en forme automatique : image réduite à la résolution de la texture, centrée, proportions
  // conservées (une image non carrée n'est jamais déformée).
  IMAGE_DIR: 'assets/enemies/',

  imageFile: function (id) {
    var e = NEBUSTION.Enemies.get(id);
    if (e && e.portrait) return e.portrait; // image envoyée par l'Atelier créateur (tools/studio.html)
    return this.IMAGE_DIR + id + '.png';
  },

  imageIds: function () {
    var EN = NEBUSTION.Enemies;
    return EN.allEnemies().concat(EN.allBosses()).map(function (d) { return d.id; });
  },

  /**
   * Tente de charger assets/enemies/<id>.png pour chaque ennemi et boss.
   * @param {Phaser.Scene} scene
   * @param {Function} onDone appelé une fois (toujours), que des images aient été trouvées ou non
   */
  loadImages: function (scene, onDone) {
    var self = this, ids = this.imageIds(), missing = {}, finished = false, queued = 0, guard = null;

    function applyOne(id) {
      var imgKey = 'img_enemy_' + id;
      if (missing[imgKey] || !scene.textures.exists(imgKey)) return;
      try { self._applyImage(scene, id, imgKey); } catch (e) { console.error('NEBUSTION enemy image error (' + id + '):', e); }
      try { scene.textures.remove(imgKey); } catch (e2) { /* sans importance */ }
    }
    // Image arrivée APRÈS l'abandon du chargement (connexion très lente) : on l'applique quand même.
    function onLate(key) {
      if (!finished || typeof key !== 'string' || key.indexOf('img_enemy_') !== 0) return;
      applyOne(key.slice('img_enemy_'.length));
    }

    function finish() {
      if (finished) return;
      finished = true;
      if (guard) guard.stop();
      scene.load.on('filecomplete', onLate);
      ids.forEach(function (id) {
        applyOne(id);
      });
      if (onDone) onDone();
    }
    function onLoadError(file) { if (file && file.key) missing[file.key] = true; }

    ids.forEach(function (id) {
      var imgKey = 'img_enemy_' + id;
      if (!scene.textures.exists(imgKey)) { scene.load.image(imgKey, self.imageFile(id)); queued++; }
    });
    if (queued === 0) { finish(); return; }

    scene.load.on('loaderror', onLoadError);
    scene.load.once('complete', function () { scene.load.off('loaderror', onLoadError); finish(); if (scene.load.off) scene.load.off('filecomplete', onLate); });
    guard = NEBUSTION.LoaderGuard.watch(scene, finish);   // sécurité : bloqué = aucun octet reçu pendant 15 s (jamais un simple chargement lent)
    scene.load.start();
  },

  _applyImage: function (scene, id, imgKey) {
    var target = scene.textures.get ? scene.textures.get('tex_enemy_' + id) : null;
    if (!target || !target.context || !target.getSourceImage) return;
    var src = scene.textures.get(imgKey).getSourceImage();
    var size = target.width || this.SIZE, ctx = target.context;
    var sw = src.naturalWidth || src.width, sh = src.naturalHeight || src.height;
    if (!sw || !sh) return;
    var k = Math.min(size / sw, size / sh), dw = Math.round(sw * k), dh = Math.round(sh * k);
    // Le contexte d'un boss a gardé le ctx.scale() du dessin procédural (x1,7) : on repart d'une matrice neutre,
    // sinon l'image serait agrandie et coupée à droite/en bas.
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, size, size);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(src, Math.round((size - dw) / 2), Math.round((size - dh) / 2), dw, dh);
    ctx.restore();
    target.refresh();
  },

  _make: function (scene, key, w, h, fn) {
    if (scene.textures.exists(key)) return;
    var tex = scene.textures.createCanvas(key, w, h);
    fn(tex.context);
    tex.refresh();
  },

  // ---------- Helpers ----------
  _rgba: function (hex, a) {
    hex = hex.replace('#', '');
    var r = parseInt(hex.substring(0, 2), 16), g = parseInt(hex.substring(2, 4), 16), b = parseInt(hex.substring(4, 6), 16);
    return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
  },
  _lin: function (ctx, x0, y0, x1, y1, stops) {
    var g = ctx.createLinearGradient(x0, y0, x1, y1);
    stops.forEach(function (s) { g.addColorStop(s[0], s[1]); });
    return g;
  },
  _rad: function (ctx, x, y, r0, r1, stops) {
    var g = ctx.createRadialGradient(x, y, r0, x, y, r1);
    stops.forEach(function (s) { g.addColorStop(s[0], s[1]); });
    return g;
  },
  _poly: function (ctx, pts) {
    ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]);
    for (var i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
    ctx.closePath();
  },
  /** Halo lumineux derrière une silhouette. */
  _aura: function (ctx, x, y, r, color, a) {
    ctx.fillStyle = this._rad(ctx, x, y, r * 0.15, r, [[0, this._rgba(color, a)], [1, this._rgba(color, 0)]]);
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
  },
  /** Remplissage métallique (haut clair → bas sombre) + contour lumineux. */
  _metal: function (ctx, color, accent, y0, y1) {
    ctx.fillStyle = this._lin(ctx, 0, y0, 0, y1, [[0, color], [0.55, this._rgba(color, 0.78)], [1, accent]]);
  },
  _outline: function (ctx, color, w) {
    ctx.save(); ctx.shadowColor = color; ctx.shadowBlur = 10;
    ctx.strokeStyle = color; ctx.lineWidth = w || 2.5; ctx.stroke(); ctx.restore();
  },
  _eye: function (ctx, x, y, r, color) {
    ctx.save(); ctx.shadowColor = color; ctx.shadowBlur = 14;
    ctx.fillStyle = this._rad(ctx, x, y, 0, r, [[0, '#ffffff'], [0.45, color], [1, this._rgba(color, 0.2)]]);
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill(); ctx.restore();
  },

  // ---------- Dispatcher ----------
  _drawEnemy: function (ctx, shape, color, accent) {
    var fn = this['shape_' + shape];
    if (!fn) fn = this.shape_drone;
    ctx.save();
    // ombre portée
    ctx.fillStyle = 'rgba(0,0,0,0.30)';
    ctx.beginPath(); ctx.ellipse(100, 182, 52, 9, 0, 0, Math.PI * 2); ctx.fill();
    fn.call(this, ctx, color, accent);
    ctx.restore();
  },

  // ---------- 10 ennemis ----------
  shape_drone: function (ctx, c, a) {
    this._aura(ctx, 100, 96, 80, c, 0.3);
    // rotors
    [[38, 78], [162, 78]].forEach(function (p) { ctx.fillStyle = a; ctx.fillRect(p[0] - 16, p[1] - 3, 32, 6); });
    ctx.strokeStyle = c; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(64, 96); ctx.lineTo(40, 80); ctx.moveTo(136, 96); ctx.lineTo(160, 80); ctx.stroke();
    // coque
    this._metal(ctx, c, a, 50, 150);
    ctx.beginPath(); ctx.ellipse(100, 100, 46, 40, 0, 0, Math.PI * 2); ctx.fill(); this._outline(ctx, '#dfe8ff', 2);
    ctx.fillStyle = 'rgba(255,255,255,0.18)';
    ctx.beginPath(); ctx.ellipse(88, 82, 22, 10, -0.4, 0, Math.PI * 2); ctx.fill();
    // œil
    ctx.fillStyle = '#0a0f1e'; ctx.beginPath(); ctx.arc(100, 102, 20, 0, Math.PI * 2); ctx.fill();
    this._eye(ctx, 100, 102, 13, '#ff4d5e');
    // antenne + pieds
    ctx.strokeStyle = c; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(100, 60); ctx.lineTo(100, 38); ctx.stroke();
    this._eye(ctx, 100, 36, 5, '#ffd166');
    ctx.fillStyle = a; ctx.fillRect(76, 138, 10, 18); ctx.fillRect(114, 138, 10, 18);
  },

  shape_hunter: function (ctx, c, a) {
    this._aura(ctx, 100, 100, 88, c, 0.35);
    // ailes en flèche
    this._metal(ctx, c, '#0a2a44', 40, 160);
    this._poly(ctx, [[100, 30], [128, 96], [176, 150], [122, 132], [100, 170], [78, 132], [24, 150], [72, 96]]);
    ctx.fill(); this._outline(ctx, c, 2.5);
    // nervures
    ctx.strokeStyle = a; ctx.lineWidth = 2; ctx.globalAlpha = 0.85;
    ctx.beginPath(); ctx.moveTo(100, 44); ctx.lineTo(100, 150); ctx.moveTo(100, 110); ctx.lineTo(150, 142); ctx.moveTo(100, 110); ctx.lineTo(50, 142); ctx.stroke();
    ctx.globalAlpha = 1;
    // arcs électriques
    ctx.save(); ctx.shadowColor = a; ctx.shadowBlur = 10; ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2.5;
    [[-1, 0], [1, 0]].forEach(function (s) {
      ctx.beginPath(); ctx.moveTo(100 + s[0] * 22, 100);
      ctx.lineTo(100 + s[0] * 34, 88); ctx.lineTo(100 + s[0] * 44, 104); ctx.lineTo(100 + s[0] * 58, 92); ctx.stroke();
    });
    ctx.restore();
    this._eye(ctx, 100, 92, 11, '#ffffff');
  },

  shape_juggernaut: function (ctx, c, a) {
    this._aura(ctx, 100, 100, 90, c, 0.26);
    // chenilles
    ctx.fillStyle = '#1c1f2b';
    ctx.beginPath(); ctx.roundRect ? ctx.roundRect(22, 128, 156, 34, 14) : ctx.rect(22, 128, 156, 34); ctx.fill();
    ctx.strokeStyle = '#4a5068'; ctx.lineWidth = 2;
    for (var i = 0; i < 8; i++) { ctx.beginPath(); ctx.moveTo(34 + i * 19, 130); ctx.lineTo(34 + i * 19, 160); ctx.stroke(); }
    // caisse blindée
    this._metal(ctx, c, a, 60, 140);
    this._poly(ctx, [[36, 128], [48, 70], [152, 70], [164, 128]]); ctx.fill(); this._outline(ctx, '#ffd9b8', 2);
    // plaques
    ctx.fillStyle = a; ctx.globalAlpha = 0.55;
    ctx.fillRect(58, 90, 84, 8); ctx.fillRect(66, 108, 68, 8); ctx.globalAlpha = 1;
    // tourelle + canon
    ctx.fillStyle = this._lin(ctx, 0, 40, 0, 80, [[0, '#ffc08a'], [1, c]]);
    ctx.beginPath(); ctx.ellipse(100, 66, 30, 20, 0, 0, Math.PI * 2); ctx.fill(); this._outline(ctx, '#ffd9b8', 2);
    ctx.fillStyle = a; ctx.fillRect(120, 58, 58, 12);
    ctx.fillStyle = '#ffb35c'; ctx.fillRect(172, 55, 12, 18);
    this._eye(ctx, 92, 64, 6, '#ff4d5e');
  },

  shape_swarm: function (ctx, c, a) {
    this._aura(ctx, 100, 100, 92, c, 0.3);
    var spores = [[100, 100, 30], [58, 78, 19], [144, 72, 21], [66, 132, 20], [138, 130, 22], [102, 52, 15], [100, 154, 14]];
    var self = this;
    // filaments
    ctx.strokeStyle = this._rgba(c, 0.6); ctx.lineWidth = 3;
    spores.slice(1).forEach(function (s) { ctx.beginPath(); ctx.moveTo(100, 100); ctx.lineTo(s[0], s[1]); ctx.stroke(); });
    spores.forEach(function (s, i) {
      ctx.save(); ctx.shadowColor = c; ctx.shadowBlur = 12;
      ctx.fillStyle = self._rad(ctx, s[0] - s[2] * 0.3, s[1] - s[2] * 0.3, 1, s[2] * 1.1, [[0, '#f2ffe8'], [0.5, c], [1, a]]);
      ctx.beginPath(); ctx.arc(s[0], s[1], s[2], 0, Math.PI * 2); ctx.fill(); ctx.restore();
      // épines
      ctx.strokeStyle = c; ctx.lineWidth = 2;
      for (var k = 0; k < 8; k++) {
        var ang = k * Math.PI / 4 + i;
        ctx.beginPath(); ctx.moveTo(s[0] + Math.cos(ang) * s[2], s[1] + Math.sin(ang) * s[2]);
        ctx.lineTo(s[0] + Math.cos(ang) * (s[2] + 7), s[1] + Math.sin(ang) * (s[2] + 7)); ctx.stroke();
      }
      ctx.fillStyle = a; ctx.beginPath(); ctx.arc(s[0], s[1], s[2] * 0.32, 0, Math.PI * 2); ctx.fill();
    });
  },

  shape_sniper: function (ctx, c, a) {
    this._aura(ctx, 100, 100, 84, c, 0.3);
    // grand fusil
    ctx.fillStyle = '#20143a'; ctx.fillRect(58, 96, 128, 9);
    ctx.fillStyle = c; ctx.fillRect(58, 94, 128, 3);
    ctx.fillStyle = '#20143a'; ctx.fillRect(176, 92, 12, 16);
    ctx.strokeStyle = c; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(120, 84, 9, 0, Math.PI * 2); ctx.stroke();
    // corps encapuchonné
    this._metal(ctx, c, a, 34, 168);
    this._poly(ctx, [[100, 32], [128, 66], [142, 168], [58, 168], [72, 66]]); ctx.fill(); this._outline(ctx, c, 2.5);
    // capuche sombre + œil unique
    ctx.fillStyle = '#0a0612';
    this._poly(ctx, [[100, 40], [118, 68], [100, 92], [82, 68]]); ctx.fill();
    this._eye(ctx, 100, 68, 7, '#ff4dff');
    // cape
    ctx.fillStyle = this._rgba(a, 0.8);
    this._poly(ctx, [[72, 110], [128, 110], [140, 168], [60, 168]]); ctx.fill();
    ctx.strokeStyle = c; ctx.lineWidth = 2; ctx.globalAlpha = 0.7;
    ctx.beginPath(); ctx.moveTo(100, 100); ctx.lineTo(100, 168); ctx.stroke(); ctx.globalAlpha = 1;
  },

  shape_bomber: function (ctx, c, a) {
    this._aura(ctx, 100, 104, 92, c, 0.32);
    // ailerons
    this._metal(ctx, '#7a1a1a', a, 60, 150);
    this._poly(ctx, [[34, 120], [64, 90], [70, 130]]); ctx.fill();
    this._poly(ctx, [[166, 120], [136, 90], [130, 130]]); ctx.fill();
    // ventre
    ctx.fillStyle = this._rad(ctx, 90, 86, 6, 76, [[0, '#ff9a8a'], [0.5, c], [1, a]]);
    ctx.beginPath(); ctx.ellipse(100, 100, 56, 48, 0, 0, Math.PI * 2); ctx.fill(); this._outline(ctx, '#ffb0a0', 2.5);
    // bandes + hublot
    ctx.strokeStyle = a; ctx.lineWidth = 5; ctx.globalAlpha = 0.5;
    ctx.beginPath(); ctx.ellipse(100, 100, 56, 20, 0, 0, Math.PI * 2); ctx.stroke(); ctx.globalAlpha = 1;
    this._eye(ctx, 100, 94, 11, '#ffd166');
    // bombes suspendues
    for (var i = 0; i < 3; i++) {
      var bx = 68 + i * 32;
      ctx.fillStyle = '#20080c'; ctx.beginPath(); ctx.ellipse(bx, 152, 11, 15, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = c; ctx.lineWidth = 2; ctx.stroke();
      this._eye(ctx, bx, 144, 3, '#ffd166');
    }
    // flamme dorsale
    ctx.save(); ctx.shadowColor = '#ff8a3d'; ctx.shadowBlur = 16; ctx.fillStyle = '#ff8a3d';
    this._poly(ctx, [[92, 54], [100, 30], [108, 54]]); ctx.fill(); ctx.restore();
  },

  shape_specter: function (ctx, c, a) {
    this._aura(ctx, 100, 100, 90, c, 0.38);
    // drap fantôme
    ctx.save(); ctx.shadowColor = c; ctx.shadowBlur = 16;
    ctx.fillStyle = this._lin(ctx, 0, 30, 0, 175, [[0, '#f0fbff'], [0.5, this._rgba(c, 0.85)], [1, this._rgba(c, 0.05)]]);
    ctx.beginPath(); ctx.moveTo(52, 100);
    ctx.bezierCurveTo(52, 30, 148, 30, 148, 100);
    ctx.lineTo(148, 150); ctx.lineTo(132, 168); ctx.lineTo(116, 148); ctx.lineTo(100, 172); ctx.lineTo(84, 148); ctx.lineTo(68, 168); ctx.lineTo(52, 150);
    ctx.closePath(); ctx.fill(); ctx.restore();
    // yeux creux
    ctx.fillStyle = a;
    ctx.beginPath(); ctx.ellipse(80, 90, 11, 16, 0.15, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(120, 90, 11, 16, -0.15, 0, Math.PI * 2); ctx.fill();
    this._eye(ctx, 80, 94, 5, '#ffffff'); this._eye(ctx, 120, 94, 5, '#ffffff');
    ctx.beginPath(); ctx.ellipse(100, 126, 9, 13, 0, 0, Math.PI * 2); ctx.fill();
    // cristaux de glace
    ctx.fillStyle = '#e8fbff'; ctx.strokeStyle = c; ctx.lineWidth = 1.5;
    [[44, 60, 1], [158, 66, -1], [156, 128, -1]].forEach(function (p) {
      ctx.beginPath(); ctx.moveTo(p[0], p[1] - 18); ctx.lineTo(p[0] + 8 * p[2], p[1]); ctx.lineTo(p[0], p[1] + 18); ctx.lineTo(p[0] - 8 * p[2], p[1]); ctx.closePath(); ctx.fill(); ctx.stroke();
    });
  },

  shape_golem: function (ctx, c, a) {
    this._aura(ctx, 100, 100, 90, c, 0.22);
    this._metal(ctx, c, a, 40, 170);
    // jambes
    ctx.fillRect(66, 132, 26, 40); ctx.fillRect(108, 132, 26, 40);
    // bras massifs
    ctx.beginPath(); ctx.rect(26, 74, 28, 66); ctx.fill(); ctx.beginPath(); ctx.rect(146, 74, 28, 66); ctx.fill();
    ctx.fillStyle = a; ctx.fillRect(22, 132, 36, 20); ctx.fillRect(142, 132, 36, 20);
    // torse
    this._metal(ctx, c, a, 60, 140);
    this._poly(ctx, [[50, 70], [150, 70], [140, 138], [60, 138]]); ctx.fill(); this._outline(ctx, '#ffffff', 2);
    // épaules
    ctx.fillStyle = this._lin(ctx, 0, 56, 0, 84, [[0, '#f1f6ff'], [1, c]]);
    ctx.beginPath(); ctx.ellipse(46, 70, 24, 14, 0, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(154, 70, 24, 14, 0, 0, Math.PI * 2); ctx.fill();
    // tête + visière
    this._metal(ctx, c, a, 34, 66);
    ctx.beginPath(); ctx.rect(76, 36, 48, 32); ctx.fill(); this._outline(ctx, '#ffffff', 2);
    ctx.fillStyle = '#05070f'; ctx.fillRect(82, 46, 36, 10);
    this._eye(ctx, 100, 51, 6, '#4fd1ff');
    // noyau
    this._eye(ctx, 100, 104, 12, '#4fd1ff');
    ctx.strokeStyle = a; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(100, 104, 17, 0, Math.PI * 2); ctx.stroke();
  },

  shape_vampire: function (ctx, c, a) {
    this._aura(ctx, 100, 96, 92, c, 0.34);
    // ailes de chauve-souris
    ctx.fillStyle = this._lin(ctx, 0, 40, 0, 150, [[0, c], [1, a]]);
    [1, -1].forEach(function (s) {
      ctx.beginPath(); ctx.moveTo(100 + s * 14, 90);
      ctx.lineTo(100 + s * 84, 38); ctx.lineTo(100 + s * 76, 78); ctx.lineTo(100 + s * 92, 104);
      ctx.lineTo(100 + s * 62, 106); ctx.lineTo(100 + s * 62, 136); ctx.lineTo(100 + s * 36, 112); ctx.closePath(); ctx.fill();
    });
    ctx.save(); ctx.strokeStyle = '#ffd0e6'; ctx.lineWidth = 2; ctx.shadowColor = c; ctx.shadowBlur = 8;
    [1, -1].forEach(function (s) { ctx.beginPath(); ctx.moveTo(100 + s * 14, 90); ctx.lineTo(100 + s * 84, 38); ctx.moveTo(100 + s * 14, 90); ctx.lineTo(100 + s * 92, 104); ctx.stroke(); });
    ctx.restore();
    // corps
    this._metal(ctx, '#3a1030', a, 60, 150);
    ctx.beginPath(); ctx.ellipse(100, 108, 26, 44, 0, 0, Math.PI * 2); ctx.fill(); this._outline(ctx, c, 2);
    // tête
    ctx.fillStyle = '#4a1a40'; ctx.beginPath(); ctx.arc(100, 66, 24, 0, Math.PI * 2); ctx.fill(); this._outline(ctx, c, 2);
    ctx.fillStyle = '#4a1a40';
    this._poly(ctx, [[80, 50], [76, 28], [92, 44]]); ctx.fill(); this._poly(ctx, [[120, 50], [124, 28], [108, 44]]); ctx.fill();
    this._eye(ctx, 90, 64, 5, '#ff4d5e'); this._eye(ctx, 110, 64, 5, '#ff4d5e');
    // crocs
    ctx.fillStyle = '#ffffff';
    this._poly(ctx, [[92, 76], [96, 90], [100, 76]]); ctx.fill(); this._poly(ctx, [[100, 76], [104, 90], [108, 76]]); ctx.fill();
    // étoile volée
    this._eye(ctx, 100, 118, 9, '#ffd166');
  },

  shape_architect: function (ctx, c, a) {
    this._aura(ctx, 100, 100, 92, c, 0.34);
    // anneaux orbitaux
    ctx.save(); ctx.strokeStyle = this._rgba(c, 0.75); ctx.lineWidth = 3; ctx.shadowColor = c; ctx.shadowBlur = 10;
    ctx.beginPath(); ctx.ellipse(100, 100, 78, 24, -0.35, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.ellipse(100, 100, 78, 24, 0.35, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
    // polyèdre central
    var g = this._lin(ctx, 60, 40, 140, 160, [[0, '#fff3cf'], [0.5, c], [1, a]]);
    ctx.fillStyle = g;
    this._poly(ctx, [[100, 36], [138, 70], [138, 130], [100, 164], [62, 130], [62, 70]]); ctx.fill(); this._outline(ctx, '#fff3cf', 2.5);
    ctx.strokeStyle = 'rgba(51,36,4,0.7)'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(100, 36); ctx.lineTo(100, 100); ctx.lineTo(138, 130); ctx.moveTo(100, 100); ctx.lineTo(62, 130); ctx.moveTo(62, 70); ctx.lineTo(100, 100); ctx.lineTo(138, 70); ctx.stroke();
    this._eye(ctx, 100, 100, 13, '#ffffff');
    // cubes orbitaux
    ctx.fillStyle = c;
    [[26, 84], [172, 116], [150, 44]].forEach(function (p) { ctx.fillRect(p[0] - 8, p[1] - 8, 16, 16); ctx.strokeStyle = '#fff3cf'; ctx.lineWidth = 1.5; ctx.strokeRect(p[0] - 8, p[1] - 8, 16, 16); });
  },

  // ---------- 3 boss ----------
  shape_boss_devourer: function (ctx, c, a) {
    this._aura(ctx, 100, 100, 100, c, 0.42);
    // épines dorsales
    ctx.fillStyle = a;
    for (var i = 0; i < 9; i++) {
      var ang = Math.PI + (i / 8) * Math.PI, r0 = 60, r1 = 92 + (i % 2) * 6;
      this._poly(ctx, [[100 + Math.cos(ang - 0.12) * r0, 100 + Math.sin(ang - 0.12) * r0], [100 + Math.cos(ang) * r1, 100 + Math.sin(ang) * r1], [100 + Math.cos(ang + 0.12) * r0, 100 + Math.sin(ang + 0.12) * r0]]);
      ctx.fill();
    }
    // corps sphérique
    ctx.fillStyle = this._rad(ctx, 84, 78, 8, 74, [[0, '#ff9aa4'], [0.5, c], [1, a]]);
    ctx.beginPath(); ctx.arc(100, 104, 62, 0, Math.PI * 2); ctx.fill(); this._outline(ctx, '#ffb3ba', 3);
    // gueule
    ctx.fillStyle = '#12030a';
    ctx.beginPath(); ctx.ellipse(100, 118, 42, 26, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#ff7a4d'; ctx.beginPath(); ctx.ellipse(100, 122, 30, 14, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#ffffff';
    for (var t = 0; t < 7; t++) {
      var tx = 66 + t * 11;
      this._poly(ctx, [[tx, 100 + Math.abs(t - 3) * 2.2], [tx + 5.5, 118], [tx + 11, 100 + Math.abs(t - 3) * 2.2]]); ctx.fill();
      this._poly(ctx, [[tx, 136 - Math.abs(t - 3) * 2.2], [tx + 5.5, 120], [tx + 11, 136 - Math.abs(t - 3) * 2.2]]); ctx.fill();
    }
    // yeux
    this._eye(ctx, 74, 78, 9, '#ffd166'); this._eye(ctx, 126, 78, 9, '#ffd166');
    this._eye(ctx, 100, 62, 6, '#ffffff');
    // griffes
    ctx.fillStyle = '#ffd9d0';
    [[36, 150], [164, 150]].forEach(function (p, k) { var s = k ? -1 : 1; ctx.beginPath(); ctx.moveTo(p[0], p[1]); ctx.lineTo(p[0] + s * 16, p[1] + 26); ctx.lineTo(p[0] + s * 4, p[1] + 6); ctx.lineTo(p[0] + s * 26, p[1] + 20); ctx.lineTo(p[0] + s * 10, p[1] - 4); ctx.closePath(); ctx.fill(); });
  },

  shape_boss_ai: function (ctx, c, a) {
    this._aura(ctx, 100, 100, 100, c, 0.42);
    // anneaux
    ctx.save(); ctx.shadowColor = c; ctx.shadowBlur = 14; ctx.strokeStyle = c;
    ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(100, 100, 88, 0, Math.PI * 2); ctx.stroke();
    ctx.lineWidth = 3; ctx.setLineDash([16, 10]); ctx.beginPath(); ctx.arc(100, 100, 74, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]); ctx.restore();
    // bras-panneaux
    this._metal(ctx, '#2b4a72', a, 30, 170);
    [0, 1, 2, 3].forEach(function (k) {
      ctx.save(); ctx.translate(100, 100); ctx.rotate(k * Math.PI / 2 + Math.PI / 4);
      ctx.beginPath(); ctx.moveTo(-14, -60); ctx.lineTo(14, -60); ctx.lineTo(24, -96); ctx.lineTo(-24, -96); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = c; ctx.lineWidth = 2; ctx.stroke(); ctx.restore();
    });
    // noyau
    ctx.fillStyle = this._rad(ctx, 100, 100, 4, 52, [[0, '#ffffff'], [0.35, c], [1, a]]);
    ctx.beginPath(); ctx.arc(100, 100, 50, 0, Math.PI * 2); ctx.fill(); this._outline(ctx, '#bdefff', 3);
    // grand œil
    ctx.fillStyle = '#050a14'; ctx.beginPath(); ctx.ellipse(100, 100, 32, 20, 0, 0, Math.PI * 2); ctx.fill();
    this._eye(ctx, 100, 100, 15, '#ff4d5e');
    ctx.strokeStyle = c; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(72, 100); ctx.lineTo(56, 100); ctx.moveTo(128, 100); ctx.lineTo(144, 100); ctx.stroke();
  },

  shape_boss_cataclysm: function (ctx, c, a) {
    this._aura(ctx, 100, 100, 102, c, 0.48);
    // cornes
    ctx.fillStyle = this._lin(ctx, 0, 10, 0, 90, [[0, '#e6d0ff'], [1, a]]);
    [1, -1].forEach(function (s) {
      ctx.beginPath(); ctx.moveTo(100 + s * 34, 60); ctx.quadraticCurveTo(100 + s * 78, 44, 100 + s * 70, 8); ctx.quadraticCurveTo(100 + s * 62, 44, 100 + s * 20, 46); ctx.closePath(); ctx.fill();
    });
    // cristaux latéraux
    ctx.fillStyle = this._lin(ctx, 0, 60, 0, 170, [[0, '#f1e4ff'], [0.5, c], [1, a]]);
    [1, -1].forEach(function (s) {
      ctx.beginPath(); ctx.moveTo(100 + s * 44, 100); ctx.lineTo(100 + s * 96, 84); ctx.lineTo(100 + s * 78, 118); ctx.lineTo(100 + s * 98, 152); ctx.lineTo(100 + s * 44, 132); ctx.closePath(); ctx.fill();
    });
    // corps fracturé
    ctx.fillStyle = this._rad(ctx, 90, 84, 6, 80, [[0, '#f5eaff'], [0.4, c], [1, a]]);
    this._poly(ctx, [[100, 40], [142, 66], [148, 118], [118, 168], [82, 168], [52, 118], [58, 66]]); ctx.fill(); this._outline(ctx, '#e6d0ff', 3);
    // fissures d'énergie
    ctx.save(); ctx.shadowColor = '#ffffff'; ctx.shadowBlur = 12; ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(100, 46); ctx.lineTo(92, 78); ctx.lineTo(108, 100); ctx.lineTo(94, 130); ctx.lineTo(102, 162);
    ctx.moveTo(108, 100); ctx.lineTo(136, 108); ctx.moveTo(92, 78); ctx.lineTo(66, 84); ctx.stroke(); ctx.restore();
    // trois yeux
    this._eye(ctx, 78, 92, 8, '#ff4dff'); this._eye(ctx, 122, 92, 8, '#ff4dff'); this._eye(ctx, 100, 76, 6, '#ffffff');
  },

  // ---------- Effets d'arène ----------
  _projectile: function (ctx) {
    var g = this._lin(ctx, 0, 0, 64, 0, [[0, 'rgba(255,255,255,0)'], [0.55, 'rgba(255,255,255,0.65)'], [1, 'rgba(255,255,255,1)']]);
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.moveTo(0, 13); ctx.quadraticCurveTo(30, 2, 60, 6); ctx.quadraticCurveTo(64, 13, 60, 20); ctx.quadraticCurveTo(30, 24, 0, 13); ctx.fill();
    ctx.fillStyle = this._rad(ctx, 56, 13, 0, 13, [[0, '#ffffff'], [1, 'rgba(255,255,255,0)']]);
    ctx.beginPath(); ctx.arc(56, 13, 13, 0, Math.PI * 2); ctx.fill();
  },
  _spark: function (ctx) {
    ctx.fillStyle = this._rad(ctx, 48, 48, 0, 46, [[0, 'rgba(255,255,255,1)'], [0.3, 'rgba(255,255,255,0.55)'], [1, 'rgba(255,255,255,0)']]);
    ctx.beginPath(); ctx.arc(48, 48, 46, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#ffffff';
    for (var k = 0; k < 8; k++) {
      ctx.save(); ctx.translate(48, 48); ctx.rotate(k * Math.PI / 4);
      var len = k % 2 ? 26 : 44, w = k % 2 ? 3 : 4.5;
      ctx.beginPath(); ctx.moveTo(6, -w); ctx.lineTo(len, 0); ctx.lineTo(6, w); ctx.closePath(); ctx.fill(); ctx.restore();
    }
  },
  _slash: function (ctx) {
    ctx.save(); ctx.translate(64, 64);
    ctx.fillStyle = this._lin(ctx, -50, -50, 50, 50, [[0, 'rgba(255,255,255,0)'], [0.5, 'rgba(255,255,255,0.95)'], [1, 'rgba(255,255,255,0)']]);
    ctx.beginPath(); ctx.moveTo(-54, 40); ctx.quadraticCurveTo(0, -60, 54, -34); ctx.quadraticCurveTo(4, -30, -54, 40); ctx.fill(); ctx.restore();
  },
  _floor: function (ctx, w, h) {
    // Sol de l'arène vu en perspective : lignes de fuite + horizontales resserrées vers l'horizon.
    var grad = this._lin(ctx, 0, 0, 0, h, [[0, 'rgba(60,90,180,0)'], [0.4, 'rgba(50,80,170,0.16)'], [1, 'rgba(30,40,110,0.42)']]);
    ctx.fillStyle = grad; ctx.fillRect(0, 0, w, h);
    ctx.lineWidth = 1.5;
    var vx = w / 2, vy = 0, i;
    for (i = -14; i <= 14; i++) {
      var bx = vx + i * (w / 9);
      ctx.strokeStyle = 'rgba(120,170,255,' + (0.30 - Math.abs(i) * 0.012) + ')';
      ctx.beginPath(); ctx.moveTo(vx + i * 6, vy); ctx.lineTo(bx, h); ctx.stroke();
    }
    for (i = 0; i < 12; i++) {
      var t = Math.pow(i / 11, 1.9), y = t * h;
      ctx.strokeStyle = 'rgba(120,170,255,' + (0.06 + t * 0.30) + ')';
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
    }
    ctx.fillStyle = this._lin(ctx, 0, 0, 0, h * 0.35, [[0, 'rgba(5,7,15,1)'], [1, 'rgba(5,7,15,0)']]);
    ctx.fillRect(0, 0, w, h * 0.35);
  },
  _asteroid: function (ctx, seed) {
    var pts = [], n = 11, i;
    for (i = 0; i < n; i++) {
      var ang = (i / n) * Math.PI * 2, r = 40 + ((i * 37 + seed * 53) % 17);
      pts.push([60 + Math.cos(ang) * r, 60 + Math.sin(ang) * r * 0.86]);
    }
    ctx.fillStyle = this._rad(ctx, 46, 42, 4, 72, [[0, '#7c7a94'], [0.6, '#3b3a52'], [1, '#14141f']]);
    this._poly(ctx, pts); ctx.fill();
    ctx.strokeStyle = 'rgba(160,190,255,0.35)'; ctx.lineWidth = 2; ctx.stroke();
    ctx.fillStyle = 'rgba(0,0,0,0.28)';
    [[46, 66, 9], [74, 50, 7], [66, 78, 6]].forEach(function (c) { ctx.beginPath(); ctx.arc(c[0], c[1], c[2], 0, Math.PI * 2); ctx.fill(); });
  },
  _bubble: function (ctx) {
    ctx.fillStyle = this._rad(ctx, 80, 80, 40, 76, [[0, 'rgba(120,220,255,0)'], [0.85, 'rgba(120,220,255,0.28)'], [1, 'rgba(200,245,255,0.75)']]);
    ctx.beginPath(); ctx.arc(80, 80, 76, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = 'rgba(220,250,255,0.9)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(80, 80, 74, 0, Math.PI * 2); ctx.stroke();
  }
};
