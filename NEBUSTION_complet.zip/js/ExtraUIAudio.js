// NEBUSTION - user-added intro + button audio.
// Kept separate from the existing gameplay SFX system.
(function () {
  'use strict';
  var base = './assets/audio/';
  var intro = new Audio(base + 'intro.mp3');
  var b1 = new Audio(base + 'button_click_1.mp3');
  var b2 = new Audio(base + 'button_click_2.mp3');

  intro.preload = 'auto';
  intro.autoplay = true;
  intro.playsInline = true;
  intro.loop = false;
  intro.volume = 0.55;
  b1.preload = 'auto'; b2.preload = 'auto';
  b1.volume = 0.16; b2.volume = 0.16;

  var unlocked = false, next = 1, introFinished = false;

  function unlock() {
    if (unlocked) return;
    unlocked = true;
    try { intro.load(); b1.load(); b2.load(); } catch (_) {}
  }

  function startIntro() {
    // On se base sur l'état réel de la balise <audio> (paused) plutôt que sur
    // un drapeau maison, pour éviter qu'un état désynchronisé bloque la relecture.
    if (introFinished || !intro.paused) return;
    if (window.NEBUSTION && NEBUSTION.Settings && !NEBUSTION.Settings.get().sfxOn) return;
    unlock();
    try {
      intro.volume = Math.min(1, currentSfxVolume() * 3.4);
      var p = intro.play();
      if (p && p.catch) p.catch(function(){});
    } catch (_) {}
  }

  intro.addEventListener('ended', function () { introFinished = true; });

  function stopIntro() {
    try { intro.pause(); } catch (_) {}
  }

  // Coupe immédiatement l'intro si l'utilisateur désactive les sons pendant qu'elle joue.
  if (window.NEBUSTION && NEBUSTION.Settings && NEBUSTION.Settings.onChange) {
    NEBUSTION.Settings.onChange(function (st) { if (!st.sfxOn) stopIntro(); });
  }

  function currentSfxVolume() { var st = (window.NEBUSTION && NEBUSTION.Settings) ? NEBUSTION.Settings.get() : null; return st ? Number(st.sfxVolume) : 0.16; }

  function clickSound(which) {
    if (window.NEBUSTION && NEBUSTION.Settings && !NEBUSTION.Settings.get().sfxOn) return;
    unlock();
    var a = which === 2 ? b2 : b1;
    try {
      a.pause(); a.currentTime = 0; a.volume = currentSfxVolume();
      var p = a.play();
      if (p && p.catch) p.catch(function(){});
    } catch (_) {}
    next = next === 1 ? 2 : 1;
  }

  window.nebustionExtraAudio = {
    startIntro: startIntro,
    stopIntro: stopIntro,
    clickSound: clickSound,
    unlock: unlock
  };

  // Autoplay: on tente de lancer l'intro tout de suite, mais la plupart des
  // navigateurs mobiles (Chrome inclus) bloquent le son tant qu'il n'y a pas
  // eu de première interaction de l'utilisateur avec la page.
  try { startIntro(); } catch (_) {}

  // Filet de sécurité : si l'autoplay a été bloqué (intro.paused reste true
  // après la tentative), on relance la lecture dès le tout premier geste de
  // l'utilisateur (tap/clic/touche), une seule fois.
  function retryIntroOnFirstInteraction() {
    if (!introFinished && intro.paused) {
      startIntro();
    }
    document.removeEventListener('pointerdown', retryIntroOnFirstInteraction, true);
    document.removeEventListener('touchstart', retryIntroOnFirstInteraction, true);
    document.removeEventListener('keydown', retryIntroOnFirstInteraction, true);
  }
  document.addEventListener('pointerdown', retryIntroOnFirstInteraction, { capture: true, once: true });
  document.addEventListener('touchstart', retryIntroOnFirstInteraction, { capture: true, once: true });
  document.addEventListener('keydown', retryIntroOnFirstInteraction, { capture: true, once: true });

  // DOM buttons (if any).
  document.addEventListener('pointerdown', function (e) {
    var el = e.target && e.target.closest && e.target.closest(
      'button,[role="button"],.btn,.button,input[type="button"],input[type="submit"],a.button'
    );
    if (el && !el.disabled) clickSound(next);
  }, { passive: true, capture: true });
})();
