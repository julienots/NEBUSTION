/**
 * NEBUSTION - main.js
 * Point d'entrée : initialise l'économie (chargement de la sauvegarde + production hors ligne),
 * configure Phaser et démarre le jeu. Résolution de référence 720x1280 (portrait mobile),
 * redimensionnée pour remplir l'écran (Scale.FIT).
 */
(function () {
  'use strict';

  if (typeof Phaser === 'undefined') {
    console.error('NEBUSTION: Phaser n\'a pas pu être chargé.');
    return;
  }

  // Mode test : ajouter ?debug=1 à l'adresse pour afficher les outils de test dans le panneau de production
  NEBUSTION.DEBUG = /[?&]debug=1/.test(window.location.search);

  // --- Économie : une seule instance globale, indépendante des scènes ---
  NEBUSTION.Resources = new NEBUSTION.ResourceManager();
  NEBUSTION.Resources.init(Date.now());        // charge la sauvegarde, crédite la production hors ligne
  NEBUSTION.Resources.installLifecycle(window, document);   // sauvegarde à la mise en veille / fermeture

  // --- Compte + sauvegarde en ligne (Firebase, facultatif — voir js/systems/CloudSave.js) ---
  // Entièrement best-effort : si Firebase n'a pas chargé ou n'est pas configuré, tout ce bloc
  // est un no-op et le jeu continue en sauvegarde locale uniquement, comme avant.
  // Exposée (idempotente) pour pouvoir être retentée plus tard si le jeu a démarré hors ligne
  // (voir index.html : réessai automatique du SDK Firebase au retour du réseau, sans recharger la page).
  NEBUSTION._cloudSaveWired = false;
  NEBUSTION.initCloudSave = function () {
    if (NEBUSTION._cloudSaveWired) return;
    try {
      var CS = NEBUSTION.CloudSave;
      if (!(CS && CS.init())) return;
      NEBUSTION._cloudSaveWired = true;
      var R0 = NEBUSTION.Resources;
      // Dernière sauvegarde locale AVANT cette session (init() vient d'en écrire une neuve, sans valeur pour comparer)
      var baseline = (R0.loadInfo && R0.loadInfo.state && Number(R0.loadInfo.state.savedAt)) || 0;
      var firstAuthCheck = true;
      CS.onAuthChange(function (user) {
        // Seule la toute première résolution (session Firebase déjà ouverte au chargement de la page, ou tout
        // juste rétablie après un démarrage hors ligne) déclenche la réconciliation automatique avec le compte ;
        // une connexion faite plus tard passe par AccountScene. CS.sync() ne perd jamais de progression en
        // silence : compte plus récent → restauré (l'ancienne partie est gardée à part) ; deux parties
        // différentes → les envois restent bloqués jusqu'au choix du joueur (écran Compte).
        if (!firstAuthCheck) return;
        firstAuthCheck = false;
        if (!user) return;
        CS.sync(R0.state, { baseline: baseline, isNew: R0.isNewGame, atStart: true }).then(function (res) {
          if (res && res.action === 'adopted') window.location.reload();
        });
      });
      // Sauvegarde locale → envoi en ligne (silencieux, au plus 1 envoi/20 s ; bloqué tant que la réconciliation n'est pas faite)
      R0.on('saved', function (info) {
        if (info && info.ok && CS.currentUser()) CS.pushSave(R0.state);
      });
      // Mise en veille / changement d'appli / fermeture : envoi immédiat (le minuteur de 20 s serait perdu)
      // Sauvegarde auto : envoi toutes les 30 s + à chaque amélioration/réinitialisation + reprise au retour du réseau
      var auto = CS.startAutoSave(function () { return R0.state; }, { everyMs: 30000 });
      R0.on('upgrade', function () { auto.now(); });
      R0.on('reset', function () { auto.now(); });
      function pushNow() { if (CS.currentUser()) CS.flush(R0.state); }
      document.addEventListener('visibilitychange', function () { if (document.hidden) pushNow(); });
      window.addEventListener('pagehide', pushNow);
    } catch (err) { console.error('NEBUSTION: compte / sauvegarde en ligne indisponible', err); }
  };
  NEBUSTION.initCloudSave();

  // --- Social : profil public + cadeaux des vrais joueurs (best-effort, sans effet hors compte) ---
  try { if (NEBUSTION.SocialManager) NEBUSTION.SocialManager.start(); } catch (err) { console.error('NEBUSTION: social indisponible', err); }

  // --- IA des 5 empires (hors ligne, sans serveur) : réactions aux conquêtes + évolution dans le temps (rattrapage 24 h max) ---
  try {
    if (NEBUSTION.EmpireAIManager && NEBUSTION.EmpireEvolutionManager) {
      NEBUSTION.EmpireAIManager.wire();
      NEBUSTION.EmpireEvolutionManager.start();
    }
  } catch (err) { console.error('NEBUSTION: évolution des empires indisponible', err); }

  // --- Raids ennemis contre le QG (étape 12, hors ligne, sans serveur) : lit l'élan des empires ci-dessus, ne les modifie jamais ---
  try { if (NEBUSTION.QGRaidManager) NEBUSTION.QGRaidManager.start(); } catch (err) { console.error('NEBUSTION: raids du QG indisponibles', err); }

  // --- Pass de saison : missions branchées sur les événements du jeu (aucun autre système modifié) ---
  try { if (NEBUSTION.PassManager) NEBUSTION.PassManager.wire(); } catch (err) { console.error('NEBUSTION: Pass de saison indisponible', err); }

  // --- Événements temporaires : missions branchées sur les événements du jeu + boss + boutique (étape 10) ---
  try { if (NEBUSTION.EventManager) NEBUSTION.EventManager.wire(); } catch (err) { console.error('NEBUSTION: événements indisponibles', err); }

  // --- Netteté du texte (anti-pixel) ---
  // Le jeu est dessiné en 720x1280 puis agrandi pour remplir l'écran (ex. x1.5 sur un téléphone 1080 px).
  // Avant : antialias:false => Phaser utilisait le filtre NEAREST (gros pixels) et les textes étaient créés en
  // résolution 1 => texte crénelé/pixelisé partout. Maintenant : filtre LINEAR + tous les textes rendus en
  // résolution 2 ou 3 (selon l'écran), y compris ceux créés par les scènes avec add.text(...).
  var CRISP_RES = (function () {
    var dpr = Math.min(window.devicePixelRatio || 1, 3);
    var fit = Math.min(window.innerWidth / 720, window.innerHeight / 1280) * dpr;
    return Math.max(2, Math.min(3, Math.ceil(fit)));
  })();
  NEBUSTION.TEXT_RESOLUTION = CRISP_RES;
  try {
    var GOF = Phaser.GameObjects.GameObjectFactory.prototype;
    var origText = GOF.text;
    GOF.text = function (x, y, text, style) {
      var t = origText.call(this, x, y, text, style);
      try { if (t && t.style && (t.style.resolution || 0) < CRISP_RES) t.setResolution(CRISP_RES); } catch (e) { /* garde la résolution par défaut */ }
      return t;
    };
    var GOC = Phaser.GameObjects.GameObjectCreator.prototype;
    var origMake = GOC.text;
    if (origMake) GOC.text = function (cfg, addToScene) {
      var t = origMake.call(this, cfg, addToScene);
      try { if (t && t.style && (t.style.resolution || 0) < CRISP_RES) t.setResolution(CRISP_RES); } catch (e) { /* idem */ }
      return t;
    };
  } catch (err) { console.error('NEBUSTION: netteté du texte indisponible', err); }

  var config = {
    type: Phaser.AUTO,
    parent: 'game-container',
    backgroundColor: '#05070f',
    scale: {
      mode: Phaser.Scale.FIT,
      // Le centrage est fait UNE seule fois, par le CSS (#game-container en flex). Avec CENTER_BOTH en plus,
      // Phaser ajoutait une marge par-dessus le flex → le jeu était décalé vers le bas (gros bandeau noir en haut).
      autoCenter: Phaser.Scale.NO_CENTER,
      width: 720,
      height: 1280
    },
    render: {
      antialias: true,           // filtre LINEAR (lissé). false = filtre NEAREST => texte et images pixelisés
      antialiasGL: false,        // pas de MSAA sur le contexte WebGL : on garde les FPS sur mobile
      pixelArt: false,
      roundPixels: false,
      transparent: false,
      powerPreference: 'high-performance',
      batchSize: 4096
    },
    fps: { target: 60, smoothStep: true },
    input: {
      activePointers: 2
    },
    scene: [
      NEBUSTION.BootScene,
      NEBUSTION.PreloadScene,
      NEBUSTION.SplashScene,
      NEBUSTION.MainMenuScene,
      NEBUSTION.PlanetScene,
      NEBUSTION.HeroesScene,
      NEBUSTION.EquipmentScene,
      NEBUSTION.ShipsScene,
      NEBUSTION.SkinsScene,
      NEBUSTION.CratesScene,
      NEBUSTION.ShopScene,
      NEBUSTION.PassScene,
      NEBUSTION.ExpeditionScene,
      NEBUSTION.EventScene,
      NEBUSTION.PrestigeScene,
      NEBUSTION.AchievementsScene,
      NEBUSTION.NebustionScene,
      NEBUSTION.CodexScene,
      NEBUSTION.CombatPrepScene,
      NEBUSTION.CombatScene,
      NEBUSTION.GalaxyScene,
      NEBUSTION.ShipFlightScene,
      NEBUSTION.UniverseScene,
      NEBUSTION.BlackHoleScene,
      NEBUSTION.BlackHoleRunScene,   // arène temps réel des rencontres du Trou Noir (doit suivre BlackHoleScene : affichée par-dessus)
      NEBUSTION.SolarSystemScene,   // système solaire de la Nouvelle Galaxie (ouvert depuis la carte Univers)
      NEBUSTION.ExoPlanetScene,   // planètes 3D du système solaire (ouvertes en touchant une planète)
      NEBUSTION.QGScene,
      NEBUSTION.SymbioteScene,   // Symtor : doit être enregistrée, sinon scene.start('SymbioteScene') laisse un écran noir
      NEBUSTION.SymbioteBattleScene,   // Combat animé réel du Symtor (barres de vie, coups portés)
      NEBUSTION.EnemyQGScene,
      NEBUSTION.SocialScene,   // Social : chat, joueurs (vrais + bots), clans, amis
      NEBUSTION.TroopsScene,
      NEBUSTION.QGBattleScene,
      NEBUSTION.AccountScene,
      NEBUSTION.ModsScene,
      NEBUSTION.AtelierScene,
      NEBUSTION.PlaceholderScene
    ].concat(
      // Scènes ajoutées par des mods (voir js/systems/ModManager.js + mods/manifest.js)
      (NEBUSTION.Mods && NEBUSTION.Mods.getExtraScenes) ? NEBUSTION.Mods.getExtraScenes() : []
    ).filter(Boolean)   // une scène facultative absente (ex. AccountScene non chargée) ne doit pas faire planter Phaser
  };

  try {
    window.__NEBUSTION_GAME__ = new Phaser.Game(config);
    var boot = document.getElementById('boot-status');
    if (boot) boot.style.display = 'none';

    // --- Mods/plugins : le jeu est prêt (voir js/systems/ModManager.js + mods/manifest.js) ---
    try { if (NEBUSTION.Mods) NEBUSTION.Mods.onGameReady(window.__NEBUSTION_GAME__); } catch (err) { console.error('NEBUSTION: erreur au démarrage des mods', err); }

    // La production passive avance à CHAQUE frame, quelle que soit la scène affichée.
    var lastGalaxyTick = 0;
    var lastNebustionTick = 0;
    window.__NEBUSTION_GAME__.events.on('step', function () {
      var t = Date.now();
      NEBUSTION.Resources.tick(t);
      // Galaxie (module 5C) : termine les scans et verse les revenus des planètes conquises, même hors de l'écran Galaxie.
      if (t - lastGalaxyTick >= 5000 && NEBUSTION.GalaxyManager) {
        lastGalaxyTick = t;
        try { NEBUSTION.GalaxyManager.update(t); NEBUSTION.GalaxyManager.collectColonies(t); } catch (err) { console.error('NEBUSTION: galaxie', err); }
      }
      // Module Nebustion (grand méchant) : fait avancer la jauge de corruption galactique, quelle que soit la scène affichée.
      if (t - lastNebustionTick >= 5000 && NEBUSTION.NebustionManager) {
        lastNebustionTick = t;
        try { NEBUSTION.NebustionManager.tick(t); } catch (err) { console.error('NEBUSTION: module Nebustion', err); }
      }
      // Mods/plugins : tick régulier (facultatif, un mod peut ignorer onTick s'il n'en a pas besoin).
      if (NEBUSTION.Mods) { try { NEBUSTION.Mods.onTick(t); } catch (err) { console.error('NEBUSTION: erreur tick des mods', err); } }
    });

    // Version du jeu, affichée en permanence (toutes les scènes) en bas à droite. À changer ici uniquement.
    NEBUSTION.VERSION = '3.4.0';
    if (!document.getElementById('nebustion-version')) {
      var vEl = document.createElement('div');
      vEl.id = 'nebustion-version';
      vEl.textContent = 'V.' + NEBUSTION.VERSION;
      vEl.style.cssText = 'position:fixed; right:8px; bottom:calc(env(safe-area-inset-bottom,0px) + 4px); z-index:99997;' +
        'font:11px/1.2 monospace; color:rgba(200,220,255,0.65); text-shadow:0 0 3px #000, 0 0 6px #000;' +
        'pointer-events:none; user-select:none;';
      document.body.appendChild(vEl);
    }

    // Empêche le "double tap zoom" et le scroll accidentel sur mobile
    document.addEventListener('touchmove', function (e) {
      e.preventDefault();
    }, { passive: false });

    window.addEventListener('resize', function () {
      if (window.__NEBUSTION_GAME__ && window.__NEBUSTION_GAME__.scale) {
        window.__NEBUSTION_GAME__.scale.refresh();
      }
    });
  } catch (err) {
    console.error('NEBUSTION: erreur au lancement du jeu', err);
    var fallback = document.getElementById('fallback-error');
    if (fallback) fallback.classList.add('visible');
  }
})();
