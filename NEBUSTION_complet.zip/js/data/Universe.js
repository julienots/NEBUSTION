/**
 * NEBUSTION - Universe (données pures, sans Phaser)
 * Carte des GALAXIES accessibles au-delà de Nexus (notre galaxie de départ, "Voie Aube").
 * Chaque galaxie est une destination de voyage : elle a son propre thème visuel (couleurs
 * de nébuleuse/étoiles réutilisées par UniverseScene) et, une fois débloquée, sa propre
 * carte de secteurs (même moteur que Galaxy.js/GalaxyManager.js, avec un jeu de données dédié).
 *
 * Pour l'instant seule "Voie Aube" (notre galaxie actuelle) est jouable. Les autres sont des
 * destinations révélées avec un aperçu de leur contenu (nouvelles troupes, cartes) et une
 * condition de déblocage claire : le contenu complet (secteurs, empires, combats) de chacune
 * arrive galaxie par galaxie.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Universe = (function () {
  'use strict';

  // ---------- Aperçu de la faction PARASITES (nouvelles troupes de la Nébuleuse Écarlate) ----------
  // Roster de démonstration : forme organique/essaim, très différente des 5 empires mécaniques/
  // militaires déjà en jeu. Ces cartes ne sont pas encore jouables en combat ; elles servent
  // d'aperçu ("à venir") tant que la galaxie n'est pas déverrouillée.
  var PARASITE_PREVIEW = [
    { id: 'par_spore', name: 'Spore Rampante', tier: 1, role: 'grunt', desc: 'Se multiplie au contact des débris organiques ennemis.', color: '#ff2e4d', accent: '#2a0006' },
    { id: 'par_essaim', name: 'Essaim Dévoreur', tier: 2, role: 'skirmisher', desc: 'Un nuage d\'insectes-spores qui ronge les coques en vol.', color: '#ff5c3a', accent: '#2a0006' },
    { id: 'par_carapace', name: 'Carapace-Mère', tier: 3, role: 'tank', desc: 'Régénère sa chitine tant qu\'elle reste au contact du sol infecté.', color: '#c81f3c', accent: '#1a0004' },
    { id: 'par_toxine', name: 'Vecteur Toxique', tier: 4, role: 'support', desc: 'Infecte les unités ennemies : elles perdent des PV chaque tour.', color: '#ff8a5c', accent: '#2a0006' },
    { id: 'par_reine', name: 'Reine Écarlate', tier: 5, role: 'elite', desc: 'Cœur de l\'essaim : sa mort libère une dernière vague de spores.', color: '#ff0033', accent: '#1a0004' }
  ];

  // ---------- Galaxies ----------
  // "visual" (seed + nombre de bras) pilote le disque spiral procédural généré par GalaxyBackdrop
  // pour la vue « starmap » (accueil + écran Univers) : mêmes valeurs des deux côtés pour que la
  // texture, mémorisée une seule fois par galaxie, soit identique partout où elle apparaît.
  var GALAXIES = [
    {
      id: 'aube', name: 'Voie Aube', subtitle: 'Notre galaxie — Nexus-01', kind: 'home',
      theme: { core: '#4fd6ff', mid: '#6c3ce9', dust: '#00e5ff' },
      desc: 'La galaxie où tout a commencé : Nexus-01 et les 5 empires de la Voie Aube.',
      unlock: null   // toujours accessible
    },
    {
      id: 'ecarlate', name: 'Nébuleuse Écarlate', subtitle: 'Territoire de l\'essaim Parasite', kind: 'sector',
      theme: { core: '#ff3b1e', mid: '#c81f3c', dust: '#ff5c3a' },
      desc: 'Une nébuleuse rouge infectée par un essaim organique qui dévore tout ce qui s\'en approche. Nouvelles troupes, nouvelles cartes.',
      unlock: { type: 'sector', sector: 's6', label: 'Débloquer Nyr\'ah (secteur 6) dans la Voie Aube' },
      enterSector: 's7',
      preview: PARASITE_PREVIEW,
      visual: { seed: 2, arms: 5 }
    },
    {
      id: 'glacial', name: 'Amas Glacial', subtitle: 'Confins gelés', kind: 'soon',
      theme: { core: '#dff6ff', mid: '#3a6e9e', dust: '#9fd4ff' },
      desc: 'Un amas d\'étoiles mourantes figées dans la glace. Contenu à venir.',
      unlock: { type: 'soon', label: 'Bientôt disponible' },
      visual: { seed: 3, arms: 2 }
    },
    {
      id: 'kaelis', name: 'Confins de Kaelis', subtitle: 'Zone inexplorée', kind: 'soon',
      theme: { core: '#fff6cf', mid: '#a8842c', dust: '#ffe28a' },
      desc: 'Signal capté aux confins de la carte connue. Contenu à venir.',
      unlock: { type: 'soon', label: 'Bientôt disponible' },
      visual: { seed: 4, arms: 4 }
    }
  ];

  var INDEX = {};
  GALAXIES.forEach(function (g) { INDEX[g.id] = g; });

  function galaxy(id) { return INDEX[id] || null; }

  /** Vrai si la galaxie est déblocable/jouable dès maintenant. */
  function isUnlocked(id) {
    var g = galaxy(id);
    if (!g) return false;
    if (!g.unlock) return true;
    if (g.unlock.type === 'sector') {
      var GM = NEBUSTION.GalaxyManager;
      return !!(GM && GM.isSectorUnlocked && GM.isSectorUnlocked(g.unlock.sector));
    }
    return false;   // 'soon' : jamais débloqué automatiquement pour l'instant
  }

  return {
    GALAXIES: GALAXIES,
    PARASITE_PREVIEW: PARASITE_PREVIEW,
    galaxy: galaxy,
    isUnlocked: isUnlocked
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.Universe; }
