/**
 * NEBUSTION - Pass (données + logique pure)
 * Pass de saison : 30 niveaux, piste GRATUITE + piste PREMIUM, points d'expérience de Pass (XP Pass)
 * gagnés via des missions quotidiennes et hebdomadaires. Les saisons durent 28 jours, s'enchaînent
 * automatiquement (thème, héros vedette et skins changent à chaque saison).
 *
 * Module pur (aucune dépendance à Phaser, testable sous Node). Les jours/semaines/saisons sont calculés
 * sur l'heure LOCALE du joueur (minuit local), à partir d'un point d'ancrage fixe (lundi 14 septembre 2026 = début de la saison 1).
 *
 * État de sauvegarde (voir PassManager) : { v, season, xp, premium, premiumSource, golden, goldenSource, claimed:{free,premium,golden},
 *   daily:{day,list}, weekly:{week,list}, lastLoginDay, history, stats }.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Pass = (function () {
  'use strict';

  var MAX_LEVEL = 30;
  var SEASON_DAYS = 28;
  var DAY_MS = 86400000;
  var WEEK_MS = 7 * DAY_MS;
  var SEASON_MS = SEASON_DAYS * DAY_MS;
  var ANCHOR = Date.UTC(2026, 8, 14);   // lundi 14 septembre 2026, 00:00 : début de la saison 1 (référence « locale », voir _local)
  var STATE_VERSION = 1;
  var DAILY_COUNT = 3, WEEKLY_COUNT = 3;

  var RES_NAMES = { dust: 'Poussière cosmique', crystal: 'Cristaux stellaires', energy: 'Énergie quantique', core: 'Noyaux antiques', metal: 'Métal galactique' };
  var RARITY_ORDER = ['commun', 'rare', 'epique', 'legendaire', 'mythique'];
  var RARITIES = {
    commun: { id: 'commun', name: 'Commun', color: 0x9aa5c0, hex: '#9aa5c0' },
    rare: { id: 'rare', name: 'Rare', color: 0x4fd1ff, hex: '#4fd1ff' },
    epique: { id: 'epique', name: 'Épique', color: 0xb47bff, hex: '#b47bff' },
    legendaire: { id: 'legendaire', name: 'Légendaire', color: 0xffd166, hex: '#ffd166' },
    mythique: { id: 'mythique', name: 'Mythique', color: 0xff4d5e, hex: '#ff4d5e' }
  };

  // ---------- Temps (heure locale) ----------
  function _local(now) { now = Number(now) || Date.now(); return now - new Date(now).getTimezoneOffset() * 60000; }
  function dayIndex(now) { return Math.floor((_local(now) - ANCHOR) / DAY_MS); }
  function weekIndex(now) { return Math.floor((_local(now) - ANCHOR) / WEEK_MS); }
  function msUntilNextDay(now) { var l = _local(now); return (dayIndex(now) + 1) * DAY_MS + ANCHOR - l; }
  function msUntilNextWeek(now) { var l = _local(now); return (weekIndex(now) + 1) * WEEK_MS + ANCHOR - l; }
  function seasonIndex(now) { return Math.max(0, Math.floor((_local(now) - ANCHOR) / SEASON_MS)); }

  // ---------- Saisons : thèmes qui tournent (la saison n utilise le thème n mod 4) ----------
  // skins : free (piste gratuite, niv. 10), p1 (niv. 5), p2 (niv. 15), p3 (niv. 25), p4 (niv. 30, légendaire)
  var THEMES = [
    { key: 'aube', name: 'Aube Stellaire', tagline: 'Une nouvelle étoile se lève sur la galaxie.', color: 0x00e5ff, color2: 0xffd166, hex: '#00e5ff', hex2: '#ffd166',
      hero: 'zyra', heroRarity: 'legendaire', subHero: 'lumina',
      skins: { free: 'h_cyan', p1: 'h_gold', p2: 's_aurora', p3: 'b_royal', p4: 'h_spectre', golden1: 's_halo', golden2: 'h_couronne' } },
    { key: 'vide', name: 'Ère du Vide', tagline: 'Le silence entre les étoiles réclame son dû.', color: 0x8a4dff, color2: 0xff6ec7, hex: '#8a4dff', hex2: '#ff6ec7',
      hero: 'korvax', heroRarity: 'mythique', subHero: 'selene',
      skins: { free: 'h_void', p1: 's_nebula', p2: 'b_royal', p3: 's_royal', p4: 's_phantom', golden1: 'b_eclipse', golden2: 'h_astral' } },
    { key: 'forge', name: 'Forge Solaire', tagline: 'Le feu des astres forge les légendes.', color: 0xff6a2a, color2: 0xffd166, hex: '#ff6a2a', hex2: '#ffd166',
      hero: 'drakor', heroRarity: 'legendaire', subHero: 'vortex',
      skins: { free: 'h_ember', p1: 's_solar', p2: 'b_inferno', p3: 'h_gold', p4: 'b_starforge', golden1: 's_magma', golden2: 'h_phenix' } },
    { key: 'givre', name: 'Givre Éternel', tagline: 'Un froid cosmique gèle les empires.', color: 0xa6e8ff, color2: 0x4fd1ff, hex: '#a6e8ff', hex2: '#4fd1ff',
      hero: 'vortex', heroRarity: 'mythique', subHero: 'nyx',
      skins: { free: 's_cobalt', p1: 'h_frost', p2: 's_aurora', p3: 's_royal', p4: 'h_spectre', golden1: 'b_cristal', golden2: 'h_polaris' } }
  ];

  function seasonInfo(now, forcedIdx) {
    now = Number(now) || Date.now();
    var idx = isFinite(forcedIdx) ? Math.max(0, Math.floor(forcedIdx)) : seasonIndex(now), l = _local(now);
    var endLocal = ANCHOR + (idx + 1) * SEASON_MS;
    return {
      index: idx, number: idx + 1, theme: THEMES[idx % THEMES.length],
      msLeft: Math.max(0, endLocal - l), totalMs: SEASON_MS,
      startMs: now - (l - (ANCHOR + idx * SEASON_MS)), endMs: now + Math.max(0, endLocal - l)
    };
  }

  // ---------- Niveaux / XP Pass ----------
  function xpForLevel(n) { n = Math.floor(n); return (n >= 1 && n <= MAX_LEVEL) ? 80 + 8 * n : 0; }   // XP pour passer du niveau n-1 au niveau n
  var CUM = [0];
  (function () { for (var i = 1; i <= MAX_LEVEL; i++) CUM[i] = CUM[i - 1] + xpForLevel(i); })();
  var MAX_XP = CUM[MAX_LEVEL];
  function totalXpForLevel(n) { n = Math.max(0, Math.min(MAX_LEVEL, Math.floor(n) || 0)); return CUM[n]; }
  function levelFromXp(xp) {
    xp = Math.max(0, Math.min(MAX_XP, Math.floor(Number(xp) || 0)));
    var lv = 0;
    while (lv < MAX_LEVEL && xp >= CUM[lv + 1]) lv++;
    var maxed = lv >= MAX_LEVEL;
    var need = maxed ? 0 : xpForLevel(lv + 1), into = maxed ? 0 : xp - CUM[lv];
    return { level: lv, into: into, need: need, pct: maxed ? 1 : (need ? into / need : 0), maxed: maxed, xp: xp };
  }

  // ---------- Récompenses : 30 niveaux × 2 pistes ----------
  var RS = function (id, n) { return { t: 'res', id: id, n: n }; };
  var GM = function (n) { return { t: 'gems', n: n }; };
  var FR = function (who, n) { return { t: 'frag', who: who, n: n }; };
  var SK = function (slot) { return { t: 'skin', slot: slot }; };
  var HE = function (n) { return { t: 'hero', n: n }; };
  var TR = function (id, n) { return { t: 'troop', id: id, n: n }; };   // module 18 : troupes de combat (Caserne)
  var CH = function (items) { return { t: 'chest', items: items }; };  // Coffret cosmique (Pass Doré) : plusieurs ressources d'un coup

  var FREE_TRACK = [
    RS('dust', 800), RS('crystal', 300), RS('energy', 250), FR('sub', 4), GM(10),
    RS('dust', 1500), TR('marine', 5), RS('crystal', 600), RS('core', 3), SK('free'),
    RS('dust', 2000), RS('energy', 500), FR('sub', 6), GM(15), RS('core', 5),
    RS('crystal', 1000), TR('berserker', 3), RS('dust', 3000), RS('energy', 800), FR('main', 10),
    GM(20), RS('crystal', 1500), RS('core', 6), RS('dust', 4000), FR('main', 12),
    RS('metal', 1200), RS('energy', 1200), GM(25), RS('core', 8), FR('main', 20)
  ];
  var PREMIUM_TRACK = [
    GM(20), RS('crystal', 800), FR('sub', 8), RS('dust', 2500), SK('p1'),
    RS('energy', 700), GM(20), RS('core', 6), RS('crystal', 1500), FR('main', 20),
    TR('titan', 1), RS('dust', 5000), GM(30), RS('energy', 1500), SK('p2'),
    RS('core', 10), RS('crystal', 2500), FR('sub', 15), RS('dust', 7000), HE(60),
    GM(40), RS('energy', 2200), RS('core', 14), RS('crystal', 4000), SK('p3'),
    TR('drone', 4), GM(50), FR('main', 30), RS('core', 20), SK('p4')
  ];
  // ---------- Pass Doré : piste exclusive au-dessus du Premium (voir PassManager.grantGolden) ----------
  // Inclut tout ce que fait la piste Premium en mieux : montants plus élevés, coffrets multi-ressources,
  // fragments/troupes renforcés et 2 skins 100% exclusifs par saison (golden1 niveau 12, golden2 niveau 30,
  // voir THEMES ci-dessous — jamais en vente en Boutique, voir Skins.js `exclusive`).
  var GOLDEN_TRACK = [
    GM(35), RS('crystal', 1400), FR('sub', 14), RS('dust', 4200), CH([{ id: 'crystal', n: 600 }, { id: 'energy', n: 400 }]),
    RS('energy', 1200), GM(35), RS('core', 10), RS('crystal', 2600), FR('main', 34),
    TR('titan', 2), SK('golden1'), GM(55), RS('energy', 2600), CH([{ id: 'crystal', n: 1800 }, { id: 'dust', n: 4000 }, { id: 'core', n: 4 }]),
    RS('core', 18), RS('crystal', 4200), FR('sub', 26), RS('dust', 12000), HE(100),
    GM(70), RS('energy', 3800), RS('core', 24), RS('crystal', 6800), CH([{ id: 'energy', n: 3000 }, { id: 'core', n: 10 }, { id: 'metal', n: 2500 }]),
    TR('drone', 8), GM(90), FR('main', 52), RS('core', 34), SK('golden2')
  ];

  function _bump(r) { var i = RARITY_ORDER.indexOf(r); return RARITY_ORDER[Math.min(i + 1, 3)]; }
  function _bracketRarity(level) {
    var r = level >= 30 ? 'legendaire' : level >= 20 ? 'epique' : level >= 10 ? 'rare' : 'commun';
    return (level % 5 === 0 && level < 30) ? _bump(r) : r;
  }
  var DUP_GEMS = { commun: 10, rare: 20, epique: 40, legendaire: 80 };   // skin déjà possédé → compensation en Prismes

  function _hero(id) { return (NEBUSTION.Heroes && NEBUSTION.Heroes.get) ? NEBUSTION.Heroes.get(id) : null; }
  function _heroName(id) { var h = _hero(id); return h ? h.name : id; }

  function resolveReward(desc, level, theme) {
    var rarity = _bracketRarity(level), out;
    if (desc.t === 'res') {
      out = { kind: 'res', res: desc.id, amount: desc.n, label: RES_NAMES[desc.id] || desc.id, detail: '×' + desc.n };
    } else if (desc.t === 'gems') {
      out = { kind: 'gems', amount: desc.n, label: 'Prismes', detail: '×' + desc.n };
    } else if (desc.t === 'frag') {
      var hid = desc.who === 'main' ? theme.hero : theme.subHero;
      out = { kind: 'frag', heroId: hid, amount: desc.n, label: 'Fragments de ' + _heroName(hid), detail: '×' + desc.n };
    } else if (desc.t === 'hero') {
      rarity = theme.heroRarity;
      out = { kind: 'hero', heroId: theme.hero, amount: desc.n, label: _heroName(theme.hero), detail: 'Héros vedette · ' + desc.n + ' fragments' };
    } else if (desc.t === 'troop') {
      var tdef = NEBUSTION.Troops && NEBUSTION.Troops.get ? NEBUSTION.Troops.get(desc.id) : null;
      out = { kind: 'troop', troopId: desc.id, amount: desc.n, icon: tdef ? tdef.icon : '🪖', label: (tdef ? tdef.name : desc.id) + ' ×' + desc.n, detail: 'Troupes de combat' };
    } else if (desc.t === 'chest') {
      var parts = desc.items.map(function (it) { return (RES_NAMES[it.id] || it.id) + ' ×' + it.n; });
      out = { kind: 'chest', items: desc.items.map(function (it) { return { res: it.id, amount: it.n }; }), label: 'Coffret cosmique', detail: parts.join(' · ') };
    } else {
      var sid = theme.skins[desc.slot], sk = NEBUSTION.Skins && NEBUSTION.Skins.get ? NEBUSTION.Skins.get(sid) : null;
      rarity = sk ? sk.rarity : 'epique';
      out = { kind: 'skin', skinId: sid, target: sk ? sk.target : 'hero', label: sk ? sk.name : sid, detail: 'Skin ' + (sk ? ({ hero: 'de héros', ship: 'de vaisseau', building: 'de bâtiment' }[sk.target]) : '') };
    }
    out.rarity = rarity;
    return out;
  }

  /** Les 30 niveaux d'une saison : [{ level, free, premium, golden }] (récompenses résolues pour le thème). */
  function levelsFor(seasonIdx) {
    var theme = THEMES[Math.max(0, seasonIdx | 0) % THEMES.length], out = [];
    for (var i = 0; i < MAX_LEVEL; i++) {
      out.push({ level: i + 1, free: resolveReward(FREE_TRACK[i], i + 1, theme), premium: resolveReward(PREMIUM_TRACK[i], i + 1, theme), golden: resolveReward(GOLDEN_TRACK[i], i + 1, theme) });
    }
    return out;
  }
  function reward(seasonIdx, level, track) {
    level = Math.floor(level);
    if (level < 1 || level > MAX_LEVEL) return null;
    var theme = THEMES[Math.max(0, seasonIdx | 0) % THEMES.length];
    var list = track === 'golden' ? GOLDEN_TRACK : (track === 'premium' ? PREMIUM_TRACK : FREE_TRACK);
    return resolveReward(list[level - 1], level, theme);
  }

  // ---------- Missions ----------
  // metric : login | tap | pod | upgrade | battle | win | purchase | gift  (alimentées par PassManager.wire)
  var DAILY_POOL = [
    { id: 'd_login', label: 'Se connecter au jeu', metric: 'login', target: 1, xp: 20 },
    { id: 'd_tap', label: 'Extraire des ressources 25 fois', metric: 'tap', target: 25, xp: 40 },
    { id: 'd_pod', label: 'Réclamer une caisse de ravitaillement', metric: 'pod', target: 1, xp: 30 },
    { id: 'd_upgrade', label: 'Améliorer un bâtiment', metric: 'upgrade', target: 1, xp: 50 },
    { id: 'd_battle', label: 'Livrer 3 combats', metric: 'battle', target: 3, xp: 50 },
    { id: 'd_win', label: 'Remporter un combat', metric: 'win', target: 1, xp: 60 },
    { id: 'd_shop', label: 'Faire un achat en boutique', metric: 'purchase', target: 1, xp: 40 },
    { id: 'd_gift', label: 'Récupérer le cadeau quotidien', metric: 'gift', target: 1, xp: 25 }
  ];
  var WEEKLY_POOL = [
    { id: 'w_win5', label: 'Remporter 5 combats', metric: 'win', target: 5, xp: 250 },
    { id: 'w_tap150', label: 'Extraire des ressources 150 fois', metric: 'tap', target: 150, xp: 200 },
    { id: 'w_upgrade3', label: 'Améliorer 3 bâtiments', metric: 'upgrade', target: 3, xp: 300 },
    { id: 'w_battle15', label: 'Livrer 15 combats', metric: 'battle', target: 15, xp: 300 },
    { id: 'w_shop3', label: 'Faire 3 achats en boutique', metric: 'purchase', target: 3, xp: 220 },
    { id: 'w_pod5', label: 'Réclamer 5 caisses de ravitaillement', metric: 'pod', target: 5, xp: 200 },
    { id: 'w_days3', label: 'Se connecter 3 jours différents', metric: 'login', target: 3, xp: 150 }
  ];
  var MISSION_INDEX = {};
  DAILY_POOL.forEach(function (m) { m.kind = 'daily'; MISSION_INDEX[m.id] = m; });
  WEEKLY_POOL.forEach(function (m) { m.kind = 'weekly'; MISSION_INDEX[m.id] = m; });
  function mission(id) { return Object.prototype.hasOwnProperty.call(MISSION_INDEX, id) ? MISSION_INDEX[id] : null; }

  function _rng(seed) {   // mulberry32
    var a = seed >>> 0;
    return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  /** Tirage déterministe (même jour/semaine → mêmes missions, sur tous les appareils). */
  function pickMissions(kind, periodIdx) {
    var pool = (kind === 'weekly' ? WEEKLY_POOL : DAILY_POOL).slice(), n = kind === 'weekly' ? WEEKLY_COUNT : DAILY_COUNT;
    var rnd = _rng((periodIdx * 2654435761 + (kind === 'weekly' ? 977 : 131)) >>> 0);
    for (var i = pool.length - 1; i > 0; i--) { var j = Math.floor(rnd() * (i + 1)), t = pool[i]; pool[i] = pool[j]; pool[j] = t; }
    return pool.slice(0, n).map(function (m) { return { id: m.id, p: 0, c: false }; });
  }
  function _cleanList(raw, kind) {
    var out = [], seen = {};
    (Array.isArray(raw) ? raw : []).forEach(function (m) {
      if (!m || typeof m !== 'object') return;
      var def = mission(m.id);
      if (!def || def.kind !== kind || seen[m.id]) return;
      seen[m.id] = true;
      var p = Math.max(0, Math.min(def.target, Math.floor(Number(m.p) || 0)));
      out.push({ id: m.id, p: p, c: m.c === true && p >= def.target });
    });
    return out;
  }

  // ---------- État de sauvegarde ----------
  function _fresh(seasonIdx, now) {
    return {
      v: STATE_VERSION, season: seasonIdx, xp: 0, premium: false, premiumSource: null, golden: false, goldenSource: null,
      claimed: { free: {}, premium: {}, golden: {} },
      daily: { day: dayIndex(now), list: pickMissions('daily', dayIndex(now)) },
      weekly: { week: weekIndex(now), list: pickMissions('weekly', weekIndex(now)) },
      lastLoginDay: -1, history: [], stats: { claims: 0, missions: 0 }
    };
  }
  function defaultState(now) { now = Number(now) || Date.now(); return _fresh(seasonIndex(now), now); }

  function _cleanClaims(raw) {
    var o = {};
    if (raw && typeof raw === 'object') for (var i = 1; i <= MAX_LEVEL; i++) if (raw[i] === true) o[i] = true;
    return o;
  }

  /** Nettoie une sauvegarde (et applique le changement de jour / semaine / saison). */
  function normalizeState(raw, now) {
    now = Number(now) || Date.now();
    var s = _fresh(seasonIndex(now), now);
    if (!raw || typeof raw !== 'object') return s;
    var hist = Array.isArray(raw.history) ? raw.history.filter(function (h) { return h && isFinite(h.season) && isFinite(h.level); }).slice(-12).map(function (h) {
      return { season: Math.floor(h.season), level: Math.max(0, Math.min(MAX_LEVEL, Math.floor(h.level))), premium: !!h.premium, golden: !!h.golden };
    }) : [];
    s.history = hist;
    s.stats = { claims: Math.max(0, Math.floor(Number(raw.stats && raw.stats.claims) || 0)), missions: Math.max(0, Math.floor(Number(raw.stats && raw.stats.missions) || 0)) };
    s.lastLoginDay = isFinite(raw.lastLoginDay) ? Math.floor(raw.lastLoginDay) : -1;

    var rawSeason = isFinite(raw.season) ? Math.floor(raw.season) : s.season;
    if (rawSeason >= s.season) {   // (>: horloge de l'appareil revenue en arrière → la progression est conservée, jamais effacée)
      s.season = rawSeason;
      s.xp = Math.max(0, Math.min(MAX_XP, Math.floor(Number(raw.xp) || 0)));
      s.premium = raw.premium === true;
      s.premiumSource = s.premium && typeof raw.premiumSource === 'string' ? raw.premiumSource.slice(0, 40) : null;
      s.golden = raw.golden === true;
      s.goldenSource = s.golden && typeof raw.goldenSource === 'string' ? raw.goldenSource.slice(0, 40) : null;
      if (s.golden) s.premium = true;   // le Pass Doré inclut toujours le Premium
      s.claimed = { free: _cleanClaims(raw.claimed && raw.claimed.free), premium: _cleanClaims(raw.claimed && raw.claimed.premium), golden: _cleanClaims(raw.claimed && raw.claimed.golden) };
    } else {
      // Nouvelle saison : la progression précédente est archivée, la piste repart de zéro (récompenses non réclamées expirées).
      hist.push({ season: rawSeason, level: levelFromXp(raw.xp).level, premium: raw.premium === true, golden: raw.golden === true });
      s.history = hist.slice(-12);
    }
    // Missions : conservées seulement si on est toujours dans le même jour / la même semaine.
    var d = raw.daily && typeof raw.daily === 'object' ? raw.daily : {}, w = raw.weekly && typeof raw.weekly === 'object' ? raw.weekly : {};
    if (d.day === s.daily.day) { var dl = _cleanList(d.list, 'daily'); if (dl.length) s.daily.list = dl; }
    if (w.week === s.weekly.week) { var wl = _cleanList(w.list, 'weekly'); if (wl.length) s.weekly.list = wl; }
    return s;
  }

  return {
    MAX_LEVEL: MAX_LEVEL, SEASON_DAYS: SEASON_DAYS, MAX_XP: MAX_XP, DAY_MS: DAY_MS,
    GOLDEN_LEVELS: GOLDEN_TRACK.length, RARITIES: RARITIES, RARITY_ORDER: RARITY_ORDER, RES_NAMES: RES_NAMES, THEMES: THEMES, DUP_GEMS: DUP_GEMS,
    DAILY_POOL: DAILY_POOL, WEEKLY_POOL: WEEKLY_POOL,
    dayIndex: dayIndex, weekIndex: weekIndex, seasonIndex: seasonIndex, seasonInfo: seasonInfo,
    msUntilNextDay: msUntilNextDay, msUntilNextWeek: msUntilNextWeek,
    xpForLevel: xpForLevel, totalXpForLevel: totalXpForLevel, levelFromXp: levelFromXp,
    levelsFor: levelsFor, reward: reward, mission: mission, pickMissions: pickMissions,
    defaultState: defaultState, normalizeState: normalizeState
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.Pass; }
