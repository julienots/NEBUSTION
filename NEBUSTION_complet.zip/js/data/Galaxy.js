/**
 * NEBUSTION - Galaxy (données pures, sans Phaser, testables sous Node)
 * Module Galaxie 1/3 : carte spatiale, 6 secteurs, 5 empires ennemis, planètes, routes.
 *
 * Tout est DONNÉE modulaire : les modules suivants (invasion, IA) lisent uniquement ces tables et
 * `battleSpec()` ; rien n'est codé en dur dans la scène. Pour ajouter une planète : une ligne dans
 * les tableaux SPEC_* plus, si besoin, une route dans LANES.
 *
 * Les unités d'empire ont EXACTEMENT le format de js/data/Enemies.js (id, name, tier, role, base,
 * visual, skill) : CombatEngine.makeEnemyUnit() peut les consommer telles quelles.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Galaxy = (function () {
  'use strict';

  var WORLD = { w: 2000, h: 3500 };
  var SCAN_TTL_MS = 12 * 3600 * 1000;      // un scan reste valable 12 h
  var RES_IDS = ['crystal', 'metal', 'energy', 'core', 'dust'];

  // ---------- Types de planètes (palette utilisée par GalaxyTextures) ----------
  var PLANET_TYPES = {
    terran:   { name: 'Tellurique',     inner: '#6fe0c0', outer: '#0c3a5a', atmo: '#66e0ff', feature: 'continents' },
    ice:      { name: 'Glacée',         inner: '#e4f6ff', outer: '#3a6e9e', atmo: '#bfe9ff', feature: 'bands' },
    desert:   { name: 'Désertique',     inner: '#ffd18a', outer: '#6e3a14', atmo: '#ffb768', feature: 'continents' },
    lava:     { name: 'Volcanique',     inner: '#ffb23d', outer: '#5a1204', atmo: '#ff6a2e', feature: 'cracks' },
    machine:  { name: 'Planète-forge',  inner: '#c9d0da', outer: '#3b2a1c', atmo: '#ff9f43', feature: 'grid' },
    void:     { name: 'Néant',          inner: '#8a4dff', outer: '#0a0418', atmo: '#b06bff', feature: 'swirl' },
    celestial:{ name: 'Céleste',        inner: '#fff6cf', outer: '#a8842c', atmo: '#ffe28a', feature: 'bands' },
    hell:     { name: 'Infernale',      inner: '#ff5a4a', outer: '#1e0404', atmo: '#ff3b3b', feature: 'cracks' },
    asteroid: { name: 'Ceinture d\'astéroïdes', inner: '#b8b0a4', outer: '#3a342e', atmo: '#9aa4b8', feature: 'craters' },
    station:  { name: 'Station en ruine', inner: '#b6c4d8', outer: '#28324a', atmo: '#7fb4ff', feature: 'grid' },
    organic:  { name: 'Infestée',        inner: '#ff4d5c', outer: '#2a0006', atmo: '#ff3b3b', feature: 'cracks' }
  };

  // ---------- Empires ----------
  // recRange : niveau d'équipe conseillé (difficulté Normal) de la planète la plus faible à la capitale.
  var EMPIRES = {
    vexor: {
      id: 'vexor', name: 'VEXOR', subtitle: 'Empire mécanique', sector: 's2', powerLevel: 1,
      color: 0xff9f43, hex: '#ff9f43', accent: '#3a2008', emblem: 'gear', recRange: [2, 14],
      description: 'Une civilisation de machines nées dans les forges d\'un monde mort. VEXOR assemble, répare et recommence : ses armées sont infinies tant que ses fonderies tournent.',
      doctrine: 'Production de masse, blindage lourd, réparation automatique.',
      resources: ['metal', 'energy'],
      defenseStyle: { shield: 'Plaques blindées', turret: 'Tourelle à pistons', shieldMult: 1.1, turretMult: 1.0 },
      trait: { name: 'Réassemblage', text: 'Les unités mécaniques se réparent entre les vagues.' },
      units: [
        { id: 'vx_scrapper', name: 'Ferrailleur Automate', tier: 1, role: 'grunt', base: { hp: 300, atk: 46, def: 26, spd: 70 }, visual: { shape: 'drone', color: '#ff9f43', accent: '#3a2008' }, skill: null },
        { id: 'vx_piston', name: 'Lancier Piston', tier: 2, role: 'skirmisher', base: { hp: 380, atk: 64, def: 30, spd: 96 }, visual: { shape: 'hunter', color: '#ffb768', accent: '#3a2008' }, skill: { name: 'Percée hydraulique', cooldown: 7, target: 'single', kind: 'singleDamage', power: 1.7 } },
        { id: 'vx_bulwark', name: 'Bastion à Vapeur', tier: 3, role: 'tank', base: { hp: 950, atk: 58, def: 80, spd: 44 }, visual: { shape: 'golem', color: '#c9d0da', accent: '#2a1a0a' }, skill: { name: 'Blindage réactif', cooldown: 9, target: 'self', kind: 'selfShield', power: 1.3 } },
        { id: 'vx_mechanic', name: 'Mécano-Réparateur', tier: 4, role: 'support', base: { hp: 520, atk: 50, def: 44, spd: 90 }, visual: { shape: 'architect', color: '#ffd166', accent: '#332404' }, skill: { name: 'Atelier mobile', cooldown: 7, target: 'allEnemies_self', kind: 'aoeHeal', power: 1.0 } },
        { id: 'vx_titan', name: 'Titan de Forge', tier: 5, role: 'elite', base: { hp: 1500, atk: 96, def: 74, spd: 58 }, visual: { shape: 'juggernaut', color: '#ff8a3d', accent: '#3a2008' }, skill: { name: 'Marteau-pilon', cooldown: 8, target: 'allEnemies_player', kind: 'aoeDamage', power: 0.9 } }
      ]
    },
    kael9: {
      id: 'kael9', name: 'KAEL-9', subtitle: 'Fédération stellaire', sector: 's3', powerLevel: 2,
      color: 0x3fa9ff, hex: '#3fa9ff', accent: '#0a1e38', emblem: 'star', recRange: [12, 25],
      description: 'Confédération de mille mondes unis par un même commandement. La Fédération KAEL-9 ne gagne pas par la force d\'un seul vaisseau, mais par la coordination parfaite de toutes ses flottes.',
      doctrine: 'Boucliers en grille, artillerie orbitale, flottes coordonnées.',
      resources: ['crystal', 'energy'],
      defenseStyle: { shield: 'Grille de boucliers fédérale', turret: 'Batterie orbitale', shieldMult: 1.35, turretMult: 1.2 },
      trait: { name: 'Commandement coordonné', text: 'La flotte réagit en renfort : les défenseurs se soutiennent mutuellement.' },
      units: [
        { id: 'k9_trooper', name: 'Marine Fédéral', tier: 1, role: 'grunt', base: { hp: 420, atk: 62, def: 36, spd: 84 }, visual: { shape: 'hunter', color: '#3fa9ff', accent: '#0a1e38' }, skill: null },
        { id: 'k9_patrol', name: 'Patrouilleur Ion', tier: 2, role: 'skirmisher', base: { hp: 470, atk: 78, def: 34, spd: 112 }, visual: { shape: 'drone', color: '#7fd0ff', accent: '#0a1e38' }, skill: { name: 'Tir ionique', cooldown: 7, target: 'single', kind: 'singleDamage', power: 1.8 } },
        { id: 'k9_gunner', name: 'Artilleur Orbital', tier: 3, role: 'sniper', base: { hp: 520, atk: 118, def: 38, spd: 82 }, visual: { shape: 'sniper', color: '#5fb8ff', accent: '#0a1e38' }, skill: { name: 'Frappe coordonnée', cooldown: 7, target: 'single', kind: 'singleDamage', power: 2.3 } },
        { id: 'k9_officer', name: 'Officier Tacticien', tier: 4, role: 'support', base: { hp: 620, atk: 60, def: 52, spd: 92 }, visual: { shape: 'architect', color: '#e6f4ff', accent: '#0a1e38' }, skill: { name: 'Ordres de bataille', cooldown: 7, target: 'allEnemies_self', kind: 'aoeHeal', power: 1.1 } },
        { id: 'k9_cruiser', name: 'Croiseur Amiral', tier: 5, role: 'elite', base: { hp: 1900, atk: 104, def: 90, spd: 60 }, visual: { shape: 'juggernaut', color: '#3fa9ff', accent: '#06101e' }, skill: { name: 'Salve de bordée', cooldown: 8, target: 'allEnemies_player', kind: 'aoeDamage', power: 0.95 } }
      ]
    },
    elyra: {
      id: 'elyra', name: 'ELYRA', subtitle: 'Ordre céleste', sector: 's4', powerLevel: 3,
      color: 0xffe28a, hex: '#ffe28a', accent: '#4a3a0c', emblem: 'wings', recRange: [20, 33],
      description: 'Un ordre de gardiens ailés qui prétend veiller sur l\'équilibre des étoiles. ELYRA juge, purifie et pardonne rarement : sa lumière guérit ses fidèles et consume ses ennemis.',
      doctrine: 'Sanctuaires fortifiés, régénération, frappes de lumière.',
      resources: ['crystal', 'core'],
      defenseStyle: { shield: 'Barrière radiante', turret: 'Prisme solaire', shieldMult: 1.5, turretMult: 1.1 },
      trait: { name: 'Sanctuaire', text: 'Régénération continue et bouclier sacré au début du combat.' },
      units: [
        { id: 'el_acolyte', name: 'Acolyte Aurique', tier: 1, role: 'grunt', base: { hp: 480, atk: 70, def: 40, spd: 90 }, visual: { shape: 'specter', color: '#ffe28a', accent: '#4a3a0c' }, skill: null },
        { id: 'el_guardian', name: 'Gardien Ailé', tier: 2, role: 'tank', base: { hp: 1200, atk: 66, def: 96, spd: 50 }, visual: { shape: 'golem', color: '#fff3c4', accent: '#4a3a0c' }, skill: { name: 'Aile protectrice', cooldown: 10, target: 'self', kind: 'selfShield', power: 1.5 } },
        { id: 'el_priest', name: 'Prêtre de Lumière', tier: 3, role: 'support', base: { hp: 640, atk: 64, def: 50, spd: 94 }, visual: { shape: 'architect', color: '#fff8e0', accent: '#4a3a0c' }, skill: { name: 'Bénédiction', cooldown: 7, target: 'allEnemies_self', kind: 'aoeHeal', power: 1.2 } },
        { id: 'el_seraph', name: 'Séraphin', tier: 4, role: 'skirmisher', base: { hp: 720, atk: 128, def: 50, spd: 108 }, visual: { shape: 'sniper', color: '#ffd166', accent: '#4a3a0c' }, skill: { name: 'Lance radiante', cooldown: 7, target: 'single', kind: 'singleDamage', power: 2.2 } },
        { id: 'el_archon', name: 'Archonte', tier: 5, role: 'elite', base: { hp: 2000, atk: 122, def: 100, spd: 72 }, visual: { shape: 'hunter', color: '#fffbe8', accent: '#4a3a0c' }, skill: { name: 'Jugement céleste', cooldown: 8, target: 'allEnemies_player', kind: 'aoeDamage', power: 1.1 } }
      ]
    },
    morvak: {
      id: 'morvak', name: 'MORVAK', subtitle: 'Légion infernale', sector: 's5', powerLevel: 4,
      color: 0xff3b3b, hex: '#ff3b3b', accent: '#2a0606', emblem: 'horns', recRange: [28, 42],
      description: 'Une légion née des flammes qui conquiert pour nourrir son forge-dieu. MORVAK ne négocie pas : chaque monde soumis devient un bûcher et chaque prisonnier une arme.',
      doctrine: 'Assauts massifs, terre brûlée, brutalité des champions.',
      resources: ['metal', 'dust', 'core'],
      defenseStyle: { shield: 'Mur de flammes', turret: 'Colonne de lave', shieldMult: 1.25, turretMult: 1.5 },
      trait: { name: 'Terre brûlée', text: 'Brûlures continues : les défenseurs infligent des dégâts sur la durée.' },
      units: [
        { id: 'mo_legionnaire', name: 'Légionnaire Cendré', tier: 1, role: 'grunt', base: { hp: 640, atk: 110, def: 48, spd: 80 }, visual: { shape: 'juggernaut', color: '#ff5a4a', accent: '#2a0606' }, skill: null },
        { id: 'mo_imp', name: 'Diablotin Incendiaire', tier: 2, role: 'skirmisher', base: { hp: 520, atk: 118, def: 40, spd: 116 }, visual: { shape: 'hunter', color: '#ff8a3d', accent: '#2a0606' }, skill: { name: 'Boule de braise', cooldown: 6, target: 'single', kind: 'singleDamage', power: 1.9 } },
        { id: 'mo_warlock', name: 'Sorcier de Braise', tier: 3, role: 'bomber', base: { hp: 700, atk: 128, def: 46, spd: 84 }, visual: { shape: 'bomber', color: '#ff4d4d', accent: '#2a0606' }, skill: { name: 'Pluie infernale', cooldown: 8, target: 'allEnemies_player', kind: 'aoeDamage', power: 1.0 } },
        { id: 'mo_executioner', name: 'Bourreau Écarlate', tier: 4, role: 'brute', base: { hp: 1300, atk: 150, def: 84, spd: 62 }, visual: { shape: 'golem', color: '#d92b2b', accent: '#1a0404' }, skill: { name: 'Décapitation', cooldown: 8, target: 'single', kind: 'singleDamage', power: 2.4 } },
        { id: 'mo_archdemon', name: 'Archidémon', tier: 5, role: 'elite', base: { hp: 2600, atk: 170, def: 100, spd: 74 }, visual: { shape: 'vampire', color: '#ff2a4d', accent: '#1a0404' }, skill: { name: 'Apocalypse', cooldown: 7, target: 'allEnemies_player', kind: 'aoeDamage', power: 1.25 } }
      ]
    },
    nyrah: {
      id: 'nyrah', name: 'NYR\'AH', subtitle: 'Empire du Néant', sector: 's6', powerLevel: 5,
      color: 0xa05cff, hex: '#a05cff', accent: '#12061f', emblem: 'eye', recRange: [38, 55],
      description: 'Ce qui reste quand les étoiles s\'éteignent. L\'empire NYR\'AH efface les mondes plutôt que de les conquérir, et ses armées ne sont que des ombres qui se souviennent d\'avoir existé.',
      doctrine: 'Puits de gravité, drain de vie, contrôle et ténèbres.',
      resources: ['core', 'dust', 'energy'],
      defenseStyle: { shield: 'Voile du Néant', turret: 'Puits de singularité', shieldMult: 1.6, turretMult: 1.7 },
      trait: { name: 'Brouillard du Néant', text: 'Réduit la précision de vos unités : une partie des attaques rate sa cible.' },
      units: [
        { id: 'ny_wisp', name: 'Ombre Errante', tier: 1, role: 'grunt', base: { hp: 520, atk: 92, def: 30, spd: 104 }, visual: { shape: 'specter', color: '#a05cff', accent: '#12061f' }, skill: null },
        { id: 'ny_caller', name: 'Invocateur du Vide', tier: 2, role: 'control', base: { hp: 640, atk: 84, def: 40, spd: 96 }, visual: { shape: 'specter', color: '#c99bff', accent: '#12061f' }, skill: { name: 'Étreinte du Néant', cooldown: 8, target: 'single', kind: 'stun', power: 0.9 } },
        { id: 'ny_devourer', name: 'Dévoreur d\'Âmes', tier: 3, role: 'drain', base: { hp: 900, atk: 120, def: 52, spd: 90 }, visual: { shape: 'vampire', color: '#8a3dff', accent: '#12061f' }, skill: { name: 'Festin du Vide', cooldown: 8, target: 'single', kind: 'drain', power: 2.0 } },
        { id: 'ny_singularity', name: 'Singularité Vivante', tier: 4, role: 'bomber', base: { hp: 780, atk: 110, def: 48, spd: 70 }, visual: { shape: 'bomber', color: '#d6b3ff', accent: '#12061f' }, skill: { name: 'Effondrement', cooldown: 8, target: 'allEnemies_player', kind: 'aoeDamage', power: 1.05 } },
        { id: 'ny_horror', name: 'Horreur Abyssale', tier: 5, role: 'elite', base: { hp: 2200, atk: 150, def: 96, spd: 80 }, visual: { shape: 'golem', color: '#7a2cff', accent: '#0a0314' }, skill: { name: 'Cri du Néant', cooldown: 7, target: 'allEnemies_player', kind: 'aoeDamage', power: 1.2 } }
      ]
    },
    parasite: {
      id: 'parasite', name: 'PARASITE', subtitle: 'Essaim de la Nébuleuse Écarlate', sector: 's7', powerLevel: 6,
      color: 0xff2e4d, hex: '#ff2e4d', accent: '#2a0006', emblem: 'spore', recRange: [50, 68],
      description: 'Un organisme galactique unique, éclaté en milliards de spores. L\'essaim Parasite ne conquiert pas : il infecte, digère et se souvient de tout ce qu\'il a dévoré.',
      doctrine: 'Prolifération rapide, infection, régénération collective.',
      resources: ['dust', 'core'],
      defenseStyle: { shield: 'Membrane Organique', turret: 'Aiguillon Toxique', shieldMult: 1.75, turretMult: 1.8 },
      trait: { name: 'Infestation', text: 'Les unités blessées libèrent des spores : une partie des dégâts subis est renvoyée à l\'attaquant.' },
      units: [
        { id: 'par_spore', name: 'Spore Rampante', tier: 1, role: 'grunt', base: { hp: 700, atk: 130, def: 40, spd: 110 }, visual: { shape: 'specter', color: '#ff5c3a', accent: '#2a0006' }, skill: null },
        { id: 'par_essaim', name: 'Essaim Dévoreur', tier: 2, role: 'skirmisher', base: { hp: 620, atk: 150, def: 36, spd: 130 }, visual: { shape: 'hunter', color: '#ff2e4d', accent: '#2a0006' }, skill: { name: 'Morsure grouillante', cooldown: 6, target: 'single', kind: 'singleDamage', power: 2.0 } },
        { id: 'par_carapace', name: 'Carapace-Mère', tier: 3, role: 'tank', base: { hp: 1700, atk: 90, def: 130, spd: 40 }, visual: { shape: 'golem', color: '#c81f3c', accent: '#1a0004' }, skill: { name: 'Chitine régénérante', cooldown: 9, target: 'self', kind: 'selfShield', power: 1.4 } },
        { id: 'par_toxine', name: 'Vecteur Toxique', tier: 4, role: 'support', base: { hp: 850, atk: 80, def: 60, spd: 100 }, visual: { shape: 'bomber', color: '#ff8a5c', accent: '#2a0006' }, skill: { name: 'Infection lente', cooldown: 8, target: 'single', kind: 'drain', power: 2.1 } },
        { id: 'par_reine', name: 'Reine Écarlate', tier: 5, role: 'elite', base: { hp: 3000, atk: 190, def: 110, spd: 85 }, visual: { shape: 'vampire', color: '#ff0033', accent: '#1a0004' }, skill: { name: 'Éclosion finale', cooldown: 7, target: 'allEnemies_player', kind: 'aoeDamage', power: 1.3 } }
      ]
    }
  };
  var EMPIRE_ORDER = ['vexor', 'kael9', 'elyra', 'morvak', 'nyrah', 'parasite'];

  // ---------- Secteurs ----------
  // unlock : conditions cumulatives (stages = nombre de stages du module Combat terminés ;
  //          scans = planètes scannées dans un secteur ; cost = ressources dépensées).
  //          D'autres conditions (conquêtes...) pourront être ajoutées par les modules suivants
  //          via GalaxyManager.addRequirementProvider().
  var SECTORS = [
    { id: 's1', index: 0, name: 'Secteur Origine', subtitle: 'Berceau de Nexus-01', empire: null, cx: 1000, cy: 2470, rx: 760, ry: 330,
      description: 'Votre système natal et ses avant-postes libres. Idéal pour apprendre à scanner avant d\'attaquer.', unlock: null },
    { id: 's2', index: 1, name: 'Ceinture de Vexor', subtitle: 'Territoire VEXOR', empire: 'vexor', cx: 860, cy: 1960, rx: 720, ry: 330,
      description: 'Une ceinture de fonderies flottantes. Les machines de VEXOR défendent chaque forge.',
      unlock: { stages: 2, scans: { sector: 's1', n: 2 }, cost: { crystal: 250, energy: 80 } } },
    { id: 's3', index: 2, name: 'Marches de Kael-9', subtitle: 'Territoire KAEL-9', empire: 'kael9', cx: 1330, cy: 1540, rx: 680, ry: 340,
      description: 'Les stations fédérales quadrillent ce secteur d\'une grille de boucliers et de patrouilles.',
      unlock: { stages: 5, scans: { sector: 's2', n: 3 }, cost: { crystal: 1200, metal: 900, energy: 300 } } },
    { id: 's4', index: 3, name: 'Halo d\'Elyra', subtitle: 'Territoire ELYRA', empire: 'elyra', cx: 620, cy: 1140, rx: 640, ry: 330,
      description: 'Des sanctuaires baignés de lumière. Chaque monde est protégé par une barrière sacrée.',
      unlock: { stages: 8, scans: { sector: 's3', n: 3 }, cost: { crystal: 3000, metal: 2200, energy: 800, core: 6 } } },
    { id: 's5', index: 4, name: 'Brasier de Morvak', subtitle: 'Territoire MORVAK', empire: 'morvak', cx: 1290, cy: 770, rx: 680, ry: 330,
      description: 'Des mondes de lave et de cendres où la Légion forge ses armées infernales.',
      unlock: { stages: 10, scans: { sector: 's4', n: 3 }, cost: { crystal: 5500, metal: 4200, energy: 1600, core: 15 } } },
    { id: 's6', index: 5, name: 'Abysse de Nyr\'ah', subtitle: 'Territoire NYR\'AH', empire: 'nyrah', cx: 1010, cy: 320, rx: 780, ry: 300,
      description: 'Le cœur du Néant. Peu d\'étoiles y brillent encore.',
      unlock: { stages: 13, scans: { sector: 's5', n: 3 }, cost: { crystal: 9000, metal: 7000, energy: 3200, core: 40 } } },
    { id: 's7', index: 6, name: 'Nébuleuse Écarlate', subtitle: 'Territoire PARASITE', empire: 'parasite', cx: 1010, cy: 3020, rx: 760, ry: 260,
      description: 'Une nébuleuse rouge où l\'espace lui-même semble infecté. Première galaxie hors de la Voie Aube.',
      unlock: { scans: { sector: 's6', n: 3 }, cost: { crystal: 14000, metal: 11000, energy: 5000, core: 70 } } }
  ];

  // ---------- Planètes : [id, nom, type, x, y, tier, description] ----------
  var SPEC_NEUTRAL = [
    ['halo7',   'Ceinture Halo-7', 'asteroid', 640, 2440, 1, 'Un champ d\'astéroïdes infesté de drones de garde abandonnés.'],
    ['cendre2', 'Cendre-2',        'desert',  1360, 2420, 1, 'Un monde de poussière rouge où rôdent des chasseurs égarés.'],
    ['lyr',     'Épave de Lyr',    'station', 1000, 2290, 2, 'Une station en ruine : porte d\'entrée vers la Ceinture de Vexor.']
  ];
  var SPEC_EMPIRE = {
    vexor: [
      ['vx1', 'Forge-Alpha',           'machine',  930, 2130, 1, 'Première fonderie de la ceinture, gardée par des automates.'],
      ['vx2', 'Rouages de Kheld',      'machine', 1250, 2060, 2, 'Un labyrinthe d\'engrenages géants en rotation permanente.'],
      ['vx3', 'Fonderie Ossature',     'machine',  560, 2020, 3, 'On y fond les carcasses des vaincus pour en tirer des pièces.'],
      ['vx4', 'Tour Piston',           'machine',  950, 1900, 4, 'Une tour de guerre hérissée de pistons hydrauliques.'],
      ['vx5', 'VEXOR PRIME · Citadelle-Moteur', 'machine', 650, 1790, 5, 'Capitale de VEXOR : un moteur planétaire qui ne s\'arrête jamais.']
    ],
    kael9: [
      ['k91', 'Station Orbe-1',        'terran', 1130, 1700, 1, 'Un avant-poste fédéral en orbite basse.'],
      ['k92', 'Havre Fédéral',         'terran', 1500, 1680, 2, 'Un port stellaire où mouillent les patrouilles de la Fédération.'],
      ['k93', 'Base Méridian',         'ice',    1630, 1500, 3, 'Une base glacée équipée de batteries orbitales.'],
      ['k94', 'Arsenal Sigma',         'ice',    1250, 1500, 4, 'L\'arsenal de la flotte : hangars, croiseurs et artilleurs.'],
      ['k95', 'Capitole Kael-9',       'terran', 1400, 1330, 5, 'Capitale de la Fédération, siège de l\'Amiral suprême.']
    ],
    elyra: [
      ['el1', 'Aube-Prime',            'celestial',  950, 1260, 1, 'Un monde doré où l\'aube ne se termine jamais.'],
      ['el2', 'Jardin des Halos',      'celestial',  620, 1330, 2, 'Des jardins suspendus gardés par des acolytes en prière.'],
      ['el3', 'Reliquaire Solaire',    'celestial',  380, 1180, 3, 'On y conserve les reliques des premiers gardiens.'],
      ['el4', 'Cathédrale-Prisme',     'celestial',  720, 1100, 4, 'Un prisme colossal qui concentre la lumière des étoiles.'],
      ['el5', 'ELYRA · Trône Céleste', 'celestial',  520, 1000, 5, 'Capitale de l\'Ordre : le Trône où siège l\'Archonte.']
    ],
    morvak: [
      ['mo1', 'Braise-Noire',          'lava',   820, 880, 1, 'Un monde de basalte fumant, premier bivouac de la Légion.'],
      ['mo2', 'Fosse de Cendres',      'lava',  1150, 940, 2, 'Un cratère sans fond où s\'entassent les prisonniers.'],
      ['mo3', 'Bastion Écarlate',      'hell',  1550, 900, 3, 'Une forteresse de roche rouge défendue par des sorciers.'],
      ['mo4', 'Forge des Damnés',      'hell',  1300, 700, 4, 'C\'est ici que la Légion forge ses armes infernales.'],
      ['mo5', 'MORVAK · Citadelle Infernale', 'hell', 1550, 620, 5, 'Capitale de la Légion : un volcan couronné de cathédrales noires.']
    ],
    nyrah: [
      ['ny1', 'Lisière du Vide',       'void', 1250, 430, 1, 'Là où les étoiles cessent : les premières ombres.'],
      ['ny2', 'Nébuleuse Morte',       'void',  800, 470, 2, 'Un nuage de matière noire peuplé d\'ombres errantes.'],
      ['ny3', 'Puits de Silence',      'void',  450, 360, 3, 'Aucun son, aucune lumière : seulement la gravité.'],
      ['ny4', 'Œil de l\'Abîme',       'void', 1520, 260, 4, 'Une singularité qui vous regarde en retour.'],
      ['ny5', 'NYR\'AH · Trône du Néant', 'void', 1000, 170, 5, 'Capitale du Néant : le vide fait trône.']
    ],
    parasite: [
      ['pa1', 'Nid-Pourri',            'organic', 850, 3200, 1, 'Un ancien avant-poste, entièrement recouvert de chitine et de spores.'],
      ['pa2', 'Larve-Amas',            'organic', 1180, 3170, 2, 'Des milliers de larves grouillent sous une croûte organique palpitante.'],
      ['pa3', 'Muraille de Chitine',   'organic', 650, 3060, 3, 'Un rempart vivant, épais de plusieurs kilomètres, qui se referme sur les intrus.'],
      ['pa4', 'Antre Toxique',         'organic', 1000, 2980, 4, 'L\'air y est saturé de spores : aucune vie extérieure n\'y survit longtemps.'],
      ['pa5', 'PARASITE PRIME · Cœur de la Reine', 'organic', 900, 2840, 5, 'Capitale de l\'essaim : la Reine Écarlate y couve depuis l\'aube de la nébuleuse.']
    ]
  };

  // ---------- Routes spatiales ----------
  var LANES = [
    ['nexus_01', 'halo7'], ['nexus_01', 'cendre2'], ['nexus_01', 'lyr'], ['halo7', 'lyr'], ['cendre2', 'lyr'],
    ['lyr', 'vx1', 'hyper'],
    ['vx1', 'vx2'], ['vx1', 'vx3'], ['vx1', 'vx4'], ['vx2', 'vx4'], ['vx3', 'vx5'], ['vx4', 'vx5'],
    ['vx5', 'k91', 'hyper'],
    ['k91', 'k92'], ['k91', 'k94'], ['k92', 'k93'], ['k92', 'k94'], ['k93', 'k95'], ['k94', 'k95'],
    ['k95', 'el1', 'hyper'],
    ['el1', 'el2'], ['el1', 'el4'], ['el2', 'el3'], ['el2', 'el4'], ['el3', 'el5'], ['el4', 'el5'],
    ['el5', 'mo1', 'hyper'],
    ['mo1', 'mo2'], ['mo1', 'mo4'], ['mo2', 'mo3'], ['mo2', 'mo4'], ['mo3', 'mo5'], ['mo4', 'mo5'],
    ['mo5', 'ny1', 'hyper'],
    ['ny1', 'ny2'], ['ny1', 'ny4'], ['ny2', 'ny3'], ['ny2', 'ny5'], ['ny4', 'ny5'], ['ny3', 'ny5'],
    ['ny5', 'pa1', 'hyper'],
    ['pa1', 'pa2'], ['pa1', 'pa3'], ['pa2', 'pa4'], ['pa3', 'pa4'], ['pa3', 'pa5'], ['pa4', 'pa5']
  ].map(function (l) { return { a: l[0], b: l[1], type: l[2] || 'route' }; });

  // ---------- Puissance : estimation calibrée sur les stages du module Combat ----------
  function unitPower(base, scale) { return Math.sqrt(base.hp * base.atk * (1 + base.def / 100)) * (scale || 1); }
  // Points (puissance → niveau conseillé Normal) tirés des stages 1/boss Vorath/Nexus/Omega du module Combat.
  // Au-delà des stages existants, la courbe est une extrapolation (à recalibrer au module d'invasion).
  var REC_ANCHORS = [[0, 1], [220, 1], [1140, 5], [1700, 11], [2450, 18], [4600, 30], [8200, 45], [13000, 60], [16000, 68]];
  function interp(x, xi, yi) {
    var A = REC_ANCHORS;
    if (x <= A[0][xi]) return A[0][yi];
    for (var i = 1; i < A.length; i++) {
      if (x <= A[i][xi]) { var p = A[i - 1], q = A[i]; return p[yi] + (q[yi] - p[yi]) * (x - p[xi]) / (q[xi] - p[xi]); }
    }
    return A[A.length - 1][yi];
  }
  function recFromPower(p) { return Math.max(1, Math.round(interp(p, 0, 1))); }
  function powerForRec(r) { return interp(r, 1, 0); }

  // ---------- Construction des planètes ----------
  var FLEET_BY_TIER = {
    1: [[0, 2]], 2: [[0, 2], [1, 1]], 3: [[1, 2], [2, 1]], 4: [[1, 2], [2, 1], [3, 1]], 5: [[2, 1], [3, 1], [4, 1]]
  };
  var NEUTRAL_FLEETS = {
    1: [{ unit: 'drone_sentinel', count: 2 }],
    2: [{ unit: 'voltaic_hunter', count: 1 }, { unit: 'drone_sentinel', count: 2 }]
  };
  var BASE_DEPOSIT = { crystal: 180, metal: 150, energy: 80, core: 1.2, dust: 320 };   // par heure, avant modulation
  var BASE_LOOT = { crystal: 60, metal: 40, energy: 18, dust: 90, core: 0 };
  var HOME = { id: 'nexus_01', name: 'Nexus-01', sector: 's1', empire: null, kind: 'home', type: 'terran', x: 1000, y: 2580, r: 56, tier: 0,
    isCapital: false, desc: 'Votre planète-mère. Le Commandement, les gisements et les drones vous y attendent.', defense: null, deposits: {}, rewards: null,
    threat: 0, scale: 1, power: 0, recLevel: 0, scan: null };

  var UNIT_INDEX = {};
  EMPIRE_ORDER.forEach(function (eid) { EMPIRES[eid].units.forEach(function (u) { u.empire = eid; UNIT_INDEX[u.id] = u; }); });

  function unitDef(id) {
    if (UNIT_INDEX[id]) return UNIT_INDEX[id];
    return (NEBUSTION.Enemies && NEBUSTION.Enemies.get) ? NEBUSTION.Enemies.get(id) : null;
  }

  function fleetPower(fleet, scale) {
    var p = 0;
    fleet.forEach(function (g) { var d = unitDef(g.unit); if (d) p += unitPower(d.base, scale) * g.count; });
    return p;
  }

  function buildEnemyPlanet(eid, spec) {
    var E = EMPIRES[eid], tier = spec[5], isCap = tier === 5;
    // Les empires plus puissants alignent plus d'unités (×1 à ×3) : le multiplicateur de stats reste raisonnable
    // et le combat se déroule en plusieurs vagues de 3 ennemis maximum (voir battleSpec).
    var mult = 1 + (E.powerLevel - 1) * 0.5;
    var fleet = FLEET_BY_TIER[tier].map(function (g) { return { unit: E.units[g[0]].id, count: Math.max(1, Math.round(g[1] * mult)) }; });
    var rec = Math.round(E.recRange[0] + (E.recRange[1] - E.recRange[0]) * (tier - 1) / 4);
    var basePower = fleetPower(fleet, 1);
    var scale = Math.max(0.6, powerForRec(rec) / basePower);
    scale = Math.round(scale * 100) / 100;
    var fleetP = fleetPower(fleet, scale);
    var threat = (E.powerLevel - 1) * 5 + tier;
    var ds = E.defenseStyle;
    var shield = Math.round(500 * (1 + threat * 0.45) * ds.shieldMult / 10) * 10;
    var turrets = 1 + tier + (E.powerLevel > 2 ? 1 : 0);
    var deposits = {};
    E.resources.forEach(function (rid, i) {
      var m = (i === 0 ? 1.0 : 0.65) * (1 + threat * 0.22) * (isCap ? 1.6 : 1);
      var v = BASE_DEPOSIT[rid] * m;
      deposits[rid] = rid === 'core' ? Math.round(v * 10) / 10 : Math.round(v);
    });
    var rewards = { xp: Math.round(24 * (1 + rec * 0.2) * (isCap ? 2.2 : 1)), fragments: Math.max(2, Math.round((2 + tier * 1.2) * (isCap ? 1.8 : 1))), first: {} };
    ['crystal', 'metal', 'energy', 'dust'].forEach(function (rid) {
      var focus = E.resources.indexOf(rid) >= 0 ? 1.5 : 0.6;
      rewards[rid] = Math.round(BASE_LOOT[rid] * (1 + rec * 0.35) * focus * (isCap ? 2.2 : 1) * (0.9 + tier * 0.05));
    });
    if (E.resources.indexOf('core') >= 0 || isCap) rewards.core = Math.max(1, Math.round((tier >= 3 ? 1 : 0.5) * (1 + E.powerLevel) * (isCap ? 2.5 : 1)));
    rewards.first[isCap ? 'core' : 'crystal'] = isCap ? 5 + E.powerLevel * 3 : Math.round(300 * (1 + rec * 0.4));
    return {
      id: spec[0], name: spec[1], sector: E.sector, empire: eid, kind: 'enemy', type: spec[2], x: spec[3], y: spec[4],
      r: isCap ? 58 : 34 + tier * 3, tier: tier, isCapital: isCap, desc: spec[6],
      defense: { shield: shield, shieldName: ds.shield, turrets: turrets, turretName: ds.turret, fleet: fleet, trait: E.trait },
      deposits: deposits, rewards: rewards, threat: threat, scale: scale,
      power: Math.round(fleetP + shield / 10 + turrets * 25 * ds.turretMult),
      recLevel: recFromPower(fleetP),
      scan: { cost: { energy: 10 + threat * 6 }, durationMs: Math.round((4 + threat * 0.8) * 1000) }
    };
  }

  function buildNeutralPlanet(spec) {
    var tier = spec[5], fleet = NEUTRAL_FLEETS[tier] || NEUTRAL_FLEETS[1];
    return {
      id: spec[0], name: spec[1], sector: 's1', empire: null, kind: 'neutral', type: spec[2], x: spec[3], y: spec[4],
      r: 30 + tier * 3, tier: tier, isCapital: false, desc: spec[6],
      defense: { shield: 200 * tier, shieldName: 'Champ de dérive', turrets: tier, turretName: 'Tourelle rouillée', fleet: fleet, trait: { name: 'Épaves piégées', text: 'Quelques défenses automatiques encore actives.' } },
      deposits: { dust: 80 * tier, metal: 40 * tier }, rewards: { crystal: 40 * tier, metal: 30 * tier, energy: 12 * tier, dust: 70 * tier, xp: 14 * tier, fragments: 1 + tier, first: { crystal: 120 * tier } },
      threat: tier * 0.5, scale: 1, power: 0, recLevel: 1,
      scan: { cost: { energy: 10 + tier * 4 }, durationMs: (3 + tier) * 1000 }
    };
  }

  var PLANETS = [HOME];
  SPEC_NEUTRAL.forEach(function (s) { PLANETS.push(buildNeutralPlanet(s)); });
  EMPIRE_ORDER.forEach(function (eid) { SPEC_EMPIRE[eid].forEach(function (s) { PLANETS.push(buildEnemyPlanet(eid, s)); }); });
  PLANETS.forEach(function (p) {
    if (p.kind === 'neutral') { p.power = Math.round(fleetPower(p.defense.fleet, 1) + p.defense.shield / 10 + p.defense.turrets * 25); p.recLevel = recFromPower(fleetPower(p.defense.fleet, 1)); }
  });

  var PLANET_INDEX = {}, SECTOR_INDEX = {};
  PLANETS.forEach(function (p) { PLANET_INDEX[p.id] = p; });
  SECTORS.forEach(function (s) { SECTOR_INDEX[s.id] = s; s.planets = PLANETS.filter(function (p) { return p.sector === s.id; }).map(function (p) { return p.id; }); });

  function planet(id) { return PLANET_INDEX[id] || null; }
  function sector(id) { return SECTOR_INDEX[id] || null; }
  function empire(id) { return EMPIRES[id] || null; }
  function planetsOf(sectorId) { return (sector(sectorId) ? sector(sectorId).planets : []).map(planet); }
  function planetsOfEmpire(eid) { return PLANETS.filter(function (p) { return p.empire === eid; }); }
  function neighbors(pid) {
    var out = [];
    LANES.forEach(function (l) { if (l.a === pid) out.push(l.b); else if (l.b === pid) out.push(l.a); });
    return out;
  }
  function empirePower(eid) { return planetsOfEmpire(eid).reduce(function (s, p) { return s + p.power; }, 0); }
  function empireUnits(eid) { return EMPIRES[eid] ? EMPIRES[eid].units.slice() : []; }

  /**
   * Description de combat d'une planète pour le futur module d'invasion : vagues de 3 unités maximum
   * (l'arène du module Combat accepte 1 à 3 ennemis), échelle de stats, récompenses.
   */
  function battleSpec(pid) {
    var p = planet(pid);
    if (!p || !p.defense) return null;
    var list = [];
    p.defense.fleet.forEach(function (g) { var d = unitDef(g.unit); if (d) for (var i = 0; i < g.count; i++) list.push(d); });
    var waves = [];
    for (var i = 0; i < list.length; i += 3) waves.push(list.slice(i, i + 3));
    return { planetId: p.id, empire: p.empire, waves: waves, scale: p.scale, recLevel: p.recLevel, rewards: p.rewards, shield: p.defense.shield, turrets: p.defense.turrets, trait: p.defense.trait };
  }

  // ---------- Sauvegarde : validation de l'état `galaxy` ----------
  function defaultState() { return { unlocked: { s1: true }, scans: {}, jobs: {}, visited: {}, conquered: {}, view: null, colonyAt: 0, stats: { scans: 0, unlocks: 0 } }; }
  function fin(x, min, max, def) { x = Number(x); return isFinite(x) ? Math.min(max, Math.max(min, x)) : def; }
  function normalizeState(raw, now) {
    var s = defaultState();
    if (!raw || typeof raw !== 'object') return s;
    now = now || Date.now();
    var ru = raw.unlocked || {};
    SECTORS.forEach(function (sec) { if (ru[sec.id] === true) s.unlocked[sec.id] = true; });
    s.unlocked.s1 = true;
    ['scans', 'visited', 'conquered'].forEach(function (k) {
      var r = raw[k] || {};
      Object.keys(r).forEach(function (pid) {
        if (!PLANET_INDEX[pid] || PLANET_INDEX[pid].kind === 'home') return;
        if (k === 'scans') { var at = r[pid] && r[pid].at; s[k][pid] = { at: fin(at, 0, now, now) }; }
        else s[k][pid] = fin(r[pid], 0, now, now);
      });
    });
    var rj = raw.jobs || {};
    Object.keys(rj).forEach(function (pid) {
      var j = rj[pid];
      if (!PLANET_INDEX[pid] || !j || PLANET_INDEX[pid].kind === 'home') return;
      var st = fin(j.start, 0, now + 1000, NaN), en = fin(j.end, 0, 1e15, NaN);
      if (isFinite(st) && isFinite(en) && en >= st && en - st <= 10 * 60 * 1000) s.jobs[pid] = { start: st, end: en };
    });
    if (raw.view && typeof raw.view === 'object') {
      var v = { x: fin(raw.view.x, 0, WORLD.w, NaN), y: fin(raw.view.y, 0, WORLD.h, NaN), z: fin(raw.view.z, 0.1, 4, NaN) };
      if (isFinite(v.x) && isFinite(v.y) && isFinite(v.z)) s.view = v;
    }
    s.colonyAt = fin(raw.colonyAt, 0, now, 0);   // dernier versement des revenus des planètes conquises (module Invasions 5C)
    var rs = raw.stats || {};
    s.stats = { scans: Math.floor(fin(rs.scans, 0, 1e9, 0)), unlocks: Math.floor(fin(rs.unlocks, 0, 100, 0)) };
    return s;
  }

  return {
    WORLD: WORLD, SCAN_TTL_MS: SCAN_TTL_MS, RES_IDS: RES_IDS,
    PLANET_TYPES: PLANET_TYPES, EMPIRES: EMPIRES, EMPIRE_ORDER: EMPIRE_ORDER, SECTORS: SECTORS, PLANETS: PLANETS, LANES: LANES,
    planet: planet, sector: sector, empire: empire, planetsOf: planetsOf, planetsOfEmpire: planetsOfEmpire, neighbors: neighbors,
    empirePower: empirePower, empireUnits: empireUnits, unitDef: unitDef, unitPower: unitPower, fleetPower: fleetPower,
    recFromPower: recFromPower, powerForRec: powerForRec, battleSpec: battleSpec,
    defaultState: defaultState, normalizeState: normalizeState
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.Galaxy; }
