/**
 * NEBUSTION - Troops (données pures, testables sous Node)
 * Les « barbares » de NEBUSTION : soldats, vaisseaux et autres unités que le joueur ACHÈTE (Caserne), stocke
 * dans son armée, puis DÉPLOIE à la main autour d'une base ennemie (mode combat, façon Clash of Clans).
 * Une unité déployée est consommée (comme au tir d'un sort) : il faut en racheter pour la prochaine attaque.
 * Elles peuvent aussi être obtenues comme récompenses (Pass de saison) via TroopManager.grant().
 *
 * Coordonnées de combat : unités « cellule » (la grille du QG fait 6×6 → x,y ∈ [0,6]).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Troops = (function () {
  'use strict';

  var BASE_CAPACITY = 12;      // places d'armée sans Hangar
  var CAPACITY_PER_HANGAR = 4; // + places par niveau de Hangar

  // pref : cible préférée ('wall' = murs, 'turret' = tourelles, 'eco' = générateurs/silos, 'core' = cœur du QG, 'any' = la plus proche non-mur)
  var LIST = [
    { id: 'marine', name: 'Marine', icon: '🪖', color: 0x4fe3ff, space: 1, hp: 45, dps: 9, range: 0.55, speed: 1.0, pref: 'any', fly: false,
      cost: { crystal: 40, metal: 25 }, desc: 'Fantassin de base, bon marché. Fonce sur la structure la plus proche.' },
    { id: 'berserker', name: 'Berserker', icon: '🪓', color: 0xff8a3d, space: 2, hp: 110, dps: 17, range: 0.55, speed: 0.9, pref: 'any', fly: false,
      cost: { metal: 90, energy: 40 }, desc: 'Le « barbare » : costaud, corps à corps, casse tout sur son passage.' },
    { id: 'sniper', name: 'Tireur', icon: '🎯', color: 0xb47bff, space: 1, hp: 28, dps: 11, range: 2.3, speed: 1.1, pref: 'any', fly: false,
      cost: { crystal: 60, dust: 60 }, desc: 'Tire de loin, très fragile. Reste derrière les autres.' },
    { id: 'artillery', name: 'Artilleur', icon: '🔫', color: 0x64d2ff, space: 2, hp: 40, dps: 20, range: 2.6, speed: 0.8, pref: 'turret', fly: false,
      cost: { crystal: 90, metal: 60, energy: 50 }, desc: 'Canon lourd à très longue portée : démolit les tourelles avant qu\'elles ne ripostent.' },
    { id: 'ranger', name: 'Éclaireur', icon: '🏃', color: 0x7dffb2, space: 1, hp: 35, dps: 8, range: 0.5, speed: 1.9, pref: 'eco', fly: false,
      cost: { crystal: 35, dust: 45 }, desc: 'Très rapide : file piller les générateurs et les silos.' },
    { id: 'swarm', name: 'Essaim', icon: '🐝', color: 0xffe14f, space: 1, hp: 18, dps: 6, range: 0.6, speed: 2.0, pref: 'eco', fly: true,
      cost: { crystal: 20, energy: 30 }, desc: 'Nuée de micro-drones volants : très rapide, bon marché, pille générateurs et silos.' },
    { id: 'grenadier', name: 'Grenadier', icon: '💥', color: 0xff9f43, space: 2, hp: 45, dps: 26, range: 1.8, speed: 0.95, pref: 'any', fly: false,
      cost: { crystal: 30, metal: 80, energy: 70 }, desc: 'Lance-grenades à moyenne portée : gros dégâts, peu de PV.' },
    { id: 'pyro', name: 'Pyromane', icon: '🔥', color: 0xff6a3d, space: 2, hp: 85, dps: 38, range: 0.7, speed: 0.95, pref: 'any', fly: false,
      cost: { metal: 110, energy: 90, dust: 40 }, desc: 'Lance-flammes : dégâts énormes à courte portée, fait fondre les structures.' },
    { id: 'shield', name: 'Garde-bouclier', icon: '🛡️', color: 0x8fb8ff, space: 3, hp: 320, dps: 9, range: 0.55, speed: 0.8, pref: 'any', fly: false,
      cost: { metal: 150, dust: 100 }, desc: 'Encaisse les tirs des tourelles à la place des autres.' },
    { id: 'breacher', name: 'Casseur', icon: '💣', color: 0xffd166, space: 2, hp: 30, dps: 0, range: 0.3, speed: 1.15, pref: 'wall', fly: false, blast: 190, blastRadius: 1.1,
      cost: { metal: 70, dust: 90 }, desc: 'Se jette sur les barricades et explose : ouvre la voie vers le cœur.' },
    { id: 'sapper', name: 'Saboteur', icon: '🧨', color: 0xff5c8a, space: 3, hp: 55, dps: 0, range: 0.3, speed: 1.05, pref: 'wall', fly: false, blast: 340, blastRadius: 1.5,
      cost: { metal: 110, dust: 150 }, desc: 'Charge lourde : une seule explosion ouvre une brèche large dans les barricades.' },
    { id: 'wraith', name: 'Spectre', icon: '👻', color: 0xc9a0ff, space: 2, hp: 55, dps: 22, range: 0.5, speed: 1.6, pref: 'core', fly: false,
      cost: { crystal: 100, energy: 40, dust: 140 }, desc: 'Assassin : fonce droit sur le cœur du QG (les murs le bloquent).' },
    { id: 'drone', name: 'Vaisseau d\'assaut', icon: '🛸', color: 0x5fd97a, space: 2, hp: 60, dps: 14, range: 1.2, speed: 1.7, pref: 'turret', fly: true,
      cost: { crystal: 110, energy: 70 }, desc: 'Vole au-dessus des barricades et vise les tourelles en premier.' },
    { id: 'bomber', name: 'Bombardier', icon: '🚀', color: 0xff6b6b, space: 4, hp: 90, dps: 32, range: 1.0, speed: 1.3, pref: 'eco', fly: true,
      cost: { crystal: 180, metal: 60, energy: 120 }, desc: 'Vaisseau volant qui pilonne générateurs et silos.' },
    { id: 'gunship', name: 'Canonnière', icon: '🛩️', color: 0x6fd8ff, space: 5, hp: 170, dps: 30, range: 1.8, speed: 1.4, pref: 'turret', fly: true,
      cost: { crystal: 240, metal: 120, energy: 160 }, desc: 'Vaisseau d\'appui rapide et solide : survole les murs et neutralise les tourelles.' },
    { id: 'titan', name: 'Cuirassé Titan', icon: '🤖', color: 0xff6b9a, space: 6, hp: 520, dps: 34, range: 0.9, speed: 0.55, pref: 'turret', fly: false,
      cost: { crystal: 260, metal: 320, energy: 160 }, desc: 'Char lourd très résistant. Détruit les tourelles, lent mais presque indestructible.' },
    { id: 'mecha', name: 'Mécha Golem', icon: '🦾', color: 0xffd0a0, space: 8, hp: 950, dps: 46, range: 0.9, speed: 0.5, pref: 'turret', fly: false,
      cost: { crystal: 420, metal: 520, energy: 260 }, desc: 'Colosse de guerre : écrase les tourelles, quasi indestructible.' },
    { id: 'cruiser', name: 'Croiseur de guerre', icon: '🚢', color: 0xffd166, space: 10, hp: 700, dps: 60, range: 1.6, speed: 1.0, pref: 'any', fly: true,
      cost: { crystal: 600, metal: 450, energy: 400, core: 3 }, desc: 'Vaisseau amiral volant : puissance de feu énorme, coûte des Noyaux.' },
    { id: 'dreadnought', name: 'Dreadnought', icon: '☄️', color: 0xffa0ff, space: 12, hp: 1500, dps: 85, range: 2.0, speed: 0.7, pref: 'any', fly: true,
      cost: { crystal: 900, metal: 700, energy: 600, core: 6 }, desc: 'Forteresse volante : quasi invincible, puissance de feu dévastatrice. Coûte des Noyaux.' },
    { id: 'spawn', name: 'Rejeton', icon: '🧬', color: 0xd77cff, space: 1, hp: 60, dps: 15, range: 0.5, speed: 1.5, pref: 'any', fly: false,
      cost: { crystal: 45, dust: 70 }, desc: 'Créature du Symtor : rapide et vorace. Le Symtor en couve gratuitement (Couvée).' },
    { id: 'raider', name: 'Pillard', icon: '🏴', color: 0xffb347, space: 1, hp: 40, dps: 10, range: 0.5, speed: 1.75, pref: 'eco', fly: false,
      cost: { crystal: 38, dust: 50 }, desc: 'Maraudeur au sol bon marché : file droit sur les générateurs et les silos.' },
    { id: 'infiltrator', name: 'Infiltré', icon: '🥷', color: 0x6ef2c4, space: 3, hp: 140, dps: 26, range: 0.6, speed: 1.2, pref: 'core', fly: false,
      cost: { crystal: 150, metal: 80, energy: 60 }, desc: 'Commando lourd : encaisse les tirs en fonçant vers le cœur (les murs le ralentissent).' },
    { id: 'seraph', name: 'Séraphin', icon: '👼', color: 0xfff2b0, space: 6, hp: 260, dps: 42, range: 1.4, speed: 1.5, pref: 'turret', fly: true,
      cost: { crystal: 280, metal: 140, energy: 190 }, desc: 'Vaisseau de soutien volant : robuste et précis, neutralise les tourelles à distance.' },
    // ---------- Troupes rares (coûtent des Noyaux antiques) ----------
    { id: 'leviathan', name: 'Léviathan', icon: '🐋', color: 0x2ee6b8, space: 14, hp: 2400, dps: 95, range: 1.1, speed: 0.45, pref: 'any', fly: false,
      cost: { crystal: 500, metal: 700, energy: 400, core: 10 }, desc: 'Colosse légendaire : encaisse et détruit presque tout, très lent. La plus grosse réserve de PV du jeu.' },
    { id: 'reaper', name: 'Faucheuse Impériale', icon: '👑', color: 0xffe14f, space: 7, hp: 260, dps: 110, range: 0.65, speed: 2.1, pref: 'core', fly: true,
      cost: { crystal: 420, energy: 260, dust: 200, core: 12 }, desc: 'Assassin volant d\'élite : file droit au cœur du QG, dégâts dévastateurs mais fragile.' },
    { id: 'voidbomb', name: 'Bombe du Néant', icon: '🌌', color: 0x9a5cff, space: 5, hp: 70, dps: 0, range: 0.3, speed: 0.9, pref: 'wall', fly: false, blast: 900, blastRadius: 2.2,
      cost: { metal: 260, dust: 340, core: 8 }, desc: 'Charge rare à antimatière : explosion massive à large rayon, ouvre une brèche énorme.' },
    { id: 'phoenix', name: 'Phénix Stellaire', icon: '🔥🦅', color: 0xff9a4f, space: 9, hp: 900, dps: 70, range: 1.3, speed: 1.0, pref: 'any', fly: true,
      cost: { crystal: 550, metal: 400, energy: 450, core: 9 }, desc: 'Croiseur volant légendaire tout-terrain : puissance et robustesse équilibrées, cible la structure la plus proche.' }
  ];
  var INDEX = {};
  LIST.forEach(function (t) { INDEX[t.id] = t; t.hex = '#' + ('000000' + t.color.toString(16)).slice(-6); });
  var ORDER = LIST.map(function (t) { return t.id; });

  var START_STOCK = { marine: 6, berserker: 2 };   // armée de départ offerte (pour pouvoir essayer le combat)

  // Progression des troupes : 3 branches indépendantes, 10 rangs chacune.
  // Assaut = dégâts, Blindage = PV, Propulsion = vitesse + portée. Les bonus sont
  // calculés au combat, à l'achat et dans tous les écrans via TroopManager.stats().
  var UPGRADE_BRANCHES = {
    assault: { id: 'assault', name: 'Assaut', icon: '⚔️', color: 0xff6b6b, max: 10, desc: '+7 % DPS par rang' },
    armor: { id: 'armor', name: 'Blindage', icon: '🛡️', color: 0x64d2ff, max: 10, desc: '+8 % PV par rang' },
    mobility: { id: 'mobility', name: 'Propulsion', icon: '⚡', color: 0x7dffb2, max: 10, desc: '+6 % vitesse et +0,05 portée par rang' }
  };
  var UPGRADE_ORDER = ['assault', 'armor', 'mobility'];

  function defaultUpgrades() { return { assault: 0, armor: 0, mobility: 0 }; }
  function normalizeUpgrades(raw) {
    var out = defaultUpgrades();
    raw = raw && typeof raw === 'object' ? raw : {};
    UPGRADE_ORDER.forEach(function (id) { out[id] = int(raw[id], 0, UPGRADE_BRANCHES[id].max, 0); });
    return out;
  }
  function baseStats(id) {
    var t = get(id);
    if (!t) return null;
    return { hp: t.hp, dps: t.dps, speed: t.speed, range: t.range, blast: t.blast || 0, blastRadius: t.blastRadius || 0 };
  }
  function combatStats(id) {
    try {
      if (NEBUSTION.TroopManager && typeof NEBUSTION.TroopManager.stats === 'function') return NEBUSTION.TroopManager.stats(id);
    } catch (e) {}
    return deriveStats(id, defaultUpgrades());
  }
  /** Lit un réglage d'équilibrage depuis l'Atelier créateur (tools/studio.html) s'il est chargé ; sinon la valeur d'origine du jeu. */
  function cfgVal(key, fallback) {
    try {
      if (NEBUSTION.CustomContent && NEBUSTION.CustomContent.GameConfig) {
        var v = NEBUSTION.CustomContent.GameConfig.get(key);
        if (typeof v === 'number' && isFinite(v)) return v;
      }
    } catch (e) {}
    return fallback;
  }
  function deriveStats(id, upgrades) {
    var t = get(id), b = baseStats(id);
    if (!t || !b) return null;
    var u = normalizeUpgrades(upgrades);
    var pAssault = cfgVal('troop_assault_pct', 7) / 100;
    var pArmor = cfgVal('troop_armor_pct', 8) / 100;
    var pSpeed = cfgVal('troop_mobility_speed_pct', 6) / 100;
    var pRange = cfgVal('troop_mobility_range', 0.05);
    b.hp = Math.round(b.hp * (1 + pArmor * u.armor));
    b.dps = Math.round(b.dps * (1 + pAssault * u.assault) * 10) / 10;
    b.speed = Math.round(b.speed * (1 + pSpeed * u.mobility) * 100) / 100;
    b.range = Math.round((b.range + pRange * u.mobility) * 100) / 100;
    if (b.blast) b.blast = Math.round(b.blast * (1 + pAssault * u.assault));
    if (b.blastRadius) b.blastRadius = Math.round((b.blastRadius + pRange * 0.6 * u.mobility) * 100) / 100;
    b.level = 1 + u.assault + u.armor + u.mobility;
    b.upgrades = u;
    return b;
  }

  function get(id) { return Object.prototype.hasOwnProperty.call(INDEX, id) ? INDEX[id] : null; }
  function int(x, min, max, def) { x = Math.floor(Number(x)); return isFinite(x) ? Math.min(max, Math.max(min, x)) : def; }

  /** Capacité d'armée : 12 + 4 / niveau de Hangar + bonus des Casernes du QG (`bonus`, en places). */
  function capacity(hangarLevel, bonus) {
    return BASE_CAPACITY + CAPACITY_PER_HANGAR * int(hangarLevel, 0, 99, 0) + int(bonus, 0, 999, 0);
  }

  function defaultState() { return { stock: JSON.parse(JSON.stringify(START_STOCK)), bought: 0, deployed: 0, upgrades: {} }; }

  function normalizeState(raw) {
    var s = { stock: {}, bought: 0, deployed: 0, upgrades: {} };
    if (!raw || typeof raw !== 'object') return defaultState();
    if (raw.stock && typeof raw.stock === 'object') {
      Object.keys(raw.stock).forEach(function (id) {
        if (!get(id)) return;
        var n = int(raw.stock[id], 0, 9999, 0);
        if (n > 0) s.stock[id] = n;
      });
    }
    s.bought = int(raw.bought, 0, 1e9, 0);
    s.deployed = int(raw.deployed, 0, 1e9, 0);
    if (raw.upgrades && typeof raw.upgrades === 'object') {
      Object.keys(raw.upgrades).forEach(function (id) { if (get(id)) s.upgrades[id] = normalizeUpgrades(raw.upgrades[id]); });
    }
    return s;
  }

  /** Places occupées par l'armée d'un stock. */
  function usedSpace(stock) {
    var n = 0;
    Object.keys(stock || {}).forEach(function (id) { var t = get(id); if (t) n += t.space * (stock[id] || 0); });
    return n;
  }

  /** Coût d'achat de `n` unités. `discount` (0..0.5) = remise des Ateliers d'armement du QG. */
  function cost(id, n, discount) {
    var t = get(id), out = {};
    n = int(n, 1, 999, 1);
    if (!t) return out;
    var k = 1 - Math.min(0.5, Math.max(0, Number(discount) || 0));
    Object.keys(t.cost).forEach(function (r) { out[r] = k === 1 ? t.cost[r] * n : Math.max(1, Math.ceil(t.cost[r] * n * k)); });
    return out;
  }

  return {
    BASE_CAPACITY: BASE_CAPACITY, CAPACITY_PER_HANGAR: CAPACITY_PER_HANGAR, LIST: LIST, ORDER: ORDER, START_STOCK: START_STOCK,
    get: get, capacity: capacity, defaultState: defaultState, normalizeState: normalizeState, usedSpace: usedSpace, cost: cost,
    UPGRADE_BRANCHES: UPGRADE_BRANCHES, UPGRADE_ORDER: UPGRADE_ORDER, defaultUpgrades: defaultUpgrades,
    normalizeUpgrades: normalizeUpgrades, baseStats: baseStats, deriveStats: deriveStats, combatStats: combatStats
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.Troops; }
