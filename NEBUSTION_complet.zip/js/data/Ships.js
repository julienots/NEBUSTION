/**
 * NEBUSTION - Ships (données)
 * Module pur (aucune dépendance à Phaser, testable sous Node comme Heroes.js/Equipment.js).
 *
 * Version réduite (première passe) : les vaisseaux ne combattent pas eux-mêmes (les héros
 * restent les unités de combat) — une flotte de 3 vaisseaux maximum accorde un bonus en
 * POURCENTAGE aux statistiques de toute l'équipe de héros pendant un combat (voir
 * ShipManager.fleetBonus + CombatManager). Chaque classe a un rôle qui détermine quelle
 * statistique elle renforce le plus (synergie simple, extensible plus tard).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Ships = (function () {
  'use strict';

  var FLEET_MAX = 3;

  var RARITY_ORDER = ['commun', 'rare', 'epique', 'legendaire'];
  var RARITIES = {
    commun: { id: 'commun', name: 'Commun', order: 1, hex: '#9aa5c0', color: 0x9aa5c0, mult: 1.0 },
    rare: { id: 'rare', name: 'Rare', order: 2, hex: '#4fd1ff', color: 0x4fd1ff, mult: 1.5 },
    epique: { id: 'epique', name: 'Épique', order: 3, hex: '#b47bff', color: 0xb47bff, mult: 2.2 },
    legendaire: { id: 'legendaire', name: 'Légendaire', order: 4, hex: '#ffd166', color: 0xffd166, mult: 3.2 }
  };

  // Rôle -> statistique principale renforcée (bonus en pourcentage, ex. 0.02 = +2 %).
  var CLASS_LIST = [
    { id: 'intercepteur', name: 'Intercepteur', role: 'assault', stat: 'atk', base: 0.020, desc: 'Vaisseau rapide et offensif : augmente l\'attaque de l\'équipe.' },
    { id: 'corvette', name: 'Corvette', role: 'speed', stat: 'spd', base: 0.020, desc: 'Coque légère : augmente la vitesse de l\'équipe.' },
    { id: 'cuirasse', name: 'Cuirassé', role: 'tank', stat: 'def', base: 0.020, desc: 'Blindage lourd : augmente la défense de l\'équipe.' },
    { id: 'porte_vaisseaux', name: 'Porte-vaisseaux', role: 'support', stat: 'hp', base: 0.020, desc: 'Support logistique : augmente les PV de l\'équipe.' }
  ];
  var CLASS_INDEX = {};
  CLASS_LIST.forEach(function (c) { CLASS_INDEX[c.id] = c; });
  var CLASS_ORDER = CLASS_LIST.map(function (c) { return c.id; });

  var MAX_LEVEL = 10;
  var LEVEL_GROWTH = 1.10; // +10 % de bonus par niveau

  function lvl(l) { l = Math.floor(Number(l)); return (isFinite(l) && l >= 1) ? Math.min(l, MAX_LEVEL) : 1; }

  /** Bonus en pourcentage {stat: pct} d'un vaisseau donné (classe + rareté + niveau). */
  function bonusFor(classId, rarityId, level) {
    var cls = CLASS_INDEX[classId];
    if (!cls) return {};
    var rarity = RARITIES[rarityId] || RARITIES.commun;
    var growth = Math.pow(LEVEL_GROWTH, lvl(level) - 1);
    var out = {};
    out[cls.stat] = Math.round(cls.base * rarity.mult * growth * 10000) / 10000;
    return out;
  }

  // Puissance d'ATTAQUE (nombre absolu, pas un %) d'un vaisseau engagé contre un QG ennemi (module 17,
  // QGAttack.js) : toutes les classes contribuent à parts égales (le rôle ne différencie que le bonus
  // en % accordé aux héros ci-dessus), seules rareté et niveau la font grandir.
  var ATTACK_BASE = 6;
  function attackPower(classId, rarityId, level) {
    if (CLASS_ORDER.indexOf(classId) < 0) return 0;
    var rarity = RARITIES[rarityId] || RARITIES.commun;
    var growth = Math.pow(LEVEL_GROWTH, lvl(level) - 1);
    return Math.round(ATTACK_BASE * rarity.mult * growth * 100) / 100;
  }

  function acquireCost(rarityId) {
    var rarity = RARITIES[rarityId] || RARITIES.commun;
    return { crystal: 80 * rarity.order, energy: 40 * rarity.order };
  }

  function upgradeCost(rarityId, level) {
    var rarity = RARITIES[rarityId] || RARITIES.commun;
    var l = lvl(level);
    var base = 55 * rarity.order;
    return { crystal: Math.round(base * Math.pow(1.35, l - 1)), energy: Math.round(base * 0.5 * Math.pow(1.35, l - 1)) };
  }

  function shipName(classId, rarityId) {
    return RARITIES[rarityId].name + ' — ' + CLASS_INDEX[classId].name;
  }

  // ---------- État de sauvegarde (pur, comme Equipment.defaultState/normalizeState) ----------
  function defaultState() {
    return { ships: {}, fleet: [], nextSeq: 1 };
  }

  function num(x, min, max, def) { x = Number(x); return isFinite(x) ? Math.min(max, Math.max(min, x)) : def; }

  function normalizeState(raw) {
    var s = defaultState();
    if (!raw || typeof raw !== 'object') return s;

    s.nextSeq = Math.max(1, num(raw.nextSeq, 1, 1e9, 1));

    var rs = raw.ships || {};
    Object.keys(rs).forEach(function (uid) {
      var sh = rs[uid];
      if (!sh || !CLASS_INDEX[sh.classId] || !RARITIES[sh.rarity]) return;
      s.ships[uid] = { classId: sh.classId, rarity: sh.rarity, level: Math.floor(num(sh.level, 1, MAX_LEVEL, 1)) };
    });

    var rf = Array.isArray(raw.fleet) ? raw.fleet : [];
    var seen = {};
    s.fleet = rf.filter(function (uid) {
      if (typeof uid !== 'string' || !s.ships[uid] || seen[uid]) return false;
      seen[uid] = true; return true;
    }).slice(0, FLEET_MAX);

    return s;
  }

  return {
    FLEET_MAX: FLEET_MAX,
    RARITY_ORDER: RARITY_ORDER, RARITIES: RARITIES,
    CLASS_LIST: CLASS_LIST, CLASS_INDEX: CLASS_INDEX, CLASS_ORDER: CLASS_ORDER,
    MAX_LEVEL: MAX_LEVEL, LEVEL_GROWTH: LEVEL_GROWTH,
    bonusFor: bonusFor, attackPower: attackPower, acquireCost: acquireCost, upgradeCost: upgradeCost, shipName: shipName,
    defaultState: defaultState, normalizeState: normalizeState
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.Ships; }
