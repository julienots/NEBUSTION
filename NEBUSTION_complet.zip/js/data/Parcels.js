/**
 * NEBUSTION - Parcels
 * PARCELLES à acheter sur les planètes. La surface est découpée en cases de longitude/latitude, donc chaque
 * parcelle épouse la COURBURE de la planète (ses bords sont des méridiens et des parallèles, pas des carrés plats).
 * Pour garder des parcelles de taille comparable, le nombre de cases par bande diminue vers les pôles
 * (18 à l'équateur, 6 près des pôles) : ~104 parcelles par monde solide.
 *
 * Règles (données pures, aucune dépendance à Phaser — testables sous Node) :
 *  - Nexus-01 : on ne peut CONSTRUIRE (constructions libres) que sur ses parcelles. Un territoire de départ est offert
 *    (autour de la base) et toute construction déjà posée garde sa parcelle (aucune perte pour les anciennes parties).
 *  - Mondes de la Nouvelle Galaxie (Pyros, Aqualis, Rubéa, Glacia) : aucune parcelle au départ ; chaque parcelle
 *    possédée donne +1 % de production à la colonie de ce monde. Les géantes gazeuses n'ont pas de sol : pas de parcelles.
 *  - Une parcelle s'achète si elle touche (par un bord) une parcelle déjà possédée ; sur un monde sans parcelle, la
 *    première peut être choisie n'importe où (« site d'atterrissage »).
 *  - Prix croissant : base × (1 + 0,10·n + 0,004·n²), n = parcelles déjà ACHETÉES sur ce monde (les offertes ne comptent pas).
 *
 * État sauvegardé : state.parcels = { v:1, worlds:{ nexus:{ owned:['p4_9', ...], paid:n }, pyros:{...}, ... } }
 * Équilibrage : tout se règle dans WORLDS et les constantes ci-dessous.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Parcels = (function () {
  'use strict';

  var BAND_DEG = 20;            // hauteur d'une bande de latitude
  var LAT_MAX = 80;             // pas de parcelles sur les calottes polaires (au-delà de ±80°)
  var TARGET_W = 20;            // largeur visée (en degrés de surface) d'une parcelle
  var NB = (2 * LAT_MAX) / BAND_DEG;   // 8 bandes
  var PRICE_LIN = 0.10, PRICE_QUAD = 0.004;
  var COLONY_BONUS_EACH = 0.01; // +1 % de production de colonie par parcelle possédée (mondes de la Nouvelle Galaxie)
  var START_RADIUS = 36;        // Nexus-01 : parcelles offertes dont le centre est à moins de 36° du cœur de la base
  var START_CENTER = { lon: 0, lat: 8 };
  var BAND_LETTERS = 'ABCDEFGH';   // A = bande la plus au nord

  // res : ressources du prix de base (1re parcelle). solid:false = géante gazeuse, pas de sol.
  var WORLDS = {
    nexus:    { id: 'nexus',    name: 'Nexus-01', solid: true,  price: { crystal: 180, metal: 120 },  use: 'build' },
    pyros:    { id: 'pyros',    name: 'Pyros',    solid: true,  price: { metal: 420, energy: 260 },   use: 'colony' },
    aqualis:  { id: 'aqualis',  name: 'Aqualis',  solid: true,  price: { crystal: 420, dust: 320 },   use: 'colony' },
    rubea:    { id: 'rubea',    name: 'Rubéa',    solid: true,  price: { metal: 400, dust: 360 },     use: 'colony' },
    glacia:   { id: 'glacia',   name: 'Glacia',   solid: true,  price: { crystal: 400, energy: 280 }, use: 'colony' },
    goliath:  { id: 'goliath',  name: 'Goliath',  solid: false, price: {}, use: 'colony' },
    saturnia: { id: 'saturnia', name: 'Saturnia', solid: false, price: {}, use: 'colony' }
  };
  var WORLD_IDS = Object.keys(WORLDS);

  // ---------------------------------------------------------------- grille (identique pour tous les mondes)
  var BANDS = [], CELLS = [], BY_ID = {};
  (function build() {
    var b, i, lat0, lat1, mid, n, w, c;
    for (b = 0; b < NB; b++) {
      lat0 = -LAT_MAX + b * BAND_DEG; lat1 = lat0 + BAND_DEG; mid = (lat0 + lat1) / 2;
      n = Math.max(3, Math.round(360 * Math.cos(mid * Math.PI / 180) / TARGET_W));
      w = 360 / n;
      BANDS.push({ b: b, lat0: lat0, lat1: lat1, n: n, w: w, cells: [] });
      for (i = 0; i < n; i++) {
        c = { id: 'p' + b + '_' + i, b: b, i: i, lon0: -180 + i * w, lon1: -180 + (i + 1) * w, lat0: lat0, lat1: lat1,
          lonC: -180 + (i + 0.5) * w, latC: mid, name: BAND_LETTERS.charAt(NB - 1 - b) + (i + 1), nb: null };
        BANDS[b].cells.push(c); CELLS.push(c); BY_ID[c.id] = c;
      }
    }
  })();

  function get(id) { return BY_ID[id] || null; }
  function normLon(lon) { return ((lon + 180) % 360 + 360) % 360 - 180; }

  /** Parcelle qui contient le point (longitude, latitude en degrés) ; null au-delà de ±80° ou si non numérique. */
  function cellAt(lon, lat) {
    lon = Number(lon); lat = Number(lat);
    if (!isFinite(lon) || !isFinite(lat) || Math.abs(lat) > LAT_MAX) return null;
    var b = Math.min(NB - 1, Math.max(0, Math.floor((lat + LAT_MAX) / BAND_DEG)));
    var band = BANDS[b], i = Math.min(band.n - 1, Math.floor((normLon(lon) + 180) / band.w));
    return band.cells[i];
  }

  /** Parcelles voisines (qui partagent un bord) : mêmes bandes ±1 case (bouclage à 360°), bandes voisines si les longitudes se recouvrent. */
  function neighbors(cell) {
    if (cell.nb) return cell.nb;
    var out = [], band = BANDS[cell.b], n = band.n, bb, k, o;
    out.push(band.cells[(cell.i + n - 1) % n]);
    if (n > 2) out.push(band.cells[(cell.i + 1) % n]);
    [cell.b - 1, cell.b + 1].forEach(function (nbIdx) {
      if (nbIdx < 0 || nbIdx >= NB) return;
      bb = BANDS[nbIdx];
      for (k = 0; k < bb.n; k++) {
        o = bb.cells[k];
        if (Math.min(cell.lon1, o.lon1) - Math.max(cell.lon0, o.lon0) > 1e-6) out.push(o);
      }
    });
    cell.nb = out;
    return out;
  }

  /** Vecteur unitaire d'un point (lon, lat) : même convention que PlanetScene._projectSphere (x droite, y haut, z vers nous à rotation 0). */
  function unit(lonDeg, latDeg) {
    var lo = lonDeg * Math.PI / 180, la = latDeg * Math.PI / 180, cl = Math.cos(la);
    return [cl * Math.sin(lo), Math.sin(la), cl * Math.cos(lo)];
  }

  /**
   * Contour d'une parcelle pour le dessin : points (vecteurs unitaires) le long des méridiens et des parallèles, assez
   * nombreux pour que les bords SUIVENT la courbure une fois projetés. Renvoie { center:[x,y,z], ring:[[x,y,z],...] }. Mis en cache.
   */
  function mesh(cell) {
    if (cell.mesh) return cell.mesh;
    var w = cell.lon1 - cell.lon0, h = cell.lat1 - cell.lat0;
    var N = Math.max(2, Math.ceil(w / 7)), M = Math.max(2, Math.ceil(h / 7)), ring = [], k;
    for (k = 0; k < N; k++) ring.push(unit(cell.lon0 + w * k / N, cell.lat1));        // bord nord, d'ouest en est
    for (k = 0; k < M; k++) ring.push(unit(cell.lon1, cell.lat1 - h * k / M));        // bord est, du nord au sud
    for (k = 0; k < N; k++) ring.push(unit(cell.lon1 - w * k / N, cell.lat0));        // bord sud, d'est en ouest
    for (k = 0; k < M; k++) ring.push(unit(cell.lon0, cell.lat0 + h * k / M));        // bord ouest, du sud au nord
    cell.mesh = { center: unit(cell.lonC, cell.latC), ring: ring };
    return cell.mesh;
  }

  /** Distance angulaire (degrés) entre deux points lon/lat. */
  function angDist(lon1, lat1, lon2, lat2) {
    var r = Math.PI / 180, a = lat1 * r, b = lat2 * r, dl = (lon1 - lon2) * r;
    var d = Math.sin(a) * Math.sin(b) + Math.cos(a) * Math.cos(b) * Math.cos(dl);
    return Math.acos(d < -1 ? -1 : (d > 1 ? 1 : d)) / r;
  }

  // ---------------------------------------------------------------- territoire de départ de Nexus-01
  var FALLBACK_ANCHORS = [   // à garder cohérent avec NEBUSTION.PlanetLayout (PlanetScene.js) ; ce dernier est préféré s'il est chargé
    [-34, 34], [34, 34], [0, 44], [0, 2], [-46, 6], [46, 6], [-42, -30], [42, -30],
    [-78, 10], [78, 10], [-66, -46], [66, -46], [0, -58]
  ];
  function baseAnchors() {
    var L = NEBUSTION.PlanetLayout, out = [];
    if (L && L.buildings && L.nodes) {
      L.buildings.forEach(function (b) { out.push([b.lonDeg, b.latDeg]); });
      Object.keys(L.nodes).forEach(function (k) { out.push([L.nodes[k].lonDeg, L.nodes[k].latDeg]); });
      return out;
    }
    return FALLBACK_ANCHORS;
  }
  /**
   * Parcelles offertes sur Nexus-01 : celles des bâtiments/gisements d'origine + celles proches du cœur de la base, puis reliées
   * entre elles par le plus court chemin (le territoire de départ est d'un seul bloc, sans parcelle isolée).
   */
  function startCells() {
    var set = {}, out = [];
    baseAnchors().forEach(function (a) { var c = cellAt(a[0], a[1]); if (c) set[c.id] = true; });
    CELLS.forEach(function (c) { if (angDist(c.lonC, c.latC, START_CENTER.lon, START_CENTER.lat) <= START_RADIUS) set[c.id] = true; });
    // Relier les morceaux : tant qu'il y a plusieurs blocs, on ajoute le plus court chemin du bloc principal vers un autre.
    var guard = 0;
    while (guard++ < 60) {
      var main = {}, queue = [], first = null;
      CELLS.forEach(function (c) { if (!first && set[c.id]) first = c; });
      if (!first) break;
      main[first.id] = true; queue.push(first);
      for (var q = 0; q < queue.length; q++) {
        neighbors(queue[q]).forEach(function (o) { if (set[o.id] && !main[o.id]) { main[o.id] = true; queue.push(o); } });
      }
      var rest = CELLS.filter(function (c) { return set[c.id] && !main[c.id]; });
      if (!rest.length) break;
      // BFS depuis tout le bloc principal à travers n'importe quelle parcelle, jusqu'à toucher un autre bloc.
      var prev = {}, seen = {}, fr = [], hit = null;
      Object.keys(main).forEach(function (id) { seen[id] = true; fr.push(BY_ID[id]); });
      for (var h = 0; h < fr.length && !hit; h++) {
        var nb = neighbors(fr[h]);
        for (var m = 0; m < nb.length; m++) {
          var o = nb[m]; if (seen[o.id]) continue;
          seen[o.id] = true; prev[o.id] = fr[h].id; fr.push(o);
          if (set[o.id]) { hit = o; break; }
        }
      }
      if (!hit) break;
      for (var cur = prev[hit.id]; cur && !main[cur]; cur = prev[cur]) set[cur] = true;
    }
    CELLS.forEach(function (c) { if (set[c.id]) out.push(c.id); });
    return out;
  }

  // ---------------------------------------------------------------- état
  function defaultState() { return { v: 1, worlds: {} }; }

  function worldEntry(state, wid) {
    if (!state.worlds) state.worlds = {};
    var w = state.worlds[wid];
    if (!w || !Array.isArray(w.owned)) w = state.worlds[wid] = { owned: [], paid: 0 };
    return w;
  }

  /**
   * Nettoie une sauvegarde : mondes/identifiants inconnus retirés, doublons écartés, 'paid' borné. Nexus-01 reçoit toujours son
   * territoire de départ ET les parcelles de toutes les constructions déjà posées (`planetBuild`) : rien n'est jamais perdu.
   */
  function normalizeState(raw, planetBuild) {
    var s = defaultState();
    WORLD_IDS.forEach(function (wid) {
      if (!WORLDS[wid].solid) return;
      var rw = raw && typeof raw === 'object' && raw.worlds && typeof raw.worlds === 'object' ? raw.worlds[wid] : null;
      var e = s.worlds[wid] = { owned: [], paid: 0 }, seen = {};
      if (rw && Array.isArray(rw.owned)) {
        rw.owned.forEach(function (id) { id = String(id); if (BY_ID[id] && !seen[id]) { seen[id] = true; e.owned.push(id); } });
        var p = Math.floor(Number(rw.paid)); e.paid = isFinite(p) ? Math.max(0, Math.min(CELLS.length, p)) : 0;
      }
      if (wid === 'nexus') {
        startCells().forEach(function (id) { if (!seen[id]) { seen[id] = true; e.owned.push(id); } });
        if (planetBuild && Array.isArray(planetBuild.items)) {
          planetBuild.items.forEach(function (it) {
            var c = it ? cellAt(it.lon, it.lat) : null;
            if (c && !seen[c.id]) { seen[c.id] = true; e.owned.push(c.id); }
          });
        }
      }
    });
    return s;
  }

  function isOwned(state, wid, cellId) {
    var w = state && state.worlds && state.worlds[wid];
    return !!(w && w.owned.indexOf(cellId) >= 0);
  }
  function ownedList(state, wid) { var w = state && state.worlds && state.worlds[wid]; return w ? w.owned : []; }
  function ownedCount(state, wid) { return ownedList(state, wid).length; }
  function paidCount(state, wid) { var w = state && state.worlds && state.worlds[wid]; return w ? w.paid : 0; }
  function totalCells() { return CELLS.length; }

  /** Peut-on construire au point (lon, lat) de ce monde ? Oui seulement sur une parcelle possédée. */
  function canBuild(state, wid, lon, lat) {
    var c = cellAt(lon, lat);
    return !!c && isOwned(state, wid, c.id);
  }

  /** Une parcelle est-elle achetable (solide, non possédée, voisine d'une possédée — ou n'importe où si le monde est vierge) ? */
  function isBuyable(state, wid, cellId) {
    var def = WORLDS[wid], c = BY_ID[cellId];
    if (!def || !def.solid || !c || isOwned(state, wid, cellId)) return false;
    if (ownedCount(state, wid) === 0) return true;
    return neighbors(c).some(function (nb) { return isOwned(state, wid, nb.id); });
  }

  /** Coût de la prochaine parcelle quand `paid` ont déjà été achetées sur ce monde. */
  function price(wid, paid) {
    var def = WORLDS[wid], out = {};
    if (!def || !def.solid) return out;
    paid = Math.max(0, paid | 0);
    var mult = 1 + PRICE_LIN * paid + PRICE_QUAD * paid * paid;
    Object.keys(def.price).forEach(function (rid) { out[rid] = Math.ceil(def.price[rid] * mult); });
    return out;
  }

  /** Bonus de production de la colonie d'un monde (0,05 = +5 %) apporté par ses parcelles. */
  function colonyBonus(state, wid) {
    var def = WORLDS[wid];
    if (!def || !def.solid || def.use !== 'colony') return 0;
    return ownedCount(state, wid) * COLONY_BONUS_EACH;
  }

  /** Achète une parcelle (tout ou rien). R = NEBUSTION.Resources. */
  function buy(R, wid, cellId) {
    var def = WORLDS[wid], c = BY_ID[cellId];
    if (!def) return { ok: false, reason: 'monde' };
    if (!def.solid) return { ok: false, reason: 'gaz' };
    if (!c) return { ok: false, reason: 'inconnue' };
    if (!R.state.parcels || !R.state.parcels.worlds) R.state.parcels = normalizeState(R.state.parcels, R.state.planetBuild);
    var st = R.state.parcels;
    if (isOwned(st, wid, cellId)) return { ok: false, reason: 'possedee' };
    if (!isBuyable(st, wid, cellId)) return { ok: false, reason: 'loin' };
    var e = worldEntry(st, wid), cost = price(wid, e.paid);
    if (!R.canAfford(cost) || R.spendMany(cost) === false) return { ok: false, reason: 'cost', cost: cost };
    e.owned.push(cellId); e.paid++;
    R._rates = null;
    try { R.saveNow(Date.now()); } catch (err) { /* le jeu continue en mémoire */ }
    return { ok: true, cost: cost, cell: c };
  }

  return {
    WORLDS: WORLDS, WORLD_IDS: WORLD_IDS, BANDS: BANDS, CELLS: CELLS, NB: NB, COLONY_BONUS_EACH: COLONY_BONUS_EACH,
    get: get, cellAt: cellAt, neighbors: neighbors, mesh: mesh, unit: unit, angDist: angDist, normLon: normLon, totalCells: totalCells,
    startCells: startCells, defaultState: defaultState, normalizeState: normalizeState,
    isOwned: isOwned, ownedList: ownedList, ownedCount: ownedCount, paidCount: paidCount,
    canBuild: canBuild, isBuyable: isBuyable, price: price, colonyBonus: colonyBonus, buy: buy
  };
})();
