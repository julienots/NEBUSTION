/**
 * NEBUSTION - EmpireEvolution (données + logique pure, sans Phaser, testable sous Node)
 * Module IA 3 : évolution/adaptation des 5 empires dans le temps (ressources, développement, défenses, unités).
 *
 * RÉUTILISE l'existant sans le dupliquer : planètes/empires/flottes = Galaxy.js, posture/effets = EmpireAI.js.
 * N'ajoute qu'UN état persistant `state.empires` (validé par normalizeState, branché dans SaveManager).
 *
 * Modèle (volontairement simple et borné) :
 *  - Chaque empire encaisse des ressources (dépôts de ses planètes NON conquises, /h) par pas de 30 min.
 *  - Il les dépense selon sa posture : développement (evo 0..8), bouclier (0..5), tourelles (0..4),
 *    unités de renfort (0..2 par planète) — coûts croissants, plafonds fixes → jamais infini.
 *  - Plafond de développement lié au niveau d'équipe du joueur (+ difficulté) : un empire ne
 *    s'emballe pas si le joueur est faible, et rattrape à mesure que le joueur progresse.
 *  - Absence longue : au plus 24 h de progression sont rattrapées (aucun gain illimité hors ligne).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.EmpireEvolution = (function () {
  'use strict';

  var G = function () { return NEBUSTION.Galaxy; };
  var D = function () { return NEBUSTION.EmpireDoctrine || null; };   // doctrine/adaptation (facultatif : sans lui, comportement du module 3 initial)

  var STEP_MS = 30 * 60 * 1000;         // un « tour » d'empire
  var MAX_CATCHUP_STEPS = 48;           // 24 h max rattrapées d'un coup
  var MAX_EVO = 8;
  var SH_MAX = 5, TU_MAX = 4;
  var FL_MAX = { 1: 1, 2: 1, 3: 2, 4: 2, 5: 2 };   // unités de renfort max par planète, selon son tier
  var VALUE = { crystal: 1, metal: 1, energy: 1.2, dust: 0.5, core: 120 };   // valeur en « points » (pour payer avec un mélange)
  var CAP_POINTS = 60000;               // plafond de stock par ressource, en points
  var INCOME_EFF = 0.12;                // part des dépôts/h réellement convertie en richesse
  var INCOME_PER_EVO = 0.06;
  var ACTIONS_PER_STEP = 3, ACTIONS_MAX = 4;
  var HURT_DECAY = 0.96, MOM_DECAY = 0.97;   // le traumatisme et l'élan s'estompent (½-vie ≈ 8 h) : jamais permanents
  var CLAIM = { maxPerEmpire: 2, minEvo: 3, cooldownMs: 24 * 3600 * 1000, chanceK: 0.06, cost: 2200, reach: 2, minExpansion: 0.4, rewardMult: 1.1 };
  var SHIELD_STEP = 0.10, SHIELD_TOTAL_CAP = 2.0;   // +10 %/niveau ; bouclier total (posture incluse) ≤ ×2
  var TURRET_TOTAL_CAP = 1.5;
  var SCALE_PER_EVO = 0.01;
  var REWARD_PER_LEVEL = 0.02, REWARD_CAP = 0.25;
  var COST_BASE = { sh: 450, tu: 600, fl: 800, ut: 700 };
  var EVO_COST_BASE = 1500;
  var RECAPTURE = { graceMs: 12 * 3600 * 1000, cooldownMs: 24 * 3600 * 1000, chanceK: 0.04, minEvo: 2, powerGate: 0.85, cost: 2500 };
  // Plafond de développement : evo max = 1 + niveau d'équipe / diviseur (mêmes clés que les difficultés du module Combat)
  var CEIL_DIV = { facile: 8, normal: 6, difficile: 5, cauchemar: 4.5 };
  // Poids de dépense selon la posture décidée par EmpireAI
  var WEIGHTS = {
    defensive: { sh: 1.5, tu: 1.3, fl: 0.8, ut: 1.0, evo: 0.7 },
    offensive: { sh: 0.6, tu: 1.0, fl: 1.6, ut: 1.3, evo: 0.9 },
    balanced:  { sh: 1.0, tu: 0.9, fl: 0.9, ut: 0.9, evo: 1.3 }
  };

  function fin(x, min, max, def) { x = Number(x); return isFinite(x) ? Math.min(max, Math.max(min, x)) : def; }
  function int(x, min, max, def) { return Math.floor(fin(x, min, max, def)); }
  function r2(x) { return Math.round(x * 100) / 100; }
  function r4(x) { return Math.round(x * 10000) / 10000; }   // mémoire (hurt/mom) : 4 décimales, sinon l'arrondi bloque la décroissance

  // ---------- Plafonds / coûts ----------
  function capRes(rid) { return CAP_POINTS / (VALUE[rid] || 1); }
  // eid (facultatif) : plafond propre à l'empire (EmpireDoctrine.STYLE.max), toujours ≤ plafond global
  function sm(eid, kind, g) { return (eid && D()) ? Math.min(g, D().styleMax(eid, kind, g)) : g; }
  function shMax(evo, eid) { return Math.min(sm(eid, 'sh', SH_MAX), evo); }
  function tuMax(evo, eid) { return Math.min(sm(eid, 'tu', TU_MAX), Math.ceil(evo / 2)); }
  function flMax(evo, tier, eid) { return Math.min(FL_MAX[tier] || 1, sm(eid, 'fl', 2), Math.floor(evo / 2)); }
  function ceilingFor(teamLevel, difficultyId) {
    var d = CEIL_DIV[difficultyId] || CEIL_DIV.normal;
    return Math.max(1, Math.min(MAX_EVO, 1 + Math.floor((Number(teamLevel) || 1) / d)));
  }
  function rkMax(evo) { return D() ? D().rankMax(evo) : 0; }
  function upgradeCost(kind, level, threat) { return Math.round(COST_BASE[kind] * (1 + 0.15 * (threat || 0)) * Math.pow(1.5, level)); }
  function evoCost(evo, powerLevel) { return Math.round(EVO_COST_BASE * (1 + 0.1 * ((powerLevel || 1) - 1)) * Math.pow(1.55, evo)); }
  function recaptureCost(threat) { return Math.round(RECAPTURE.cost * (1 + 0.15 * (threat || 0))); }

  function wealth(es, eid) {
    var E = G().empire(eid), w = 0;
    (E ? E.resources : []).forEach(function (rid) { w += (es.res[rid] || 0) * VALUE[rid]; });
    return w;
  }
  /** Paie `cost` points en prélevant la même fraction sur chaque ressource. Tout ou rien. */
  function pay(es, eid, cost) {
    var w = wealth(es, eid);
    if (!(cost > 0) || w + 1e-9 < cost) return false;
    var keep = 1 - cost / w, E = G().empire(eid);
    E.resources.forEach(function (rid) { es.res[rid] = r2((es.res[rid] || 0) * keep); });
    return true;
  }

  // ---------- Aléa déterministe (aucun Math.random : recharger la sauvegarde ne change pas le résultat) ----------
  function rand01(seed, n, salt) {
    var h = (seed ^ Math.imul(n + 1, 0x9E3779B1) ^ Math.imul(salt + 7, 0x85EBCA6B)) >>> 0;
    h = Math.imul(h ^ (h >>> 16), 0x45D9F3B) >>> 0; h = Math.imul(h ^ (h >>> 16), 0x45D9F3B) >>> 0; h = (h ^ (h >>> 16)) >>> 0;
    return h / 4294967296;
  }

  // ---------- État sauvegardé ----------
  function emptyEmpire(eid) {
    var E = G().empire(eid), res = {};
    E.resources.forEach(function (rid) { res[rid] = 0; });
    return { res: res, evo: 0, def: {}, lastRec: 0, rec: 0, spent: 0, ups: 0,
      rank: {}, hurt: 0, mom: 0, lost: 0, lostAt: {}, held: 0, claims: {}, lastClaim: 0 };
  }
  function defaultState(now) {
    var s = { v: 2, lastAt: now || Date.now(), n: 0, seed: Math.floor(Math.random() * 2147483645) + 1, e: {} };
    G().EMPIRE_ORDER.forEach(function (eid) { s.e[eid] = emptyEmpire(eid); });
    return s;
  }
  /** Reconstruit un état VALIDE (jamais de doublon : tout est indexé par empire puis par planète). */
  function normalizeState(raw, now) {
    now = now || Date.now();
    var s = defaultState(now);
    if (!raw || typeof raw !== 'object') return s;
    s.lastAt = fin(raw.lastAt, 0, now, now);      // date future (horloge modifiée) → maintenant
    s.n = int(raw.n, 0, 1e9, 0);
    s.seed = int(raw.seed, 1, 2147483645, s.seed);
    var re = (raw.e && typeof raw.e === 'object') ? raw.e : {}, claimed = {};
    G().EMPIRE_ORDER.forEach(function (eid) {
      var r = re[eid], o = s.e[eid], E = G().empire(eid);
      if (!r || typeof r !== 'object') return;
      o.evo = int(r.evo, 0, MAX_EVO, 0);
      var rr = r.res || {};
      E.resources.forEach(function (rid) { o.res[rid] = r2(fin(rr[rid], 0, capRes(rid), 0)); });
      var rd = r.def || {};
      Object.keys(rd).forEach(function (pid) {
        var p = G().planet(pid), d = rd[pid];
        if (!p || p.empire !== eid || !d || typeof d !== 'object') return;
        var v = { sh: int(d.sh, 0, shMax(o.evo, eid), 0), tu: int(d.tu, 0, tuMax(o.evo, eid), 0), fl: int(d.fl, 0, flMax(o.evo, p.tier, eid), 0) };
        if (v.sh || v.tu || v.fl) o.def[pid] = v;
      });
      o.lastRec = fin(r.lastRec, 0, now, 0);
      o.rec = int(r.rec, 0, 1e6, 0);
      o.spent = fin(r.spent, 0, 1e15, 0);
      o.ups = int(r.ups, 0, 1e9, 0);
      // --- v2 : mémoire d'adaptation, unités entraînées, revendications (absents d'une v1 → valeurs neuves) ---
      var rk = r.rank && typeof r.rank === 'object' ? r.rank : {};
      E.units.forEach(function (u) { var v = int(rk[u.id], 0, rkMax(o.evo), 0); if (v) o.rank[u.id] = v; });
      o.hurt = r4(fin(r.hurt, 0, 1, 0)); o.mom = r4(fin(r.mom, 0, 1, 0));
      o.lost = int(r.lost, 0, 1e6, 0); o.held = int(r.held, 0, 1e6, 0);
      var la = r.lostAt && typeof r.lostAt === 'object' ? r.lostAt : {};
      Object.keys(la).forEach(function (pid) { var p = G().planet(pid); if (p && p.empire === eid) o.lostAt[pid] = fin(la[pid], 0, now, now); });
      o.lastClaim = fin(r.lastClaim, 0, now, 0);
      var cl = r.claims && typeof r.claims === 'object' ? r.claims : {};
      Object.keys(cl).forEach(function (pid) {
        var p = G().planet(pid);
        if (!p || p.kind !== 'neutral' || claimed[pid] || Object.keys(o.claims).length >= CLAIM.maxPerEmpire) return;   // un monde n'a qu'un revendicateur
        claimed[pid] = eid; o.claims[pid] = fin(cl[pid], 0, now, now);
      });
    });
    return s;
  }

  // ---------- Vue d'une planète après évolution (jamais modifie Galaxy.js) ----------
  function extraUnit(eid, tier) {
    var u = G().empire(eid).units;
    return u[Math.max(0, Math.min(3, tier - 2))];
  }
  function ranked(unitId, es) { var d = G().unitDef(unitId); return (D() && es && es.rank) ? D().rankedDef(d, es.rank[unitId] || 0) : d; }
  function fleetPowerRanked(fleet, scale, es) {
    var p = 0;
    fleet.forEach(function (g) { var d = ranked(g.unit, es); if (d) p += G().unitPower(d.base, scale) * g.count; });
    return p;
  }
  function withRanks(fleet, es) { fleet.forEach(function (g) { g.rank = (es && es.rank && es.rank[g.unit]) || 0; }); return fleet; }
  /**
   * Défense évolutive d'une planète d'empire. `effects` (facultatif) = effets de posture EmpireAI
   * ({shieldMult, turretMult}) appliqués au moment du combat, bornés par SHIELD_TOTAL_CAP/TURRET_TOTAL_CAP.
   */
  function planetView(eid, pid, es, effects) {
    var p = G().planet(pid);
    if (!p || !p.defense || p.empire !== eid) return null;
    var d = (es && es.def && es.def[pid]) || { sh: 0, tu: 0, fl: 0 }, evo = es ? es.evo : 0;
    var ef = effects || {};
    var shMul = Math.min(SHIELD_TOTAL_CAP, (1 + SHIELD_STEP * d.sh) * (ef.shieldMult || 1));
    var tuMul = Math.min(TURRET_TOTAL_CAP, ef.turretMult || 1);
    var shield = Math.round(p.defense.shield * shMul);
    var turrets = Math.round((p.defense.turrets + d.tu) * tuMul);
    var fleet = p.defense.fleet.map(function (g) { return { unit: g.unit, count: g.count }; });
    if (d.fl > 0) {
      var xu = extraUnit(eid, p.tier), hit = fleet.filter(function (g) { return g.unit === xu.id; })[0];
      if (hit) hit.count += d.fl; else fleet.push({ unit: xu.id, count: d.fl });
    }
    var caps = D() ? D().capabilities(eid, evo, es ? es.hurt : 0) : { list: [], bonus: {} };
    var xg = p.isCapital ? Math.floor(caps.bonus.extraGrunt || 0) : 0;      // capacité « production de masse » : renfort de capitale
    if (xg > 0) { var u0 = G().empire(eid).units[0].id, h0 = fleet.filter(function (g) { return g.unit === u0; })[0]; if (h0) h0.count += xg; else fleet.push({ unit: u0, count: xg }); }
    withRanks(fleet, es);
    var scale = r2(p.scale * (1 + SCALE_PER_EVO * evo));
    var fleetP = fleetPowerRanked(fleet, scale, es);
    var ds = G().empire(eid).defenseStyle;
    var lv = d.sh + d.tu + d.fl;
    return {
      planet: pid, empire: eid, shield: shield, turrets: turrets, fleet: fleet, scale: scale,
      power: Math.round(fleetP + shield / 10 + turrets * 25 * ds.turretMult),
      recLevel: G().recFromPower(fleetP), levels: { sh: d.sh, tu: d.tu, fl: d.fl },
      rewardMult: r2(1 + Math.min(REWARD_CAP, REWARD_PER_LEVEL * lv)), capabilities: caps.list, bonus: caps.bonus
    };
  }
  /** Monde NEUTRE revendiqué par un empire : garnison d'avant-poste ajoutée (bornée), le reste est inchangé. */
  function claimView(eid, pid, es) {
    var p = G().planet(pid), E = G().empire(eid);
    if (!p || p.kind !== 'neutral' || !p.defense || !E) return null;
    var fleet = p.defense.fleet.map(function (g) { return { unit: g.unit, count: g.count }; });
    fleet.push({ unit: E.units[0].id, count: (es && es.evo >= 6) ? 2 : 1 });
    withRanks(fleet, es);
    var fleetP = fleetPowerRanked(fleet, p.scale, es);
    return { planet: pid, empire: null, claimedBy: eid, shield: p.defense.shield, turrets: p.defense.turrets, fleet: fleet, scale: p.scale,
      power: Math.round(fleetP + p.defense.shield / 10 + p.defense.turrets * 25), recLevel: G().recFromPower(fleetP),
      levels: { sh: 0, tu: 0, fl: 0 }, rewardMult: CLAIM.rewardMult, capabilities: [], bonus: {} };
  }

  // ---------- Un pas de simulation d'un empire ----------
  function stockRatio(es, E) { var m = 0; E.resources.forEach(function (rid) { m = Math.max(m, (es.res[rid] || 0) / capRes(rid)); }); return m; }
  function decay(x, k) { x = x * k; return x < 0.02 ? 0 : r4(x); }
  /** Unités présentes dans les flottes des planètes possédées (base + renfort) → { unitId: nombre }. */
  function usageOf(es, owned, eid) {
    var use = {};
    owned.forEach(function (o) {
      var p = G().planet(o.id), d = es.def[o.id] || { fl: 0 };
      p.defense.fleet.forEach(function (g) { use[g.unit] = (use[g.unit] || 0) + g.count; });
      if (d.fl > 0) { var xu = extraUnit(eid, p.tier); use[xu.id] = (use[xu.id] || 0) + d.fl; }
    });
    return use;
  }
  /**
   * @param es  état de CET empire (muté)
   * @param ctx {eid, planets:[{id,tier,threat,isCapital,deposits,owned}], posture, reinforceRate,
   *             targets:{planetId: poids}, ceiling, capitalLost, lossRatio?, pressure?}
   * @returns {{income:number, upgrades:[{kind,planet,level,unit?}], focus:string}}
   */
  function stepEmpire(es, ctx) {
    var E = G().empire(ctx.eid), rep = { income: 0, upgrades: [], focus: 'growth' };
    var owned = ctx.planets.filter(function (p) { return p.owned; });
    if (!E || !owned.length) return rep;                       // empire entièrement conquis : plus aucun revenu
    es.hurt = decay(es.hurt || 0, HURT_DECAY); es.mom = decay(es.mom || 0, MOM_DECAY);
    var k = (STEP_MS / 3600000) * INCOME_EFF * (1 + INCOME_PER_EVO * es.evo) *
      (ctx.capitalLost ? 0.5 : 1) * Math.min(2, Math.max(0.5, ctx.reinforceRate || 1));
    owned.forEach(function (p) {
      E.resources.forEach(function (rid) {
        var v = (p.deposits[rid] || 0) * k;
        es.res[rid] = r2(Math.min(capRes(rid), (es.res[rid] || 0) + v));
        rep.income += v * VALUE[rid];
      });
    });
    var W = WEIGHTS[ctx.posture] || WEIGHTS.balanced, Dd = D();
    var style = (Dd && Dd.STYLE[ctx.eid]) || { pref: {}, cost: {}, spread: 0, focus: [] };
    var ad = Dd ? Dd.adaptation({ posture: ctx.posture, lossRatio: ctx.lossRatio, capitalLost: ctx.capitalLost, hurt: es.hurt, pressure: ctx.pressure,
      momentum: es.mom, stockRatio: stockRatio(es, E) }) : { mult: {}, actions: ACTIONS_PER_STEP, focus: 'growth' };
    rep.focus = ad.focus;
    var mul = function (kind) { return (W[kind] || 1) * (style.pref[kind] || 1) * (ad.mult[kind] || 1); };
    var cst = function (kind, base) { return Math.round(base * (style.cost[kind] || 1)); };
    var best = null;
    var consider = function (c) { if (!best || c.score > best.score) best = c; };
    var actions = Math.min(ACTIONS_MAX, Math.max(1, ad.actions || ACTIONS_PER_STEP));
    for (var a = 0; a < actions; a++) {
      best = null;
      if (es.evo < Math.min(MAX_EVO, ctx.ceiling)) {
        consider({ kind: 'evo', planet: null, level: es.evo, cost: cst('evo', evoCost(es.evo, E.powerLevel)), score: mul('evo') / (1 + es.evo * 0.35) });
      }
      // niveau moyen par type : la coordination (spread) favorise les planètes en retard sur la moyenne
      var mean = { sh: 0, tu: 0, fl: 0 };
      owned.forEach(function (p) { var d = es.def[p.id] || {}; mean.sh += d.sh || 0; mean.tu += d.tu || 0; mean.fl += d.fl || 0; });
      ['sh', 'tu', 'fl'].forEach(function (kk) { mean[kk] /= owned.length; });
      var even = function (kk, lvl) { return Math.max(0.5, Math.min(1.5, 1 + (style.spread || 0) * 0.5 * (mean[kk] - lvl))); };
      owned.forEach(function (p) {
        var d = es.def[p.id] || { sh: 0, tu: 0, fl: 0 };
        var pw = (p.isCapital ? 1.35 : 1 + 0.05 * p.tier) * (1 + (ctx.targets[p.id] || 0));
        if (d.sh < shMax(es.evo, ctx.eid)) consider({ kind: 'sh', planet: p.id, level: d.sh, cost: cst('sh', upgradeCost('sh', d.sh, p.threat)), score: mul('sh') * pw * even('sh', d.sh) / (1 + d.sh * 0.35) });
        if (d.tu < tuMax(es.evo, ctx.eid)) consider({ kind: 'tu', planet: p.id, level: d.tu, cost: cst('tu', upgradeCost('tu', d.tu, p.threat)), score: mul('tu') * pw * even('tu', d.tu) / (1 + d.tu * 0.35) });
        if (d.fl < flMax(es.evo, p.tier, ctx.eid)) consider({ kind: 'fl', planet: p.id, level: d.fl, cost: cst('fl', upgradeCost('fl', d.fl, p.threat)), score: mul('fl') * pw * even('fl', d.fl) / (1 + d.fl * 0.35) });
      });
      if (Dd && rkMax(es.evo) > 0) {              // entraînement d'une unité (rang) : global à l'empire
        var use = usageOf(es, owned, ctx.eid);
        Object.keys(use).forEach(function (uid) {
          var r = (es.rank && es.rank[uid]) || 0, def = G().unitDef(uid);
          if (r >= rkMax(es.evo) || !def) return;
          var fm = style.focus.indexOf(def.role) >= 0 ? 1.3 : 1;
          consider({ kind: 'ut', planet: null, unit: uid, level: r, cost: cst('ut', upgradeCost('ut', r, E.powerLevel * 2)), score: mul('ut') * fm * (1 + 0.1 * use[uid]) / (1 + r * 0.35) });
        });
      }
      if (!best || !pay(es, ctx.eid, best.cost)) break;        // on met de côté jusqu'à pouvoir payer la meilleure option
      if (best.kind === 'evo') es.evo += 1;
      else if (best.kind === 'ut') { var rk = {}; E.units.forEach(function (un) { var v = un.id === best.unit ? best.level + 1 : ((es.rank && es.rank[un.id]) || 0); if (v) rk[un.id] = v; }); es.rank = rk; }   // ordre canonique (= normalizeState)
      else { var dd = es.def[best.planet] || (es.def[best.planet] = { sh: 0, tu: 0, fl: 0 }); dd[best.kind] += 1; }
      es.spent = Math.min(1e15, es.spent + best.cost); es.ups += 1;
      var u = { kind: best.kind, planet: best.planet, level: best.level + 1 }; if (best.unit) u.unit = best.unit;
      rep.upgrades.push(u);
    }
    return rep;
  }

  return {
    STEP_MS: STEP_MS, MAX_CATCHUP_STEPS: MAX_CATCHUP_STEPS, MAX_EVO: MAX_EVO, SH_MAX: SH_MAX, TU_MAX: TU_MAX, FL_MAX: FL_MAX,
    VALUE: VALUE, CAP_POINTS: CAP_POINTS, RECAPTURE: RECAPTURE, CEIL_DIV: CEIL_DIV, WEIGHTS: WEIGHTS,
    SHIELD_TOTAL_CAP: SHIELD_TOTAL_CAP, TURRET_TOTAL_CAP: TURRET_TOTAL_CAP,
    capRes: capRes, shMax: shMax, tuMax: tuMax, flMax: flMax, ceilingFor: ceilingFor,
    upgradeCost: upgradeCost, evoCost: evoCost, recaptureCost: recaptureCost, wealth: wealth, pay: pay, rand01: rand01,
    defaultState: defaultState, normalizeState: normalizeState, planetView: planetView, claimView: claimView, stepEmpire: stepEmpire,
    CLAIM: CLAIM, ACTIONS_MAX: ACTIONS_MAX, HURT_DECAY: HURT_DECAY, MOM_DECAY: MOM_DECAY, rkMax: rkMax, stockRatio: stockRatio, fleetPowerRanked: fleetPowerRanked
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.EmpireEvolution; }
