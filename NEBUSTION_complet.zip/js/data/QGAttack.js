/**
 * NEBUSTION - QGAttack
 * Données et formules PURES (aucune dépendance à Phaser, testable sous Node) pour les attaques
 * lancées par le JOUEUR contre le Quartier Général d'un empire ennemi, avec la flotte de vaisseaux
 * (« bots ») du Hangar (module 6, Ships.js) — symétrique de QGRaid.js (qui gère l'inverse : les
 * empires attaquant le QG du joueur).
 *
 * Modèle volontairement simple et borné, dans le même esprit que QGRaid.js :
 *  - Puissance d'attaque du joueur = somme de la puissance des vaisseaux engagés dans la flotte
 *    (ShipManager.fleetPower(), 3 vaisseaux maximum, même flotte que le bonus de combat).
 *  - Défense du QG ennemi = développement de l'empire (`evo`), affaiblie par son traumatisme
 *    (`hurt`, mémoire du module IA 3, EmpireEvolutionManager) : un empire déjà éprouvé défend moins bien.
 *  - Issue tirée immédiatement (action manuelle du joueur, comme les autres tirages du jeu :
 *    Equipment.rollRarity, CombatEngine — pas besoin de déterminisme hors ligne ici).
 *  - Victoire : butin crédité (jamais les Noyaux antiques, comme QGRaid), l'empire encaisse un coup
 *    (traumatisme accru, élan réduit). Défaite : rien n'est perdu, l'empire reprend un peu d'élan
 *    (a tenu bon) — même logique que EmpireEvolutionManager.resolveInvasion() en cas d'échec.
 *  - Recharge (cooldown) par empire entre deux attaques, pour éviter le spam.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.QGAttack = (function () {
  'use strict';

  var COOLDOWN_MS = 3 * 3600 * 1000;   // au moins 3 h entre deux attaques contre le MÊME empire
  var LOG_MAX = 8;                     // entrées d'historique conservées

  function clamp01(x) { return Math.max(0, Math.min(1, x)); }
  function r2(x) { return Math.round(x * 100) / 100; }
  function int(x, min, max, def) { x = Math.floor(Number(x)); return isFinite(x) ? Math.min(max, Math.max(min, x)) : def; }

  var TROPHIES_MAX = 999999;

  function defaultState() { return { cooldowns: {}, log: [], trophies: 0 }; }

  function sInt(x, min, max, def) { x = Math.round(Number(x)); return isFinite(x) ? Math.min(max, Math.max(min, x)) : def; }

  function normalizeLogEntry(raw) {
    if (!raw || typeof raw !== 'object' || typeof raw.empire !== 'string' || !raw.empire) return null;
    var loot = {}, rl = raw.loot;
    if (rl && typeof rl === 'object') {
      Object.keys(rl).forEach(function (rid) { if (isFinite(Number(rl[rid]))) loot[rid] = Math.max(0, Math.round(Number(rl[rid]))); });
    }
    return {
      at: int(raw.at, 0, 8.64e15, 0), empire: raw.empire, victory: !!raw.victory,
      attack: r2(Number(raw.attack) || 0), defense: r2(Number(raw.defense) || 0), loot: loot,
      trophies: sInt(raw.trophies, -999, 999, 0)
    };
  }

  function normalizeState(raw) {
    var s = defaultState();
    if (!raw || typeof raw !== 'object') return s;
    var cd = raw.cooldowns;
    if (cd && typeof cd === 'object') {
      Object.keys(cd).forEach(function (eid) {
        var v = int(cd[eid], 0, 8.64e15, 0);
        if (v > 0) s.cooldowns[eid] = v;
      });
    }
    s.log = Array.isArray(raw.log) ? raw.log.map(normalizeLogEntry).filter(Boolean).slice(-LOG_MAX) : [];
    s.trophies = int(raw.trophies, 0, TROPHIES_MAX, 0);
    return s;
  }

  /** Puissance d'attaque du joueur, sur une échelle comparable à la défense d'un empire (0..20+). */
  function attackPower(fleetPower) {
    return Math.max(1, r2(2 + Math.max(0, Number(fleetPower) || 0)));
  }

  /** Défense du QG ennemi : croît avec le développement (`evo`), s'affaiblit avec le traumatisme (`hurt`). */
  function defensePower(evo, hurt) {
    var base = 2 + Math.max(0, Number(evo) || 0) * 1.7;
    return Math.max(1, r2(base * (1 - clamp01(hurt) * 0.4)));
  }

  /** Chance que le JOUEUR gagne l'attaque, selon l'écart attaque - défense (mêmes bornes/pente que QGRaid.defenseChance). */
  function victoryChance(attack, defense) {
    return clamp01(0.5 + (Number(attack) - Number(defense)) * 0.045);
  }

  /** Butin crédité si l'attaque réussit : croît avec le développement de l'empire visé et la marge de victoire. */
  function lootFor(evo, margin) {
    var scale = 1 + Math.max(0, Number(evo) || 0) * 0.6 + clamp01(margin) * 0.8;
    return {
      crystal: Math.round(30 * scale),
      metal: Math.round(24 * scale),
      energy: Math.round(18 * scale)
    };
  }

  /**
   * Trophées de QG (façon « Coupes » Clash of Clans) : une seconde récompense, séparée du butin, qui ne
   * sert qu'à mesurer la réussite des attaques de QG dans le temps (aucun impact sur les ressources).
   * `strength` (0..1) résume la qualité du combat : marge de victoire à l'attaque, mélange étoiles/%
   * de destruction en mode combat manuel.
   */
  function trophyGain(strength) {
    return Math.max(6, Math.round(10 + clamp01(strength) * 24));   // victoire : de 10 à 34
  }
  function trophyLoss(strength) {
    return Math.max(2, Math.round(10 - clamp01(strength) * 7));    // défaite : de 3 à 10 (plus dur si le combat n'était pas serré)
  }

  return {
    COOLDOWN_MS: COOLDOWN_MS, LOG_MAX: LOG_MAX, TROPHIES_MAX: TROPHIES_MAX,
    defaultState: defaultState, normalizeState: normalizeState,
    attackPower: attackPower, defensePower: defensePower, victoryChance: victoryChance, lootFor: lootFor,
    trophyGain: trophyGain, trophyLoss: trophyLoss
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.QGAttack; }
