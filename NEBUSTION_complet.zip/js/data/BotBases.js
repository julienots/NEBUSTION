/**
 * NEBUSTION - BotBases
 * Données et formules PURES (aucune dépendance à Phaser, testable sous Node) : chaque empire ennemi (bot)
 * est présenté comme un JOUEUR adverse avec un pseudo, un niveau et un vrai QG (une grille de structures
 * comme celle du joueur, module 11C : NEBUSTION.QGGrid).
 *
 * Le QG d'un bot n'est pas inventé au hasard : il est DÉDUIT de la mémoire de l'empire (développement `evo`,
 * traumatisme `hurt` — EmpireEvolutionManager) de façon déterministe. Un empire plus développé a plus de
 * générateurs/silos/tourelles ; un empire traumatisé par tes attaques a moins de tourelles. Le même empire
 * dans le même état donne toujours exactement le même QG (pas d'aléa non rejouable).
 *
 * Le rendu du combat (qui tire sur quoi, ce qui explose) est purement visuel : `battlePlan()` ne fait que
 * mettre en scène une issue DÉJÀ tirée par QGAttackManager.attack().
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.BotBases = (function () {
  'use strict';

  var MAX_EVO = 8;
  var HANDLES = {
    vexor: 'Ferrox_Prime', kael9: 'K9_Sable', elyra: 'ElyraVeil', morvak: 'MorVak_Dread', nyrah: 'Nyr_Ahsha', parasite: 'Xyloth_Essaim'
  };
  var RANKS = [
    { min: 0, name: 'Recrue' }, { min: 10, name: 'Lieutenant' }, { min: 18, name: 'Capitaine' },
    { min: 26, name: 'Commandant' }, { min: 34, name: 'Amiral' }
  ];

  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  function num(x, def) { x = Number(x); return isFinite(x) ? x : def; }

  function hashStr(s) {
    var h = 2166136261 >>> 0;
    s = String(s);
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    return h >>> 0;
  }
  // Petit générateur pseudo-aléatoire déterministe (mulberry32)
  function rng(seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /** Identité « joueur » d'un empire : pseudo stable, niveau et niveau de QG croissant avec le développement. */
  function profile(eid, evo) {
    evo = clamp(num(evo, 0), 0, MAX_EVO);
    var level = 5 + Math.floor(evo * 4.5);
    var rank = RANKS[0].name;
    RANKS.forEach(function (r) { if (level >= r.min) rank = r.name; });
    return {
      eid: eid,
      handle: HANDLES[eid] || (String(eid || 'bot').toUpperCase() + '_bot'),
      level: level,
      rank: rank,
      qgLevel: clamp(1 + Math.floor(evo * 1.1), 1, 10)
    };
  }

  function handleOf(eid) { return HANDLES[eid] || (String(eid || 'bot').toUpperCase() + '_bot'); }

  /** Nombre de structures de chaque type que possède le QG d'un empire dans cet état. */
  function structurePlan(evo, hurt) {
    evo = clamp(num(evo, 0), 0, MAX_EVO);
    hurt = clamp(num(hurt, 0), 0, 1);
    return {
      turret: clamp(Math.round(1 + evo * 0.6 * (1 - hurt * 0.5)), 1, 6),
      generator: clamp(Math.round(1 + evo * 0.6), 1, 6),
      silo: clamp(Math.round(1 + evo * 0.45), 1, 6)
    };
  }

  /**
   * QG du bot : { unlocked: {"x,y":true}, cells: {"x,y": structureId} } — même forme que l'état de QGGrid.
   * Tourelles en périphérie, générateurs au centre, silos entre les deux.
   */
  function layout(eid, evo, hurt, variant) {
    var Q = NEBUSTION.QGGrid;
    var plan = structurePlan(evo, hurt);
    var total = plan.turret + plan.generator + plan.silo;
    var nCells = clamp(total + 4 + Math.floor(clamp(num(evo, 0), 0, MAX_EVO) / 2), 4, Q.MAX_CELLS);
    var rand = rng(hashStr(eid + '|' + num(variant, 0)));

    var cx = (Q.COLS - 1) / 2, cy = (Q.ROWS - 1) / 2, all = [];
    for (var y = 0; y < Q.ROWS; y++) {
      for (var x = 0; x < Q.COLS; x++) {
        var d = Math.sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy));
        all.push({ x: x, y: y, k: Q.key(x, y), d: d + rand() * 0.6 });
      }
    }
    all.sort(function (a, b) { return a.d - b.d; });

    var picked = all.slice(0, nCells);
    var out = { unlocked: {}, cells: {} };
    picked.forEach(function (c) { out.unlocked[c.k] = true; });

    // picked est trié du centre vers l'extérieur.
    var inner = picked.slice(), outer = picked.slice().reverse();
    var used = {};
    function take(list, n, sid) {
      var got = 0;
      for (var i = 0; i < list.length && got < n; i++) {
        if (used[list[i].k]) continue;
        used[list[i].k] = true; out.cells[list[i].k] = sid; got++;
      }
    }
    take(outer, plan.turret, 'turret');
    take(inner, plan.generator, 'generator');
    take(inner, plan.silo, 'silo');
    return out;
  }

  /** Nombre de structures par type dans un QG (`destroyed` : clés déjà détruites, optionnel). */
  function structureCounts(lay, destroyed) {
    var c = { turret: 0, generator: 0, silo: 0 };
    Object.keys(lay.cells).forEach(function (k) {
      if (destroyed && destroyed[k]) return;
      var sid = lay.cells[k];
      if (c[sid] !== undefined) c[sid]++;
    });
    return c;
  }

  function shuffle(arr, rand) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rand() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }

  var MAX_SHOT_TARGETS = 6; // au-delà, les cibles restantes explosent en réaction en chaîne (sans tir dédié)

  /**
   * Mise en scène d'une attaque DÉJÀ résolue (victory tiré ailleurs) :
   *  - victoire : toutes les tourelles + la moitié des autres structures sont détruites ;
   *  - défaite : aucune destruction (quelques tirs sont absorbés par les défenses).
   * Retourne { turrets:[clés], order:[{key,kind}], rest:[clés] } — `order` = tirs visibles, `rest` = réaction en chaîne.
   */
  function battlePlan(lay, victory, seed) {
    var rand = rng(num(seed, 1));
    var turrets = [], others = [];
    Object.keys(lay.cells).forEach(function (k) { (lay.cells[k] === 'turret' ? turrets : others).push(k); });
    turrets.sort(); others.sort();

    var order = [], rest = [];
    if (victory) {
      var chosen = shuffle(others, rand).slice(0, Math.ceil(others.length / 2));
      var targets = shuffle(turrets, rand).concat(chosen);
      targets.forEach(function (k, i) {
        if (i < MAX_SHOT_TARGETS) order.push({ key: k, kind: 'destroy' }); else rest.push(k);
      });
    } else {
      var pool = turrets.length ? turrets : others;
      var shots = shuffle(pool, rand);
      for (var i = 0; i < Math.min(3, Math.max(1, shots.length)); i++) {
        order.push({ key: shots[i % shots.length], kind: i === 0 ? 'damage' : 'miss' });
      }
    }
    return { turrets: turrets, order: order, rest: rest };
  }

  return {
    MAX_EVO: MAX_EVO, HANDLES: HANDLES,
    profile: profile, handleOf: handleOf, structurePlan: structurePlan, layout: layout,
    structureCounts: structureCounts, battlePlan: battlePlan, hashStr: hashStr, rng: rng
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.BotBases; }
