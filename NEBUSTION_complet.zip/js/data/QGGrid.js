/**
 * NEBUSTION - QGGrid
 * Données pures (aucune dépendance à Phaser) pour la zone intérieure CONSTRUCTIBLE du QG :
 * une grille de parcelles, à déverrouiller puis à équiper de structures qui apportent
 * de vrais bonus de jeu (production, stockage, sécurité). Même esprit que Economy.js/Security.js :
 * testable sous Node, l'équilibrage se règle entièrement ici.
 *
 * Modèle : state = { unlocked: { "x,y": true, ... }, cells: { "x,y": structureId, ... } }
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.QGGrid = (function () {
  'use strict';

  var COLS = 6, ROWS = 6;
  var MAX_CELLS = COLS * ROWS;

  // Parcelle centrale (2x2) déverrouillée gratuitement dès l'entrée dans le QG.
  var START_CELLS = [[2, 2], [3, 2], [2, 3], [3, 3]];

  var UNLOCK_BASE = { crystal: 40, metal: 30 };
  var UNLOCK_GROWTH = 0.45; // coût ×(1 + n·0.45), n = nb de parcelles déjà déverrouillées

  var STRUCTURES = {
    generator: {
      id: 'generator', name: 'Générateur', icon: '🔋', color: 0x4fe3ff,
      base: { metal: 120, energy: 70 }, growth: 1.35, maxCount: 6,
      effect: { type: 'production', perUnit: 0.02 },
      desc: function (n) { return '+' + Math.round(n * 0.02 * 100) + ' % de production de ressources (toutes)'; }
    },
    silo: {
      id: 'silo', name: 'Silo', icon: '🛢️', color: 0xc9d4ea,
      base: { metal: 140, dust: 110 }, growth: 1.35, maxCount: 6,
      effect: { type: 'storage', perUnit: 0.03 },
      desc: function (n) { return '+' + Math.round(n * 0.03 * 100) + ' % de capacité de stockage'; }
    },
    turret: {
      id: 'turret', name: 'Tourelle', icon: '🗼', color: 0x5fd97a,
      base: { metal: 130, energy: 90 }, growth: 1.35, maxCount: 6,
      effect: { type: 'security', perUnit: 1 },
      desc: function (n) { return '+' + n + ' niveau(x) de Sécurité de zone équivalents'; }
    },
    // Module 18 : la Barricade protège le CŒUR du QG. En combat, elle bloque les troupes au sol (il faut la détruire
    // pour passer) ; hors combat, chaque paire de barricades vaut +1 niveau de Sécurité contre les raids.
    wall: {
      id: 'wall', name: 'Barricade', icon: '🧱', color: 0xffb04f,
      base: { metal: 90, dust: 80 }, growth: 1.25, maxCount: 8,
      effect: { type: 'security', perUnit: 0.5 },
      desc: function (n) { return 'Protège le cœur du QG : bloque les troupes au sol · +' + (Math.round(n * 0.5 * 10) / 10) + ' niveau(x) de Sécurité'; }
    }    ,
    // ---------- Bâtiments utiles (module 20) : chaque type apporte un bonus RÉEL, branché dans les managers ----------
    // 'army' → TroopManager.capacity · 'troopDiscount' → coût des troupes · 'symbiote' → XP du Symtor
    // 'attackCooldown' → recharge des attaques de flotte · 'loot' → butin des attaques.
    barracks: {
      id: 'barracks', name: 'Caserne', icon: '🏕️', color: 0xff7a59,
      base: { metal: 160, crystal: 90 }, growth: 1.4, maxCount: 5,
      effect: { type: 'army', perUnit: 4 },
      desc: function (n) { return '+' + (n * 4) + ' places d\'armée (troupes)'; }
    },
    workshop: {
      id: 'workshop', name: 'Atelier', icon: '🔧', color: 0xffd166,
      base: { metal: 150, energy: 110 }, growth: 1.4, maxCount: 6,
      effect: { type: 'troopDiscount', perUnit: 0.03 },
      desc: function (n) { return '−' + Math.round(n * 3) + ' % sur le prix des troupes'; }
    },
    lab: {
      id: 'lab', name: 'Bio-labo', icon: '🧬', color: 0xd77cff,
      base: { crystal: 140, energy: 100, dust: 80 }, growth: 1.4, maxCount: 5,
      effect: { type: 'symbiote', perUnit: 0.08 },
      desc: function (n) { return '+' + Math.round(n * 8) + ' % d\'XP pour le Symtor quand tu le nourris'; }
    },
    radar: {
      id: 'radar', name: 'Radar', icon: '📡', color: 0x3f8cff,
      base: { crystal: 110, energy: 120 }, growth: 1.35, maxCount: 5,
      effect: { type: 'attackCooldown', perUnit: 0.06 },
      desc: function (n) { return '−' + Math.round(n * 6) + ' % de recharge entre deux attaques de flotte'; }
    },
    refinery: {
      id: 'refinery', name: 'Raffinerie', icon: '⚗️', color: 0x2ee6b8,
      base: { crystal: 130, metal: 100, dust: 90 }, growth: 1.4, maxCount: 5,
      effect: { type: 'loot', perUnit: 0.05 },
      desc: function (n) { return '+' + Math.round(n * 5) + ' % de butin sur les attaques victorieuses'; }
    },
    // 'raidShield' → QGRaidManager.applyLoss : réduit la part des ressources perdue quand un raid ennemi réussit.
    vault: {
      id: 'vault', name: 'Coffre-fort', icon: '🔐', color: 0xffe14f,
      base: { metal: 170, dust: 140 }, growth: 1.4, maxCount: 5,
      effect: { type: 'raidShield', perUnit: 0.06 },
      desc: function (n) { return '−' + Math.round(n * 6) + ' % de pertes de ressources en cas de raid réussi'; }
    },
    // ---------- Nouveaux bâtiments ----------
    commandpost: {
      id: 'commandpost', name: 'Poste de commandement', icon: '🎖️', color: 0xff5c8a,
      base: { metal: 200, crystal: 130 }, growth: 1.45, maxCount: 4,
      effect: { type: 'army', perUnit: 3 },
      desc: function (n) { return '+' + (n * 3) + ' places d\'armée supplémentaires (cumulable avec la Caserne)'; }
    },
    blackmarket: {
      id: 'blackmarket', name: 'Comptoir noir', icon: '🏴‍☠️', color: 0x8a5cff,
      base: { crystal: 160, dust: 130 }, growth: 1.4, maxCount: 4,
      effect: { type: 'loot', perUnit: 0.04 },
      desc: function (n) { return '+' + Math.round(n * 4) + ' % de butin supplémentaire sur les attaques victorieuses'; }
    },
    // ---------- Bâtiments à CONSTRUCTION (module 28) : plus chers, plus puissants, mais pas instantanés.
    // `buildTimeSec` > 0 → posés sur `state.building[key]` (chantier en cours) puis transférés dans
    // `state.cells` une fois `end` atteint (voir startBuild/completePending). Les structures SANS
    // `buildTimeSec` restent instantanées (rétrocompatibilité totale avec les 12 bâtiments existants).
    observatory: {
      id: 'observatory', name: 'Observatoire stellaire', icon: '🔭', color: 0x7fd0ff,
      base: { crystal: 220, energy: 170 }, growth: 1.45, maxCount: 4, buildTimeSec: 240,
      effect: { type: 'offlineEff', perUnit: 0.03 },
      desc: function (n) { return '+' + Math.round(n * 3) + ' % d\'efficacité de production hors ligne'; }
    },
    beacon: {
      id: 'beacon', name: 'Balise de ravitaillement', icon: '🛰️', color: 0xffe066,
      base: { metal: 170, dust: 150 }, growth: 1.4, maxCount: 5, buildTimeSec: 200,
      effect: { type: 'podRate', perUnit: 0.08 },
      desc: function (n) { return '−' + Math.round(Math.min(n * 8, 50)) + ' % d\'attente entre deux caisses de ravitaillement'; }
    },
    arsenal: {
      id: 'arsenal', name: 'Arsenal de combat', icon: '⚔️', color: 0xff8a5c,
      base: { metal: 210, crystal: 140 }, growth: 1.45, maxCount: 5, buildTimeSec: 260,
      effect: { type: 'troopDiscount', perUnit: 0.02 },
      desc: function (n) { return '−' + Math.round(n * 2) + ' % supplémentaires sur le prix des troupes (cumulable avec l\'Atelier)'; }
    },
    citadel: {
      id: 'citadel', name: 'Citadelle orbitale', icon: '🏯', color: 0xf2b53c,
      base: { metal: 260, dust: 200 }, growth: 1.45, maxCount: 4, buildTimeSec: 300,
      effect: { type: 'raidShield', perUnit: 0.04 },
      desc: function (n) { return '−' + Math.round(n * 4) + ' % de pertes supplémentaires en cas de raid réussi (cumulable avec le Coffre-fort)'; }
    }
  };
  var STRUCTURE_ORDER = ['generator', 'silo', 'turret', 'wall', 'barracks', 'workshop', 'lab', 'radar', 'refinery', 'vault', 'commandpost', 'blackmarket',
    'observatory', 'beacon', 'arsenal', 'citadel'];
  // Durée max raisonnable d'un chantier (garde-fou de normalizeState : une sauvegarde corrompue/manipulée
  // ne doit jamais produire un chantier qui dure des jours).
  var MAX_BUILD_MS = 2 * 3600 * 1000;

  function inBounds(x, y) { return Number.isInteger(x) && Number.isInteger(y) && x >= 0 && x < COLS && y >= 0 && y < ROWS; }
  function key(x, y) { return x + ',' + y; }
  function parseKey(k) {
    var p = String(k).split(',');
    var x = parseInt(p[0], 10), y = parseInt(p[1], 10);
    return { x: x, y: y };
  }
  function isValidKey(k) {
    var p = parseKey(k);
    return inBounds(p.x, p.y);
  }

  function defaultUnlocked() {
    var u = {};
    START_CELLS.forEach(function (c) { u[key(c[0], c[1])] = true; });
    return u;
  }

  function defaultState() {
    return { unlocked: defaultUnlocked(), cells: {}, building: {} };
  }

  function normalizeState(raw, now) {
    var s = defaultState();
    if (!raw || typeof raw !== 'object') return s;
    now = Number(now) || Date.now();

    var unlocked = {};
    if (raw.unlocked && typeof raw.unlocked === 'object') {
      Object.keys(raw.unlocked).forEach(function (k) {
        if (raw.unlocked[k] && isValidKey(k)) unlocked[k] = true;
      });
    }
    // Le noyau central reste toujours acquis, même sur une sauvegarde corrompue/tronquée.
    Object.keys(defaultUnlocked()).forEach(function (k) { unlocked[k] = true; });

    var cells = {};
    if (raw.cells && typeof raw.cells === 'object') {
      Object.keys(raw.cells).forEach(function (k) {
        var sid = raw.cells[k];
        if (isValidKey(k) && unlocked[k] && STRUCTURES[sid]) cells[k] = sid;
      });
    }
    // Chaque type respecte son plafond même si la sauvegarde a été manipulée.
    var seen = {};
    Object.keys(cells).forEach(function (k) {
      var sid = cells[k];
      seen[sid] = (seen[sid] || 0) + 1;
      if (seen[sid] > STRUCTURES[sid].maxCount) delete cells[k];
    });

    // Chantiers en cours (module 28) : une parcelle déverrouillée, sans structure posée, avec un
    // couple start/end valide (start <= now, end > start, durée <= MAX_BUILD_MS).
    var building = {};
    if (raw.building && typeof raw.building === 'object') {
      Object.keys(raw.building).forEach(function (k) {
        var j = raw.building[k];
        if (!j || !isValidKey(k) || !unlocked[k] || cells[k]) return;
        var def = STRUCTURES[j.id];
        if (!def || !def.buildTimeSec) return;
        var st = Number(j.start), en = Number(j.end);
        if (!isFinite(st) || !isFinite(en) || en <= st || (en - st) > MAX_BUILD_MS) return;
        if (st > now + 1000) return; // pas de chantier qui commencerait dans le futur
        building[k] = { id: j.id, start: st, end: en };
      });
    }
    // Chaque type (posé + en chantier) respecte aussi son plafond.
    var seenB = {};
    Object.keys(building).forEach(function (k) {
      var sid = building[k].id;
      var already = (seen[sid] || 0) + (seenB[sid] || 0);
      seenB[sid] = (seenB[sid] || 0) + 1;
      if (already >= STRUCTURES[sid].maxCount) delete building[k];
    });

    s.unlocked = unlocked;
    s.cells = cells;
    s.building = building;
    return s;
  }

  function unlockedCount(state) { return Object.keys(state.unlocked).length; }

  /** Coût pour déverrouiller la PROCHAINE parcelle (n = nb déjà déverrouillées). */
  function unlockCost(n) {
    n = Math.max(0, Math.floor(Number(n) || 0));
    var mult = 1 + n * UNLOCK_GROWTH;
    var out = {};
    Object.keys(UNLOCK_BASE).forEach(function (id) { out[id] = Math.ceil(UNLOCK_BASE[id] * mult); });
    return out;
  }

  /** Coût pour construire une structure de type `structureId` (n = nb déjà construites de ce type). */
  function buildCost(structureId, n) {
    var def = STRUCTURES[structureId];
    if (!def) return {};
    n = Math.max(0, Math.floor(Number(n) || 0));
    var mult = Math.pow(def.growth, n);
    var out = {};
    Object.keys(def.base).forEach(function (id) { out[id] = Math.ceil(def.base[id] * mult); });
    return out;
  }

  /** Remboursement à la revente (50 % du coût payé pour la dernière unité construite de ce type). */
  function sellRefund(structureId, n) {
    var def = STRUCTURES[structureId];
    if (!def) return {};
    var paid = buildCost(structureId, Math.max(0, Math.floor(Number(n) || 0) - 1));
    var out = {};
    Object.keys(paid).forEach(function (id) { out[id] = Math.floor(paid[id] * 0.5); });
    return out;
  }

  /** Nombre de structures construites (ACTIVES), par type. */
  function counts(state) {
    var c = {};
    STRUCTURE_ORDER.forEach(function (sid) { c[sid] = 0; });
    Object.keys(state.cells).forEach(function (k) {
      var sid = state.cells[k];
      if (c[sid] !== undefined) c[sid]++;
    });
    return c;
  }

  /** Nombre de chantiers EN COURS (pas encore actifs), par type. */
  function countsPending(state) {
    var c = {};
    STRUCTURE_ORDER.forEach(function (sid) { c[sid] = 0; });
    var b = state.building || {};
    Object.keys(b).forEach(function (k) {
      var sid = b[k].id;
      if (c[sid] !== undefined) c[sid]++;
    });
    return c;
  }

  function pendingAt(state, x, y) { return (state.building || {})[key(x, y)] || null; }

  /**
   * Lance un chantier sur une parcelle libre et déverrouillée (le coût a déjà été payé par l'appelant,
   * comme pour build()). `structureId` DOIT avoir un `buildTimeSec` (sinon utiliser la pose instantanée).
   */
  function startBuild(state, x, y, structureId, now) {
    var def = STRUCTURES[structureId], k = key(x, y);
    if (!def || !def.buildTimeSec || !inBounds(x, y)) return { ok: false, reason: 'invalid' };
    if (!state.unlocked[k]) return { ok: false, reason: 'locked' };
    if (state.cells[k] || pendingAt(state, x, y)) return { ok: false, reason: 'occupied' };
    var already = (counts(state)[structureId] || 0) + (countsPending(state)[structureId] || 0);
    if (already >= def.maxCount) return { ok: false, reason: 'max' };
    now = Number(now) || Date.now();
    var end = now + Math.max(1, Math.round(def.buildTimeSec)) * 1000;
    if (!state.building) state.building = {};
    state.building[k] = { id: structureId, start: now, end: end };
    return { ok: true, end: end };
  }

  /** Fait avancer le temps : transfère dans `cells` tout chantier dont l'heure de fin est atteinte. */
  function completePending(state, now) {
    now = Number(now) || Date.now();
    var done = [];
    var b = state.building || {};
    Object.keys(b).forEach(function (k) {
      var job = b[k];
      if (job.end > now) return;
      var def = STRUCTURES[job.id];
      var n = counts(state)[job.id] || 0;
      if (def && !state.cells[k] && n < def.maxCount) {
        state.cells[k] = job.id;
        done.push({ key: k, id: job.id });
      }
      delete b[k];
    });
    return done;
  }

  /** Temps restant (ms) avant la fin du chantier de la parcelle (x,y) ; 0 si aucun chantier. */
  function remainingMs(state, x, y, now) {
    var job = pendingAt(state, x, y);
    if (!job) return 0;
    now = Number(now) || Date.now();
    return Math.max(0, job.end - now);
  }

  /** Annule un chantier en cours ; ne calcule PAS le remboursement (voir QGGridManager.cancelBuild). */
  function cancelBuild(state, x, y) {
    var k = key(x, y), job = pendingAt(state, x, y);
    if (!job) return null;
    delete state.building[k];
    return job;
  }

  /** Bonus total d'un type d'effet ('production' | 'storage' | 'security'), toutes structures confondues. */
  function bonusValue(type, state) {
    var c = counts(state);
    var total = 0;
    STRUCTURE_ORDER.forEach(function (sid) {
      var def = STRUCTURES[sid];
      if (def.effect.type !== type) return;
      var n = Math.min(c[sid] || 0, def.maxCount);
      total += n * def.effect.perUnit;
    });
    return total;
  }

  return {
    COLS: COLS, ROWS: ROWS, MAX_CELLS: MAX_CELLS, START_CELLS: START_CELLS,
    STRUCTURES: STRUCTURES, STRUCTURE_ORDER: STRUCTURE_ORDER, MAX_BUILD_MS: MAX_BUILD_MS,
    inBounds: inBounds, key: key, parseKey: parseKey,
    defaultState: defaultState, normalizeState: normalizeState,
    unlockedCount: unlockedCount, unlockCost: unlockCost,
    buildCost: buildCost, sellRefund: sellRefund,
    counts: counts, bonusValue: bonusValue,
    countsPending: countsPending, pendingAt: pendingAt,
    startBuild: startBuild, completePending: completePending, remainingMs: remainingMs, cancelBuild: cancelBuild
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.QGGrid; }
