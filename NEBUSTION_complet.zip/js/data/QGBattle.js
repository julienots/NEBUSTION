/**
 * NEBUSTION - QGBattle (moteur de combat PUR, sans Phaser, testable sous Node)
 * Mode combat façon Clash of Clans dans le QG : la base ennemie est une grille 6×6 (celle de QGGrid) avec, au
 * centre, le CŒUR du QG protégé par des BARRICADES. Le joueur déploie ses troupes (Troops.js) autour de la base,
 * elles avancent seules vers leurs cibles, les tourelles ripostent. Les troupes au sol sont bloquées par les
 * barricades (il faut les détruire, ou les faire exploser avec des Casseurs) ; les vaisseaux les survolent.
 *
 * Unités = « cellules » : la base occupe [0,6]×[0,6], l'arène [-1.5,7.5]². Le moteur est déterministe (aucun aléa).
 * Étoiles : ★ ≥ 50 % de structures détruites · ★ cœur détruit · ★ 100 % (murs non comptés).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.QGBattle = (function () {
  'use strict';

  var GRID = 6;
  var ARENA_MIN = -1.5, ARENA_MAX = 7.5;
  var DURATION = 120;               // secondes de combat
  var MAX_STEP = 0.05;              // pas de simulation maximum (s)
  var TURRET_RANGE = 3.0, TURRET_CD = 0.8;
  // ---- Frappe orbitale du Commandant (attaque spéciale activable par le joueur) ----
  var STRIKE_MAX = 100, STRIKE_GAIN = 22, STRIKE_RADIUS = 1.3, STRIKE_BASE_DMG = 260;
  // ---- Objets/consommables utilisables en assaut de QG (voir js/data/CombatItems.js) ----
  var ITEM_RADIUS = 1.6;

  var KIND = {
    core:      { name: 'Cœur du QG',  icon: '💠', color: 0x4fe3ff, hp: 1000, half: 0.3 },
    wall:      { name: 'Barricade',   icon: '🧱', color: 0xffb04f, hp: 500, half: 0.42 },
    turret:    { name: 'Tourelle',    icon: '🗼', color: 0x5fd97a, hp: 240, half: 0.3 },
    generator: { name: 'Générateur',  icon: '🔋', color: 0x4fe3ff, hp: 220, half: 0.3 },
    silo:      { name: 'Silo',        icon: '🛢️', color: 0xc9d4ea, hp: 220, half: 0.3 }
  };

  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  function num(x, d) { x = Number(x); return isFinite(x) ? x : d; }
  function dist(ax, ay, bx, by) { var dx = ax - bx, dy = ay - by; return Math.sqrt(dx * dx + dy * dy); }
  function parseKey(k) { var p = String(k).split(','); return { x: parseInt(p[0], 10), y: parseInt(p[1], 10) }; }

  /** Force d'un QG selon le développement de l'empire (`evo` 0..8) et son traumatisme (`hurt` 0..1). */
  function scaleFor(evo, hurt) {
    return Math.max(0.5, (1 + clamp(num(evo, 0), 0, 8) * 0.16) * (1 - clamp(num(hurt, 0), 0, 1) * 0.3));
  }

  /** Nombre de barricades d'un QG ennemi selon son développement. */
  function wallCount(evo) { return clamp(Math.round(1 + clamp(num(evo, 0), 0, 8) * 0.7), 1, 6); }

  /**
   * Ajoute des barricades EN ANNEAU autour du cœur : parcelles libres déverrouillées, les plus proches
   * d'un cercle de rayon ~1,6 cellule autour du centre. Ne modifie pas le layout d'origine (copie).
   */
  function withWalls(layout, n) {
    var out = { unlocked: {}, cells: {} };
    Object.keys(layout.unlocked || {}).forEach(function (k) { out.unlocked[k] = true; });
    Object.keys(layout.cells || {}).forEach(function (k) { out.cells[k] = layout.cells[k]; });
    var free = Object.keys(out.unlocked).filter(function (k) { return !out.cells[k]; }).map(function (k) {
      var p = parseKey(k);
      return { k: k, d: Math.abs(dist(p.x + 0.5, p.y + 0.5, GRID / 2, GRID / 2) - 1.6), s: k };
    });
    free.sort(function (a, b) { return a.d - b.d || (a.s < b.s ? -1 : 1); });
    free.slice(0, Math.max(0, n | 0)).forEach(function (f) { out.cells[f.k] = 'wall'; });
    return out;
  }

  /**
   * Construit la base de combat à partir d'un layout de QG ({unlocked, cells}) :
   * un cœur au centre + une entité par structure. `opts.scale` multiplie les PV et les dégâts des tourelles.
   */
  function buildBase(layout, opts) {
    opts = opts || {};
    var scale = Math.max(0.3, num(opts.scale, 1));
    var list = [], id = 0;
    function add(kind, x, y, key) {
      var K = KIND[kind];
      if (!K) return;
      var hp = Math.round(K.hp * scale);
      list.push({ id: ++id, kind: kind, key: key || null, x: x, y: y, half: K.half, hp: hp, maxHp: hp, alive: true, cd: 0.3 + (id % 5) * 0.12 });
    }
    add('core', GRID / 2, GRID / 2, 'core');
    Object.keys((layout && layout.cells) || {}).sort().forEach(function (k) {
      var p = parseKey(k), kind = layout.cells[k];
      if (!KIND[kind] || kind === 'core') return;
      add(kind, p.x + 0.5, p.y + 0.5, k);
    });
    return { buildings: list, scale: scale, turretDmg: 13 * (1 + (scale - 1) * 0.5) };
  }

  /** QG d'un empire (déduit de son état réel, comme BotBases) + barricades autour du cœur. */
  function botBase(eid, evo, hurt, variant) {
    var BB = NEBUSTION.BotBases;
    var lay = BB.layout(eid, evo, hurt, variant);
    return buildBase(withWalls(lay, wallCount(evo)), { scale: scaleFor(evo, hurt) });
  }

  /** Ton propre QG (grille du joueur) — même moteur, utile pour visualiser/tester la défense. */
  function playerBase(gridState, scale) { return buildBase(gridState || { cells: {} }, { scale: scale || 1 }); }

  function inDeployZone(x, y) {
    if (!isFinite(x) || !isFinite(y)) return false;
    if (x < ARENA_MIN || x > ARENA_MAX || y < ARENA_MIN || y > ARENA_MAX) return false;
    return x < -0.25 || x > GRID + 0.25 || y < -0.25 || y > GRID + 0.25;
  }

  function rectDist(px, py, b) {
    var dx = Math.max(Math.abs(px - b.x) - b.half, 0), dy = Math.max(Math.abs(py - b.y) - b.half, 0);
    return Math.sqrt(dx * dx + dy * dy);
  }
  function insideRect(px, py, b, pad) {
    return Math.abs(px - b.x) < b.half + pad && Math.abs(py - b.y) < b.half + pad;
  }

  /**
   * Crée un combat. `reserve` = { troopId: nombre } (les troupes disponibles au déploiement).
   * Troops = NEBUSTION.Troops (catalogue) ; on le lit à l'appel pour rester testable avec un faux catalogue.
   */
  function create(base, reserve, troopsApi, opts) {
    var T = troopsApi || NEBUSTION.Troops;
    opts = opts || {};
    var sim = {
      base: base, buildings: base.buildings, troops: [], events: [], t: 0, started: false, over: false, duration: DURATION,
      reserve: {}, deployedCount: 0, lost: 0, _uid: 0,
      strikeCharge: 0   // Frappe orbitale du Commandant : jauge alimentée par les dégâts infligés aux structures
    };
    Object.keys(reserve || {}).forEach(function (tid) { if (T.get(tid) && reserve[tid] > 0) sim.reserve[tid] = Math.floor(reserve[tid]); });

    // Objets/consommables (charges limitées pour ce combat) : voir js/data/CombatItems.js.
    sim.items = {};
    var itemDefs = (NEBUSTION.CombatItems && NEBUSTION.CombatItems.DEFS) || {};
    var loadout = opts.items || {};
    Object.keys(itemDefs).forEach(function (id) {
      if (!itemDefs[id].qgEffect) return;
      var charges = (loadout[id] !== undefined) ? loadout[id] : itemDefs[id].defaultCharges;
      sim.items[id] = { charges: charges };
    });

    function aliveTroops() { return sim.troops.filter(function (u) { return u.alive; }); }
    sim.aliveTroops = aliveTroops;
    sim.remaining = function () { return Object.keys(sim.reserve).reduce(function (a, k) { return a + sim.reserve[k]; }, 0); };

    sim.deploy = function (tid, x, y) {
      if (sim.over) return { ok: false, reason: 'termine' };
      var t = T.get(tid);
      if (!t) return { ok: false, reason: 'inconnu' };
      // Les améliorations de Caserne sont appliquées au moment du déploiement.
      var cs = (typeof T.combatStats === 'function') ? T.combatStats(tid) : null;
      if (cs) t = Object.assign({}, t, cs);
      if (!(sim.reserve[tid] > 0)) return { ok: false, reason: 'stock' };
      if (!inDeployZone(x, y)) return { ok: false, reason: 'zone' };
      sim.reserve[tid] -= 1;
      var u = { id: ++sim._uid, type: tid, x: x, y: y, hp: t.hp, maxHp: t.hp, alive: true, fly: !!t.fly, target: null, def: t };
      sim.troops.push(u);
      sim.started = true;
      sim.deployedCount++;
      return { ok: true, unit: u };
    };

    /**
     * Formation/escouade : déploie plusieurs troupes EN UNE FOIS autour du point (cx, cy), les
     * unités de mêlée (portée courte) se plaçant en AVANT (côté base) et les troupes de
     * soutien/tir (portée longue) en ARRIÈRE — un vrai choix de positionnement en un tap.
     */
    sim.deploySquad = function (tids, cx, cy) {
      if (sim.over) return { ok: false, reason: 'termine' };
      if (!Array.isArray(tids) || !tids.length) return { ok: false, reason: 'vide' };
      if (!inDeployZone(cx, cy)) return { ok: false, reason: 'zone' };
      var center = GRID / 2;
      var dx = center - cx, dy = center - cy, len = Math.sqrt(dx * dx + dy * dy) || 1;
      dx /= len; dy /= len;             // direction unitaire vers le cœur de la base
      var perpX = -dy, perpY = dx;      // direction perpendiculaire (étalement latéral)
      var results = tids.map(function (tid, i) {
        var t = T.get(tid);
        var isFront = !t || t.range <= 1;                 // mêlée devant, tir/soutien derrière
        var depth = isFront ? 0.2 : -0.6;
        var lateral = (i - (tids.length - 1) / 2) * 0.55;
        var px = clamp(cx + dx * depth + perpX * lateral, ARENA_MIN + 0.1, ARENA_MAX - 0.1);
        var py = clamp(cy + dy * depth + perpY * lateral, ARENA_MIN + 0.1, ARENA_MAX - 0.1);
        return sim.deploy(tid, px, py);
      });
      return { ok: results.every(function (r) { return r.ok; }), results: results };
    };

    // ---------- Frappe orbitale du Commandant ----------
    sim.strikeReady = function () { return !sim.over && sim.strikeCharge >= STRIKE_MAX; };
    sim.useStrike = function (x, y) {
      if (!sim.strikeReady()) return { ok: false, reason: 'charge' };
      if (!isFinite(x) || !isFinite(y) || x < ARENA_MIN || x > ARENA_MAX || y < ARENA_MIN || y > ARENA_MAX) return { ok: false, reason: 'zone' };
      var dmg = STRIKE_BASE_DMG * sim.base.scale, hit = [];
      sim.buildings.forEach(function (b) {
        if (!b.alive || rectDist(x, y, b) > STRIKE_RADIUS) return;
        hurt(b, dmg);
        hit.push(b.id);
      });
      sim.strikeCharge = 0;
      sim.events.push({ type: 'strike', x: x, y: y, radius: STRIKE_RADIUS, hit: hit });
      checkEnd();
      return { ok: true, hit: hit };
    };

    // ---------- Objets/consommables de combat (charges limitées) ----------
    sim.useItem = function (itemId, x, y) {
      if (sim.over) return { ok: false, reason: 'termine' };
      var it = sim.items[itemId];
      var def = NEBUSTION.CombatItems && NEBUSTION.CombatItems.get(itemId);
      if (!it || !def || !def.qgEffect || it.charges <= 0) return { ok: false, reason: 'stock' };
      if (!isFinite(x) || !isFinite(y) || x < ARENA_MIN || x > ARENA_MAX || y < ARENA_MIN || y > ARENA_MAX) return { ok: false, reason: 'zone' };
      it.charges--;
      var radius = def.radius || ITEM_RADIUS, hit = [];
      switch (def.qgEffect) {
        case 'qgDamage':
          sim.buildings.forEach(function (b) { if (b.alive && rectDist(x, y, b) <= radius) { hurt(b, def.qgPower); hit.push(b.id); } });
          break;
        case 'qgHeal':
          aliveTroops().forEach(function (u) {
            if (dist(u.x, u.y, x, y) > radius) return;
            u.hp = Math.min(u.maxHp, u.hp + u.maxHp * def.qgPower);
            hit.push(u.id);
          });
          break;
        case 'qgShield':
          aliveTroops().forEach(function (u) {
            if (dist(u.x, u.y, x, y) > radius) return;
            u._shieldUntil = sim.t + (def.duration_qg || 4);
            hit.push(u.id);
          });
          break;
        case 'qgRage':
          aliveTroops().forEach(function (u) {
            if (dist(u.x, u.y, x, y) > radius) return;
            u._rageUntil = sim.t + (def.duration_qg || 4);
            u._ragePower = def.qgPower;
            hit.push(u.id);
          });
          break;
        default: break;
      }
      sim.events.push({ type: 'item', item: itemId, x: x, y: y, radius: radius, hit: hit });
      checkEnd();
      return { ok: true, hit: hit };
    };

    function nearest(u, pred) {
      var best = null, bd = 1e9;
      for (var i = 0; i < sim.buildings.length; i++) {
        var b = sim.buildings[i];
        if (!b.alive || !pred(b)) continue;
        var d = dist(u.x, u.y, b.x, b.y);
        if (d < bd) { bd = d; best = b; }
      }
      return best;
    }
    function pickTarget(u) {
      var pref = u.def.pref, b = null;
      if (pref === 'wall') b = nearest(u, function (x) { return x.kind === 'wall'; });
      else if (pref === 'turret') b = nearest(u, function (x) { return x.kind === 'turret'; });
      else if (pref === 'eco') b = nearest(u, function (x) { return x.kind === 'generator' || x.kind === 'silo'; });
      else if (pref === 'core') b = nearest(u, function (x) { return x.kind === 'core'; });
      return b || nearest(u, function (x) { return x.kind !== 'wall'; });
    }

    function hurt(b, dmg) {
      if (!b.alive) return;
      var dealt = Math.min(b.hp, dmg);
      b.hp -= dmg;
      // Toute attaque portée à une structure (troupe, explosion, objet ou frappe orbitale) charge la
      // jauge de Frappe du Commandant, proportionnellement aux PV max de la structure touchée.
      if (dealt > 0) sim.strikeCharge = clamp(sim.strikeCharge + (dealt / Math.max(1, b.maxHp)) * STRIKE_GAIN, 0, STRIKE_MAX);
      if (b.hp <= 0) { b.hp = 0; b.alive = false; sim.events.push({ type: 'destroy', id: b.id, kind: b.kind, x: b.x, y: b.y }); }
    }

    function explode(u, victim) {
      var d = u.def;
      sim.events.push({ type: 'boom', x: u.x, y: u.y });
      if (victim) hurt(victim, d.blast);
      sim.buildings.forEach(function (b) {
        if (b === victim || !b.alive) return;
        if (rectDist(u.x, u.y, b) <= (d.blastRadius || 1)) hurt(b, d.blast * 0.6);
      });
      u.alive = false;
    }

    function stepTroop(u, dt) {
      if (!u.target || !u.target.alive || (u.def.pref === 'wall' && u.target.kind !== 'wall' && sim.buildings.some(function (b) { return b.alive && b.kind === 'wall'; }))) {
        u.target = pickTarget(u);
      }
      var tg = u.target;
      if (!tg) return;
      var d = u.def, gap = rectDist(u.x, u.y, tg);
      if (gap <= d.range) {
        if (d.blast) { explode(u, tg); return; }
        var rageMult = (u._rageUntil && u._rageUntil > sim.t) ? (1 + (u._ragePower || 0.5)) : 1;
        hurt(tg, d.dps * dt * rageMult);
        if (d.range > 1 && (!u._shotCd || u._shotCd <= 0)) { sim.events.push({ type: 'shot', from: 'troop', x1: u.x, y1: u.y, x2: tg.x, y2: tg.y, color: d.color }); u._shotCd = 0.5; }
        return;
      }
      var dx = tg.x - u.x, dy = tg.y - u.y, len = Math.sqrt(dx * dx + dy * dy) || 1;
      var step = Math.min(d.speed * dt, Math.max(0, gap - d.range * 0.9));
      var nx = u.x + dx / len * step, ny = u.y + dy / len * step;
      if (!u.fly) {
        for (var i = 0; i < sim.buildings.length; i++) {
          var w = sim.buildings[i];
          if (w.kind !== 'wall' || !w.alive || w === tg) continue;
          if (insideRect(nx, ny, w, 0.1) && !insideRect(u.x, u.y, w, 0.1)) {
            // bloqué par une barricade : on l'attaque (ou le Casseur la fait sauter)
            if (d.blast) { explode(u, w); return; }
            var rageMultW = (u._rageUntil && u._rageUntil > sim.t) ? (1 + (u._ragePower || 0.5)) : 1;
            hurt(w, d.dps * dt * rageMultW);
            if (d.range > 1 && (!u._shotCd || u._shotCd <= 0)) { sim.events.push({ type: 'shot', from: 'troop', x1: u.x, y1: u.y, x2: w.x, y2: w.y, color: d.color }); u._shotCd = 0.5; }
            return;
          }
        }
      }
      u.x = nx; u.y = ny;
    }

    function stepTurrets(dt) {
      var scale = sim.base.turretDmg;
      sim.buildings.forEach(function (b) {
        if (!b.alive || b.kind !== 'turret') return;
        b.cd -= dt;
        if (b.cd > 0) return;
        var best = null, bd = 1e9;
        sim.troops.forEach(function (u) {
          if (!u.alive) return;
          var dd = dist(u.x, u.y, b.x, b.y);
          if (dd <= TURRET_RANGE && dd < bd) { bd = dd; best = u; }
        });
        if (!best) { b.cd = 0.1; return; }
        var dmgToTroop = scale * ((best._shieldUntil && best._shieldUntil > sim.t) ? 0.4 : 1);
        best.hp -= dmgToTroop;
        b.cd = TURRET_CD;
        sim.events.push({ type: 'shot', from: 'turret', x1: b.x, y1: b.y, x2: best.x, y2: best.y, color: 0x5fd97a });
        if (best.hp <= 0) { best.alive = false; sim.lost++; sim.events.push({ type: 'die', x: best.x, y: best.y, id: best.id }); }
      });
    }

    function checkEnd() {
      if (sim.over) return;
      var standing = sim.buildings.some(function (b) { return b.alive && b.kind !== 'wall'; });
      if (!standing) sim.over = true;
      else if (sim.t >= sim.duration) sim.over = true;
      else if (sim.started && aliveTroops().length === 0 && sim.remaining() === 0) sim.over = true;
    }

    sim.step = function (dt) {
      dt = clamp(num(dt, 0), 0, 1);
      while (dt > 1e-9 && !sim.over) {
        var h = Math.min(dt, MAX_STEP);
        dt -= h;
        if (sim.started) sim.t += h;
        sim.troops.forEach(function (u) {
          if (!u.alive) return;
          if (u._shotCd > 0) u._shotCd -= h;
          var was = u.alive;
          stepTroop(u, h);
          if (was && !u.alive) sim.lost++;   // Casseur : consommé par son explosion
        });
        stepTurrets(h);
        checkEnd();
      }
    };

    sim.retreat = function () { sim.over = true; };

    sim.result = function () {
      var d = sim.buildings.filter(function (b) { return b.kind !== 'wall'; });
      var down = d.filter(function (b) { return !b.alive; }).length;
      var pct = d.length ? down / d.length : 0;
      var coreDown = sim.buildings.some(function (b) { return b.kind === 'core' && !b.alive; });
      var stars = (pct >= 0.5 ? 1 : 0) + (coreDown ? 1 : 0) + (pct >= 1 ? 1 : 0);
      return { pct: Math.round(pct * 1000) / 1000, coreDown: coreDown, stars: stars, victory: stars >= 1, time: Math.round(sim.t * 10) / 10,
        deployed: sim.deployedCount, lost: sim.lost };
    };
    return sim;
  }

  return {
    GRID: GRID, ARENA_MIN: ARENA_MIN, ARENA_MAX: ARENA_MAX, DURATION: DURATION, TURRET_RANGE: TURRET_RANGE, KIND: KIND,
    STRIKE_MAX: STRIKE_MAX, STRIKE_RADIUS: STRIKE_RADIUS, ITEM_RADIUS: ITEM_RADIUS,
    scaleFor: scaleFor, wallCount: wallCount, withWalls: withWalls, buildBase: buildBase, botBase: botBase, playerBase: playerBase,
    inDeployZone: inDeployZone, create: create, rectDist: rectDist
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.QGBattle; }
