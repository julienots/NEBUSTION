/**
 * NEBUSTION - QGMatchmaking
 * Données et formules PURES (aucune dépendance à Phaser, testable sous Node) pour le MATCHMAKING
 * du panneau « Attaquer » du QG : au lieu de choisir soi-même dans une liste figée des 5 empires,
 * le joueur appuie sur « Trouver un adversaire » et le jeu lui TROUVE un ennemi.
 *
 * Ne remplace ni n'invente de nouveaux empires : le pool reste les empires réels de la Galaxie
 * (mêmes QG, mêmes profils, mêmes effets de victoire/défaite déjà gérés par QGAttackManager/BotBases).
 * Deux choses changent :
 *  1) la SÉLECTION n'est plus manuelle : tirage pondéré, plus de chances de tomber sur un empire dont
 *     le niveau est proche du niveau du joueur (déduit du développement de son propre QG) ;
 *  2) l'APPARENCE de la base tirée varie à chaque recherche (une « variante » de disposition, passée
 *     à BotBases.layout) même si c'est le même empire, pour que « la base ennemie » ne soit jamais
 *     identique à la précédente, sans changer sa défense réelle (toujours dérivée de evo/hurt).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.QGMatchmaking = (function () {
  'use strict';

  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  function num(x, def) { x = Number(x); return isFinite(x) ? x : def; }

  // Petit générateur pseudo-aléatoire déterministe (mulberry32) — même patron que BotBases.
  function rng(seed) {
    var a = (seed >>> 0);
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /** Niveau « joueur », sur la même échelle que BotBases.profile (5..41), déduit du développement de son QG. */
  function playerLevel(unlockedCount, maxCells) {
    var evoLike = clamp((num(unlockedCount, 0) / Math.max(1, num(maxCells, 36))) * 8, 0, 8);
    return Math.round(5 + evoLike * 4.5);
  }

  /**
   * Tirage pondéré d'un adversaire parmi les empires encore en jeu : plus son niveau est proche du
   * niveau du joueur, plus il a de chances d'être choisi — sans jamais exclure totalement les autres
   * (poids plancher), pour garder de la variété au fil des recherches.
   * `candidates` : [{ eid, level }, ...]. `seed` : nombre (ex. Date.now()) pour un tirage rejouable.
   * Retourne l'eid choisi, ou null si `candidates` est vide.
   */
  function pickTarget(candidates, playerLvl, seed) {
    if (!candidates || !candidates.length) return null;
    var rand = rng(num(seed, 1));
    var weights = candidates.map(function (c) {
      var d = Math.abs(num(c.level, playerLvl) - num(playerLvl, 0));
      return Math.max(0.08, 1 / (1 + d * 0.28));
    });
    var sum = weights.reduce(function (a, b) { return a + b; }, 0);
    var r = rand() * sum, acc = 0;
    for (var i = 0; i < candidates.length; i++) {
      acc += weights[i];
      if (r <= acc) return candidates[i].eid;
    }
    return candidates[candidates.length - 1].eid;
  }

  /** Identifiant de variante d'apparence (0..999999), à passer en 4e argument de BotBases.layout(). */
  function rollVariant(seed) { return Math.floor(rng(num(seed, 1))() * 1000000); }

  return {
    playerLevel: playerLevel, pickTarget: pickTarget, rollVariant: rollVariant, rng: rng
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.QGMatchmaking; }
