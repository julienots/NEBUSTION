/**
 * NEBUSTION - Social (données pures, testables sous Node, aucune dépendance à Phaser)
 *
 * Contient tout ce qui est DÉTERMINISTE côté « faux joueurs » :
 *  - 160 bots UNIQUES (pseudo, bio, avatar, archétype, rythme de connexion, niveau/puissance qui évoluent) ;
 *  - 14 clans de bots UNIQUES (nom, tag, devise, emblème, membres, niveau) ;
 *  - un chat « vivant » reconstruit à la demande (même minute → mêmes messages, jamais de répétition proche) ;
 *  - réponses des bots aux messages du joueur, duels amicaux, cadeaux, règles du clan.
 * Les VRAIS joueurs et VRAIS clans passent par Firebase (voir js/systems/SocialManager.js).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Social = (function () {
  'use strict';

  // Mettre à true pour afficher un badge « BOT » dans les listes (transparence envers les joueurs).
  var SHOW_BOT_TAG = false;

  var BOT_COUNT = 160, CLAN_COUNT = 14, CLAN_MAX = 30;
  var CFG = {
    GIFT_COST: 100, GIFT_DAILY: 5, GIFT_BACK_RATIO: 0.7, DUEL_DAILY: 5,
    CLAN_CREATE_COST: 2000, CLAN_DONATE: 500, CLAN_DONATE_XP: 50, CLAN_DONATE_DAILY: 4,
    ONLINE_MS: 150000, CHAT_MAX: 140, CHAT_SLOT_MS: 40000
  };

  function rngOf(seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function hash(str) {
    var h = 2166136261 >>> 0;
    for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    return h >>> 0;
  }
  function pick(r, arr) { return arr[Math.floor(r() * arr.length) % arr.length]; }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function dayOf(now) { return Math.floor(now / 86400000); }

  // ---------------------------------------------------------------- Pseudos
  var PRE = ['Kael', 'Nyx', 'Vor', 'Zen', 'Astra', 'Drak', 'Lum', 'Xan', 'Orb', 'Ryn', 'Sol', 'Thal', 'Umbr', 'Vex', 'Zor', 'Aer', 'Bael', 'Cry', 'Dex', 'Elar',
    'Fen', 'Gal', 'Hex', 'Ion', 'Jax', 'Kry', 'Lyr', 'Myr', 'Neb', 'Oxi', 'Pyr', 'Quas', 'Rho', 'Syl', 'Tor', 'Ulr', 'Val', 'Wyr', 'Yor', 'Zeph',
    'Ark', 'Bor', 'Cyr', 'Dar', 'Eon', 'Fyr', 'Gra', 'Hyd', 'Ith', 'Kor', 'Lex', 'Mor', 'Nov', 'Omn', 'Pra', 'Rax', 'Sek', 'Tyr', 'Vel', 'Zar'];
  var SUF = ['ix', 'on', 'ara', 'us', 'ion', 'ex', 'yn', 'ar', 'os', 'ia', 'eth', 'ok', 'ul', 'ax', 'is', 'or', 'an', 'el', 'um', 'ith',
    'ora', 'ade', 'ova', 'eon', 'ys', 'oth', 'ire', 'ane', 'ulo', 'ess', 'ark', 'ell', 'yx', 'ova', 'ien', 'osk', 'ast', 'ire', 'orn', 'ura'];
  var ADJ = ['Silent', 'Rogue', 'Lunar', 'Cosmic', 'Frozen', 'Crimson', 'Hollow', 'Nova', 'Feral', 'Astral', 'Rusty', 'Neon', 'Grim', 'Lucky', 'Wild', 'Solar',
    'Vagabond', 'Phantom', 'Iron', 'Velvet', 'Sacré', 'Petit', 'Grand', 'Dernier', 'Fou', 'Sombre', 'Rapide', 'Tranquille', 'Ancien', 'Brisé'];
  var NOUN = ['Comet', 'Reaper', 'Drifter', 'Pilot', 'Wolf', 'Hunter', 'Nomad', 'Falcon', 'Ghost', 'Baron', 'Miner', 'Sniper', 'Raven', 'Titan', 'Sage', 'Viper',
    'Capitaine', 'Corsaire', 'Mineur', 'Renard', 'Voyageur', 'Croiseur', 'Pirate', 'Chasseur', 'Gardien', 'Amiral', 'Astéroïde', 'Pulsar', 'Quasar', 'Météore'];

  function makeName(r) {
    var m = r();
    if (m < 0.34) return pick(r, PRE) + pick(r, SUF);
    if (m < 0.58) return pick(r, ADJ) + '_' + pick(r, NOUN);
    if (m < 0.74) return pick(r, PRE) + pick(r, SUF) + '_' + (10 + Math.floor(r() * 90));
    if (m < 0.86) return 'xX' + pick(r, PRE) + pick(r, SUF) + 'Xx';
    if (m < 0.94) return pick(r, NOUN) + pick(r, PRE) + Math.floor(r() * 999);
    return pick(r, PRE).toLowerCase() + pick(r, SUF) + '.' + pick(r, NOUN).toLowerCase();
  }

  var BIO_A = ['Je farm les cristaux', 'Ancien mineur de Nexus-01', 'Joueur du soir', 'Collectionneur de héros', 'Explorateur du Trou Noir', 'Bâtisseur de QG', 'Chasseur de boss',
    'Ici pour le fun', 'Objectif : top classement', 'Je débute sur NEBUSTION', 'Stratège dans l\'âme', 'Fan de la Nouvelle Galaxie', 'Marchand d\'Éclats', 'Pilote de la flotte',
    'Défenseur du QG', 'Grand amateur d\'expéditions', 'Rôdeur des colonies', 'Papa gamer', 'Étudiant en pause', 'Insomniaque cosmique', 'Joueur casual', 'Joueur compétitif',
    'Toujours en retard sur les mises à jour', 'Mordu du Codex', 'Amoureux des parcelles', 'Roi des caisses', 'Perfectionniste', 'Solitaire mais sympa', 'Touriste galactique', 'Vétéran'];
  var BIO_B = ['— on s\'entraide ?', '— dispo en soirée.', '— pas de rush.', '— GG à tous.', '— cherche un clan actif.', '— venez chatter !', '— le café d\'abord.',
    '— j\'accepte les amis.', '— cadeaux bienvenus 😄', '— duel amical ?', '— toujours prêt.', '— je débloque tout doucement.', '— fier de mon QG.', '— la nuit porte conseil.',
    '— anti-stress spatial.', '— pas de pitié en duel.', '— je réponds vite.', '— level up chaque jour.', '— en route vers le prestige.', '— fan de skins.', '— zéro rage.',
    '— team bonne humeur.', '— je partage mes astuces.', '— rejoins-moi !', '— mode zen.', '— survivant du Trou Noir.', '— jamais sans mes drones.', '— fidèle au poste.', '— vive la Renaissance.', '— à fond !'];

  var ARCH = {
    warrior: { label: 'Guerrier', pw: 1.25, chat: 0.7, hours: [14, 22] },
    builder: { label: 'Bâtisseur', pw: 0.9, chat: 0.5, hours: [9, 18] },
    trader: { label: 'Marchand', pw: 0.8, chat: 0.9, hours: [11, 20] },
    explorer: { label: 'Explorateur', pw: 1.0, chat: 0.6, hours: [17, 25] },
    hoarder: { label: 'Collectionneur', pw: 0.95, chat: 0.4, hours: [8, 15] },
    newbie: { label: 'Recrue', pw: 0.5, chat: 1.0, hours: [15, 23] }
  };
  var ARCH_IDS = Object.keys(ARCH);
  var GLYPHS = ['◆', '✦', '⬢', '▲', '●', '✚', '☄', '⚡', '❖', '✹'];

  // ---------------------------------------------------------------- Génération des bots
  var _bots = null, _botById = null;
  function botsBuild() {
    var used = {}, bios = {}, list = [], i = 0, guard = 0;
    while (list.length < BOT_COUNT && guard++ < 20000) {
      var r = rngOf(0xB07 + i * 7919 + guard);
      var name = makeName(r);
      var key = name.toLowerCase();
      if (used[key] || name.length > 16) continue;
      var bio, tries = 0;
      do { bio = pick(r, BIO_A) + ' ' + pick(r, BIO_B); } while (bios[bio] && ++tries < 40);
      bios[bio] = 1; used[key] = 1;
      var arch = ARCH_IDS[Math.floor(r() * ARCH_IDS.length)];
      var tier = r();
      var hrs = ARCH[arch].hours, start = hrs[0] + Math.floor(r() * 3) - 1;
      list.push({
        id: 'b' + (1000 + list.length), name: name, isBot: true, arch: arch, bio: bio,
        avatar: { hue: Math.floor(r() * 360), glyph: pick(r, GLYPHS), shape: Math.floor(r() * 3) },
        tier: tier, near: r() < 0.45,                       // « near » : puissance calée sur celle du joueur (duels équilibrés)
        basePower: Math.round(250 + Math.pow(tier, 2.2) * 30000 * ARCH[arch].pw),
        joinDay: 20400 + Math.floor(r() * 500),
        tz: Math.floor(r() * 4) - 1, winStart: ((start % 24) + 24) % 24, winLen: 5 + Math.floor(r() * 9),
        chatty: clamp(ARCH[arch].chat * (0.5 + r()), 0.15, 1.4), clanId: null, seed: Math.floor(r() * 1e9)
      });
      i++;
    }
    return list;
  }
  function bots() {
    if (!_bots) {
      _bots = botsBuild(); _botById = {};
      _bots.forEach(function (b) { _botById[b.id] = b; });
      clansBuild();
    }
    return _bots;
  }
  function botById(id) { bots(); return _botById[id] || null; }

  /** Statut selon l'heure : { state:'online'|'away'|'offline', lastSeen:ms }. Déterministe par tranche de 30 min. */
  function botStatus(b, now) {
    now = now || Date.now();
    function blockOnline(t) {
      var d = new Date(t), h = (d.getUTCHours() + b.tz + 24 + 1) % 24 + d.getUTCMinutes() / 60;   // +1 ≈ heure de Paris
      var s = b.winStart, e = s + b.winLen, inWin = (h >= s && h < e) || (e > 24 && h < e - 24);
      if (!inWin) return 0;
      var rr = rngOf(b.seed ^ Math.floor(t / 1800000))();
      return rr < 0.82 ? 2 : (rr < 0.95 ? 1 : 0);   // 2 = en ligne, 1 = absent, 0 = hors ligne
    }
    var now0 = blockOnline(now);
    if (now0 === 2) return { state: 'online', lastSeen: now };
    if (now0 === 1) return { state: 'away', lastSeen: now - 60000 };
    for (var k = 1; k <= 96; k++) {
      if (blockOnline(now - k * 1800000) === 2) return { state: 'offline', lastSeen: now - k * 1800000 + Math.floor(rngOf(b.seed + k)() * 1800000) };
    }
    return { state: 'offline', lastSeen: now - 49 * 3600000 };
  }

  /** Niveau / puissance actuels (évoluent avec les jours ; « near » suit le joueur). */
  function botStats(b, ctx, now) {
    now = now || Date.now(); ctx = ctx || {};
    var days = Math.max(0, dayOf(now) - b.joinDay);
    var growth = 1 + Math.min(2.2, days * 0.0035);
    var power = b.basePower * growth;
    if (b.near && ctx.power > 0) power = ctx.power * (0.6 + b.tier * 1.0) * (1 + ((days % 9) - 4) * 0.01);
    power = Math.max(120, Math.round(power));
    var level = clamp(Math.floor(Math.sqrt(power) / 3.1) + 1, 1, 99);
    return { power: power, level: level, days: days };
  }

  // ---------------------------------------------------------------- Clans de bots
  var CL_A = ['Légion', 'Ordre', 'Confrérie', 'Armada', 'Alliance', 'Escadre', 'Cartel', 'Meute', 'Garde', 'Cercle', 'Flotte', 'Empire', 'Syndicat', 'Fraternité'];
  var CL_B = ['Aube Noire', 'd\'Orion', 'des Cendres', 'Nébuleuse', 'Étoile Brisée', 'du Vide', 'Cristal Vif', 'des Corsaires', 'Ion Rouge', 'de Kaelis', 'Sans Retour', 'du Pulsar', 'Éclipse', 'Andromède',
    'Lames Solaires', 'du Trou Noir', 'des Mineurs', 'Zéro Gravité'];
  var CL_MOTTO = ['Ensemble jusqu\'aux étoiles.', 'On farm, on rit, on gagne.', 'Forts ensemble.', 'Actifs chaque jour.', 'Respect avant tout.', 'Pas de clan sans entraide.',
    'Le QG ne tombe jamais.', 'Bienvenue aux nouveaux.', 'Discipline et bonne humeur.', 'Toujours un pas devant.', 'Le silence avant la tempête.', 'On explore, on partage.', 'Casual mais redoutables.', 'Cristaux pour tous.'];
  var CL_COL = [0xff4d6d, 0x4fc3ff, 0xffd166, 0x5fd97a, 0xb28dff, 0xff9f43, 0x00e5ff, 0xff7bd1, 0x9ad1ff, 0xf6e05e, 0x7bed9f, 0xff6b81, 0x70a1ff, 0xeccc68];
  var _clans = null, _clanById = null;

  function tagOf(name, taken) {
    var letters = name.replace(/[^A-Za-zÀ-ÿ ]/g, '').split(' ').filter(Boolean);
    var t = (letters[0][0] + (letters[1] ? letters[1][0] : letters[0][1]) + (letters[letters.length - 1][0] || 'X')).toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    var n = 0, base = t;
    while (taken[t]) { n++; t = base.slice(0, 2) + String.fromCharCode(65 + (n % 26)); if (n > 60) t = base + n; }
    return t;
  }
  function clansBuild() {
    var used = {}, tags = {}, mottos = {}, list = [], guard = 0;
    while (list.length < CLAN_COUNT && guard++ < 5000) {
      var r = rngOf(0xC1A + guard * 104729 + list.length);
      var name = pick(r, CL_A) + ' ' + pick(r, CL_B);
      if (used[name]) continue;
      used[name] = 1;
      var motto = CL_MOTTO[list.length % CL_MOTTO.length];
      var tag = tagOf(name, tags); tags[tag] = 1;
      list.push({ id: 'c' + (100 + list.length), name: name, tag: tag, motto: motto, isBot: true,
        color: CL_COL[list.length % CL_COL.length], glyph: GLYPHS[(list.length * 3) % GLYPHS.length],
        minLevel: [1, 1, 3, 5, 8, 12, 1, 4, 6, 10, 15, 2, 7, 20][list.length % 14], open: list.length % 5 !== 4, members: [], seed: Math.floor(r() * 1e9) });
    }
    _clans = list; _clanById = {};
    list.forEach(function (c) { _clanById[c.id] = c; });
    // Répartition des bots : ~72 % appartiennent à un clan, 8 à 26 membres par clan
    var caps = {}; list.forEach(function (c, i) { caps[c.id] = 8 + Math.floor(rngOf(c.seed)() * 18); });
    _bots.forEach(function (b, i) {
      if (rngOf(b.seed + 5)() > 0.72) return;
      var c = list[hash(b.id) % list.length], tries = 0;
      while (c.members.length >= caps[c.id] && tries++ < list.length) c = list[(list.indexOf(c) + 1) % list.length];
      if (c.members.length < caps[c.id]) { c.members.push(b.id); b.clanId = c.id; }
    });
    list.forEach(function (c) {
      c.members.sort(function (a, b) { return _botById[b].basePower - _botById[a].basePower; });
      c.leader = c.members[0];
    });
  }
  function botClans() { bots(); return _clans; }
  function botClanById(id) { bots(); return _clanById[id] || null; }

  /** Vue d'un clan de bot : membres avec rôle, puissance totale, niveau. */
  function botClanView(id, ctx, now) {
    var c = botClanById(id); if (!c) return null;
    var total = 0;
    var members = c.members.map(function (bid, i) {
      var b = _botById[bid], st = botStats(b, ctx, now);
      total += st.power;
      return { id: b.id, name: b.name, isBot: true, power: st.power, level: st.level, role: i === 0 ? 'leader' : (i < 4 ? 'officer' : 'member'), status: botStatus(b, now).state };
    });
    var xp = Math.round(total / 6);
    return { id: c.id, name: c.name, tag: c.tag, motto: c.motto, color: c.color, glyph: c.glyph, isBot: true, minLevel: c.minLevel, open: c.open,
      members: members, size: members.length, power: total, xp: xp, level: clanLevel(xp), online: members.filter(function (m) { return m.status === 'online'; }).length };
  }
  function clanLevel(xp) { return Math.max(1, Math.floor(Math.sqrt(Math.max(0, xp) / 400)) + 1); }
  function clanLevelProgress(xp) {
    var L = clanLevel(xp), a = 400 * (L - 1) * (L - 1), b = 400 * L * L;
    return { level: L, cur: xp - a, need: b - a, ratio: clamp((xp - a) / (b - a), 0, 1) };
  }
  /** Coffre quotidien du clan : plus le clan est haut, plus c'est riche. */
  function clanChest(level) {
    return { crystal: 300 + level * 120, metal: 200 + level * 80, energy: 100 + level * 40, dust: 20 + level * 6 };
  }

  // ---------------------------------------------------------------- Chat vivant
  var SLOT = {
    planet: ['Nexus-01', 'la Nouvelle Galaxie', 'ma planète', 'la galaxie Écarlate', 'Kaelis'],
    res: ['cristaux', 'métal', 'énergie', 'poussière', 'noyaux'],
    thing: ['le Trou Noir', 'mon QG', 'les expéditions', 'la Forge d\'Éclats', 'les parcelles', 'le Pass', 'la Caserne', 'le Symtor', 'le Codex', 'les colonies'],
    n: ['3', '5', '7', '10', '12', '15', '20']
  };
  var GENERIC = [
    'Salut tout le monde !', 'Bonsoir la team 👋', 'Quelqu\'un a vu le nouvel événement ?', 'Ça farm bien aujourd\'hui.', 'Je viens de finir une expédition, pas mal du tout.',
    'Qui est chaud pour un duel amical ?', 'J\'adore {thing}, franchement.', 'Petite pause café, je reviens.', 'Mon stockage de {res} est plein, encore...', 'Bon courage à tous 💪',
    'Quelqu\'un connaît une astuce pour {thing} ?', 'Je passe niveau {n} bientôt !', 'GG à celui qui m\'a battu tout à l\'heure.', 'Le Trou Noir m\'a coûté ma sonde... encore.',
    'Je cherche un clan actif, des places ?', 'Merci pour le cadeau, c\'est sympa !', 'Ça rame chez moi ou c\'est juste moi ?', 'Bienvenue aux nouveaux !', 'Je fais le tour de {planet}.',
    'Toujours plus de {res}, jamais assez.', 'Quel héros vous montez en premier ?', 'Je crois que je vais tenter le prestige.', 'Bonne nuit les astronautes 🌙', 'Vive NEBUSTION !',
    'Je vends mon âme contre 1000 {res} 😂', 'Quelqu\'un pour m\'expliquer {thing} ?', 'Hier j\'ai eu une caisse énorme.', 'Une petite alliance, ça vous dit ?', 'Encore {n} minutes et je lance mon amélioration.'
  ];
  var BY_ARCH = {
    warrior: ['Mon équipe de combat est enfin niveau {n}.', 'Qui ose m\'affronter en duel ?', 'Je casse les QG ennemis un par un.', 'Les tourelles adverses ne me font plus peur.', 'Mes troupes sont prêtes, à l\'attaque !', 'Encore une victoire, je suis en feu 🔥'],
    builder: ['Je réorganise mon QG, la grille est parfaite.', 'Nouvelle construction sur {planet} !', 'Amélioration du Stockage terminée.', 'Les bâtiments utiles changent tout.', 'Je place mes générateurs près des silos.', 'Mon QG tient bon face aux raids.'],
    trader: ['Je fais un échange ? {res} contre du métal.', 'Les offres de la boutique sont bonnes ce soir.', 'Quelqu\'un veut m\'envoyer des cadeaux ? Je rends la pareille 😉', 'Bon plan : la caisse du jour.', 'Le Comptoir de l\'Abîme vaut le coup.', 'Je surveille les prix comme un faucon.'],
    explorer: ['Je viens de revenir de {planet}, c\'est magnifique.', 'Le Trou Noir en 3D, c\'est bluffant.', 'Une nouvelle planète découverte !', 'Profondeur {n} atteinte dans l\'abîme.', 'Ma sonde a tenu, incroyable.', 'Les colonies rapportent bien.'],
    hoarder: ['Encore une carte rare ! Ma collection grossit.', 'Il me manque 3 héros pour finir le Codex.', 'Je garde mes {res} pour plus tard.', 'Mes skins sont superbes.', 'J\'économise pour la prochaine caisse.', 'Le Codex avance doucement.'],
    newbie: ['Je débute, des conseils ?', 'Comment on gagne plus de {res} ?', 'C\'est quoi la différence entre héros et troupes ?', 'Waouh ce jeu est beau !', 'J\'ai rejoint hier, déjà accro.', 'Où trouver le Pass ?']
  };
  var CLAN_LINES = ['On fait la collecte du coffre ce soir ?', 'Pensez à donner pour monter le niveau du clan !', 'Bien joué à tous pour le classement.', 'Qui peut m\'aider sur {thing} ?',
    'Le clan est au top, merci les gars.', 'Nouveau membre ? Bienvenue chez nous 🎉', 'Rappel : soyez actifs, on grimpe.', 'J\'ai donné mes {res}, à vous !', 'Petit objectif : niveau de clan supérieur cette semaine.', 'Gardons la bonne ambiance.'];

  function fill(t, r) {
    return t.replace(/\{(\w+)\}/g, function (m, k) { return SLOT[k] ? pick(r, SLOT[k]) : m; });
  }
  function botLine(b, r, kind) {
    var pool = (kind === 'clan' && r() < 0.5) ? CLAN_LINES : (r() < 0.55 ? BY_ARCH[b.arch] : GENERIC);
    return fill(pick(r, pool), r);
  }

  /**
   * Historique déterministe d'un canal : mêmes messages pour la même tranche de temps, jamais deux fois le même texte de suite.
   * opts : { pool: [bot...], kind:'global'|'clan', slots: 70, density: 0.5 }
   */
  function chatHistory(channel, now, opts) {
    opts = opts || {};
    var pool = opts.pool || bots(), kind = opts.kind || 'global', slots = opts.slots || 70, dens = opts.density !== undefined ? opts.density : 0.5;
    var cur = Math.floor(now / CFG.CHAT_SLOT_MS), out = [], recent = [], lastSpeaker = null, ch = hash(channel);
    for (var s = cur - slots; s <= cur; s++) {
      var r = rngOf(ch ^ Math.imul(s, 2654435761));
      var t = s * CFG.CHAT_SLOT_MS + Math.floor(r() * CFG.CHAT_SLOT_MS * 0.9);
      if (t > now) continue;
      if (r() > dens) continue;
      var cand = [];
      for (var i = 0; i < pool.length; i++) {
        var b = pool[i];
        if (b.id === lastSpeaker) continue;
        if (botStatus(b, t).state !== 'online') continue;
        cand.push(b);
      }
      if (!cand.length) continue;
      // pondération par bavardage
      var tot = 0; cand.forEach(function (b) { tot += b.chatty; });
      var x = r() * tot, sp = cand[0];
      for (var j = 0; j < cand.length; j++) { x -= cand[j].chatty; if (x <= 0) { sp = cand[j]; break; } }
      var text = '', tries = 0;
      do { text = botLine(sp, r, kind); } while (recent.indexOf(text) >= 0 && ++tries < 8);
      recent.push(text); if (recent.length > 40) recent.shift();
      lastSpeaker = sp.id;
      out.push({ id: channel + ':' + s, t: t, from: sp.id, name: sp.name, text: text, isBot: true });
    }
    return out;
  }

  var REPLY = [
    { re: /\b(salut|bonjour|bonsoir|hello|coucou|yo|hey)\b/i, a: ['Salut ! 👋', 'Hello, bienvenue !', 'Coucou, ça va ?', 'Yo ! Tu joues depuis longtemps ?'] },
    { re: /\b(aide|help|conseil|comment|astuce)\b/i, a: ['Investis d\'abord dans le Stockage, ça change tout.', 'Fais tes expéditions avant de dormir, elles tournent seules.', 'Pense à récolter les caisses de ravitaillement !', 'Mets à niveau tes extracteurs avant les bâtiments de déco.'] },
    { re: /\b(clan|guilde|rejoindre|recrut)/i, a: ['Va dans l\'onglet Clan, il y en a plein qui recrutent !', 'Un clan actif = un coffre par jour, ça vaut le coup.', 'Choisis un clan avec un bon niveau, c\'est plus riche.'] },
    { re: /\b(merci|thx|thanks)\b/i, a: ['De rien !', 'Avec plaisir 😊', 'Pas de souci !'] },
    { re: /\b(gg|bravo|félicitations|felicitations)\b/i, a: ['GG à toi aussi !', 'Merci ! 💪', 'On continue !'] },
    { re: /\b(duel|combat|battre|affront)/i, a: ['Ouvre mon profil et lance un duel !', 'Je suis chaud, mais je ne te ferai pas de cadeau 😄', 'Ça marche, prépare ton équipe.'] },
    { re: /\b(cadeau|gift|offre)/i, a: ['Envoie-moi un cadeau depuis mon profil, je te rendrai la pareille !', 'Un cadeau ? Avec plaisir, je te renvoie le mien.'] },
    { re: /\?\s*$/, a: ['Bonne question... je dirais que ça dépend de ton équipe.', 'Aucune idée, mais je suis curieux aussi !', 'Je crois que oui, à vérifier.'] }
  ];
  var REPLY_GEN = ['Ah oui ?', 'Pas faux 😄', 'Intéressant.', 'Je suis d\'accord.', 'Haha ok.', 'Moi aussi, en ce moment.', 'On verra bien !', 'Clairement.'];
  function botReply(b, text, seed) {
    var r = rngOf((seed >>> 0) ^ b.seed);
    for (var i = 0; i < REPLY.length; i++) if (REPLY[i].re.test(text || '')) return pick(r, REPLY[i].a);
    return pick(r, REPLY_GEN);
  }

  /** Un bot répond-il à ce message ? Renvoie { bot, text, delayMs } ou null. */
  function chatReply(channel, playerText, now, pool) {
    pool = pool || bots();
    var r = rngOf(hash(channel) ^ hash(String(playerText)) ^ Math.floor(now / 1000));
    if (r() > 0.75) return null;
    var cand = pool.filter(function (b) { return botStatus(b, now).state === 'online'; });
    if (!cand.length) return null;
    var b = pick(r, cand);
    return { bot: b, text: botReply(b, playerText, Math.floor(r() * 1e9)), delayMs: 1800 + Math.floor(r() * 4200) };
  }

  // ---------------------------------------------------------------- Interactions
  function duelChance(playerPower, botPower) {
    var pp = Math.max(50, playerPower), bp = Math.max(50, botPower);
    return clamp(1 / (1 + Math.exp(-2.2 * Math.log(pp / bp))), 0.08, 0.92);
  }
  function duel(playerPower, botPower, seed) {
    var ch = duelChance(playerPower, botPower);
    var win = rngOf(seed >>> 0)() < ch;
    return { win: win, chance: ch };
  }
  function duelReward(botLevel, win) {
    return win ? { crystal: 120 + botLevel * 8, metal: 30 + botLevel * 3 } : { crystal: 20 };
  }
  function giftBack(botSeed, day) {
    var r = rngOf(botSeed ^ Math.imul(day, 40503));
    return r() < 0.6 ? { crystal: Math.round(CFG.GIFT_COST * CFG.GIFT_BACK_RATIO), delayMs: 60000 + Math.floor(r() * 540000) } : null;
  }

  // ---------------------------------------------------------------- Textes / validation
  var BAD = /(connard|salop|encul|pute|fdp|nazi|pd\b|ntm|nique|merde)/i;
  function cleanText(s) {
    s = String(s == null ? '' : s).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim();
    if (s.length > CFG.CHAT_MAX) s = s.slice(0, CFG.CHAT_MAX);
    return s;
  }
  function chatAllowed(s) { s = cleanText(s); return s.length > 0 && !BAD.test(s); }
  function cleanName(s, max) {
    s = String(s == null ? '' : s).replace(/[^\w\u00C0-\u017F .'\-]/g, '').replace(/\s+/g, ' ').trim();
    return s.slice(0, max || 16);
  }
  function validName(s) { var raw = String(s == null ? '' : s).replace(/\s+/g, ' ').trim(), c = cleanName(raw, 16); return c.length >= 3 && c === raw && !BAD.test(c); }
  function validTag(s) { return /^[A-Z0-9]{2,4}$/.test(s); }
  function agoText(ms) {
    var m = Math.floor(ms / 60000);
    if (m < 1) return 'à l\'instant';
    if (m < 60) return 'il y a ' + m + ' min';
    var h = Math.floor(m / 60);
    if (h < 24) return 'il y a ' + h + ' h';
    return 'il y a ' + Math.floor(h / 24) + ' j';
  }
  function defaultName(uidOrSeed) {
    var r = rngOf(hash(String(uidOrSeed || Math.random())));
    return 'Commandant' + (100 + Math.floor(r() * 900));
  }

  function defaultState() {
    return { v: 1, name: '', friends: [], clan: null, gifts: { day: 0, n: 0 }, duels: { day: 0, n: 0 }, donate: { day: 0, n: 0 }, lastChest: 0, inbox: [], wins: 0, sentTotal: 0 };
  }
  /** État valide à partir de données brutes ou abîmées. */
  function normalizeState(raw) {
    var s = defaultState();
    if (!raw || typeof raw !== 'object') return s;
    s.name = cleanName(raw.name, 16);
    s.friends = Array.isArray(raw.friends) ? raw.friends.filter(function (x) { return typeof x === 'string'; }).slice(0, 100) : [];
    if (raw.clan && typeof raw.clan === 'object' && typeof raw.clan.id === 'string') s.clan = { id: raw.clan.id, kind: raw.clan.kind === 'real' ? 'real' : 'bot', name: cleanName(raw.clan.name, 20), tag: String(raw.clan.tag || '').slice(0, 4), role: raw.clan.role || 'member', joinedAt: Number(raw.clan.joinedAt) || 0 };
    ['gifts', 'duels', 'donate'].forEach(function (k) { if (raw[k] && typeof raw[k] === 'object') s[k] = { day: Number(raw[k].day) || 0, n: Number(raw[k].n) || 0 }; });
    s.lastChest = Number(raw.lastChest) || 0;
    s.wins = Number(raw.wins) || 0; s.sentTotal = Number(raw.sentTotal) || 0;
    s.inbox = Array.isArray(raw.inbox) ? raw.inbox.filter(function (m) { return m && typeof m.id === 'string'; }).slice(-30).map(function (m) {
      return { id: m.id, from: String(m.from || ''), name: cleanName(m.name, 16), res: m.res || 'crystal', amount: Math.max(0, Math.min(5000, Number(m.amount) || 0)), t: Number(m.t) || 0, real: !!m.real };
    }) : [];
    return s;
  }

  return {
    CFG: CFG, ARCH: ARCH, SHOW_BOT_TAG: SHOW_BOT_TAG, CLAN_MAX: CLAN_MAX,
    bots: bots, botById: botById, botStatus: botStatus, botStats: botStats,
    botClans: botClans, botClanById: botClanById, botClanView: botClanView,
    clanLevel: clanLevel, clanLevelProgress: clanLevelProgress, clanChest: clanChest,
    chatHistory: chatHistory, chatReply: chatReply, botReply: botReply,
    duelChance: duelChance, duel: duel, duelReward: duelReward, giftBack: giftBack,
    cleanText: cleanText, chatAllowed: chatAllowed, cleanName: cleanName, validName: validName, validTag: validTag,
    agoText: agoText, defaultName: defaultName, defaultState: defaultState, normalizeState: normalizeState,
    dayOf: dayOf, hash: hash, rngOf: rngOf
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.Social; }
