/**
 * NEBUSTION - CombatItems
 * Catalogue des objets/consommables utilisables PENDANT un combat (combat principal contre
 * ennemis/boss ET assaut de QG). Chaque objet a un nombre de charges limité pour le combat en
 * cours (rechargé au combat suivant) ; ce n'est PAS un système d'inventaire persistant.
 *
 * `effect` (combat principal, lu par CombatEngine.useItem) :
 *  - heal      : soigne toute l'équipe de `power` % de ses PV max
 *  - shield    : bouclier sur toute l'équipe, `power` (facteur d'ATQ) pendant `duration` s
 *  - buffAtk   : +`power` (fraction) d'ATQ pour toute l'équipe pendant `duration` s
 *  - stunAoe   : étourdit tous les ennemis `duration` s + dégâts `power` (facteur d'ATQ moyenne)
 *
 * `qgEffect` (assaut de QG, lu par QGBattle.useItem, ciblé à un point x/y de l'arène) :
 *  - qgDamage  : dégâts de zone aux structures dans `radius`
 *  - qgHeal    : soigne les troupes dans `radius` de `power` % de leurs PV max
 *  - qgShield  : réduit les dégâts subis (tourelles) des troupes dans `radius` pendant `duration` s
 *  - qgRage    : +`power` (fraction) de dégâts des troupes dans `radius` pendant `duration` s
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.CombatItems = (function () {
  'use strict';

  var DEFS = {
    medkit: {
      id: 'medkit', name: 'Kit de soin', icon: '🩹',
      desc: 'Soigne toute l\'équipe de 20 % de ses PV max.',
      defaultCharges: 1,
      effect: 'heal', power: 0.20,
      qgEffect: 'qgHeal', radius: 1.6, qgPower: 0.4
    },
    shield_drone: {
      id: 'shield_drone', name: 'Drone-bouclier', icon: '🛡️',
      desc: 'Place un bouclier sur toute l\'équipe pendant 4 s.',
      defaultCharges: 1,
      effect: 'shield', power: 1.4, duration: 4,
      qgEffect: 'qgShield', radius: 1.6, duration_qg: 4
    },
    overcharge_cell: {
      id: 'overcharge_cell', name: 'Cellule de surcharge', icon: '⚡',
      desc: '+20 % de dégâts pour toute l\'équipe pendant 5 s.',
      defaultCharges: 1,
      effect: 'buffAtk', power: 0.20, duration: 5,
      qgEffect: 'qgRage', radius: 1.6, qgPower: 0.5, duration_qg: 5
    },
    emp_grenade: {
      id: 'emp_grenade', name: 'Grenade EMP', icon: '💥',
      desc: 'Étourdit tous les ennemis 1,2 s et inflige des dégâts.',
      defaultCharges: 1,
      effect: 'stunAoe', power: 0.35, duration: 1.2,
      qgEffect: 'qgDamage', radius: 1.4, qgPower: 150
    }
  };

  function list() { return Object.keys(DEFS).map(function (k) { return DEFS[k]; }); }
  function get(id) { return DEFS[id] || null; }

  return { DEFS: DEFS, list: list, get: get };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.CombatItems; }
