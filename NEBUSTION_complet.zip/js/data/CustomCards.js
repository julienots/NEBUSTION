/* NEBUSTION — cartes personnalisées
 * Contrat sûr: les cartes importées sont validées avant utilisation.
 * Le jeu peut charger un tableau depuis assets/data/custom_cards.json.
 */
(function(){
  const MAX_NAME=40, MAX_DESC=300, MAX_LEVEL=200;
  function cleanNumber(v, fallback=0, max=999999999){ const n=Number(v); return Number.isFinite(n)?Math.max(0,Math.min(max,n)):fallback; }
  function slug(v){ return String(v||'').toLowerCase().replace(/[^a-z0-9_-]/g,'_').slice(0,40); }
  function validate(raw){
    if(!raw || typeof raw!=='object') throw new Error('Carte invalide');
    const name=String(raw.name||'').trim().slice(0,MAX_NAME); if(!name) throw new Error('Nom manquant');
    const id=slug(raw.id||name); if(!id) throw new Error('ID invalide');
    const lvl=raw.level||{}; const max=Math.max(1,Math.min(MAX_LEVEL,Math.round(cleanNumber(lvl.max,50,MAX_LEVEL)))); const start=Math.max(1,Math.min(max,Math.round(cleanNumber(lvl.start,1,max))));
    const s=raw.stats||{}, l1=s.level1||{}, g=s.growthPerLevel||{};
    return Object.freeze({schemaVersion:1,type:'nebustion_card',id,name,rarity:String(raw.rarity||'Commun').slice(0,20),description:String(raw.description||'').slice(0,MAX_DESC),image:typeof raw.image==='string'&&raw.image.startsWith('data:image/')?raw.image:'',level:{start,max},stats:{level1:{hp:cleanNumber(l1.hp),attack:cleanNumber(l1.attack),defense:cleanNumber(l1.defense),speed:cleanNumber(l1.speed,0,999999),special:cleanNumber(l1.special),energy:cleanNumber(l1.energy)},growthPerLevel:{hp:cleanNumber(g.hp),attack:cleanNumber(g.attack),defense:cleanNumber(g.defense),speed:cleanNumber(g.speed,0,999999)}},cost:Object.fromEntries(Object.entries(raw.cost||{}).slice(0,8).map(([k,v])=>[String(k).slice(0,30),cleanNumber(v)])),ability:String(raw.ability||'').slice(0,MAX_DESC)});
  }
  const BUILTIN_CARDS=[];
  // Remarque : "Outsiderz" vivait ici comme carte de démonstration, achetable dans la Boutique
  // mais totalement inerte (aucune trace en Héros/Combat une fois "achetée"). Elle est désormais
  // un vrai héros exclusif de la Boutique — voir js/data/Heroes.js (id: 'outsiderz').
window.NEBUSTION = window.NEBUSTION || {};
window.NebustionCustomCards={
  validate,fromJSON(data){const arr=Array.isArray(data)?data:(Array.isArray(data?.cards)?data.cards:[data]);return arr.map(validate);},
  getStats(card,level){const c=validate(card);const lv=Math.max(1,Math.min(c.level.max,Math.round(level||1)));const d=lv-1;return {hp:c.stats.level1.hp+c.stats.growthPerLevel.hp*d,attack:c.stats.level1.attack+c.stats.growthPerLevel.attack*d,defense:c.stats.level1.defense+c.stats.growthPerLevel.defense*d,speed:c.stats.level1.speed+c.stats.growthPerLevel.speed*d,special:c.stats.level1.special,energy:c.stats.level1.energy};},
  all(){return BUILTIN_CARDS.slice();}
};
// ShopManager (et le reste du jeu) lisent ce module via le namespace NEBUSTION :
// on l'expose donc aussi là, sinon la Boutique ne trouve jamais la liste des cartes.
window.NEBUSTION.NebustionCustomCards = window.NebustionCustomCards;
})();
