/**
 * NEBUSTION - EmpireAI (données + logique pure, sans Phaser, testable sous Node)
 * Module IA 1/2 : personnalité, stratégies et niveaux de difficulté des 5 empires de js/data/Galaxy.js.
 *
 * Ce fichier ne touche à AUCUN état de sauvegarde : chooseStrategy() est une fonction PURE
 * (mêmes entrées → même sortie), appelée par js/systems/EmpireAIManager.js qui, lui, lit la
 * situation réelle (Galaxy + GalaxyManager + Resources) et orchestre le cache/les événements.
 * Cette séparation permet au futur module d'invasion (étape suivante) de réutiliser
 * chooseStrategy() sans dépendre de Phaser ni du DOM.
 *
 * Chaque empire a :
 *  - une PERSONALITY (poids 0..1 dérivés de sa doctrine/trait dans Galaxy.js) qui influence quelle
 *    stratégie il choisit à égalité de situation ;
 *  - 3 STRATEGIES (posture 'balanced' | 'defensive' | 'offensive') avec une fonction when(situation)
 *    → 0..1 qui mesure à quel point la situation appelle cette stratégie ;
 *  - des effets (shieldMult, turretMult, reinforceRate, counterChance) que le futur module
 *    d'invasion pourra appliquer à battleSpec()/defense pour rendre la posture perceptible.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.EmpireAI = (function () {
  'use strict';

  function clamp01(x) { x = Number(x); return isFinite(x) ? Math.max(0, Math.min(1, x)) : 0; }

  // ---------- Niveaux de difficulté (mêmes clés que NEBUSTION.Resources.state.combat.difficulty) ----------
  // reactivity   : fréquence/probabilité des réactions (contre-attaques, changements de posture)
  // aggression   : amplifie les effets de posture offensive/défensive
  // reinforceRate: vitesse à laquelle l'empire se renforce après des pertes (préparation étape suivante)
  // thinkDelayMs : temps minimum simulé entre deux ré-évaluations d'un même empire (anti-oscillation)
  var DIFFICULTY_ORDER = ['facile', 'normal', 'difficile', 'cauchemar'];
  var DIFFICULTY = {
    facile:    { reactivity: 0.55, aggression: 0.70, reinforceRate: 0.65, thinkDelayMs: 7000 },
    normal:    { reactivity: 1.00, aggression: 1.00, reinforceRate: 1.00, thinkDelayMs: 4500 },
    difficile: { reactivity: 1.35, aggression: 1.25, reinforceRate: 1.35, thinkDelayMs: 2800 },
    cauchemar: { reactivity: 1.70, aggression: 1.55, reinforceRate: 1.75, thinkDelayMs: 1200 }
  };
  function difficultyProfile(id) { return DIFFICULTY[id] || DIFFICULTY.normal; }

  // ---------- Personnalité : tempérament stratégique de chaque empire (0 = jamais, 1 = toujours) ----------
  // aggression   : penchant pour l'offensive/les représailles
  // defense      : penchant pour le repli/la fortification
  // expansion    : volonté d'étendre son influence sur les mondes neutres/frontaliers
  // opportunism  : saisit les occasions (adversaire affaibli) plutôt que de suivre un plan fixe
  // resilience   : capacité à absorber des pertes sans changer de posture
  // coordination : synchronise ses unités/planètes plutôt que d'agir isolément
  var PERSONALITY = {
    vexor:  { aggression: 0.40, defense: 0.80, expansion: 0.45, opportunism: 0.30, resilience: 0.90, coordination: 0.35 },
    kael9:  { aggression: 0.55, defense: 0.70, expansion: 0.55, opportunism: 0.45, resilience: 0.55, coordination: 0.90 },
    elyra:  { aggression: 0.30, defense: 0.85, expansion: 0.25, opportunism: 0.25, resilience: 0.80, coordination: 0.50 },
    morvak: { aggression: 0.90, defense: 0.40, expansion: 0.85, opportunism: 0.70, resilience: 0.45, coordination: 0.30 },
    nyrah:  { aggression: 0.65, defense: 0.60, expansion: 0.40, opportunism: 0.90, resilience: 0.60, coordination: 0.20 },
    parasite: { aggression: 0.75, defense: 0.35, expansion: 0.95, opportunism: 0.60, resilience: 0.85, coordination: 0.15 }
  };

  /**
   * Situation attendue par when(s) : toutes les valeurs sont normalisées 0..1 par EmpireAIManager.assess().
   *  s.pressure    : présence du joueur dans le secteur de l'empire (scans/visites/secteur débloqué)
   *  s.lossRatio   : proportion des planètes de l'empire déjà conquises par le joueur
   *  s.dominance   : à quel point le joueur est plus fort que le niveau conseillé de l'empire (0 = à niveau)
   *  s.capitalLost : 1 si la capitale est tombée, sinon 0
   */
  var STRATEGIES = {
    vexor: [
      { id: 'vx_production', name: 'Production continue', posture: 'balanced',
        when: function (s) { return 1 - Math.max(s.pressure, s.lossRatio, s.capitalLost); },
        effects: { shieldMult: 1.00, turretMult: 1.00, reinforceRate: 1.00, counterChance: 0.15 },
        text: 'VEXOR fait tourner ses fonderies à rythme normal et répare ses automates entre les vagues.' },
      { id: 'vx_repli', name: 'Repli en fonderie', posture: 'defensive',
        when: function (s) { return clamp01(s.lossRatio * 0.7 + s.pressure * 0.5 + s.capitalLost * 0.4); },
        effects: { shieldMult: 1.30, turretMult: 1.15, reinforceRate: 1.35, counterChance: 0.08 },
        text: 'Les forges se retranchent derrière un blindage renforcé ; la production est redirigée vers la défense.' },
      { id: 'vx_chaine', name: 'Chaîne de montage d\'urgence', posture: 'offensive',
        when: function (s) { return clamp01((s.dominance - 0.1) * 1.3); },
        effects: { shieldMult: 0.95, turretMult: 1.00, reinforceRate: 1.55, counterChance: 0.32 },
        text: 'VEXOR accélère l\'assemblage : les automates sortent des chaînes plus vite et contre-attaquent davantage.' }
    ],
    kael9: [
      { id: 'k9_doctrine', name: 'Doctrine standard', posture: 'balanced',
        when: function (s) { return 1 - Math.max(s.pressure, s.lossRatio, s.capitalLost); },
        effects: { shieldMult: 1.00, turretMult: 1.00, reinforceRate: 1.00, counterChance: 0.18 },
        text: 'La Fédération maintient ses patrouilles coordonnées et sa grille de boucliers habituelle.' },
      { id: 'k9_alerte', name: 'Alerte rouge', posture: 'defensive',
        when: function (s) { return clamp01(s.lossRatio * 0.6 + s.pressure * 0.6 + s.capitalLost * 0.4); },
        effects: { shieldMult: 1.35, turretMult: 1.20, reinforceRate: 1.30, counterChance: 0.12 },
        text: 'Toutes les flottes convergent vers les mondes menacés ; la grille de boucliers passe en renfort mutuel.' },
      { id: 'k9_frappe', name: 'Frappe préventive', posture: 'offensive',
        when: function (s) { return clamp01((s.dominance - 0.15) * 1.1); },
        effects: { shieldMult: 1.05, turretMult: 1.10, reinforceRate: 1.25, counterChance: 0.40 },
        text: 'L\'Amirauté ordonne des frappes coordonnées avant que le joueur ne devienne trop menaçant.' }
    ],
    elyra: [
      { id: 'el_veille', name: 'Veille sereine', posture: 'balanced',
        when: function (s) { return 1 - Math.max(s.pressure, s.lossRatio, s.capitalLost); },
        effects: { shieldMult: 1.00, turretMult: 1.00, reinforceRate: 1.00, counterChance: 0.10 },
        text: 'L\'Ordre veille en silence, sanctuaires ouverts, régénération lente et continue.' },
      { id: 'el_scelle', name: 'Sanctuaire scellé', posture: 'defensive',
        when: function (s) { return clamp01(s.lossRatio * 0.75 + s.pressure * 0.4 + s.capitalLost * 0.5); },
        effects: { shieldMult: 1.55, turretMult: 1.10, reinforceRate: 1.20, counterChance: 0.06 },
        text: 'Les barrières radiantes se referment sur les mondes restants : ELYRA privilégie la protection à tout prix.' },
      { id: 'el_jugement', name: 'Jugement', posture: 'offensive',
        when: function (s) { return clamp01((s.dominance - 0.25) * 0.9 + s.capitalLost * 0.6); },
        effects: { shieldMult: 1.15, turretMult: 1.05, reinforceRate: 1.10, counterChance: 0.22 },
        text: 'L\'Ordre juge la profanation impardonnable : ses Séraphins et Archontes ripostent avec la lumière.' }
    ],
    morvak: [
      { id: 'mo_guerre', name: 'Guerre totale', posture: 'offensive',
        when: function (s) { return 1 - clamp01(s.lossRatio * 0.6 + s.capitalLost * 0.5); },
        effects: { shieldMult: 0.95, turretMult: 1.10, reinforceRate: 1.10, counterChance: 0.35 },
        text: 'La Légion attaque en continu : chaque monde soumis nourrit la prochaine offensive.' },
      { id: 'mo_representailles', name: 'Assaut de représailles', posture: 'offensive',
        when: function (s) { return clamp01(s.pressure * 0.7 + (1 - s.lossRatio) * 0.3); },
        effects: { shieldMult: 1.00, turretMult: 1.25, reinforceRate: 1.20, counterChance: 0.50 },
        text: 'MORVAK riposte sans attendre : chaque incursion déclenche une contre-offensive brutale et immédiate.' },
      { id: 'mo_rassemblement', name: 'Rassemblement des légions', posture: 'defensive',
        when: function (s) { return clamp01(s.lossRatio * 0.9 + s.capitalLost * 0.6); },
        effects: { shieldMult: 1.20, turretMult: 1.30, reinforceRate: 1.60, counterChance: 0.20 },
        text: 'Les légions décimées se regroupent temporairement autour du forge-dieu avant de repartir à l\'assaut.' }
    ],
    nyrah: [
      { id: 'ny_silence', name: 'Silence du Néant', posture: 'balanced',
        when: function (s) { return 1 - Math.max(s.pressure * 0.7, s.lossRatio, s.capitalLost); },
        effects: { shieldMult: 1.00, turretMult: 1.00, reinforceRate: 1.00, counterChance: 0.14 },
        text: 'NYR\'AH observe depuis l\'ombre, drainant lentement l\'énergie des mondes environnants.' },
      { id: 'ny_effondrement', name: 'Effondrement ciblé', posture: 'offensive',
        when: function (s) { return clamp01((s.dominance < 0.05 ? 0.6 : 0) + (1 - s.pressure) * 0.5); },
        effects: { shieldMult: 0.95, turretMult: 1.00, reinforceRate: 1.05, counterChance: 0.38 },
        text: 'Le Néant frappe précisément là où le joueur semble le plus vulnérable, sans jamais s\'exposer.' },
      { id: 'ny_voile', name: 'Voile impénétrable', posture: 'defensive',
        when: function (s) { return clamp01(s.lossRatio * 0.65 + s.pressure * 0.5 + s.capitalLost * 0.45); },
        effects: { shieldMult: 1.45, turretMult: 1.35, reinforceRate: 1.15, counterChance: 0.10 },
        text: 'Le Voile du Néant s\'épaissit : la précision adverse chute encore davantage autour des derniers mondes.' }
    ],
    parasite: [
      { id: 'par_proliferation', name: 'Prolifération', posture: 'offensive',
        when: function (s) { return 1 - clamp01(s.lossRatio * 0.5 + s.capitalLost * 0.4); },
        effects: { shieldMult: 1.00, turretMult: 1.05, reinforceRate: 1.30, counterChance: 0.30 },
        text: 'L\'essaim se répand sans relâche : chaque monde infecté nourrit la prochaine vague de spores.' },
      { id: 'par_regeneration', name: 'Régénération collective', posture: 'defensive',
        when: function (s) { return clamp01(s.lossRatio * 0.8 + s.pressure * 0.4 + s.capitalLost * 0.5); },
        effects: { shieldMult: 1.25, turretMult: 1.15, reinforceRate: 1.50, counterChance: 0.15 },
        text: 'La Reine Écarlate concentre l\'essaim autour du Cœur : la chitine se régénère plus vite que les pertes.' },
      { id: 'par_eclosion', name: 'Éclosion massive', posture: 'offensive',
        when: function (s) { return clamp01((s.dominance - 0.05) * 1.2 + s.pressure * 0.3); },
        effects: { shieldMult: 0.90, turretMult: 1.00, reinforceRate: 1.60, counterChance: 0.45 },
        text: 'Des milliers de spores éclosent d\'un coup : l\'essaim submerge l\'intrus par le nombre.' }
    ]
  };

  function empireIds() {
    return (NEBUSTION.Galaxy && NEBUSTION.Galaxy.EMPIRE_ORDER) ? NEBUSTION.Galaxy.EMPIRE_ORDER.slice() : Object.keys(PERSONALITY);
  }

  function scaleEffects(effects, diff) {
    return {
      shieldMult: Math.round(effects.shieldMult * (1 + (diff.aggression - 1) * 0.35) * 100) / 100,
      turretMult: Math.round(effects.turretMult * (1 + (diff.aggression - 1) * 0.35) * 100) / 100,
      reinforceRate: Math.round(effects.reinforceRate * diff.reinforceRate * 100) / 100,
      counterChance: Math.round(clamp01(effects.counterChance * diff.reactivity) * 100) / 100
    };
  }

  /**
   * Sélectionne la meilleure stratégie d'un empire pour une situation donnée. Fonction PURE.
   * @param {string} eid - id d'empire ('vexor'|'kael9'|'elyra'|'morvak'|'nyrah')
   * @param {object} situation - voir doc au-dessus des STRATEGIES (pressure, lossRatio, dominance, capitalLost)
   * @param {string} [difficultyId='normal'] - une clé de DIFFICULTY_ORDER
   * @returns {{empire,strategy,name,posture,text,score,effects,difficulty}|null}
   */
  function chooseStrategy(eid, situation, difficultyId) {
    var list = STRATEGIES[eid];
    if (!list) return null;
    var s = situation || {};
    var perso = PERSONALITY[eid] || {};
    var diff = difficultyProfile(difficultyId);
    var best = null, bestScore = -1;
    list.forEach(function (strat) {
      var raw = clamp01(strat.when(s));
      // Le tempérament amplifie/atténue l'adéquation brute : à égalité de situation, MORVAK penche
      // vers l'offensive et ELYRA vers la défense, sans jamais ignorer complètement la situation réelle.
      var lean = strat.posture === 'offensive' ? perso.aggression : strat.posture === 'defensive' ? perso.defense : 0.5;
      var score = raw * 0.7 + lean * 0.3;
      // Mémoire (module d'évolution) : un empire récemment blessé se replie plus volontiers, un empire qui vient de tenir ose l'offensive.
      if (strat.posture === 'defensive') score += 0.15 * clamp01(s.hurt);
      else if (strat.posture === 'offensive') score += 0.15 * clamp01(s.momentum) * (perso.aggression || 0.5);
      if (score > bestScore) { bestScore = score; best = strat; }
    });
    if (!best) return null;
    return {
      empire: eid, strategy: best.id, name: best.name, posture: best.posture, text: best.text,
      score: Math.round(bestScore * 100) / 100,
      effects: scaleEffects(best.effects, diff),
      difficulty: DIFFICULTY_ORDER.indexOf(difficultyId) >= 0 ? difficultyId : 'normal'
    };
  }

  return {
    DIFFICULTY_ORDER: DIFFICULTY_ORDER, DIFFICULTY: DIFFICULTY, PERSONALITY: PERSONALITY, STRATEGIES: STRATEGIES,
    difficultyProfile: difficultyProfile, empireIds: empireIds, chooseStrategy: chooseStrategy, clamp01: clamp01
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.EmpireAI; }
