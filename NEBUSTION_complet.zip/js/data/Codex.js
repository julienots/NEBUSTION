/**
 * NEBUSTION - Codex (données pures, sans Phaser)
 * Chronique narrative qui relie les systèmes existants (Combat/Hérauts, module Nebustion,
 * Événements, Expéditions, Raids de QG, Renaissance, Symtor) à UNE seule menace de fond :
 * NEBUSTION, une corruption cosmique qui ronge le secteur depuis avant l'arrivée du joueur.
 *
 * Ce fichier n'ajoute AUCUN nouveau système de jeu : il ne fait que donner un sens aux
 * systèmes déjà présents, sous forme d'entrées débloquées par leur progression réelle
 * (victoires de Combat, jauge/état du module Nebustion, nombre de Renaissances).
 *
 * Comme Nebustion.js/Economy.js : JavaScript pur, testable sous Node (tests/codex.test.js).
 * `unlock(ctx)` lit un contexte fourni par l'appelant (CodexManager en jeu ; un objet simulé
 * dans les tests) — AUCUNE dépendance directe à NEBUSTION.Resources ici.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Codex = (function () {
  'use strict';

  // ---------- Chapitres (regroupement de l'onglet « Récit ») ----------
  var CHAPTERS = [
    { id: 0, name: 'Prologue' },
    { id: 1, name: 'Acte I — Les Hérauts' },
    { id: 2, name: 'Acte II — La Révélation' },
    { id: 3, name: 'Acte III — L\'Endiguement' },
    { id: 4, name: 'Acte IV — Les Cycles' }
  ];

  function stars(ctx, stageId) {
    try { return (ctx.stageStars && ctx.stageStars(stageId)) || 0; } catch (e) { return 0; }
  }
  function neb(ctx) { return (ctx && ctx.nebustion) || {}; }

  // ---------- Onglet « Récit » : chronologie gagnée par la progression réelle ----------
  var STORY = [
    {
      id: 'prologue', chapter: 0,
      title: 'Nexus-01',
      hint: null,
      unlock: function () { return true; },
      body: 'Vous commandez Nexus-01, un avant-poste au bord du secteur. Les gisements sont ' +
        'riches, les drones tournent, l\'empire commence à peine. Rien, dans les rapports, ne ' +
        'laisse deviner ce qui approche — seulement des anomalies qu\'on classe encore comme ' +
        'des incidents isolés : une flotte fantôme, une ruée de cristaux instable, un orage ' +
        'quantique trop régulier pour être naturel. On y reviendra.'
    },
    {
      id: 'herald_vorath', chapter: 1,
      title: 'VORATH, Dévoreur d\'Étoiles',
      hint: 'Vaincre VORATH en Combat.',
      unlock: function (ctx) { return stars(ctx, 'boss_vorath') > 0; },
      body: 'Le premier signal fort n\'était pas une flotte : c\'était une seule entité, VORATH, ' +
        'assez massive pour vider une étoile de sa lumière en une orbite. Vous l\'avez abattu. ' +
        'Le secteur a soufflé — mais les capteurs de Nexus-01 ont continué d\'enregistrer, ' +
        'pendant des semaines, une lente dérive de fond, comme si quelque chose de plus grand ' +
        'avait simplement retiré une main.'
    },
    {
      id: 'herald_nexus', chapter: 1,
      title: 'NEXUS PRIME, l\'Intelligence Centrale',
      hint: 'Vaincre NEXUS PRIME en Combat.',
      unlock: function (ctx) { return stars(ctx, 'boss_nexus_prime') > 0; },
      body: 'NEXUS PRIME ne combattait pas comme un animal traqué : il calculait, froidement, ' +
        'sacrifiant des unités entières pour des gains minuscules. Depuis sa chute, les IA des ' +
        'empires rivaux du secteur affichent la même froideur — les mêmes ouvertures optimales, ' +
        'les mêmes sacrifices calculés. Coïncidence de conception, ou fragment d\'une même ' +
        'logique semée ailleurs ?'
    },
    {
      id: 'herald_omega', chapter: 1,
      title: 'OMEGA-KRELL, Le Cataclysme',
      hint: 'Vaincre OMEGA-KRELL en Combat.',
      unlock: function (ctx) { return stars(ctx, 'boss_omega_krell') > 0; },
      body: 'OMEGA-KRELL ne cherchait pas à gagner : il cherchait à durer assez longtemps pour ' +
        'que quelque chose derrière lui finisse de s\'éveiller. Sa défaite n\'a pas fermé un ' +
        'dossier. Elle en a ouvert un autre : les capteurs de Nexus-01 captent, pour la première ' +
        'fois, une jauge — une présence diffuse, partout dans le secteur, en lente montée.'
    },
    {
      id: 'revelation', chapter: 2,
      title: 'NEBUSTION',
      hint: 'Débloquer le module Nebustion (vaincre OMEGA-KRELL).',
      unlock: function (ctx) { return !!neb(ctx).unlocked; },
      body: 'VORATH, NEXUS PRIME, OMEGA-KRELL : trois « boss » distincts dans les rapports de ' +
        'combat, un seul et même émissaire dans les faits. NEBUSTION n\'est pas une flotte ni un ' +
        'empire — c\'est une corruption cosmique qui s\'étend en silence, sector par secteur, ' +
        'depuis bien avant l\'arrivée de Nexus-01. Les Hérauts n\'étaient que ses gants. Ce que ' +
        'vous croyiez être trois victoires n\'était que le retrait de trois doigts.'
    },
    {
      id: 'blackhole_echo', chapter: 2,
      title: 'Ce que l\'Horizon murmure',
      hint: 'Atteindre la profondeur 5 dans le Trou Noir.',
      unlock: function (ctx) { return (ctx.blackHoleMaxDepth || 0) >= 5; },
      body: 'Les premières plongées au-delà de l\'horizon ramenaient surtout des curiosités : ' +
        'reliques figées, échos de matière compressée. Plus loin, les rapports changent de ton. ' +
        'Les capteurs y détectent une signature de fond identique, presque trait pour trait, à ' +
        'celle que Nexus-01 associe désormais à NEBUSTION — comme si le trou noir n\'était pas ' +
        'né dans ce secteur, mais y avait simplement été attiré.'
    },
    {
      id: 'sanctuary', chapter: 3,
      title: 'Le Sanctuaire',
      hint: 'Construire le Sanctuaire (onglet Nebustion).',
      unlock: function (ctx) { return (neb(ctx).sanctuaryLevel || 0) > 0; },
      body: 'On ne repousse pas NEBUSTION par la force brute — sa jauge continue de monter quoi ' +
        'que l\'on fasse. Le Sanctuaire est un pari différent : il puise dans la même énergie ' +
        'que la corruption exploite, et la retourne contre elle. Chaque niveau ne l\'arrête pas, ' +
        'il achète du temps. C\'est tout ce que le secteur peut espérer, pour l\'instant.'
    },
    {
      id: 'outposts', chapter: 3,
      title: 'Avant-postes corrompus',
      hint: 'Vaincre un avant-poste corrompu (Alpha, Beta ou Gamma).',
      unlock: function (ctx) {
        return stars(ctx, 'corruption_outpost_1') > 0 || stars(ctx, 'corruption_outpost_2') > 0 || stars(ctx, 'corruption_outpost_3') > 0;
      },
      body: 'Là où la jauge monte le plus vite, NEBUSTION prend pied physiquement : des avant-' +
        'postes corrompus, hérissés de sentinelles greffées et de colosses assimilés. Les vaincre ' +
        'ne fait pas que gagner du terrain — chaque victoire arrache un fragment de la corruption ' +
        'elle-même, l\'Éclat Souillé, et fait redescendre la jauge d\'autant. Plus elle est haute, ' +
        'plus ils sont durs à reprendre : le temps ne joue jamais pour vous.'
    },
    {
      id: 'symtor_dilemma', chapter: 3,
      title: 'Le dilemme du Symtor',
      hint: 'Nourrir le Symtor avec de l\'Éclat Souillé (onglet Nebustion, module Symtor).',
      unlock: function (ctx) { return (neb(ctx).symtorFeeds || 0) > 0; },
      body: 'L\'Éclat Souillé n\'est pas qu\'une monnaie de combat : c\'est un fragment vivant de ' +
        'NEBUSTION. Le nourrir au Symtor le fait grandir plus vite qu\'aucune ressource propre — ' +
        'mais chaque repas laisse une trace, une Résonance qui ne redescend jamais d\'elle-même. ' +
        'Le compagnon que vous élevez depuis le début pourrait bien être en train d\'apprendre, ' +
        'petit à petit, à obéir à autre chose que vous.'
    },
    {
      id: 'symtor_corrupted', chapter: 3,
      title: 'Symtor corrompu',
      hint: 'Laisser la Résonance du Symtor atteindre 100 %.',
      unlock: function (ctx) { return !!neb(ctx).symtorCorrupted; },
      body: 'La Résonance a atteint son maximum : le Symtor est corrompu. Il continue de se battre ' +
        'à vos côtés — mais chaque heure qui passe, il « appelle » NEBUSTION un peu plus fort, ' +
        'et la jauge de corruption grimpe plus vite tant qu\'il reste dans cet état. Seule une ' +
        'relique de toute fin de partie, la Larme de Purification, est censée pouvoir l\'en ' +
        'libérer — elle n\'a encore été vue nulle part dans le secteur.'
    },
    {
      id: 'renaissance_cycle', chapter: 4,
      title: 'Ce que la Renaissance n\'efface pas',
      hint: 'Effectuer une première Renaissance galactique.',
      unlock: function (ctx) { return (ctx.prestigeCount || 0) > 0; },
      body: 'Une Renaissance efface les étoiles de combat, les territoires conquis, les empires ' +
        'rivaux du cycle — tout repart de zéro, contre des Reliques cosmiques permanentes. Tout, ' +
        'sauf une chose : la jauge de corruption de NEBUSTION continue de monter, exactement là ' +
        'où elle en était. Le Sanctuaire construit et l\'Éclat Souillé amassé restent, eux aussi. ' +
        'Une Renaissance n\'est pas une victoire sur NEBUSTION. C\'est le secteur qui recommence ' +
        'pendant que la menace, elle, ne recommence jamais.'
    },
    {
      id: 'renaissance_veteran', chapter: 4,
      title: 'Commandant de plusieurs cycles',
      hint: 'Effectuer 3 Renaissances galactiques.',
      unlock: function (ctx) { return (ctx.prestigeCount || 0) >= 3; },
      body: 'Trois cycles, trois secteurs reconstruits, trois fois les mêmes Hérauts abattus à ' +
        'nouveau. Ce qui ne change jamais, d\'un cycle à l\'autre, c\'est la jauge — et le sentiment ' +
        'de plus en plus net qu\'on ne repousse pas NEBUSTION en reconstruisant plus vite. On ne ' +
        'fait que retarder le moment où il faudra l\'affronter pour de bon, avec tout ce qui a été ' +
        'patiemment conservé : les héros, l\'équipement, le Sanctuaire.'
    },
    {
      id: 'boss_nebustion_defeated', chapter: 4,
      title: 'Une main coupée, pas un cœur percé',
      hint: 'Vaincre le stage final NEBUSTION, l\'Éveil Primordial.',
      unlock: function (ctx) { return stars(ctx, 'boss_nebustion') > 0; },
      body: 'Vous avez vaincu NEBUSTION là où il s\'est manifesté — et pourtant, la jauge du ' +
        'secteur n\'est pas retombée à zéro. Ce combat n\'a pas tué la corruption : il en a ' +
        'sectionné une manifestation locale, comme les Hérauts avant lui. Ce qui reste à découvrir, ' +
        'c\'est s\'il existe seulement un « cœur » à atteindre, ou si NEBUSTION est, par nature, ' +
        'une chose sans centre — une main coupée qui repousse ailleurs.'
    },
    {
      id: 'blackhole_core', chapter: 4,
      title: 'Le Noyau ne contient rien — il attend',
      hint: 'Atteindre la profondeur 20 dans le Trou Noir.',
      unlock: function (ctx) { return (ctx.blackHoleMaxDepth || 0) >= 20; },
      body: 'À cette profondeur, les instruments cessent de mesurer une singularité et commencent ' +
        'à mesurer une intention. Rien n\'y est dévoré au hasard : les Fragments récoltés portent ' +
        'la même froideur calculée que NEXUS PRIME, la même patience que OMEGA-KRELL. Peut-être que ' +
        'le trou noir n\'est pas un phénomène que NEBUSTION a corrompu en passant, mais l\'endroit ' +
        'précis d\'où tout, dans ce secteur, a commencé à être observé.'
    }
  ];

  // ---------- Onglet « Connexions » : pourquoi chaque système existe (toujours visible) ----------
  var CONNECTIONS = [
    {
      id: 'link_events', title: 'Pourquoi les Événements reviennent',
      body: 'Invasion Voidique, Ruée de Cristaux, Tempête d\'Énergie : trois menaces qui tournent ' +
        'tous les quatorze jours ne sont pas trois crises séparées. Ce sont des avant-signes — des ' +
        'tests, réguliers et calculés, envoyés en éclaireurs pour mesurer la défense du secteur ' +
        'avant que la vraie corruption n\'avance plus loin.'
    },
    {
      id: 'link_expeditions', title: 'Pourquoi les Expéditions existent',
      body: 'Envoyer des héros en Expédition, ce n\'est pas seulement aller chercher des ressources ' +
        'plus loin. Chaque mission est un relevé : cartographier les secteurs voisins, repérer où ' +
        'la corruption a déjà pris pied, et ramener de quoi tenir le siège sur Nexus-01 un peu plus ' +
        'longtemps.'
    },
    {
      id: 'link_qg', title: 'Pourquoi les empires rivaux attaquent',
      body: 'Les raids contre votre QG et les attaques contre les QG ennemis ne sont pas un simple ' +
        'concours de puissance entre voisins. Les cinq empires du secteur sentent, eux aussi, la ' +
        'même pression monter — certains se renforcent pour y résister, d\'autres, déjà entamés, ' +
        'deviennent plus agressifs à mesure qu\'ils perdent pied.'
    },
    {
      id: 'link_prestige', title: 'Pourquoi la Renaissance existe',
      body: 'La Renaissance galactique n\'est pas qu\'un système de progression permanente : c\'est ' +
        'la seule option quand un cycle devient intenable — évacuer ce qui compte (héros, ' +
        'équipement, savoir) et reconstruire ailleurs, plutôt que de s\'accrocher à un secteur que ' +
        'la corruption finira de toute façon par rattraper.'
    },
    {
      id: 'link_symtor', title: 'Pourquoi le Symtor est unique',
      body: 'Le Symtor n\'est pas un animal domestiqué comme un autre : sa croissance procédurale, ' +
        'ses gènes qui varient d\'une partie à l\'autre, viennent d\'une origine que personne à ' +
        'bord ne sait expliquer. C\'est peut-être justement ce qui le rend sensible à l\'Éclat ' +
        'Souillé, là où aucune autre unité du secteur n\'y réagit.'
    }
  ];

  function _annotate(list, ctx) {
    return list.map(function (e) {
      var unlocked = !e.unlock || !!e.unlock(ctx);
      return { id: e.id, chapter: e.chapter, title: e.title, hint: e.hint, unlocked: unlocked, body: unlocked ? e.body : null };
    });
  }

  /** Liste chronologique (onglet « Récit »), chaque entrée annotée `unlocked`. */
  function story(ctx) { return _annotate(STORY, ctx || {}); }
  /** Liste fixe (onglet « Connexions »), toujours débloquée. */
  function connections() { return CONNECTIONS.map(function (e) { return { id: e.id, title: e.title, body: e.body, unlocked: true }; }); }

  function chapterName(id) { var c = CHAPTERS.filter(function (c) { return c.id === id; })[0]; return c ? c.name : ''; }
  function storyUnlockedCount(ctx) { return story(ctx).filter(function (e) { return e.unlocked; }).length; }
  function storyTotalCount() { return STORY.length; }

  return {
    CHAPTERS: CHAPTERS,
    story: story, connections: connections,
    chapterName: chapterName, storyUnlockedCount: storyUnlockedCount, storyTotalCount: storyTotalCount
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = NEBUSTION.Codex;
