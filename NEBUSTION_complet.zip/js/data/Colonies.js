/**
 * NEBUSTION - Colonies (données pures, sans Phaser — testable sous Node)
 * Les 6 planètes de la Nouvelle Galaxie (système Héliora) peuvent être colonisées. Chaque colonie a 3 installations
 * qui produisent en continu (même hors ligne, jusqu'à CAP_HOURS d'avance) et s'améliorent. On récolte depuis l'écran
 * de la planète. Équilibrage : tout se règle ici.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Colonies = (function () {
  'use strict';

  var MAX_LEVEL = 10;
  var RATE_GROWTH = 1.28;      // production ×1,28 par niveau
  var COST_GROWTH = 1.6;       // coût ×1,6 par niveau
  var CAP_HOURS = 4;           // avance maximale stockée dans la colonie
  var CAP_SEC = CAP_HOURS * 3600;
  var COLONY_BONUS = 0.05;     // +5 % de production par colonie fondée (sur la production de toutes les colonies)

  // res : ressource produite ; rate : production/s au niveau 1 ; cost : coût du niveau 1 (améliorations : ×COST_GROWTH par niveau)
  var DEFS = {
    pyros: { colonize: { metal: 4000, energy: 1500 }, inst: [
      { id: 'forge',   name: 'Forge volcanique',      icon: '🌋', res: 'metal',   rate: 0.45,  cost: { metal: 900,  energy: 300 } },
      { id: 'geo',     name: 'Centrale géothermique', icon: '⚡', res: 'energy',  rate: 0.30,  cost: { metal: 700,  crystal: 400 } },
      { id: 'noyau',   name: 'Sonde de noyaux',       icon: '🔥', res: 'core',    rate: 0.012, cost: { metal: 1200, energy: 600 } } ] },
    aqualis: { colonize: { crystal: 3500, metal: 2000 }, inst: [
      { id: 'perle',   name: 'Ferme de cristaux marins', icon: '💠', res: 'crystal', rate: 0.55, cost: { metal: 800,  dust: 600 } },
      { id: 'maree',   name: 'Turbines de marée',        icon: '🌊', res: 'energy',  rate: 0.28, cost: { metal: 700,  crystal: 500 } },
      { id: 'plankt',  name: 'Récolteur de plancton',    icon: '✨', res: 'dust',    rate: 1.10, cost: { metal: 600,  crystal: 300 } } ] },
    rubea: { colonize: { metal: 3500, dust: 3000 }, inst: [
      { id: 'mine',    name: 'Mine à ciel ouvert',    icon: '⛏️', res: 'metal',   rate: 0.50, cost: { crystal: 700, energy: 300 } },
      { id: 'dune',    name: 'Aspirateur de dunes',   icon: '🏜️', res: 'dust',    rate: 1.20, cost: { metal: 700,  energy: 250 } },
      { id: 'geode',   name: 'Foreuse à géodes',      icon: '💎', res: 'crystal', rate: 0.42, cost: { metal: 900,  dust: 700 } } ] },
    goliath: { colonize: { energy: 4500, crystal: 2500 }, inst: [
      { id: 'coll',    name: 'Collecteur orbital',    icon: '🛰️', res: 'energy',  rate: 0.42, cost: { metal: 1000, crystal: 500 } },
      { id: 'siphon',  name: 'Siphon de gaz rares',   icon: '🌀', res: 'core',    rate: 0.015, cost: { metal: 1500, energy: 800 } },
      { id: 'nuage',   name: 'Filtre à poussières',   icon: '☁️', res: 'dust',    rate: 1.00, cost: { metal: 800,  energy: 400 } } ] },
    saturnia: { colonize: { dust: 4500, metal: 3000 }, inst: [
      { id: 'glace',   name: 'Collecteur d\'anneaux', icon: '🪐', res: 'dust',    rate: 1.30, cost: { metal: 900,  energy: 300 } },
      { id: 'cristal', name: 'Fonderie d\'anneau',    icon: '💠', res: 'crystal', rate: 0.50, cost: { metal: 1000, dust: 800 } },
      { id: 'debris',  name: 'Récupérateur d\'épaves', icon: '🔩', res: 'metal',   rate: 0.48, cost: { crystal: 800, energy: 350 } } ] },
    glacia: { colonize: { crystal: 3000, energy: 2500 }, inst: [
      { id: 'foreuse', name: 'Foreuse cryogénique',   icon: '❄️', res: 'crystal', rate: 0.60, cost: { metal: 900,  energy: 350 } },
      { id: 'geyser',  name: 'Capteur de geysers',    icon: '🧊', res: 'energy',  rate: 0.32, cost: { metal: 800,  crystal: 500 } },
      { id: 'noyauG',  name: 'Sonde des abysses',     icon: '🔷', res: 'core',    rate: 0.011, cost: { metal: 1300, dust: 900 } } ] }
  };
  var IDS = Object.keys(DEFS);

  function get(pid) { return DEFS[pid] || null; }
  function instDef(pid, iid) {
    var d = DEFS[pid]; if (!d) return null;
    for (var i = 0; i < d.inst.length; i++) if (d.inst[i].id === iid) return d.inst[i];
    return null;
  }
  /** Production par seconde d'une installation au niveau donné (0 → 0). */
  function rateAt(pid, iid, level) {
    var d = instDef(pid, iid); level = Math.floor(level || 0);
    if (!d || level < 1) return 0;
    return d.rate * Math.pow(RATE_GROWTH, Math.min(level, MAX_LEVEL) - 1);
  }
  /** Coût pour passer de `level` à `level + 1` (level 0 → construction). */
  function upgradeCost(pid, iid, level) {
    var d = instDef(pid, iid); if (!d) return null;
    level = Math.max(0, Math.floor(level || 0));
    var out = {}, m = Math.pow(COST_GROWTH, level);
    Object.keys(d.cost).forEach(function (k) { out[k] = Math.ceil(d.cost[k] * m); });
    return out;
  }

  function defaultColony() { return { on: false, last: 0, lv: {} }; }
  function defaultState() {
    var s = { v: 1, colonies: {} };
    IDS.forEach(function (id) { s.colonies[id] = defaultColony(); });
    return s;
  }
  /** Sauvegarde corrompue / absente / ancienne → état valide (niveaux bornés, dates saines). */
  function normalizeState(raw, now) {
    var s = defaultState(); now = now || Date.now();
    if (!raw || typeof raw !== 'object' || !raw.colonies || typeof raw.colonies !== 'object') return s;
    IDS.forEach(function (pid) {
      var c = raw.colonies[pid]; if (!c || typeof c !== 'object' || !c.on) return;
      var out = s.colonies[pid]; out.on = true;
      var last = Number(c.last);
      out.last = (isFinite(last) && last > 0 && last <= now) ? last : now;
      DEFS[pid].inst.forEach(function (d) {
        var lv = Math.floor(Number(c.lv && c.lv[d.id]));
        if (isFinite(lv) && lv > 0) out.lv[d.id] = Math.min(MAX_LEVEL, lv);
      });
    });
    return s;
  }

  return { MAX_LEVEL: MAX_LEVEL, RATE_GROWTH: RATE_GROWTH, COST_GROWTH: COST_GROWTH, CAP_HOURS: CAP_HOURS, CAP_SEC: CAP_SEC, COLONY_BONUS: COLONY_BONUS,
    DEFS: DEFS, IDS: IDS, get: get, instDef: instDef, rateAt: rateAt, upgradeCost: upgradeCost,
    defaultColony: defaultColony, defaultState: defaultState, normalizeState: normalizeState };
})();
