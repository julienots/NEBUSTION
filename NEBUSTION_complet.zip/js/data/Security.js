/**
 * NEBUSTION - Security
 * Données pures (aucune dépendance à Phaser) pour la « Sécurité de zone » du Quartier Général.
 * Distinct du niveau du bâtiment QG (qui débloque les types d'expéditions, voir Expeditions.js) :
 * ici, on améliore un système interne indépendant, visible en entrant dans le QG (QGScene).
 * Volontairement minimal pour l'instant (un simple niveau + coût) : de vraies défenses
 * (tourelles, boucliers, vagues d'ennemis à repousser...) viendront se brancher dessus plus tard.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Security = (function () {
  'use strict';

  var MAX_LEVEL = 20;
  var BASE_COST = { crystal: 250, metal: 200, energy: 120 };
  var COST_GROWTH = 1.45;

  function lvl(l) {
    l = Math.floor(Number(l));
    return (isFinite(l) && l >= 1) ? Math.min(l, MAX_LEVEL) : 1;
  }

  function defaultState() {
    return { level: 1 };
  }

  function normalizeState(raw) {
    var s = defaultState();
    if (!raw || typeof raw !== 'object') return s;
    s.level = lvl(raw.level);
    return s;
  }

  /** Coût pour passer du niveau `level` au suivant. */
  function upgradeCost(level) {
    var mult = Math.pow(COST_GROWTH, lvl(level) - 1);
    var out = {};
    Object.keys(BASE_COST).forEach(function (rid) { out[rid] = Math.ceil(BASE_COST[rid] * mult); });
    return out;
  }

  /** Texte affiché dans QGScene pour l'amélioration en cours. */
  function effectText(level) {
    var l = lvl(level);
    if (l >= MAX_LEVEL) return 'Zone entièrement sécurisée (niveau maximum).';
    return 'Renforce la sécurité de la zone intérieure — de nouvelles menaces et défenses arriveront dans une prochaine mise à jour.';
  }

  return {
    MAX_LEVEL: MAX_LEVEL,
    defaultState: defaultState,
    normalizeState: normalizeState,
    upgradeCost: upgradeCost,
    effectText: effectText,
    lvl: lvl
  };
})();
