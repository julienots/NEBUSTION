/**
 * NEBUSTION - EmpireDoctrine (données + logique pure, sans Phaser, testable sous Node)
 * Module IA 3 (finalisation) : ce qui rend chaque empire DISTINCT quand il évolue.
 *  - STYLE      : préférences et coûts de dépense propres à chaque empire (défense / flotte / entraînement...)
 *  - CAPS       : capacités déverrouillées par le développement (evo), + capacité de CRISE (réaction aux pertes)
 *  - adaptation : multiplicateurs de dépense selon pertes, pression, stocks, élan (aucun état ici : tout est passé en entrée)
 *  - rankedDef  : unité « entraînée » (rang 0..3) : stats +2 %/rang, id inchangé (textures/combat compatibles)
 * Tout est borné (LIMITS, RANK_MAX) : aucune progression infinie possible.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.EmpireDoctrine = (function () {
  'use strict';

  var RANK_MAX = 3, RANK_STEP = 0.02;
  function clamp(x, a, b) { x = Number(x); return isFinite(x) ? Math.max(a, Math.min(b, x)) : a; }
  function r2(x) { return Math.round(x * 100) / 100; }

  // max : niveaux maximaux propres à l'empire (ELYRA : boucliers max, peu de tourelles ; MORVAK : l'inverse...) ;
  // pref : poids de score ; cost : multiplicateur de coût ; spread : coordination (répartit les niveaux entre planètes) ;
  // focus : rôles d'unités que l'empire entraîne en priorité.
  var STYLE = {
    vexor:  { max: { sh: 5, tu: 3, fl: 1 }, pref: { sh: 1.15, tu: 1.00, fl: 1.20, ut: 1.00, evo: 1.00 }, cost: { sh: 1.00, tu: 1.00, fl: 0.90, ut: 0.90, evo: 1.00 }, spread: 0.2, focus: ['tank', 'grunt'] },
    kael9:  { max: { sh: 4, tu: 4, fl: 2 }, pref: { sh: 1.10, tu: 1.10, fl: 1.00, ut: 1.00, evo: 1.05 }, cost: { sh: 0.90, tu: 1.00, fl: 1.00, ut: 1.00, evo: 0.95 }, spread: 0.9, focus: ['sniper', 'support'] },
    elyra:  { max: { sh: 5, tu: 2, fl: 1 }, pref: { sh: 1.35, tu: 0.90, fl: 0.80, ut: 0.90, evo: 0.90 }, cost: { sh: 0.80, tu: 1.00, fl: 1.25, ut: 1.10, evo: 1.00 }, spread: 0.5, focus: ['tank', 'support'] },
    morvak: { max: { sh: 2, tu: 4, fl: 2 }, pref: { sh: 0.70, tu: 1.10, fl: 1.40, ut: 1.20, evo: 0.90 }, cost: { sh: 1.25, tu: 0.90, fl: 0.80, ut: 0.85, evo: 1.00 }, spread: 0.1, focus: ['elite', 'brute', 'bomber'] },
    nyrah:  { max: { sh: 3, tu: 4, fl: 1 }, pref: { sh: 1.00, tu: 1.35, fl: 0.80, ut: 1.00, evo: 1.10 }, cost: { sh: 1.00, tu: 0.85, fl: 1.10, ut: 1.00, evo: 1.00 }, spread: 0.2, focus: ['control', 'drain', 'bomber'] },
    parasite: { max: { sh: 3, tu: 3, fl: 2 }, pref: { sh: 0.85, tu: 1.05, fl: 1.30, ut: 1.15, evo: 1.20 }, cost: { sh: 1.10, tu: 1.00, fl: 0.75, ut: 0.80, evo: 0.90 }, spread: 0.05, focus: ['grunt', 'skirmisher', 'elite'] }
  };

  // Effets numériques lus par le futur module d'invasion (spec.bonus). Plafonds : LIMITS.
  var LIMITS = { healBetweenWaves: 0.30, defBonus: 0.20, extraGrunt: 2, supportAura: 0.15, shieldStartPct: 0.30, atkBonus: 0.20, regen: 0.03, dotPct: 0.06, missChance: 0.15, lifeDrain: 0.12 };
  var CAPS = {
    vexor: [
      { id: 'vx_repair', evo: 2, name: 'Réassemblage renforcé', text: 'Les automates se réparent davantage entre les vagues.', effect: { healBetweenWaves: 0.10 } },
      { id: 'vx_plating', evo: 4, name: 'Blindage lourd', text: 'Plaques supplémentaires : défense accrue.', effect: { defBonus: 0.08 } },
      { id: 'vx_mass', evo: 6, name: 'Production de masse', text: 'Un Ferrailleur de plus garde la capitale.', effect: { extraGrunt: 1, healBetweenWaves: 0.05 } }
    ],
    kael9: [
      { id: 'k9_link', evo: 2, name: 'Liaison tactique', text: 'Les défenseurs se soutiennent : soutien mutuel accru.', effect: { supportAura: 0.06 } },
      { id: 'k9_grid', evo: 4, name: 'Grille étendue', text: 'Bouclier de départ plus épais.', effect: { shieldStartPct: 0.10 } },
      { id: 'k9_sync', evo: 6, name: 'Frappe synchronisée', text: 'Les tirs de la flotte sont coordonnés.', effect: { atkBonus: 0.08, supportAura: 0.04 } }
    ],
    elyra: [
      { id: 'el_regen', evo: 2, name: 'Grâce persistante', text: 'Régénération continue des gardiens.', effect: { regen: 0.01 } },
      { id: 'el_barrier', evo: 4, name: 'Barrière sacrée', text: 'Un bouclier sacré plus grand au début du combat.', effect: { shieldStartPct: 0.15 } },
      { id: 'el_judgement', evo: 6, name: 'Jugement radiant', text: 'La lumière frappe plus fort.', effect: { atkBonus: 0.08, regen: 0.005 } }
    ],
    morvak: [
      { id: 'mo_burn', evo: 2, name: 'Braises tenaces', text: 'Brûlures plus longues sur vos unités.', effect: { dotPct: 0.02 } },
      { id: 'mo_rage', evo: 4, name: 'Fureur des légions', text: 'Les champions frappent plus fort.', effect: { atkBonus: 0.10 } },
      { id: 'mo_ash', evo: 6, name: 'Terre entièrement brûlée', text: 'Le sol lui-même consume l\'ennemi.', effect: { dotPct: 0.02, atkBonus: 0.04 } }
    ],
    nyrah: [
      { id: 'ny_fog', evo: 2, name: 'Brume épaissie', text: 'Vos attaques ratent plus souvent.', effect: { missChance: 0.05 } },
      { id: 'ny_drain', evo: 4, name: 'Soif du Vide', text: 'Les ombres se soignent en vous frappant.', effect: { lifeDrain: 0.05 } },
      { id: 'ny_singularity', evo: 6, name: 'Singularité stable', text: 'Le Néant se referme sur vos tirs.', effect: { missChance: 0.04, lifeDrain: 0.02 } }
    ],
    parasite: [
      { id: 'par_multiplication', evo: 2, name: 'Multiplication accélérée', text: 'De nouvelles spores rejoignent la mêlée.', effect: { extraGrunt: 1 } },
      { id: 'par_membrane', evo: 4, name: 'Membrane adaptative', text: 'La chitine se reforme entre les vagues.', effect: { healBetweenWaves: 0.08 } },
      { id: 'par_essaim_total', evo: 6, name: 'Essaim total', text: 'L\'infection se propage à chaque assaillant.', effect: { dotPct: 0.03, extraGrunt: 1 } }
    ]
  };
  // Capacité de CRISE : temporaire, proportionnelle au traumatisme (`hurt` 0..1), différente pour chaque empire.
  var CRISIS = {
    vexor:  { id: 'vx_emergency', name: 'Réparation d\'urgence', effect: { healBetweenWaves: 0.05 } },
    kael9:  { id: 'k9_redlert', name: 'Réserves de la flotte', effect: { shieldStartPct: 0.05 } },
    elyra:  { id: 'el_lastprayer', name: 'Dernière prière', effect: { regen: 0.005 } },
    morvak: { id: 'mo_bloodlust', name: 'Soif de vengeance', effect: { atkBonus: 0.06 } },
    nyrah:  { id: 'ny_veil', name: 'Voile de désespoir', effect: { missChance: 0.03 } },
    parasite: { id: 'par_frenzy', name: 'Frénésie de survie', effect: { extraGrunt: 1 } }
  };

  /** Capacités actives (evo + crise) et bonus fusionnés/plafonnés. */
  function capabilities(eid, evo, hurt) {
    var list = (CAPS[eid] || []).filter(function (c) { return evo >= c.evo; });
    var bonus = {}, h = clamp(hurt, 0, 1);
    function add(effect, k) { Object.keys(effect).forEach(function (key) { bonus[key] = (bonus[key] || 0) + effect[key] * k; }); }
    list.forEach(function (c) { add(c.effect, 1); });
    var out = list.map(function (c) { return { id: c.id, name: c.name, text: c.text, effect: c.effect, crisis: false }; });
    var cr = CRISIS[eid];
    if (cr && h >= 0.2) { add(cr.effect, h); out.push({ id: cr.id, name: cr.name, text: 'Réaction temporaire aux pertes récentes.', effect: cr.effect, crisis: true }); }
    Object.keys(bonus).forEach(function (k) { bonus[k] = r2(Math.min(LIMITS[k] || 1, bonus[k])); });
    return { list: out, bonus: bonus };
  }

  /**
   * Multiplicateurs d'adaptation (0.5..2) de la dépense selon la situation réelle.
   * @param s {posture, lossRatio, capitalLost, hurt, pressure, momentum, stockRatio}
   * @returns {{mult:{sh,tu,fl,ut,evo}, actions:number, focus:string}}
   */
  function adaptation(s) {
    s = s || {};
    var loss = Math.max(clamp(s.lossRatio, 0, 1), clamp(s.hurt, 0, 1)), cap = s.capitalLost ? 1 : 0;
    var pr = clamp(s.pressure, 0, 1), mo = clamp(s.momentum, 0, 1), st = clamp(s.stockRatio, 0, 1);
    var m = { sh: 1, tu: 1, fl: 1, ut: 1, evo: 1 };
    m.sh *= 1 + 0.6 * loss + 0.3 * pr;                    // les pertes et la présence du joueur → boucliers
    m.tu *= 1 + 0.4 * loss + 0.3 * pr;
    m.evo *= 1 - 0.3 * loss - 0.1 * cap;                  // un empire blessé investit moins dans le long terme...
    m.fl *= 1 + 0.2 * cap + 0.25 * mo + (s.posture === 'offensive' ? 0.15 * loss : 0);   // ...et reconstruit sa flotte
    m.ut *= 1 + 0.25 * mo + 0.3 * loss;                   // entraîne ses unités après un revers ou une défense réussie
    if (st > 0.8) { m.fl *= 1.1; m.ut *= 1.1; m.evo *= 1.1; }        // stock plein : on dépense
    var focus = 'growth', best = m.evo, names = { sh: 'shield', tu: 'turret', fl: 'fleet', ut: 'training' };
    Object.keys(names).forEach(function (k) { if (m[k] > best + 0.05) { best = m[k]; focus = names[k]; } });
    Object.keys(m).forEach(function (k) { m[k] = r2(clamp(m[k], 0.5, 2)); });
    return { mult: m, actions: st > 0.85 ? 4 : 3, focus: focus };
  }

  /** Copie d'une définition d'unité entraînée au rang `rank` (0 = définition d'origine). */
  function rankedDef(def, rank) {
    rank = Math.floor(clamp(rank, 0, RANK_MAX));
    if (!def || !rank) return def;
    var k = 1 + RANK_STEP * rank, o = {};
    Object.keys(def).forEach(function (key) { o[key] = def[key]; });
    o.base = { hp: Math.round(def.base.hp * k), atk: Math.round(def.base.atk * k), def: def.base.def, spd: def.base.spd };
    o.rank = rank; o.name = def.name + ' ' + '★'.repeat(rank);
    return o;
  }
  /** Niveau maximal d'un type de défense pour cet empire (sh/tu/fl), avant plafond de développement. */
  function styleMax(eid, kind, dflt) { var st = STYLE[eid]; return st && st.max && st.max[kind] != null ? st.max[kind] : dflt; }
  function rankMax(evo) { return Math.min(RANK_MAX, Math.floor(clamp(evo, 0, 8) / 2)); }

  return { RANK_MAX: RANK_MAX, RANK_STEP: RANK_STEP, STYLE: STYLE, CAPS: CAPS, CRISIS: CRISIS, LIMITS: LIMITS,
    capabilities: capabilities, adaptation: adaptation, rankedDef: rankedDef, rankMax: rankMax, styleMax: styleMax };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.EmpireDoctrine; }
