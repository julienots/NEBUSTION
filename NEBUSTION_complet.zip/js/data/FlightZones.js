/**
 * NEBUSTION - FlightZones (données pures, sans Phaser, testable sous Node comme Galaxy.js)
 * Module Vol libre : monde 2D dans lequel le joueur pilote son vaisseau (hangar) pour découvrir
 * des zones spéciales (planètes, épaves, anomalies) et débloquer leur accès. Aucune dépendance à
 * Phaser ici : ShipFlightScene ne fait que lire ces tables et appeler FlightZoneManager.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.FlightZones = (function () {
  'use strict';

  // Monde de vol : plus petit que la carte Galaxie (2 600 x 2 600), le vaisseau part du centre bas.
  var WORLD = { w: 2600, h: 2600 };
  var START = { x: 1300, y: 2300 };

  // Réutilise la palette de types de planète de la Galaxie (couleurs/atmosphère cohérentes).
  var TYPES = NEBUSTION.Galaxy ? NEBUSTION.Galaxy.PLANET_TYPES : {};

  // spec : [id, name, type, x, y, radius, kind, reward, desc]
  //   kind : 'planet' | 'wreck' | 'anomaly' | 'belt'  (influence uniquement le rendu de la scène)
  var SPEC = [
    ['kyrion9', 'Kyrion-9', 'desert', 700, 1850, 62, 'planet', { metal: 220 }, 'Un monde désertique battu par les vents, riche en gisements de métal à ciel ouvert.'],
    ['nymbral', 'Nymbral', 'ice', 1950, 1700, 58, 'planet', { energy: 200 }, 'Planète glacée dont les champs cristallins accumulent une énergie statique considérable.'],
    ['valkara_wreck', 'Épave du Valkara', 'station', 420, 1350, 46, 'wreck', { dust: 180, metal: 90 }, 'La carcasse d\'un vaisseau-mère englouti dans la poussière stellaire. Pillable en toute sécurité.'],
    ['ferrun3', 'Ferrun-3', 'machine', 2150, 1150, 60, 'planet', { metal: 160, energy: 120 }, 'Planète-forge automatisée : ses usines tournent encore, sans personne pour les arrêter.'],
    ['obsidia', 'Monolithe d\'Obsidia', 'void', 1300, 950, 50, 'anomaly', { core: 90 }, 'Une faille spatiale instable entoure un monolithe dont la nature reste inconnue.'],
    ['kairos_belt', 'Ceinture Kaïros', 'asteroid', 850, 650, 54, 'belt', { metal: 140, dust: 100 }, 'Un amas d\'astéroïdes truffé de poches de minerai brut.'],
    ['scarlet_pulsar', 'Pulsar Écarlate', 'hell', 1750, 480, 56, 'anomaly', { dust: 160, core: 60 }, 'Les radiations de ce pulsar mort dissimulent une poche d\'énergie exploitable.'],
    ['celestia_minor', 'Celestia Minor', 'celestial', 2250, 350, 58, 'planet', { crystal: 200, core: 60 }, 'Un sanctuaire flottant baigné d\'une lumière dorée, à l\'écart des routes commerciales.'],
    ['spore9', 'Essaim Spore-9', 'organic', 500, 250, 54, 'anomaly', { crystal: 120, dust: 120 }, 'Un nuage de spores bioluminescentes enveloppe ce qui reste d\'une colonie organique.'],
    ['nova_terminus', 'Nova Terminus', 'lava', 1300, 100, 70, 'planet', { crystal: 260, metal: 180, energy: 180, dust: 140, core: 120 }, 'Aux confins connus du secteur : une planète volcanique isolée, la plus riche découverte à ce jour.']
  ];

  function typeDef(t) { return TYPES[t] || { name: t, inner: '#8fa0c8', outer: '#1c2740', atmo: '#8fa0c8' }; }

  function buildZone(s) {
    return {
      id: s[0], name: s[1], type: s[2], x: s[3], y: s[4], r: s[5], kind: s[6],
      reward: s[7] || {}, desc: s[8] || '', typeDef: typeDef(s[2])
    };
  }

  var ZONES = SPEC.map(buildZone);
  var ZONE_INDEX = {};
  ZONES.forEach(function (z) { ZONE_INDEX[z.id] = z; });

  function zone(id) { return ZONE_INDEX[id] || null; }
  function all() { return ZONES.slice(); }

  // ---------- Sauvegarde : validation de l'état `flightZones` ----------
  function defaultState() { return { unlocked: {}, stats: { unlocks: 0 } }; }
  function normalizeState(raw) {
    var s = defaultState();
    if (!raw || typeof raw !== 'object') return s;
    var ru = raw.unlocked || {};
    Object.keys(ru).forEach(function (zid) { if (ZONE_INDEX[zid] && ru[zid] === true) s.unlocked[zid] = true; });
    var rs = raw.stats || {};
    var n = Number(rs.unlocks);
    s.stats.unlocks = isFinite(n) ? Math.max(0, Math.min(ZONES.length, Math.floor(n))) : 0;
    return s;
  }

  return {
    WORLD: WORLD, START: START, ZONES: ZONES, zone: zone, all: all,
    defaultState: defaultState, normalizeState: normalizeState
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.FlightZones; }
