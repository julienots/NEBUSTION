/**
 * NEBUSTION - Configuration Firebase (compte joueur + sauvegarde en ligne)
 *
 * Ce fichier ne contient AUCUNE clé valide : il faut le remplir avec les clés de TON
 * propre projet Firebase (gratuit) avant que le système de compte fonctionne. Tant que ce
 * n'est pas fait, le jeu tourne normalement en local (aucune fonctionnalité cassée) ; seul
 * l'écran « Compte » affichera un message expliquant qu'il faut d'abord configurer Firebase.
 *
 * Étapes (5 minutes, gratuit) :
 *  1. Aller sur https://console.firebase.google.com → « Ajouter un projet » → lui donner un nom
 *     (ex. « nebustion »). Désactiver Google Analytics si proposé (pas nécessaire).
 *  2. Dans le projet : menu de gauche « Compilation » → « Authentication » → « Get started »
 *     → onglet « Sign-in method » → activer le fournisseur « E-mail/Mot de passe ».
 *  3. Toujours dans « Compilation » → « Firestore Database » → « Créer une base de données »
 *     → choisir une région proche → démarrer en « mode production ».
 *  4. Dans Firestore, onglet « Règles », remplacer les règles par celles-ci (chaque joueur ne
 *     peut lire/écrire QUE sa propre sauvegarde) puis « Publier » :
 *
 *       rules_version = '2';
 *       service cloud.firestore {
 *         match /databases/{database}/documents {
 *           match /saves/{uid} {
 *             allow read, write: if request.auth != null && request.auth.uid == uid;
 *           }
 *         }
 *       }
 *
 *  5. Revenir à la page d'accueil du projet (icône ⚙ → « Paramètres du projet ») → onglet
 *     « Général » → tout en bas « Vos applications » → cliquer sur l'icône « </> » (Web) →
 *     donner un surnom → « Enregistrer l'application ». Firebase affiche alors un bloc
 *     `firebaseConfig = { apiKey: "...", ... }` : copier CES valeurs ci-dessous, à la place
 *     des "REMPLACE_MOI".
 *
 *  6. Déployer le ZIP tel quel sur Vercel. Aucune autre étape côté Vercel : tout se passe
 *     directement entre le navigateur du joueur et Firebase.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.FirebaseConfig = {
  apiKey: 'AIzaSyD1oR97JfmnLD3xs3JUP0S_DbFaDfbLwzg',
  authDomain: 'nebustion-cef0d.firebaseapp.com',
  projectId: 'nebustion-cef0d',
  storageBucket: 'nebustion-cef0d.firebasestorage.app',
  messagingSenderId: '567244643556',
  appId: '1:567244643556:web:14a8e7496bdbf56e63e0f1'
};
