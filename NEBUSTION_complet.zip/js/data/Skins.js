/**
 * NEBUSTION - Skins (données)
 * Module pur (aucune dépendance à Phaser, testable sous Node comme Ships.js/Equipment.js).
 *
 * Personnalisation cosmétique (étape 6, 3e volet) : skins de HÉROS, de VAISSEAUX et de BÂTIMENTS.
 * Un skin est un « thème » (teinte, aura, effet visuel) qui s'achète UNE fois (inventaire de cosmétiques)
 * puis peut être équipé sur n'importe quelle cible de son type. Purement visuel : aucun effet sur les
 * statistiques (les bonus viennent de l'équipement et de la flotte).
 *
 * État de sauvegarde : { owned: { skinId: true }, equipped: { 'hero:kael': 'h_gold', 'ship:sh3': ..., 'building:command': ... } }
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Skins = (function () {
  'use strict';

  var TARGET_TYPES = ['hero', 'ship', 'building'];
  var TARGET_NAMES = { hero: 'Héros', ship: 'Vaisseaux', building: 'Bâtiments' };
  // Bâtiments visibles sur la planète-mère (les extracteurs ne sont pas dessinés individuellement).
  var BUILDING_TARGETS = ['command', 'hangar', 'lab', 'defense', 'qg'];

  var RARITY_ORDER = ['commun', 'rare', 'epique', 'legendaire'];
  var RARITIES = {
    commun: { id: 'commun', name: 'Commun', order: 1, hex: '#9aa5c0', color: 0x9aa5c0 },
    rare: { id: 'rare', name: 'Rare', order: 2, hex: '#4fd1ff', color: 0x4fd1ff },
    epique: { id: 'epique', name: 'Épique', order: 3, hex: '#b47bff', color: 0xb47bff },
    legendaire: { id: 'legendaire', name: 'Légendaire', order: 4, hex: '#ffd166', color: 0xffd166 }
  };

  // Effets visuels disponibles (interprétés par js/ui/SkinFX.js).
  var FX = { none: 'Aura', pulse: 'Onde pulsée', sparkle: 'Étincelles', flame: 'Flammes', orbit: 'Orbites' };

  var COSTS = {
    commun: { dust: 600, crystal: 150 },
    rare: { dust: 1800, crystal: 500, energy: 150 },
    epique: { dust: 5000, crystal: 1500, energy: 500 },
    legendaire: { dust: 12000, crystal: 4000, energy: 1500, core: 20 }
  };

  var SKINS = [];
  var SKIN_INDEX = {};
  // `exclusive` (optionnel) : skin non disponible à l'achat en Boutique (SkinManager.buy le refuse) —
  // obtenu uniquement en récompense (Pass Doré, voir js/data/Pass.js GOLDEN_TRACK).
  function mk(target, id, name, rarity, aura, tint, hull, fx, desc, exclusive) {
    var s = { id: id, target: target, name: name, rarity: rarity, aura: aura, tint: tint, hull: hull, fx: fx, desc: desc, exclusive: !!exclusive };
    SKINS.push(s); SKIN_INDEX[id] = s;
  }

  // ---- Héros : `tint` teinte le portrait, `aura` colore l'halo et les effets ----
  mk('hero', 'h_cyan', 'Néon Cyan', 'commun', 0x00e5ff, 0xb8f3ff, 0x0b3a4a, 'none', 'Un halo cyan discret autour du héros.');
  mk('hero', 'h_rose', 'Rose Quantique', 'commun', 0xff6ec7, 0xffc4ec, 0x4a1238, 'none', 'Reflets rose vif, halo magenta.');
  mk('hero', 'h_ember', 'Braise', 'rare', 0xff6a2a, 0xffcfa8, 0x4a1c0a, 'flame', 'Des flammes montent autour du héros.');
  mk('hero', 'h_void', 'Vide Violet', 'rare', 0x8a4dff, 0xd3b8ff, 0x22104a, 'pulse', 'Une onde violette pulse à intervalle régulier.');
  mk('hero', 'h_gold', 'Or Solaire', 'epique', 0xffd166, 0xffe9a3, 0x4a3a10, 'orbit', 'Deux astres dorés gravitent autour du héros.');
  mk('hero', 'h_frost', 'Givre Éternel', 'epique', 0xa6e8ff, 0xd6efff, 0x123a4a, 'sparkle', 'Cristaux de givre qui scintillent.');
  mk('hero', 'h_spectre', 'Spectre Émeraude', 'legendaire', 0x5fffb0, 0xc9ffe0, 0x0c4a30, 'orbit', 'Aura spectrale intense et orbes émeraude.');

  // ---- Vaisseaux : `hull` = coque, `aura` = liserés / réacteurs / halo ----
  mk('ship', 's_cobalt', 'Cobalt', 'commun', 0x4fd1ff, null, 0x1f3352, 'none', 'Coque bleu acier, réacteurs cyan.');
  mk('ship', 's_crimson', 'Carmin', 'commun', 0xff4d6d, null, 0x4a1622, 'none', 'Livrée rouge de combat.');
  mk('ship', 's_solar', 'Éclipse Solaire', 'rare', 0xffb040, null, 0x4a3210, 'flame', 'Réacteurs incandescents, traînée de feu.');
  mk('ship', 's_nebula', 'Nébuleuse', 'rare', 0xb47bff, null, 0x2a1a55, 'pulse', 'Coque violette, onde de propulsion.');
  mk('ship', 's_aurora', 'Aurore', 'epique', 0x5fffb0, null, 0x0e3f34, 'sparkle', 'Particules d\'aurore boréale dans le sillage.');
  mk('ship', 's_royal', 'Royal', 'epique', 0xffd166, null, 0x40300e, 'orbit', 'Dorures royales et satellites d\'escorte.');
  mk('ship', 's_phantom', 'Fantôme', 'legendaire', 0x9bd4ff, null, 0x10182e, 'orbit', 'Coque noire, halo spectral et orbes d\'escorte.');

  // ---- Bâtiments : aura, balise et effets sur la planète-mère ----
  mk('building', 'b_cyber', 'Cyber Cyan', 'commun', 0x00e5ff, null, 0x0b3a4a, 'none', 'Halo cyan, balise assortie.');
  mk('building', 'b_amber', 'Ambre', 'commun', 0xffd166, null, 0x4a3a10, 'none', 'Lueur ambrée, balise dorée.');
  mk('building', 'b_plasma', 'Plasma Rose', 'rare', 0xff6ec7, null, 0x4a1238, 'pulse', 'Onde de plasma rose autour du bâtiment.');
  mk('building', 'b_verdant', 'Verdoyant', 'rare', 0x5fd97a, null, 0x0e3f22, 'sparkle', 'Spores lumineuses qui s\'élèvent.');
  mk('building', 'b_royal', 'Améthyste', 'epique', 0xb47bff, null, 0x2a1a55, 'orbit', 'Satellites d\'améthyste en orbite.');
  mk('building', 'b_inferno', 'Fournaise', 'epique', 0xff6a2a, null, 0x4a1c0a, 'flame', 'Braises et flammes au sommet.');
  mk('building', 'b_starforge', 'Forge Stellaire', 'legendaire', 0xfff1a8, null, 0x3a3010, 'orbit', 'Halo stellaire éclatant et orbes solaires.');

  // ---- Exclusivités du Pass Doré (2 par thème de saison, voir Pass.js) : jamais en vente en Boutique ----
  mk('ship', 's_halo', 'Halo Solaire', 'epique', 0xffe9a3, null, 0x3a3010, 'sparkle', 'Coque nacrée cerclée d\'un halo doré. Exclusivité du Pass Doré.', true);
  mk('hero', 'h_couronne', 'Couronne Céleste', 'legendaire', 0xfff6d6, 0xffffff, 0x40300e, 'orbit', 'Une couronne de lumière dorée irradie autour du héros. Exclusivité du Pass Doré.', true);
  mk('building', 'b_eclipse', 'Éclipse Pourpre', 'epique', 0x2a1a55, null, 0x0c0818, 'pulse', 'Un disque d\'ombre violette cerclé d\'or éclipse le bâtiment. Exclusivité du Pass Doré.', true);
  mk('hero', 'h_astral', 'Astral Suprême', 'legendaire', 0xd9b8ff, 0xf3e6ff, 0x22104a, 'orbit', 'Constellation dorée et violette en orbite permanente. Exclusivité du Pass Doré.', true);
  mk('ship', 's_magma', 'Cœur Magmatique', 'epique', 0xffb040, null, 0x4a1c0a, 'flame', 'Coque craquelée d\'où jaillit une lave dorée. Exclusivité du Pass Doré.', true);
  mk('hero', 'h_phenix', 'Phénix Solaire', 'legendaire', 0xffcf7a, 0xfff1a8, 0x4a2408, 'flame', 'Des ailes de flammes dorées enveloppent le héros. Exclusivité du Pass Doré.', true);
  mk('building', 'b_cristal', 'Cristal Boréal', 'epique', 0xdff6ff, null, 0x123a4a, 'sparkle', 'Cristaux de glace dorée qui captent la lumière. Exclusivité du Pass Doré.', true);
  mk('hero', 'h_polaris', 'Polaris Éternelle', 'legendaire', 0xf2fbff, 0xffffff, 0x123a4a, 'sparkle', 'Une étoile polaire dorée guide chacun de ses pas. Exclusivité du Pass Doré.', true);

  // hasOwnProperty : « constructor », « toString », « __proto__ »… ne doivent jamais passer pour des identifiants de skin.
  function get(id) { return (typeof id === 'string' && Object.prototype.hasOwnProperty.call(SKIN_INDEX, id)) ? SKIN_INDEX[id] : null; }
  function forTarget(type) { return SKINS.filter(function (s) { return s.target === type; }); }
  function cost(rarityId) { var c = COSTS[rarityId] || COSTS.commun; return Object.assign({}, c); }
  function price(skinId) { var s = SKIN_INDEX[skinId]; return s ? cost(s.rarity) : null; }
  function key(type, id) { return type + ':' + id; }

  // ---------- État de sauvegarde (pur, comme Ships.defaultState/normalizeState) ----------
  function defaultState() { return { owned: {}, equipped: {} }; }

  function normalizeState(raw) {
    var s = defaultState();
    if (!raw || typeof raw !== 'object') return s;

    var ro = raw.owned && typeof raw.owned === 'object' ? raw.owned : {};
    Object.keys(ro).forEach(function (id) { if (get(id) && ro[id]) s.owned[id] = true; });

    var re = raw.equipped && typeof raw.equipped === 'object' ? raw.equipped : {};
    var n = 0;
    Object.keys(re).forEach(function (k) {
      if (n >= 200 || typeof k !== 'string' || k.length > 60) return;
      var i = k.indexOf(':');
      if (i <= 0) return;
      var type = k.slice(0, i), tid = k.slice(i + 1);
      if (TARGET_TYPES.indexOf(type) < 0 || !tid || tid.length > 40) return;
      var skin = get(re[k]);
      if (!skin || skin.target !== type || !s.owned[skin.id]) return;   // inconnu, mauvais type ou non possédé : ignoré
      s.equipped[k] = skin.id; n++;
    });
    return s;
  }

  return {
    TARGET_TYPES: TARGET_TYPES, TARGET_NAMES: TARGET_NAMES, BUILDING_TARGETS: BUILDING_TARGETS,
    RARITY_ORDER: RARITY_ORDER, RARITIES: RARITIES, FX: FX, COSTS: COSTS,
    SKINS: SKINS, SKIN_INDEX: SKIN_INDEX,
    get: get, forTarget: forTarget, cost: cost, price: price, key: key,
    defaultState: defaultState, normalizeState: normalizeState
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.Skins; }
