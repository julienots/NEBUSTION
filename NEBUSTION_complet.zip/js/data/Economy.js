/**
 * NEBUSTION - Economy
 * Données et formules d'équilibrage de l'économie. AUCUNE dépendance à Phaser :
 * ce fichier est du JavaScript pur (testable sous Node).
 *
 * Tout ce qui touche à l'équilibrage se règle ICI (taux, plafonds, coûts, hors-ligne).
 * Les valeurs sont volontairement centralisées pour que les prochaines étapes
 * (bâtiments améliorables, héros, boutique) n'aient qu'à appeler ces fonctions.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Economy = (function () {
  'use strict';

  var ORDER = ['crystal', 'metal', 'energy', 'core', 'dust'];

  var RES = {
    crystal: { id: 'crystal', name: 'Cristaux stellaires', short: 'Cristaux', color: 0x4fe3ff, hex: '#4fe3ff', decimals: 0 },
    metal:   { id: 'metal',   name: 'Métal galactique',    short: 'Métal',    color: 0xc9d4ea, hex: '#c9d4ea', decimals: 0 },
    energy:  { id: 'energy',  name: 'Énergie quantique',   short: 'Énergie',  color: 0xb47bff, hex: '#b47bff', decimals: 0 },
    core:    { id: 'core',    name: 'Noyaux antiques',     short: 'Noyaux',   color: 0xffd166, hex: '#ffd166', decimals: 1 },
    dust:    { id: 'dust',    name: 'Poussière cosmique',  short: 'Poussière', color: 0xff6ec7, hex: '#ff6ec7', decimals: 0 }
  };

  /**
   * Production de base au NIVEAU 1 (par seconde).
   *  extractor : production passive de l'extracteur (niveau 1)
   *  drone     : production passive apportée par CHAQUE drone minier
   *  tap       : gain d'une récolte manuelle (un tap sur le gisement)
   *  cap       : capacité de stockage de base (niveau 1 du Stockage)
   *  start     : ressources d'une nouvelle partie
   */
  var PROD = {
    crystal: { extractor: 0.50,  drone: 0.20,  tap: 3,    cap: 15000, start: 100 },
    metal:   { extractor: 0.40,  drone: 0.15,  tap: 2,    cap: 12000, start: 60 },
    energy:  { extractor: 0.20,  drone: 0.08,  tap: 1.2,  cap: 6000,  start: 30 },
    core:    { extractor: 0.010, drone: 0.004, tap: 0.04, cap: 300,   start: 0 },
    dust:    { extractor: 1.00,  drone: 0.40,  tap: 5,    cap: 30000, start: 150 }
  };

  var CFG = {
    RATE_GROWTH: 1.22,          // production ×1.22 par niveau d'extracteur
    TAP_GROWTH: 1.12,           // gain de récolte ×1.12 par niveau d'extracteur
    CAP_GROWTH: 1.5,            // capacité de stockage ×1.5 par niveau de Stockage
    COST_GROWTH: 1.55,          // coût d'amélioration ×1.55 par niveau
    HANGAR_DRONE_BONUS: 0.12,   // +12 % de rendement des drones par niveau de Hangar au-dessus de 1
    LAB_PRODUCTION_BONUS: 0.025,      // +2,5 % de production totale par niveau de Laboratoire au-dessus de 1
    DEFENSE_SECURITY_BONUS: 0.4,      // +0,4 sécurité effective du QG par niveau de Défense au-dessus de 1
    AMPLIFIER_PRODUCTION_BONUS: 0.05, // +5 % de production totale par niveau d'Amplificateur au-dessus de 1
    MAX_LEVEL: 50,
    MAX_DRONES: 12,
    START_DRONES: 1,            // drones par ressource au départ (5 au total)

    // Récolte manuelle : réserve de « charges » par gisement (empêche le spam infini)
    MAX_CHARGES: 8,
    CHARGE_REGEN_SEC: 3,        // 1 charge regagnée toutes les 3 s
    CRIT_CHANCE: 0.10,
    CRIT_MULT: 3,

    // Hors-ligne
    OFFLINE_MAX_SEC: 8 * 3600,  // on ne crédite jamais plus de 8 h d'absence
    OFFLINE_EFFICIENCY: 0.6,    // 60 % du rendement en ligne (jouer reste plus rentable)
    OFFLINE_REPORT_MIN_SEC: 60, // en dessous, pas de fenêtre « bon retour »
    GAP_THRESHOLD_SEC: 5,       // un trou de plus de 5 s entre deux frames = absence

    AUTOSAVE_SEC: 5,

    // Caisses de ravitaillement
    POD_MIN_SEC: 75,
    POD_MAX_SEC: 130,
    POD_LIFETIME_SEC: 25
  };

  var POD = {
    weights: { crystal: 30, metal: 28, energy: 20, dust: 30, core: 8 },
    secondsMin: 50,   // le lot vaut entre 50 et 90 s de production passive
    secondsMax: 90,
    floor: { crystal: 15, metal: 12, energy: 8, core: 0.2, dust: 30 }
  };

  /** Bâtiments : niveau de départ, coût de base (niveau 1 → 2) et texte d'info. */
  var BUILDINGS = {
    command: { id: 'command', name: 'Commandement', start: 3, base: { crystal: 400, metal: 400, energy: 150 },
      info: 'Centre de collecte : les drones y déposent leur cargaison.' },
    hangar:  { id: 'hangar', name: 'Hangar', start: 2, base: { crystal: 300, metal: 300, energy: 100 },
      info: 'Drones miniers : +12 % de rendement par niveau.' },
    lab:     { id: 'lab', name: 'Laboratoire', start: 1, base: { crystal: 350, energy: 200, dust: 400 },
      info: 'Recherches et technologies : augmente la production totale de toutes les ressources.' },
    defense: { id: 'defense', name: 'Défense', start: 1, base: { metal: 450, energy: 150, dust: 300 },
      info: 'Protection de la base : renforce la sécurité du QG contre les raids ennemis.' },
    qg: { id: 'qg', name: 'Quartier Général', start: 1, base: { crystal: 600, metal: 500, core: 2 },
      info: 'Coordination stratégique : débloque de nouveaux types d\'expéditions à mesure qu\'il monte de niveau.' },
    storage: { id: 'storage', name: 'Stockage', start: 1, base: { metal: 500, dust: 600 },
      info: 'Capacité de stockage ×1,5 par niveau.' },
    amplifier: { id: 'amplifier', name: 'Amplificateur quantique', start: 1, base: { crystal: 500, energy: 400, dust: 500 },
      info: 'Amplifie la production totale de toutes les ressources.' },
    ext_crystal: { id: 'ext_crystal', name: 'Extracteur de cristaux', start: 1, resource: 'crystal', base: { metal: 150, dust: 300 } },
    ext_metal:   { id: 'ext_metal',   name: 'Mine de métal',         start: 1, resource: 'metal',   base: { crystal: 120, dust: 250 } },
    ext_energy:  { id: 'ext_energy',  name: 'Réacteur quantique',    start: 1, resource: 'energy',  base: { crystal: 200, metal: 150 } },
    ext_core:    { id: 'ext_core',    name: 'Excavateur antique',    start: 1, resource: 'core',    base: { energy: 300, crystal: 400, metal: 300 } },
    ext_dust:    { id: 'ext_dust',    name: 'Collecteur de poussière', start: 1, resource: 'dust',  base: { crystal: 80, metal: 80 } }
  };
  var BUILDING_ORDER = ['command', 'hangar', 'lab', 'defense', 'qg', 'storage', 'amplifier',
    'ext_crystal', 'ext_metal', 'ext_energy', 'ext_core', 'ext_dust'];

  // ---------- Formules ----------

  function lvl(l) { l = Math.floor(Number(l)); return (isFinite(l) && l >= 1) ? Math.min(l, CFG.MAX_LEVEL) : 1; }

  function extractorRate(id, level) {
    return PROD[id].extractor * Math.pow(CFG.RATE_GROWTH, lvl(level) - 1);
  }
  function droneBonus(hangarLevel) {
    return 1 + CFG.HANGAR_DRONE_BONUS * (lvl(hangarLevel) - 1);
  }
  /** Production d'UN drone (par seconde). */
  function droneRate(id, hangarLevel) {
    return PROD[id].drone * droneBonus(hangarLevel);
  }
  /** Production totale passive d'une ressource (par seconde). Jamais négative. */
  /** Lit un multiplicateur d'équilibrage depuis l'Atelier créateur (tools/studio.html) s'il est chargé ; sinon 1 (aucun changement). */
  function cfgMult(key) {
    try {
      if (NEBUSTION.CustomContent && NEBUSTION.CustomContent.GameConfig) {
        var v = NEBUSTION.CustomContent.GameConfig.get(key);
        if (v > 0) return v;
      }
    } catch (e) {}
    return 1;
  }
  function totalRate(id, extractorLevel, droneCount, hangarLevel) {
    var n = Math.max(0, Math.floor(Number(droneCount) || 0));
    var r = (extractorRate(id, extractorLevel) + n * droneRate(id, hangarLevel)) * cfgMult('eco_global_prod_mult');
    return (isFinite(r) && r > 0) ? r : 0;
  }
  function tapYield(id, extractorLevel) {
    return PROD[id].tap * Math.pow(CFG.TAP_GROWTH, lvl(extractorLevel) - 1) * cfgMult('eco_global_tap_mult');
  }
  function storageCap(id, storageLevel) {
    return Math.floor(PROD[id].cap * Math.pow(CFG.CAP_GROWTH, lvl(storageLevel) - 1));
  }
  /** Bonus de production totale (multiplicateur additif) apporté par le Laboratoire, au-delà du niveau 1. */
  function labBonus(level) { return CFG.LAB_PRODUCTION_BONUS * (lvl(level) - 1); }
  /** Bonus de sécurité effective du QG apporté par la Défense, au-delà du niveau 1. */
  function defenseBonus(level) { return CFG.DEFENSE_SECURITY_BONUS * (lvl(level) - 1); }
  /** Bonus de production totale (multiplicateur additif) apporté par l'Amplificateur, au-delà du niveau 1. */
  function amplifierBonus(level) { return CFG.AMPLIFIER_PRODUCTION_BONUS * (lvl(level) - 1); }

  /** Coût pour passer du niveau `level` au suivant. */
  function upgradeCost(buildingId, level) {
    var def = BUILDINGS[buildingId];
    var out = {};
    if (!def) return out;
    var mult = Math.pow(CFG.COST_GROWTH, lvl(level) - 1) * cfgMult('eco_building_cost_mult');
    Object.keys(def.base).forEach(function (rid) { out[rid] = Math.ceil(def.base[rid] * mult); });
    return out;
  }

  /**
   * Texte « effet de l'amélioration » (niveau actuel → niveau suivant) affiché dans le panneau d'amélioration.
   * Pur (aucune dépendance à Phaser). Le Commandement est complété côté interface (objectif de Renaissance).
   */
  function effectText(buildingId, level) {
    var def = BUILDINGS[buildingId];
    if (!def) return '';
    var l = lvl(level);
    if (l >= CFG.MAX_LEVEL) return 'Niveau maximum atteint';
    if (def.resource) {
      var id = def.resource;
      var t0 = fmtGain(tapYield(id, l)), t1 = fmtGain(tapYield(id, l + 1));
      return 'Extracteur ' + fmtRate(extractorRate(id, l)) + ' → ' + fmtRate(extractorRate(id, l + 1)) + ' /s' +
        (t0 !== t1 ? '  •  Récolte ' + t0 + ' → ' + t1 : '');
    }
    if (buildingId === 'hangar') {
      var p0 = Math.round((droneBonus(l) - 1) * 100), p1 = Math.round((droneBonus(l + 1) - 1) * 100);
      return 'Drones : +' + p0 + ' % → +' + p1 + ' % de rendement';
    }
    if (buildingId === 'storage') {
      return 'Capacité ×1,5  •  cristaux ' + fmt(storageCap('crystal', l), 0) + ' → ' + fmt(storageCap('crystal', l + 1), 0);
    }
    if (buildingId === 'command') return 'Niveau requis pour la Renaissance';
    if (buildingId === 'lab') {
      var lp0 = Math.round(labBonus(l) * 100), lp1 = Math.round(labBonus(l + 1) * 100);
      return 'Production totale +' + lp0 + ' % → +' + lp1 + ' %';
    }
    if (buildingId === 'defense') {
      var dp0 = Math.round(defenseBonus(l) * 10) / 10, dp1 = Math.round(defenseBonus(l + 1) * 10) / 10;
      return 'Sécurité du QG +' + dp0 + ' → +' + dp1 + '  •  atténue les raids ennemis';
    }
    if (buildingId === 'amplifier') {
      var ap0 = Math.round(amplifierBonus(l) * 100), ap1 = Math.round(amplifierBonus(l + 1) * 100);
      return 'Production totale +' + ap0 + ' % → +' + ap1 + ' %';
    }
    if (buildingId === 'qg' && window.NEBUSTION.Expeditions) {
      var next = window.NEBUSTION.Expeditions.TYPE_ORDER
        .map(function (tid) { return window.NEBUSTION.Expeditions.TYPES[tid]; })
        .find(function (t) { return t.unlockQG === l + 1; });
      return next ? 'Débloque les expéditions « ' + next.name + ' »' : 'Aucun nouveau déblocage à ce niveau';
    }
    return '';
  }

  /**
   * Tire le contenu d'une caisse de ravitaillement.
   * @param {object} rates  production par seconde de chaque ressource
   * @param {function} rng  générateur dans [0,1)
   * @returns {Array<{id:string, amount:number}>} 2 ressources distinctes, montants > 0
   */
  function rollPodReward(rates, rng) {
    rng = rng || Math.random;
    var pool = ORDER.slice();
    var picks = [];
    for (var n = 0; n < 2; n++) {
      var total = 0;
      pool.forEach(function (id) { total += POD.weights[id]; });
      var roll = rng() * total, chosen = pool[pool.length - 1];
      for (var i = 0; i < pool.length; i++) {
        roll -= POD.weights[pool[i]];
        if (roll < 0) { chosen = pool[i]; break; }
      }
      pool.splice(pool.indexOf(chosen), 1);
      var secs = POD.secondsMin + rng() * (POD.secondsMax - POD.secondsMin);
      var amount = Math.max(POD.floor[chosen], (rates[chosen] || 0) * secs);
      amount = chosen === 'core' ? Math.round(amount * 10) / 10 : Math.round(amount);
      picks.push({ id: chosen, amount: Math.max(amount, chosen === 'core' ? 0.1 : 1) });
    }
    return picks;
  }

  // ---------- Formats d'affichage (toujours arrondis vers le BAS : jamais de valeur affichée > réelle) ----------

  function trim(x, d) { return String(parseFloat(x.toFixed(d))); }
  function floorTo(v, d) { var m = Math.pow(10, d); return Math.floor(v * m + 1e-9) / m; }
  function grouped(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' '); }

  /** Montant de stock : 8 452 · 12.4K · 1.25M */
  function fmt(v, decimals) {
    v = Number(v);
    if (!isFinite(v) || v < 0) v = 0;
    decimals = decimals || 0;
    if (v >= 1e9) return trim(floorTo(v / 1e9, 2), 2) + 'B';
    if (v >= 1e6) return trim(floorTo(v / 1e6, 2), 2) + 'M';
    if (v >= 1e4) return trim(floorTo(v / 1e3, 1), 1) + 'K';
    if (decimals > 0) return floorTo(v, decimals).toFixed(decimals);
    return grouped(Math.floor(v + 1e-9));
  }
  /** Gain ponctuel (popup) : 4 · 4.48 · 0.05 · 120 */
  function fmtGain(v) {
    v = Number(v);
    if (!isFinite(v) || v <= 0) return '0';
    if (v >= 1000) return fmt(v, 0);
    if (v >= 100) return String(Math.round(v));
    if (v >= 10) return trim(v, 1);
    if (v >= 0.01) return trim(v, 2);
    return '<0.01';
  }
  /** Taux : 0.014 · 0.72 · 14.5 · 128 · 1.2K */
  function fmtRate(r) {
    r = Number(r);
    if (!isFinite(r) || r < 0) r = 0;
    if (r >= 1000) return fmt(r, 0);
    if (r >= 100) return String(Math.round(r));
    if (r >= 10) return r.toFixed(1);
    if (r >= 0.1) return r.toFixed(2);
    if (r >= 0.01) return r.toFixed(3);
    return r.toFixed(4);
  }
  function fmtDuration(sec) {
    sec = Math.max(0, Math.floor(Number(sec) || 0));
    var h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
    if (h > 0) return h + ' h ' + (m < 10 ? '0' : '') + m + ' min';
    if (m > 0) return m + ' min ' + (s < 10 ? '0' : '') + s + ' s';
    return s + ' s';
  }

  return {
    ORDER: ORDER, RES: RES, PROD: PROD, CFG: CFG, POD: POD,
    BUILDINGS: BUILDINGS, BUILDING_ORDER: BUILDING_ORDER,
    extractorRate: extractorRate, droneRate: droneRate, droneBonus: droneBonus, totalRate: totalRate,
    labBonus: labBonus, defenseBonus: defenseBonus, amplifierBonus: amplifierBonus,
    tapYield: tapYield, storageCap: storageCap, upgradeCost: upgradeCost, effectText: effectText, rollPodReward: rollPodReward,
    fmt: fmt, fmtGain: fmtGain, fmtRate: fmtRate, fmtDuration: fmtDuration
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.Economy; }
