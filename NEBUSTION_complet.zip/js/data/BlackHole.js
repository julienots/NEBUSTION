/**
 * NEBUSTION - BlackHole (données + formules pures)
 * Le Trou Noir n'est plus une simple curiosité visuelle : c'est une VRAIE zone d'exploration à
 * profondeurs progressives, avec des rencontres procédurales, une monnaie dédiée (Fragments de
 * Singularité), des améliorations permanentes et un Comptoir de l'Abîme pour les dépenser.
 * AUCUNE dépendance à Phaser (testable sous Node, comme Economy.js / Expeditions.js).
 *
 * PRINCIPE DE PLONGÉE :
 *  - Une plongée avance par PROFONDEURS (1, 2, 3...). À chaque profondeur, le joueur reçoit 2 ou 3
 *    options (choiceOptions), chacune annotée d'un simple niveau de danger (1 = calme, 2 = trouble,
 *    3 = chaotique) — le TYPE exact de la rencontre n'est révélé qu'à la résolution (resolveChoice),
 *    pour garder une vraie tension d'exploration sans jamais tricher : les deux fonctions sont pures
 *    et déterministes (seed de la plongée + profondeur + index d'option), donc rejouables/testables.
 *  - Tous les seuils multiples de CFG.CHECKPOINT_EVERY forcent UNE option "Seuil de la Singularité"
 *    (abime) : une rencontre plus dure, plus payante, qui rythme la descente comme des mini-boss.
 *  - AUCUNE perte définitive : reculer ("remonter") ne coûte jamais rien de ce qui a déjà été
 *    gagné (tout est crédité immédiatement au fil de la descente). Seule l'Intégrité de la sonde
 *    limite la profondeur atteignable en une plongée ; à 0, la plongée se termine (sans pénalité
 *    au-delà de la fin de l'exploration).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.BlackHole = (function () {
  'use strict';

  var CFG = {
    MAX_CHARGES: 3,                    // plongées "fraîches" disponibles sans attendre
    CHARGE_REGEN_MS: 3 * 3600 * 1000,  // 1 charge récupérée toutes les 3 h (temps réel)
    MAX_INTEGRITY_BASE: 100,
    CHECKPOINT_EVERY: 5,               // profondeurs 5, 10, 15... : un Seuil forcé parmi les options
    FRAGMENT_BASE: 2.2,
    POWER_BASE: 250,                   // puissance d'équipe recommandée à la profondeur 1
    POWER_GROWTH: 1.135,               // croissance de la puissance recommandée par profondeur
    EQUIV_SEC: 210,                    // "durée équivalente" de production convertie en butin ponctuel
    ABIME_POWER_MULT: 1.4,             // les Seuils demandent plus de puissance qu'un Écho normal
    VARIANCE_MIN: 0.85, VARIANCE_MAX: 1.15
  };

  // ---------- Zones (thème visuel + multiplicateur de récompense croissant) ----------
  var ZONES = [
    { id: 'horizon',     name: 'Horizon des Événements',   depthFrom: 1,  depthTo: 4,        color: 0x4fc3ff, hex: '#4fc3ff', mult: 1.0 },
    { id: 'anneau',      name: 'Anneau de Feu',            depthFrom: 5,  depthTo: 9,        color: 0xff8a3c, hex: '#ff8a3c', mult: 1.6 },
    { id: 'maree',       name: 'Marée Gravitationnelle',   depthFrom: 10, depthTo: 14,       color: 0x6c3ce9, hex: '#6c3ce9', mult: 2.4 },
    { id: 'spaghetti',   name: 'Spaghettification',        depthFrom: 15, depthTo: 19,       color: 0xff4d6d, hex: '#ff4d6d', mult: 3.6 },
    { id: 'noyau',       name: 'Le Noyau',                 depthFrom: 20, depthTo: 24,       color: 0xffd166, hex: '#ffd166', mult: 5.2 },
    { id: 'singularite', name: 'La Singularité',           depthFrom: 25, depthTo: Infinity, color: 0xeafcff, hex: '#eafcff', mult: 7.5 }
  ];

  function zoneForDepth(depth) {
    depth = Math.max(1, Math.floor(depth) || 1);
    for (var i = 0; i < ZONES.length; i++) { if (depth >= ZONES[i].depthFrom && depth <= ZONES[i].depthTo) return ZONES[i]; }
    return ZONES[ZONES.length - 1];
  }
  /** Multiplicateur de récompense continu : croît encore À L'INTÉRIEUR d'une zone, pas de palier plat. */
  function zoneMultAt(depth) {
    var z = zoneForDepth(depth);
    var span = Math.max(1, (isFinite(z.depthTo) ? z.depthTo : depth + 10) - z.depthFrom);
    var progress = Math.min(1.5, (depth - z.depthFrom) / span);
    return z.mult * (1 + progress * 0.35);
  }
  /** Puissance d'équipe recommandée pour un Écho à cette profondeur (voir Expeditions.js pour l'échelle des héros). */
  function requiredPower(depth) { return Math.round(CFG.POWER_BASE * Math.pow(CFG.POWER_GROWTH, Math.max(0, depth - 1))); }

  // ---------- Améliorations permanentes de la sonde (achetées avec des Fragments) ----------
  var TALENTS = {
    hull: { id: 'hull', name: 'Coque renforcée', desc: '+10 Intégrité maximale', maxLevel: 5, baseCost: 12, growth: 1.65, perLevel: 10 },
    prod: { id: 'prod', name: 'Résonance productive', desc: '+6 % ressources et Fragments gagnés', maxLevel: 5, baseCost: 15, growth: 1.7, perLevel: 0.06 },
    luck: { id: 'luck', name: 'Détecteur amélioré', desc: 'Favorise les trouvailles, atténue les dangers', maxLevel: 5, baseCost: 15, growth: 1.7, perLevel: 0.10 }
  };
  var TALENT_ORDER = ['hull', 'prod', 'luck'];

  function talentLevel(talents, id) { return Math.max(0, Math.min(TALENTS[id].maxLevel, Math.floor((talents && talents[id]) || 0))); }
  function talentCost(id, currentLevel) {
    var t = TALENTS[id]; if (!t) return null;
    currentLevel = Math.max(0, Math.floor(currentLevel) || 0);
    if (currentLevel >= t.maxLevel) return null;
    return Math.round(t.baseCost * Math.pow(t.growth, currentLevel));
  }
  function maxIntegrity(talents) { return CFG.MAX_INTEGRITY_BASE + talentLevel(talents, 'hull') * TALENTS.hull.perLevel; }
  function prodBonus(talents) { return talentLevel(talents, 'prod') * TALENTS.prod.perLevel; }
  function luckLevel(talents) { return talentLevel(talents, 'luck'); }

  // ---------- Comptoir de l'Abîme : Fragments → ressources ciblées (+ un peu de Prismes, limité) ----------
  var EXCHANGE_OFFERS = [
    { id: 'ex_crystal', resId: 'crystal', cost: 6,  equivSec: 170 },
    { id: 'ex_metal',   resId: 'metal',   cost: 6,  equivSec: 170 },
    { id: 'ex_energy',  resId: 'energy',  cost: 8,  equivSec: 170 },
    { id: 'ex_dust',    resId: 'dust',    cost: 6,  equivSec: 170 },
    { id: 'ex_core',    resId: 'core',    cost: 26, equivSec: 520 },
    { id: 'ex_gem',     gem: 3,           cost: 50, dailyLimit: 3 }
  ];
  function exchangeOffer(id) { for (var i = 0; i < EXCHANGE_OFFERS.length; i++) { if (EXCHANGE_OFFERS[i].id === id) return EXCHANGE_OFFERS[i]; } return null; }
  /** Montant de ressource accordé par un échange, calé sur la production ACTUELLE (jamais dérisoire en fin de partie). */
  function exchangeAmount(offer, rates) {
    if (!offer || !offer.resId) return 0;
    var rate = Math.max(0, Number(rates && rates[offer.resId]) || 0);
    return Math.max(1, Math.round(rate * offer.equivSec));
  }

  // ---------- RNG déterministe (mulberry32, comme Expeditions._rng) ----------
  function _rng(seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a; t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function _mix(a, b) { return (Math.imul(a ^ b, 0x45d9f3b)) >>> 0; }
  /** Seed dérivée : même (seed, depth, salt) → toujours le même flux de tirages (testable, pas de mémoire cachée). */
  function _stepSeed(seed, depth, salt) {
    var s = (Number(seed) >>> 0) ^ Math.imul(((Number(depth) || 0) + 1) >>> 0, 0x9E3779B1);
    return _mix(s, ((Number(salt) || 0) + 1) >>> 0);
  }
  function _weightedPick(rng, pool) {
    var total = 0, i;
    for (i = 0; i < pool.length; i++) total += Math.max(0, pool[i].w);
    if (total <= 0) return pool[pool.length - 1].kind;
    var r = rng() * total, acc = 0;
    for (i = 0; i < pool.length; i++) { acc += Math.max(0, pool[i].w); if (r <= acc) return pool[i].kind; }
    return pool[pool.length - 1].kind;
  }
  function _variance(rng) { return CFG.VARIANCE_MIN + rng() * (CFG.VARIANCE_MAX - CFG.VARIANCE_MIN); }

  // ---------- Bassins de rencontre par niveau de danger (le "Seuil" est injecté à part, voir choiceOptions) ----------
  var DANGER_POOLS = {
    1: [{ kind: 'cache', w: 60 }, { kind: 'anomalie_positive', w: 25 }, { kind: 'sanctuaire', w: 15 }],
    2: [{ kind: 'cache', w: 30 }, { kind: 'relique', w: 20 }, { kind: 'anomalie_negative', w: 20 }, { kind: 'echo', w: 30 }],
    3: [{ kind: 'echo', w: 45 }, { kind: 'relique', w: 25 }, { kind: 'anomalie_negative', w: 30 }]
  };
  function _luckPool(pool, luck) {
    if (!luck) return pool;
    var shift = Math.min(0.6, luck);
    return pool.map(function (p) {
      if (p.kind === 'anomalie_negative') return { kind: p.kind, w: p.w * (1 - shift) };
      if (p.kind === 'cache' || p.kind === 'sanctuaire') return { kind: p.kind, w: p.w * (1 + shift) };
      return p;
    });
  }

  var DANGER_LABELS = {
    1: { label: 'Signal stable', hex: '#5fd97a' },
    2: { label: 'Signal trouble', hex: '#ffb84d' },
    3: { label: 'Signal chaotique', hex: '#ff4d6d' }
  };

  var KIND_META = {
    cache:              { name: 'Cache de ressources' },
    anomalie_positive:  { name: 'Accalmie gravitationnelle' },
    anomalie_negative:  { name: 'Choc de marée' },
    relique:            { name: 'Relique de l\u2019Abîme' },
    echo:               { name: 'Écho hostile' },
    sanctuaire:         { name: 'Point d\u2019ancrage' },
    abime:              { name: 'Seuil de la Singularité' }
  };
  var FLAVOR = {
    cache: [
      'Une poche de matière encore intacte dérive dans le flux : vos capteurs s\u2019en emparent.',
      'Un fragment d\u2019épave ancienne, rongé par la marée gravitationnelle, cède ses restes.',
      'La sonde capte un dépôt minéral compressé par la pression de l\u2019horizon.',
      'Des cristaux de glace exotique, formés par un froid impossible, se brisent contre la coque.'
    ],
    anomalie_positive: [
      'Une poche de calme improbable, au cœur du chaos : la coque se stabilise.',
      'Le flux temporel ralentit un instant, assez pour que les réparateurs automatiques agissent.',
      'Une résonance apaisante traverse la structure ; les capteurs de stress redescendent.',
      'Un courant de matière froide referme lentement les micro-fractures de la coque.'
    ],
    anomalie_negative: [
      'Une onde de marée gravitationnelle tord la coque en un instant douloureux.',
      'La pression différentielle grince contre les plaques externes.',
      'Un éclat de débris à vitesse relativiste traverse le blindage secondaire.',
      'L\u2019espace se plisse brièvement — tout à bord ressent le déchirement.'
    ],
    relique: [
      'Un fragment cristallisé, plus vieux que toute étoile connue, flotte intact.',
      'Une relique métallique porte des inscriptions qu\u2019aucun catalogue ne reconnaît.',
      'Quelque chose ici a été façonné, pas formé par le hasard.',
      'Un noyau de résonance pure vibre à une fréquence étrangement familière.'
    ],
    echo: [
      'Une présence hostile se matérialise à la lisière du disque d\u2019accrétion.',
      'Un écho de combat, figé puis relâché par la distorsion, s\u2019anime soudain.',
      'Quelque chose, prisonnier de l\u2019horizon depuis des siècles, sort de sa torpeur.',
      'Un fragment d\u2019intelligence hostile, déformé par la gravité, tente une frappe.'
    ],
    sanctuaire: [
      'Une poche de gravité neutre, stable, presque accueillante.',
      'Ici, pour un instant, l\u2019horizon ne tire dans aucune direction.',
      'Un point d\u2019ancrage improbable : la sonde s\u2019y repose, intacte.',
      'Le silence, pour une fois, n\u2019a rien de menaçant.'
    ],
    abime: [
      'Au bord du Seuil, quelque chose d\u2019immense semble ouvrir les yeux.',
      'La singularité elle-même paraît se retourner vers vous.',
      'Ce n\u2019est plus un simple écho : c\u2019est une volonté, ancienne et froide.',
      'Le Seuil ne se franchit jamais sans qu\u2019il en coûte quelque chose.'
    ]
  };
  function _flavor(rng, kind) { var pool = FLAVOR[kind] || ['...']; return pool[Math.floor(rng() * pool.length) % pool.length]; }

  var RES_WEIGHTS = { crystal: 26, metal: 24, energy: 22, dust: 24, core: 4 };
  function _pickResId(rng) {
    var pool = Object.keys(RES_WEIGHTS).map(function (id) { return { kind: id, w: RES_WEIGHTS[id] }; });
    return _weightedPick(rng, pool);
  }
  function _rate(rates, id) { return Math.max(0, Number(rates && rates[id]) || 0); }

  // ---------- Rencontres JOUABLES (arène temps réel : BlackHoleRunScene) ----------
  // Chaque type de rencontre "actif" devient une vraie épreuve pilotée au doigt. Les autres (point
  // d'ancrage, accalmie) restent instantanés : ce sont des moments de repos.
  var MODE_OF = { cache: 'collect', relique: 'collect', anomalie_negative: 'dodge', echo: 'fight', abime: 'fight' };
  function modeOf(kind) { return MODE_OF[kind] || null; }
  function _clamp(x, a, b) { return x < a ? a : (x > b ? b : x); }
  /** Dégâts d'Intégrité par impact dans l'arène (croît avec la profondeur, comme les pertes du mode texte). */
  function hitDamage(depth) { return Math.round(4 + Math.max(1, Math.floor(depth) || 1) * 0.6); }
  var ENEMY_BY_ZONE = {
    horizon: ['drone_sentinel', 'spore_swarm'], anneau: ['cinder_bomber', 'voltaic_hunter'],
    maree: ['glacial_specter', 'umbra_sniper'], spaghetti: ['stellar_vampire', 'steel_golem'],
    noyau: ['corvex_juggernaut', 'nexus_architect'], singularite: ['nexus_architect', 'corvex_juggernaut']
  };
  var BOSS_IDS = ['vorath', 'nexus_prime', 'omega_krell', 'nebustion_primordiale'];

  /** Type de rencontre que produira l'option choisie (même tirage que resolveChoice : PUR et cohérent). */
  function previewKind(seed, depth, option, talents) {
    option = option || {}; depth = Math.max(1, Math.floor(depth) || 1);
    if (option.forced === 'abime') return 'abime';
    var rng = _rng(_stepSeed(seed, depth, 100 + (Math.max(0, option.idx | 0))));
    var luck = luckLevel(talents) * TALENTS.luck.perLevel;
    return _weightedPick(rng, _luckPool(DANGER_POOLS[option.danger] || DANGER_POOLS[1], luck));
  }

  /** Paramètres de l'épreuve (null si la rencontre n'est pas jouable). Déterministe pour (seed, depth, idx). */
  function arenaParams(kind, depth, teamPower, seed, idx) {
    var mode = modeOf(kind); if (!mode) return null;
    depth = Math.max(1, Math.floor(depth) || 1);
    var zone = zoneForDepth(depth), r = _rng(_stepSeed(seed, depth, 900 + (idx | 0)));
    var p = {
      mode: mode, kind: kind, depth: depth, zoneHex: zone.hex, zoneColor: zone.color, zoneName: zone.name,
      hitDmg: hitDamage(depth), speedMult: Math.min(2.2, 1 + depth * 0.03), resId: _pickResId(r)
    };
    if (mode === 'collect') {
      p.duration = 12; p.total = 14; p.hazardEvery = Math.max(0.5, 1.15 - depth * 0.02);
    } else if (mode === 'dodge') {
      p.duration = 10; p.hazardEvery = Math.max(0.3, 0.55 - depth * 0.01); p.waveEvery = 2.4;
    } else {
      var boss = kind === 'abime', pool = ENEMY_BY_ZONE[zone.id] || ENEMY_BY_ZONE.horizon;
      p.boss = boss;
      p.ratio = Math.max(0, Number(teamPower) || 0) / Math.max(1, requiredPower(depth) * (boss ? CFG.ABIME_POWER_MULT : 1));
      p.duration = boss ? 28 : 20;
      p.enemyHp = 100;
      p.enemyId = boss ? BOSS_IDS[(Math.floor(depth / CFG.CHECKPOINT_EVERY) - 1 + BOSS_IDS.length * 10) % BOSS_IDS.length] : pool[Math.floor(r() * pool.length) % pool.length];
      // Dégâts par seconde de la sonde : dépend de la puissance de l'équipe (les héros comptent toujours).
      p.playerDps = 100 / (p.duration * 0.85) * _clamp(p.ratio, 0.4, 2.2);   // à puissance recommandée (x1) : ~85 % du temps avec ~35 % de tirs au but
      p.enemyFireEvery = Math.max(0.55, (boss ? 1.1 : 1.5) - depth * 0.02);
    }
    return p;
  }

  /**
   * Options offertes à la profondeur `depth` (celle qu'on s'apprête à atteindre), pour une plongée
   * de seed `seed`. Fonction PURE : toujours le même résultat pour les mêmes arguments.
   * @returns {Array<{idx:number, danger:1|2|3, forced:'abime'|null}>}
   */
  function choiceOptions(seed, depth) {
    var n = 3;
    var rng = _rng(_stepSeed(seed, depth, 0));
    var checkpoint = depth > 0 && depth % CFG.CHECKPOINT_EVERY === 0;
    var forcedIdx = checkpoint ? Math.floor(rng() * n) : -1;
    var out = [];
    for (var i = 0; i < n; i++) {
      if (i === forcedIdx) { out.push({ idx: i, danger: 3, forced: 'abime' }); continue; }
      var roll = rng();
      var d = roll < 0.45 ? 1 : (roll < 0.8 ? 2 : 3);
      out.push({ idx: i, danger: d, forced: null });
    }
    return out;
  }

  /**
   * Résout UNE option choisie parmi celles de choiceOptions(seed, depth). Fonction PURE (aucune
   * écriture d'état : c'est BlackHoleManager qui applique le résultat à la sauvegarde).
   * @param input {seed, depth, option, teamPower, rates, talents}
   * @returns {{kind, title, body, integrityDelta, resources:object, fragments:number, gems:number,
   *            success:boolean|null, ratio:number|null}}
   */
  function resolveChoice(input) {
    input = input || {};
    var seed = input.seed, depth = Math.max(1, Math.floor(input.depth) || 1), option = input.option || {};
    var rates = input.rates || {}, talents = input.talents || {};
    var teamPower = Math.max(0, Number(input.teamPower) || 0);
    var rng = _rng(_stepSeed(seed, depth, 100 + (Math.max(0, option.idx | 0))));
    var mult = zoneMultAt(depth);
    var bonus = 1 + prodBonus(talents);
    var luck = luckLevel(talents) * TALENTS.luck.perLevel;

    var kind;
    if (option.forced === 'abime') kind = 'abime';
    else kind = _weightedPick(rng, _luckPool(DANGER_POOLS[option.danger] || DANGER_POOLS[1], luck));

    var out = { kind: kind, title: KIND_META[kind].name, body: _flavor(rng, kind), integrityDelta: 0, resources: {}, fragments: 0, gems: 0, success: null, ratio: null };

    function grantRes(id, base) {
      var amt = Math.round(_rate(rates, id) * CFG.EQUIV_SEC * mult * base * bonus * _variance(rng));
      if (amt > 0) out.resources[id] = (out.resources[id] || 0) + amt;
    }
    function grantFrag(base) { out.fragments += Math.max(0, Math.round(CFG.FRAGMENT_BASE * mult * base * bonus * _variance(rng))); }

    // --- Rencontre JOUÉE : le résultat vient de la performance dans l'arène (input.perf), pas d'un jet de dés ---
    if (input.perf && MODE_OF[kind]) {
      var pf = {
        score: _clamp(Number(input.perf.score) || 0, 0, 1), win: !!input.perf.win,
        damage: Math.round(_clamp(Number(input.perf.damage) || 0, 0, 1e4)),
        resId: RES_WEIGHTS[input.perf.resId] ? input.perf.resId : null
      };
      var sc = pf.score;
      out.played = true;
      out.integrityDelta = -pf.damage;
      if (kind === 'cache') {
        grantRes(pf.resId || _pickResId(rng), 0.35 + 1.1 * sc);
      } else if (kind === 'relique') {
        grantFrag(0.4 + 1.1 * sc);
      } else if (kind === 'anomalie_negative') {
        if (pf.damage === 0) grantFrag(0.5);            // esquive parfaite
      } else {
        var rq = requiredPower(depth) * (kind === 'abime' ? CFG.ABIME_POWER_MULT : 1);
        out.ratio = teamPower / Math.max(1, rq);
        var rs = kind === 'abime' ? 2.2 : 1.4, fs = kind === 'abime' ? 2.0 : 0.6;
        out.success = pf.win;
        if (pf.win) {
          grantRes(pf.resId || _pickResId(rng), rs * (0.85 + 0.3 * sc));
          if (kind === 'abime') grantRes(_pickResId(rng), rs * 0.6);
          grantFrag(fs * (0.9 + 0.2 * sc));
          if (kind === 'abime' && rng() < 0.08) out.gems = 2 + Math.floor(rng() * 3);
        } else {
          grantRes(pf.resId || _pickResId(rng), rs * 0.4 * sc);
          grantFrag(fs * 0.5 * sc);
        }
      }
      return out;
    }

    if (kind === 'cache') {
      grantRes(_pickResId(rng), 1.0);
      out.integrityDelta = 0;
    } else if (kind === 'anomalie_positive') {
      out.integrityDelta = Math.round(15 + rng() * 10);
    } else if (kind === 'anomalie_negative') {
      out.integrityDelta = -Math.round(15 + rng() * 15);
    } else if (kind === 'relique') {
      grantFrag(1.0);
      out.integrityDelta = Math.round(rng() * 6);
    } else if (kind === 'sanctuaire') {
      out.integrityDelta = Math.round(30 + rng() * 15);
      grantFrag(0.35);
    } else if (kind === 'echo' || kind === 'abime') {
      var reqPower = requiredPower(depth) * (kind === 'abime' ? CFG.ABIME_POWER_MULT : 1);
      var ratio = teamPower / Math.max(1, reqPower);
      out.ratio = ratio;
      var resScale = kind === 'abime' ? 2.2 : 1.4, fragScale = kind === 'abime' ? 2.0 : 0.6;
      if (ratio >= 1.0) {
        out.success = true;
        grantRes(_pickResId(rng), resScale);
        if (kind === 'abime') grantRes(_pickResId(rng), resScale * 0.6);
        grantFrag(fragScale);
        out.integrityDelta = -Math.round(5 + rng() * 8);
        if (kind === 'abime' && rng() < 0.08) out.gems = 2 + Math.floor(rng() * 3);
      } else if (ratio >= 0.55) {
        out.success = false;
        grantRes(_pickResId(rng), resScale * 0.45);
        grantFrag(fragScale * 0.5);
        out.integrityDelta = -Math.round(15 + rng() * 12);
      } else {
        out.success = false;
        grantFrag(kind === 'abime' ? 0.3 : 0);
        out.integrityDelta = -Math.round(25 + rng() * 18);
      }
    }
    return out;
  }

  return {
    CFG: CFG, ZONES: ZONES, TALENTS: TALENTS, TALENT_ORDER: TALENT_ORDER, EXCHANGE_OFFERS: EXCHANGE_OFFERS,
    DANGER_LABELS: DANGER_LABELS, KIND_META: KIND_META,
    zoneForDepth: zoneForDepth, zoneMultAt: zoneMultAt, requiredPower: requiredPower,
    talentLevel: talentLevel, talentCost: talentCost, maxIntegrity: maxIntegrity, prodBonus: prodBonus, luckLevel: luckLevel,
    exchangeOffer: exchangeOffer, exchangeAmount: exchangeAmount,
    choiceOptions: choiceOptions, resolveChoice: resolveChoice,
    MODE_OF: MODE_OF, modeOf: modeOf, hitDamage: hitDamage, previewKind: previewKind, arenaParams: arenaParams
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.BlackHole; }
