/**
 * NEBUSTION - Enemies
 * Données pures (aucune dépendance à Phaser, testable sous Node) du module Combat :
 *  - 10 ennemis réguliers uniques + 3 boss galactiques uniques (avec phases).
 *  - Table de stages (progression) : chaque stage oppose l'équipe du joueur à une
 *    petite escouade d'ennemis. Les 3 derniers stages "boss_*" affrontent un boss.
 *  - Niveaux de difficulté (multiplicateurs de stats/récompenses).
 *  - Table de récompenses (ressources déjà définies dans Economy.js + XP + fragments
 *    de héros), modulée par le nombre d'étoiles obtenues (0 à 3) et la difficulté.
 *
 * Comme pour Heroes.js, chaque ennemi porte un champ "visual" utilisé par
 * EnemyTextures.js pour générer une silhouette procédurale distincte.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Enemies = (function () {
  'use strict';

  // ---------- Ennemis réguliers (10, tiers 1 à 10) ----------
  var ENEMY_LIST = [
    {
      id: 'drone_sentinel', name: 'Drone Sentinelle', tier: 1, role: 'grunt',
      base: { hp: 260, atk: 40, def: 20, spd: 70 },
      visual: { shape: 'drone', color: '#7a89ad', accent: '#c7d1ea' },
      skill: null
    },
    {
      id: 'voltaic_hunter', name: 'Chasseur Voltaïque', tier: 2, role: 'skirmisher',
      base: { hp: 320, atk: 58, def: 22, spd: 118 },
      visual: { shape: 'hunter', color: '#4fd1ff', accent: '#eafcff' },
      skill: { name: 'Décharge en chaîne', cooldown: 7, target: 'allEnemies_player', kind: 'aoeDamage', power: 0.75 }
    },
    {
      id: 'corvex_juggernaut', name: 'Blindé Corvex', tier: 3, role: 'brute',
      base: { hp: 780, atk: 66, def: 58, spd: 56 },
      visual: { shape: 'juggernaut', color: '#ff8a3d', accent: '#3a2008' },
      skill: { name: 'Charge blindée', cooldown: 9, target: 'single', kind: 'singleDamage', power: 2.0 }
    },
    {
      id: 'spore_swarm', name: 'Nuée Sporale', tier: 3, role: 'swarm',
      base: { hp: 300, atk: 46, def: 18, spd: 96 },
      visual: { shape: 'swarm', color: '#9cff8a', accent: '#173a12' },
      skill: { name: 'Nuage toxique', cooldown: 8, target: 'allEnemies_player', kind: 'aoeDamage', power: 0.6 }
    },
    {
      id: 'umbra_sniper', name: 'Sniper Umbra', tier: 4, role: 'sniper',
      base: { hp: 340, atk: 96, def: 24, spd: 90 },
      visual: { shape: 'sniper', color: '#b47bff', accent: '#20143a' },
      skill: { name: 'Tir de précision', cooldown: 7, target: 'single', kind: 'singleDamage', power: 2.3 }
    },
    {
      id: 'cinder_bomber', name: 'Bombardier Cinder', tier: 5, role: 'bomber',
      base: { hp: 460, atk: 78, def: 30, spd: 64 },
      visual: { shape: 'bomber', color: '#ff4d4d', accent: '#2a0808' },
      skill: { name: 'Explosion incendiaire', cooldown: 9, target: 'allEnemies_player', kind: 'aoeDamage', power: 1.0 }
    },
    {
      id: 'glacial_specter', name: 'Spectre Glacial', tier: 5, role: 'control',
      base: { hp: 420, atk: 62, def: 34, spd: 100 },
      visual: { shape: 'specter', color: '#8fd8ff', accent: '#0b2038' },
      skill: { name: 'Étreinte gelée', cooldown: 8, target: 'single', kind: 'stun', power: 0.9 }
    },
    {
      id: 'steel_golem', name: 'Golem d\'Acier', tier: 6, role: 'tank',
      base: { hp: 1150, atk: 60, def: 96, spd: 42 },
      visual: { shape: 'golem', color: '#c9d4ea', accent: '#20242f' },
      skill: { name: 'Carapace renforcée', cooldown: 10, target: 'self', kind: 'selfShield', power: 1.4 }
    },
    {
      id: 'stellar_vampire', name: 'Vampire Stellaire', tier: 7, role: 'drain',
      base: { hp: 560, atk: 92, def: 40, spd: 84 },
      visual: { shape: 'vampire', color: '#ff4d9e', accent: '#2a0a1c' },
      skill: { name: 'Morsure stellaire', cooldown: 8, target: 'single', kind: 'drain', power: 1.9 }
    },
    {
      id: 'nexus_architect', name: 'Architecte Nexus', tier: 8, role: 'support',
      base: { hp: 640, atk: 54, def: 46, spd: 92 },
      visual: { shape: 'architect', color: '#ffd166', accent: '#332404' },
      skill: { name: 'Réseau réparateur', cooldown: 7, target: 'allEnemies_self', kind: 'aoeHeal', power: 1.1 }
    },

    // ---------- Avant-postes corrompus (module Nebustion, tiers 14-16) ----------
    // Variantes teintées d'ennemis déjà connus : ce ne sont plus des machines/créatures autonomes,
    // mais des coquilles greffées à Nebustion (voir Nebustion.js / le concept narratif).
    {
      id: 'echo_corrompu', name: 'Écho Corrompu', tier: 14, role: 'skirmisher',
      base: { hp: 980, atk: 130, def: 60, spd: 110 },
      visual: { shape: 'hunter', color: '#8a2be2', accent: '#180022' },
      skill: { name: 'Cri assimilateur', cooldown: 6, target: 'allEnemies_player', kind: 'aoeDamage', power: 0.8 }
    },
    {
      id: 'sentinelle_greffee', name: 'Sentinelle Greffée', tier: 15, role: 'tank',
      base: { hp: 2100, atk: 118, def: 130, spd: 60 },
      visual: { shape: 'golem', color: '#6a1fb0', accent: '#12001f' },
      skill: { name: 'Carapace tentaculaire', cooldown: 9, target: 'self', kind: 'selfShield', power: 1.6 }
    },
    {
      id: 'colosse_assimile', name: 'Colosse Assimilé', tier: 16, role: 'brute',
      base: { hp: 2600, atk: 165, def: 90, spd: 70 },
      visual: { shape: 'juggernaut', color: '#9b30ff', accent: '#150022' },
      skill: { name: 'Broyage violet', cooldown: 7, target: 'single', kind: 'singleDamage', power: 2.2 }
    }
  ];

  // ---------- Boss galactiques (3, avec phases) ----------
  var BOSS_LIST = [
    {
      id: 'vorath', name: 'VORATH, Dévoreur d\'Étoiles', tier: 11, role: 'boss', isBoss: true,
      base: { hp: 5200, atk: 92, def: 50, spd: 76 },
      visual: { shape: 'boss_devourer', color: '#ff4d5e', accent: '#2a0808' },
      skill: { name: 'Griffe abyssale', cooldown: 6, target: 'single', kind: 'singleDamage', power: 1.9 },
      phaseThresholds: [0.55],
      phaseBonus: { atkMult: 1.25, spdMult: 1.15, cooldownMult: 0.75 },
      novaPower: 0.5,
      title: 'Boss galactique — niveau 1'
    },
    {
      id: 'nexus_prime', name: 'NEXUS PRIME, l\'Intelligence Centrale', tier: 12, role: 'boss', isBoss: true,
      base: { hp: 9200, atk: 110, def: 70, spd: 88 },
      visual: { shape: 'boss_ai', color: '#4fd1ff', accent: '#0a1830' },
      skill: { name: 'Frappe orbitale', cooldown: 6, target: 'allEnemies_player', kind: 'aoeDamage', power: 0.85 },
      phaseThresholds: [0.66, 0.33],
      phaseBonus: { atkMult: 1.2, spdMult: 1.12, cooldownMult: 0.8 },
      novaPower: 0.6,
      title: 'Boss galactique — niveau 2'
    },
    {
      id: 'omega_krell', name: 'OMEGA-KRELL, Le Cataclysme', tier: 13, role: 'boss', isBoss: true,
      base: { hp: 14500, atk: 132, def: 84, spd: 96 },
      visual: { shape: 'boss_cataclysm', color: '#b47bff', accent: '#1a0a2a' },
      skill: { name: 'Rupture spatiale', cooldown: 5, target: 'allEnemies_player', kind: 'aoeDamage', power: 1.0 },
      phaseThresholds: [0.66, 0.33],
      phaseBonus: { atkMult: 1.22, spdMult: 1.14, cooldownMult: 0.72 },
      novaPower: 0.75,
      title: 'Boss galactique — niveau 3 (final)'
    },
    {
      id: 'nebustion_primordiale', name: 'NEBUSTION, l\'Éveil Primordial', tier: 20, role: 'boss', isBoss: true, isFinalBoss: true,
      base: { hp: 42000, atk: 165, def: 100, spd: 92 },
      visual: { shape: 'boss_nebustion', color: '#8a2be2', accent: '#050014' },
      skill: { name: 'Étreinte des astres', cooldown: 5, target: 'single', kind: 'singleDamage', power: 2.1 },
      // 3 seuils => 4 phases (Réveil / Propagation / Corruption / Effondrement), une de plus que les
      // 3 boss précédents — voir le concept narratif pour le sens de chaque phase.
      phaseThresholds: [0.75, 0.50, 0.25],
      phaseBonus: { atkMult: 1.28, spdMult: 1.16, cooldownMult: 0.68 },
      novaPower: 0.9,
      title: 'NEBUSTION — l\'entité primordiale'
    }
  ];

  // ---------- Difficultés ----------
  var DIFFICULTY_ORDER = ['facile', 'normal', 'difficile', 'cauchemar'];
  var DIFFICULTIES = {
    facile:    { id: 'facile',    name: 'Facile',    statMult: 0.78, rewardMult: 0.75 },
    normal:    { id: 'normal',    name: 'Normal',     statMult: 1.00, rewardMult: 1.00 },
    difficile: { id: 'difficile', name: 'Difficile',  statMult: 1.35, rewardMult: 1.35 },
    cauchemar: { id: 'cauchemar', name: 'Cauchemar',  statMult: 1.85, rewardMult: 1.75 }
  };

  /** DIFFICULTIES avec les éventuels réglages personnalisés (voir tools/studio.html, onglet Réglages). */
  function effectiveDifficulty(id) {
    var base = DIFFICULTIES[id] || DIFFICULTIES.normal;
    var GC = window.NEBUSTION.CustomContent && NEBUSTION.CustomContent.GameConfig;
    if (!GC) return base;
    var statKey = 'diff_' + base.id + '_stat', rewardKey = 'diff_' + base.id + '_reward';
    return {
      id: base.id, name: base.name,
      statMult: GC.isOverridden(statKey) ? GC.get(statKey) : base.statMult,
      rewardMult: GC.isOverridden(rewardKey) ? GC.get(rewardKey) : base.rewardMult
    };
  }

  // ---------- Stages (progression) ----------
  // "enemies" : ids de ENEMY_LIST/BOSS_LIST formant l'escouade adverse.
  // "scale" : multiplicateur de PV/ATQ/DÉF propre au stage (progression) ; "rewardMult" : récompenses.
  // "recLevel" : niveau d'équipe recommandé [facile, normal, difficile, cauchemar], calibré par
  //   simulation (victoire >= 85 % avec des équipes variées) — voir tests/enemies.test.js.
  var STAGES = [
    { id: 'stage_01', name: 'Débris de patrouille', kind: 'stage', scale: 1.0, rewardMult: 1.0, recLevel: [1,1,1,1], enemies: ['drone_sentinel', 'drone_sentinel'] },
    { id: 'stage_02', name: 'Escadron voltaïque', kind: 'stage', scale: 1.1, rewardMult: 1.1, recLevel: [1,1,1,1], enemies: ['voltaic_hunter', 'drone_sentinel'] },
    { id: 'stage_03', name: 'Colonne blindée', kind: 'stage', scale: 1.25, rewardMult: 1.2, recLevel: [1,1,1,1], enemies: ['corvex_juggernaut', 'drone_sentinel', 'drone_sentinel'] },
    { id: 'stage_04', name: 'Essaim toxique', kind: 'stage', scale: 1.5, rewardMult: 1.3, recLevel: [1,1,1,1], enemies: ['spore_swarm', 'spore_swarm', 'voltaic_hunter'] },
    { id: 'boss_vorath', name: 'VORATH, Dévoreur d\'Étoiles', kind: 'boss', scale: 1.35, rewardMult: 1.0, recLevel: [2,5,10,15], enemies: ['vorath'] },
    { id: 'stage_05', name: 'Ligne de snipers', kind: 'stage', scale: 2.4, rewardMult: 1.4, recLevel: [1,1,5,10], enemies: ['umbra_sniper', 'umbra_sniper'] },
    { id: 'stage_06', name: 'Raid incendiaire', kind: 'stage', scale: 2.8, rewardMult: 1.5, recLevel: [1,1,5,10], enemies: ['cinder_bomber', 'voltaic_hunter'] },
    { id: 'stage_07', name: 'Cellule gelée', kind: 'stage', scale: 3.2, rewardMult: 1.6, recLevel: [2,6,10,16], enemies: ['glacial_specter', 'umbra_sniper', 'drone_sentinel'] },
    { id: 'boss_nexus_prime', name: 'NEXUS PRIME, l\'Intelligence Centrale', kind: 'boss', scale: 1.3, rewardMult: 1.4, recLevel: [7,11,16,20], enemies: ['nexus_prime'] },
    { id: 'stage_08', name: 'Forteresse d\'acier', kind: 'stage', scale: 3.4, rewardMult: 1.7, recLevel: [5,7,11,15], enemies: ['steel_golem', 'nexus_architect'] },
    { id: 'stage_09', name: 'Nid vampirique', kind: 'stage', scale: 3.6, rewardMult: 1.8, recLevel: [8,12,16,22], enemies: ['stellar_vampire', 'stellar_vampire', 'spore_swarm'] },
    { id: 'stage_10', name: 'Ultime bastion', kind: 'stage', scale: 3.8, rewardMult: 1.9, recLevel: [9,13,17,23], enemies: ['nexus_architect', 'corvex_juggernaut', 'umbra_sniper'] },
    { id: 'boss_omega_krell', name: 'OMEGA-KRELL, Le Cataclysme', kind: 'boss', scale: 1.3, rewardMult: 2.0, recLevel: [14,18,23,28], enemies: ['omega_krell'] },

    // ---------- Module Nebustion : Acte 2 (avant-postes farmables) + Acte 3 (boss final) ----------
    // Débloqués par la victoire sur OMEGA-KRELL (comme la suite normale des stages). Les avant-postes
    // sont pensés pour être rejoués (Éclat Souillé + purification de la jauge à chaque victoire,
    // voir NebustionManager.rewardOutpostVictory) ; leur difficulté réelle est légèrement augmentée
    // en jeu par NebustionManager.outpostScaleBonus() tant que la jauge de corruption est haute.
    { id: 'corruption_outpost_1', name: 'Avant-poste corrompu — Alpha', kind: 'stage', scale: 4.2, rewardMult: 2.1, recLevel: [16,20,25,30], enemies: ['echo_corrompu', 'echo_corrompu'], nebustionOutpost: true },
    { id: 'corruption_outpost_2', name: 'Avant-poste corrompu — Beta', kind: 'stage', scale: 4.6, rewardMult: 2.3, recLevel: [17,21,26,31], enemies: ['sentinelle_greffee', 'echo_corrompu'], nebustionOutpost: true },
    { id: 'corruption_outpost_3', name: 'Avant-poste corrompu — Gamma', kind: 'stage', scale: 5.0, rewardMult: 2.5, recLevel: [18,22,27,32], enemies: ['colosse_assimile', 'sentinelle_greffee', 'echo_corrompu'], nebustionOutpost: true },
    { id: 'boss_nebustion', name: 'NEBUSTION, l\'Éveil Primordial', kind: 'boss', scale: 1.0, rewardMult: 3.5, recLevel: [20,25,30,36], enemies: ['nebustion_primordiale'], nebustionBoss: true }
  ];

  // ---------- Récompenses de base par stage (avant multiplicateur de difficulté/étoiles) ----------
  var BASE_REWARD = {
    stage: { crystal: 60, metal: 40, energy: 18, dust: 90, xp: 24, fragments: 2 },
    boss:  { crystal: 260, metal: 180, energy: 90, core: 4, dust: 340, xp: 140, fragments: 8 }
  };

  function stageIndex(id) { for (var i = 0; i < STAGES.length; i++) { if (STAGES[i].id === id) return i; } return -1; }

  // ---------- Ennemis créés sans code (voir tools/studio.html) ----------
  // Même principe que Heroes.fullList() : fusionnés une seule fois avec la liste de base.
  function customEnemyList() {
    var CC = window.NEBUSTION.CustomContent;
    return (CC && CC.enemies) ? CC.enemies() : [];
  }
  /** Stage bonus toujours débloqué regroupant tous les ennemis créés sans code (max 5, pour rester jouable). */
  function customArenaStage() {
    var custom = customEnemyList();
    if (!custom.length) return null;
    return {
      id: 'custom_arena', name: 'Arène personnalisée', kind: 'stage',
      scale: 1.0, rewardMult: 1.0, recLevel: [1, 1, 1, 1],
      enemies: custom.slice(0, 5).map(function (e) { return e.id; }),
      custom: true
    };
  }
  function fullStageList() {
    var extra = customArenaStage();
    return extra ? STAGES.concat([extra]) : STAGES;
  }

  function get(id) {
    for (var i = 0; i < ENEMY_LIST.length; i++) { if (ENEMY_LIST[i].id === id) return ENEMY_LIST[i]; }
    for (var j = 0; j < BOSS_LIST.length; j++) { if (BOSS_LIST[j].id === id) return BOSS_LIST[j]; }
    var custom = customEnemyList();
    for (var k = 0; k < custom.length; k++) { if (custom[k].id === id) return custom[k]; }
    return null;
  }
  /** Niveau d'équipe recommandé pour un stage et une difficulté. */
  function recommendedLevel(stageId, difficultyId) {
    var st = stage(stageId);
    if (!st || !st.recLevel) return 1;
    var i = DIFFICULTY_ORDER.indexOf(difficultyId);
    return st.recLevel[i < 0 ? 1 : i];
  }

  function allEnemies() { return ENEMY_LIST.concat(customEnemyList()); }
  function allBosses() { return BOSS_LIST.slice(); }
  function allStages() { return fullStageList().slice(); }
  function stage(id) { var list = fullStageList(); for (var i = 0; i < list.length; i++) { if (list[i].id === id) return list[i]; } return null; }
  function firstStageId() { return STAGES[0].id; }
  function nextStageId(id) { var i = stageIndex(id); if (i < 0 || i + 1 >= STAGES.length) return null; return STAGES[i + 1].id; }

  /** Statistiques d'un ennemi/boss : difficulté choisie x progression du stage (optionnelle). */
  function statsForEnemy(def, difficultyId, stageScale) {
    var d = effectiveDifficulty(difficultyId);
    var b = def.base;
    var m = d.statMult * (stageScale > 0 ? stageScale : 1); // stageScale : progression propre au stage (STAGES[].scale)
    return {
      hp: Math.round(b.hp * m),
      atk: Math.round(b.atk * m),
      def: Math.round(b.def * m),
      spd: b.spd // la vitesse ne dépend pas de la difficulté (rythme de combat stable)
    };
  }

  /** Récompenses d'un stage, modulées par la difficulté et le nombre d'étoiles (0 à 3). */
  function rewardsFor(stageDef, difficultyId, stars) {
    var d = effectiveDifficulty(difficultyId);
    var base = BASE_REWARD[stageDef.kind] || BASE_REWARD.stage;
    var starMult = stars <= 0 ? 0.25 : (stars === 1 ? 0.6 : (stars === 2 ? 0.85 : 1.0));
    var mult = d.rewardMult * starMult * (stageDef.rewardMult || 1);
    var out = { xp: Math.round(base.xp * mult), fragments: Math.max(0, Math.round(base.fragments * mult)) };
    ['crystal', 'metal', 'energy', 'core', 'dust'].forEach(function (rid) {
      if (base[rid]) out[rid] = Math.round(base[rid] * mult);
    });
    return out;
  }

  return {
    ENEMY_LIST: ENEMY_LIST, BOSS_LIST: BOSS_LIST, STAGES: STAGES,
    DIFFICULTY_ORDER: DIFFICULTY_ORDER, DIFFICULTIES: DIFFICULTIES,
    get: get, allEnemies: allEnemies, allBosses: allBosses, allStages: allStages,
    stage: stage, stageIndex: stageIndex, firstStageId: firstStageId, nextStageId: nextStageId,
    statsForEnemy: statsForEnemy, rewardsFor: rewardsFor, recommendedLevel: recommendedLevel
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.Enemies; }
