/**
 * NEBUSTION - AdminMode
 * Déverrouillage local du « Mode Atelier » (accès aux outils de création : cartes, héros,
 * ennemis, équilibrage...) via un compte spécial Admin / Admin.
 *
 * Volontairement PURE et SANS RÉSEAU : ne passe jamais par Firebase/CloudSave. La vérification
 * se fait entièrement dans le navigateur, et le déverrouillage est mémorisé sur CET appareil
 * uniquement (localStorage), comme un réglage local — pas une vraie sauvegarde de compte.
 *
 * ⚠️ Ce n'est PAS un système de sécurité : le mot de passe est écrit ici en clair et visible par
 * quiconque ouvre les fichiers du jeu. Il ne sert qu'à réserver un accès simple aux outils de
 * création (Atelier), pas à protéger une donnée sensible. Ne pas l'utiliser tel quel pour un jeu
 * en ligne avec de vrais enjeux de triche.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.AdminMode = (function () {
  'use strict';

  var STORAGE_KEY = 'nebustion_admin_atelier_v1';
  var ADMIN_LOGIN = 'admin';
  var ADMIN_PASS = 'admin';

  var listeners = [];

  function isActive() {
    try { return window.localStorage.getItem(STORAGE_KEY) === '1'; }
    catch (e) { return false; }
  }

  function setActive(on) {
    try { window.localStorage.setItem(STORAGE_KEY, on ? '1' : '0'); } catch (e) { /* stockage indisponible : sans effet */ }
    listeners.forEach(function (fn) { try { fn(isActive()); } catch (e2) { /* ignore */ } });
  }

  /** Écoute les changements d'état (activation/désactivation). Retourne une fonction de désinscription. */
  function onChange(fn) {
    listeners.push(fn);
    return function () { var i = listeners.indexOf(fn); if (i >= 0) listeners.splice(i, 1); };
  }

  /** Compare les identifiants saisis dans l'écran Compte au compte atelier local « Admin » / « Admin ».
   *  Insensible à la casse des deux côtés (« Admin », « admin », « ADMIN »... acceptés) : ce n'est
   *  pas un mot de passe protégeant une donnée sensible, juste un raccourci pratique vers l'Atelier. */
  function checkCredentials(login, pass) {
    return String(login || '').trim().toLowerCase() === ADMIN_LOGIN &&
           String(pass || '').trim().toLowerCase() === ADMIN_PASS;
  }

  return {
    ADMIN_LOGIN: ADMIN_LOGIN,
    isActive: isActive,
    setActive: setActive,
    onChange: onChange,
    checkCredentials: checkCredentials
  };
})();
