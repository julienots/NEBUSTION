/**
 * NEBUSTION - Expeditions (données + formules pures)
 * Envoi de héros en mission pendant une durée déterminée (ou instantanée pour le type
 * "Éclair", limitée par un temps de recharge). AUCUNE dépendance à Phaser (testable sous Node).
 *
 * Un héros envoyé en expédition est simplement marqué "occupé" (voir ExpeditionManager) :
 * il n'est ni retiré de l'équipe de combat ni de la sauvegarde, il redevient disponible
 * dès l'expédition réclamée (ou annulée).
 *
 * ÉQUILIBRAGE (cohérent avec l'économie existante) :
 *  - les ressources gagnées sont proportionnelles à la PRODUCTION ACTUELLE du joueur (Economy :
 *    l'économie croît de ×1,22 par niveau d'extracteur, une valeur fixe serait vite dérisoire ou
 *    absurde) : ressource = production/s × durée équivalente × YIELD × difficulté × qualité de l'équipe ;
 *  - la qualité de l'équipe = puissance totale envoyée / puissance recommandée (recommandée par
 *    héros × nombre de héros que la mission accueille) : envoyer moins de héros ou des héros plus
 *    faibles réduit le gain (plancher 0,4 : une équipe faible réussit quand même, aucune perte
 *    définitive), une équipe plus forte l'augmente (plafond 1,6) ;
 *  - conditions : étoiles de Combat, Renaissances (difficultés Abyssal/Mythique), niveau minimum
 *    de chaque héros, nombre de héros ; un rôle « recommandé » donne +12 % ;
 *  - les Éclair sont instantanées mais ont un temps de recharge par mission (pas de farm infini).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Expeditions = (function () {
  'use strict';

  var STATE_VERSION = 2;

  // ---------- Types d'expédition ----------
  // durationSec: 0 = instantanée (résolue immédiatement, pas d'attente)
  // equivSec   : durée de production équivalente prise comme base de récompense
  // recHeroes  : nombre de héros pour lequel la puissance recommandée est calculée (= max accepté)
  // unlockQG   : niveau du Quartier Général requis pour voir/lancer ce type de mission
  var TYPES = {
    eclair: { id: 'eclair', name: 'Éclair', durationSec: 0, equivSec: 600, cooldownSec: 15 * 60, slots: [1, 1], recHeroes: 1, timeBonus: 1.0, fragFactor: 0.5, icon: 'bolt', unlockQG: 1 },
    courte: { id: 'courte', name: 'Courte', durationSec: 20 * 60, equivSec: 20 * 60, cooldownSec: 0, slots: [1, 2], recHeroes: 2, timeBonus: 1.0, fragFactor: 1, icon: 'clock', unlockQG: 1 },
    longue: { id: 'longue', name: 'Longue', durationSec: 3 * 3600, equivSec: 3 * 3600, cooldownSec: 0, slots: [2, 3], recHeroes: 3, timeBonus: 1.15, fragFactor: 2.5, icon: 'moon', unlockQG: 3 },
    epique: { id: 'epique', name: 'Épique', durationSec: 8 * 3600, equivSec: 8 * 3600, cooldownSec: 0, slots: [3, 4], recHeroes: 4, timeBonus: 1.35, fragFactor: 5, icon: 'star', unlockQG: 6 }
  };
  var TYPE_ORDER = ['eclair', 'courte', 'longue', 'epique'];

  // ---------- Difficultés (les 4 premières portent les noms du Combat ; Abyssal/Mythique arrivent avec la Renaissance) ----------
  //  perHero    : puissance recommandée PAR héros (voir Heroes.statsAtLevel : niv.1 ≈ 975, niv.20 ≈ 2 250, niv.40 ≈ 5 400, niv.60 ≈ 13 000)
  //  minLevel   : niveau minimum de CHAQUE héros envoyé
  //  mult       : multiplicateur de récompense
  var DIFFICULTIES = {
    facile:    { id: 'facile',    name: 'Facile',    perHero: 900,   minLevel: 1,  mult: 1.0, unlockStars: 0,  unlockPrestige: 0, fragBase: 1, gemChance: 0,    gems: 0, color: 0x5fd97a },
    normal:    { id: 'normal',    name: 'Normal',    perHero: 1500,  minLevel: 4,  mult: 1.5, unlockStars: 4,  unlockPrestige: 0, fragBase: 2, gemChance: 0.06, gems: 2, color: 0x4fc3ff },
    difficile: { id: 'difficile', name: 'Difficile', perHero: 2400,  minLevel: 10, mult: 2.2, unlockStars: 10, unlockPrestige: 0, fragBase: 3, gemChance: 0.14, gems: 4, color: 0xffb347 },
    cauchemar: { id: 'cauchemar', name: 'Cauchemar', perHero: 4000,  minLevel: 20, mult: 3.2, unlockStars: 20, unlockPrestige: 0, fragBase: 5, gemChance: 0.24, gems: 6, color: 0xff4d6d },
    abyssal:   { id: 'abyssal',   name: 'Abyssal',   perHero: 7000,  minLevel: 32, mult: 4.5, unlockStars: 20, unlockPrestige: 1, fragBase: 7, gemChance: 0.30, gems: 8, xonChance: 0.015, xon: 1, color: 0xb47bff },
    mythique:  { id: 'mythique',  name: 'Mythique',  perHero: 11500, minLevel: 45, mult: 6.0, unlockStars: 20, unlockPrestige: 3, fragBase: 9, gemChance: 0.36, gems: 12, xonChance: 0.04, xon: 1, color: 0xffd166 }
  };
  var DIFF_ORDER = ['facile', 'normal', 'difficile', 'cauchemar', 'abyssal', 'mythique'];

  var ROLE_POOL = ['tank', 'healer', 'damage', 'sniper', 'control', 'support', 'assassin', 'dps'];
  var ROLE_BONUS = 0.12;

  // ---------- Catalogue de missions : type × difficulté (24 combinaisons) ----------
  var MISSION_NAMES = {
    facile: ['Ceinture d\'astéroïdes', 'Épave à la dérive', 'Champ de débris'],
    normal: ['Avant-poste abandonné', 'Nébuleuse trouble', 'Convoi égaré'],
    difficile: ['Ruines antiques', 'Zone de faille', 'Colonie assiégée'],
    cauchemar: ['Cœur du Vide', 'Nid du Léviathan', 'Sanctuaire interdit'],
    abyssal: ['Fosse des Ombres', 'Trône déchu', 'Horizon silencieux'],
    mythique: ['Origine du Multivers', 'Forge des étoiles mortes', 'Mémoire du Premier Vide']
  };

  function _hash(str) { var h = 5381; for (var i = 0; i < str.length; i++) h = (((h << 5) + h) + str.charCodeAt(i)) | 0; return h >>> 0; }
  function _name(typeId, diffId) {
    var pool = MISSION_NAMES[diffId];
    return pool[_hash(typeId + diffId) % pool.length];
  }
  function missionId(typeId, diffId) { return 'm_' + typeId + '_' + diffId; }

  /** Liste complète des missions du catalogue (statique, ne dépend pas de l'heure). */
  function allMissions() {
    var out = [];
    TYPE_ORDER.forEach(function (tId) {
      DIFF_ORDER.forEach(function (dId) {
        var t = TYPES[tId], d = DIFFICULTIES[dId];
        out.push({
          id: missionId(tId, dId), typeId: tId, difficultyId: dId,
          name: _name(tId, dId), durationSec: t.durationSec, cooldownSec: t.cooldownSec,
          minHeroes: t.slots[0], maxHeroes: t.slots[1],
          powerReq: d.perHero * t.recHeroes, minLevel: d.minLevel,
          unlockStars: d.unlockStars, unlockPrestige: d.unlockPrestige, unlockQG: t.unlockQG || 1,
          favoredRole: ROLE_POOL[_hash('role' + tId + dId) % ROLE_POOL.length],
          rewardMult: d.mult * t.timeBonus
        });
      });
    });
    return out;
  }
  var ALL = allMissions();
  var INDEX = {};
  ALL.forEach(function (m) { INDEX[m.id] = m; });
  function mission(id) { return Object.prototype.hasOwnProperty.call(INDEX, id) ? INDEX[id] : null; }

  /** Déverrouillée quand le total d'étoiles de Combat, le nombre de Renaissances ET le niveau du
   * Quartier Général atteignent ses seuils. qgLevel est optionnel (défaut 1 : au moins le type « Éclair »
   * reste disponible dès le départ) pour ne pas casser les appels existants. */
  function isUnlocked(m, totalStars, prestigeCount, qgLevel) {
    return (totalStars || 0) >= m.unlockStars && (prestigeCount || 0) >= (m.unlockPrestige || 0) &&
      (qgLevel === undefined ? 1 : (qgLevel || 0)) >= (m.unlockQG || 1);
  }

  // ---------- Récompenses ----------
  var YIELD = 0.18;          // part de la production (durée équivalente × difficulté) versée en récompense
  var SCALE_MIN = 0.4, SCALE_MAX = 1.6;
  var XP_PER_MIN = 0.25;

  function _rng(seed) {
    var a = seed >>> 0;
    return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }

  /** Production/s de départ (niveaux initiaux) : plancher de calcul quand aucune production n'est fournie. */
  function baseRates() {
    var E = NEBUSTION.Economy, out = {};
    if (E) E.ORDER.forEach(function (id) { out[id] = E.totalRate(id, E.BUILDINGS['ext_' + id].start, E.CFG.START_DRONES, E.BUILDINGS.hangar.start); });
    return out;
  }

  /** Qualité de l'équipe : puissance envoyée / puissance recommandée, bornée. */
  function qualityScale(m, teamPower) {
    var ratio = Math.max(0, (teamPower || 0)) / Math.max(1, m.powerReq);
    return { ratio: ratio, scale: Math.max(SCALE_MIN, Math.min(SCALE_MAX, ratio)) };
  }

  /**
   * Calcule les récompenses d'une expédition.
   * @param m mission (voir mission())
   * @param teamPower somme de la Puissance des héros envoyés
   * @param seed entier (variance déterministe, ex. horodatage de lancement)
   * @param rates production/s actuelle par ressource (défaut : production de départ)
   * @param opts {heroCount, roleMatch}
   */
  /** Lit un multiplicateur d'équilibrage depuis l'Atelier créateur (tools/studio.html) s'il est chargé ; sinon 1 (aucun changement). */
  function cfgMult(key) {
    try {
      if (NEBUSTION.CustomContent && NEBUSTION.CustomContent.GameConfig) {
        var v = NEBUSTION.CustomContent.GameConfig.get(key);
        if (v > 0) return v;
      }
    } catch (e) {}
    return 1;
  }
  function rewardsFor(m, teamPower, seed, rates, opts) {
    opts = opts || {};
    var t = TYPES[m.typeId], d = DIFFICULTIES[m.difficultyId];
    var q = qualityScale(m, teamPower), scale = q.scale;
    var floor = baseRates(), r = rates || floor;
    var rnd = _rng((seed || 1) >>> 0);
    var roleMult = opts.roleMatch ? (1 + ROLE_BONUS) : 1;
    var globalMult = cfgMult('expedition_reward_mult');
    var res = {};
    ['crystal', 'metal', 'energy', 'core', 'dust'].forEach(function (id) {
      var rate = Math.max(Number(r[id]) || 0, floor[id] || 0);
      var variance = 0.9 + rnd() * 0.2;
      res[id] = Math.max(0, Math.round(rate * t.equivSec * YIELD * m.rewardMult * scale * roleMult * variance * globalMult));
    });
    var gemChance = d.gemChance * Math.min(1.3, scale);
    var gems = rnd() < gemChance ? d.gems : 0;
    var xon = d.xon && rnd() < (d.xonChance || 0) ? d.xon : 0;
    var fragments = Math.max(1, Math.round(d.fragBase * t.fragFactor * scale * roleMult * globalMult));
    var xp = Math.max(1, Math.round((t.equivSec / 60) * XP_PER_MIN * d.mult * scale * globalMult));
    return { ratio: q.ratio, scale: scale, roleMatch: !!opts.roleMatch, success: q.ratio >= 0.6, res: res, gems: gems, xon: xon, fragments: fragments, xp: xp };
  }

  return {
    TYPES: TYPES, TYPE_ORDER: TYPE_ORDER, DIFFICULTIES: DIFFICULTIES, DIFF_ORDER: DIFF_ORDER,
    STATE_VERSION: STATE_VERSION, ROLE_BONUS: ROLE_BONUS, YIELD: YIELD, SCALE_MIN: SCALE_MIN, SCALE_MAX: SCALE_MAX,
    allMissions: allMissions, mission: mission, missionId: missionId, isUnlocked: isUnlocked,
    qualityScale: qualityScale, baseRates: baseRates, rewardsFor: rewardsFor
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.Expeditions; }
