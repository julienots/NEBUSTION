/**
 * NEBUSTION - Events (données + formules pures)
 * Événements temporaires simulés sur l'heure LOCALE du joueur (aucun serveur) : un cycle de
 * 14 jours dont les 5 premiers jours sont actifs (thème + boss + missions + boutique
 * événementielle), les 9 jours suivants sont calmes avant le prochain événement. Les thèmes
 * tournent (3 thèmes), comme les saisons du Pass (voir js/data/Pass.js, même méthode de calcul).
 *
 * AUCUNE dépendance à Phaser (testable sous Node, comme Pass.js).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Events = (function () {
  'use strict';

  var DAY_MS = 86400000;
  var CYCLE_DAYS = 14;
  var ACTIVE_DAYS = 5;
  var ANCHOR = Date.UTC(2026, 8, 14);   // même ancrage que le Pass : lundi 14 septembre 2026
  var STATE_VERSION = 1;

  function _local(now) { now = Number(now) || Date.now(); return now - new Date(now).getTimezoneOffset() * 60000; }
  function dayIndex(now) { return Math.floor((_local(now) - ANCHOR) / DAY_MS); }
  function cycleIndex(now) { return Math.max(0, Math.floor(dayIndex(now) / CYCLE_DAYS)); }
  function dayInCycle(now) { var d = dayIndex(now); return ((d % CYCLE_DAYS) + CYCLE_DAYS) % CYCLE_DAYS; }
  function msUntilNextDay(now) { var l = _local(now); return (dayIndex(now) + 1) * DAY_MS + ANCHOR - l; }

  // ---------- Thèmes (tournent chaque occurrence) ----------
  var THEMES = [
    { key: 'invasion', name: 'Invasion Voidique', tagline: 'Une flotte fantôme émerge du Vide.', color: 0x8a4dff, hex: '#8a4dff',
      boss: { name: 'Nexus Architecte Éveillé', baseHp: 42000, hpPerCycle: 6500 },
      currency: { id: 'esquille_vide', name: 'Éclats du Vide', hex: '#b47bff' } },
    { key: 'ruee', name: 'Ruée de Cristaux', tagline: 'Un gisement instable affleure dans le secteur.', color: 0x4fe3ff, hex: '#4fe3ff',
      boss: { name: 'Golem de Cristal Primordial', baseHp: 36000, hpPerCycle: 5200 },
      currency: { id: 'esquille_cristal', name: 'Éclats de Cristal', hex: '#4fe3ff' } },
    { key: 'tempete', name: 'Tempête d\'Énergie', tagline: 'Les orages quantiques frappent Nexus-01.', color: 0xffd166, hex: '#ffd166',
      boss: { name: 'Entité Foudre Stellaire', baseHp: 50000, hpPerCycle: 7800 },
      currency: { id: 'esquille_energie', name: 'Éclats d\'Énergie', hex: '#ffd166' } }
  ];

  function theme(cIdx) { return THEMES[Math.max(0, cIdx | 0) % THEMES.length]; }

  /** Décrit l'événement courant : actif ou non, thème, temps restant avant le prochain changement d'état. */
  function currentEvent(now, prestigeTier) {
    now = Number(now) || Date.now();
    var cIdx = cycleIndex(now), dIc = dayInCycle(now), active = dIc < ACTIVE_DAYS;
    var l = _local(now), cycleStartLocal = ANCHOR + cIdx * CYCLE_DAYS * DAY_MS;
    var activeEndLocal = cycleStartLocal + ACTIVE_DAYS * DAY_MS;
    var cycleEndLocal = cycleStartLocal + CYCLE_DAYS * DAY_MS;
    var msLeft = active ? (activeEndLocal - l) : (cycleEndLocal - l);
    var th = theme(cIdx);
    var bossHp = Math.round(th.boss.baseHp + th.boss.hpPerCycle * cIdx * (1 + 0.15 * Math.max(0, prestigeTier || 0)));
    return {
      cycleIndex: cIdx, dayInCycle: dIc, active: active, msLeft: Math.max(0, msLeft),
      theme: th, bossMaxHp: bossHp, activeDays: ACTIVE_DAYS, cycleDays: CYCLE_DAYS
    };
  }

  // ---------- Attaques contre le boss ----------
  var ATTEMPTS_PER_DAY = 5;
  var ATTEMPT_BONUS_PER_TIER = 1;
  var ATTEMPT_MAX = 10;
  var DAMAGE_PER_POWER = 1.35;      // dégâts infligés au boss = puissance d'équipe × ce facteur
  var CRIT_CHANCE = 0.16;
  var CRIT_MULT = 1.8;

  function maxAttempts(prestigeTier) { return Math.min(ATTEMPT_MAX, ATTEMPTS_PER_DAY + Math.floor(ATTEMPT_BONUS_PER_TIER * (prestigeTier || 0))); }

  function resolveAttack(teamPower, seedInt) {
    var rnd = (function (seed) {
      var a = (seed >>> 0) || 1;
      return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
    })(seedInt);
    var crit = rnd() < CRIT_CHANCE;
    var variance = 0.9 + rnd() * 0.22;
    var dmg = Math.round(Math.max(1, teamPower) * DAMAGE_PER_POWER * variance * (crit ? CRIT_MULT : 1));
    return { damage: dmg, crit: crit };
  }

  // ---------- Missions événementielles (suivies pendant les jours actifs uniquement) ----------
  var MISSION_POOL = [
    { id: 'e_attack', label: 'Attaquer le boss événementiel 3 fois', metric: 'attack', target: 3, currency: 30 },
    { id: 'e_dmg', label: 'Infliger 5 000 dégâts cumulés au boss', metric: 'damage', target: 5000, currency: 40 },
    { id: 'e_expedition', label: 'Terminer 2 expéditions pendant l\'événement', metric: 'expedition', target: 2, currency: 25 },
    { id: 'e_login', label: 'Se connecter pendant l\'événement', metric: 'login', target: 1, currency: 15 },
    { id: 'e_win', label: 'Remporter 5 combats pendant l\'événement', metric: 'win', target: 5, currency: 25 }
  ];
  function missionDef(id) { for (var i = 0; i < MISSION_POOL.length; i++) if (MISSION_POOL[i].id === id) return MISSION_POOL[i]; return null; }

  // ---------- Boutique événementielle (achetée avec la monnaie du thème en cours) ----------
  var SHOP_ITEMS = [
    { id: 'ev_res', label: 'Cargaison événementielle', desc: 'Cristaux, métal et énergie', kind: 'res', res: { crystal: 1200, metal: 1000, energy: 700 }, cost: 40, limit: 5 },
    { id: 'ev_frag', label: 'Fragments du chef d\'équipe', desc: '+12 fragments pour le premier héros de votre équipe', kind: 'frag_choice', amount: 12, cost: 70, limit: 4 },
    { id: 'ev_gems', label: 'Prismes', desc: '+25 Prismes', kind: 'gems', amount: 25, cost: 90, limit: 3 },
    { id: 'ev_core', label: 'Noyaux antiques', desc: '+8 noyaux antiques', kind: 'res', res: { core: 8 }, cost: 120, limit: 2 }
  ];
  function shopItem(id) { for (var i = 0; i < SHOP_ITEMS.length; i++) if (SHOP_ITEMS[i].id === id) return SHOP_ITEMS[i]; return null; }

  /** Lit un multiplicateur d'équilibrage depuis l'Atelier créateur (tools/studio.html) s'il est chargé ; sinon 1 (aucun changement). */
  function cfgMult(key) {
    try {
      if (NEBUSTION.CustomContent && NEBUSTION.CustomContent.GameConfig) {
        var v = NEBUSTION.CustomContent.GameConfig.get(key);
        if (v > 0) return v;
      }
    } catch (e) {}
    return 1;
  }
  // ---------- Récompense de mise à mort du boss ----------
  function bossDefeatReward(th, cIdx) {
    var m = cfgMult('event_boss_reward_mult');
    return {
      res: { dust: Math.round((4000 + cIdx * 400) * m), crystal: Math.round((2500 + cIdx * 250) * m), metal: Math.round((2000 + cIdx * 200) * m) },
      gems: Math.round(20 * m), fragments: Math.round(15 * m), currency: Math.round(60 * m)
    };
  }

  /** Convertit la monnaie événementielle non dépensée en Prismes quand l'événement se termine (aucune perte sèche). */
  var LEFTOVER_TO_GEM = 0.2;
  function convertLeftover(amount) { return Math.floor(Math.max(0, amount) * LEFTOVER_TO_GEM); }

  return {
    DAY_MS: DAY_MS, CYCLE_DAYS: CYCLE_DAYS, ACTIVE_DAYS: ACTIVE_DAYS, STATE_VERSION: STATE_VERSION,
    THEMES: THEMES, theme: theme,
    dayIndex: dayIndex, cycleIndex: cycleIndex, dayInCycle: dayInCycle, msUntilNextDay: msUntilNextDay,
    currentEvent: currentEvent, maxAttempts: maxAttempts, resolveAttack: resolveAttack,
    MISSION_POOL: MISSION_POOL, missionDef: missionDef,
    SHOP_ITEMS: SHOP_ITEMS, shopItem: shopItem,
    bossDefeatReward: bossDefeatReward, convertLeftover: convertLeftover
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.Events; }
