/**
 * NEBUSTION - Achievements (données pures)
 * Trois choses distinctes réunies ici :
 *  1) Succès (paliers bronze/argent/or) : progression permanente, jamais réinitialisée
 *     (même par une Renaissance galactique), récompense une seule fois par palier.
 *  2) Calendrier de récompenses quotidiennes (7 jours, en boucle) : une connexion par jour
 *     LOCAL fait avancer la série ; un jour manqué la remet à 1 (pas de pénalité au-delà).
 *  3) Objectifs à long terme : mêmes paliers que les succès, présentés séparément dans
 *     l'écran (catégorie "long terme") pour donner un horizon de jeu au-delà de quelques heures.
 *
 * AUCUNE dépendance à Phaser. La VALEUR de chaque métrique est lue par AchievementsManager
 * (qui a accès aux autres systèmes) ; ce fichier ne connaît que les seuils et récompenses.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Achievements = (function () {
  'use strict';

  var STATE_VERSION = 1;
  var TIERS = ['bronze', 'argent', 'or'];
  var TIER_COLOR = { bronze: 0xcd8a4d, argent: 0xc9d4ea, or: 0xffd166 };

  // ---------- Succès (progression court/moyen terme) ----------
  var ACHIEVEMENTS = [
    { id: 'ach_command', category: 'succes', metric: 'commandLevel', name: 'Centre de commandement', unit: 'niveau', tiers: [5, 10, 20], rewards: [{ dust: 1000 }, { crystal: 1500 }, { gem: 20 }] },
    { id: 'ach_battles', category: 'succes', metric: 'battlesWon', name: 'Vétéran des étoiles', unit: 'victoires', tiers: [10, 50, 200], rewards: [{ dust: 800 }, { gem: 15 }, { gem: 40 }] },
    { id: 'ach_stars', category: 'succes', metric: 'totalStars', name: 'Collectionneur d\'étoiles', unit: 'étoiles', tiers: [10, 25, 39], rewards: [{ crystal: 1200 }, { gem: 20 }, { gem: 50 }] },
    { id: 'ach_planets', category: 'succes', metric: 'conqueredPlanets', name: 'Conquérant galactique', unit: 'planètes', tiers: [1, 5, 12], rewards: [{ metal: 1200 }, { gem: 25 }, { gem: 60 }] },
    { id: 'ach_expeditions', category: 'succes', metric: 'expeditionsCompleted', name: 'Capitaine explorateur', unit: 'expéditions', tiers: [5, 25, 100], rewards: [{ dust: 1500 }, { gem: 20 }, { gem: 50 }] }
  ];

  // ---------- Objectifs à long terme (horizon de plusieurs jours/semaines) ----------
  var HERO_COUNT = (NEBUSTION.Heroes && NEBUSTION.Heroes.all) ? NEBUSTION.Heroes.all().length : 24;
  var LONG_TERM = [
    { id: 'lt_heroes', category: 'longterme', metric: 'heroesUnlocked', name: 'Panthéon complet', unit: 'héros recrutés', tiers: [5, Math.max(6, Math.round(HERO_COUNT / 2)), HERO_COUNT], rewards: [{ gem: 30 }, { gem: 80 }, { gem: 200 }] },
    { id: 'lt_boss', category: 'longterme', metric: 'eventBossKills', name: 'Fléau des événements', unit: 'boss vaincus', tiers: [1, 10, 30], rewards: [{ gem: 25 }, { gem: 70 }, { gem: 150 }] },
    { id: 'lt_prestige', category: 'longterme', metric: 'prestigeCount', name: 'Renaissance éternelle', unit: 'Renaissances', tiers: [1, 3, 8], rewards: [{ gem: 50 }, { gem: 120 }, { gem: 300, xon: 1 }] },
    { id: 'lt_relics', category: 'longterme', metric: 'relicsTotal', name: 'Archiviste cosmique', unit: 'Reliques cumulées', tiers: [20, 100, 400], rewards: [{ gem: 30 }, { gem: 90 }, { gem: 220, xon: 1 }] }
  ];

  var ALL = ACHIEVEMENTS.concat(LONG_TERM);
  var INDEX = {}; ALL.forEach(function (a) { INDEX[a.id] = a; });
  function get(id) { return Object.prototype.hasOwnProperty.call(INDEX, id) ? INDEX[id] : null; }
  function all() { return ALL.slice(); }

  /** Palier atteint (0..tiers.length) pour une valeur courante donnée. */
  function tierReached(def, value) {
    var n = 0;
    for (var i = 0; i < def.tiers.length; i++) { if (value >= def.tiers[i]) n = i + 1; }
    return n;
  }

  // ---------- Calendrier quotidien (7 jours, en boucle) ----------
  var DAILY_REWARDS = [
    { res: { dust: 500 } },
    { res: { crystal: 400 } },
    { gem: 10 },
    { res: { energy: 300, metal: 300 } },
    { gem: 15 },
    { res: { core: 2 } },
    { gem: 30, res: { dust: 1000, crystal: 1000 } }
  ];
  function dailyReward(streakDay) {
    var i = Math.max(1, Math.floor(streakDay)) - 1;
    return DAILY_REWARDS[i % DAILY_REWARDS.length];
  }

  return {
    STATE_VERSION: STATE_VERSION, TIERS: TIERS, TIER_COLOR: TIER_COLOR,
    ACHIEVEMENTS: ACHIEVEMENTS, LONG_TERM: LONG_TERM, all: all, get: get, tierReached: tierReached,
    DAILY_REWARDS: DAILY_REWARDS, dailyReward: dailyReward
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.Achievements; }
