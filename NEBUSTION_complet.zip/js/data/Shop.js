/**
 * NEBUSTION - Shop (données)
 * Module pur (aucune dépendance à Phaser, testable sous Node comme Economy.js/Equipment.js).
 * Définit la monnaie premium (Prismes), le pool de la boutique quotidienne (rotation
 * déterministe par jour), les paquets de fragments de héros, les offres d'équipement et
 * l'offre événementielle. La boutique de skins n'a pas de données propres : elle affiche
 * directement NEBUSTION.Skins via SkinManager.buy (déjà existant).
 *
 * État de sauvegarde (voir ShopManager) : { gems, dayIndex, purchasedToday: {offerId:true},
 * lastGiftDay, eventBought }.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Shop = (function () {
  'use strict';

  var GEM = { id: 'gem', name: 'Prismes', short: 'Prismes', hex: '#e6c6ff', color: 0xe6c6ff };
  // Monnaie ultra-rare : réservée aux contenus cosmiques/exclusifs. Elle n'est jamais donnée au démarrage.
  var XON = { id: 'xon', name: 'Jetons Xon', short: 'Xon', hex: '#62f4ff', color: 0x62f4ff, max: 999999 };

  var DAILY_GIFT_GEMS = 12;
  var DAILY_SLOTS = 4;
  var DAY_MS = 86400000;

  // ---------- Boutique quotidienne : pool (8 entrées, 4 tirées chaque jour) ----------
  var DAILY_POOL = [
    { id: 'd_dust', kind: 'resource', label: 'Poussière cosmique', res: { dust: 1500 }, cost: { crystal: 350 } },
    { id: 'd_crystal', kind: 'resource', label: 'Cristaux stellaires', res: { crystal: 600 }, cost: { dust: 1800 } },
    { id: 'd_energy', kind: 'resource', label: 'Énergie quantique', res: { energy: 350 }, cost: { dust: 1000, crystal: 200 } },
    { id: 'd_core', kind: 'resource', label: 'Noyaux antiques', res: { core: 6 }, cost: { gem: 35 } },
    { id: 'd_bundle', kind: 'bundle', label: 'Lot express', res: { dust: 2500, crystal: 900, energy: 500 }, cost: { gem: 55 } },
    { id: 'd_equip_c', kind: 'equipment', label: 'Objet aléatoire (Commun)', rarity: 'commun', cost: { metal: 900, core: 280 } },
    { id: 'd_equip_r', kind: 'equipment', label: 'Objet aléatoire (Rare)', rarity: 'rare', cost: { gem: 60 } },
    { id: 'd_gems', kind: 'gems', label: 'Prismes bonus', amount: 25, cost: { dust: 5000, crystal: 2000, energy: 1000 } }
  ];
  var DAILY_INDEX = {};
  DAILY_POOL.forEach(function (o) { DAILY_INDEX[o.id] = o; });

  // ---------- Boutique de héros : paquets de fragments (fixes, appliqués au héros choisi) ----------
  var HERO_PACKS = [
    { id: 'hp_small', name: 'Paquet de fragments — Petit', amount: 10, cost: { dust: 2500, crystal: 900 } },
    { id: 'hp_medium', name: 'Paquet de fragments — Moyen', amount: 30, cost: { gem: 60 } },
    { id: 'hp_large', name: 'Paquet de fragments — Grand', amount: 80, cost: { gem: 150 } }
  ];

  // ---------- Boutique d'équipements : objets neufs (niveau 1), toutes raretés au-dessus de Commun ----------
  var EQUIPMENT_RARITIES = ['rare', 'epique', 'legendaire'];
  var EQUIPMENT_PRICE = {
    rare: { gem: 45 },
    epique: { gem: 90 },
    legendaire: { gem: 170 }
  };

  // ---------- Boutique événementielle : offre unique, achetable une seule fois ----------
  var EVENT_OFFER = {
    id: 'evt_launch',
    name: 'Négoce Stellaire — Offre de lancement',
    desc: 'Un lot unique pour renforcer votre empire : ressources, Prismes et matériaux rares.',
    contents: { dust: 6000, crystal: 2500, energy: 1200, core: 15, gem: 120 },
    cost: { dust: 3000, crystal: 1200, energy: 600 }
  };

  // ---------- Rotation quotidienne (déterministe : même tirage pour tout le monde, ce jour-là) ----------
  function dayIndex(now) { return Math.floor((Number(now) || Date.now()) / DAY_MS); }

  /** Générateur pseudo-aléatoire déterministe (LCG) à partir d'une graine entière. */
  function makeRng(seed) {
    var s = seed >>> 0;
    return function () { s = (Math.imul(s, 1103515245) + 12345) >>> 0; return (s >>> 8) / 16777216; };
  }

  function dailyOffers(now) {
    var idx = dayIndex(now);
    var rng = makeRng(idx * 2654435761);
    var pool = DAILY_POOL.slice();
    for (var i = pool.length - 1; i > 0; i--) {
      var j = Math.floor(rng() * (i + 1));
      var t = pool[i]; pool[i] = pool[j]; pool[j] = t;
    }
    var picked = pool.slice(0, DAILY_SLOTS);
    // Emplacement déterministe pour les offres d'équipement (constant pour la journée).
    var slots = NEBUSTION.Equipment ? NEBUSTION.Equipment.SLOT_ORDER : ['weapon', 'armor', 'module', 'reactor', 'artifact'];
    return picked.map(function (o) {
      var copy = Object.assign({}, o);
      if (o.kind === 'equipment') copy.slot = slots[Math.floor(rng() * slots.length)];
      return copy;
    });
  }

  function msUntilNextDay(now) {
    now = Number(now) || Date.now();
    return DAY_MS - (now % DAY_MS);
  }

  // ---------- État de sauvegarde ----------
  function defaultState(now) {
    return { gems: 30, xon: 0, dayIndex: dayIndex(now), purchasedToday: {}, lastGiftDay: -1, eventBought: false, customCards: {} };
  }

  function num(x, min, max, def) { x = Number(x); return isFinite(x) ? Math.min(max, Math.max(min, x)) : def; }
  function int(x, min, max, def) { return Math.floor(num(x, min, max, def)); }

  function normalizeState(raw, now) {
    var s = defaultState(now);
    if (!raw || typeof raw !== 'object') return s;
    s.gems = int(raw.gems, 0, 1e9, 30);
    s.xon = int(raw.xon, 0, XON.max, 0);
    s.dayIndex = int(raw.dayIndex, 0, 1e12, dayIndex(now));
    s.lastGiftDay = int(raw.lastGiftDay, -1, 1e12, -1);
    s.eventBought = raw.eventBought === true;
    var rp = raw.purchasedToday || {};
    var rc = raw.customCards || {};
    if (rc && typeof rc === 'object') {
      Object.keys(rc).forEach(function (id) { if (rc[id] === true) s.customCards[String(id)] = true; });
    }
    // Un jour a changé depuis la sauvegarde : la rotation d'aujourd'hui repart neuve.
    if (s.dayIndex === dayIndex(now)) {
      Object.keys(rp).forEach(function (id) { if (DAILY_INDEX[id]) s.purchasedToday[id] = true; });
    } else {
      s.dayIndex = dayIndex(now);
    }
    return s;
  }

  return {
    GEM: GEM, XON: XON, DAILY_GIFT_GEMS: DAILY_GIFT_GEMS, DAILY_SLOTS: DAILY_SLOTS,
    DAILY_POOL: DAILY_POOL, DAILY_INDEX: DAILY_INDEX,
    HERO_PACKS: HERO_PACKS,
    EQUIPMENT_RARITIES: EQUIPMENT_RARITIES, EQUIPMENT_PRICE: EQUIPMENT_PRICE,
    EVENT_OFFER: EVENT_OFFER,
    dayIndex: dayIndex, dailyOffers: dailyOffers, msUntilNextDay: msUntilNextDay,
    defaultState: defaultState, normalizeState: normalizeState
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.Shop; }
