/**
 * NEBUSTION - Prestige (données + formules pures)
 * "Renaissance galactique" : réinitialise l'économie et la progression de combat/galaxie
 * du cycle en cours en échange de Reliques cosmiques (monnaie permanente, JAMAIS
 * réinitialisée) dépensées dans un arbre de bonus permanents.
 *
 * Conservé à la Renaissance (voir PrestigeManager.perform) : héros (fragments/niveaux),
 * équipement, vaisseaux, skins, Prismes, Pass de saison, succès, progression d'expédition/
 * événement. Réinitialisé : bâtiments, ressources et drones, étoiles/victoires de combat,
 * secteurs de galaxie et empires.
 *
 * AUCUNE dépendance à Phaser (testable sous Node, comme Economy.js).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Prestige = (function () {
  'use strict';

  var STATE_VERSION = 1;

  // ---------- Condition de déclenchement (monte à chaque Renaissance : nouveaux objectifs) ----------
  var REQUIREMENTS = { commandLevel: 12, totalStars: 15 };
  var REQ_STEP = { commandLevel: 3, totalStars: 3 };
  var REQ_CAP = { commandLevel: 30, totalStars: 30 };   // 13 étapes de Combat = 39 étoiles maximum
  function requirementsFor(count) {
    count = Math.max(0, Math.floor(count || 0));
    return {
      commandLevel: Math.min(REQ_CAP.commandLevel, REQUIREMENTS.commandLevel + REQ_STEP.commandLevel * count),
      totalStars: Math.min(REQ_CAP.totalStars, REQUIREMENTS.totalStars + REQ_STEP.totalStars * count)
    };
  }

  // ---------- Reliques : valeur d'un cycle avant réinitialisation ----------
  var LIFE_WEIGHT = { crystal: 1.0, metal: 1.1, energy: 1.6, dust: 0.8, core: 45 };
  var STAR_VALUE = 140;
  var XP_VALUE = 0.4;
  var RELIC_DIVISOR = 1800;

  function pointsFor(lifeTotals, totalStars, playerXP) {
    var lifeScore = 0;
    Object.keys(LIFE_WEIGHT).forEach(function (id) { lifeScore += (lifeTotals[id] || 0) * LIFE_WEIGHT[id]; });
    var starScore = (totalStars || 0) * STAR_VALUE;
    var xpScore = (playerXP || 0) * XP_VALUE;
    return lifeScore + starScore + xpScore;
  }
  /** Lit un multiplicateur d'équilibrage depuis l'Atelier créateur (tools/studio.html) s'il est chargé ; sinon 1 (aucun changement). */
  function cfgMult(key) {
    try {
      if (NEBUSTION.CustomContent && NEBUSTION.CustomContent.GameConfig) {
        var v = NEBUSTION.CustomContent.GameConfig.get(key);
        if (v > 0) return v;
      }
    } catch (e) {}
    return 1;
  }
  function relicsFor(points) { return Math.max(1, Math.floor(Math.cbrt(Math.max(0, points) / RELIC_DIVISOR) * cfgMult('prestige_relic_mult'))); }

  // ---------- Arbre de bonus permanents (payé en Reliques, jamais remis à zéro) ----------
  var TREE = [
    { id: 'production', name: 'Flux cosmique', desc: '+2 % de production passive et hors ligne par palier', maxLevel: 25, costBase: 3, costGrowth: 1.18, perLevel: 0.02 },
    { id: 'combatPower', name: 'Bénédiction stellaire', desc: '+1,5 % de PV, attaque et défense des héros par palier', maxLevel: 20, costBase: 4, costGrowth: 1.2, perLevel: 0.015 },
    { id: 'expeditionSlot', name: 'Flotte étendue', desc: '+1 emplacement d\'expédition simultané par palier', maxLevel: 3, costBase: 25, costGrowth: 1.6, perLevel: 1 },
    { id: 'offlineEff', name: 'Réacteurs dormants', desc: '+5 % d\'efficacité de production hors ligne par palier (max. 100 %)', maxLevel: 8, costBase: 6, costGrowth: 1.22, perLevel: 0.05 },
    { id: 'headStart', name: 'Fondations gravées', desc: '+1 niveau de départ pour chaque bâtiment après une Renaissance, par palier', maxLevel: 5, costBase: 10, costGrowth: 1.35, perLevel: 1 }
  ];
  var TREE_INDEX = {};
  TREE.forEach(function (t) { TREE_INDEX[t.id] = t; });
  function node(id) { return Object.prototype.hasOwnProperty.call(TREE_INDEX, id) ? TREE_INDEX[id] : null; }

  function nodeCost(id, currentLevel) {
    var t = node(id);
    if (!t || currentLevel >= t.maxLevel) return null;
    return Math.round(t.costBase * Math.pow(t.costGrowth, currentLevel) * cfgMult('prestige_tree_cost_mult'));
  }
  function nodeValue(id, level) {
    var t = node(id);
    if (!t) return 0;
    return Math.min(level, t.maxLevel) * t.perLevel;
  }

  // ---------- Paliers de Renaissance : ce que chaque Renaissance débloque ou change (tous réellement appliqués) ----------
  //  - Expéditions Abyssal / Mythique : Expeditions.DIFFICULTIES[].unlockPrestige
  //  - +1 tentative de boss d'événement par jour et par Renaissance (Events.maxAttempts, plafonné à 10)
  //  - boss d'événement +15 % de PV par Renaissance (Events.currentEvent)
  var TIER_PERKS = [
    { count: 1, name: 'Aube', desc: 'Expéditions Abyssal débloquées · +1 tentative de boss par jour' },
    { count: 2, name: 'Éveil', desc: '+1 tentative de boss par jour · les boss d\'événement gagnent en puissance' },
    { count: 3, name: 'Ascension', desc: 'Expéditions Mythique débloquées · +1 tentative de boss par jour' },
    { count: 4, name: 'Transcendance', desc: '+1 tentative de boss par jour · objectifs de Renaissance plus élevés' },
    { count: 5, name: 'Singularité', desc: '+1 tentative de boss par jour (10 maximum)' }
  ];
  function tierName(count) {
    count = Math.max(0, Math.floor(count || 0));
    if (count <= 0) return 'Origine';
    return TIER_PERKS[Math.min(count, TIER_PERKS.length) - 1].name;
  }

  return {
    STATE_VERSION: STATE_VERSION, REQUIREMENTS: REQUIREMENTS, requirementsFor: requirementsFor, TIER_PERKS: TIER_PERKS,
    TREE: TREE, node: node, nodeCost: nodeCost, nodeValue: nodeValue,
    pointsFor: pointsFor, relicsFor: relicsFor, tierName: tierName
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.Prestige; }
