/**
 * NEBUSTION - Symbiote
 * Données pures du système Symtor : créature procédurale, nourriture, évolution,
 * combats simulés et défense de la base. Aucun serveur requis.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Symbiote = (function () {
  'use strict';

  var MAX_LEVEL = 50;
  var FEED = {
    crystal: { xp: 18, cost: { crystal: 18 } },
    metal:   { xp: 12, cost: { metal: 24 } },
    energy:  { xp: 24, cost: { energy: 18 } },
    dust:    { xp: 9,  cost: { dust: 35 } }
  };
  // Élargi pour multiplier les combinaisons visuelles possibles.
  var GENES = ['horns', 'eyes', 'tentacles', 'plates', 'tail', 'mouth', 'spikes', 'wings', 'fins', 'crystals', 'fur', 'glowSpots', 'stripes'];
  var TRAIT_LABELS = {
    horns: 'Cornes', eyes: 'Œil supplémentaire', tentacles: 'Tentacule', plates: 'Plaques osseuses',
    tail: 'Queue', mouth: 'Bouche vorace', spikes: 'Pics', wings: 'Ailes membraneuses',
    fins: 'Nageoires', crystals: 'Excroissances cristallines', fur: 'Fourrure hirsute',
    glowSpots: 'Points luminescents', stripes: 'Rayures organiques'
  };
  var BODY_SHAPES = ['round', 'elongated', 'angular', 'segmented'];

  // PRNG déterministe (mulberry32) : même graine → même séquence, à chaque partie/rechargement.
  function mulberry32(a) {
    a = a >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function rng(seed) { return mulberry32((Number(seed) || 0) | 0); }

  // ---------- Module 20 : le Symtor devient utile à la base ----------
  var STAGES = [
    { from: 1,  id: 'larva',   name: 'Larve',     icon: '🥚' },
    { from: 5,  id: 'juvenile', name: 'Juvénile', icon: '🐛' },
    { from: 10, id: 'predator', name: 'Prédateur', icon: '🦎' },
    { from: 20, id: 'alpha',   name: 'Alpha',     icon: '🐲' },
    { from: 35, id: 'elder',   name: 'Ancien',    icon: '👁️' },
    { from: 50, id: 'primordial', name: 'Primordial', icon: '🌌' }
  ];
  function stageOf(level) {
    var st = STAGES[0];
    STAGES.forEach(function (g) { if (level >= g.from) st = g; });
    return st;
  }
  var SECRETION_CAP_HOURS = 8;               // la sécrétion s'accumule 8 h max entre deux collectes
  var HATCH_MS = 6 * 3600 * 1000;            // une Couvée toutes les 6 h
  var HATCH_MIN_LEVEL = 3;
  /** Ressources sécrétées par heure (le Symtor « produit » pour la base). */
  function secretionPerHour(level) {
    level = Math.max(1, Math.floor(Number(level) || 1));
    return { crystal: Math.round(4 + level * 1.1), metal: Math.round(3 + level * 0.9), energy: Math.round(2 + level * 0.6), dust: Math.round(6 + level * 1.6) };
  }
  /** Bonus PERMANENT de production de la base (toutes ressources) : +0,2 % par niveau, max +10 %. */
  function productionBonus(level) { return Math.min(0.10, Math.max(0, (Math.floor(Number(level) || 1) - 1)) * 0.002); }
  /** Nombre de Rejetons couvés à chaque Couvée. */
  function hatchCount(level) { level = Math.floor(Number(level) || 1); return level < HATCH_MIN_LEVEL ? 0 : Math.min(6, 1 + Math.floor(level / 8)); }
  /** Les récompenses de combat croissent avec le niveau : ×(1 + 3 % par niveau). */
  function rewardMult(level) { return 1 + Math.max(0, Math.floor(Number(level) || 1) - 1) * 0.03; }

  function xpFor(level) { return Math.floor(70 * Math.pow(1.19, Math.max(0, level - 1))); }
  function power(level, xp) { return Math.floor(level * 34 + Math.sqrt(Math.max(0, xp)) * 2.2); }
  function defense(level, mutations) { return Math.floor(level * 1.8 + mutations * 1.7); }
  function growth(level) { return 1 + Math.min(3.2, level * 0.055); }
  /** Nombre de « bouts de corps » (excroissances) qui poussent en plus au fil des niveaux : 0 à 6,
   * un nouveau tous les ~7 niveaux à partir du niveau 9. Déterministe (dépend seulement du niveau). */
  function lobeCount(level) { level = Math.floor(Number(level) || 1); return Math.min(6, Math.floor(Math.max(0, level - 2) / 7)); }

  // Identité visuelle fixe de la créature (couleur, teinte de contour, forme de base) : dérivée
  // une fois pour toutes de la graine du génome, donc unique et stable pour chaque symbiote.
  function bodyStyle(seed) {
    var r = rng((Number(seed) || 0) + 1);
    var shape = BODY_SHAPES[Math.floor(r() * BODY_SHAPES.length)];
    var hue = Math.floor(r() * 360);
    var sat = 0.5 + r() * 0.4;
    var val = 0.42 + r() * 0.18;
    var asym = 0.85 + r() * 0.3; // asymétrie légère du corps, pour éviter des silhouettes trop identiques
    return { shape: shape, hue: hue, sat: sat, val: val, asym: asym };
  }

  function defaultState() {
    return {
      built: false,
      capsuleOpened: false,
      level: 1,
      xp: 0,
      totalFed: 0,
      mutations: 0,
      genome: { seed: Math.floor(Math.random() * 2147483647), traits: {} },
      battles: { galaxyWon: 0, galaxyLost: 0, symbioteWon: 0, symbioteLost: 0 },
      lastFedAt: 0,
      lastCollectAt: 0,    // dernière collecte de sécrétion (ms) — 0 = pas encore démarré
      lastHatchAt: 0       // dernière Couvée (ms)
    };
  }

  function normalizeState(raw) {
    var s = defaultState();
    if (!raw || typeof raw !== 'object') return s;
    s.built = raw.built === true;
    s.capsuleOpened = raw.capsuleOpened === true;
    s.level = Math.max(1, Math.min(MAX_LEVEL, Math.floor(Number(raw.level) || 1)));
    s.xp = Math.max(0, Math.min(1e9, Number(raw.xp) || 0));
    s.totalFed = Math.max(0, Math.min(1e9, Math.floor(Number(raw.totalFed) || 0)));
    s.mutations = Math.max(0, Math.min(500, Math.floor(Number(raw.mutations) || 0)));
    if (raw.genome && typeof raw.genome === 'object') {
      s.genome.seed = Number(raw.genome.seed) || s.genome.seed;
      if (raw.genome.traits && typeof raw.genome.traits === 'object') {
        Object.keys(raw.genome.traits).forEach(function (k) { if (GENES.indexOf(k) >= 0) s.genome.traits[k] = Math.max(0, Math.min(12, Math.floor(Number(raw.genome.traits[k]) || 0))); });
      }
    }
    if (raw.battles && typeof raw.battles === 'object') {
      ['galaxyWon','galaxyLost','symbioteWon','symbioteLost'].forEach(function (k) { s.battles[k] = Math.max(0, Math.floor(Number(raw.battles[k]) || 0)); });
    }
    s.lastFedAt = Math.max(0, Number(raw.lastFedAt) || 0);
    s.lastCollectAt = Math.max(0, Number(raw.lastCollectAt) || 0);
    s.lastHatchAt = Math.max(0, Number(raw.lastHatchAt) || 0);
    return s;
  }

  // Choix de la mutation à débloquer : pondéré vers les traits encore peu présents, pour que
  // chaque créature développe un éventail varié plutôt que de répéter toujours les mêmes traits.
  // Reste 100% déterministe (graine + progression déjà sauvegardées), donc reproductible.
  function pickTrait(state) {
    var t = traits(state);
    var r = rng(state.genome.seed + state.mutations * 104729 + state.level * 977);
    var weights = GENES.map(function (g) { return 1 / (1 + (t[g] || 0) * (t[g] || 0)); });
    var total = weights.reduce(function (a, b) { return a + b; }, 0);
    var roll = r() * total, acc = 0;
    for (var i = 0; i < GENES.length; i++) {
      acc += weights[i];
      if (roll <= acc) return GENES[i];
    }
    return GENES[GENES.length - 1];
  }

  function gainXP(state, amount) {
    var gained = Math.max(0, Number(amount) || 0), levels = [];
    state.xp += gained;
    while (state.level < MAX_LEVEL && state.xp >= xpFor(state.level)) {
      state.xp -= xpFor(state.level);
      state.level += 1;
      state.mutations += 1;
      var trait = pickTrait(state);
      state.genome.traits[trait] = (state.genome.traits[trait] || 0) + 1;
      levels.push({ level: state.level, trait: trait, label: TRAIT_LABELS[trait] || trait });
    }
    return levels;
  }

  function feed(state, resourceId) {
    var f = FEED[resourceId];
    if (!f) return { ok: false, reason: 'invalid' };
    return { ok: true, xp: f.xp, cost: f.cost };
  }

  function traits(state) {
    var t = (state && state.genome && state.genome.traits) || {};
    var out = {};
    GENES.forEach(function (g) { out[g] = t[g] || 0; });
    return out;
  }

  function opponentPower(seed, level, type) {
    var base = type === 'symbiote' ? 42 : 58;
    var variance = ((Math.abs(seed * 9301 + 49297) % 233280) / 233280);
    return Math.floor(base + level * (type === 'symbiote' ? 29 : 25) + variance * 90);
  }
  /** Défense de l'adversaire (galactique ou symbiote sauvage), même logique de graine que opponentPower. */
  function opponentDefense(seed, level, type) {
    var variance = ((Math.abs(seed * 7919 + 15485863) % 97711) / 97711);
    return Math.floor(level * (type === 'symbiote' ? 1.6 : 1.3) + variance * 14);
  }

  // ---------- Combat réel tour par tour ----------
  // Simule un duel complet (barres de vie qui descendent, coups portés dans les deux sens) à partir
  // des stats des deux créatures, au lieu de tirer juste un « gagnant » à pile ou face. Déterministe
  // pour une graine donnée (rejouable), donc l'animation peut être reconstruite de façon identique.
  function simulateBattle(seed, own, enemy) {
    var r = rng(seed);
    var ownMax = Math.round(90 + own.defense * 4 + own.power * 0.5);
    var enemyMax = Math.round(90 + enemy.defense * 4 + enemy.power * 0.5);
    var ownHP = ownMax, enemyHP = enemyMax;
    var rounds = [], turn = 0, ownTurn = true;
    while (ownHP > 0 && enemyHP > 0 && turn < 40) {
      turn++;
      var atk = ownTurn ? own : enemy, def = ownTurn ? enemy : own;
      var crit = r() < 0.16;
      var raw = atk.power * (0.16 + r() * 0.09) * (crit ? 1.7 : 1);
      var dmg = Math.max(4, Math.round(raw - def.defense * 0.45));
      if (ownTurn) enemyHP = Math.max(0, enemyHP - dmg); else ownHP = Math.max(0, ownHP - dmg);
      rounds.push({ turn: turn, attacker: ownTurn ? 'own' : 'enemy', damage: dmg, crit: crit, ownHP: ownHP, enemyHP: enemyHP });
      ownTurn = !ownTurn;
    }
    var win = enemyHP <= 0 && ownHP > 0 ? true : (ownHP <= 0 ? false : ownHP >= enemyHP);
    return { rounds: rounds, ownMax: ownMax, enemyMax: enemyMax, win: win };
  }

  return {
    MAX_LEVEL: MAX_LEVEL, FEED: FEED, GENES: GENES, TRAIT_LABELS: TRAIT_LABELS, BODY_SHAPES: BODY_SHAPES,
    defaultState: defaultState, normalizeState: normalizeState, rng: rng, bodyStyle: bodyStyle,
    xpFor: xpFor, power: power, defense: defense, growth: growth, lobeCount: lobeCount,
    gainXP: gainXP, feed: feed, traits: traits, opponentPower: opponentPower, opponentDefense: opponentDefense, simulateBattle: simulateBattle,
    STAGES: STAGES, stageOf: stageOf, SECRETION_CAP_HOURS: SECRETION_CAP_HOURS, HATCH_MS: HATCH_MS, HATCH_MIN_LEVEL: HATCH_MIN_LEVEL,
    secretionPerHour: secretionPerHour, productionBonus: productionBonus, hatchCount: hatchCount, rewardMult: rewardMult
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = NEBUSTION.Symbiote;
