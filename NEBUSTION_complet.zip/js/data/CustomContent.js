/**
 * NEBUSTION - CustomContent
 * Magasin de héros/cartes créés SANS CODE (via tools/studio.html ou tools/import.html).
 * Stocké en localStorage, validé avant utilisation, au même format que HERO_LIST
 * (js/data/Heroes.js) : c'est ce qui permet à un héros créé ici d'apparaître
 * automatiquement partout (Boutique, Héros, Combat) sans toucher au code du jeu.
 * Aucune dépendance à Phaser : chargé très tôt, avant Heroes.js.
 */
window.NEBUSTION = window.NEBUSTION || {};

(function () {
  'use strict';
  var KEY = 'nebustion_custom_heroes_v1';
  var MAX_NAME = 32, MAX_TITLE = 140, MAX_DESC = 220;
  var VALID_BODY = ['bulky', 'robed', 'winged', 'armored_soldier', 'slim'];
  var VALID_PROP = ['dual_blades', 'shield', 'staff_orb', 'rifle', 'claws_mane', 'hologram_cards', 'orbiting_orbs', 'fire_hands', 'hammer'];
  var VALID_RARITY = ['commun', 'rare', 'epique', 'legendaire', 'mythique', 'celeste'];
  var VALID_ROLE = ['assassin', 'tank', 'healer', 'damage', 'sniper', 'control', 'support', 'dps', 'god'];

  function num(v, fb, min, max) { var n = Number(v); if (!Number.isFinite(n)) return fb; return Math.max(min === undefined ? 0 : min, Math.min(max === undefined ? 999999 : max, n)); }
  function str(v, max) { return String(v == null ? '' : v).trim().slice(0, max); }
  function slug(v) { var s = str(v, 40).toLowerCase().replace(/[^a-z0-9_-]/g, '_').replace(/^_+|_+$/g, ''); return s || ('heros_' + Math.random().toString(36).slice(2, 8)); }
  /** Préfixe idempotent : un id déjà préfixé ne l'est pas une seconde fois lors d'une ré-validation. */
  function makeId(rawId, name) { var base = slug(rawId || name); return base.indexOf('c_') === 0 ? base : ('c_' + base); }
  function pick(v, list, fb) { return list.indexOf(v) >= 0 ? v : fb; }
  function color(v, fb) { return /^#[0-9a-fA-F]{6}$/.test(v || '') ? v : fb; }
  /** Image envoyée par l'Atelier créateur : data URL, taille bornée (~260 Ko décodés) pour ne pas saturer le stockage local. */
  var MAX_PORTRAIT_LEN = 350000;
  function portrait(v) {
    if (typeof v !== 'string' || v.indexOf('data:image/') !== 0) return undefined;
    return v.length <= MAX_PORTRAIT_LEN ? v : undefined;
  }

  function validate(raw) {
    if (!raw || typeof raw !== 'object') throw new Error('héros invalide');
    var name = str(raw.name, MAX_NAME);
    if (!name) throw new Error('nom manquant');
    var id = makeId(raw.id, name);
    var b = raw.base || {}, v = raw.visual || {}, sk = raw.skills || {};
    var hero = {
      id: id, name: name,
      title: str(raw.title, MAX_TITLE) || (name + '.'),
      role: pick(raw.role, VALID_ROLE, 'damage'),
      rarity: pick(raw.rarity, VALID_RARITY, 'commun'),
      affinity: str(raw.affinity, 20) || 'neutre',
      base: {
        hp: num(b.hp, 500, 50, 5000),
        atk: num(b.atk, 100, 10, 500),
        def: num(b.def, 60, 5, 400),
        spd: num(b.spd, 95, 20, 400)
      },
      visual: {
        body: pick(v.body, VALID_BODY, 'slim'),
        prop: pick(v.prop, VALID_PROP, 'dual_blades'),
        accent: color(v.accent, '#4fd1ff'),
        accent2: color(v.accent2, '#0a0f1e')
      },
      skills: {
        passive: { name: str(sk.passive && sk.passive.name, 30) || 'Don inné', target: 'self', desc: str(sk.passive && sk.passive.desc, MAX_DESC) || 'Talent naturel.' },
        active: { name: str(sk.active && sk.active.name, 30) || 'Frappe', target: 'enemy', cooldown: num(sk.active && sk.active.cooldown, 6, 1, 30), desc: str(sk.active && sk.active.desc, MAX_DESC) || 'Attaque la cible.' },
        ultimate: { name: str(sk.ultimate && sk.ultimate.name, 30) || 'Ultime', target: 'allEnemies', cost: num(sk.ultimate && sk.ultimate.cost, 100, 10, 100), desc: str(sk.ultimate && sk.ultimate.desc, MAX_DESC) || 'Attaque dévastatrice.' }
      },
      custom: true
    };
    // Vente en Boutique uniquement si un coût est explicitement fourni ; sinon le héros
    // est utilisable immédiatement partout (comme un héros de base sans `shop`).
    if (raw.shop && raw.shop.cost && Object.keys(raw.shop.cost).length) {
      var cost = {};
      Object.keys(raw.shop.cost).slice(0, 6).forEach(function (k) { cost[str(k, 20)] = num(raw.shop.cost[k], 0, 0, 999999999); });
      hero.shop = { cost: cost };
    }
    var img = portrait(raw.portrait);
    if (img) hero.portrait = img;
    return Object.freeze(hero);
  }

  function loadAll() {
    try { var arr = JSON.parse(localStorage.getItem(KEY) || '[]'); return Array.isArray(arr) ? arr : []; }
    catch (_) { return []; }
  }
  function saveAll(arr) { try { localStorage.setItem(KEY, JSON.stringify(arr)); } catch (_) {} }

  var raw = loadAll();
  var listeners = [];
  function emit() { listeners.forEach(function (fn) { try { fn(); } catch (_) {} }); }
  function findIndex(idOrName) {
    var key = slug(idOrName);
    for (var i = 0; i < raw.length; i++) { if (slug(raw[i].id || raw[i].name) === key) return i; }
    return -1;
  }

  window.NEBUSTION.CustomContent = {
    validate: validate,
    /** Liste validée, prête à fusionner avec HERO_LIST. */
    heroes: function () {
      var out = [];
      raw.forEach(function (item) { try { out.push(validate(item)); } catch (_) {} });
      return out;
    },
    /** Version brute (non figée) pour ré-édition dans l'outil créateur. */
    rawList: function () { return raw.slice(); },
    rawGet: function (id) { var i = findIndex(id); return i >= 0 ? raw[i] : null; },
    upsert: function (item) {
      var v = validate(item); // valide avant tout ; lève une erreur explicite si invalide
      var stored = JSON.parse(JSON.stringify(item));
      stored.id = v.id;
      var idx = findIndex(item.id || item.name);
      if (idx >= 0) raw[idx] = stored; else raw.push(stored);
      saveAll(raw); emit();
      return v;
    },
    remove: function (id) {
      raw = raw.filter(function (x) { return slug(x.id || x.name) !== slug(id); });
      saveAll(raw); emit();
    },
    importJSON: function (json) {
      var obj = typeof json === 'string' ? JSON.parse(json) : json;
      var list = Array.isArray(obj) ? obj : (Array.isArray(obj.heroes) ? obj.heroes : (Array.isArray(obj.cards) ? obj.cards : [obj]));
      var report = { added: 0, updated: 0, errors: [] };
      list.forEach(function (item) {
        try {
          var existed = findIndex(item.id || item.name) >= 0;
          window.NEBUSTION.CustomContent.upsert(item);
          if (existed) report.updated++; else report.added++;
        } catch (e) { report.errors.push((item && (item.name || item.id) || '?') + ' : ' + e.message); }
      });
      return report;
    },
    exportJSON: function () { return JSON.stringify({ heroes: raw }, null, 2); },
    onChange: function (fn) { listeners.push(fn); return function () { listeners = listeners.filter(function (f) { return f !== fn; }); }; }
  };
})();

/**
 * Ennemis créés sans code (via tools/studio.html), même principe que les héros :
 * validés puis fusionnés dans NEBUSTION.Enemies (ENEMY_LIST) et regroupés dans un
 * stage toujours débloqué "Arène personnalisée" pour être jouables immédiatement.
 */
(function () {
  'use strict';
  var KEY = 'nebustion_custom_enemies_v1';
  var MAX_NAME = 32;
  var VALID_ROLE = ['grunt', 'skirmisher', 'brute', 'swarm', 'sniper', 'bomber', 'control', 'tank', 'drain', 'support'];
  var VALID_SHAPE = ['drone', 'hunter', 'juggernaut', 'swarm', 'sniper', 'bomber', 'specter', 'golem', 'vampire', 'architect'];
  var VALID_KIND = ['singleDamage', 'aoeDamage', 'stun', 'drain', 'selfShield', 'aoeHeal'];
  var VALID_TARGET = ['single', 'allEnemies_player', 'allEnemies_self'];

  function num(v, fb, min, max) { var n = Number(v); if (!Number.isFinite(n)) return fb; return Math.max(min === undefined ? 0 : min, Math.min(max === undefined ? 999999 : max, n)); }
  function str(v, max) { return String(v == null ? '' : v).trim().slice(0, max); }
  function slug(v) { var s = str(v, 40).toLowerCase().replace(/[^a-z0-9_-]/g, '_').replace(/^_+|_+$/g, ''); return s || ('ennemi_' + Math.random().toString(36).slice(2, 8)); }
  function makeId(rawId, name) { var base = slug(rawId || name); return base.indexOf('ce_') === 0 ? base : ('ce_' + base); }
  function pick(v, list, fb) { return list.indexOf(v) >= 0 ? v : fb; }
  function color(v, fb) { return /^#[0-9a-fA-F]{6}$/.test(v || '') ? v : fb; }
  var MAX_PORTRAIT_LEN = 350000;
  function portrait(v) {
    if (typeof v !== 'string' || v.indexOf('data:image/') !== 0) return undefined;
    return v.length <= MAX_PORTRAIT_LEN ? v : undefined;
  }

  function validate(raw) {
    if (!raw || typeof raw !== 'object') throw new Error('ennemi invalide');
    var name = str(raw.name, MAX_NAME);
    if (!name) throw new Error('nom manquant');
    var id = makeId(raw.id, name);
    var b = raw.base || {}, v = raw.visual || {}, sk = raw.skill || null;
    var enemy = {
      id: id, name: name,
      tier: Math.floor(num(raw.tier, 5, 1, 13)),
      role: pick(raw.role, VALID_ROLE, 'grunt'),
      base: {
        hp: num(b.hp, 400, 50, 20000),
        atk: num(b.atk, 60, 5, 500),
        def: num(b.def, 30, 0, 300),
        spd: num(b.spd, 80, 10, 300)
      },
      visual: {
        shape: pick(v.shape, VALID_SHAPE, 'drone'),
        color: color(v.color, '#7a89ad'),
        accent: color(v.accent, '#c7d1ea')
      },
      custom: true
    };
    if (sk && str(sk.name, 30)) {
      enemy.skill = {
        name: str(sk.name, 30),
        cooldown: num(sk.cooldown, 8, 1, 30),
        target: pick(sk.target, VALID_TARGET, 'single'),
        kind: pick(sk.kind, VALID_KIND, 'singleDamage'),
        power: Math.round(num(sk.power, 1, 0.1, 4) * 100) / 100
      };
    } else {
      enemy.skill = null;
    }
    var eimg = portrait(raw.portrait);
    if (eimg) enemy.portrait = eimg;
    return Object.freeze(enemy);
  }

  function loadAll() {
    try { var arr = JSON.parse(localStorage.getItem(KEY) || '[]'); return Array.isArray(arr) ? arr : []; }
    catch (_) { return []; }
  }
  function saveAll(arr) { try { localStorage.setItem(KEY, JSON.stringify(arr)); } catch (_) {} }

  var raw = loadAll();
  var listeners = [];
  function emit() { listeners.forEach(function (fn) { try { fn(); } catch (_) {} }); }
  function findIndex(idOrName) {
    var key = slug(idOrName);
    for (var i = 0; i < raw.length; i++) { if (slug(raw[i].id || raw[i].name) === key) return i; }
    return -1;
  }

  window.NEBUSTION.CustomContent.enemies = function () {
    var out = [];
    raw.forEach(function (item) { try { out.push(validate(item)); } catch (_) {} });
    return out;
  };
  window.NEBUSTION.CustomContent.validateEnemy = validate;
  window.NEBUSTION.CustomContent.rawEnemyList = function () { return raw.slice(); };
  window.NEBUSTION.CustomContent.rawEnemyGet = function (id) { var i = findIndex(id); return i >= 0 ? raw[i] : null; };
  window.NEBUSTION.CustomContent.upsertEnemy = function (item) {
    var v = validate(item);
    var stored = JSON.parse(JSON.stringify(item));
    stored.id = v.id;
    var idx = findIndex(item.id || item.name);
    if (idx >= 0) raw[idx] = stored; else raw.push(stored);
    saveAll(raw); emit();
    return v;
  };
  window.NEBUSTION.CustomContent.removeEnemy = function (id) {
    raw = raw.filter(function (x) { return slug(x.id || x.name) !== slug(id); });
    saveAll(raw); emit();
  };
  window.NEBUSTION.CustomContent.exportEnemiesJSON = function () { return JSON.stringify({ enemies: raw }, null, 2); };
  window.NEBUSTION.CustomContent.onEnemiesChange = function (fn) { listeners.push(fn); return function () { listeners = listeners.filter(function (f) { return f !== fn; }); }; };
})();

/**
 * Objets/équipements créés sans code (via tools/studio.html, onglet Équipement) : contrairement
 * aux héros/ennemis, un "objet personnalisé" n'est qu'une IDENTITÉ (nom + image) posée sur un
 * emplacement et une rareté déjà existants (js/data/Equipment.js) — les bonus, coûts et niveaux
 * restent calculés par les formules du jeu, jamais par l'objet lui-même. Chaque objet fabriqué
 * en jeu à partir d'un modèle référence son id (templateId, voir EquipmentManager.craftTemplate) ;
 * modifier ou supprimer un modèle plus tard n'affecte que son nom/image affichés.
 */
(function () {
  'use strict';
  var KEY = 'nebustion_custom_items_v1';
  var MAX_NAME = 32;
  var VALID_SLOT = ['weapon', 'armor', 'module', 'reactor', 'artifact'];
  var VALID_RARITY = ['commun', 'rare', 'epique', 'legendaire'];

  function str(v, max) { return String(v == null ? '' : v).trim().slice(0, max); }
  function slug(v) { var s = str(v, 40).toLowerCase().replace(/[^a-z0-9_-]/g, '_').replace(/^_+|_+$/g, ''); return s || ('objet_' + Math.random().toString(36).slice(2, 8)); }
  function makeId(rawId, name) { var base = slug(rawId || name); return base.indexOf('ci_') === 0 ? base : ('ci_' + base); }
  function pick(v, list, fb) { return list.indexOf(v) >= 0 ? v : fb; }
  function color(v, fb) { return /^#[0-9a-fA-F]{6}$/.test(v || '') ? v : fb; }
  var MAX_PORTRAIT_LEN = 350000;
  function portrait(v) {
    if (typeof v !== 'string' || v.indexOf('data:image/') !== 0) return undefined;
    return v.length <= MAX_PORTRAIT_LEN ? v : undefined;
  }

  function validate(raw) {
    if (!raw || typeof raw !== 'object') throw new Error('objet invalide');
    var name = str(raw.name, MAX_NAME);
    if (!name) throw new Error('nom manquant');
    var id = makeId(raw.id, name);
    var item = {
      id: id, name: name,
      slot: pick(raw.slot, VALID_SLOT, 'weapon'),
      rarity: pick(raw.rarity, VALID_RARITY, 'commun'),
      accent: color(raw.accent, '#4fd1ff'),
      custom: true
    };
    var img = portrait(raw.portrait);
    if (img) item.portrait = img;
    return Object.freeze(item);
  }

  function loadAll() {
    try { var arr = JSON.parse(localStorage.getItem(KEY) || '[]'); return Array.isArray(arr) ? arr : []; }
    catch (_) { return []; }
  }
  function saveAll(arr) { try { localStorage.setItem(KEY, JSON.stringify(arr)); } catch (_) {} }

  var raw = loadAll();
  var listeners = [];
  function emit() { listeners.forEach(function (fn) { try { fn(); } catch (_) {} }); }
  function findIndex(idOrName) {
    var key = slug(idOrName);
    for (var i = 0; i < raw.length; i++) { if (slug(raw[i].id || raw[i].name) === key) return i; }
    return -1;
  }

  window.NEBUSTION.CustomContent.validateItem = validate;
  window.NEBUSTION.CustomContent.items = function () {
    var out = [];
    raw.forEach(function (item) { try { out.push(validate(item)); } catch (_) {} });
    return out;
  };
  window.NEBUSTION.CustomContent.rawItemList = function () { return raw.slice(); };
  window.NEBUSTION.CustomContent.rawItemGet = function (id) { var i = findIndex(id); return i >= 0 ? raw[i] : null; };
  window.NEBUSTION.CustomContent.upsertItem = function (item) {
    var v = validate(item);
    var stored = JSON.parse(JSON.stringify(item));
    stored.id = v.id;
    var idx = findIndex(item.id || item.name);
    if (idx >= 0) raw[idx] = stored; else raw.push(stored);
    saveAll(raw); emit();
    return v;
  };
  window.NEBUSTION.CustomContent.removeItem = function (id) {
    raw = raw.filter(function (x) { return slug(x.id || x.name) !== slug(id); });
    saveAll(raw); emit();
  };
  window.NEBUSTION.CustomContent.exportItemsJSON = function () { return JSON.stringify({ items: raw }, null, 2); };
  window.NEBUSTION.CustomContent.onItemsChange = function (fn) { listeners.push(fn); return function () { listeners = listeners.filter(function (f) { return f !== fn; }); }; };
})();

/**
 * Réglages d'équilibrage modifiables sans code (via tools/studio.html, onglet Réglages) :
 * bonus d'équipement par emplacement, multiplicateurs de rareté, et multiplicateurs de
 * difficulté (stats/récompenses des ennemis). Un SCHEMA fixe décrit chaque réglage
 * (clé, groupe, bornes, valeur par défaut) ; seules les valeurs qui s'en écartent sont
 * stockées, pour pouvoir toujours "Réinitialiser" proprement.
 */
(function () {
  'use strict';
  var KEY = 'nebustion_game_config_v1';

  var SCHEMA = [
    // ---- Équipement : bonus de base (niveau 1, rareté commune) par emplacement ----
    { key: 'eq_bonus_weapon_atk', group: 'equipement', label: 'Arme — bonus Attaque', min: 1, max: 200, step: 1, def: 14 },
    { key: 'eq_bonus_armor_hp', group: 'equipement', label: 'Armure — bonus PV', min: 1, max: 1000, step: 1, def: 90 },
    { key: 'eq_bonus_armor_def', group: 'equipement', label: 'Armure — bonus Défense', min: 1, max: 200, step: 1, def: 8 },
    { key: 'eq_bonus_module_spd', group: 'equipement', label: 'Module — bonus Vitesse', min: 1, max: 100, step: 1, def: 6 },
    { key: 'eq_bonus_module_crit', group: 'equipement', label: 'Module — bonus Critique', min: 0.005, max: 0.3, step: 0.005, def: 0.02 },
    { key: 'eq_bonus_reactor_hp', group: 'equipement', label: 'Réacteur — bonus PV', min: 1, max: 1000, step: 1, def: 60 },
    { key: 'eq_bonus_reactor_spd', group: 'equipement', label: 'Réacteur — bonus Vitesse', min: 1, max: 100, step: 1, def: 3 },
    { key: 'eq_bonus_artifact_crit', group: 'equipement', label: 'Artefact — bonus Critique', min: 0.005, max: 0.3, step: 0.005, def: 0.035 },
    { key: 'eq_bonus_artifact_atk', group: 'equipement', label: 'Artefact — bonus Attaque', min: 1, max: 200, step: 1, def: 5 },
    { key: 'eq_level_growth', group: 'equipement', label: 'Croissance par niveau (x)', min: 1.01, max: 2, step: 0.01, def: 1.12 },
    { key: 'eq_max_level', group: 'equipement', label: 'Niveau maximum', min: 1, max: 50, step: 1, def: 10 },
    { key: 'eq_rarity_mult_rare', group: 'equipement', label: 'Multiplicateur rareté Rare', min: 1, max: 10, step: 0.1, def: 1.5 },
    { key: 'eq_rarity_mult_epique', group: 'equipement', label: 'Multiplicateur rareté Épique', min: 1, max: 15, step: 0.1, def: 2.2 },
    { key: 'eq_rarity_mult_legendaire', group: 'equipement', label: 'Multiplicateur rareté Légendaire', min: 1, max: 20, step: 0.1, def: 3.2 },
    // ---- Difficultés : multiplicateurs de stats ennemies / récompenses ----
    { key: 'diff_facile_stat', group: 'difficulte', label: 'Facile — stats ennemies (x)', min: 0.2, max: 3, step: 0.01, def: 0.78 },
    { key: 'diff_facile_reward', group: 'difficulte', label: 'Facile — récompenses (x)', min: 0.1, max: 5, step: 0.01, def: 0.75 },
    { key: 'diff_normal_stat', group: 'difficulte', label: 'Normal — stats ennemies (x)', min: 0.2, max: 3, step: 0.01, def: 1.00 },
    { key: 'diff_normal_reward', group: 'difficulte', label: 'Normal — récompenses (x)', min: 0.1, max: 5, step: 0.01, def: 1.00 },
    { key: 'diff_difficile_stat', group: 'difficulte', label: 'Difficile — stats ennemies (x)', min: 0.2, max: 4, step: 0.01, def: 1.35 },
    { key: 'diff_difficile_reward', group: 'difficulte', label: 'Difficile — récompenses (x)', min: 0.1, max: 6, step: 0.01, def: 1.35 },
    { key: 'diff_cauchemar_stat', group: 'difficulte', label: 'Cauchemar — stats ennemies (x)', min: 0.2, max: 6, step: 0.01, def: 1.85 },
    { key: 'diff_cauchemar_reward', group: 'difficulte', label: 'Cauchemar — récompenses (x)', min: 0.1, max: 8, step: 0.01, def: 1.75 },
    // ---- Troupes : bonus par rang d'amélioration (Caserne, 3 branches × 10 rangs) ----
    { key: 'troop_assault_pct', group: 'troupes', label: 'Assaut — bonus DPS par rang (%)', min: 1, max: 25, step: 0.5, def: 7 },
    { key: 'troop_armor_pct', group: 'troupes', label: 'Blindage — bonus PV par rang (%)', min: 1, max: 25, step: 0.5, def: 8 },
    { key: 'troop_mobility_speed_pct', group: 'troupes', label: 'Propulsion — bonus vitesse par rang (%)', min: 1, max: 25, step: 0.5, def: 6 },
    { key: 'troop_mobility_range', group: 'troupes', label: 'Propulsion — bonus portée par rang', min: 0.01, max: 0.3, step: 0.01, def: 0.05 },
    { key: 'troop_upgrade_cost_mult', group: 'troupes', label: 'Coût des rangs d\'amélioration (x)', min: 0.2, max: 5, step: 0.05, def: 1 },
    // ---- Économie : multiplicateurs globaux de production ----
    { key: 'eco_global_prod_mult', group: 'economie', label: 'Production passive — multiplicateur global (x)', min: 0.1, max: 10, step: 0.05, def: 1 },
    { key: 'eco_global_tap_mult', group: 'economie', label: 'Récolte manuelle (tap) — multiplicateur global (x)', min: 0.1, max: 10, step: 0.05, def: 1 },
    { key: 'eco_building_cost_mult', group: 'economie', label: 'Bâtiments du QG — coût des améliorations (x)', min: 0.1, max: 10, step: 0.05, def: 1 },
    // ---- Renaissance (Prestige) : gain de Reliques et coût de l'arbre permanent ----
    { key: 'prestige_relic_mult', group: 'renaissance', label: 'Reliques gagnées par Renaissance (x)', min: 0.1, max: 10, step: 0.05, def: 1 },
    { key: 'prestige_tree_cost_mult', group: 'renaissance', label: 'Coût de l\'arbre de bonus permanents (x)', min: 0.1, max: 10, step: 0.05, def: 1 },
    // ---- Expéditions & Événements : récompenses ----
    { key: 'expedition_reward_mult', group: 'expeditions', label: 'Expéditions — récompenses (ressources, fragments, XP) (x)', min: 0.1, max: 10, step: 0.05, def: 1 },
    { key: 'event_boss_reward_mult', group: 'expeditions', label: 'Boss événementiel — récompense de mise à mort (x)', min: 0.1, max: 10, step: 0.05, def: 1 }
  ];
  var BY_KEY = {};
  SCHEMA.forEach(function (s) { BY_KEY[s.key] = s; });

  function loadAll() {
    try { var o = JSON.parse(localStorage.getItem(KEY) || '{}'); return (o && typeof o === 'object') ? o : {}; }
    catch (_) { return {}; }
  }
  function saveAll(o) { try { localStorage.setItem(KEY, JSON.stringify(o)); } catch (_) {} }

  var overrides = loadAll();
  var listeners = [];
  function emit() { listeners.forEach(function (fn) { try { fn(); } catch (_) {} }); }
  function clamp(schemaEntry, v) {
    var n = Number(v);
    if (!Number.isFinite(n)) return schemaEntry.def;
    return Math.max(schemaEntry.min, Math.min(schemaEntry.max, n));
  }

  window.NEBUSTION.CustomContent.GameConfig = {
    schema: function () { return SCHEMA.slice(); },
    /** Valeur effective d'un réglage (override validé, sinon valeur par défaut). */
    get: function (key) {
      var s = BY_KEY[key];
      if (!s) return undefined;
      return (key in overrides) ? clamp(s, overrides[key]) : s.def;
    },
    getAll: function () {
      var out = {};
      SCHEMA.forEach(function (s) { out[s.key] = (s.key in overrides) ? clamp(s, overrides[s.key]) : s.def; });
      return out;
    },
    /** true si ce réglage a une valeur personnalisée (différente du défaut). */
    isOverridden: function (key) { return key in overrides; },
    set: function (key, value) {
      var s = BY_KEY[key];
      if (!s) throw new Error('réglage inconnu : ' + key);
      overrides[key] = clamp(s, value);
      saveAll(overrides); emit();
      return overrides[key];
    },
    reset: function (key) {
      delete overrides[key];
      saveAll(overrides); emit();
    },
    resetAll: function () {
      overrides = {};
      saveAll(overrides); emit();
    },
    onChange: function (fn) { listeners.push(fn); return function () { listeners = listeners.filter(function (f) { return f !== fn; }); }; }
  };
})();
