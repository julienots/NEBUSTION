/**
 * NEBUSTION - PlanetBuild
 * Bâtiments à PLACEMENT LIBRE sur Nexus-01 : le joueur choisit un type, tourne la planète et le
 * pose où il veut (longitude/latitude). Données + règles pures (aucune dépendance à Phaser),
 * testables sous Node ; les fonctions qui touchent à l'économie reçoivent le gestionnaire
 * (NEBUSTION.Resources) en paramètre.
 *
 * État sauvegardé : state.planetBuild = { v:1, seq:n, items:[{ id, type, lon, lat }] }
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.PlanetBuild = (function () {
  'use strict';

  var MAX_TOTAL = 42;          // bâtiments posés au maximum (performances)
  var MIN_SEP_DEG = 15;        // écart angulaire minimal entre deux constructions (elles ne se chevauchent pas)
  var MAX_LAT = 80;            // pas de construction pile sur les pôles (déformation)
  var REFUND = 0.5;            // part remboursée au recyclage

  // Coûts en ressources existantes (crystal / metal / energy / dust), croissants par exemplaire déjà posé.
  var CATALOG = {
    beacon:  { id: 'beacon',  name: 'Balise lumineuse',  icon: '💡', color: 0xff6ec7, base: { crystal: 30, energy: 20 },  growth: 1.25, maxCount: 6, info: 'Un faisceau visible de loin. Pour baliser un secteur.' },
    pylon:   { id: 'pylon',   name: 'Pylône d\'énergie', icon: '⚡', color: 0x4fe3ff, base: { metal: 60, energy: 40 },    growth: 1.28, maxCount: 6, info: 'Anneaux d\'énergie pulsants autour d\'un mât.' },
    radar:   { id: 'radar',   name: 'Antenne radar',     icon: '📡', color: 0xffd166, base: { metal: 70, energy: 50 },    growth: 1.28, maxCount: 6, info: 'Une parabole qui balaie le ciel en continu.' },
    silo:    { id: 'silo',    name: 'Silo',              icon: '🛢️', color: 0xc9d4ea, base: { metal: 80, dust: 80 },      growth: 1.28, maxCount: 6, info: 'Réservoirs cylindriques pour la base.' },
    dome:    { id: 'dome',    name: 'Dôme habitat',      icon: '🏙️', color: 0x7dffb0, base: { crystal: 90, metal: 70 },   growth: 1.3,  maxCount: 5, info: 'Une petite colonie sous verrière lumineuse.' },
    garden:  { id: 'garden',  name: 'Serre bio',         icon: '🌿', color: 0x8dff6a, base: { dust: 100, crystal: 60 },   growth: 1.3,  maxCount: 5, info: 'Végétation sous serre, un coin de vert sur la planète.' },
    turret:  { id: 'turret',  name: 'Tourelle orbitale', icon: '🎯', color: 0xff4d6d, base: { metal: 110, energy: 70 },   growth: 1.32, maxCount: 5, info: 'Blindage et canons jumelés qui scrutent l\'horizon.' },
    reactor: { id: 'reactor', name: 'Réacteur',          icon: '☢️', color: 0xb26bff, base: { energy: 150, crystal: 100 }, growth: 1.35, maxCount: 4, info: 'Un noyau instable qui rayonne d\'énergie.' },
    // Seul bâtiment libre avec un EFFET DE JEU : chaque tour posée relaie les gisements et augmente la production
    // totale (passive ET hors ligne). Cumulable jusqu'à maxCount. Branché dans ResourceManager.rates().
    tower:   { id: 'tower',   name: 'Tour de relais',    icon: '🗼', color: 0x3affd0, base: { metal: 200, energy: 120 },  growth: 1.4,  maxCount: 4, tall: true,
               effect: { production: 0.03 }, badge: '+3 % prod.',
               info: 'Relaie les gisements : +3 % de production sur toutes les ressources, par tour posée.' },
    // ---- Bâtiments utiles (effets réels, cumulables jusqu'à maxCount) — branchés dans ResourceManager ----
    warehouse: { id: 'warehouse', name: 'Entrepôt blindé', icon: '📦', color: 0xffb347, base: { metal: 180, dust: 150 }, growth: 1.4, maxCount: 4,
               effect: { storage: 0.10 }, badge: '+10 % stockage',
               info: 'Agrandit les réserves : +10 % de capacité de stockage (toutes ressources), par entrepôt.' },
    harvester: { id: 'harvester', name: 'Foreuse de gisements', icon: '⛏️', color: 0xff8a4a, base: { metal: 160, energy: 90 }, growth: 1.4, maxCount: 4,
               effect: { tap: 0.08 }, badge: '+8 % récolte',
               info: 'Perce plus profond : +8 % de ressources à chaque récolte manuelle, par foreuse.' },
    chrono:  { id: 'chrono',  name: 'Chronodôme',        icon: '⏳', color: 0xc48bff, base: { crystal: 260, energy: 200 }, growth: 1.5, maxCount: 3, tall: true,
               effect: { offlineEff: 0.08 }, badge: '+8 % hors ligne',
               info: 'Garde la base active en ton absence : +8 points de rendement hors ligne, par dôme (max 100 %).' },
    refinery: { id: 'refinery', name: 'Raffinerie',       icon: '🏭', color: 0xd7dde8, base: { crystal: 140, energy: 110 }, growth: 1.38, maxCount: 4,
               effect: { resProd: { metal: 0.08, dust: 0.08 } }, badge: '+8 % métal/poussière',
               info: 'Traite les minerais : +8 % de production de métal et de poussière, par raffinerie.' },
    condenser: { id: 'condenser', name: 'Condenseur quantique', icon: '🔮', color: 0x62e6ff, base: { metal: 170, dust: 130 }, growth: 1.38, maxCount: 4,
               effect: { resProd: { energy: 0.08, crystal: 0.08 } }, badge: '+8 % énergie/cristaux',
               info: 'Concentre le flux : +8 % de production d\'énergie et de cristaux, par condenseur.' },
    // ---- Bâtiments SANS rapport avec les ressources : défense, combat, expéditions, caisses, Pass (branchés dans les managers concernés) ----
    shield:  { id: 'shield',  name: 'Générateur de bouclier', icon: '🛡️', color: 0x4d9bff, base: { crystal: 400, energy: 300 }, growth: 1.6, maxCount: 3,
               effect: { security: 1 }, badge: '+1 sécurité QG',
               info: 'Un dôme protecteur : +1 niveau de sécurité du QG (contre les raids), par générateur.' },
    academy: { id: 'academy', name: 'Académie de guerre', icon: '⚔️', color: 0xff5d5d, base: { metal: 300, crystal: 200 }, growth: 1.5, maxCount: 4,
               effect: { combatPower: 0.02 }, badge: '+2 % PV/ATQ/DÉF',
               info: 'Entraîne tes héros : +2 % de PV, d\'attaque et de défense en combat, par académie.' },
    spaceport: { id: 'spaceport', name: 'Spatioport', icon: '🚀', color: 0x7fd0ff, base: { metal: 350, energy: 250 }, growth: 1.5, maxCount: 3, tall: true,
               effect: { expDur: 0.08 }, badge: '−8 % durée exped.',
               info: 'Décollages accélérés : les expéditions durent 8 % de moins, par spatioport (max −24 %).' },
    forge:   { id: 'forge',   name: 'Forge d\'éclats',  icon: '⚒️', color: 0xffb3f0, base: { metal: 250, dust: 300 }, growth: 1.45, maxCount: 3,
               effect: { shardsPct: 0.15 }, badge: '+15 % Éclats',
               info: 'Récupère mieux les débris : +15 % d\'Éclats stellaires gagnés à chaque ouverture de caisse, par forge.' },
    training: { id: 'training', name: 'Centre de formation', icon: '🎓', color: 0x8dff6a, base: { crystal: 300, dust: 250 }, growth: 1.5, maxCount: 3,
               effect: { passXp: 0.10 }, badge: '+10 % XP Pass',
               info: 'Progresse plus vite : +10 % d\'XP de Pass de saison gagnée, par centre.' }
  };
  var ORDER = ['beacon', 'pylon', 'radar', 'silo', 'dome', 'garden', 'turret', 'reactor', 'tower', 'warehouse', 'harvester', 'chrono', 'refinery', 'condenser', 'shield', 'academy', 'spaceport', 'forge', 'training'];

  function num(x, min, max, def) { x = Number(x); if (!isFinite(x)) return def; return x < min ? min : (x > max ? max : x); }

  function defaultState() { return { v: 1, seq: 0, items: [] }; }

  /** Nettoie une sauvegarde : types inconnus retirés, coordonnées bornées, doublons d'id et excédents écartés. */
  function normalizeState(raw) {
    var s = defaultState();
    if (!raw || typeof raw !== 'object' || !Array.isArray(raw.items)) return s;
    var seen = {}, counts = {}, i, it, id, type, lon, lat;
    for (i = 0; i < raw.items.length && s.items.length < MAX_TOTAL; i++) {
      it = raw.items[i];
      if (!it || typeof it !== 'object') continue;
      type = String(it.type || '');
      if (!CATALOG[type]) continue;
      id = String(it.id || '').slice(0, 24);
      if (!id || seen[id]) continue;
      counts[type] = (counts[type] || 0) + 1;
      if (counts[type] > CATALOG[type].maxCount) continue;
      lon = num(it.lon, -180, 180, NaN); lat = num(it.lat, -MAX_LAT, MAX_LAT, NaN);
      if (isNaN(lon) || isNaN(lat)) continue;
      seen[id] = true;
      s.items.push({ id: id, type: type, lon: Math.round(lon * 100) / 100, lat: Math.round(lat * 100) / 100 });
    }
    s.seq = Math.floor(num(raw.seq, s.items.length, 1e9, s.items.length));
    return s;
  }

  function count(state, type) {
    var n = 0, i;
    for (i = 0; i < state.items.length; i++) if (state.items[i].type === type) n++;
    return n;
  }

  /** Coût du prochain exemplaire d'un type quand `owned` sont déjà posés. */
  function cost(type, owned) {
    var def = CATALOG[type], out = {};
    if (!def) return out;
    var mult = Math.pow(def.growth, Math.max(0, owned | 0));
    Object.keys(def.base).forEach(function (rid) { out[rid] = Math.ceil(def.base[rid] * mult); });
    return out;
  }

  /** Distance angulaire (degrés) entre deux points lon/lat à la surface d'une sphère. */
  function angDist(lon1, lat1, lon2, lat2) {
    var r = Math.PI / 180, a = lat1 * r, b = lat2 * r, dl = (lon1 - lon2) * r;
    var d = Math.sin(a) * Math.sin(b) + Math.cos(a) * Math.cos(b) * Math.cos(dl);
    return Math.acos(d < -1 ? -1 : (d > 1 ? 1 : d)) / r;
  }

  /**
   * Un emplacement est-il libre ? `others` = [{lon, lat}] (bâtiments, gisements, autres constructions).
   * `ignoreId` : la construction qu'on est en train de déplacer.
   */
  function spotOk(lon, lat, others, ignoreId) {
    if (!isFinite(lon) || !isFinite(lat) || Math.abs(lat) > MAX_LAT) return false;
    for (var i = 0; i < others.length; i++) {
      if (ignoreId && others[i].id === ignoreId) continue;
      if (angDist(lon, lat, others[i].lon, others[i].lat) < MIN_SEP_DEG) return false;
    }
    return true;
  }

  function normLon(lon) { lon = ((lon + 180) % 360 + 360) % 360 - 180; return lon; }

  /** Parcelles (Parcels.js) : on ne construit que sur une parcelle possédée de Nexus-01. Sans état de parcelles (vieux tests), tout est permis. */
  function parcelOk(R, lon, lat) {
    var P = NEBUSTION.Parcels, s = R && R.state && R.state.parcels;
    if (!P || !s || !s.worlds || !s.worlds.nexus) return true;
    return P.canBuild(s, 'nexus', lon, lat);
  }

  /** Pose un bâtiment : vérifie la limite, l'emplacement puis paie (tout ou rien). R = NEBUSTION.Resources. */
  function place(R, type, lon, lat, others) {
    var st = R.state.planetBuild, def = CATALOG[type];
    if (!def) return { ok: false, reason: 'type' };
    if (st.items.length >= MAX_TOTAL) return { ok: false, reason: 'total' };
    var owned = count(st, type);
    if (owned >= def.maxCount) return { ok: false, reason: 'max' };
    lon = normLon(lon);
    // Les constructions déjà posées comptent toujours, même si l'appelant ne les a pas listées.
    if (!spotOk(lon, lat, (others || []).concat(st.items), null)) return { ok: false, reason: 'spot' };
    if (!parcelOk(R, lon, lat)) return { ok: false, reason: 'parcel' };   // parcelle non achetée
    var c = cost(type, owned);
    if (!R.canAfford(c) || !R.spendMany(c)) return { ok: false, reason: 'cost', cost: c };
    st.seq++;
    var item = { id: 'pb' + st.seq, type: type, lon: Math.round(lon * 100) / 100, lat: Math.round(lat * 100) / 100 };
    st.items.push(item);
    R._rates = null;   // une tour / raffinerie / condenseur change le taux de production en cache
    try { R.saveNow(Date.now()); } catch (e) { /* le jeu continue en mémoire */ }
    return { ok: true, item: item, cost: c };
  }

  /** Bonus de production total (0,03 = +3 %) apporté par les constructions posées (tours de relais). */
  function productionBonus(state) {
    var sum = 0, i, def;
    if (!state || !Array.isArray(state.items)) return 0;
    for (i = 0; i < state.items.length; i++) {
      def = CATALOG[state.items[i].type];
      if (def && def.effect && def.effect.production) sum += def.effect.production;
    }
    return sum;
  }

  /** Somme d'un effet simple (`storage`, `tap`, `offlineEff`) apporté par les constructions posées. */
  function effectSum(state, key) {
    var sum = 0, i, def;
    if (!state || !Array.isArray(state.items)) return 0;
    for (i = 0; i < state.items.length; i++) {
      def = CATALOG[state.items[i].type];
      if (def && def.effect && typeof def.effect[key] === 'number') sum += def.effect[key];
    }
    return sum;
  }
  /** Bonus de production d'UNE ressource (0,08 = +8 %) apporté par les raffineries / condenseurs. */
  function resBonus(state, rid) {
    var sum = 0, i, def;
    if (!state || !Array.isArray(state.items)) return 0;
    for (i = 0; i < state.items.length; i++) {
      def = CATALOG[state.items[i].type];
      if (def && def.effect && def.effect.resProd && typeof def.effect.resProd[rid] === 'number') sum += def.effect.resProd[rid];
    }
    return sum;
  }

  function find(state, id) {
    for (var i = 0; i < state.items.length; i++) if (state.items[i].id === id) return state.items[i];
    return null;
  }

  /** Déplace gratuitement une construction existante. */
  function move(R, id, lon, lat, others) {
    var it = find(R.state.planetBuild, id);
    if (!it) return { ok: false, reason: 'unknown' };
    lon = normLon(lon);
    if (!spotOk(lon, lat, (others || []).concat(R.state.planetBuild.items), id)) return { ok: false, reason: 'spot' };
    if (!parcelOk(R, lon, lat)) return { ok: false, reason: 'parcel' };
    it.lon = Math.round(lon * 100) / 100; it.lat = Math.round(lat * 100) / 100;
    try { R.saveNow(Date.now()); } catch (e) { /* ignore */ }
    return { ok: true, item: it };
  }

  /** Recycle : retire la construction et rembourse REFUND × le prix du dernier exemplaire de ce type. */
  function recycle(R, id) {
    var st = R.state.planetBuild, it = find(st, id);
    if (!it) return { ok: false, reason: 'unknown' };
    var owned = count(st, it.type), c = cost(it.type, owned - 1), refund = {};
    Object.keys(c).forEach(function (rid) { refund[rid] = Math.floor(c[rid] * REFUND); });
    st.items.splice(st.items.indexOf(it), 1);
    R._rates = null;
    Object.keys(refund).forEach(function (rid) { if (refund[rid] > 0) R.add(rid, refund[rid], 'refund'); });
    try { R.saveNow(Date.now()); } catch (e) { /* ignore */ }
    return { ok: true, refund: refund };
  }

  return {
    CATALOG: CATALOG, ORDER: ORDER, MAX_TOTAL: MAX_TOTAL, MIN_SEP_DEG: MIN_SEP_DEG, MAX_LAT: MAX_LAT, REFUND: REFUND,
    defaultState: defaultState, normalizeState: normalizeState, count: count, cost: cost,
    angDist: angDist, spotOk: spotOk, parcelOk: parcelOk, normLon: normLon, place: place, move: move, recycle: recycle, find: find, productionBonus: productionBonus, effectSum: effectSum, resBonus: resBonus
  };
})();
