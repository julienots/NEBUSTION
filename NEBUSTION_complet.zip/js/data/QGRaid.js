/**
 * NEBUSTION - QGRaid
 * Données et formules PURES (aucune dépendance à Phaser, testable sous Node) pour les RAIDS ennemis
 * contre le Quartier Général du joueur (Nexus-01). Suite directe de `Security.js`, qui annonçait :
 * « de vraies défenses (tourelles, boucliers, vagues d'ennemis à repousser...) viendront se brancher
 * dessus plus tard ». C'est ce module qui les branche.
 *
 * Modèle volontairement simple et borné, dans le même esprit que EmpireEvolution.js :
 *  - Un empire assez développé (`evo`) et motivé (élan `mom` / traumatisme `hurt`, mémoire du module IA 3)
 *    tente parfois un raid contre le QG plutôt qu'une simple défense de ses planètes.
 *  - Défense du joueur = SecurityManager.effectiveLevel() (niveau manuel + bonus des Tourelles de la
 *    grille QG, module 11C) — aucune nouvelle jauge, on réutilise ce qui existe déjà.
 *  - Issue tirée par un aléa DÉTERMINISTE (seed de sauvegarde) : recharger la partie ne change jamais
 *    le résultat d'un raid déjà survenu, et la simulation reste rejouable/testable sous Node.
 *  - Raid repoussé : rien n'est perdu. Raid réussi : une partie des ressources stockées est pillée —
 *    jamais les Noyaux antiques (`core`), laissés intacts (liste exacte au choix du manager).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.QGRaid = (function () {
  'use strict';

  var STEP_MS = 30 * 60 * 1000;          // cadence de vérification : même pas que l'évolution des empires
  var MAX_CATCHUP_STEPS = 48;            // 24 h de vérifications rattrapées au plus (comme les autres modules)
  var MIN_GAP_MS = 6 * 3600 * 1000;      // au moins 6 h entre deux raids, qu'ils réussissent ou échouent
  var MIN_EVO = 2;                       // un empire trop jeune ne tente pas encore de raid
  var BASE_CHANCE = 0.045;               // chance de base, PAR vérification (30 min), qu'un raid soit tenté
  var LOSS_MIN = 0.06, LOSS_MAX = 0.18;  // part des ressources pillées si le raid réussit (bornée)
  var LOG_MAX = 8;                       // entrées d'historique conservées

  function clamp01(x) { return Math.max(0, Math.min(1, x)); }
  function r2(x) { return Math.round(x * 100) / 100; }
  function int(x, min, max, def) { x = Math.floor(Number(x)); return isFinite(x) ? Math.min(max, Math.max(min, x)) : def; }

  // ---------- Aléa déterministe (même famille que EmpireEvolution.rand01, sels différents : indépendant) ----------
  function rand01(seed, n, salt) {
    var h = (seed ^ Math.imul(n + 1, 0x9E3779B1) ^ Math.imul(salt + 11, 0xC2B2AE35)) >>> 0;
    h = Math.imul(h ^ (h >>> 16), 0x45D9F3B) >>> 0; h = Math.imul(h ^ (h >>> 16), 0x45D9F3B) >>> 0; h = (h ^ (h >>> 16)) >>> 0;
    return h / 4294967296;
  }

  function defaultState(now) {
    return { seed: Math.floor(Math.random() * 2147483645) + 1, n: 0, lastAt: now || Date.now(), lastRaidAt: 0, lastSeenAt: 0, log: [] };
  }

  function normalizeLogEntry(raw) {
    if (!raw || typeof raw !== 'object' || typeof raw.empire !== 'string' || !raw.empire) return null;
    return {
      at: int(raw.at, 0, 8.64e15, 0), empire: raw.empire, victory: !!raw.victory,
      attack: r2(Number(raw.attack) || 0), defense: r2(Number(raw.defense) || 0), lossPct: r2(Math.max(0, Number(raw.lossPct) || 0))
    };
  }

  function normalizeState(raw, now) {
    var s = defaultState(now);
    if (!raw || typeof raw !== 'object') return s;
    s.seed = int(raw.seed, 1, 2147483645, s.seed);
    s.n = int(raw.n, 0, 8.64e15, 0);
    s.lastAt = int(raw.lastAt, 0, 8.64e15, s.lastAt);
    s.lastRaidAt = int(raw.lastRaidAt, 0, 8.64e15, 0);
    s.lastSeenAt = int(raw.lastSeenAt, 0, 8.64e15, 0);
    s.log = Array.isArray(raw.log) ? raw.log.map(normalizeLogEntry).filter(Boolean).slice(-LOG_MAX) : [];
    return s;
  }

  /** Puissance d'attaque d'un empire, sur une échelle comparable au niveau de Sécurité du joueur (0..20+). */
  function attackPower(evo, momentum, hurt) {
    var base = 2 + Math.max(0, Number(evo) || 0) * 1.9;                          // evo 0..8 -> 2..17.2
    var mood = 1 + clamp01(momentum) * 0.5 - clamp01(hurt) * 0.35;               // motivé par l'élan, freiné par le traumatisme
    return Math.max(1, r2(base * Math.max(0.3, mood)));
  }

  /** Chance que le JOUEUR défende avec succès (repousse le raid), selon l'écart défense - attaque. */
  function defenseChance(defense, attack) {
    return clamp01(0.5 + (Number(defense) - Number(attack)) * 0.045);
  }

  /** Part des ressources perdues si le raid réussit (écart plus large en faveur de l'attaquant = pillage plus lourd, borné). */
  function lossFraction(defense, attack) {
    var margin = clamp01((Number(attack) - Number(defense)) / Math.max(1, Number(attack)));
    return r2(LOSS_MIN + (LOSS_MAX - LOSS_MIN) * margin);
  }

  return {
    STEP_MS: STEP_MS, MAX_CATCHUP_STEPS: MAX_CATCHUP_STEPS, MIN_GAP_MS: MIN_GAP_MS, MIN_EVO: MIN_EVO,
    BASE_CHANCE: BASE_CHANCE, LOSS_MIN: LOSS_MIN, LOSS_MAX: LOSS_MAX, LOG_MAX: LOG_MAX,
    rand01: rand01, defaultState: defaultState, normalizeState: normalizeState,
    attackPower: attackPower, defenseChance: defenseChance, lossFraction: lossFraction
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.QGRaid; }
