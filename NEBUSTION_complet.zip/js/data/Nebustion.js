/**
 * NEBUSTION - Nebustion (données pures, sans Phaser)
 * Module "grand méchant" : jauge de corruption galactique, Sanctuaire (contre-mesure
 * achetée directement depuis l'écran dédié, pas un bâtiment de la plateforme), Éclat
 * Souillé (monnaie des avant-postes corrompus) et dilemme du Symtor (nourrissage interdit).
 *
 * Contexte narratif : voir NEBUSTION_LA_CORRUPTION_concept.md. Ce fichier N'IMPLÉMENTE PAS
 * de nouveau moteur de combat : le combat contre les avant-postes corrompus et contre le
 * boss final réutilise entièrement CombatEngine/CombatManager/Enemies.js (nouveaux stages
 * 'corruption_outpost_1/2/3' et 'boss_nebustion', voir Enemies.js). Ce fichier ne fait que
 * la partie qui n'existait pas encore : la jauge elle-même, le Sanctuaire, et les formules
 * de récompense/dilemme qui s'y raccrochent.
 *
 * Comme Economy.js/Symbiote.js : JavaScript pur, testable sous Node (tests/nebustion.test.js).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Nebustion = (function () {
  'use strict';

  var CFG = {
    // Jauge de corruption galactique (0..100), montée passive lente (voir le concept :
    // ~1 %/4h en jeu réel), ralentie par le niveau du Sanctuaire.
    BASE_RATE_PER_HOUR: 0.25,        // +0,25 %/h sans Sanctuaire => ~+1 %/4h, ~100 % en ~16,7 jours
    MAX_PCT: 100,
    MAX_CATCHUP_HOURS: 24 * 21,      // rattrapage hors ligne borné à 21 jours (comme les autres modules à pas de temps)

    // Sanctuaire : contre-mesure du joueur, achetée en paliers (pas un bâtiment de plateforme).
    SANCTUARY_MAX_LEVEL: 20,
    SANCTUARY_DECAY_PER_LEVEL: 0.035,      // -3,5 % de vitesse de corruption par niveau (jusqu'à -70 % au niveau 20)
    SANCTUARY_BASE_COST: { crystal: 800, energy: 500, dust: 900 },
    SANCTUARY_COST_GROWTH: 1.45,
    SANCTUARY_PURIFY_PCT: 5,               // activation manuelle : -5 % de jauge, immédiat
    SANCTUARY_ACTIVATE_COOLDOWN_MS: 20 * 3600 * 1000,   // une activation toutes les 20 h

    // Avant-postes corrompus (stages 'corruption_outpost_*' dans Enemies.js) : plus la jauge
    // est haute, plus ils sont durs (mais aussi plus payants) — vrai tir de corde avec le temps.
    OUTPOST_MAX_SCALE_BONUS: 0.6,          // jusqu'à +60 % PV/ATQ/DÉF à 100 % de corruption
    OUTPOST_PURIFY_PCT: 4,                 // chaque avant-poste vaincu fait redescendre la jauge de 4 %
    OUTPOST_SHARD_REWARD: 6,               // Éclat Souillé gagné par victoire sur un avant-poste
    BOSS_SHARD_REWARD: 40,                 // Éclat Souillé gagné en battant le boss final

    // Dilemme du Symtor : nourrir avec de l'Éclat Souillé fait monter une "Résonance" (0..100).
    RESONANCE_MAX: 100,
    RESONANCE_PER_FEED: 14,
    SHARDS_PER_FEED: 10,
    CORRUPTED_SYMTOR_EXTRA_RATE_PER_HOUR: 0.10,   // le Symtor corrompu "appelle" Nebustion en continu

    // Identifiants des stages Enemies.js liés à ce module (voir Enemies.js).
    OUTPOST_STAGE_IDS: ['corruption_outpost_1', 'corruption_outpost_2', 'corruption_outpost_3'],
    BOSS_STAGE_ID: 'boss_nebustion',
    // Le module ne s'active (jauge visible, Sanctuaire achetable) qu'une fois ce stage battu :
    // c'est la victoire qui révèle que OMEGA-KRELL n'était qu'un héraut (voir le concept, Acte 1 -> 2).
    UNLOCK_STAGE_ID: 'boss_omega_krell'
  };

  function clamp(x, lo, hi) { return Math.max(lo, Math.min(hi, x)); }
  function num(v, lo, hi, def) { v = Number(v); return isFinite(v) ? clamp(v, lo, hi) : def; }
  function int(v, lo, hi, def) { v = Math.floor(Number(v)); return isFinite(v) ? clamp(v, lo, hi) : def; }

  // ---------- État ----------
  function defaultState(now) {
    now = Number(now) || Date.now();
    return {
      pct: 0,                 // jauge de corruption galactique, 0..100
      lastAt: now,
      sanctuaryLevel: 0,      // 0 = pas encore construit ; premier niveau = "construction"
      sanctuaryUsedAt: 0,     // dernière activation manuelle (purification immédiate)
      shards: 0,              // Éclat Souillé accumulé
      resonance: 0,           // 0..100, dilemme du Symtor
      symtorFeeds: 0,
      symtorCorrupted: false,
      unlocked: false          // devient vrai après la victoire sur UNLOCK_STAGE_ID
    };
  }

  function normalizeState(raw, now) {
    var s = defaultState(now);
    if (!raw || typeof raw !== 'object') return s;
    s.pct = num(raw.pct, 0, CFG.MAX_PCT, 0);
    s.lastAt = num(raw.lastAt, 0, now, now);
    s.sanctuaryLevel = int(raw.sanctuaryLevel, 0, CFG.SANCTUARY_MAX_LEVEL, 0);
    s.sanctuaryUsedAt = num(raw.sanctuaryUsedAt, 0, now, 0);
    s.shards = num(raw.shards, 0, 1e9, 0);
    s.resonance = num(raw.resonance, 0, CFG.RESONANCE_MAX, 0);
    s.symtorFeeds = int(raw.symtorFeeds, 0, 1e9, 0);
    s.symtorCorrupted = raw.symtorCorrupted === true;
    s.unlocked = raw.unlocked === true;
    return s;
  }

  // ---------- Vitesse de corruption ----------
  /** Vitesse effective (%/h), compte tenu du Sanctuaire et d'un éventuel Symtor corrompu. */
  function ratePerHour(state) {
    var decay = clamp(CFG.SANCTUARY_DECAY_PER_LEVEL * (state.sanctuaryLevel || 0), 0, 0.9);
    var rate = CFG.BASE_RATE_PER_HOUR * (1 - decay);
    if (state.symtorCorrupted) rate += CFG.CORRUPTED_SYMTOR_EXTRA_RATE_PER_HOUR;
    return Math.max(0, rate);
  }

  /** Avance la jauge de `state.lastAt` jusqu'à `now`, plafonné (rattrapage hors ligne borné). @returns delta appliqué (%) */
  function tick(state, now) {
    now = Number(now) || Date.now();
    if (!(now > state.lastAt)) { if (now < state.lastAt) state.lastAt = now; return 0; }
    var hours = Math.min((now - state.lastAt) / 3600000, CFG.MAX_CATCHUP_HOURS);
    var delta = ratePerHour(state) * hours;
    var before = state.pct;
    state.pct = clamp(state.pct + delta, 0, CFG.MAX_PCT);
    state.lastAt = now;
    return state.pct - before;
  }

  /** Réduit la jauge (avant-poste vaincu, Sanctuaire activé...). Jamais négative. */
  function purify(state, amountPct) {
    var before = state.pct;
    state.pct = clamp(state.pct - Math.max(0, Number(amountPct) || 0), 0, CFG.MAX_PCT);
    return before - state.pct;
  }

  // ---------- Sanctuaire ----------
  function sanctuaryCost(level) {
    level = int(level, 0, CFG.SANCTUARY_MAX_LEVEL, 0);
    var mult = Math.pow(CFG.SANCTUARY_COST_GROWTH, level);
    var out = {};
    Object.keys(CFG.SANCTUARY_BASE_COST).forEach(function (id) {
      out[id] = Math.ceil(CFG.SANCTUARY_BASE_COST[id] * mult);
    });
    return out;
  }
  function sanctuaryDecayPct(level) { return Math.round(clamp(CFG.SANCTUARY_DECAY_PER_LEVEL * (int(level, 0, CFG.SANCTUARY_MAX_LEVEL, 0)), 0, 0.9) * 100); }
  function canActivateSanctuary(state, now) {
    if (!(state.sanctuaryLevel > 0)) return false;
    return (Number(now) || Date.now()) - (state.sanctuaryUsedAt || 0) >= CFG.SANCTUARY_ACTIVATE_COOLDOWN_MS;
  }
  function sanctuaryCooldownRemainingMs(state, now) {
    var left = CFG.SANCTUARY_ACTIVATE_COOLDOWN_MS - ((Number(now) || Date.now()) - (state.sanctuaryUsedAt || 0));
    return Math.max(0, left);
  }

  // ---------- Avant-postes ----------
  /** Multiplicateur (>= 1) à appliquer au `scale` des stages 'corruption_outpost_*' : plus dur si la jauge est haute. */
  function outpostScaleBonus(pct) {
    return 1 + CFG.OUTPOST_MAX_SCALE_BONUS * clamp(Number(pct) || 0, 0, CFG.MAX_PCT) / CFG.MAX_PCT;
  }

  // ---------- Dilemme du Symtor ----------
  /** Nourrit le Symtor avec de l'Éclat Souillé. @returns {{ok, resonance, corrupted}} */
  function feedTainted(state) {
    if (state.shards < CFG.SHARDS_PER_FEED) return { ok: false, reason: 'shards' };
    state.shards -= CFG.SHARDS_PER_FEED;
    state.symtorFeeds += 1;
    state.resonance = clamp(state.resonance + CFG.RESONANCE_PER_FEED, 0, CFG.RESONANCE_MAX);
    var justCorrupted = false;
    if (!state.symtorCorrupted && state.resonance >= CFG.RESONANCE_MAX) { state.symtorCorrupted = true; justCorrupted = true; }
    return { ok: true, resonance: state.resonance, corrupted: state.symtorCorrupted, justCorrupted: justCorrupted };
  }

  /** Objet Larme de Purification (fin de jeu) : lève la corruption du Symtor. */
  function purifySymtor(state) {
    if (!state.symtorCorrupted) return false;
    state.symtorCorrupted = false;
    state.resonance = 0;
    return true;
  }

  return {
    CFG: CFG,
    defaultState: defaultState, normalizeState: normalizeState,
    ratePerHour: ratePerHour, tick: tick, purify: purify,
    sanctuaryCost: sanctuaryCost, sanctuaryDecayPct: sanctuaryDecayPct,
    canActivateSanctuary: canActivateSanctuary, sanctuaryCooldownRemainingMs: sanctuaryCooldownRemainingMs,
    outpostScaleBonus: outpostScaleBonus,
    feedTainted: feedTainted, purifySymtor: purifySymtor
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = NEBUSTION.Nebustion;
