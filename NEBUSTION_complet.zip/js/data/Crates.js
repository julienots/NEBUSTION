/**
 * NEBUSTION - Caisses & Clés (données)
 * Module pur (aucune dépendance à Phaser, testable sous Node comme Skins.js / Shop.js).
 *
 * Une CAISSE s'ouvre avec une CLÉ du même palier (3 paliers : Astrale, Nébuleuse, Singularité).
 * Chaque ouverture donne 1 récompense principale (skin exclusif, équipement, fragments de héros,
 * ressources ou Prismes) + des ÉCLATS STELLAIRES. Les doublons de skins sont recyclés en Éclats.
 *
 * Nouvelle fonctionnalité — la FORGE D'ÉCLATS : les Éclats servent à forger des clés ou à fabriquer
 * DIRECTEMENT le skin de son choix (plus de malchance). Un système de PITIÉ garantit un Épique toutes
 * les 10 ouvertures et un Légendaire toutes les 40.
 *
 * État de sauvegarde : { crates:{id:n}, keys:{id:n}, shards, pity:{epic,leg}, opened, lastDaily, history:[...] }
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Crates = (function () {
  'use strict';

  var SHARD = { id: 'shard', name: 'Éclats stellaires', short: 'Éclats', hex: '#ffb3f0', color: 0xffb3f0 };
  var RARITY_ORDER = ['commun', 'rare', 'epique', 'legendaire'];
  var RARITY_NAMES = { commun: 'Commun', rare: 'Rare', epique: 'Épique', legendaire: 'Légendaire' };

  var TIERS = ['astral', 'nebula', 'singularity'];

  // Paliers : caisse + clé associée, couleurs, prix, chances (en %) de chaque rareté.
  var CRATES = {
    astral: {
      id: 'astral', name: 'Caisse Astrale', keyName: 'Clé Astrale', color: 0x4fd1ff, hex: '#4fd1ff', color2: 0x1f6fa8,
      desc: 'La caisse de tous les jours : surtout du Commun et du Rare, avec une petite chance d\'Épique.',
      odds: { commun: 58, rare: 33, epique: 8, legendaire: 1 },
      crateCost: { dust: 1500, crystal: 400 }, keyCost: { gem: 20 }, keyShards: 25
    },
    nebula: {
      id: 'nebula', name: 'Caisse Nébuleuse', keyName: 'Clé Nébuleuse', color: 0xb47bff, hex: '#b47bff', color2: 0x5a2ea8,
      desc: 'Rare garanti au minimum, bonnes chances d\'Épique et vraie chance de Légendaire.',
      odds: { commun: 0, rare: 62, epique: 31, legendaire: 7 },
      crateCost: { dust: 5000, crystal: 1500, energy: 500 }, keyCost: { gem: 60 }, keyShards: 80
    },
    singularity: {
      id: 'singularity', name: 'Caisse de Singularité', keyName: 'Clé de Singularité', color: 0xffd166, hex: '#ffd166', color2: 0xa8721f,
      desc: 'Épique garanti au minimum : un Légendaire sort une fois sur quatre.',
      odds: { commun: 0, rare: 0, epique: 74, legendaire: 26 },
      crateCost: { gem: 150 }, keyCost: { gem: 160 }, keyShards: 200
    }
  };

  // Type de récompense principale (poids) — identique pour tous les paliers.
  var KIND_WEIGHTS = { skin: 42, equipment: 20, fragments: 16, resources: 17, gems: 5 };
  var KIND_ORDER = ['skin', 'equipment', 'fragments', 'resources', 'gems'];

  var FRAGMENTS = { commun: 6, rare: 14, epique: 32, legendaire: 80 };
  var GEMS = { commun: 6, rare: 15, epique: 40, legendaire: 110 };
  var BONUS_SHARDS = { commun: 2, rare: 5, epique: 12, legendaire: 30 };
  var DUP_SHARDS = { commun: 8, rare: 25, epique: 70, legendaire: 180 };      // skin déjà possédé → recyclé
  var FORGE_SKIN = { commun: 40, rare: 120, epique: 320, legendaire: 750 };    // fabriquer un skin précis
  var RESOURCE_BUNDLES = {
    commun: { dust: 1200, crystal: 300 },
    rare: { dust: 3500, crystal: 900, energy: 250 },
    epique: { dust: 9000, crystal: 2600, energy: 800, metal: 1500 },
    legendaire: { dust: 22000, crystal: 7000, energy: 2400, core: 25 }
  };

  var PITY = { epic: 10, leg: 40 };   // ouvertures max avant un Épique / un Légendaire garanti
  var HISTORY_MAX = 30;
  var MAX_STACK = 9999;
  var DAY_MS = 86400000;
  var DAILY_GIFT = { crate: 'astral', crates: 1, key: 'astral', keys: 1 };

  // Sources de butin passif (chance en %, tirée à chaque victoire / caisse de ravitaillement).
  var DROPS = {
    combat: { base: 14, perStar: 5, nebula: 3 },   // % de trouver une caisse OU une clé Astrale (moitié-moitié)
    pod: { chance: 12 }
  };

  // ---------- Aléatoire ----------
  function pickWeighted(weights, order, rng) {
    var total = 0, i;
    for (i = 0; i < order.length; i++) total += Math.max(0, weights[order[i]] || 0);
    if (total <= 0) return order[0];
    var r = (rng ? rng() : Math.random()) * total, acc = 0;
    for (i = 0; i < order.length; i++) {
      acc += Math.max(0, weights[order[i]] || 0);
      if (r < acc) return order[i];
    }
    return order[order.length - 1];
  }

  function rarityIndex(r) { return RARITY_ORDER.indexOf(r); }

  /**
   * Tire l'issue d'une ouverture (pur) : { rarity, kind, pity } — `pity` = compteurs APRÈS tirage.
   * La pitié relève la rareté minimale (Épique tous les 10, Légendaire tous les 40) sans jamais la baisser.
   */
  function rollOutcome(tier, pity, rng) {
    var c = CRATES[tier];
    if (!c) return null;
    pity = normalizePity(pity);
    var rarity = pickWeighted(c.odds, RARITY_ORDER, rng);
    if (pity.leg >= PITY.leg - 1) rarity = 'legendaire';
    else if (pity.epic >= PITY.epic - 1 && rarityIndex(rarity) < 2) rarity = 'epique';
    var kind = pickWeighted(KIND_WEIGHTS, KIND_ORDER, rng);
    var np = { epic: pity.epic + 1, leg: pity.leg + 1 };
    if (rarityIndex(rarity) >= 2) np.epic = 0;
    if (rarity === 'legendaire') np.leg = 0;
    return { rarity: rarity, kind: kind, pity: np, pityTriggered: (pity.leg >= PITY.leg - 1 && rarity === 'legendaire') || (pity.epic >= PITY.epic - 1 && rarity === 'epique') };
  }

  /** Skins pouvant sortir / être forgés : exclusivités des Caisses + skins vendus en Boutique (pas les exclusivités du Pass). */
  function skinPool(rarity) {
    return NEBUSTION.Skins.SKINS.filter(function (s) { return s.rarity === rarity && (s.crate || !s.exclusive); });
  }

  /** Choisit un skin de la rareté donnée, en favorisant nettement ceux qui ne sont pas encore possédés. */
  function pickSkin(rarity, owned, rng) {
    var pool = skinPool(rarity);
    if (!pool.length) return null;
    var fresh = pool.filter(function (s) { return !(owned && owned[s.id]); });
    var r = rng ? rng() : Math.random();
    var list = (fresh.length && r < 0.92) ? fresh : pool;
    return list[Math.min(list.length - 1, Math.floor((rng ? rng() : Math.random()) * list.length))];
  }

  function chances(tier) {
    var c = CRATES[tier];
    return RARITY_ORDER.map(function (r) { return { rarity: r, pct: c.odds[r] || 0 }; }).filter(function (o) { return o.pct > 0; });
  }

  function forgeSkinCost(skinId) {
    var s = NEBUSTION.Skins.get(skinId);
    if (!s || !(s.crate || !s.exclusive)) return null;
    return FORGE_SKIN[s.rarity];
  }

  // ---------- État de sauvegarde ----------
  function normalizePity(p) {
    var o = { epic: 0, leg: 0 };
    if (p && typeof p === 'object') {
      o.epic = Math.max(0, Math.min(PITY.epic - 1, Math.floor(Number(p.epic) || 0)));
      o.leg = Math.max(0, Math.min(PITY.leg - 1, Math.floor(Number(p.leg) || 0)));
    }
    return o;
  }

  function defaultState() {
    var s = { crates: {}, keys: {}, shards: 0, pity: { epic: 0, leg: 0 }, opened: 0, lastDaily: -1, history: [] };
    TIERS.forEach(function (t) { s.crates[t] = 0; s.keys[t] = 0; });
    return s;
  }

  function clampInt(v) { v = Math.floor(Number(v)); return (isFinite(v) && v > 0) ? Math.min(MAX_STACK, v) : 0; }

  function normalizeState(raw) {
    var s = defaultState();
    if (!raw || typeof raw !== 'object') return s;
    TIERS.forEach(function (t) {
      s.crates[t] = clampInt(raw.crates && raw.crates[t]);
      s.keys[t] = clampInt(raw.keys && raw.keys[t]);
    });
    s.shards = Math.min(9999999, clampInt(raw.shards));
    s.pity = normalizePity(raw.pity);
    s.opened = Math.min(99999999, clampInt(raw.opened));
    s.lastDaily = Number.isFinite(Number(raw.lastDaily)) ? Math.floor(Number(raw.lastDaily)) : -1;
    if (Array.isArray(raw.history)) {
      raw.history.slice(0, HISTORY_MAX).forEach(function (h) {
        if (!h || typeof h !== 'object' || TIERS.indexOf(h.tier) < 0 || RARITY_ORDER.indexOf(h.rarity) < 0) return;
        s.history.push({ t: Math.floor(Number(h.t)) || 0, tier: h.tier, rarity: h.rarity, kind: String(h.kind || '').slice(0, 16), label: String(h.label || '').slice(0, 60), dup: !!h.dup });
      });
    }
    return s;
  }

  function dayIndex(now) { return Math.floor((Number(now) || Date.now()) / DAY_MS); }

  return {
    SHARD: SHARD, TIERS: TIERS, CRATES: CRATES, RARITY_ORDER: RARITY_ORDER, RARITY_NAMES: RARITY_NAMES,
    KIND_WEIGHTS: KIND_WEIGHTS, FRAGMENTS: FRAGMENTS, GEMS: GEMS, BONUS_SHARDS: BONUS_SHARDS, DUP_SHARDS: DUP_SHARDS,
    FORGE_SKIN: FORGE_SKIN, RESOURCE_BUNDLES: RESOURCE_BUNDLES, PITY: PITY, HISTORY_MAX: HISTORY_MAX,
    DAILY_GIFT: DAILY_GIFT, DROPS: DROPS, MAX_STACK: MAX_STACK,
    rollOutcome: rollOutcome, skinPool: skinPool, pickSkin: pickSkin, chances: chances, forgeSkinCost: forgeSkinCost,
    pickWeighted: pickWeighted, defaultState: defaultState, normalizeState: normalizeState, normalizePity: normalizePity, dayIndex: dayIndex
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.Crates; }
