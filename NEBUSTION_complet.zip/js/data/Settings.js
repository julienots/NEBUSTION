/**
 * NEBUSTION - Settings
 * Petit magasin de préférences persisté (localStorage) : musique de fond
 * (on/off + volume) et sons/bruitages (on/off). Pas de dépendance à Phaser,
 * chargé très tôt (avant ExtraUIAudio.js et BackgroundMusic.js).
 */
window.NEBUSTION = window.NEBUSTION || {};

(function () {
  'use strict';
  var KEY = 'nebustion_settings_v1';
  var DEFAULTS = { musicOn: true, musicVolume: 0.045, sfxOn: true, sfxVolume: 0.16, vibrationOn: true, reducedFX: false, batterySaver: false };
  var state, listeners = [];

  function load() {
    try {
      var raw = localStorage.getItem(KEY);
      var parsed = raw ? JSON.parse(raw) : {};
      state = Object.assign({}, DEFAULTS, parsed && typeof parsed === 'object' ? parsed : {});
    } catch (_) { state = Object.assign({}, DEFAULTS); }
  }
  function persist() {
    try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (_) {}
  }
  function emit() {
    listeners.forEach(function (fn) { try { fn(state); } catch (_) {} });
  }

  load();

  window.NEBUSTION.Settings = {
    get: function () { return state; },
    set: function (patch) {
      state = Object.assign({}, state, patch || {});
      persist();
      emit();
    },
    onChange: function (fn) {
      listeners.push(fn);
      return function () { listeners = listeners.filter(function (f) { return f !== fn; }); };
    },
    reset: function () { state = Object.assign({}, DEFAULTS); persist(); emit(); }
  };
})();
