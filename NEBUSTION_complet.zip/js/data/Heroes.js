/**
 * NEBUSTION - Heroes
 * Données et formules du système de héros. AUCUNE dépendance à Phaser :
 * ce fichier est du JavaScript pur (testable sous Node, comme Economy.js).
 *
 * Structure pensée pour être étendue sans rien casser :
 *  - Pour AJOUTER un héros : ajouter un objet à HERO_LIST (voir gabarit en bas de fichier).
 *  - Pour AJOUTER une rareté ou un rôle : ajouter une entrée dans RARITIES / ROLES.
 *  - Les statistiques affichées à un niveau donné (statsAtLevel) et la Puissance
 *    (computePower) sont calculées à partir des stats de base : aucune donnée à
 *    dupliquer quand le futur système d'amélioration / équipement sera ajouté.
 *  - Chaque héros porte une identité visuelle (visual: silhouette + accessoire + couleurs)
 *    utilisée par HeroTextures.js pour générer un portrait temporaire distinct,
 *    remplaçable par une vraie illustration sans toucher au code (voir portraitFile()).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Heroes = (function () {
  'use strict';

  // ---------- Raretés (ordre croissant de puissance) ----------
  var RARITY_ORDER = ['commun', 'rare', 'epique', 'legendaire', 'mythique', 'celeste'];

  var RARITIES = {
    commun:     { id: 'commun',     name: 'Commun',     order: 1, stars: 1, color: 0x9aa5c0, hex: '#9aa5c0', mult: 1.00, dropWeight: 45.0 },
    rare:       { id: 'rare',       name: 'Rare',       order: 2, stars: 2, color: 0x4fd1ff, hex: '#4fd1ff', mult: 1.18, dropWeight: 30.0 },
    epique:     { id: 'epique',     name: 'Épique',     order: 3, stars: 3, color: 0xb47bff, hex: '#b47bff', mult: 1.40, dropWeight: 15.0 },
    legendaire: { id: 'legendaire', name: 'Légendaire', order: 4, stars: 4, color: 0xffd166, hex: '#ffd166', mult: 1.68, dropWeight: 7.0 },
    mythique:   { id: 'mythique',   name: 'Mythique',   order: 5, stars: 5, color: 0xff4d5e, hex: '#ff4d5e', mult: 2.00, dropWeight: 2.6 },
    // Rareté la plus haute, au-dessus de Mythique. Aucun héros de base n'est obligé d'y être :
    // elle sert de palier final pour les futures invocations et éveils.
    celeste:    { id: 'celeste',    name: 'Céleste',    order: 6, stars: 6, color: 0xeafcff, hex: '#eafcff', mult: 2.40, dropWeight: 0.4, glow: '#ffd166' }
  };

  // ---------- Rôles ----------
  var ROLES = {
    assassin: { id: 'assassin', name: 'Assassin', desc: 'Dégâts critiques',    icon: 'assassin', color: 0xff4d5e },
    tank:     { id: 'tank',     name: 'Tank',      desc: 'Protection',         icon: 'tank',     color: 0x4fd1ff },
    healer:   { id: 'healer',   name: 'Soigneur',  desc: 'Soutien',            icon: 'healer',   color: 0xffffff },
    damage:   { id: 'damage',   name: 'Dégâts',    desc: 'Attaque puissante',  icon: 'damage',   color: 0xff8a3d },
    sniper:   { id: 'sniper',   name: 'Sniper',    desc: 'Dégâts à distance',  icon: 'sniper',   color: 0x4fd1ff },
    control:  { id: 'control',  name: 'Contrôle',  desc: 'Étourdissement',     icon: 'control',  color: 0xb47bff },
    support:  { id: 'support',  name: 'Support',   desc: 'Buffs / soins',      icon: 'support',  color: 0xffd166 },
    dps:      { id: 'dps',      name: 'DPS',       desc: 'Polyvalent',         icon: 'dps',      color: 0x4fe3ff },
    god:      { id: 'god',      name: 'Dieu',      desc: 'Puissance cosmique', icon: 'god',      color: 0xffd166 }
  };

  /**
   * Liste des héros. Stats données au NIVEAU 1 (voir statsAtLevel pour la montée en niveau).
   * "visual" décrit une identité graphique réellement différente (silhouette + accessoire +
   * couleurs), utilisée pour générer un portrait temporaire propre à chaque héros.
   * "skills" contient déjà les 3 emplacements attendus par le futur système de combat
   * (passive / active / ultimate), avec cooldown ou coût d'énergie et une cible logique.
   */
  var HERO_LIST = [
    {
      id: 'zyra', name: 'Zyra', title: 'La vitesse est ma plus grande arme.',
      role: 'assassin', rarity: 'legendaire', affinity: 'ombre',
      base: { hp: 760, atk: 172, def: 62, spd: 132 },
      visual: { body: 'slim', prop: 'dual_blades', accent: '#c86bff', accent2: '#241238' },
      skills: {
        passive: { name: 'Lame fantôme', target: 'self', desc: '+15 % de chances de coup critique. Un coup critique réduit le temps de recharge de la compétence active de 1 s.' },
        active: { name: 'Danse des ombres', target: 'enemy', cooldown: 8, desc: 'Se téléporte derrière la cible et porte 3 coups rapides infligeant des dégâts physiques.' },
        ultimate: { name: 'Éclipse totale', target: 'allEnemies', cost: 100, desc: 'Devient invisible 2 s puis frappe toutes les cibles proches avec des dégâts critiques garantis.' }
      }
    },
    {
      id: 'korvax', name: 'Korvax', title: 'Je protège ce qui compte.',
      role: 'tank', rarity: 'mythique', affinity: 'techno',
      base: { hp: 1450, atk: 98, def: 168, spd: 68 },
      visual: { body: 'bulky', prop: 'shield', accent: '#4fd1ff', accent2: '#0e2a44' },
      skills: {
        passive: { name: 'Plaque renforcée', target: 'self', desc: 'Réduit les dégâts subis de 12 % tant que les PV sont au-dessus de 50 %.' },
        active: { name: 'Mur d\'énergie', target: 'self', cooldown: 10, desc: 'Déploie un bouclier absorbant les dégâts pendant 4 s et provoque les ennemis proches.' },
        ultimate: { name: 'Impact sismique', target: 'allEnemies', cost: 100, desc: 'Frappe le sol : étourdit les ennemis proches et regagne 20 % de ses PV max.' }
      }
    },
    {
      id: 'lumina', name: 'Lumina', title: 'La lumière guérit toutes les blessures.',
      role: 'healer', rarity: 'epique', affinity: 'lumiere',
      base: { hp: 640, atk: 78, def: 70, spd: 96 },
      visual: { body: 'robed', prop: 'staff_orb', accent: '#ffe9a8', accent2: '#3a2c0f' },
      skills: {
        passive: { name: 'Aura bienveillante', target: 'allAllies', desc: 'Régénère 1 % des PV max de chaque allié à chaque tour.' },
        active: { name: 'Bénédiction', target: 'ally', cooldown: 6, desc: 'Soigne un allié et lui accorde un bouclier léger pendant 3 s.' },
        ultimate: { name: 'Sanctuaire de lumière', target: 'allAllies', cost: 100, desc: 'Soigne fortement toute l\'équipe et purge un effet négatif sur chacun.' }
      }
    },
    {
      id: 'drakor', name: 'Drakor', title: 'La force est une forme de sagesse.',
      role: 'damage', rarity: 'legendaire', affinity: 'feu',
      base: { hp: 880, atk: 188, def: 92, spd: 84 },
      visual: { body: 'winged', wingStyle: 'dragon', prop: 'claws_mane', accent: '#ff5a4d', accent2: '#2a0d0a' },
      skills: {
        passive: { name: 'Écailles ardentes', target: 'self', desc: 'Renvoie 8 % des dégâts physiques subis sous forme de dégâts de feu.' },
        active: { name: 'Griffe draconique', target: 'enemy', cooldown: 7, desc: 'Lacère la cible pour des dégâts physiques élevés et applique un saignement (3 s).' },
        ultimate: { name: 'Souffle du dragon', target: 'zone', cost: 100, desc: 'Crache un cône de flammes infligeant de lourds dégâts à toutes les cibles touchées.' }
      }
    },
    {
      id: 'selene', name: 'Selene', title: 'Chaque tir a un but.',
      role: 'sniper', rarity: 'epique', affinity: 'glace',
      base: { hp: 560, atk: 148, def: 58, spd: 100 },
      visual: { body: 'armored_soldier', prop: 'rifle', accent: '#8fd8ff', accent2: '#0b2038' },
      skills: {
        passive: { name: 'Œil de lune', target: 'self', desc: 'Les dégâts augmentent de 20 % contre les cibles isolées, loin de leurs alliés.' },
        active: { name: 'Tir perforant', target: 'enemy', cooldown: 6, desc: 'Tire un projectile qui traverse la cible et touche l\'ennemi juste derrière elle.' },
        ultimate: { name: 'Pluie stellaire', target: 'allEnemies', cost: 100, desc: 'Fait pleuvoir des tirs de précision sur tous les ennemis pendant 3 s.' }
      }
    },
    {
      id: 'vortex', name: 'Vortex', title: 'Le chaos est ma force.',
      role: 'damage', rarity: 'mythique', affinity: 'foudre',
      base: { hp: 720, atk: 176, def: 66, spd: 152 },
      visual: { body: 'slim', prop: 'dual_blades', accent: '#ff4d4d', accent2: '#2a0808' },
      skills: {
        passive: { name: 'Surcharge', target: 'self', desc: 'Chaque attaque augmente la vitesse de 3 % (cumulable 5 fois, remis à zéro hors combat).' },
        active: { name: 'Tourbillon écarlate', target: 'allEnemies', cooldown: 7, desc: 'Tournoie en frappant tous les ennemis proches à grande vitesse.' },
        ultimate: { name: 'Rupture temporelle', target: 'self', cost: 100, desc: 'Double sa vitesse et ses dégâts pendant 4 s.' }
      }
    },
    {
      id: 'nyx', name: 'Nyx', title: 'Le silence est une arme.',
      role: 'control', rarity: 'epique', affinity: 'poison',
      base: { hp: 600, atk: 112, def: 60, spd: 110 },
      visual: { body: 'slim', prop: 'orbiting_orbs', accent: '#9cff8a', accent2: '#22143a' },
      skills: {
        passive: { name: 'Voile toxique', target: 'self', desc: 'Les attaques appliquent un poison léger qui réduit la vitesse de la cible de 5 %.' },
        active: { name: 'Piège spectral', target: 'enemy', cooldown: 9, desc: 'Étourdit une cible pendant 1,5 s et lui inflige des dégâts magiques.' },
        ultimate: { name: 'Nuit sans fin', target: 'allEnemies', cost: 100, desc: 'Plonge la zone dans l\'obscurité : réduit la précision de tous les ennemis pendant 4 s.' }
      }
    },
    {
      id: 'rexar', name: 'Rexar', title: 'La loyauté est ma force.',
      role: 'tank', rarity: 'legendaire', affinity: 'nature',
      base: { hp: 1180, atk: 104, def: 138, spd: 78 },
      visual: { body: 'bulky', prop: 'claws_mane', accent: '#ffb347', accent2: '#332008' },
      skills: {
        passive: { name: 'Cœur du clan', target: 'allAllies', desc: 'Tant qu\'il est en vie, les alliés proches regagnent 0,5 % de leurs PV max par tour.' },
        active: { name: 'Rugissement', target: 'self', cooldown: 8, desc: 'Augmente sa défense de 25 % pendant 4 s et attire l\'attention des ennemis proches.' },
        ultimate: { name: 'Fureur du lion', target: 'self', cost: 100, desc: 'Augmente fortement son attaque et sa défense pendant 5 s.' }
      }
    },
    {
      id: 'vega', name: 'Vega', title: 'Ensemble, on va plus loin.',
      role: 'support', rarity: 'epique', affinity: 'techno',
      base: { hp: 620, atk: 84, def: 66, spd: 102 },
      visual: { body: 'armored_soldier', prop: 'hologram_cards', accent: '#ffcf6b', accent2: '#2c2004' },
      skills: {
        passive: { name: 'Optimisation', target: 'allAllies', desc: 'Augmente en permanence la vitesse de toute l\'équipe de 4 %.' },
        active: { name: 'Protocole de soutien', target: 'ally', cooldown: 6, desc: 'Augmente l\'attaque et la défense d\'un allié pendant 4 s.' },
        ultimate: { name: 'Réseau tactique', target: 'allAllies', cost: 100, desc: 'Accorde à toute l\'équipe une action supplémentaire immédiate.' }
      }
    },
    {
      id: 'orion', name: 'Orion', title: 'L\'univers est ma toile.',
      role: 'damage', rarity: 'mythique', affinity: 'cosmique',
      base: { hp: 700, atk: 196, def: 70, spd: 96 },
      visual: { body: 'robed', prop: 'orbiting_orbs', accent: '#b98bff', accent2: '#170a2e' },
      skills: {
        passive: { name: 'Vide stellaire', target: 'self', desc: 'Les dégâts magiques ignorent 10 % de la défense de la cible.' },
        active: { name: 'Trou noir', target: 'zone', cooldown: 8, desc: 'Attire les ennemis proches vers un point et leur inflige des dégâts magiques.' },
        ultimate: { name: 'Naissance d\'étoile', target: 'allEnemies', cost: 100, desc: 'Fait exploser une étoile miniature infligeant de très lourds dégâts magiques en zone.' }
      }
    },
    {
      id: 'kael', name: 'Kael', title: 'Toujours un pas en avant.',
      role: 'dps', rarity: 'epique', affinity: 'neutre',
      base: { hp: 660, atk: 128, def: 76, spd: 98 },
      visual: { body: 'armored_soldier', prop: 'rifle', accent: '#5fb3ff', accent2: '#0c2036' },
      skills: {
        passive: { name: 'Adaptation', target: 'self', desc: 'Gagne 2 % de dégâts par ennemi restant en vie sur le terrain.' },
        active: { name: 'Rafale ciblée', target: 'enemy', cooldown: 5, desc: 'Tire une rafale de munitions infligeant des dégâts physiques répétés.' },
        ultimate: { name: 'Tir de barrage', target: 'allEnemies', cost: 100, desc: 'Arrose la zone de tirs, infligeant des dégâts modérés à tous les ennemis.' }
      }
    },
    {
      id: 'soraya', name: 'Soraya', title: 'La chaleur de mon cœur détruit mes ennemis.',
      role: 'damage', rarity: 'legendaire', affinity: 'feu',
      base: { hp: 740, atk: 168, def: 68, spd: 90 },
      visual: { body: 'slim', prop: 'fire_hands', accent: '#ff8a3d', accent2: '#2e1204' },
      skills: {
        passive: { name: 'Combustion', target: 'self', desc: 'Les dégâts contre une cible déjà brûlée sont augmentés de 15 %.' },
        active: { name: 'Vague de flammes', target: 'zone', cooldown: 7, desc: 'Envoie une vague de feu qui brûle tous les ennemis touchés pendant 3 s.' },
        ultimate: { name: 'Tempête ardente', target: 'allEnemies', cost: 100, desc: 'Embrase toute la zone de combat, infligeant des dégâts continus pendant 4 s.' }
      }
    },
    {
      id: 'targon', name: 'Targon', title: 'Personne ne passe.',
      role: 'tank', rarity: 'mythique', affinity: 'techno',
      base: { hp: 1620, atk: 92, def: 182, spd: 60 },
      visual: { body: 'bulky', prop: 'hammer', accent: '#5fb3ff', accent2: '#0c1c30' },
      skills: {
        passive: { name: 'Rempart', target: 'self', desc: 'Ne peut pas être déplacé ni étourdi tant que ses PV sont au-dessus de 30 %.' },
        active: { name: 'Provocation', target: 'allEnemies', cooldown: 9, desc: 'Force tous les ennemis proches à l\'attaquer pendant 3 s et augmente sa défense.' },
        ultimate: { name: 'Coup de masse', target: 'enemy', cost: 100, desc: 'Assène un coup dévastateur qui étourdit la cible et l\'envoie en arrière.' }
      }
    },
    {
      id: 'elys', name: 'Elys', title: 'Je vois tout, tu ne me vois pas.',
      role: 'assassin', rarity: 'epique', affinity: 'glace',
      base: { hp: 580, atk: 138, def: 52, spd: 124 },
      visual: { body: 'winged', wingStyle: 'ice', prop: 'dual_blades', accent: '#a8f0ff', accent2: '#0a2230' },
      skills: {
        passive: { name: 'Pas silencieux', target: 'self', desc: 'Le premier coup porté en combat inflige toujours un coup critique.' },
        active: { name: 'Lame de givre', target: 'enemy', cooldown: 6, desc: 'Frappe la cible et ralentit sa vitesse de 15 % pendant 3 s.' },
        ultimate: { name: 'Vol glacial', target: 'enemy', cost: 100, desc: 'Fond sur la cible avec une série de coups gelants infligeant de très lourds dégâts.' }
      }
    },
    {
      id: 'xanor', name: 'Xanor', title: 'L\'équilibre est la clé de tout.',
      role: 'support', rarity: 'legendaire', affinity: 'lumiere',
      base: { hp: 820, atk: 90, def: 88, spd: 94 },
      visual: { body: 'robed', prop: 'staff_orb', accent: '#ffe27a', accent2: '#2f2404' },
      skills: {
        passive: { name: 'Halo protecteur', target: 'allAllies', desc: 'Réduit de 5 % les dégâts subis par toute l\'équipe.' },
        active: { name: 'Soin de zone', target: 'allAllies', cooldown: 7, desc: 'Soigne tous les alliés proches d\'une quantité modérée.' },
        ultimate: { name: 'Convergence', target: 'allAllies', cost: 100, desc: 'Rétablit une grande quantité de PV à toute l\'équipe et purge les effets négatifs.' }
      }
    },
    // 16e héros : démontre la rareté la plus haute (Céleste), au-delà de Mythique.
    {
      id: 'aeon', name: 'Aeon', title: 'Le temps s\'incline devant l\'éternité.',
      role: 'support', rarity: 'celeste', affinity: 'cosmique',
      base: { hp: 1100, atk: 150, def: 130, spd: 108 },
      visual: { body: 'robed', prop: 'staff_orb', accent: '#eafcff', accent2: '#20303a', wingStyle: 'ice' },
      skills: {
        passive: { name: 'Éternité', target: 'allAllies', desc: 'Une fois par combat, ramène un allié tombé au combat avec 30 % de ses PV.' },
        active: { name: 'Distorsion temporelle', target: 'ally', cooldown: 8, desc: 'Accorde à un allié une action immédiate supplémentaire.' },
        ultimate: { name: 'Convergence des astres', target: 'allAllies', cost: 100, desc: 'Soigne, purge et accélère toute l\'équipe pendant 4 s.' }
      }
    },
    // ---------- Étape 9 : 8 nouveaux héros, EXCLUSIVITÉS BOUTIQUE (onglet Héros → « Recruter ») ----------
    // `shop.cost` = prix de recrutement (Prismes). Tant qu'un héros n'est pas recruté, il n'est pas
    // sélectionnable en combat (voir CombatManager.isUnlocked) ; ses fragments ne peuvent pas être achetés.
    {
      id: 'velmora', name: 'Velmora', title: 'Son aura restaure même les âmes brisées.',
      role: 'healer', rarity: 'legendaire', affinity: 'lumiere',
      base: { hp: 810, atk: 92, def: 86, spd: 99 },
      shop: { cost: { gem: 380 } },
      visual: { body: 'winged', wingStyle: 'ice', prop: 'staff_orb', accent: '#ffd98a', accent2: '#3a2c0f' },
      skills: {
        passive: { name: 'Aura de renaissance', target: 'allAllies', desc: 'Régénère 1,2 % des PV max de chaque allié à chaque tour.' },
        active: { name: 'Souffle des anges', target: 'ally', cooldown: 6, desc: 'Soigne fortement l\'allié le plus blessé et le purge des effets négatifs.' },
        ultimate: { name: 'Sanctuaire ailé', target: 'allAllies', cost: 100, desc: 'Soigne toute l\'équipe et l\'enveloppe d\'un bouclier lumineux pendant 4 s.' }
      }
    },
    {
      id: 'zephyrax', name: 'Zephyrax', title: 'Il apparaît dans l\'ombre, mais jamais dans le même endroit.',
      role: 'assassin', rarity: 'epique', affinity: 'foudre',
      base: { hp: 620, atk: 152, def: 54, spd: 130 },
      shop: { cost: { gem: 220 } },
      visual: { body: 'slim', prop: 'dual_blades', accent: '#b45cff', accent2: '#180a2e' },
      skills: {
        passive: { name: 'Furtivité', target: 'self', desc: 'Le premier coup est toujours critique ; +10 % de chances de coup critique.' },
        active: { name: 'Frappe foudroyante', target: 'enemy', cooldown: 7, desc: 'Surgit et frappe deux fois la cible avec des dégâts critiques garantis.' },
        ultimate: { name: 'Tempête d\'ombres', target: 'allEnemies', cost: 100, desc: 'Frappe tous les ennemis (critique garanti) et gagne 40 % de vitesse pendant 4 s.' }
      }
    },
    {
      id: 'drakathor', name: 'Drakathor', title: 'La rage du dragon ne connaît pas de limite.',
      role: 'damage', rarity: 'mythique', affinity: 'feu',
      base: { hp: 950, atk: 208, def: 96, spd: 92 },
      shop: { cost: { gem: 560 } },
      visual: { body: 'winged', wingStyle: 'dragon', prop: 'claws_mane', accent: '#ff5a2a', accent2: '#2a0806' },
      skills: {
        passive: { name: 'Sang de dragon', target: 'self', desc: 'Renvoie 10 % des dégâts subis à l\'attaquant.' },
        active: { name: 'Souffle de lave', target: 'enemy', cooldown: 8, desc: 'Frappe la cible avec une force dévastatrice et l\'enflamme pendant 3 s.' },
        ultimate: { name: 'Fureur ancestrale', target: 'allEnemies', cost: 100, desc: 'Déchaîne un brasier sur tous les ennemis : dégâts massifs et brûlure.' }
      }
    },
    {
      id: 'selenia', name: 'Sélénia', title: 'Elle vise l\'impossible.',
      role: 'sniper', rarity: 'epique', affinity: 'cosmique',
      base: { hp: 570, atk: 156, def: 56, spd: 104 },
      shop: { cost: { gem: 220 } },
      visual: { body: 'armored_soldier', prop: 'rifle', accent: '#6fa8ff', accent2: '#08142e' },
      skills: {
        passive: { name: 'Œil de la lune', target: 'self', desc: '+22 % de dégâts contre une cible isolée.' },
        active: { name: 'Flèche perçante', target: 'enemy', cooldown: 7, desc: 'Transperce la cible puis touche l\'ennemi situé derrière elle.' },
        ultimate: { name: 'Tir lunaire', target: 'enemy', cost: 100, desc: 'Un tir parfait qui inflige des dégâts critiques garantis, puis frappe l\'ennemi voisin.' }
      }
    },
    {
      id: 'krakenis', name: 'Krakenis', title: 'Il contrôle les océans... et les champs de bataille.',
      role: 'tank', rarity: 'legendaire', affinity: 'glace',
      base: { hp: 1240, atk: 106, def: 142, spd: 76 },
      shop: { cost: { gem: 380 } },
      visual: { body: 'bulky', prop: 'shield', accent: '#3fb8ff', accent2: '#062038' },
      skills: {
        passive: { name: 'Carapace des abysses', target: 'self', desc: 'Réduit les dégâts subis de 14 % tant que les PV sont au-dessus de 50 %.' },
        active: { name: 'Mur d\'eau', target: 'self', cooldown: 9, desc: 'Se couvre d\'un bouclier d\'eau pendant 4 s et provoque les ennemis proches.' },
        ultimate: { name: 'Raz-de-marée', target: 'allEnemies', cost: 100, desc: 'Une vague frappe et ralentit tous les ennemis ; regagne 15 % de ses PV max.' }
      }
    },
    {
      id: 'nythera', name: 'Nythera', title: 'Là où elle passe, tout brûle.',
      role: 'damage', rarity: 'mythique', affinity: 'feu',
      base: { hp: 780, atk: 194, def: 72, spd: 118 },
      shop: { cost: { gem: 560 } },
      visual: { body: 'winged', wingStyle: 'dragon', prop: 'fire_hands', accent: '#ff3b3b', accent2: '#2a0606' },
      skills: {
        passive: { name: 'Chemin de flammes', target: 'self', desc: '+20 % de dégâts contre les ennemis en feu.' },
        active: { name: 'Sillage ardent', target: 'allEnemies', cooldown: 8, desc: 'Une vague de feu frappe tous les ennemis et les enflamme pendant 3 s.' },
        ultimate: { name: 'Nova infernale', target: 'allEnemies', cost: 100, desc: 'Une explosion embrase tout le champ de bataille : dégâts et brûlure intense.' }
      }
    },
    {
      id: 'arcanis', name: 'Arcanis', title: 'La magie est sa plus grande arme.',
      role: 'control', rarity: 'epique', affinity: 'ombre',
      base: { hp: 610, atk: 118, def: 62, spd: 108 },
      shop: { cost: { gem: 220 } },
      visual: { body: 'robed', prop: 'orbiting_orbs', accent: '#c25cff', accent2: '#140a2e' },
      skills: {
        passive: { name: 'Sceaux runiques', target: 'self', desc: '6 % de chances de ralentir la cible à chaque attaque.' },
        active: { name: 'Sceau étourdissant', target: 'enemy', cooldown: 8, desc: 'Frappe la cible et l\'étourdit pendant 1,6 s.' },
        ultimate: { name: 'Cercles arcaniques', target: 'allEnemies', cost: 100, desc: 'Étourdit tous les ennemis 1,5 s et leur inflige des dégâts magiques.' }
      }
    },
    {
      id: 'vulkar', name: 'Vulkar', title: 'Il encaisse, régénère, et ne tombe jamais.',
      role: 'tank', rarity: 'legendaire', affinity: 'feu',
      base: { hp: 1300, atk: 100, def: 146, spd: 66 },
      shop: { cost: { gem: 380 } },
      visual: { body: 'bulky', prop: 'hammer', accent: '#ff8a2a', accent2: '#2a1004' },
      skills: {
        passive: { name: 'Cœur de magma', target: 'self', desc: 'Réduit les dégâts subis de 10 % tant que les PV sont au-dessus de 50 %.' },
        active: { name: 'Carapace en fusion', target: 'self', cooldown: 9, desc: 'Se protège d\'un bouclier, se soigne de 12 % de ses PV max et provoque les ennemis.' },
        ultimate: { name: 'Éruption', target: 'allEnemies', cost: 100, desc: 'Fait jaillir la lave : dégâts à tous, puis regagne 30 % de ses PV max.' }
      }
    },
    {
      id: 'auraxis', name: 'Auraxis', title: 'La lumière plie devant son existence.',
      role: 'tank', rarity: 'legendaire', affinity: 'lumiere',
      base: { hp: 1280, atk: 118, def: 150, spd: 74 },
      shop: { cost: { gem: 380, xon: 2 } },
      visual: { body: 'bulky', prop: 'shield', accent: '#ffd166', accent2: '#17120a', glow: '#fff3b0' },
      skills: {
        passive: { name: 'Couronne solaire', target: 'self', desc: 'Réduit les dégâts subis de 14 % tant que ses PV sont au-dessus de 50 %.' },
        active: { name: 'Égide aurale', target: 'self', cooldown: 9, desc: 'Déploie une barrière de lumière, augmente sa protection et provoque les ennemis pendant 4 s.' },
        ultimate: { name: 'Singularité lumineuse', target: 'allEnemies', cost: 100, desc: 'Libère plusieurs noyaux stellaires qui frappent tous les ennemis puis restaure une partie de ses PV.' }
      }
    },
    {
      id: 'ravnor', name: 'Ravnor', title: 'La douleur est sa seule langue.',
      role: 'dps', rarity: 'mythique', affinity: 'feu',
      base: { hp: 820, atk: 205, def: 78, spd: 112 },
      shop: { cost: { gem: 560, xon: 3 } },
      visual: { body: 'winged', wingStyle: 'dragon', prop: 'claws_mane', accent: '#ff4d4d', accent2: '#240606' },
      skills: {
        passive: { name: 'Fureur écarlate', target: 'self', desc: 'Gagne +12 % de chances de coup critique et augmente ses dégâts de 15 % contre les ennemis enflammés.' },
        active: { name: 'Ravage sanguinaire', target: 'enemy', cooldown: 7, desc: 'Porte deux frappes brutales successives et applique une brûlure pendant 3 s.' },
        ultimate: { name: 'Apocalypse rouge', target: 'allEnemies', cost: 100, desc: 'Déchaîne une explosion démoniaque qui inflige de lourds dégâts à tous les ennemis et les embrase.' }
      }
    },
    {
      id: 'kythar', name: 'Kythar', title: 'Il engloutit ce que l’univers oublie.',
      role: 'control', rarity: 'epique', affinity: 'ombre',
      base: { hp: 650, atk: 126, def: 66, spd: 108 },
      shop: { cost: { gem: 220, xon: 1 } },
      visual: { body: 'slim', prop: 'orbiting_orbs', accent: '#7d5cff', accent2: '#0b0820', glow: '#bba8ff' },
      skills: {
        passive: { name: 'Gravité oubliée', target: 'self', desc: 'Ses attaques ont 8 % de chances de ralentir la cible pendant 3 s.' },
        active: { name: 'Puits d’ombre', target: 'enemy', cooldown: 8, desc: 'Ouvre un vortex autour de la cible, inflige des dégâts et la ralentit fortement pendant 3 s.' },
        ultimate: { name: 'Nébuleuse dévorante', target: 'allEnemies', cost: 100, desc: 'Une anomalie cosmique frappe tous les ennemis et les étourdit pendant 1,5 s.' }
      }
    },
    {
      id: 'glacivor', name: 'Glacivor', title: 'Le froid façonne son royaume.',
      role: 'tank', rarity: 'legendaire', affinity: 'glace',
      base: { hp: 1360, atk: 110, def: 156, spd: 70 },
      shop: { cost: { gem: 380, xon: 2 } },
      visual: { body: 'bulky', prop: 'shield', accent: '#5bc8ff', accent2: '#071a2d', glow: '#c8f4ff' },
      skills: {
        passive: { name: 'Armure cryogénique', target: 'self', desc: 'Réduit les dégâts subis de 15 % tant que ses PV sont au-dessus de 50 %.' },
        active: { name: 'Forteresse de glace', target: 'self', cooldown: 10, desc: 'Cristallise son armure, crée un bouclier massif et provoque les ennemis pendant 4 s.' },
        ultimate: { name: 'Âge glaciaire', target: 'allEnemies', cost: 100, desc: 'Une tempête de cristaux frappe tous les ennemis, les ralentit puis renforce son propre bouclier.' }
      }
    },
    {
      id: 'nymora', name: 'Nymora', title: 'Elle soigne... pour mieux contrôler.',
      role: 'support', rarity: 'mythique', affinity: 'cosmique',
      base: { hp: 760, atk: 104, def: 82, spd: 112 },
      shop: { cost: { gem: 560, xon: 3 } },
      visual: { body: 'robed', prop: 'orbiting_orbs', accent: '#d45cff', accent2: '#170a2d', glow: '#f1b7ff' },
      skills: {
        passive: { name: 'Orbite réparatrice', target: 'allAllies', desc: 'Régénère 1,5 % des PV max de chaque allié à chaque tour.' },
        active: { name: 'Soin gravitationnel', target: 'lowestAlly', cooldown: 7, desc: 'Soigne fortement l’allié le plus faible et augmente sa vitesse pendant 4 s.' },
        ultimate: { name: 'Constellation vitale', target: 'allAllies', cost: 100, desc: 'Soigne toute l’équipe, purge les effets négatifs et déploie un bouclier protecteur.' }
      }
    },
    {
      id: 'necravion', name: 'Necravion', title: 'Il efface les mondes pour en créer de nouveaux.',
      role: 'control', rarity: 'celeste', rarityLabel: 'Divin', affinity: 'lumiere',
      base: { hp: 1850, atk: 210, def: 142, spd: 96 },
      shop: { cost: { gem: 900, xon: 5 } },
      visual: { body: 'winged', prop: 'orbiting_orbs', accent: '#fff0a8', accent2: '#16120a', glow: '#ffffff' },
      skills: {
        passive: { name: 'Annihilation', target: 'self', desc: 'Ses attaques ont 12 % de chances de désintégrer les défenses ennemies et augmentent les dégâts de contrôle de 18 %.' },
        active: { name: 'Effacement astral', target: 'allEnemies', cooldown: 9, desc: 'Déchaîne une onde cosmique qui frappe tous les ennemis et réduit leur attaque pendant 3 s.' },
        ultimate: { name: 'Création du néant', target: 'allEnemies', cost: 100, desc: 'Déchire le champ de bataille : dégâts massifs à tous les ennemis et étourdissement pendant 2 s.' }
      }
    },
    {
      id: 'symbioroth', name: 'Symbioroth', title: 'Plus il se nourrit, plus il évolue. Aucune limite.',
      role: 'dps', rarity: 'mythique', affinity: 'ombre',
      base: { hp: 1040, atk: 218, def: 94, spd: 108 },
      shop: { cost: { gem: 560, xon: 3 } },
      visual: { body: 'segmented', prop: 'claws_mane', accent: '#ff405c', accent2: '#21060b', glow: '#ff8797' },
      skills: {
        passive: { name: 'Mutation vorace', target: 'self', desc: 'Récupère 2 % de ses PV max après chaque attaque et gagne +3 % d’attaque par cumul, jusqu’à 5 cumuls.' },
        active: { name: 'Régénération mutante', target: 'self', cooldown: 8, desc: 'Se régénère fortement et augmente temporairement son attaque.' },
        ultimate: { name: 'Évolution absolue', target: 'allEnemies', cost: 100, desc: 'Libère une forme mutante gigantesque qui inflige de lourds dégâts à tous les ennemis puis restaure ses PV.' }
      }
    },
    {
      id: 'aqualith', name: 'Aqualith', title: 'L’océan lui obéit, même l’espace tombe dans ses vagues.',
      role: 'tank', rarity: 'legendaire', affinity: 'glace',
      base: { hp: 1480, atk: 124, def: 164, spd: 82 },
      shop: { cost: { gem: 380, xon: 2 } },
      visual: { body: 'serpentine', prop: 'orbiting_orbs', accent: '#45cfff', accent2: '#06233a', glow: '#b9f5ff' },
      skills: {
        passive: { name: 'Marée protectrice', target: 'self', desc: 'Réduit les dégâts subis de 15 % et ralentit de 4 % les ennemis qui l’attaquent.' },
        active: { name: 'Vague abyssale', target: 'allEnemies', cooldown: 9, desc: 'Une vague traverse toute la zone, inflige des dégâts et ralentit tous les ennemis pendant 3 s.' },
        ultimate: { name: 'Royaume des profondeurs', target: 'allEnemies', cost: 100, desc: 'Inonde le champ de bataille, inflige de lourds dégâts, étourdit les ennemis et renforce son bouclier.' }
      }
    },
    {
      id: 'umbrielle', name: 'Umbrielle', title: 'Dans l’ombre, elle n’est jamais seule.',
      role: 'assassin', rarity: 'epique', affinity: 'ombre',
      base: { hp: 680, atk: 174, def: 62, spd: 146 },
      shop: { cost: { gem: 220, xon: 1 } },
      visual: { body: 'slim', prop: 'dual_blades', accent: '#a95cff', accent2: '#170928', glow: '#e1a8ff' },
      skills: {
        passive: { name: 'Illusion parfaite', target: 'self', desc: 'Le premier coup porté à chaque combat est critique et augmente sa vitesse de 10 % pendant 3 s.' },
        active: { name: 'Dédoublement', target: 'primary', cooldown: 7, desc: 'Frappe rapidement la cible deux fois et la désoriente, réduisant sa vitesse.' },
        ultimate: { name: 'Royaume des ombres', target: 'allEnemies', cost: 100, desc: 'Crée plusieurs illusions qui frappent tous les ennemis et garantissent un coup critique.' }
      }
    },
    {
      id: 'terraxis', name: 'Terraxis', title: 'Il fait naître des montagnes à chaque pas.',
      role: 'tank', rarity: 'mythique', affinity: 'nature',
      base: { hp: 1560, atk: 132, def: 176, spd: 70 },
      shop: { cost: { gem: 560, xon: 3 } },
      visual: { body: 'bulky', prop: 'hammer', accent: '#8cff35', accent2: '#102408', glow: '#c9ff8f' },
      skills: {
        passive: { name: 'Cuirasse tectonique', target: 'self', desc: 'Réduit les dégâts subis de 18 % et augmente sa défense de 5 % après chaque attaque reçue, jusqu’à 4 cumuls.' },
        active: { name: 'Faille terrestre', target: 'allEnemies', cooldown: 9, desc: 'Soulève des blocs rocheux sous tous les ennemis et réduit leur vitesse pendant 3 s.' },
        ultimate: { name: 'Colosse planétaire', target: 'allAllies', cost: 100, desc: 'Érige une forteresse minérale qui protège toute l’équipe et inflige des dégâts aux ennemis.' }
      }
    },
    {
      id: 'stellaris', name: 'Stellaris', title: 'Il façonne les étoiles comme d’autres manient des armes.',
      role: 'control', rarity: 'legendaire', affinity: 'cosmique',
      base: { hp: 820, atk: 168, def: 78, spd: 118 },
      shop: { cost: { gem: 380, xon: 2 } },
      visual: { body: 'robed', prop: 'staff_orb', accent: '#9c7cff', accent2: '#090b25', glow: '#d7caff' },
      skills: {
        passive: { name: 'Orbite stellaire', target: 'self', desc: 'Chaque attaque applique une marque cosmique. À 3 marques, la cible est ralentie et subit 20 % de dégâts supplémentaires.' },
        active: { name: 'Météores orbitaux', target: 'allEnemies', cooldown: 8, desc: 'Fait tomber plusieurs projectiles stellaires sur tous les ennemis.' },
        ultimate: { name: 'Constellation zéro', target: 'allEnemies', cost: 100, desc: 'Aligne des étoiles autour de tous les ennemis, inflige de lourds dégâts et les étourdit.' }
      }
    },
    {
      id: 'virulom', name: 'Virulom', title: 'Tout ce qu’il touche se propage.',
      role: 'damage', rarity: 'rare', rarityLabel: 'Rare Suprême', affinity: 'poison',
      base: { hp: 720, atk: 154, def: 64, spd: 122 },
      shop: { cost: { gem: 320, xon: 1 } },
      visual: { body: 'segmented', prop: 'orbiting_orbs', accent: '#8cff31', accent2: '#0a2108', glow: '#bfff72' },
      skills: {
        passive: { name: 'Contamination', target: 'self', desc: 'Chaque attaque applique un poison. Le poison inflige 20 % de dégâts supplémentaires s’il se propage à une seconde cible.' },
        active: { name: 'Nuage infectieux', target: 'allEnemies', cooldown: 7, desc: 'Diffuse un nuage toxique qui inflige des dégâts et empoisonne tous les ennemis pendant 3 s.' },
        ultimate: { name: 'Épidémie galactique', target: 'allEnemies', cost: 100, desc: 'Une contamination massive frappe toute la zone et applique un poison renforcé pendant 4 s.' }
      }
    },
    {
      id: 'zentihar', name: 'Zentihar', title: 'Il élève ses alliés vers l’immortalité.',
      role: 'support', rarity: 'celeste', rarityLabel: 'Divin', affinity: 'lumiere',
      base: { hp: 1280, atk: 176, def: 116, spd: 104 },
      shop: { cost: { gem: 900, xon: 5 } },
      visual: { body: 'winged', prop: 'spear', accent: '#fff2b8', accent2: '#18203b', glow: '#ffffff' },
      skills: {
        passive: { name: 'Ascension', target: 'allAllies', desc: 'Augmente de 8 % l’attaque et la défense de toute l’équipe tant qu’il est vivant.' },
        active: { name: 'Lance céleste', target: 'primary', cooldown: 8, desc: 'Frappe une cible avec une attaque lumineuse et augmente l’attaque du meilleur allié pendant 4 s.' },
        ultimate: { name: 'Immortalité divine', target: 'allAllies', cost: 100, desc: 'Soigne toute l’équipe, purge les effets négatifs et accorde un puissant bonus d’attaque et de défense.' }
      }
    },
    {
      // Anciennement une « carte » de la Boutique achetable mais totalement inerte (aucun effet,
      // invisible dans l'onglet Héros/Combat) : intégrée ici comme une vraie exclusivité Boutique,
      // recrutable gratuitement et utilisable en équipe comme n'importe quel autre héros.
      id: 'outsiderz', name: 'Outsiderz', title: 'Ils ne viennent pas d\'ici, ils ne veulent pas y rester.',
      role: 'damage', rarity: 'mythique', affinity: 'poison',
      base: { hp: 760, atk: 182, def: 68, spd: 118 },
      shop: { cost: {} },
      visual: { body: 'slim', prop: 'dual_blades', accent: '#6dff9e', accent2: '#0f1f14' },
      skills: {
        passive: { name: 'Toxine instable', target: 'self', desc: '+8 % de chances de coup critique : le poison rend chaque frappe plus précise.' },
        active: { name: 'Morsure venimeuse', target: 'enemy', cooldown: 7, desc: 'Frappe la cible et l\'empoisonne pendant 3 tours : elle perd des PV à chaque tour.' },
        ultimate: { name: 'Éruption toxique', target: 'allEnemies', cost: 100, desc: 'Frappe tous les ennemis et les empoisonne pendant 3 tours.' }
      }
    },
    {
      // Dieu Supérieur, au-dessus du panthéon des héros classiques : rareté Céleste (la plus haute),
      // stats largement supérieures à tout héros Mythique. Ne se recrute PAS contre des Prismes :
      // `shop.fragmentsToUnlock` remplace `shop.cost` et indique le nombre de fragments à accumuler
      // avant que le héros ne rejoigne automatiquement la collection (voir CombatManager.isUnlocked).
      // Les paquets de fragments de la Boutique restent achetables même verrouillé, et continuent
      // ensuite à le faire monter en niveau exactement comme les autres héros.
      id: 'aetherion', name: 'Aetherion', title: 'Je ne suis pas né des étoiles... les étoiles sont nées de moi.',
      role: 'god', rarity: 'celeste', affinity: 'cosmique',
      base: { hp: 2200, atk: 232, def: 188, spd: 118 },
      shop: { fragmentsToUnlock: 240 },
      visual: { body: 'robed', prop: 'staff_orb', accent: '#ffd166', accent2: '#0a0a14', glow: '#eafcff' },
      skills: {
        passive: { name: 'Origine cosmique', target: 'self', desc: 'Régénère 2 % d\'énergie ultime à chaque tour et augmente les dégâts cosmiques infligés de 18 %.' },
        active: { name: 'Rupture stellaire', target: 'allEnemies', cooldown: 9, desc: 'Ouvre une faille cosmique : dégâts lourds à tous les ennemis et -15 % de vitesse pendant 3 s.' },
        ultimate: { name: 'Absorption cosmique', target: 'allAllies', cost: 100, desc: 'Absorbe 100 % des dégâts reçus par l\'équipe pendant 3 s, convertit 50 % en énergie et restaure tous les PV de tous les alliés.' }
      }
    }
  ];

  // ---------- Accès ----------
  // Héros créés sans code (voir tools/studio.html / tools/import.html) : fusionnés ici,
  // une seule fois, avec la liste de base — c'est ce qui les fait apparaître automatiquement
  // en Boutique / Héros / Combat sans toucher au reste du jeu.
  function fullList() {
    var custom = (window.NEBUSTION.CustomContent && NEBUSTION.CustomContent.heroes) ? NEBUSTION.CustomContent.heroes() : [];
    return custom.length ? HERO_LIST.concat(custom) : HERO_LIST;
  }
  function get(id) {
    var list = fullList();
    for (var i = 0; i < list.length; i++) { if (list[i].id === id) return list[i]; }
    return null;
  }
  function all() { return fullList().slice(); }
  function byRarity(rarityId) { return fullList().filter(function (h) { return h.rarity === rarityId; }); }
  /** Héros vendus en Boutique (recrutement payant). */
  function shopHeroes() { return fullList().filter(function (h) { return !!h.shop; }); }
  function byRole(roleId) { return fullList().filter(function (h) { return h.role === roleId; }); }

  // ---------- Puissance (calculée, jamais dupliquée à la main) ----------
  var POWER_WEIGHTS = { hp: 0.12, atk: 3.1, def: 2.6, spd: 2.2 };
  function computePower(stats) {
    var p = stats.hp * POWER_WEIGHTS.hp + stats.atk * POWER_WEIGHTS.atk +
      stats.def * POWER_WEIGHTS.def + stats.spd * POWER_WEIGHTS.spd;
    return Math.round(p);
  }

  // ---------- Montée en niveau (prête pour le futur système d'amélioration) ----------
  var MAX_LEVEL = 60;
  var LEVEL_GROWTH = 1.045; // +4.5 % de stats par niveau

  function lvl(l) { l = Math.floor(Number(l)); return (isFinite(l) && l >= 1) ? Math.min(l, MAX_LEVEL) : 1; }

  /** Statistiques d'un héros à un niveau donné, PV/ATQ/DÉF/VIT + Puissance calculée. */
  function statsAtLevel(hero, level) {
    var l = lvl(level);
    var mult = Math.pow(LEVEL_GROWTH, l - 1);
    var b = hero.base;
    var stats = {
      hp: Math.round(b.hp * mult),
      atk: Math.round(b.atk * mult),
      def: Math.round(b.def * mult),
      spd: Math.round(b.spd * mult)
    };
    stats.power = computePower(stats);
    return stats;
  }

  // ---------- Portraits (temporaires, remplaçables sans toucher au code) ----------
  // Pour utiliser une vraie illustration : déposer un fichier image nommé exactement
  // "<id_du_heros>.png" (ou .jpg) dans le dossier assets/heroes/ du projet.
  // Au chargement suivant, le jeu détecte le fichier et l'utilise automatiquement à la
  // place du portrait généré ; sans fichier, le portrait temporaire reste affiché.
  function portraitKey(id) { return 'hero_portrait_' + id; }
  function portraitFile(id) {
    var h = get(id);
    if (h && h.portrait) return h.portrait; // image envoyée par l'Atelier créateur (tools/studio.html)
    return 'assets/heroes/' + id + '.png';
  }

  return {
    RARITY_ORDER: RARITY_ORDER, RARITIES: RARITIES, ROLES: ROLES, HERO_LIST: HERO_LIST,
    get: get, all: all, byRarity: byRarity, byRole: byRole, shopHeroes: shopHeroes,
    computePower: computePower, statsAtLevel: statsAtLevel, MAX_LEVEL: MAX_LEVEL, LEVEL_GROWTH: LEVEL_GROWTH,
    portraitKey: portraitKey, portraitFile: portraitFile

    /* Gabarit pour ajouter un héros :
    {
      id: 'mon_heros', name: 'Nom', title: 'Réplique du héros.',
      role: 'damage', rarity: 'rare', affinity: 'neutre',
      base: { hp: 500, atk: 100, def: 60, spd: 95 },
      visual: { body: 'slim', prop: 'dual_blades', accent: '#ffffff', accent2: '#202020' },
      skills: {
        passive: { name: '...', target: 'self', desc: '...' },
        active: { name: '...', target: 'enemy', cooldown: 7, desc: '...' },
        ultimate: { name: '...', target: 'allEnemies', cost: 100, desc: '...' }
      }
    }
    */
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.Heroes; }
