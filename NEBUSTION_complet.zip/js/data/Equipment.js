/**
 * NEBUSTION - Equipment (données)
 * Module pur (aucune dépendance à Phaser, testable sous Node comme Heroes.js/Economy.js).
 *
 * 5 emplacements (arme / armure / module / réacteur / artefact), 4 raretés, fusion incluse.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.Equipment = (function () {
  'use strict';

  var SLOT_ORDER = ['weapon', 'armor', 'module', 'reactor', 'artifact'];
  var SLOTS = {
    weapon: { id: 'weapon', name: 'Arme', stat: 'atk', icon: 'weapon' },
    armor: { id: 'armor', name: 'Armure', stat: 'def', icon: 'armor' },
    module: { id: 'module', name: 'Module', stat: 'spd', icon: 'module' },
    reactor: { id: 'reactor', name: 'Réacteur', stat: 'hp', icon: 'reactor' },
    artifact: { id: 'artifact', name: 'Artefact', stat: 'critChance', icon: 'artifact' }
  };

  var RARITY_ORDER = ['commun', 'rare', 'epique', 'legendaire'];
  var RARITIES = {
    commun: { id: 'commun', name: 'Commun', order: 1, hex: '#9aa5c0', color: 0x9aa5c0, mult: 1.0 },
    rare: { id: 'rare', name: 'Rare', order: 2, hex: '#4fd1ff', color: 0x4fd1ff, mult: 1.5 },
    epique: { id: 'epique', name: 'Épique', order: 3, hex: '#b47bff', color: 0xb47bff, mult: 2.2 },
    legendaire: { id: 'legendaire', name: 'Légendaire', order: 4, hex: '#ffd166', color: 0xffd166, mult: 3.2 }
  };

  var MAX_LEVEL = 10;
  var LEVEL_GROWTH = 1.12; // +12 % de bonus par niveau

  // Bonus de base (niveau 1, rareté commune) par emplacement : {stat principal, +stat secondaire}
  var BASE_BONUS = {
    weapon: { atk: 14 },
    armor: { hp: 90, def: 8 },
    module: { spd: 6, critChance: 0.02 },
    reactor: { hp: 60, spd: 3 },
    artifact: { critChance: 0.035, atk: 5 }
  };
  // Correspondance {emplacement}_{stat} -> clé de réglage NEBUSTION.CustomContent.GameConfig
  // (voir tools/studio.html, onglet Réglages : ces valeurs peuvent être personnalisées sans code).
  var CONFIG_KEY = {
    weapon_atk: 'eq_bonus_weapon_atk',
    armor_hp: 'eq_bonus_armor_hp', armor_def: 'eq_bonus_armor_def',
    module_spd: 'eq_bonus_module_spd', module_critChance: 'eq_bonus_module_crit',
    reactor_hp: 'eq_bonus_reactor_hp', reactor_spd: 'eq_bonus_reactor_spd',
    artifact_critChance: 'eq_bonus_artifact_crit', artifact_atk: 'eq_bonus_artifact_atk'
  };
  var RARITY_CONFIG_KEY = { rare: 'eq_rarity_mult_rare', epique: 'eq_rarity_mult_epique', legendaire: 'eq_rarity_mult_legendaire' };

  function gameConfig() { return window.NEBUSTION.CustomContent && NEBUSTION.CustomContent.GameConfig; }
  function effBaseBonus(slot) {
    var base = BASE_BONUS[slot] || {};
    var GC = gameConfig();
    if (!GC) return base;
    var out = {};
    Object.keys(base).forEach(function (k) {
      var ck = CONFIG_KEY[slot + '_' + k];
      out[k] = (ck && GC.isOverridden(ck)) ? GC.get(ck) : base[k];
    });
    return out;
  }
  function effRarityMult(rarityId) {
    var rarity = RARITIES[rarityId] || RARITIES.commun;
    var GC = gameConfig(), ck = RARITY_CONFIG_KEY[rarityId];
    return (GC && ck && GC.isOverridden(ck)) ? GC.get(ck) : rarity.mult;
  }
  function effLevelGrowth() { var GC = gameConfig(); return (GC && GC.isOverridden('eq_level_growth')) ? GC.get('eq_level_growth') : LEVEL_GROWTH; }
  function effMaxLevel() { var GC = gameConfig(); return (GC && GC.isOverridden('eq_max_level')) ? Math.round(GC.get('eq_max_level')) : MAX_LEVEL; }

  function lvl(l) { l = Math.floor(Number(l)); var max = effMaxLevel(); return (isFinite(l) && l >= 1) ? Math.min(l, max) : 1; }

  /** Bonus de stats {hp,atk,def,spd,critChance} d'un objet donné (emplacement + rareté + niveau). */
  function bonusFor(slot, rarityId, level) {
    var base = effBaseBonus(slot);
    var mult = effRarityMult(rarityId);
    var growth = Math.pow(effLevelGrowth(), lvl(level) - 1);
    var out = {};
    Object.keys(base).forEach(function (k) {
      var v = base[k] * mult * growth;
      out[k] = (k === 'critChance') ? Math.round(v * 1000) / 1000 : Math.round(v);
    });
    return out;
  }

  /** Coût (ressources) pour améliorer un objet de son niveau actuel vers le suivant. */
  function upgradeCost(rarityId, level) {
    var rarity = RARITIES[rarityId] || RARITIES.commun;
    var l = lvl(level);
    var base = 40 * rarity.order;
    return {
      metal: Math.round(base * Math.pow(1.35, l - 1)),
      core: Math.round(base * 0.4 * Math.pow(1.35, l - 1))
    };
  }

  /** Coût pour fabriquer un objet neuf (niveau 1) d'un emplacement/rareté donnés. */
  function craftCost(slot, rarityId) {
    var rarity = RARITIES[rarityId] || RARITIES.commun;
    return { metal: 60 * rarity.order, core: 20 * rarity.order };
  }

  /** Ressources rendues au démantèlement (environ la moitié de l'investissement total). */
  function dismantleRefund(slot, rarityId, level) {
    var l = lvl(level);
    var cc = craftCost(slot, rarityId);
    var totalMetal = cc.metal, totalCore = cc.core;
    for (var i = 1; i < l; i++) {
      var uc = upgradeCost(rarityId, i);
      totalMetal += uc.metal; totalCore += uc.core;
    }
    return { metal: Math.round(totalMetal * 0.5), core: Math.round(totalCore * 0.5) };
  }

  /** Rareté suivante pour la fusion (null si déjà légendaire). */
  function nextRarity(rarityId) {
    var i = RARITY_ORDER.indexOf(rarityId);
    return (i >= 0 && i + 1 < RARITY_ORDER.length) ? RARITY_ORDER[i + 1] : null;
  }

  function itemName(slot, rarityId) {
    return RARITIES[rarityId].name + ' — ' + SLOTS[slot].name;
  }

  // ---------- Objets personnalisés (Atelier créateur, tools/studio.html, onglet Équipement) ----------
  // Un objet personnalisé n'est qu'une IDENTITÉ (nom + image) posée sur un emplacement/rareté déjà
  // existants : les bonus, coûts et niveaux restent calculés par les formules ci-dessus (équilibrage
  // inchangé). Ainsi un objet créé sans code reste toujours cohérent avec le reste du jeu.
  function customContent() { return window.NEBUSTION && window.NEBUSTION.CustomContent; }
  function template(templateId) {
    if (!templateId) return null;
    var CC = customContent();
    if (!CC || !CC.items) return null;
    var found = null;
    CC.items().forEach(function (t) { if (t.id === templateId) found = t; });
    return found;
  }
  /** Clé de texture Phaser pour l'image d'un objet personnalisé (une par modèle, réutilisée par tous les objets fabriqués depuis ce modèle). */
  function itemIconKey(templateId) { return 'eq_custom_icon_' + templateId; }
  /** Nom affiché d'un objet : celui du modèle personnalisé s'il existe, sinon le nom générique emplacement/rareté. */
  function itemDisplayName(slot, rarityId, templateId) {
    var t = template(templateId);
    return t ? t.name : itemName(slot, rarityId);
  }

  // ---------- État de sauvegarde (pur, comme Galaxy.defaultState/normalizeState) ----------
  function defaultState() {
    return { items: {}, equipped: {}, nextSeq: 1 };
  }

  function num(x, min, max, def) { x = Number(x); return isFinite(x) ? Math.min(max, Math.max(min, x)) : def; }

  function normalizeState(raw) {
    var s = defaultState();
    if (!raw || typeof raw !== 'object') return s;

    s.nextSeq = Math.max(1, num(raw.nextSeq, 1, 1e9, 1));

    var ri = raw.items || {};
    Object.keys(ri).forEach(function (uid) {
      var it = ri[uid];
      if (!it || SLOT_ORDER.indexOf(it.slot) < 0 || !RARITIES[it.rarity]) return;
      s.items[uid] = { slot: it.slot, rarity: it.rarity, level: Math.floor(num(it.level, 1, MAX_LEVEL, 1)) };
    });

    var re = raw.equipped || {};
    Object.keys(re).forEach(function (heroId) {
      var slots = re[heroId] || {};
      var clean = {};
      SLOT_ORDER.forEach(function (slotId) {
        var uid = slots[slotId];
        if (typeof uid === 'string' && s.items[uid]) clean[slotId] = uid;
      });
      if (Object.keys(clean).length) s.equipped[heroId] = clean;
    });

    return s;
  }

  return {
    SLOT_ORDER: SLOT_ORDER, SLOTS: SLOTS, RARITY_ORDER: RARITY_ORDER, RARITIES: RARITIES,
    MAX_LEVEL: MAX_LEVEL, LEVEL_GROWTH: LEVEL_GROWTH,
    bonusFor: bonusFor, upgradeCost: upgradeCost, craftCost: craftCost, dismantleRefund: dismantleRefund,
    itemName: itemName, nextRarity: nextRarity,
    template: template, itemIconKey: itemIconKey, itemDisplayName: itemDisplayName,
    defaultState: defaultState, normalizeState: normalizeState
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = NEBUSTION.Equipment; }
