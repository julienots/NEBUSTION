/**
 * NEBUSTION - ResourceNode
 * Gisement + portique d'extraction animé d'une ressource sur Nexus-01.
 * Tap = récolte manuelle (réserve de 8 charges qui se recharge). Affiche le taux de production
 * et les charges disponibles. Le niveau « Nv.x +y/s » et la flèche ▲ ouvrent le panneau d'amélioration de l'extracteur.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.ResourceNode = class ResourceNode {
  constructor(scene, fx, id, x, y) {
    this.scene = scene; this.fx = fx; this.id = id; this.x = x; this.y = y;
    var E = NEBUSTION.Economy, def = E.RES[id];
    this.def = def;
    this.SCALE = 0.85;
    var S = this.SCALE, oy = 138; // le centre du pad est à y=138 dans la texture

    var c = scene.add.container(x, y).setDepth(Math.round(y));
    this.container = c;

    this.glow = scene.add.image(0, -70 * S, 'tex_glow_' + id).setScale(3.1).setAlpha(0.35).setBlendMode(Phaser.BlendModes.ADD);
    this.gantry = scene.add.image(0, 0, 'tex_gantry').setOrigin(0.5, oy / 180).setScale(S);
    this.art = scene.add.image(0, 0, 'tex_node_' + id).setOrigin(0.5, oy / 180).setScale(S);
    this.gear = scene.add.image(0, -(oy - 30) * S, 'tex_gear').setScale(0.42).setTint(def.color);
    this.lens = scene.add.image(0, -(oy - 46) * S, 'tex_glow_' + id).setScale(0.75).setBlendMode(Phaser.BlendModes.ADD);
    this.dots = scene.add.graphics();
    this.label = scene.add.text(0, 38, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '22px', fontStyle: 'bold', color: def.hex, stroke: '#05070f', strokeThickness: 4
    }).setOrigin(0.5);
    // Flèche ▲ d'amélioration, posée à côté du niveau, côté BORD de l'écran (verte quand on peut payer).
    // Poussée vers l'extérieur (et non vers le centre) pour ne jamais passer derrière les
    // bâtiments, qui sont tous regroupés près du centre de la plateforme.
    this.side = x > scene.scale.width / 2 ? 1 : -1;
    this.upArrow = scene.add.container(this.side * 90, 38);
    this.upGfx = scene.add.graphics();
    this.upTxt = scene.add.text(0, -1, '▲', { fontFamily: 'Arial, sans-serif', fontSize: '15px', fontStyle: 'bold', color: '#9fb0d6' }).setOrigin(0.5);
    this.upArrow.add([this.upGfx, this.upTxt]);
    this._canUp = null;
    c.add([this.glow, this.gantry, this.art, this.gear, this.lens, this.dots, this.label, this.upArrow]);

    // Animations : engrenage, pulsation de la lueur, lentille
    scene.tweens.add({ targets: this.gear, angle: 360, duration: 6000, repeat: -1, ease: 'Linear' });
    scene.tweens.add({ targets: this.glow, alpha: 0.6, scale: 3.5, duration: 1400 + Math.random() * 600, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    scene.tweens.add({ targets: this.lens, alpha: 0.3, duration: 500 + Math.random() * 300, yoyo: true, repeat: -1 });
    if (id === 'energy' || id === 'core') {
      scene.tweens.add({ targets: this.art, y: -4, duration: 1800, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    }

    // Zone tactile (hors du conteneur : hit-test fiable quel que soit l'ordre de profondeur)
    this.zone = scene.add.zone(x, y - 60, 150, 190).setInteractive({ useHandCursor: true });
    this.zone.on('pointerdown', (pointer) => { scene.harvest(this, pointer); });

    // Zone tactile de l'étiquette (niveau + flèche) → panneau d'amélioration. Hors conteneur et au-dessus de la zone de récolte.
    this.upZone = scene.add.zone(x, y + 40, 250, 36).setDepth(Math.round(y) + 3).setInteractive({ useHandCursor: true });
    this.upZone.on('pointerdown', () => { if (scene.openUpgrade) scene.openUpgrade('ext_' + id); });

    this._acc = 999; this._lastLabel = ''; this._lastChargeKey = '';
  }

  /** Point du sommet du gisement (cible du laser des drones). */
  get topX() { return this.x; }
  get topY() { return this.y - 82 * this.SCALE; }
  /** Point de vol stationnaire d'un drone au-dessus du portique. */
  get hoverX() { return this.x; }
  get hoverY() { return this.y - 150; }

  pulse() {
    var s = this.scene;
    s.tweens.add({ targets: this.art, scaleX: this.SCALE * 1.07, scaleY: this.SCALE * 1.07, duration: 70, yoyo: true, ease: 'Sine.easeOut' });
    s.tweens.add({ targets: this.glow, alpha: 0.95, duration: 90, yoyo: true });
  }
  shakeDenied() {
    var s = this.scene;
    s.tweens.add({ targets: this.container, x: this.x + 6, duration: 45, yoyo: true, repeat: 2, onComplete: () => { this.container.x = this.x; } });
  }

  update(delta) {
    this._acc += delta;
    if (this._acc < 120) return;
    this._acc = 0;
    var R = NEBUSTION.Resources, E = NEBUSTION.Economy, now = Date.now();

    var full = R.isFull(this.id);
    var txt = full ? 'PLEIN' : 'Nv.' + R.extractorLevel(this.id) + '  +' + E.fmtRate(R.rate(this.id)) + '/s';
    if (txt !== this._lastLabel) {
      this.label.setText(txt); this.label.setColor(full ? '#ff8fa3' : this.def.hex);
      this._lastLabel = txt;
      // la flèche suit la largeur du texte, sans jamais sortir de l'écran
      var ax = this.side * (this.label.width / 2 + 20), sx = Math.max(20, Math.min(this.scene.scale.width - 20, this.x + ax));
      this.upArrow.x = sx - this.x;
    }
    var bid = 'ext_' + this.id, lv = R.extractorLevel(this.id);
    var can = lv < E.CFG.MAX_LEVEL && R.canAfford(E.upgradeCost(bid, lv));
    if (can !== this._canUp) {
      this._canUp = can;
      var g = this.upGfx; g.clear();
      g.fillStyle(0x0b1224, 0.95); g.fillCircle(0, 0, 15);
      if (can) { g.fillStyle(0x7dffb0, 0.22); g.fillCircle(0, 0, 21); }
      g.lineStyle(2, can ? 0x7dffb0 : this.def.color, can ? 1 : 0.5); g.strokeCircle(0, 0, 15);
      this.upTxt.setColor(can ? '#7dffb0' : '#9fb0d6');
    }
    var ch = R.charges(this.id, now), max = E.CFG.MAX_CHARGES;
    var key = Math.floor(ch * 10) + (full ? 'f' : '');
    if (key !== this._lastChargeKey) {
      this._lastChargeKey = key;
      var g = this.dots; g.clear();
      var whole = Math.floor(ch + 1e-9), frac = ch - whole, sp = 17, x0 = -((max - 1) * sp) / 2;
      for (var i = 0; i < max; i++) {
        var px = x0 + i * sp, py = 66;
        if (i < whole) { g.fillStyle(this.def.color, 1); g.fillCircle(px, py, 5.5); }
        else if (i === whole && frac > 0.02) { g.fillStyle(this.def.color, 0.25 + 0.6 * frac); g.fillCircle(px, py, 4 + 1.5 * frac); }
        else { g.lineStyle(1.5, this.def.color, 0.35); g.strokeCircle(px, py, 4.5); }
      }
    }
  }
};
