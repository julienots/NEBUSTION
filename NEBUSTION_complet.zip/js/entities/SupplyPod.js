/**
 * NEBUSTION - SupplyPod
 * Caisse de ravitaillement : tombe du ciel sur la plateforme, reste 25 s, tap = récompense
 * (2 ressources tirées au sort, proportionnelles à la production). Une seule à la fois.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.SupplyPod = class SupplyPod {
  constructor(scene, fx, x, y, onDone) {
    this.scene = scene; this.fx = fx; this.x = x; this.y = y; this.onDone = onDone;
    this.landed = false; this.done = false;
    var E = NEBUSTION.Economy;
    this.expireAt = Date.now() + 900 + E.CFG.POD_LIFETIME_SEC * 1000;

    this.shadow = scene.add.image(x, y + 34, 'tex_shadow').setAlpha(0.1).setScale(0.6).setDepth(1040);
    this.glow = scene.add.image(x, y - 10, 'tex_glow_core').setScale(3).setAlpha(0).setBlendMode(Phaser.BlendModes.ADD).setDepth(1044);
    this.img = scene.add.image(x, y - 720, 'tex_pod').setScale(0.9).setDepth(1045);
    this.timerGfx = scene.add.graphics().setDepth(1046);
    this.hint = scene.add.text(x, y - 92, 'TOUCHER', { fontFamily: 'Arial, sans-serif', fontSize: '22px', fontStyle: 'bold', color: '#ffd166', stroke: '#05070f', strokeThickness: 4 }).setOrigin(0.5).setDepth(1046).setAlpha(0);

    scene.tweens.add({ targets: this.img, y: y - 10, duration: 900, ease: 'Quad.easeIn', onComplete: () => this._land() });
    scene.tweens.add({ targets: this.shadow, alpha: 0.4, scale: 1.1, duration: 900, ease: 'Quad.easeIn' });
  }

  _land() {
    if (this.done) return;
    var s = this.scene;
    this.landed = true;
    this.fx.ring(this.x, this.y + 30, 0xffd166, 1.4);
    this.fx.burst('core', this.x, this.y + 24, 14);
    this.fx.shake(120, 0.004);
    s.tweens.add({ targets: this.img, y: this.img.y - 8, duration: 1100, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    s.tweens.add({ targets: this.glow, alpha: 0.6, duration: 700, yoyo: true, repeat: -1 });
    s.tweens.add({ targets: this.hint, alpha: 1, duration: 300 });
    this.zone = s.add.zone(this.x, this.y - 30, 130, 150).setInteractive({ useHandCursor: true }).setDepth(1047);
    this.zone.on('pointerdown', () => this._claim());
  }

  _claim() {
    if (this.done || !this.landed) return;
    var R = NEBUSTION.Resources, E = NEBUSTION.Economy, fx = this.fx, s = this.scene;
    var rewards = R.claimPod(Date.now());   // crédité UNE fois ; this.done empêche tout second appel
    this._finish(true);
    fx.ring(this.x, this.y - 30, 0xffd166, 1.6);
    fx.vibrate(30);
    var parts = [];
    rewards.forEach((r, i) => {
      if (r.amount > 0) parts.push('+' + E.fmtGain(r.amount) + ' ' + E.RES[r.id].short);
      var px = this.x, py = this.y - 40;
      s.time.delayedCall(i * 200, function () {
        fx.burst(r.id, px, py, 18);
        if (r.amount > 0) fx.gain(r.id, r.amount, px + (i ? 60 : -60), py - 20, false);
        else fx.text(px, py, 'Stockage plein', '#ff8fa3', 22, 50);
      });
    });
    fx.toast('Caisse de ravitaillement !', parts.length ? parts.join('   ') : 'Stockage plein', rewards[0] ? rewards[0].id : null);

    // Farm : petite chance additionnelle de trouver un objet d'équipement dans la caisse.
    var EM = NEBUSTION.EquipmentManager;
    if (EM) {
      var drop = EM.maybeDropFromFarm();
      if (drop) {
        var EQ = NEBUSTION.Equipment;
        s.time.delayedCall(rewards.length * 200 + 250, function () {
          fx.toast('Objet trouvé !', EQ.itemName(drop.slot, drop.rarity), null);
        });
      }
    }
  }

  update() {
    if (this.done || !this.landed) return;
    var left = this.expireAt - Date.now();
    if (left <= 0) { NEBUSTION.Resources.markPod(Date.now()); this._finish(false); return; }
    var frac = left / (NEBUSTION.Economy.CFG.POD_LIFETIME_SEC * 1000);
    var g = this.timerGfx; g.clear();
    g.lineStyle(6, 0x0b1224, 0.8); g.beginPath(); g.arc(this.x, this.y - 30, 66, 0, Math.PI * 2, false); g.strokePath();
    g.lineStyle(5, frac < 0.25 ? 0xff4d6d : 0xffd166, 0.95);
    g.beginPath(); g.arc(this.x, this.y - 30, 66, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * frac, false); g.strokePath();
  }

  _finish(claimed) {
    if (this.done) return;
    this.done = true;
    var s = this.scene, objs = [this.img, this.shadow, this.glow, this.timerGfx, this.hint];
    if (this.zone) { this.zone.destroy(); }
    s.tweens.add({
      targets: objs, alpha: 0, scale: claimed ? 1.4 : 0.6, duration: 320,
      onComplete: () => { objs.forEach(function (o) { if (o && o.destroy) o.destroy(); }); }
    });
    if (this.onDone) this.onDone(claimed);
  }

  destroy() {
    if (this.done) return; this.done = true;
    [this.img, this.shadow, this.glow, this.timerGfx, this.hint, this.zone].forEach(function (o) { if (o && o.destroy) o.destroy(); });
  }
};
