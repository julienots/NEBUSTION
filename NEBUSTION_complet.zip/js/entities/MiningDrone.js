/**
 * NEBUSTION - MiningDrone
 * Drone minier animé : décolle du Commandement, rejoint son gisement, le mine au laser
 * (étincelles, jauge de cargaison), revient déposer et affiche la cargaison livrée.
 *
 * Le drone vit dans le repère de la PLANÈTE : son trajet est un arc de grand cercle entre le dépôt
 * (au-dessus du Commandement) et son gisement, à une altitude en pixels le long de la verticale du sol.
 * Quand la planète tourne, il suit ; quand son point de survol passe derrière le globe, il disparaît
 * (opacité, ombre, étincelles et laser) exactement comme les bâtiments.
 *
 * NB : la production est créditée EN CONTINU par le ResourceManager (fiable même si l'écran
 * est fermé). Le drone illustre cette production : la cargaison affichée à la livraison =
 * (production d'un drone) × (durée du trajet). Aucun crédit n'est donc dupliqué par les drones.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.MiningDrone = class MiningDrone {
  /** depot = { lonDeg, latDeg, altPx } (au-dessus du Commandement) ; node = gisement (node.lonDeg / node.latDeg). */
  constructor(scene, fx, node, depot, slot) {
    this.scene = scene; this.fx = fx; this.node = node; this.id = node.id; this.depot = depot;
    this.def = node.def;
    this.hoverAlt = 150;

    this.state = 'wait';
    this.timer = 400 + slot * 900;     // départs décalés
    this.phase = Math.random() * 6.28;
    this.cycleStart = Date.now();
    this.mineTime = 4500;
    this.trail = 0; this.spark = 0;
    this.t = 0; this.dur = 1; this.lift = 40;
    this.deliveries = 0;
    this.pos = { x: 0, y: 0 };
    this.frame = null;
    this.fromU = MiningDrone.unit(depot.lonDeg, depot.latDeg); this.toU = this.fromU;
    this.fromAlt = depot.altPx; this.toAlt = depot.altPx;
    this.cur = { lonDeg: depot.lonDeg, latDeg: depot.latDeg, alt: depot.altPx };

    this.shadow = scene.add.image(0, 0, 'tex_shadow').setAlpha(0.3).setDepth(1);
    var c = scene.add.container(0, 0).setDepth(1050).setScale(0.8);
    this.c = c;
    this.glow = scene.add.image(0, 8, 'tex_glow_' + this.id).setScale(1.5).setAlpha(0.5).setBlendMode(Phaser.BlendModes.ADD);
    this.rotL = scene.add.image(-41, -10, 'tex_rotor');
    this.rotR = scene.add.image(41, -10, 'tex_rotor');
    this.body = scene.add.image(0, 0, 'tex_drone');
    this.light = scene.add.image(0, -4, 'tex_glow_' + this.id).setScale(0.35).setBlendMode(Phaser.BlendModes.ADD);
    this.bar = scene.add.graphics();
    c.add([this.glow, this.rotL, this.rotR, this.body, this.light, this.bar]);

    scene.tweens.add({ targets: [this.rotL, this.rotR], scaleX: 0.3, duration: 60, yoyo: true, repeat: -1 });
    scene.tweens.add({ targets: this.light, alpha: 0.3, duration: 450, yoyo: true, repeat: -1 });
    this._place(0);
  }

  // ---- Géométrie sphérique (vecteurs unitaires lon/lat en degrés) ----
  static unit(lonDeg, latDeg) {
    var lo = lonDeg * Math.PI / 180, la = latDeg * Math.PI / 180;
    return [Math.cos(la) * Math.sin(lo), Math.sin(la), Math.cos(la) * Math.cos(lo)];
  }
  static slerp(a, b, t) {
    var d = Math.max(-1, Math.min(1, a[0] * b[0] + a[1] * b[1] + a[2] * b[2])), w = Math.acos(d), sw = Math.sin(w);
    var u, v;
    if (sw < 1e-4) { u = 1 - t; v = t; } else { u = Math.sin((1 - t) * w) / sw; v = Math.sin(t * w) / sw; }
    var x = a[0] * u + b[0] * v, y = a[1] * u + b[1] * v, z = a[2] * u + b[2] * v, n = Math.sqrt(x * x + y * y + z * z) || 1;
    return [x / n, y / n, z / n];
  }
  static angle(a, b) { return Math.acos(Math.max(-1, Math.min(1, a[0] * b[0] + a[1] * b[1] + a[2] * b[2]))); }

  _go(toU, toAlt, speed, lift) {
    this.fromU = MiningDrone.unit(this.cur.lonDeg, this.cur.latDeg); this.fromAlt = this.cur.alt;
    this.toU = toU; this.toAlt = toAlt; this.lift = lift || 40;
    var arcPx = MiningDrone.angle(this.fromU, toU) * this.scene._planetR;
    this.dur = Math.max(900, arcPx / speed * 1000);
    this.t = 0;
  }

  /** Projette la position sphérique courante à l'écran (suit la rotation de la planète, image par image). */
  _place(time) {
    var sc = this.scene, cur = this.cur, f = sc._projectFixed(cur.lonDeg, cur.latDeg), k = f.scale;
    this.frame = f;
    this.pos.x = f.x + f.ux * cur.alt * k;
    this.pos.y = f.y + f.uy * cur.alt * k;
    var vis = f.alpha > 0.02;
    var bob = Math.sin(time * 0.004 + this.phase) * 4 * k;
    this.c.setPosition(this.pos.x, this.pos.y + bob).setScale(0.8 * k).setAlpha(f.alpha).setDepth(f.depth + 40).setVisible(vis);
    this.shadow.setPosition(f.x, f.y + 6 * k).setScale((0.9 - Math.min(0.4, cur.alt / 500)) * k).setAlpha(0.3 * f.alpha).setDepth(f.depth - 0.5).setVisible(vis);
    return vis;
  }

  update(time, delta) {
    var prevX = this.pos.x, prevY = this.pos.y, cur = this.cur, e, u;
    this.timer -= delta;

    switch (this.state) {
      case 'wait':
        if (this.timer <= 0) {
          this.state = 'out'; this.cycleStart = Date.now();
          this._go(MiningDrone.unit(this.node.lonDeg, this.node.latDeg), this.hoverAlt, 190, 50);
        }
        break;
      case 'out':
        this.t = Math.min(1, this.t + delta / this.dur);
        this._move(this.t * this.t * (3 - 2 * this.t));
        if (this.t >= 1) { this.state = 'mine'; this.timer = this.mineTime; this.spark = 0; }
        break;
      case 'mine':
        this.spark -= delta;
        if (this.spark <= 0) {
          this.spark = 90;
          if (this._visible()) this.fx.sparkle(this.id, this.node.topX + (Math.random() - 0.5) * 30, this.node.topY + (Math.random() - 0.5) * 12);
        }
        if (this.timer <= 0) {
          this.state = 'back';
          this._go(MiningDrone.unit(this.depot.lonDeg, this.depot.latDeg), this.depot.altPx, 190, 50);
        }
        break;
      case 'back':
        this.t = Math.min(1, this.t + delta / this.dur);
        this._move(this.t * this.t * (3 - 2 * this.t));
        if (this.t >= 1) { this._deliver(); this.state = 'unload'; this.timer = 500; }
        break;
      case 'unload':
        if (this.timer <= 0) { this.state = 'wait'; this.timer = 600 + Math.random() * 900; }
        break;
    }

    var vis = this._place(time);

    // Inclinaison selon la vitesse à l'écran + traînée (seulement si le drone est visible)
    var vx = (this.pos.x - prevX) / Math.max(1, delta);
    this.c.rotation = Phaser.Math.Clamp(vx * 0.18, -0.25, 0.25) + (this.frame ? this.frame.rot * 0.5 : 0);
    if (vis && (this.state === 'out' || this.state === 'back')) {
      this.trail -= delta;
      if (this.trail <= 0) { this.trail = 55; if (this.frame.alpha > 0.4) this.fx.sparkle(this.id, this.c.x, this.c.y + 26 * this.frame.scale); }
    }

    // Jauge de cargaison
    var frac = this.state === 'mine' ? 1 - Math.max(0, this.timer) / this.mineTime : (this.state === 'back' || this.state === 'unload' ? 1 : 0);
    this.bar.clear();
    if (frac > 0) {
      this.bar.fillStyle(0x0b1224, 0.85); this.bar.fillRoundedRect(-24, -50, 48, 8, 3);
      this.bar.fillStyle(this.def.color, 1); this.bar.fillRoundedRect(-23, -49, Math.max(2, 46 * frac), 6, 2);
    }
  }

  /** Avance le long de l'arc de grand cercle (e = progression lissée 0..1) et met à jour lon/lat/altitude. */
  _move(e) {
    var u = MiningDrone.slerp(this.fromU, this.toU, e);
    this.cur.lonDeg = Math.atan2(u[0], u[2]) * 180 / Math.PI;
    this.cur.latDeg = Math.asin(Math.max(-1, Math.min(1, u[1]))) * 180 / Math.PI;
    this.cur.alt = this.fromAlt + (this.toAlt - this.fromAlt) * e + this.lift * Math.sin(Math.PI * e);
  }

  /** Drone réellement visible à l'écran (pas caché derrière la planète). */
  _visible() { return !!this.frame && this.frame.alpha > 0.4; }

  /** Dessine le laser (Graphics partagé, effacé à chaque frame par la scène). */
  drawBeam(g, time) {
    if (this.state !== 'mine' || !this._visible()) return;
    var k = this.frame.scale, sx = this.c.x, sy = this.c.y + 26 * k, tx = this.node.topX, ty = this.node.topY;
    var a = this.frame.alpha, pulse = 0.6 + Math.sin(time * 0.02) * 0.25;
    g.lineStyle(9 * k, this.def.color, 0.22 * pulse * a); g.lineBetween(sx, sy, tx, ty);
    g.lineStyle(3 * k, 0xffffff, 0.9 * a); g.lineBetween(sx, sy, tx, ty);
    g.fillStyle(this.def.color, 0.8 * a); g.fillCircle(tx, ty, (7 + Math.sin(time * 0.03) * 2) * k);
  }

  _deliver() {
    this.deliveries++;
    var R = NEBUSTION.Resources, E = NEBUSTION.Economy;
    if (!this._visible()) return;   // dépôt derrière la planète : rien à afficher
    var secs = (Date.now() - this.cycleStart) / 1000;
    var amount = R.droneRate(this.id) * secs;
    var x = this.pos.x, y = this.pos.y - 34;
    if (R.isFull(this.id)) this.fx.text(x, y, 'Stockage plein', '#ff8fa3', 22, 50);
    else if (amount >= 0.01) this.fx.gain(this.id, amount, x, y, false);
    this.fx.ring(this.pos.x, this.pos.y + 30, this.def.color, 0.9);
    this.fx.burst(this.id, this.pos.x, this.pos.y + 20, 6);
    if (this.scene.flashTower) this.scene.flashTower(this.def.color);
  }
};
