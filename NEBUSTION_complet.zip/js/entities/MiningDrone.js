/**
 * NEBUSTION - MiningDrone
 * Drone minier animé : décolle du Commandement, rejoint son gisement, le mine au laser
 * (étincelles, jauge de cargaison), revient déposer et affiche la cargaison livrée.
 *
 * NB : la production est créditée EN CONTINU par le ResourceManager (fiable même si l'écran
 * est fermé). Le drone illustre cette production : la cargaison affichée à la livraison =
 * (production d'un drone) × (durée du trajet). Aucun crédit n'est donc dupliqué par les drones.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.MiningDrone = class MiningDrone {
  constructor(scene, fx, node, depot, slot) {
    this.scene = scene; this.fx = fx; this.node = node; this.id = node.id; this.depot = depot;
    this.def = node.def;
    var col = this.def.color;

    this.pos = { x: depot.x, y: depot.y };
    this.state = 'wait';
    this.timer = 400 + slot * 900;     // départs décalés
    this.phase = Math.random() * 6.28;
    this.cycleStart = Date.now();
    this.mineTime = 4500;
    this.trail = 0; this.spark = 0;
    this.from = { x: depot.x, y: depot.y }; this.to = { x: depot.x, y: depot.y }; this.ctrl = { x: depot.x, y: depot.y };
    this.t = 0; this.dur = 1;
    this.deliveries = 0;

    this.shadow = scene.add.image(depot.x, depot.y + 90, 'tex_shadow').setAlpha(0.3).setDepth(1040);
    var c = scene.add.container(depot.x, depot.y).setDepth(1050).setScale(0.8);
    this.c = c;
    this.glow = scene.add.image(0, 8, 'tex_glow_' + this.id).setScale(1.5).setAlpha(0.5).setBlendMode(Phaser.BlendModes.ADD);
    this.rotL = scene.add.image(-41, -10, 'tex_rotor');
    this.rotR = scene.add.image(41, -10, 'tex_rotor');
    this.body = scene.add.image(0, 0, 'tex_drone');
    this.light = scene.add.image(0, -4, 'tex_glow_' + this.id).setScale(0.35).setBlendMode(Phaser.BlendModes.ADD);
    this.bar = scene.add.graphics();
    c.add([this.glow, this.rotL, this.rotR, this.body, this.light, this.bar]);

    scene.tweens.add({ targets: [this.rotL, this.rotR], scaleX: 0.3, duration: 60, yoyo: true, repeat: -1 });
    scene.tweens.add({ targets: this.light, alpha: 0.3, duration: 450, yoyo: true, repeat: -1 });
  }

  _go(target, speed, lift) {
    this.from = { x: this.pos.x, y: this.pos.y };
    this.to = { x: target.x, y: target.y };
    var dx = this.to.x - this.from.x, dy = this.to.y - this.from.y;
    var dist = Math.sqrt(dx * dx + dy * dy);
    this.ctrl = { x: (this.from.x + this.to.x) / 2, y: Math.min(this.from.y, this.to.y) - (lift || 40) };
    this.dur = Math.max(700, dist / speed * 1000);
    this.t = 0;
  }

  _bez(t) {
    var a = 1 - t;
    return {
      x: a * a * this.from.x + 2 * a * t * this.ctrl.x + t * t * this.to.x,
      y: a * a * this.from.y + 2 * a * t * this.ctrl.y + t * t * this.to.y
    };
  }

  update(time, delta) {
    var R = NEBUSTION.Resources, E = NEBUSTION.Economy;
    var prevX = this.pos.x;
    this.timer -= delta;

    switch (this.state) {
      case 'wait':
        if (this.timer <= 0) { this.state = 'out'; this._go({ x: this.node.hoverX, y: this.node.hoverY }, 190, 50); this.cycleStart = Date.now(); }
        break;
      case 'out':
        this.t = Math.min(1, this.t + delta / this.dur);
        this.pos = this._bez(this.t * this.t * (3 - 2 * this.t));
        if (this.t >= 1) { this.state = 'mine'; this.timer = this.mineTime; this.spark = 0; }
        break;
      case 'mine':
        this.spark -= delta;
        if (this.spark <= 0) {
          this.spark = 90;
          this.fx.sparkle(this.id, this.node.topX + (Math.random() - 0.5) * 30, this.node.topY + (Math.random() - 0.5) * 12);
        }
        if (this.timer <= 0) { this.state = 'back'; this._go(this.depot, 190, 50); }
        break;
      case 'back':
        this.t = Math.min(1, this.t + delta / this.dur);
        this.pos = this._bez(this.t * this.t * (3 - 2 * this.t));
        if (this.t >= 1) { this._deliver(); this.state = 'unload'; this.timer = 500; }
        break;
      case 'unload':
        if (this.timer <= 0) { this.state = 'wait'; this.timer = 600 + Math.random() * 900; }
        break;
    }

    // Vol stationnaire + inclinaison + traînée
    var bob = Math.sin(time * 0.004 + this.phase) * 4;
    this.c.x = this.pos.x; this.c.y = this.pos.y + bob;
    var vx = (this.pos.x - prevX) / Math.max(1, delta);
    this.c.rotation = Phaser.Math.Clamp(vx * 0.18, -0.25, 0.25);
    this.shadow.x = this.pos.x; this.shadow.y = this.pos.y + 96;
    this.shadow.setScale(1 + (this.pos.y - 420) * -0.0005);
    if (this.state === 'out' || this.state === 'back') {
      this.trail -= delta;
      if (this.trail <= 0) { this.trail = 55; this.fx.sparkle(this.id, this.c.x, this.c.y + 26); }
    }

    // Jauge de cargaison
    var frac = this.state === 'mine' ? 1 - Math.max(0, this.timer) / this.mineTime : (this.state === 'back' || this.state === 'unload' ? 1 : 0);
    this.bar.clear();
    if (frac > 0) {
      this.bar.fillStyle(0x0b1224, 0.85); this.bar.fillRoundedRect(-24, -50, 48, 8, 3);
      this.bar.fillStyle(this.def.color, 1); this.bar.fillRoundedRect(-23, -49, Math.max(2, 46 * frac), 6, 2);
    }
  }

  /** Dessine le laser (Graphics partagé, effacé à chaque frame par la scène). */
  drawBeam(g, time) {
    if (this.state !== 'mine') return;
    var sx = this.c.x, sy = this.c.y + 26, tx = this.node.topX, ty = this.node.topY;
    var pulse = 0.6 + Math.sin(time * 0.02) * 0.25;
    g.lineStyle(9, this.def.color, 0.22 * pulse); g.lineBetween(sx, sy, tx, ty);
    g.lineStyle(3, 0xffffff, 0.9); g.lineBetween(sx, sy, tx, ty);
    g.fillStyle(this.def.color, 0.8); g.fillCircle(tx, ty, 7 + Math.sin(time * 0.03) * 2);
  }

  _deliver() {
    this.deliveries++;
    var R = NEBUSTION.Resources, E = NEBUSTION.Economy;
    var secs = (Date.now() - this.cycleStart) / 1000;
    var amount = R.droneRate(this.id) * secs;
    var x = this.depot.x, y = this.depot.y - 34;
    if (R.isFull(this.id)) this.fx.text(x, y, 'Stockage plein', '#ff8fa3', 22, 50);
    else if (amount >= 0.01) this.fx.gain(this.id, amount, x, y, false);
    this.fx.ring(this.depot.x, this.depot.y + 30, this.def.color, 0.9);
    this.fx.burst(this.id, this.depot.x, this.depot.y + 20, 6);
    if (this.scene.flashTower) this.scene.flashTower(this.def.color);
  }
};
