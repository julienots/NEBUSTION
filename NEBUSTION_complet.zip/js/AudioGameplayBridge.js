// Compatibility bridge for semantic gameplay events.
window.addEventListener('nebustion:sfx', e=>{ const d=e.detail||{}; if(window.nebustionPlaySfx&&d.name) window.nebustionPlaySfx(d.name,d.options||{}); });
window.addEventListener('nebustion:ui-click',()=>window.nebustionPlaySfx&&window.nebustionPlaySfx('ui_click',{volume:0.5}));
