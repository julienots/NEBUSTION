/**
 * NEBUSTION - HeroesScene
 * Section "Héros" : liste défilante de la collection (16 héros de base) avec
 * portrait, rareté, rôle et réplique, plus une fiche détaillée (stats + compétences)
 * à l'ouverture d'un héros. Ne gère PAS encore le combat, l'invocation ni
 * l'amélioration : uniquement la consultation de la base de héros.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.HeroesScene = class HeroesScene extends Phaser.Scene {
  constructor() {
    super('HeroesScene');
  }

  create() {
    var w = this.scale.width, h = this.scale.height;
    var H = NEBUSTION.Heroes;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(300, 5, 7, 15);

    NEBUSTION.SceneBackground.build(this, { withPlanet: false });

    // La barre de ressources (HUD) occupe y = 12 → 104 : tout l'en-tête doit être placé en dessous.
    this.add.text(w / 2, 142, 'HÉROS', {
      fontFamily: 'Arial, sans-serif', fontSize: '26px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(50).setShadow(0, 0, '#00e5ff', 10, true, true);

    this.allHeroes = H.all();
    this.filterRarity = null;

    this.add.text(w / 2, 174, 'Collection · ' + this.allHeroes.length + ' héros', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#7a89ad'
    }).setOrigin(0.5).setDepth(50);

    this._buildFilters(210);

    // Zone de liste : sous les filtres, au-dessus de la barre de navigation
    this.listTop = 240;
    this.listBottom = h - 132;
    this._buildList();

    this.hud = NEBUSTION.HUD.attach(this);
    new NEBUSTION.BottomNav(this, 'heroes');

    this.detailLayer = this.add.container(0, 0).setDepth(2000).setVisible(false);
  }

  // ---------- Filtres de rareté ----------
  _buildFilters(y) {
    var self = this, w = this.scale.width;
    var H = NEBUSTION.Heroes;
    var options = [{ id: null, name: 'Tous', hex: '#7a89ad' }].concat(
      H.RARITY_ORDER.map(function (id) { return { id: id, name: H.RARITIES[id].name, hex: H.RARITIES[id].hex }; })
    );
    var gap = 6;
    var chipW = (w - 24 - gap * (options.length - 1)) / options.length;
    this.filterChips = [];

    options.forEach(function (opt, i) {
      var x = 12 + chipW / 2 + i * (chipW + gap);
      var c = self.add.container(x, y).setDepth(60);
      var bg = self.add.graphics();
      c.add(bg);
      var label = self.add.text(0, 0, opt.name, {
        fontFamily: 'Arial, sans-serif', fontSize: '11px', fontStyle: 'bold', color: '#eaf2ff'
      }).setOrigin(0.5);
      c.add(label);

      function draw(active) {
        bg.clear();
        bg.fillStyle(Phaser.Display.Color.HexStringToColor(opt.hex).color, active ? 0.85 : 0.12);
        bg.fillRoundedRect(-chipW / 2, -16, chipW, 32, 10);
        bg.lineStyle(1.5, Phaser.Display.Color.HexStringToColor(opt.hex).color, active ? 1 : 0.5);
        bg.strokeRoundedRect(-chipW / 2, -16, chipW, 32, 10);
        label.setColor(active ? '#0a0f1e' : '#eaf2ff');
      }
      draw(opt.id === self.filterRarity);

      var zone = self.add.zone(0, 0, chipW, 32).setInteractive({ useHandCursor: true });
      c.add(zone);
      zone.on('pointerdown', function () {
        self.filterRarity = opt.id;
        self.filterChips.forEach(function (fc) { fc.draw(fc.opt.id === self.filterRarity); });
        self._refreshList();
      });

      self.filterChips.push({ opt: opt, draw: draw });
    });
  }

  // ---------- Liste défilante ----------
  _buildList() {
    var w = this.scale.width;
    var viewH = this.listBottom - this.listTop;

    this.listMaskGfx = this.make.graphics();
    this.listMaskGfx.fillRect(0, this.listTop, w, viewH);
    var mask = this.listMaskGfx.createGeometryMask();

    this.listContainer = this.add.container(0, this.listTop).setDepth(40);
    this.listContainer.setMask(mask);
    this.scrollY = 0;
    this.maxScroll = 0;

    this._refreshList();

    // Défilement tactile (drag vertical) ET tap pour ouvrir une fiche, gérés par UNE seule
    // zone : on distingue un tap d'un glissement grâce à la distance parcourue avant de
    // relâcher, puis on calcule quelle carte se trouvait sous le doigt. Les cartes elles-mêmes
    // ne sont pas interactives, pour éviter tout conflit entre glissement et appui.
    var self = this;
    var dragging = false, startY = 0, startScroll = 0, moved = 0;
    var zone = this.add.zone(0, this.listTop, w, viewH).setOrigin(0).setInteractive();
    zone.setDepth(41);

    zone.on('pointerdown', function (p) {
      dragging = true; startY = p.y; startScroll = self.scrollY; moved = 0;
    });
    this.input.on('pointermove', function (p) {
      if (!dragging) return;
      var dy = p.y - startY;
      moved = Math.max(moved, Math.abs(dy));
      self.scrollY = Phaser.Math.Clamp(startScroll - dy, 0, self.maxScroll);
      self.listContainer.y = self.listTop - self.scrollY;
    });
    zone.on('pointerup', function (p) {
      dragging = false;
      if (moved > 12) return; // c'était un glissement, pas un tap
      self._handleListTap(p.y);
    });
    this.input.on('pointerupoutside', function () { dragging = false; });
  }

  _handleListTap(pointerY) {
    var grid = this._rowGrid;
    var list = this._currentList;
    if (!grid || !list || !list.length) return;
    var localY = (pointerY - this.listTop) + this.scrollY;
    var idx = Math.floor(localY / grid);
    if (idx < 0 || idx >= list.length) return;
    var within = localY - idx * grid;
    if (within <= this._rowH) this._openDetail(list[idx]);
  }

  _refreshList() {
    var self = this;
    this.listContainer.removeAll(true);
    var w = this.scale.width;
    var list = this.allHeroes.filter(function (h) { return !self.filterRarity || h.rarity === self.filterRarity; });

    var rowH = 136, rowGap = 10;
    list.forEach(function (hero, i) {
      var row = self._buildRow(hero, w, rowH);
      row.y = i * (rowH + rowGap);
      self.listContainer.add(row);
    });

    this._currentList = list;
    this._rowH = rowH;
    this._rowGrid = rowH + rowGap;

    var viewH = this.listBottom - this.listTop;
    var contentH = list.length * (rowH + rowGap);
    this.maxScroll = Math.max(0, contentH - viewH + 12);
    this.scrollY = Math.min(this.scrollY, this.maxScroll);
    this.listContainer.y = this.listTop - this.scrollY;

    if (list.length === 0) {
      this.listContainer.add(this.add.text(w / 2, 40, 'Aucun héros de cette rareté pour le moment.', {
        fontFamily: 'Arial, sans-serif', fontSize: '14px', color: '#7a89ad', align: 'center'
      }).setOrigin(0.5));
    }
  }

  _buildRow(hero, w, rowH) {
    var H = NEBUSTION.Heroes;
    var rarity = H.RARITIES[hero.rarity];
    var rarityLabel = hero.rarityLabel || rarity.name;
    var role = H.ROLES[hero.role];

    var row = this.add.container(0, 0);

    var bg = this.add.graphics();
    bg.fillGradientStyle(0x121a30, 0x121a30, 0x0a0f1e, 0x0a0f1e, 0.92);
    bg.fillRoundedRect(12, 0, w - 24, rowH - 10, 16);
    bg.lineStyle(1.5, rarity.color, 0.5);
    bg.strokeRoundedRect(12, 0, w - 24, rowH - 10, 16);
    row.add(bg);

    var thumbW = 92, thumbH = rowH - 26;
    var portraitKey = H.portraitKey(hero.id);
    var thumb = this.add.image(26 + thumbW / 2, (rowH - 10) / 2, portraitKey)
      .setDisplaySize(thumbW, thumbH);
    row.add(thumb);
    // Skin équipé (module Personnalisation) : teinte + aura légère sur la miniature.
    var thumbSkin = NEBUSTION.SkinManager && NEBUSTION.SkinManager.equippedSkin('hero', hero.id);
    if (thumbSkin) NEBUSTION.SkinFX.attach(this, row, thumb, thumbSkin, thumbW, thumbH, { light: true });
    var thumbBorder = this.add.graphics();
    thumbBorder.lineStyle(2, rarity.color, 0.8);
    thumbBorder.strokeRoundedRect(26, (rowH - 10 - thumbH) / 2, thumbW, thumbH, 8);
    row.add(thumbBorder);
    var locked = !NEBUSTION.Combat.isUnlocked(hero.id);   // héros exclusif de la Boutique pas encore recruté
    if (locked) {
      row.add(this.add.rectangle(26 + thumbW / 2, (rowH - 10) / 2, thumbW, thumbH, 0x02040a, 0.6));
      row.add(this.add.text(26 + thumbW / 2, (rowH - 10) / 2, 'BOUTIQUE', {
        fontFamily: 'Arial, sans-serif', fontSize: '13px', fontStyle: 'bold', color: '#ffd166'
      }).setOrigin(0.5));
    }

    var textX = 26 + thumbW + 16;
    row.add(this.add.text(textX, 14, hero.name, {
      fontFamily: 'Arial, sans-serif', fontSize: '18px', fontStyle: 'bold', color: '#eaf2ff'
    }));

    var rarityPill = this.add.graphics();
    var pillW = 14 + rarityLabel.length * 7;
    rarityPill.fillStyle(rarity.color, 0.22);
    rarityPill.fillRoundedRect(textX, 42, pillW, 22, 8);
    rarityPill.lineStyle(1, rarity.color, 0.9);
    rarityPill.strokeRoundedRect(textX, 42, pillW, 22, 8);
    row.add(rarityPill);
    row.add(this.add.text(textX + pillW / 2, 53, rarityLabel, {
      fontFamily: 'Arial, sans-serif', fontSize: '11px', fontStyle: 'bold', color: rarity.hex
    }).setOrigin(0.5));

    var rolePillX = textX + pillW + 8;
    var rolePillW = 16 + role.name.length * 7;
    var rolePill = this.add.graphics();
    rolePill.fillStyle(role.color, 0.16);
    rolePill.fillRoundedRect(rolePillX, 42, rolePillW, 22, 8);
    rolePill.lineStyle(1, role.color, 0.85);
    rolePill.strokeRoundedRect(rolePillX, 42, rolePillW, 22, 8);
    row.add(rolePill);
    row.add(this.add.text(rolePillX + rolePillW / 2, 53, role.name, {
      fontFamily: 'Arial, sans-serif', fontSize: '11px', fontStyle: 'bold', color: '#eaf2ff'
    }).setOrigin(0.5));

    row.add(this.add.text(textX, 74, '« ' + hero.title + ' »', {
      fontFamily: 'Arial, sans-serif', fontSize: '12px', fontStyle: 'italic', color: '#9aa5c0',
      wordWrap: { width: w - textX - 30 }
    }));

    if (locked) {
      // Un Dieu obtenu par fragments (shop.fragmentsToUnlock, ex. Aetherion) n'a pas de prix en
      // Prismes (pas de shop.cost) : on affiche sa progression plutôt qu'un recrutement direct.
      var lockedLine;
      if (hero.shop && hero.shop.fragmentsToUnlock) {
        var frags = NEBUSTION.Resources.state.combat.fragments[hero.id] || 0;
        lockedLine = 'Fragments ' + Math.min(frags, hero.shop.fragmentsToUnlock) + ' / ' + hero.shop.fragmentsToUnlock + ' pour l\'invoquer';
      } else {
        var price = hero.shop.cost.gem;
        lockedLine = 'Recrutement en Boutique · ' + price + ' Prismes';
      }
      row.add(this.add.text(textX, 100, lockedLine, {
        fontFamily: 'Arial, sans-serif', fontSize: '12px', fontStyle: 'bold', color: '#ffd166'
      }));
    }
    return row;
  }

  // ---------- Fiche détaillée ----------
  _openDetail(hero) {
    if (!NEBUSTION.Combat.isUnlocked(hero.id)) { this.scene.start('ShopScene', { tab: 'heroes', heroId: hero.id }); return; }   // héros à recruter → Boutique
    var self = this, w = this.scale.width, h = this.scale.height;
    var H = NEBUSTION.Heroes;
    var rarity = H.RARITIES[hero.rarity];
    var rarityLabel = hero.rarityLabel || rarity.name;
    var role = H.ROLES[hero.role];
    var stats = H.statsAtLevel(hero, 1);

    this.detailLayer.removeAll(true);
    this.detailLayer.setVisible(true);

    var tint = this.add.rectangle(w / 2, h / 2, w, h, 0x02040a, 0.82).setInteractive();
    this.detailLayer.add(tint);
    tint.on('pointerdown', function () { self._closeDetail(); });

    var panelW = w - 48, panelH = Math.min(h - 140, 1020);
    var panel = this.add.container(w / 2, h / 2);
    this.detailLayer.add(panel);

    var pbg = this.add.graphics();
    pbg.fillGradientStyle(0x141d33, 0x141d33, 0x0a0f1e, 0x0a0f1e, 0.98);
    pbg.fillRoundedRect(-panelW / 2, -panelH / 2, panelW, panelH, 22);
    pbg.lineStyle(2, rarity.color, 0.9);
    pbg.strokeRoundedRect(-panelW / 2, -panelH / 2, panelW, panelH, 22);
    panel.add(pbg);
    // Le fond du panneau absorbe le tap pour qu'un appui À L'INTÉRIEUR de la fiche
    // ne déclenche pas la fermeture (le voile derrière ne reçoit l'appui que si rien
    // au-dessus ne l'a intercepté).
    pbg.setInteractive(new Phaser.Geom.Rectangle(-panelW / 2, -panelH / 2, panelW, panelH), Phaser.Geom.Rectangle.Contains);
    pbg.on('pointerdown', function () {});

    var top = -panelH / 2;

    var closeBtn = this.add.text(panelW / 2 - 26, top + 16, '✕', {
      fontFamily: 'Arial, sans-serif', fontSize: '20px', color: '#eaf2ff'
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });
    closeBtn.on('pointerdown', function () { self._closeDetail(); });
    panel.add(closeBtn);

    var portrait = this.add.image(0, top + 132, H.portraitKey(hero.id)).setDisplaySize(176, 224);
    panel.add(portrait);
    // Skin équipé (module Personnalisation) : teinte, aura et effet animé sur le portrait de la fiche.
    var portraitSkin = NEBUSTION.SkinManager && NEBUSTION.SkinManager.equippedSkin('hero', hero.id);
    if (portraitSkin) NEBUSTION.SkinFX.attach(this, panel, portrait, portraitSkin, 176, 224);
    var pborder = this.add.graphics();
    pborder.lineStyle(3, rarity.color, 0.9);
    pborder.strokeRoundedRect(-88, top + 132 - 112, 176, 224, 10);
    panel.add(pborder);

    panel.add(this.add.text(0, top + 262, hero.name, {
      fontFamily: 'Arial, sans-serif', fontSize: '24px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5));

    panel.add(this.add.text(0, top + 290, '« ' + hero.title + ' »', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', fontStyle: 'italic', color: '#9aa5c0'
    }).setOrigin(0.5));

    panel.add(this.add.text(-panelW / 2 + 24, top + 314, rarityLabel.toUpperCase() + '  ·  ' + role.name, {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', fontStyle: 'bold', color: rarity.hex
    }));

    // Barres de statistiques
    var statY = top + 344;
    var statDefs = [
      { key: 'hp', label: 'PV', color: 0x5fd97a, max: 1800 },
      { key: 'atk', label: 'Attaque', color: 0xff8a3d, max: 220 },
      { key: 'def', label: 'Défense', color: 0x4fd1ff, max: 200 },
      { key: 'spd', label: 'Vitesse', color: 0xb47bff, max: 170 }
    ];
    var barW = panelW - 48;
    statDefs.forEach(function (sd, i) {
      var y = statY + i * 34;
      panel.add(self.add.text(-panelW / 2 + 24, y, sd.label, {
        fontFamily: 'Arial, sans-serif', fontSize: '12px', color: '#7a89ad'
      }));
      var track = self.add.graphics();
      track.fillStyle(0x0a0f1e, 1);
      track.fillRoundedRect(-panelW / 2 + 24, y + 16, barW, 8, 4);
      panel.add(track);
      var pct = Phaser.Math.Clamp(stats[sd.key] / sd.max, 0.04, 1);
      var fill = self.add.graphics();
      fill.fillStyle(sd.color, 1);
      fill.fillRoundedRect(-panelW / 2 + 24, y + 16, barW * pct, 8, 4);
      panel.add(fill);
      panel.add(self.add.text(panelW / 2 - 24, y, String(stats[sd.key]), {
        fontFamily: 'Arial, sans-serif', fontSize: '12px', fontStyle: 'bold', color: '#eaf2ff'
      }).setOrigin(1, 0));
    });

    panel.add(this.add.text(0, statY + statDefs.length * 34 + 6, 'PUISSANCE  ' + stats.power, {
      fontFamily: 'Arial, sans-serif', fontSize: '15px', fontStyle: '900', color: '#ffd166'
    }).setOrigin(0.5).setShadow(0, 0, '#ffd166', 8, true, true));

    // Compétences
    var skillY = statY + statDefs.length * 34 + 34;
    var order = [{ id: 'passive', label: 'PASSIF' }, { id: 'active', label: 'ACTIF' }, { id: 'ultimate', label: 'ULTIME' }];
    order.forEach(function (o) {
      var sk = hero.skills[o.id];
      var sbg = self.add.graphics();
      var boxH = 70;
      sbg.fillStyle(0x0a0f1e, 0.8);
      sbg.fillRoundedRect(-panelW / 2 + 24, skillY, barW, boxH, 10);
      panel.add(sbg);
      panel.add(self.add.text(-panelW / 2 + 36, skillY + 8, o.label + '  —  ' + sk.name, {
        fontFamily: 'Arial, sans-serif', fontSize: '13px', fontStyle: 'bold', color: '#00e5ff'
      }));
      panel.add(self.add.text(-panelW / 2 + 36, skillY + 28, sk.desc, {
        fontFamily: 'Arial, sans-serif', fontSize: '11.5px', color: '#c7d1ea',
        wordWrap: { width: barW - 24 }
      }));
      skillY += boxH + 8;
    });

    // Bouton d'accès à l'équipement de ce héros (module ajouté à l'étape 6).
    var btnY = Math.min(skillY + 30, panelH / 2 - 34), halfW = (barW - 8) / 2;
    var equipBtn = new NEBUSTION.Button(this, -halfW / 2 - 4, btnY, {
      width: halfW, height: 48, label: 'Équipement', accentColor: 0x00e5ff,
      onClick: function () { self.scene.start('EquipmentScene', { heroId: hero.id }); }
    });
    panel.add(equipBtn);
    // Bouton d'accès aux skins de ce héros (module Personnalisation, étape 6 / 3e volet).
    var skinBtn = new NEBUSTION.Button(this, halfW / 2 + 4, btnY, {
      width: halfW, height: 48, label: 'Skins', accentColor: 0xb47bff,
      onClick: function () { self.scene.start('SkinsScene', { tab: 'hero', targetId: hero.id, from: 'HeroesScene' }); }
    });
    panel.add(skinBtn);
  }

  _closeDetail() {
    this.detailLayer.setVisible(false);
    this.detailLayer.removeAll(true);
  }
};
