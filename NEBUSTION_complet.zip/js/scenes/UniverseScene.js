/**
 * NEBUSTION - UniverseScene
 * Carte spatiale de l'Univers : toutes les galaxies connues sont visibles d'un coup, dispersées
 * autour de notre galaxie natale (la Voie Aube, au centre). Le style visuel et le geste tactile
 * (tap → zoom → entrer/condition) viennent de NEBUSTION.UniverseMap, partagé avec l'aperçu de
 * l'écran d'accueil.
 * Aucune logique de jeu ici : tout vient de NEBUSTION.Universe (données) + GalaxyManager (déblocage).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.UniverseScene = class UniverseScene extends Phaser.Scene {
  constructor() {
    super('UniverseScene');
  }

  init(data) {
    this._from = (data && data.from) || 'GalaxyScene';
  }

  create() {
    var w = this.scale.width, h = this.scale.height;
    var U = NEBUSTION.Universe;
    var self = this;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(300, 5, 7, 15);
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });

    this.fx = new NEBUSTION.FX(this);
    this.hud = NEBUSTION.HUD.attach(this);
    this._umBusy = false;

    this.add.text(w / 2, 126, 'UNIVERS', {
      fontFamily: 'Arial, sans-serif', fontSize: '20px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(80).setShadow(0, 0, '#ff3b1e', 10, true, true);
    this.add.text(w / 2, 150, 'Touchez une galaxie pour l\'explorer', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#7a89ad'
    }).setOrigin(0.5).setDepth(80);

    // Bouton retour vers la carte de la Voie Aube
    var back = new NEBUSTION.Button(this, 46, 126, {
      width: 56, height: 44, accentColor: 0x6c3ce9,
      iconDraw: function (g) {
        g.lineStyle(2.5, 0x6c3ce9, 1);
        g.lineBetween(8, 0, -8, 0);
        g.lineBetween(-8, 0, -1, -7);
        g.lineBetween(-8, 0, -1, 7);
      },
      onClick: function () { self._goTo(self._from); }
    });
    back.setDepth(80);

    // --- Disposition : la Voie Aube au centre, les autres galaxies dispersées tout autour,
    // toutes visibles dès l'arrivée sur l'écran (aucun défilement nécessaire). ---
    var cx = w / 2, cy = h * 0.5 + 30;
    var layout = {
      aube: { x: cx, y: cy, size: 250, big: true, tilt: -0.3, depth: 40 },
      ecarlate: { x: cx - 170, y: cy - 260, size: 150, tilt: -0.22, depth: 40 },
      glacial: { x: cx + 180, y: cy - 260, size: 150, tilt: -0.34, depth: 40 },
      kaelis: { x: cx, y: cy + 310, size: 150, tilt: -0.18, depth: 40 }
    };

    // Routes stellaires reliant Nexus aux galaxies voisines (décor, sous les galaxies)
    var routes = this.add.graphics().setDepth(30);
    U.GALAXIES.forEach(function (g) {
      if (g.id === 'aube') return;
      var L = layout[g.id] || { x: cx, y: cy };
      var col = parseInt(g.theme.mid.replace('#', '0x'));
      routes.lineStyle(1.5, col, 0.16);
      routes.lineBetween(cx, cy, L.x, L.y);
    });

    // Les galaxies elles-mêmes
    U.GALAXIES.forEach(function (g) {
      var L = layout[g.id] || { x: cx, y: cy, size: 150 };
      NEBUSTION.UniverseMap.buildNode(self, g, L.x, L.y, L);
    });

    // Une curiosité gravitationnelle, à l'écart des routes stellaires : toujours accessible.
    this._buildBlackHoleNode(cx + 240, cy + 190, 130);

    new NEBUSTION.BottomNav(this, 'galaxy');
  }

  /** Nœud du Trou Noir sur la carte Univers : toujours visible, jamais verrouillé. */
  _buildBlackHoleNode(x, y, size) {
    var self = this, BT = NEBUSTION.BlackHoleTextures, ADD = Phaser.BlendModes.ADD;
    var key = BT.ensureIcon(this);
    var node = this.add.container(x, y).setDepth(45);

    var halo = this.add.image(0, 0, 'tex_nebula_purple').setTint(0x7a2cff)
      .setDisplaySize(size * 2.1, size * 2.1).setAlpha(0.16).setBlendMode(ADD);
    node.add(halo);
    this.tweens.add({ targets: halo, alpha: 0.28, duration: 2600, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });

    var disk = this.add.image(0, 0, key).setDisplaySize(size, size);
    node.add(disk);
    this.tweens.add({ targets: disk, rotation: Math.PI * 2, duration: 26000, repeat: -1, ease: 'Linear' });

    node.add(this.add.text(0, size * 0.44, 'Trou Noir', {
      fontFamily: 'Arial, sans-serif', fontSize: '12px', fontStyle: '900', color: '#ffb84d', align: 'center'
    }).setOrigin(0.5, 0));

    this.tweens.add({ targets: node, y: y - 6, duration: 3100, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });

    var hr = size * 0.85;
    var hit = this.add.circle(0, 0, hr, 0xffffff, 0.001)
      .setInteractive(new Phaser.Geom.Circle(hr, hr, hr), Phaser.Geom.Circle.Contains);
    hit.input.cursor = 'pointer';
    node.add(hit);
    hit.on('pointerup', function () {
      if (self._umBusy) return;
      self._umBusy = true;
      node.setDepth(9999);
      self.tweens.add({
        targets: node, scaleX: 6, scaleY: 6, duration: 620, ease: 'Cubic.easeIn'
      });
      self.time.delayedCall(360, function () {
        self.cameras.main.fadeOut(320, 0, 0, 0);
        self.cameras.main.once('camerafadeoutcomplete', function () { self.scene.start('BlackHoleScene', { from: 'UniverseScene' }); });
      });
    });
  }

  _goTo(scene, data) {
    this.cameras.main.fadeOut(250, 5, 7, 15);
    this.cameras.main.once('camerafadeoutcomplete', () => { this.scene.start(scene, data || {}); });
  }
};
