/**
 * NEBUSTION - QGScene
 * Intérieur du Quartier Général : ouvert en tapant « Entrer › » depuis le panneau du bâtiment
 * QG sur Nexus-01 (PlanetScene). Vraie zone constructible : une grille de 6x6 parcelles, plus
 * grande que l'écran (on la fait glisser au doigt pour l'explorer), où l'on déverrouille des
 * parcelles puis y pose des structures qui apportent de vrais bonus de jeu :
 *   - Générateur : + production de ressources (toutes)
 *   - Silo       : + capacité de stockage
 *   - Tourelle   : + Sécurité de zone (affichage combiné avec le niveau manuel existant)
 * Données pures dans NEBUSTION.QGGrid, glue dans NEBUSTION.QGGridManager (module 11C).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.QGScene = class QGScene extends Phaser.Scene {
  constructor(key) { super(key || 'QGScene'); }

  create() {
    var w = this.scale.width, h = this.scale.height;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(250, 5, 7, 15);
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });

    this.G = NEBUSTION.QGGrid;
    this.GM = NEBUSTION.QGGridManager;

    // ---------- Géométrie de la grille isométrique 2.5D (plus grande que l'écran : on la fait glisser) ----------
    this._initIsoGeometry(0x2e9eff);

    this.viewport = { x: w * 0.055, y: 244, w: w - w * 0.11, h: 730 };

    // Perf : parcelles et structures pré-rendues une seule fois en textures (par état / par type).
    this._buildCellTextures();

    this.fx = new NEBUSTION.FX(this);

    this._buildHeader();
    this._buildInfoBar();
    this._buildRaidBanner();
    this._buildGridLayer();
    this._buildPanel();
    this._buildAttackPanel();
    this._buildPanTarget();

    this.add.text(w / 2, this.viewport.y + this.viewport.h + 26, '↔ Glisse pour explorer la zone ↕', {
      fontFamily: 'Arial, sans-serif', fontSize: '14px', color: '#5c6b8a'
    }).setOrigin(0.5).setDepth(50);

    this._refreshInfoBar();
    this._refreshGrid();

    this.hud = NEBUSTION.HUD.attach(this);

    // Module 28 : fait avancer les chantiers en cours (Observatoire, Balise, Arsenal, Citadelle) ~1x/s
    // et rafraîchit leur décompte affiché, sans dépendre de la boucle update() (la scène peut être en pause).
    this._buildTicker = this.time.addEvent({ delay: 1000, loop: true, callback: () => this._tickBuilds(), callbackScope: this });

    this.events.once('shutdown', () => { this._teardownPan(); if (this._buildTicker) this._buildTicker.remove(); });
  }

  // Avance les chantiers en cours : rafraîchit leur décompte affiché et active ceux qui viennent de finir.
  _tickBuilds() {
    var GM = this.GM, G = this.G;
    var beforeKeys = GM.pendingKeys();
    var done = GM.tick();
    var self = this;
    var refreshed = {};
    beforeKeys.forEach(function (p) {
      var k = p.x + ',' + p.y;
      if (refreshed[k]) return;
      refreshed[k] = true;
      self._refreshCell(p.x, p.y);
    });
    done.forEach(function (d) {
      var p = G.parseKey(d.key), def = G.STRUCTURES[d.id];
      self._refreshCell(p.x, p.y, true);
      var pos = self._tilePos(p.x, p.y);
      var wx = self.gridLayer.x + pos.x, wy = self.gridLayer.y + pos.y;
      if (self.fx) {
        self.fx.ring(wx, wy, def.color, 1.5);
        self.fx.burst('crystal', wx, wy - 20, 12);
        if (self.fx.toast) self.fx.toast('Construction terminée', def.icon + ' ' + def.name + ' est maintenant actif.', null);
      }
    });
    if (done.length) this._refreshInfoBar();
    if (this._panelCell) {
      var col = this._panelCell.col, row = this._panelCell.row, k2 = col + ',' + row;
      var touched = refreshed[k2] || done.some(function (d) { return d.key === k2; });
      if (touched) this._afterAction(col, row);
    }
  }

  // Géométrie isométrique partagée avec EnemyQGScene (QG des bots) ; `accent` = couleur du liseré de la plateforme.
  _initIsoGeometry(accent) {
    this.accent = accent;
    this.TW = 176;           // largeur d'un losange de parcelle (ratio iso 2:1)
    this.TH = 88;            // hauteur d'un losange
    this.slab = 30;          // épaisseur de la plateforme flottante
    this.ox = this.G.ROWS * this.TW / 2 + 44;   // x de la pointe haute de la grille
    this.oy = 170;                              // marge haute (les structures dépassent au-dessus)
    this.contentW = (this.G.COLS + this.G.ROWS) * this.TW / 2 + 88;
    this.contentH = this.oy + (this.G.COLS + this.G.ROWS) * this.TH / 2 + this.slab + 70;
  }

  // ---------- En-tête ----------
  _buildHeader() {
    var w = this.scale.width;
    this.add.text(w / 2, 96, 'QUARTIER GÉNÉRAL', {
      fontFamily: 'Arial, sans-serif', fontSize: '24px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(50).setShadow(0, 0, '#5fd97a', 10, true, true);

    // Module 18 : Caserne (achat de troupes) — les troupes se déploient ensuite au mode combat d'un QG ennemi.
    var barBtn = this.add.text(w / 2, 126, '🪖 Caserne', {
      fontFamily: 'Arial, sans-serif', fontSize: '16px', fontStyle: 'bold', color: '#ffd166'
    }).setOrigin(0.5).setDepth(60).setInteractive({ useHandCursor: true });
    barBtn.on('pointerdown', () => { if (NEBUSTION.TroopsScene) this.scene.start('TroopsScene'); });

    var backBtn = this.add.text(28, 126, '‹ Retour', {
      fontFamily: 'Arial, sans-serif', fontSize: '16px', color: '#00e5ff'
    }).setOrigin(0, 0.5).setDepth(60).setInteractive({ useHandCursor: true });
    backBtn.on('pointerdown', () => this.scene.start('PlanetScene'));

    // Module 17 : lance une attaque contre le QG d'un empire ennemi, avec la flotte de vaisseaux (bots).
    var atkBtn = this.add.text(w - 28, 126, '⚔ Attaquer ›', {
      fontFamily: 'Arial, sans-serif', fontSize: '16px', fontStyle: 'bold', color: '#ff8fa3'
    }).setOrigin(1, 0.5).setDepth(60).setInteractive({ useHandCursor: true });
    atkBtn.on('pointerdown', () => this._openAttackPanel());

    // Trophées de QG : total du joueur, visible en permanence (pas seulement pendant un combat).
    this._trophyChip = this.add.text(w - 28, 96, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '16px', fontStyle: '900', color: '#ffd166'
    }).setOrigin(1, 0.5).setDepth(60);
    this._refreshTrophies();
  }

  _refreshTrophies() {
    if (!this._trophyChip) return;
    var AM = NEBUSTION.QGAttackManager;
    this._trophyChip.setText('🏆 ' + (AM ? AM.trophies() : 0));
  }

  // ---------- Barre de bonus (production / stockage / sécurité) ----------
  _buildInfoBar() {
    var w = this.scale.width, y = 172;
    var chipStyle = { fontFamily: 'Arial, sans-serif', fontSize: '15px', fontStyle: 'bold', color: '#eaf2ff' };
    this._prodChip = this.add.text(w * 0.055, y, '', chipStyle).setOrigin(0, 0.5).setDepth(50);
    this._storChip = this.add.text(w / 2, y, '', chipStyle).setOrigin(0.5, 0.5).setDepth(50);
    this._secChip = this.add.text(w * 0.945, y, '', chipStyle).setOrigin(1, 0.5).setDepth(50);
  }

  _refreshInfoBar() {
    this._refreshTrophies();
    var GM = this.GM, SM = NEBUSTION.SecurityManager;
    var prod = Math.round(GM.bonusValue('production') * 100);
    var stor = Math.round(GM.bonusValue('storage') * 100);
    var sec = SM.effectiveLevel();
    var RM = NEBUSTION.QGRaidManager;
    var threat = RM ? RM.threat() : null;
    var underThreat = !!(threat && threat.attack > sec);
    this._prodChip.setText('⚡ +' + prod + '%');
    this._storChip.setText('📦 +' + stor + '%');
    this._secChip.setText((underThreat ? '⚠️ ' : '🛡️ ') + 'Niv.' + sec).setColor(underThreat ? '#ff8fa3' : '#eaf2ff');

    var n = GM.unlockedCount(), max = this.G.MAX_CELLS;
    if (!this._cellsText) {
      this._cellsText = this.add.text(this.scale.width / 2, 196, '', {
        fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#5c6b8a'
      }).setOrigin(0.5).setDepth(50);
    }
    this._cellsText.setText('Parcelles : ' + n + ' / ' + max);

    this._refreshRaidBanner(threat, sec);
  }

  // ---------- Bannière raids (module 12 : les empires ennemis peuvent riposter contre le QG) ----------
  _buildRaidBanner() {
    var w = this.scale.width;
    this._raidBanner = this.add.text(w / 2, 224, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', fontStyle: 'bold', color: '#5c6b8a', align: 'center',
      wordWrap: { width: w * 0.86 }
    }).setOrigin(0.5).setDepth(50);
  }

  _timeAgo(ms) {
    if (ms < 60000) return 'à l\'instant';
    var min = Math.round(ms / 60000);
    if (min < 60) return 'il y a ' + min + ' min';
    var h = Math.round(min / 60);
    if (h < 24) return 'il y a ' + h + ' h';
    return 'il y a ' + Math.round(h / 24) + ' j';
  }

  _empireName(eid) {
    var E = NEBUSTION.Galaxy && NEBUSTION.Galaxy.empire ? NEBUSTION.Galaxy.empire(eid) : null;
    var name = (E && E.name) || eid;
    var BB = NEBUSTION.BotBases;
    return BB ? BB.handleOf(eid) + ' (' + name + ')' : name;
  }

  _refreshRaidBanner(threat, sec) {
    if (!this._raidBanner) return;
    var RM = NEBUSTION.QGRaidManager;
    var last = RM ? RM.lastRaid() : null;
    var txt, color;
    if (!last) {
      txt = '🛰️ Zone calme — aucun raid ennemi signalé pour l\'instant.';
      color = '#5c6b8a';
    } else if (last.victory) {
      txt = '💥 Raid ennemi réussi ' + this._timeAgo(Date.now() - last.at) + ' — ' + this._empireName(last.empire) + ', -' + Math.round(last.lossPct * 100) + ' % de ressources pillées.';
      color = '#ff8fa3';
    } else {
      txt = '🛡️ Raid ennemi repoussé ' + this._timeAgo(Date.now() - last.at) + ' — ' + this._empireName(last.empire) + '.';
      color = '#5fd97a';
    }
    if (threat && sec != null && threat.attack > sec) {
      txt += '  ⚠️ Menace actuelle élevée : renforcez la Sécurité ou les Tourelles.';
    }
    this._raidBanner.setText(txt).setColor(color);
  }

  // ---------- Grille isométrique 2.5D (contenu pannable, découpé au rectangle `viewport`) ----------
  // Rendu « 2D-3D stylisé » : plateforme flottante en losange avec épaisseur, parcelles isométriques
  // (2:1), vraies structures dessinées en volumes (boîtes/cylindres ombrés) avec animations légères.
  // Toute la logique de jeu (QGGrid / QGGridManager) reste inchangée : seul le rendu a changé.
  _buildGridLayer() {
    var v = this.viewport;

    var maskShape = this.make.graphics({ x: 0, y: 0, add: false });
    maskShape.fillStyle(0xffffff);
    maskShape.fillRoundedRect(v.x, v.y, v.w, v.h, 18);

    var frame = this.add.graphics().setDepth(40);
    frame.fillGradientStyle(0x0d1428, 0x0d1428, 0x060a16, 0x060a16, 0.55);
    frame.fillRoundedRect(v.x, v.y, v.w, v.h, 18);
    frame.lineStyle(2, this.accent || 0x2e9eff, 0.45);
    frame.strokeRoundedRect(v.x, v.y, v.w, v.h, 18);

    this.gridLayer = this.add.container(0, 0).setDepth(41);
    this.gridLayer.setMask(maskShape.createGeometryMask());

    this._buildPlatform();

    // Vue initiale : centrée sur le noyau de départ (2x2 au milieu de la grille).
    var mid = this._tilePos(2, 2);
    var midB = this._tilePos(3, 3);
    var focusX = (mid.x + midB.x) / 2, focusY = (mid.y + midB.y) / 2;
    var cx0 = this._clampAxis(v.x + v.w / 2 - focusX, this.contentW, v.x, v.w);
    var cy0 = this._clampAxis(v.y + v.h / 2 - focusY, this.contentH, v.y, v.h);
    this.gridLayer.setPosition(cx0, cy0);
  }

  // Centre (en coordonnées du calque) du losange de la parcelle (col,row).
  _tilePos(col, row) {
    return {
      x: this.ox + (col - row) * this.TW / 2,
      y: this.oy + (col + row) * this.TH / 2 + this.TH / 2
    };
  }

  _poly(pts) { return pts.map(function (p) { return { x: p[0], y: p[1] }; }); }

  // Plateforme flottante : dalle épaisse, faces latérales, liseré lumineux, réacteurs dessous.
  _buildPlatform() {
    var G = this.G, TW = this.TW, TH = this.TH, ox = this.ox, oy = this.oy, T = this.slab, pm = 26;
    var top = [ox, oy - pm / 2];
    var right = [ox + G.COLS * TW / 2 + pm, oy + G.COLS * TH / 2];
    var bottom = [ox + (G.COLS - G.ROWS) * TW / 2, oy + (G.COLS + G.ROWS) * TH / 2 + pm / 2];
    var left = [ox - G.ROWS * TW / 2 - pm, oy + G.ROWS * TH / 2];
    var add = (o) => { o.setDepth(-30); this.gridLayer.add(o); return o; };

    // Halo sous la plateforme (effet flottant)
    var under = this.add.image(bottom[0], bottom[1] + T + 40, 'tex_glow_white').setDisplaySize(TW * 5, TH * 2.4)
      .setTint((this.accent || 0x2e9eff)).setAlpha(0.22).setBlendMode(Phaser.BlendModes.ADD);
    add(under);

    var g = this.add.graphics();
    add(g);
    // faces latérales (épaisseur)
    g.fillStyle(0x0b1428, 1);
    g.fillPoints(this._poly([left, bottom, [bottom[0], bottom[1] + T], [left[0], left[1] + T]]), true);
    g.fillStyle(0x060c1b, 1);
    g.fillPoints(this._poly([bottom, right, [right[0], right[1] + T], [bottom[0], bottom[1] + T]]), true);
    // bandes lumineuses + joints de panneaux sur les faces
    g.lineStyle(2, (this.accent || 0x2e9eff), 0.5);
    g.lineBetween(left[0], left[1] + T * 0.55, bottom[0], bottom[1] + T * 0.55);
    g.lineBetween(bottom[0], bottom[1] + T * 0.55, right[0], right[1] + T * 0.55);
    g.lineStyle(1, 0x1c2c52, 0.9);
    for (var i = 1; i < 8; i++) {
      var t = i / 8;
      var lx = left[0] + (bottom[0] - left[0]) * t, ly = left[1] + (bottom[1] - left[1]) * t;
      g.lineBetween(lx, ly, lx, ly + T);
      var rx = bottom[0] + (right[0] - bottom[0]) * t, ry = bottom[1] + (right[1] - bottom[1]) * t;
      g.lineBetween(rx, ry, rx, ry + T);
    }
    g.lineStyle(2, (this.accent || 0x2e9eff), 0.8);
    g.lineBetween(left[0], left[1] + T, bottom[0], bottom[1] + T);
    g.lineBetween(bottom[0], bottom[1] + T, right[0], right[1] + T);

    // dessus de la dalle
    g.fillStyle(0x0a1226, 1);
    g.fillPoints(this._poly([top, right, bottom, left]), true);
    g.lineStyle(3, (this.accent || 0x2e9eff), 0.75);
    g.strokePoints(this._poly([top, right, bottom, left]), true);
    g.lineStyle(1, 0x54e7ff, 0.18);
    g.strokePoints(this._poly([
      [top[0], top[1] + 8], [right[0] - 16, right[1]], [bottom[0], bottom[1] - 8], [left[0] + 16, left[1]]
    ]), true);

    // Quadrillage isométrique très discret (visible dans les interstices entre parcelles)
    g.lineStyle(1, 0x16305a, 0.35);
    for (var k = 0; k <= G.COLS; k++) {
      var a = this._tilePos(0, 0), s0 = ox + (k - 0) * TW / 2, s1 = oy + k * TH / 2;
      g.lineBetween(s0, s1, s0 - G.ROWS * TW / 2, s1 + G.ROWS * TH / 2);
      g.lineBetween(ox - k * TW / 2, oy + k * TH / 2, ox - k * TW / 2 + G.COLS * TW / 2, oy + k * TH / 2 + G.COLS * TH / 2);
    }

    // Petits feux de balisage le long du bord avant
    g.fillStyle(0x7bdfff, 0.9);
    for (var j = 1; j < 12; j++) {
      var u = j / 12;
      g.fillCircle(left[0] + (bottom[0] - left[0]) * u, left[1] + (bottom[1] - left[1]) * u + 3, 2.2);
      g.fillCircle(bottom[0] + (right[0] - bottom[0]) * u, bottom[1] + (right[1] - bottom[1]) * u + 3, 2.2);
    }

    // Réacteurs sous la plateforme (pulsation)
    [[left, bottom, 0.3], [left, bottom, 0.72], [bottom, right, 0.28], [bottom, right, 0.7]].forEach((c) => {
      var px = c[0][0] + (c[1][0] - c[0][0]) * c[2], py = c[0][1] + (c[1][1] - c[0][1]) * c[2] + T + 4;
      var f = add(this.add.image(px, py, 'tex_glow_white').setDisplaySize(120, 70)
        .setTint(0x54c8ff).setAlpha(0.6).setBlendMode(Phaser.BlendModes.ADD));
      this._trackTween(f, this.tweens.add({
        targets: f, alpha: 0.25, scaleX: f.scaleX * 0.8, duration: 700 + Math.random() * 500, yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
      }));
    });
  }

  _trackTween(node, tw) { (node._tw = node._tw || []).push(tw); return tw; }
  _killNode(n) {
    if (!n) return;
    if (n._tw) n._tw.forEach(function (t) { t.stop(); });
    n.destroy();
  }

  // Mélange linéaire de deux couleurs hex (0xRRGGBB), t dans [0,1]
  _mix(c1, c2, t) {
    var r1 = (c1 >> 16) & 255, g1 = (c1 >> 8) & 255, b1 = c1 & 255;
    var r2 = (c2 >> 16) & 255, g2 = (c2 >> 8) & 255, b2 = c2 & 255;
    var r = Math.round(r1 + (r2 - r1) * t), g = Math.round(g1 + (g2 - g1) * t), b = Math.round(b1 + (b2 - b1) * t);
    return (r << 16) | (g << 8) | b;
  }

  _clampAxis(pos, contentSize, viewPos, viewSize) {
    if (contentSize <= viewSize) return viewPos + (viewSize - contentSize) / 2;
    var minPos = viewPos + viewSize - contentSize;
    var maxPos = viewPos;
    return Phaser.Math.Clamp(pos, minPos, maxPos);
  }

  // ---------- Primitives de dessin isométrique (Graphics) ----------
  // Dalle losange avec épaisseur : centre (cx,cy), demi-largeur hw, demi-hauteur hh, épaisseur th.
  _isoTile(g, cx, cy, hw, hh, th, topC, leftC, rightC, edgeC, edgeA) {
    g.fillStyle(leftC, 1);
    g.fillPoints(this._poly([[cx - hw, cy], [cx, cy + hh], [cx, cy + hh + th], [cx - hw, cy + th]]), true);
    g.fillStyle(rightC, 1);
    g.fillPoints(this._poly([[cx, cy + hh], [cx + hw, cy], [cx + hw, cy + th], [cx, cy + hh + th]]), true);
    g.fillStyle(topC, 1);
    var t = this._poly([[cx, cy - hh], [cx + hw, cy], [cx, cy + hh], [cx - hw, cy]]);
    g.fillPoints(t, true);
    g.lineStyle(2, edgeC, edgeA);
    g.strokePoints(t, true);
  }

  // Boîte isométrique posée au sol : centre au sol (cx,cy), demi-largeur a, hauteur h.
  _box(g, cx, cy, a, h, topC, leftC, rightC, edge) {
    var b = a / 2;
    g.fillStyle(leftC, 1);
    g.fillPoints(this._poly([[cx - a, cy], [cx, cy + b], [cx, cy + b - h], [cx - a, cy - h]]), true);
    g.fillStyle(rightC, 1);
    g.fillPoints(this._poly([[cx, cy + b], [cx + a, cy], [cx + a, cy - h], [cx, cy + b - h]]), true);
    g.fillStyle(topC, 1);
    var t = this._poly([[cx, cy - b - h], [cx + a, cy - h], [cx, cy + b - h], [cx - a, cy - h]]);
    g.fillPoints(t, true);
    g.lineStyle(1.5, edge, 0.85);
    g.strokePoints(t, true);
    g.lineBetween(cx, cy + b - h, cx, cy + b);
    g.lineBetween(cx - a, cy - h, cx - a, cy);
    g.lineBetween(cx + a, cy - h, cx + a, cy);
  }

  // Cylindre vertical ombré (gauche clair → droite sombre) : centre au sol (cx,cy), rayon r, hauteur h.
  _cyl(g, cx, cy, r, h, light, mid, dark, topC, edge) {
    var ry = r / 2;
    g.fillStyle(mid, 1);
    g.fillEllipse(cx, cy, r * 2, ry * 2);
    g.fillRect(cx - r, cy - h, r * 2, h);
    g.fillStyle(light, 1);
    g.fillRect(cx - r, cy - h, r * 0.7, h);
    g.fillStyle(dark, 1);
    g.fillRect(cx + r * 0.35, cy - h, r * 0.65, h);
    g.fillStyle(dark, 1);
    g.fillEllipse(cx + r * 0.35 + (r * 0.65) / 2, cy, r * 0.65, ry * 0.9);
    g.fillStyle(light, 1);
    g.fillEllipse(cx - r * 0.65, cy, r * 0.7, ry * 0.9);
    g.fillStyle(topC, 1);
    g.fillEllipse(cx, cy - h, r * 2, ry * 2);
    g.lineStyle(1.5, edge, 0.85);
    g.strokeEllipse(cx, cy - h, r * 2, ry * 2);
    g.lineBetween(cx - r, cy, cx - r, cy - h);
    g.lineBetween(cx + r, cy, cx + r, cy - h);
  }

  // Anneau sur la face avant d'un cylindre (demi-ellipse basse).
  _band(g, cx, cy, r, lw, color, alpha) {
    var pts = [];
    for (var i = 0; i <= 18; i++) {
      var t = Math.PI * i / 18;
      pts.push({ x: cx + r * Math.cos(t), y: cy + (r / 2) * Math.sin(t) });
    }
    g.lineStyle(lw, color, alpha);
    g.strokePoints(pts, false);
  }

  _dome(g, cx, cy, r, ry, color, edge) {
    var pts = [];
    for (var i = 0; i <= 24; i++) {
      var t = Math.PI + Math.PI * i / 24;
      pts.push({ x: cx + r * Math.cos(t), y: cy + ry * Math.sin(t) });
    }
    g.fillStyle(color, 1);
    g.fillPoints(pts, true);
    g.lineStyle(1.5, edge, 0.8);
    g.strokePoints(pts, false);
  }

  _genTex(key, w, h, drawFn) {
    if (this.textures.exists(key)) return;
    var g = this.make.graphics({ x: 0, y: 0, add: false });
    drawFn(g);
    g.generateTexture(key, w, h);
    g.destroy();
  }

  // Pré-rendu des textures (une fois) : 3 états de parcelle + 1 volume par structure.
  _buildCellTextures() {
    var TW = this.TW, TH = this.TH, th = 10, G = this.G;
    var texH = TH + th + 6, cy = TH / 2 + 3, hw = TW / 2 * 0.95, hh = TH / 2 * 0.95;
    this._tileTexH = texH; this._tileCY = cy;

    this._genTex('qgiso_locked', TW, texH, (g) => {
      this._isoTile(g, TW / 2, cy, hw, hh, th, 0x0b1020, 0x070a14, 0x05070f, 0x22304f, 0.9);
      // roche / cristaux sombres (déterministe)
      [[-46, -4, 12], [28, 8, 10], [-8, 14, 8], [52, -8, 9], [-62, 10, 7]].forEach((r) => {
        var x = TW / 2 + r[0], y = cy + r[1], s = r[2];
        g.fillStyle(0x17223d, 1);
        g.fillPoints(this._poly([[x, y - s * 1.3], [x + s * 0.8, y], [x, y + s * 0.5], [x - s * 0.8, y]]), true);
        g.fillStyle(0x24365f, 1);
        g.fillPoints(this._poly([[x, y - s * 1.3], [x + s * 0.8, y], [x, y]]), true);
      });
      g.lineStyle(1, 0x16223f, 0.6);
      for (var i = -3; i <= 3; i++) g.lineBetween(TW / 2 + i * 22 - 20, cy - 12 + i * 2, TW / 2 + i * 22 + 10, cy + 8 + i * 2);
    });

    this._genTex('qgiso_free', TW, texH, (g) => {
      this._isoTile(g, TW / 2, cy, hw, hh, th, 0x15264a, 0x0b1428, 0x070d1c, 0x2e9eff, 0.85);
      // plaque intérieure
      var iw = hw * 0.74, ih = hh * 0.74;
      g.fillStyle(0x0e1b36, 1);
      g.fillPoints(this._poly([[TW / 2, cy - ih], [TW / 2 + iw, cy], [TW / 2, cy + ih], [TW / 2 - iw, cy]]), true);
      g.lineStyle(1.5, 0x2e9eff, 0.4);
      g.strokePoints(this._poly([[TW / 2, cy - ih], [TW / 2 + iw, cy], [TW / 2, cy + ih], [TW / 2 - iw, cy]]), true);
      // équerres lumineuses aux 4 sommets
      var V = [[TW / 2, cy - hh], [TW / 2 + hw, cy], [TW / 2, cy + hh], [TW / 2 - hw, cy]];
      g.lineStyle(3, 0x5fc9ff, 0.9);
      for (var i = 0; i < 4; i++) {
        var p = V[i], n = V[(i + 1) % 4], q = V[(i + 3) % 4];
        g.lineBetween(p[0], p[1], p[0] + (n[0] - p[0]) * 0.22, p[1] + (n[1] - p[1]) * 0.22);
        g.lineBetween(p[0], p[1], p[0] + (q[0] - p[0]) * 0.22, p[1] + (q[1] - p[1]) * 0.22);
      }
    });

    G.STRUCTURE_ORDER.forEach((sid) => {
      var def = G.STRUCTURES[sid];
      var top = this._mix(def.color, 0x05070f, 0.72), inner = this._mix(def.color, 0x05070f, 0.84);
      this._genTex('qgiso_pad_' + sid, TW, texH, (g) => {
        this._isoTile(g, TW / 2, cy, hw, hh, th, top, this._mix(def.color, 0x05070f, 0.82), this._mix(def.color, 0x05070f, 0.9), def.color, 0.95);
        var iw = hw * 0.8, ih = hh * 0.8;
        var ring = this._poly([[TW / 2, cy - ih], [TW / 2 + iw, cy], [TW / 2, cy + ih], [TW / 2 - iw, cy]]);
        g.fillStyle(inner, 1); g.fillPoints(ring, true);
        g.lineStyle(2, def.color, 0.85); g.strokePoints(ring, true);
      });
      this._genTex('qgiso_b_' + sid, 170, 220, (g) => this._drawStructure(g, sid));
    });
  }

  // Volume de chaque structure — sol au centre (85,170) de la texture 170x220.
  _drawStructure(g, sid) {
    var gx = 85, gy = 170;
    g.fillStyle(0x000000, 0.38);
    g.fillEllipse(gx, gy + 2, 150, 64);

    if (sid === 'generator') {
      this._box(g, gx, gy, 64, 10, 0x2c3852, 0x1d2740, 0x131a2c, 0x4fe3ff);
      // cuves latérales
      this._cyl(g, gx - 50, gy - 4, 10, 24, 0x5a6a8c, 0x3c4a68, 0x252f47, 0x6a7899, 0x4fe3ff);
      this._cyl(g, gx + 50, gy - 4, 10, 24, 0x5a6a8c, 0x3c4a68, 0x252f47, 0x6a7899, 0x4fe3ff);
      g.lineStyle(3, 0x4fe3ff, 0.6);
      g.lineBetween(gx - 50, gy - 28, gx - 26, gy - 46); g.lineBetween(gx + 50, gy - 28, gx + 26, gy - 46);
      // caisson moteur
      this._box(g, gx, gy - 10, 46, 36, 0x33415f, 0x222c45, 0x161d31, 0x4fe3ff);
      g.lineStyle(2, 0x4fe3ff, 0.45);
      [10, 18, 26].forEach(function (hh) { g.lineBetween(gx - 36, gy - 10 - hh + 5, gx - 12, gy - 10 - hh + 17); });
      g.fillStyle(0x5fe39a, 1); g.fillCircle(gx + 22, gy - 21, 3);
      g.fillStyle(0xffc86b, 1); g.fillCircle(gx + 32, gy - 27, 2.5);
      // cœur en verre
      this._cyl(g, gx, gy - 46, 27, 44, 0x2a8fab, 0x136a82, 0x0b2f3b, 0x2ab4d4, 0x4fe3ff);
      g.fillStyle(0x4fe3ff, 0.35); g.fillRoundedRect(gx - 12, gy - 46 - 40, 24, 36, 8);
      g.fillStyle(0xd4fbff, 0.95); g.fillRoundedRect(gx - 5, gy - 46 - 37, 10, 30, 5);
      [10, 22, 34].forEach((yy) => this._band(g, gx, gy - 46 - yy, 27, 3, 0x4fe3ff, 0.9));
      // chapeau + antenne
      this._cyl(g, gx, gy - 90, 31, 7, 0x6a7899, 0x4a5673, 0x2c3450, 0x7c8bb0, 0x4fe3ff);
      g.lineStyle(3, 0x4fe3ff, 0.9); g.lineBetween(gx, gy - 97, gx, gy - 112);
      g.fillStyle(0xd4fbff, 1); g.fillCircle(gx, gy - 114, 3.5);
    } else if (sid === 'silo') {
      this._box(g, gx, gy, 58, 8, 0x3a4560, 0x293249, 0x1b2236, 0xc9d4ea);
      this._cyl(g, gx, gy - 8, 38, 92, 0x9db0d0, 0x6f81a5, 0x3f4b68, 0x8fa3c6, 0xc9d4ea);
      this._band(g, gx, gy - 16, 38, 6, 0xffc86b, 0.85);
      [30, 54, 78].forEach((yy) => this._band(g, gx, gy - 8 - yy, 38, 2.5, 0x2b3550, 0.9));
      // échelle
      g.lineStyle(2, 0x2b3550, 0.9);
      g.lineBetween(gx + 12, gy - 6, gx + 12, gy - 92); g.lineBetween(gx + 22, gy - 4, gx + 22, gy - 90);
      for (var i = 0; i < 9; i++) g.lineBetween(gx + 12, gy - 14 - i * 9, gx + 22, gy - 12 - i * 9);
      // dôme
      this._dome(g, gx, gy - 100, 38, 30, 0xb5c5e0, 0xc9d4ea);
      g.fillStyle(0xffffff, 0.28); g.fillEllipse(gx - 14, gy - 118, 18, 8);
      this._band(g, gx, gy - 100, 38, 2, 0x8fa3c6, 0.9);
      g.lineStyle(3, 0xc9d4ea, 0.9); g.lineBetween(gx, gy - 130, gx, gy - 146);
      g.fillStyle(0xff6b6b, 1); g.fillCircle(gx, gy - 148, 3.5);
      // tuyau de remplissage
      this._cyl(g, gx + 54, gy - 4, 8, 30, 0x7c8bb0, 0x55628a, 0x353f5c, 0x8a98bb, 0xc9d4ea);
      g.lineStyle(5, 0x55628a, 1); g.lineBetween(gx + 54, gy - 34, gx + 34, gy - 46);
    } else if (sid === 'wall') {
      // Barricade : mur bas de plots renforcés, bandes de danger
      this._box(g, gx, gy, 66, 12, 0x4a3a26, 0x33281a, 0x221a11, 0xffb04f);
      this._box(g, gx, gy - 12, 58, 26, 0x6b5636, 0x4d3d26, 0x33281a, 0xffb04f);
      g.fillStyle(0xffb04f, 0.9);
      [-30, -10, 10, 30].forEach(function (dx) { g.fillRect(gx + dx - 4, gy - 30, 8, 12); });
      g.lineStyle(3, 0x1d1610, 0.9);
      g.lineBetween(gx - 34, gy - 6, gx - 14, gy - 22); g.lineBetween(gx - 6, gy - 6, gx + 14, gy - 22); g.lineBetween(gx + 22, gy - 6, gx + 40, gy - 22);
      g.lineStyle(2, 0xffd59a, 0.8); g.strokeRect(gx - 29, gy - 38, 58, 26);
    } else if (sid === 'barracks') {
      // Caserne : bâtiment militaire à toit plat, porte blindée, fenêtres éclairées, drapeau
      this._box(g, gx, gy, 66, 10, 0x4a2f2a, 0x33201c, 0x221410, 0xff7a59);
      this._box(g, gx - 4, gy - 10, 50, 36, 0x8a4a3c, 0x5f3229, 0x40211b, 0xff7a59);
      this._box(g, gx - 4, gy - 46, 56, 8, 0xb5604c, 0x7a3d30, 0x522820, 0xffb09a);
      // fenêtres sur la face droite (bord haut de la face : de (gx-4, gy-21) à (gx+46, gy-46))
      [0.2, 0.58].forEach((t) => {
        var x0 = gx - 4 + 50 * t, x1 = x0 + 12, y0 = (gy - 21) - 25 * t, y1 = (gy - 21) - 25 * (t + 0.24);
        g.fillStyle(0xffd166, 0.92);
        g.fillPoints(this._poly([[x0, y0 + 10], [x1, y1 + 10], [x1, y1 + 22], [x0, y0 + 22]]), true);
      });
      // porte blindée sur la face gauche
      g.fillStyle(0x1a0f0c, 1);
      g.fillPoints(this._poly([[gx - 30, gy + 2], [gx - 18, gy + 8], [gx - 18, gy - 16], [gx - 30, gy - 22]]), true);
      g.lineStyle(2, 0xff7a59, 0.9); g.lineBetween(gx - 24, gy + 5, gx - 24, gy - 19);
      // mât + drapeau
      g.lineStyle(3, 0xc9d4ea, 1); g.lineBetween(gx - 40, gy - 50, gx - 40, gy - 96);
      g.fillStyle(0xff4d4d, 1); g.fillPoints(this._poly([[gx - 40, gy - 96], [gx - 12, gy - 88], [gx - 40, gy - 78]]), true);
      // sacs de sable
      g.fillStyle(0x8a7a52, 1); [[gx + 44, gy + 8], [gx + 56, gy + 4], [gx + 50, gy - 2]].forEach(function (q) { g.fillEllipse(q[0], q[1], 16, 9); });
    } else if (sid === 'workshop') {
      // Atelier d'armement : hall industriel, cheminée fumante, grand engrenage
      this._box(g, gx, gy, 62, 10, 0x4b4130, 0x342d20, 0x211c13, 0xffd166);
      this._box(g, gx - 6, gy - 10, 44, 30, 0x6b5a2e, 0x4a3e20, 0x30280f, 0xffd166);
      g.fillStyle(0xffd166, 0.85); [[gx + 6, gy - 4], [gx + 18, gy - 10]].forEach(function (q) { g.fillRect(q[0], q[1] - 12, 8, 7); });
      this._cyl(g, gx + 34, gy - 22, 8, 46, 0x8a8a99, 0x666677, 0x3f3f4d, 0x9a9aab, 0xffd166);
      this._band(g, gx + 34, gy - 58, 8, 3, 0xffd166, 0.9);
      // engrenage (dents en étoile + moyeu)
      var gcx = gx - 12, gcy = gy - 54;
      g.fillStyle(0xc9a13f, 1);
      for (var gt = 0; gt < 8; gt++) { var ga = gt * Math.PI / 4; g.fillCircle(gcx + Math.cos(ga) * 19, gcy + Math.sin(ga) * 19, 5); }
      g.fillCircle(gcx, gcy, 17);
      g.fillStyle(0x4b4130, 1); g.fillCircle(gcx, gcy, 8);
      g.lineStyle(2, 0xffd166, 0.9); g.strokeCircle(gcx, gcy, 17); g.fillStyle(0xffd166, 1); g.fillCircle(gcx, gcy, 3);
      // enclume
      g.fillStyle(0x2b3550, 1); g.fillRect(gx + 40, gy + 2, 18, 6); g.fillRect(gx + 44, gy + 8, 10, 5);
    } else if (sid === 'lab') {
      // Bio-labo : cuve de verre contenant un embryon luminescent, dôme, tubulures
      this._box(g, gx, gy, 62, 10, 0x35284a, 0x241a35, 0x16101f, 0xd77cff);
      this._cyl(g, gx - 36, gy - 4, 9, 30, 0x6a5a8c, 0x4a3e68, 0x2a2247, 0x7a6a99, 0xd77cff);
      this._cyl(g, gx + 36, gy - 4, 9, 30, 0x6a5a8c, 0x4a3e68, 0x2a2247, 0x7a6a99, 0xd77cff);
      this._cyl(g, gx, gy - 8, 30, 70, 0x8a4fb0, 0x5f2f88, 0x3a1b58, 0xb56cdb, 0xd77cff);
      g.fillStyle(0xe6b0ff, 0.28); g.fillRoundedRect(gx - 22, gy - 8 - 62, 44, 56, 12);
      g.fillStyle(0x7dffb0, 0.75); g.fillEllipse(gx, gy - 40, 20, 26);            // embryon
      g.fillStyle(0xeafff2, 0.9); g.fillCircle(gx + 4, gy - 46, 3);
      [[-12, -22], [10, -30], [-6, -58], [14, -50]].forEach(function (q) { g.fillStyle(0xffffff, 0.55); g.fillCircle(gx + q[0], gy + q[1], 2.4); });   // bulles
      this._band(g, gx, gy - 8 - 20, 30, 2.5, 0xd77cff, 0.9); this._band(g, gx, gy - 8 - 46, 30, 2.5, 0xd77cff, 0.9);
      this._dome(g, gx, gy - 78, 30, 20, 0xb56cdb, 0xe6b0ff);
      g.lineStyle(3, 0xd77cff, 0.8); g.lineBetween(gx - 36, gy - 34, gx - 24, gy - 60); g.lineBetween(gx + 36, gy - 34, gx + 24, gy - 60);
    } else if (sid === 'radar') {
      // Radar : mât treillis, grande parabole inclinée, balise
      this._box(g, gx, gy, 54, 12, 0x20304f, 0x162238, 0x0d1524, 0x3f8cff);
      this._box(g, gx, gy - 12, 26, 20, 0x2c4270, 0x1d2d4d, 0x111b30, 0x3f8cff);
      g.lineStyle(5, 0x9db0d0, 1); g.lineBetween(gx, gy - 32, gx, gy - 92);
      g.lineStyle(2, 0x3f8cff, 0.85); [-50, -66, -82].forEach(function (yy) { g.lineBetween(gx - 8, gy + yy + 6, gx + 8, gy + yy - 6); g.lineBetween(gx - 8, gy + yy - 6, gx + 8, gy + yy + 6); });
      // parabole
      g.fillStyle(0xc9d4ea, 1); g.fillEllipse(gx + 4, gy - 104, 74, 40);
      g.fillStyle(0x6f81a5, 1); g.fillEllipse(gx + 6, gy - 102, 58, 30);
      g.lineStyle(2, 0x3f8cff, 0.95); g.strokeEllipse(gx + 4, gy - 104, 74, 40);
      g.lineStyle(3, 0x3f8cff, 1); g.lineBetween(gx + 6, gy - 102, gx + 22, gy - 130); g.fillStyle(0xff6b6b, 1); g.fillCircle(gx + 23, gy - 132, 3.5);
      g.lineStyle(2, 0x7dbcff, 0.6); g.strokeCircle(gx + 4, gy - 104, 44); 
    } else if (sid === 'refinery') {
      // Raffinerie : cuves de traitement, tour de distillation, torchère
      this._box(g, gx, gy, 66, 8, 0x1f3d38, 0x142b27, 0x0b1a17, 0x2ee6b8);
      this._cyl(g, gx - 34, gy - 6, 20, 44, 0x2fb59a, 0x1f8571, 0x114d42, 0x3fd2b3, 0x2ee6b8);
      this._cyl(g, gx + 30, gy - 4, 16, 34, 0x2fb59a, 0x1f8571, 0x114d42, 0x3fd2b3, 0x2ee6b8);
      this._band(g, gx - 34, gy - 6 - 22, 20, 3, 0xffc86b, 0.85); this._band(g, gx + 30, gy - 4 - 16, 16, 3, 0xffc86b, 0.85);
      // tour de distillation
      this._cyl(g, gx - 2, gy - 20, 10, 92, 0x9db0d0, 0x6f81a5, 0x3f4b68, 0x8fa3c6, 0x2ee6b8);
      [24, 48, 72].forEach((yy) => this._band(g, gx - 2, gy - 20 - yy, 10, 3, 0x2ee6b8, 0.9));
      // tuyaux
      g.lineStyle(6, 0x55628a, 1); g.lineBetween(gx - 26, gy - 40, gx - 6, gy - 60); g.lineBetween(gx + 26, gy - 28, gx + 4, gy - 44);
      // torchère
      g.lineStyle(4, 0x8fa3c6, 1); g.lineBetween(gx + 48, gy - 4, gx + 48, gy - 80);
      g.fillStyle(0xff8a3d, 1); g.fillPoints(this._poly([[gx + 48, gy - 104], [gx + 56, gy - 84], [gx + 48, gy - 78], [gx + 40, gy - 84]]), true);
      g.fillStyle(0xffe08a, 1); g.fillPoints(this._poly([[gx + 48, gy - 96], [gx + 52, gy - 84], [gx + 48, gy - 80], [gx + 44, gy - 84]]), true);
    } else {
      this._box(g, gx, gy, 64, 14, 0x27402f, 0x1b2f22, 0x12211a, 0x5fd97a);
      // plots de renfort aux coins
      g.fillStyle(0x5fd97a, 0.85);
      [[-44, -10], [44, -10], [0, 20]].forEach(function (p) { g.fillCircle(gx + p[0], gy + p[1] - 14 + 12, 2.5); });
      this._cyl(g, gx, gy - 14, 30, 18, 0x4f7f5c, 0x35583f, 0x22392a, 0x5c8f6a, 0x5fd97a);
      this._band(g, gx, gy - 24, 30, 2, 0x5fd97a, 0.7);
      // tête pivotante
      this._box(g, gx, gy - 32, 36, 26, 0x3c6a4a, 0x2b4c35, 0x1b3324, 0x5fd97a);
      // radar
      g.lineStyle(3, 0x5fd97a, 0.9); g.lineBetween(gx - 14, gy - 58, gx - 14, gy - 76);
      g.lineStyle(2, 0xc7ffe1, 0.9); g.strokeEllipse(gx - 14, gy - 78, 24, 10);
      // canons jumeaux
      [[10, -52, 66, -22], [2, -58, 58, -28]].forEach(function (b) {
        g.lineStyle(11, 0x16231b, 1); g.lineBetween(gx + b[0], gy + b[1], gx + b[2], gy + b[3]);
        g.lineStyle(4, 0x5fd97a, 0.6); g.lineBetween(gx + b[0], gy + b[1] - 3, gx + b[2], gy + b[3] - 3);
        g.fillStyle(0x0d1610, 1); g.fillCircle(gx + b[2], gy + b[3], 6.5);
        g.lineStyle(2, 0x5fd97a, 0.95); g.strokeCircle(gx + b[2], gy + b[3], 6.5);
      });
      g.fillStyle(0x5fd97a, 1); g.fillCircle(gx + 2, gy - 64, 3);
    }
  }

  _refreshGrid() {
    if (this._cellNodes) this._cellNodes.forEach((n) => this._killNode(n));
    this._cellNodes = [];
    var G = this.G;
    for (var row = 0; row < G.ROWS; row++) {
      for (var col = 0; col < G.COLS; col++) {
        var node = this._buildCellNode(col, row, false);
        this.gridLayer.add(node);
        this._cellNodes.push(node);
      }
    }
    this.gridLayer.sort('depth');
    this._refreshInfoBar();
  }

  // Rafraîchit UNE seule case (après construction/vente/déverrouillage).
  _refreshCell(col, row, animate) {
    var idx = row * this.G.COLS + col;
    var old = this._cellNodes && this._cellNodes[idx];
    if (old) this._killNode(old);
    var node = this._buildCellNode(col, row, !!animate);
    this.gridLayer.add(node);
    this._cellNodes[idx] = node;
    this.gridLayer.sort('depth');
  }

  _buildCellNode(col, row, animate) {
    var G = this.G, GM = this.GM, TH = this.TH;
    var unlocked = GM.isUnlocked(col, row);
    var sid = unlocked ? GM.structureAt(col, row) : null;
    var pend = unlocked && !sid ? GM.pendingAt(col, row) : null;
    var p = this._tilePos(col, row);
    var c = this.add.container(p.x, p.y).setDepth(col + row);
    var oy = this._tileCY / this._tileTexH;
    var self = this;

    if (pend) {
      var pdef = G.STRUCTURES[pend.id];
      c.add(this.add.image(0, 0, 'qgiso_pad_' + pend.id).setOrigin(0.5, oy));
      var pbld = this.add.image(0, 2, 'qgiso_b_' + pend.id).setOrigin(0.5, 170 / 220).setAlpha(0.4).setTint(0x3a4560);
      c.add(pbld);
      var total = (pdef.buildTimeSec || 1) * 1000;
      var left = GM.remainingMs(col, row);
      var ratio = Phaser.Math.Clamp(1 - left / total, 0, 1);
      var barW = this.TW * 0.5;
      var bar = this.add.graphics();
      bar.fillStyle(0x0a1020, 0.85); bar.fillRoundedRect(-barW / 2, TH * 0.16, barW, 8, 4);
      bar.fillStyle(pdef.color, 0.95); bar.fillRoundedRect(-barW / 2, TH * 0.16, Math.max(4, barW * ratio), 8, 4);
      c.add(bar);
      c.add(this.add.text(0, TH * 0.3, '🚧 ' + (this._timeLeft(left) || '< 1 min'), {
        fontFamily: 'Arial, sans-serif', fontSize: '11px', fontStyle: 'bold', color: '#ffd166'
      }).setOrigin(0.5).setShadow(1, 1, '#05070f', 3, true, true));
      this._trackTween(c, this.tweens.add({ targets: pbld, alpha: 0.55, duration: 900, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' }));
    } else if (sid) {
      var def = G.STRUCTURES[sid];
      c.add(this.add.image(0, 0, 'qgiso_pad_' + sid).setOrigin(0.5, oy));
      var glow = this.add.image(0, 2, 'tex_glow_white').setDisplaySize(this.TW * 1.05, TH * 1.15)
        .setTint(def.color).setAlpha(0.32).setBlendMode(Phaser.BlendModes.ADD);
      c.add(glow);
      var bld = this.add.image(0, 2, 'qgiso_b_' + sid).setOrigin(0.5, 170 / 220);
      c.add(bld);
      this._addStructureFX(c, sid, def);
      c.add(this.add.text(0, TH * 0.4, def.name, {
        fontFamily: 'Arial, sans-serif', fontSize: '11px', fontStyle: 'bold', color: '#eaf2ff'
      }).setOrigin(0.5).setShadow(1, 1, '#05070f', 3, true, true));

      if (animate) {
        bld.setScale(0.55, 0.05).setAlpha(0.2);
        this.tweens.add({ targets: bld, scaleX: 1, scaleY: 1, alpha: 1, duration: 420, ease: 'Back.easeOut' });
        var wx = this.gridLayer.x + p.x, wy = this.gridLayer.y + p.y;
        if (this.fx) { this.fx.ring(wx, wy, def.color, 1.5); this.fx.burst('crystal', wx, wy - 20, 14); }
      }
    } else if (unlocked) {
      c.add(this.add.image(0, 0, 'qgiso_free').setOrigin(0.5, oy));
      if (this._showPlus !== false) {
        var plus = this.add.text(0, -4, '+', {
          fontFamily: 'Arial, sans-serif', fontSize: '46px', fontStyle: 'bold', color: '#7bdfff'
        }).setOrigin(0.5).setAlpha(0.8).setShadow(0, 0, '#2e9eff', 12, true, true);
        c.add(plus);
        this._trackTween(c, this.tweens.add({ targets: plus, y: -12, alpha: 0.35, duration: 1200, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' }));
      }
    } else {
      c.add(this.add.image(0, 0, 'qgiso_locked').setOrigin(0.5, oy));
      c.add(this.add.text(0, -6, '🔒', { fontSize: '30px' }).setOrigin(0.5).setAlpha(0.6));
    }

    c._qgCol = col; c._qgRow = row;
    return c;
  }

  // Animations légères propres à chaque structure (positions relatives au sol de la parcelle).
  _addStructureFX(c, sid, def) {
    var add = (x, y, size, color, from, to, dur) => {
      var g = this.add.image(x, y, 'tex_glow_white').setDisplaySize(size, size).setTint(color)
        .setAlpha(from).setBlendMode(Phaser.BlendModes.ADD);
      c.add(g);
      this._trackTween(c, this.tweens.add({ targets: g, alpha: to, duration: dur, yoyo: true, repeat: -1, ease: 'Sine.easeInOut', delay: Math.random() * 400 }));
    };
    if (sid === 'generator') {
      add(0, -70, 96, 0x4fe3ff, 0.65, 0.2, 800);   // cœur d'énergie
      add(0, -112, 30, 0xd4fbff, 0.9, 0.2, 500);   // pointe d'antenne
    } else if (sid === 'silo') {
      add(0, -146, 34, 0xff6b6b, 0.95, 0.05, 700); // balise rouge
    } else if (sid === 'wall') {
      add(0, -30, 40, 0xffb04f, 0.5, 0.1, 1200);   // voyant de la barricade
    } else if (sid === 'barracks') {
      add(-26, -88, 26, 0xff5a5a, 0.85, 0.25, 900); // drapeau
      add(4, -30, 30, 0xffd166, 0.5, 0.15, 1400);   // fenêtres
    } else if (sid === 'workshop') {
      add(34, -66, 34, 0xffa640, 0.9, 0.2, 700);    // cheminée
      add(-12, -54, 44, 0xffd166, 0.35, 0.1, 1100); // engrenage chaud
    } else if (sid === 'lab') {
      add(0, -48, 70, 0x7dffb0, 0.55, 0.15, 1000);  // cuve vivante
      add(0, -96, 26, 0xe6b0ff, 0.9, 0.2, 600);
    } else if (sid === 'radar') {
      add(23, -132, 24, 0xff6b6b, 0.95, 0.05, 600); // balise
      add(4, -104, 60, 0x3f8cff, 0.4, 0.05, 1500);  // balayage
    } else if (sid === 'refinery') {
      add(48, -92, 40, 0xff8a3d, 0.95, 0.35, 380);  // torchère
      add(-34, -28, 40, 0x2ee6b8, 0.4, 0.1, 1300);  // cuve
    } else {
      add(2, -62, 22, 0x5fd97a, 0.9, 0.2, 600);    // voyant de tête
      add(62, -24, 40, 0xc7ffe1, 0.0, 0.85, 1500); // éclat de bouche de canon
    }
  }

  _hex(n) { return '#' + ('000000' + n.toString(16)).slice(-6); }

  // ---------- Glisser / taper : une seule zone interactive couvre tout le viewport ----------
  _buildPanTarget() {
    var v = this.viewport;
    var zone = this.add.zone(v.x + v.w / 2, v.y + v.h / 2, v.w, v.h).setOrigin(0.5).setDepth(42).setInteractive();
    this._panZone = zone;
    this._dragging = false;
    this._downX = 0; this._downY = 0; this._downLayerX = 0; this._downLayerY = 0;

    var self = this;
    this._onDown = function (p) {
      self._downX = p.x; self._downY = p.y;
      self._downLayerX = self.gridLayer.x; self._downLayerY = self.gridLayer.y;
      self._dragging = false;
    };
    this._onMove = function (p) {
      if (!p.isDown) return;
      var dx = p.x - self._downX, dy = p.y - self._downY;
      // Seuil de glissement : 8 px du jeu ≈ 4 px d'écran sur téléphone (720 px de large réduits à ~390) → un doigt qui tremble
      // un peu était pris pour un glissement et le tap sur la parcelle/structure était perdu. 22 px du jeu ≈ 12 px d'écran.
      if (!self._dragging && Math.sqrt(dx * dx + dy * dy) > 22) self._dragging = true;
      if (!self._dragging) return;
      var nx = self._clampAxis(self._downLayerX + dx, self.contentW, v.x, v.w);
      var ny = self._clampAxis(self._downLayerY + dy, self.contentH, v.y, v.h);
      self.gridLayer.setPosition(nx, ny);
    };
    this._onUp = function (p) {
      if (self._dragging) { self._dragging = false; return; }
      self._handleTap(self._downX, self._downY);   // le tap vise là où le doigt a TOUCHÉ (pas où il a fini son léger tremblement)
    };
    zone.on('pointerdown', this._onDown);
    this.input.on('pointermove', this._onMove);
    zone.on('pointerup', this._onUp);
    zone.on('pointerupoutside', function () { self._dragging = false; });
  }

  _teardownPan() {
    if (this.input) this.input.off('pointermove', this._onMove);
    // Stoppe les tweens (pulsations, balises, réacteurs) pour ne pas laisser de tweens orphelins.
    if (this._cellNodes) this._cellNodes.forEach(function (n) { if (n._tw) n._tw.forEach(function (t) { t.stop(); }); });
  }

  // Le point (lx,ly) (repère du calque) touche-t-il la structure posée en (col,row) ? Deux façons : soit le losange de sa
  // propre parcelle, soit son CORPS visible (test de transparence sur la texture du volume). Avant, on testait un grand
  // rectangle 112×168 px autour de chaque structure : il volait les taps des parcelles libres voisines et de celles situées
  // juste derrière → impossible de poser un bâtiment sur ces parcelles. Maintenant seule la silhouette réelle compte.
  _hitStructure(col, row, lx, ly) {
    var TW = this.TW, TH = this.TH;
    var p = this._tilePos(col, row);
    if (Math.abs(lx - p.x) / (TW / 2) + Math.abs(ly - p.y) / (TH / 2) <= 1) return true;   // sa propre dalle
    var sid = this.GM.structureAt(col, row);
    var key = 'qgiso_b_' + sid;
    var tx = Math.round(lx - p.x + 85), ty = Math.round(ly - (p.y + 2) + 170);            // texture 170×220, sol en (85,170)
    if (tx < -8 || ty < -8 || tx > 178 || ty > 228) return false;
    var tm = this.textures;
    if (tm && typeof tm.getPixelAlpha === 'function') {
      try {
        var pts = [[0, 0], [-6, 0], [6, 0], [0, -6], [0, 6]], seen = false;
        for (var i = 0; i < pts.length; i++) {
          var x = tx + pts[i][0], y = ty + pts[i][1];
          if (x < 0 || y < 0 || x >= 170 || y >= 220) continue;
          var a = tm.getPixelAlpha(x, y, key);
          if (a === null || a === undefined) { seen = null; break; }
          if (a > 24) return true;
          seen = true;
        }
        if (seen) return false;
      } catch (e) { /* on retombe sur le rectangle ci-dessous */ }
    }
    return lx >= p.x - 44 && lx <= p.x + 44 && ly >= p.y - 120 && ly <= p.y + TH * 0.3;   // secours (pas de lecture de pixels)
  }

  // Tap → parcelle : la structure DEVANT (plus grand col+row) dont le corps est touché, sinon la parcelle sous le doigt.
  _handleTap(px, py) {
    var G = this.G, GM = this.GM, TW = this.TW, TH = this.TH;
    var lx = px - this.gridLayer.x, ly = py - this.gridLayer.y;

    var best = null;
    for (var r = 0; r < G.ROWS; r++) {
      for (var cc = 0; cc < G.COLS; cc++) {
        if (!GM.isUnlocked(cc, r) || !GM.structureAt(cc, r)) continue;
        if (!this._hitStructure(cc, r, lx, ly)) continue;
        var d = cc + r;
        if (!best || d >= best.d) best = { col: cc, row: r, d: d };
      }
    }
    if (best) { this._openPanel(best.col, best.row); return; }

    var u = ((lx - this.ox) / (TW / 2) + (ly - this.oy) / (TH / 2)) / 2;
    var v = ((ly - this.oy) / (TH / 2) - (lx - this.ox) / (TW / 2)) / 2;
    var col = Math.floor(u), row = Math.floor(v);
    if (col < 0 || col >= G.COLS || row < 0 || row >= G.ROWS) return;
    this._openPanel(col, row);
  }

  // ---------- Panneau (parcelle verrouillée / vide à construire / structure posée) ----------
  _buildPanel() {
    var w = this.scale.width, h = this.scale.height;
    var panel = this.add.container(w / 2, h + 320).setDepth(1100);
    var TOP = -230, PH = 440;

    var bg = this.add.graphics();
    bg.fillGradientStyle(0x101a33, 0x101a33, 0x0a1020, 0x0a1020, 0.98);
    bg.fillRoundedRect(-w * 0.44, TOP, w * 0.88, PH, 20);
    bg.lineStyle(2, 0x2e9eff, 0.6);
    bg.strokeRoundedRect(-w * 0.44, TOP, w * 0.88, PH, 20);
    panel.add(bg);
    panel.add(this.add.rectangle(0, TOP + PH / 2, w * 0.88, PH, 0x000000, 0.001).setInteractive());

    var title = this.add.text(-w * 0.38, TOP + 30, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '24px', fontStyle: 'bold', color: '#eaf2ff'
    }).setOrigin(0, 0.5);
    var sub = this.add.text(-w * 0.38, TOP + 62, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '15px', color: '#8ea0c8', wordWrap: { width: w * 0.76 }
    }).setOrigin(0, 0.5);
    var closeBtn = this.add.text(w * 0.38, TOP + 22, '✕', {
      fontFamily: 'Arial, sans-serif', fontSize: '28px', color: '#a9b8dc'
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });
    closeBtn.on('pointerdown', () => this._closePanel());
    panel.add([title, sub, closeBtn]);

    // Ligne coût (verrouillage ou structure posée)
    this._pCostY = TOP + 108;
    this._pCostSlots = [];
    for (var k = 0; k < 3; k++) {
      var ci = this.add.image(0, this._pCostY, 'tex_icon_crystal').setDisplaySize(26, 26).setVisible(false);
      var ct = this.add.text(0, this._pCostY, '', {
        fontFamily: 'Arial, sans-serif', fontSize: '19px', fontStyle: 'bold', color: '#eaf2ff'
      }).setOrigin(0, 0.5).setVisible(false);
      panel.add([ci, ct]);
      this._pCostSlots.push({ icon: ci, text: ct });
    }

    this._mainBtn = new NEBUSTION.Button(this, 0, TOP + 260, {
      width: w * 0.74, height: 56, label: ' ', accentColor: 0x5fd97a, fontSize: '18px',
      onClick: () => this._onPanelAction()
    });
    panel.add(this._mainBtn);

    // Rangée de cartes de structures (mode "construire ici")
    this._buildCards = [];
    // 12 structures : 4 colonnes × 3 rangées, toutes dans le panneau.
    var nCards = this.G.STRUCTURE_ORDER.length, COLS = 4;
    var gap = 6, cardW = (w * 0.88 - 24 - gap * (COLS - 1)) / COLS, cardH = 90, rowGap = 6;
    for (var i = 0; i < nCards; i++) {
      var ccol = i % COLS, crow = Math.floor(i / COLS);
      var cx = -((COLS - 1) / 2) * (cardW + gap) + ccol * (cardW + gap);
      var cy = TOP + 156 + crow * (cardH + rowGap);
      var card = this._buildStructureCard(cx, cy, cardW, cardH);
      panel.add(card.container);
      this._buildCards.push(card);
    }

    this._panel = panel;
    this._panelTitle = title;
    this._panelSub = sub;
    this._panelOpenY = h - 340;
    this._panelClosedY = h + 320;
    this._panelMode = null;
    this._panelCell = null;
    this._panelBusy = false; // empêche deux achats pendant le même rafraîchissement
  }

  _buildStructureCard(x, y, cw, ch) {
    var container = this.add.container(x, y);
    var g = this.add.graphics();
    container.add(g);
    var icon = this.add.text(0, -ch * 0.34, '', { fontSize: '30px' }).setOrigin(0.5);
    var name = this.add.text(0, -ch * 0.2, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', fontStyle: 'bold', color: '#eaf2ff', align: 'center', wordWrap: { width: cw * 0.96 }
    }).setOrigin(0.5, 0);
    var cost = this.add.text(0, ch * 0.08, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '12px', color: '#8ea0c8', align: 'center', wordWrap: { width: cw * 0.96 }
    }).setOrigin(0.5, 0);
    container.add([icon, name, cost]);

    // Zone tactile = toute la carte (+ 3 px de marge de chaque côté pour les gros doigts).
    var hit = this.add.rectangle(0, 0, cw + 6, ch + 6, 0x000000, 0.001).setInteractive({ useHandCursor: true });
    container.add(hit);

    var card = { container: container, g: g, icon: icon, name: name, cost: cost, cw: cw, ch: ch, structureId: null };
    hit.on('pointerdown', () => { if (card.structureId) this._doBuild(card.structureId); else this._explainBuildFail({ ok: false, reason: 'max' }); });
    return card;
  }

  _openPanel(col, row) {
    var GM = this.GM, G = this.G;
    this._panelCell = { col: col, row: row };

    if (!GM.isUnlocked(col, row)) {
      this._panelMode = 'locked';
    } else if (GM.structureAt(col, row)) {
      this._panelMode = 'built';
    } else if (GM.pendingAt(col, row)) {
      this._panelMode = 'building';
    } else {
      this._panelMode = 'build';
    }
    this._refreshPanel();

    this.tweens.add({ targets: this._panel, y: this._panelOpenY, duration: 260, ease: 'Back.easeOut' });
  }

  _closePanel() {
    this.tweens.add({ targets: this._panel, y: this._panelClosedY, duration: 220, ease: 'Sine.easeIn' });
    this._panelCell = null;
  }

  _refreshPanel() {
    if (!this._panelCell) return;
    var col = this._panelCell.col, row = this._panelCell.row;
    var GM = this.GM, G = this.G, E = NEBUSTION.Economy;

    this._buildCards.forEach((c) => { c.container.setVisible(false); });
    this._mainBtn.setVisible(true);
    this._pCostSlots.forEach((s) => { s.icon.setVisible(false); s.text.setVisible(false); });

    if (this._panelMode === 'locked') {
      this._panelTitle.setText('Parcelle verrouillée');
      this._panelSub.setText('Défriche cette parcelle pour pouvoir y construire une structure.');
      this._renderCost(GM.unlockCost());
      var canU = GM.canUnlock(col, row);
      if (this._mainBtn.labelText) this._mainBtn.labelText.setText('DÉFRICHER');
      this._mainBtn.setLook(0x5fd97a, '#eaf2ff');
      this._mainBtn.setDisabled(!canU);
    } else if (this._panelMode === 'build') {
      this._panelTitle.setText('Parcelle libre');
      this._panelSub.setText('Touche une carte pour construire : 🏕️ armée · 🔧 remise troupes · 🧬 XP Symtor · 📡 recharge · ⚗️ butin · 🔐 protection raids\n🔭 hors ligne · 🛰️ caisses · ⚔️ troupes · 🏯 anti-raid (ces 4 derniers prennent du temps à construire)');
      this._mainBtn.setVisible(false);
      this.G.STRUCTURE_ORDER.forEach((sid, i) => {
        var def = this.G.STRUCTURES[sid];
        var card = this._buildCards[i];
        if (!card) return;
        var n = GM.counts()[sid] || 0;
        var maxed = n >= def.maxCount;
        var cost = GM.buildCost(sid);
        var afford = Object.keys(cost).every((id) => NEBUSTION.Resources.get(id) >= cost[id]);
        card.structureId = maxed ? null : sid;
        card.container.setVisible(true);
        card.icon.setText(def.icon);
        card.name.setText(def.name + ' (' + n + '/' + def.maxCount + ')');
        card.cost.setText(maxed ? 'Complet' : Object.keys(cost).map((id) => E.fmt(cost[id], 0) + ' ' + E.RES[id].short).join('\n'));
        card.cost.setColor(maxed ? '#5c6b8a' : (afford ? '#8ea0c8' : '#ff6b6b'));
        this._drawCardBg(card, maxed ? 0x33415f : def.color, maxed ? 0.12 : (afford ? 0.3 : 0.16));
      });
    } else if (this._panelMode === 'built') {
      var sid2 = GM.structureAt(col, row);
      var def2 = this.G.STRUCTURES[sid2];
      var n2 = GM.counts()[sid2] || 0;
      this._panelTitle.setText(def2.icon + ' ' + def2.name);
      this._panelSub.setText(def2.desc(n2) + '  •  ' + n2 + '/' + def2.maxCount + ' construit(s)');
      var refund = GM.sellRefund(col, row);
      this._renderCost(refund);
      if (this._mainBtn.labelText) this._mainBtn.labelText.setText('VENDRE');
      this._mainBtn.setLook(0xff6b6b, '#eaf2ff');
      this._mainBtn.setDisabled(false);
    } else if (this._panelMode === 'building') {
      var job = GM.pendingAt(col, row);
      var def3 = this.G.STRUCTURES[job.id];
      var left = GM.remainingMs(col, row);
      this._panelTitle.setText('🚧 ' + def3.icon + ' ' + def3.name + ' en construction');
      this._panelSub.setText('Temps restant : ' + (this._timeLeft(left) || '< 1 min') + '  •  ' + def3.desc(1) + ' une fois terminé.');
      this._pCostSlots.forEach((s) => { s.icon.setVisible(false); s.text.setVisible(false); });
      if (this._mainBtn.labelText) this._mainBtn.labelText.setText('ANNULER (50 % remboursé)');
      this._mainBtn.setLook(0xff6b6b, '#eaf2ff');
      this._mainBtn.setDisabled(false);
    }
  }

  _drawCardBg(card, color, alpha) {
    var g = card.g, cw = card.cw, ch = card.ch;
    g.clear();
    g.fillStyle(color, alpha);
    g.fillRoundedRect(-cw / 2, -ch / 2, cw, ch, 12);
    g.lineStyle(1.5, color, 0.7);
    g.strokeRoundedRect(-cw / 2, -ch / 2, cw, ch, 12);
  }

  _renderCost(cost) {
    var E = NEBUSTION.Economy;
    var ids = Object.keys(cost);
    var totalW = ids.length * 100;
    var startX = -totalW / 2 + 12;
    this._pCostSlots.forEach((slot, i) => {
      var id = ids[i];
      if (!id) return;
      var have = NEBUSTION.Resources.get(id) >= (cost[id] || 0);
      slot.icon.setTexture('tex_icon_' + id).setPosition(startX + i * 100, this._pCostY).setVisible(true);
      slot.text.setText(E.fmt(cost[id], 0)).setColor(have ? '#eaf2ff' : '#ff6b6b')
        .setPosition(startX + i * 100 + 18, this._pCostY).setVisible(true);
    });
  }

  _onPanelAction() {
    if (!this._panelCell || this._panelBusy) return;
    this._panelBusy = true;
    var col = this._panelCell.col, row = this._panelCell.row;
    var res;
    try {
    if (this._panelMode === 'locked') {
      res = this.GM.unlockCell(col, row);
      if (res.ok) { this.cameras.main.flash(150, 95, 217, 122); this._afterAction(col, row); }
      else this._explainBuildFail(res);
    } else if (this._panelMode === 'built') {
      res = this.GM.sell(col, row);
      if (res.ok) { this.cameras.main.flash(150, 255, 107, 107); this._closePanel(); this._refreshCell(col, row); this._refreshInfoBar(); }
    } else if (this._panelMode === 'building') {
      res = this.GM.cancelBuild(col, row);
      if (res.ok) { this.cameras.main.flash(150, 255, 107, 107); this._closePanel(); this._refreshCell(col, row); this._refreshInfoBar(); }
    }
    } finally { this._panelBusy = false; }
  }

  _doBuild(structureId) {
    if (!this._panelCell || this._panelBusy) return;
    var col = this._panelCell.col, row = this._panelCell.row;
    var res = this.GM.build(col, row, structureId);
    if (res.ok) {
      this.cameras.main.flash(150, 95, 217, 122);
      this._afterAction(col, row);
      if (res.buildTimeSec && this.fx && this.fx.toast) {
        var def = this.G.STRUCTURES[structureId];
        this.fx.toast('Chantier lancé', def.icon + ' ' + def.name + ' — prêt dans ' + (this._timeLeft(res.buildTimeSec * 1000) || '< 1 min') + '.', null);
      }
    }
    else this._explainBuildFail(res);
  }

  // Dit POURQUOI la construction n'a pas eu lieu (avant : un simple tremblement d'écran quasi invisible → on croyait
  // que le bâtiment « ne se posait pas »).
  _explainBuildFail(res) {
    if (this.cameras && this.cameras.main) this.cameras.main.shake(120, 0.004);
    if (!this.fx || !this.fx.toast) return;
    var E = NEBUSTION.Economy, R = NEBUSTION.Resources, title = 'Construction impossible', sub = null;
    if (res.reason === 'cost' && res.cost) {
      var miss = Object.keys(res.cost).filter(function (id) { return R.get(id) < res.cost[id]; })
        .map(function (id) { return E.fmt(res.cost[id] - R.get(id), 0) + ' ' + E.RES[id].short; });
      title = 'Ressources insuffisantes'; sub = 'Il manque : ' + miss.join(' · ');
    } else if (res.reason === 'max') { title = 'Maximum atteint'; sub = 'Ce bâtiment est déjà construit au maximum.'; }
    else if (res.reason === 'occupied') { title = 'Parcelle occupée'; }
    else if (res.reason === 'locked') { title = 'Parcelle verrouillée'; sub = 'Défriche-la d\'abord.'; }
    this.fx.toast(title, sub, null);
  }

  _afterAction(col, row) {
    this._refreshCell(col, row, !!this.GM.structureAt(col, row));
    this._refreshInfoBar();
    this._panelMode = this.GM.structureAt(col, row) ? 'built' : (this.GM.isUnlocked(col, row) ? 'build' : 'locked');
    this._refreshPanel();
  }

  // ---------- Panneau « Attaquer un QG ennemi » (module 17 : le joueur riposte avec sa flotte de bots) ----------
  _timeLeft(ms) {
    if (ms <= 0) return null;
    var min = Math.ceil(ms / 60000);
    if (min < 60) return min + ' min';
    return Math.ceil(min / 60) + ' h';
  }

  _buildAttackPanel() {
    var w = this.scale.width, h = this.scale.height;
    var panel = this.add.container(w / 2, h + 620).setDepth(1150);
    var TOP = -380, PH = 600;

    var bg = this.add.graphics();
    bg.fillGradientStyle(0x1a1024, 0x1a1024, 0x0a0a18, 0x0a0a18, 0.98);
    bg.fillRoundedRect(-w * 0.44, TOP, w * 0.88, PH, 20);
    bg.lineStyle(2, 0xff6b9a, 0.6);
    bg.strokeRoundedRect(-w * 0.44, TOP, w * 0.88, PH, 20);
    panel.add(bg);
    panel.add(this.add.rectangle(0, TOP + PH / 2, w * 0.88, PH, 0x000000, 0.001).setInteractive());

    panel.add(this.add.text(-w * 0.38, TOP + 30, '⚔ MATCHMAKING — QG ENNEMI', {
      fontFamily: 'Arial, sans-serif', fontSize: '21px', fontStyle: 'bold', color: '#ff8fa3'
    }).setOrigin(0, 0.5));
    var closeBtn = this.add.text(w * 0.38, TOP + 22, '✕', {
      fontFamily: 'Arial, sans-serif', fontSize: '28px', color: '#a9b8dc'
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });
    closeBtn.on('pointerdown', () => this._closeAttackPanel());
    panel.add(closeBtn);

    this._atkSub = this.add.text(-w * 0.38, TOP + 64, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '14px', color: '#8ea0c8', wordWrap: { width: w * 0.76 }
    }).setOrigin(0, 0.5);
    panel.add(this._atkSub);

    // Carte unique : soit « aucun adversaire », soit l'adversaire trouvé par le matchmaking.
    var cardY = TOP + 260, cw = w * 0.8, ch = 300;
    var cardBg = this.add.graphics();
    var chip = this.add.text(0, cardY - 108, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '18px', fontStyle: 'bold', color: '#eaf2ff', align: 'center'
    }).setOrigin(0.5);
    var info = this.add.text(0, cardY - 74, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#8ea0c8', align: 'center', wordWrap: { width: cw * 0.9 }
    }).setOrigin(0.5);
    var status = this.add.text(0, cardY - 46, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', fontStyle: 'bold', color: '#5c6b8a', align: 'center'
    }).setOrigin(0.5);
    var searchBtn = new NEBUSTION.Button(this, 0, cardY + 20, {
      width: cw * 0.86, height: 64, label: '🎯 TROUVER UN ADVERSAIRE', fontSize: '17px', accentColor: 0x54c8ff,
      onClick: () => this._searchOpponent()
    });
    var visitBtn = new NEBUSTION.Button(this, 0, cardY + 20, {
      width: cw * 0.86, height: 58, label: 'VISITER SA BASE', fontSize: '16px', accentColor: 0xff6b6b,
      onClick: () => this._visitOpponent()
    });
    var rematchBtn = new NEBUSTION.Button(this, 0, cardY + 92, {
      width: cw * 0.86, height: 48, label: '🔄 CHANGER D\'ADVERSAIRE', fontSize: '14px', accentColor: 0xffd166,
      onClick: () => this._searchOpponent()
    });
    panel.add([cardBg, chip, info, status, searchBtn, visitBtn, rematchBtn]);
    this._atkCard = { bg: cardBg, chip: chip, info: info, status: status, searchBtn: searchBtn, visitBtn: visitBtn, rematchBtn: rematchBtn, cw: cw, y: cardY };

    this._atkPanel = panel;
    this._atkOpenY = h - 400;
    this._atkClosedY = h + 620;
  }

  _openAttackPanel() {
    this._refreshAttackPanel();
    this.tweens.add({ targets: this._atkPanel, y: this._atkOpenY, duration: 260, ease: 'Back.easeOut' });
  }

  _closeAttackPanel() {
    this.tweens.add({ targets: this._atkPanel, y: this._atkClosedY, duration: 220, ease: 'Sine.easeIn' });
  }

  // Lance une recherche de matchmaking et rafraîchit la carte pour montrer le nouvel adversaire.
  _searchOpponent() {
    var MM = NEBUSTION.QGMatchmakingManager;
    if (MM) MM.search(Date.now());
    this._refreshAttackPanel();
  }

  _refreshAttackPanel() {
    if (!this._atkCard) return;
    var AM = NEBUSTION.QGAttackManager, SH = NEBUSTION.ShipManager, MM = NEBUSTION.QGMatchmakingManager;
    var now = Date.now(), power = SH ? SH.fleetPower() : 0;
    var hasFleet = SH && SH.getFleet().length > 0;
    this._atkSub.setText(hasFleet
      ? '⚡ Puissance de flotte : ' + power + ' · le matchmaking te trouve un QG ennemi à ton niveau.'
      : '⚠️ Ta flotte est vide — assemble des vaisseaux (onglet Vaisseaux) avant d\'attaquer.');

    var c = this._atkCard, match = MM ? MM.current(now) : null;
    c.bg.clear();
    if (!match) {
      c.bg.fillStyle(0x161022, 0.6); c.bg.fillRoundedRect(-c.cw / 2, c.y - 150, c.cw, 300, 18);
      c.bg.lineStyle(1.5, 0x54c8ff, 0.4); c.bg.strokeRoundedRect(-c.cw / 2, c.y - 150, c.cw, 300, 18);
      c.chip.setText('Aucun adversaire pour l\'instant').setColor('#8ea0c8');
      c.info.setText('Ton niveau : ' + (MM ? MM.playerLevel() : '?') + ' · lance une recherche pour te trouver un QG ennemi à affronter.');
      c.status.setText('');
      c.searchBtn.setVisible(true).setDisabled(false);
      c.visitBtn.setVisible(false);
      c.rematchBtn.setVisible(false);
      return;
    }
    var E = NEBUSTION.Galaxy.empire(match.eid), BB = NEBUSTION.BotBases;
    var handle = BB ? BB.handleOf(match.eid) : E.name;
    c.bg.fillStyle(E.color, 0.14); c.bg.fillRoundedRect(-c.cw / 2, c.y - 150, c.cw, 300, 18);
    c.bg.lineStyle(1.5, E.color, 0.6); c.bg.strokeRoundedRect(-c.cw / 2, c.y - 150, c.cw, 300, 18);
    c.chip.setText(handle + ' · ' + E.name).setColor(E.hex);
    c.info.setText(match.profile.rank + ' niv. ' + match.profile.level + ' · QG niv. ' + match.profile.qgLevel +
      ' · Dév. ' + match.es.evo + ' · Traumatisme ' + Math.round((match.es.hurt || 0) * 100) + ' %');
    var can = AM.canAttack(match.eid, now);
    if (can.ok) c.status.setText('Prêt à attaquer').setColor('#5fd97a');
    else if (can.reason === 'recharge') c.status.setText('Recharge ' + this._timeLeft(AM.cooldownRemaining(match.eid, now))).setColor('#ffb36b');
    else if (can.reason === 'flotte_vide') c.status.setText('Flotte vide').setColor('#ff8fa3');
    else c.status.setText('').setColor('#5c6b8a');
    c.searchBtn.setVisible(false);
    c.visitBtn.setVisible(true).setDisabled(false);
    c.rematchBtn.setVisible(true).setDisabled(false);
  }

  // Ouvre le QG de l'adversaire trouvé par le matchmaking (traité comme un joueur adverse) : EnemyQGScene.
  _visitOpponent() {
    var MM = NEBUSTION.QGMatchmakingManager;
    var match = MM ? MM.current(Date.now()) : null;
    if (!match || !NEBUSTION.EnemyQGScene) return;
    this.scene.start('EnemyQGScene', { eid: match.eid, variant: match.variant });
  }

  _doAttack(eid) {
    var AM = NEBUSTION.QGAttackManager, E = NEBUSTION.Galaxy.empire(eid), Ec = NEBUSTION.Economy;
    var res = AM.attack(eid, Date.now());
    if (!res.ok) { this.fx.shake(100, 0.003); this._refreshAttackPanel(); return; }
    var r = res.result;
    if (r.victory) {
      this.cameras.main.flash(150, 95, 217, 122);
      var parts = Object.keys(r.loot).map((id) => Ec.fmt(r.loot[id], 0) + ' ' + Ec.RES[id].short).join(' · ');
      this.fx.toast('💥 QG de ' + E.name + ' pris d\'assaut !', 'Butin : ' + parts, 'crystal');
    } else {
      this.fx.shake(120, 0.004);
      this.fx.toast('🛡️ Attaque repoussée', 'Le QG de ' + E.name + ' a tenu bon.');
    }
    this._refreshAttackPanel();
    this._refreshInfoBar();
  }
};
