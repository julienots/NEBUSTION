/**
 * NEBUSTION - CodexScene
 * Journal narratif : onglet « Récit » (chronologie débloquée par la progression réelle du
 * Combat, du module Nebustion et des Renaissances — voir js/data/Codex.js) et onglet
 * « Connexions » (pourquoi Événements/Expéditions/QG/Renaissance/Symtor existent).
 *
 * Écran de lecture seule : aucune action de jeu ici, tout vient de NEBUSTION.CodexManager,
 * comme PrestigeScene/AchievementsScene/NebustionScene (même classe de base ProgressScene).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.CodexScene = class CodexScene extends NEBUSTION.ProgressScene {
  constructor() { super('CodexScene'); }

  _hubKey() { return 'codex'; }
  _titleText() { return 'CODEX'; }
  _accent() { return 0xff4d5e; }
  _accentHex() { return '#ff4d5e'; }
  _defaultTab() { return 'story'; }
  _tabDefs() { return [{ id: 'story', label: 'Récit' }, { id: 'links', label: 'Connexions' }]; }

  create() {
    super.create();
    // Ouvrir le journal marque les entrées débloquées comme lues (la pastille de la barre
    // de navigation ne réapparaît que pour de nouvelles entrées).
    try { NEBUSTION.CodexManager.markAllSeen(); } catch (e) { /* ignore */ }
  }

  _badgeContent(c) {
    var p = NEBUSTION.CodexManager.progress();
    this._badgePill(c, 'frag', p.unlocked + ' / ' + p.total, this._accent(), this._accentHex());
  }

  _renderTab(w) {
    if (this.tab === 'links') return this._renderLinks(w);
    return this._renderStory(w);
  }

  // ================= Onglet Récit =================
  _renderStory(w) {
    var self = this, cards = [], lastChapter = null;
    NEBUSTION.CodexManager.story().forEach(function (e) {
      if (e.chapter !== lastChapter) {
        lastChapter = e.chapter;
        var head = self.add.container(12, 0);
        head._cardH = 40; head._hits = []; head._cw = self.scale.width - 24;
        head.add(self._txt(4, 20, e.chapterLabel.toUpperCase(), 13, '#6d7c9c', { fontStyle: 'bold' }).setOrigin(0, 0.5));
        cards.push(head);
      }
      cards.push(self._storyCard(e));
    });
    return { cards: cards, footer: null };
  }

  _storyCard(e) {
    var self = this;
    if (!e.unlocked) {
      var lc = this._card(112, 0x394869, { dim: true });
      var lg = this.add.graphics();
      this._drawLock(lg, 40, 56, 0.9, 0x5c6b8a, 0.9);
      lc.add(lg);
      lc.add(this._txt(70, 30, 'Signal non identifié', 16, '#8e9cc0', { fontStyle: 'bold' }));
      lc.add(this._txt(70, 58, e.hint || '???', 13, '#5c6b8a', { wordWrap: { width: lc._cw - 94 } }));
      return lc;
    }
    // Mesure la hauteur réelle du texte avant de construire la carte (longueurs variables).
    var cw = this.scale.width - 24, innerW = cw - 48;
    var probe = this._txt(0, 0, e.body, 14, '#a9b8dc', { wordWrap: { width: innerW }, lineSpacing: 4 });
    var bodyH = probe.height; probe.destroy();
    var h = 24 + 30 + 10 + bodyH + 22;
    var card = this._card(h, this._accent(), {});
    card.add(this._txt(24, 22, e.title, 17, '#eaf2ff', { fontStyle: 'bold' }));
    card.add(this._txt(24, 60, e.body, 14, '#a9b8dc', { wordWrap: { width: innerW }, lineSpacing: 4 }));
    return card;
  }

  // ================= Onglet Connexions =================
  _renderLinks(w) {
    var self = this, cards = [];
    cards.push((function () {
      var c = self._card(84, self._accent(), { dim: true });
      c.add(self._txt(24, 20, 'Pourquoi rien de tout ceci n\'est séparé', 15, '#eaf2ff', { fontStyle: 'bold' }));
      c.add(self._txt(24, 46, 'Chaque système du jeu tient sa raison d\'être de la même menace de fond.', 13, '#8e9cc0', { wordWrap: { width: c._cw - 48 } }));
      return c;
    })());
    NEBUSTION.CodexManager.connections().forEach(function (e) {
      var cw = self.scale.width - 24, innerW = cw - 48;
      var probe = self._txt(0, 0, e.body, 14, '#a9b8dc', { wordWrap: { width: innerW }, lineSpacing: 4 });
      var bodyH = probe.height; probe.destroy();
      var h = 24 + 28 + 10 + bodyH + 22;
      var card = self._card(h, 0x8a2be2, {});
      card.add(self._txt(24, 22, e.title, 16, '#eaf2ff', { fontStyle: 'bold' }));
      card.add(self._txt(24, 56, e.body, 14, '#a9b8dc', { wordWrap: { width: innerW }, lineSpacing: 4 }));
      cards.push(card);
    });
    return { cards: cards, footer: null };
  }
};
