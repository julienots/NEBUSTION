/**
 * NEBUSTION - BlackHoleRunScene
 * Arène TEMPS RÉEL des rencontres du Trou Noir : le joueur pilote la sonde au doigt (glisser) au lieu
 * de lire un résultat. Trois épreuves, choisies par le type de rencontre (BlackHole.modeOf) :
 *   - collect : attraper les cristaux/fragments qui tombent vers l'horizon, éviter les débris (cache, relique)
 *   - dodge   : survivre à une marée : pluie de débris + vagues avec une brèche à traverser (choc de marée)
 *   - fight   : la sonde tire seule, on s'aligne sur l'ennemi (vrai sprite) et on esquive ses tirs
 *               (écho hostile, Seuil de la Singularité = boss). Les dégâts infligés dépendent de la PUISSANCE de
 *               l'équipe de combat : les héros comptent toujours, l'adresse compense en partie.
 * La scène ne modifie AUCUN état de jeu : elle renvoie une performance {score, win, damage, resId, summary}
 * à BlackHoleScene, qui la transmet à BlackHoleManager.chooseNode (application atomique, comme avant).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.BlackHoleRunScene = class BlackHoleRunScene extends Phaser.Scene {
  constructor() { super('BlackHoleRunScene'); }

  init(data) {
    this._plan = data.plan;
    this._onDone = data.onDone;
    this._parentKey = data.parent || 'BlackHoleScene';
  }

  create() {
    var self = this, w = this.scale.width, h = this.scale.height, plan = this._plan, P = plan.params;
    this.W = w; this.H = h; this.INTRO = 1.5;
    this.cameras.main.setBackgroundColor('#06020f');
    this.cameras.main.fadeIn(250, 0, 0, 0);
    this._ensureTextures();
    this.fx = new NEBUSTION.FX(this);

    // ---- Fond : étoiles qui filent + le vrai gros plan du trou noir, en rotation lente ----
    if (this.textures.exists('tex_starfield_far')) this._starsFar = this.add.tileSprite(0, 0, w, h, 'tex_starfield_far').setOrigin(0).setDepth(-90);
    if (this.textures.exists('tex_starfield_near')) this._starsNear = this.add.tileSprite(0, 0, w, h, 'tex_starfield_near').setOrigin(0).setAlpha(0.8).setDepth(-80);
    this._bg = this.add.image(w / 2, h * 0.64, NEBUSTION.BlackHoleTextures.ensureCloseup(this)).setDisplaySize(w * 1.5, w * 1.5).setAlpha(0.5).setDepth(-50);
    this.add.rectangle(0, 0, w, 250, 0x06020f, 0.72).setOrigin(0).setDepth(90);   // bandeau HUD lisible

    // ---- État de simulation (objets simples, indépendants de Phaser) ----
    var startInteg = Math.max(1, plan.integrity);
    this._startInteg = startInteg;
    var minY = P.mode === 'fight' ? 520 : 270;
    this.S = {
      t: 0, rt: 0, over: false, damage: 0, hits: 0, invuln: 0, minY: minY,
      probe: { x: w / 2, y: h - 240 }, target: { x: w / 2, y: h - 240 },
      ents: [], bullets: [], eshots: [], waves: [],
      got: 0, orbSpawned: 0, nextHazard: 0.6, nextWave: 1.4, fireCd: 0, enemy: null, banner: null
    };

    // ---- Sonde ----
    this._probe = this.add.container(this.S.probe.x, this.S.probe.y).setDepth(30);
    this._flame = this.add.image(0, 30, 'bh_run_orb').setTint(0xff8a3c).setBlendMode(Phaser.BlendModes.ADD).setScale(0.55, 1.1).setAlpha(0.9);
    this._probeImg = this.add.image(0, 0, 'bh_run_probe');
    this._probe.add([this._flame, this._probeImg]);
    this.tweens.add({ targets: this._flame, scaleY: 1.5, alpha: 0.55, duration: 110, yoyo: true, repeat: -1 });

    if (P.mode === 'fight') this._buildEnemy();
    this._waveG = this.add.graphics().setDepth(25);
    this._hudG = this.add.graphics().setDepth(100);
    this._buildHud();

    // ---- Commandes : glisser n'importe où, la sonde se place 110 px au-dessus du doigt ----
    this.input.on('pointerdown', function (p) { self._setTarget(p); });
    this.input.on('pointermove', function (p) { if (p.isDown) self._setTarget(p); });

    // ---- Bannière d'intro ----
    var hint = { collect: 'Glissez pour piloter la sonde\nAttrapez les cristaux, évitez les débris', dodge: 'Survivez à la marée\nGlissez dans les brèches, évitez les débris',
      fight: 'La sonde tire automatiquement\nPlacez-vous sous l\u2019ennemi, esquivez ses tirs' }[P.mode];
    var ban = this.add.container(w / 2, h * 0.42).setDepth(120);
    ban.add(this.add.text(0, -34, plan.title.toUpperCase(), { fontFamily: 'Arial, sans-serif', fontSize: '32px', fontStyle: '900', color: P.zoneHex, stroke: '#05070f', strokeThickness: 6, align: 'center' }).setOrigin(0.5));
    ban.add(this.add.text(0, 26, hint, { fontFamily: 'Arial, sans-serif', fontSize: '18px', color: '#eaf2ff', align: 'center', stroke: '#05070f', strokeThickness: 4 }).setOrigin(0.5));
    this.S.banner = ban;
  }

  // =====================================================================
  // Textures (générées une fois, aucun fichier)
  // =====================================================================
  _ensureTextures() {
    var self = this;
    function mk(key, tw, th, fn) {
      if (self.textures.exists(key)) return;
      var g = self.make.graphics({ x: 0, y: 0, add: false });
      fn(g); g.generateTexture(key, tw, th); g.destroy();
    }
    mk('bh_run_orb', 48, 48, function (g) {
      g.fillStyle(0xffffff, 0.18); g.fillCircle(24, 24, 24);
      g.fillStyle(0xffffff, 0.45); g.fillCircle(24, 24, 15);
      g.fillStyle(0xffffff, 1); g.fillCircle(24, 24, 8);
    });
    mk('bh_run_shard', 40, 52, function (g) {
      g.fillStyle(0xffffff, 0.22); g.fillPoints([{ x: 20, y: 0 }, { x: 40, y: 26 }, { x: 20, y: 52 }, { x: 0, y: 26 }], true);
      g.fillStyle(0xffffff, 0.95); g.fillPoints([{ x: 20, y: 9 }, { x: 31, y: 26 }, { x: 20, y: 43 }, { x: 9, y: 26 }], true);
    });
    mk('bh_run_debris', 48, 48, function (g) {
      var pts = [], i, a, r, rr = [20, 13, 21, 15, 19, 12, 22, 14];
      for (i = 0; i < 8; i++) { a = i / 8 * Math.PI * 2; r = rr[i]; pts.push({ x: 24 + Math.cos(a) * r, y: 24 + Math.sin(a) * r }); }
      g.fillStyle(0x2a1a2e, 1); g.fillPoints(pts, true);
      g.lineStyle(2.5, 0xff4d6d, 1); g.strokePoints(pts, true);
    });
    mk('bh_run_probe', 44, 56, function (g) {
      g.fillStyle(0x0a1020, 1); g.fillPoints([{ x: 22, y: 2 }, { x: 41, y: 50 }, { x: 22, y: 41 }, { x: 3, y: 50 }], true);
      g.lineStyle(2.5, 0x4fc3ff, 1); g.strokePoints([{ x: 22, y: 2 }, { x: 41, y: 50 }, { x: 22, y: 41 }, { x: 3, y: 50 }], true);
      g.fillStyle(0x4fc3ff, 0.95); g.fillPoints([{ x: 22, y: 14 }, { x: 30, y: 36 }, { x: 22, y: 32 }, { x: 14, y: 36 }], true);
      g.fillStyle(0xffffff, 1); g.fillCircle(22, 22, 3);
    });
  }

  // =====================================================================
  // Construction : ennemi + HUD
  // =====================================================================
  _buildEnemy() {
    var P = this._plan.params, w = this.W, size = P.boss ? 250 : 170, key = 'tex_enemy_' + P.enemyId, by = P.boss ? 395 : 340;
    var def = (NEBUSTION.Enemies && NEBUSTION.Enemies.get) ? NEBUSTION.Enemies.get(P.enemyId) : null;
    var spr;
    if (this.textures.exists(key)) spr = this.add.image(w / 2, by, key).setDisplaySize(size, size);
    else spr = this.add.image(w / 2, by, 'bh_run_orb').setTint(0xff4d6d).setDisplaySize(size * 0.7, size * 0.7);
    spr.setDepth(20);
    this.S.enemy = { spr: spr, x: w / 2, y: by, by: by, t: 0, hp: P.enemyHp, r: size * 0.42, cd: 1.0, volley: 0, name: (def && def.name) || 'Écho hostile', dead: false, baseScale: spr.scaleX };
  }

  _t(x, y, str, size, color, bold, origin) {
    return this.add.text(x, y, str, { fontFamily: 'Arial, sans-serif', fontSize: size + 'px', fontStyle: bold ? '900' : 'normal', color: color, stroke: '#05070f', strokeThickness: 3 })
      .setOrigin(origin === undefined ? 0.5 : origin, 0.5).setDepth(101);
  }

  _buildHud() {
    var P = this._plan.params, w = this.W;
    this._t(w / 2, 62, 'PROFONDEUR ' + P.depth + '  \u00B7  ' + P.zoneName.toUpperCase(), 14, P.zoneHex, true);
    this._t(w / 2, 90, this._plan.title, 24, '#eaf2ff', true).setShadow(0, 0, P.zoneHex, 10, true, true);
    this._integTxt = this._t(w / 2, 166, '', 12, '#eaf2ff', true);
    this._timeTxt = this._t(w - 40, 122, '', 13, '#a9b8dc', true, 1);
    if (P.mode === 'collect') {
      this._objTxt = this._t(w / 2, 208, '', 20, P.kind === 'cache' ? NEBUSTION.Economy.RES[P.resId].hex : '#8fe3ff', true);
    } else if (P.mode === 'dodge') {
      this._objTxt = this._t(w / 2, 208, 'Traversez les brèches \u2014 aucun impact = bonus', 16, '#ffb84d', true);
    } else {
      this._objTxt = this._t(w / 2, 198, this.S.enemy.name.toUpperCase(), 14, '#ff9a7b', true);
      this._t(w / 2, 226, 'Puissance d\u2019équipe \u00D7' + (P.ratio).toFixed(2), 12, '#8fe3ff', false);
    }
  }

  _drawHud() {
    var g = this._hudG, S = this.S, P = this._plan.params, w = this.W, bx = 40, bw = w - 80;
    g.clear();
    var tl = Math.max(0, 1 - S.rt / P.duration);              // temps restant
    g.fillStyle(0x11172a, 1); g.fillRoundedRect(bx, 118, bw - 80, 10, 5);
    if (tl > 0) { g.fillStyle(P.zoneColor, 1); g.fillRoundedRect(bx, 118, Math.max(8, (bw - 80) * tl), 10, 5); }
    var maxI = this._plan.maxIntegrity, cur = Math.max(0, this._plan.integrity - S.damage), pct = Math.max(0, Math.min(1, cur / maxI));
    g.fillStyle(0x11172a, 1); g.fillRoundedRect(bx, 148, bw, 36, 10);
    var col = pct > 0.5 ? 0x5fd97a : (pct > 0.25 ? 0xffb84d : 0xff4d6d);
    if (pct > 0) { g.fillStyle(col, 1); g.fillRoundedRect(bx, 148, Math.max(10, bw * pct), 36, 10); }
    this._integTxt.setText('Intégrité ' + Math.round(cur) + ' / ' + Math.round(maxI)).setY(166);
    if (S.enemy) {
      var hp = Math.max(0, S.enemy.hp / P.enemyHp);
      g.fillStyle(0x11172a, 1); g.fillRoundedRect(bx, 240, bw, 12, 6);
      if (hp > 0) { g.fillStyle(0xff4d6d, 1); g.fillRoundedRect(bx, 240, Math.max(8, bw * hp), 12, 6); }
    }
    this._timeTxt.setText(Math.max(0, Math.ceil(P.duration - S.rt)) + ' s');
    if (P.mode === 'collect') this._objTxt.setText((P.kind === 'cache' ? '\u25CF ' : '\u25C6 ') + S.got + ' / ' + P.total);
  }

  // =====================================================================
  // Boucle
  // =====================================================================
  _setTarget(p) {
    var S = this.S; if (!S || S.over) return;
    S.target.x = Math.max(44, Math.min(this.W - 44, p.x));
    S.target.y = Math.max(S.minY, Math.min(this.H - 90, p.y - 110));
  }

  update(time, delta) {
    if (!this.S) return;
    var dt = Math.min(delta || 16, 50) / 1000, S = this.S, P = this._plan.params;
    this._bg.rotation += dt * 0.07;
    var sp = 1 + (P.speedMult - 1) * 0.6;
    if (this._starsFar) this._starsFar.tilePositionY -= dt * 40 * sp;
    if (this._starsNear) this._starsNear.tilePositionY -= dt * 110 * sp;
    if (S.over) return;

    S.t += dt;
    this._movePlayer(dt);
    if (S.t < this.INTRO) { this._drawHud(); return; }
    if (S.banner) { var b = S.banner; S.banner = null; this.tweens.add({ targets: b, alpha: 0, duration: 300, onComplete: function () { b.destroy(); } }); }
    S.rt = S.t - this.INTRO;
    if (S.invuln > 0) { S.invuln -= dt; this._probeImg.setAlpha(Math.floor(S.invuln * 12) % 2 ? 0.35 : 1); if (S.invuln <= 0) this._probeImg.setAlpha(1); }

    if (P.mode === 'collect') this._spawnCollect(S.rt);
    if (P.mode === 'dodge') this._spawnDodge(S.rt);
    if (P.mode !== 'fight') this._spawnHazards(S.rt);
    this._stepEntities(dt);
    if (P.mode === 'dodge') this._stepWaves(dt);
    if (P.mode === 'fight') this._stepFight(dt);
    this._drawHud();

    if (S.over) return;
    if (S.rt >= P.duration) this._finish('time');
  }

  _movePlayer(dt) {
    var S = this.S, pr = S.probe, tg = S.target;
    var k = Math.min(1, 14 * dt), sx = (tg.x - pr.x) * k, sy = (tg.y - pr.y) * k, sl = Math.sqrt(sx * sx + sy * sy), mx = 1100 * dt;
    if (sl > mx) { sx *= mx / sl; sy *= mx / sl; }
    pr.x += sx; pr.y += sy;
    this._probe.setPosition(pr.x, pr.y);
    this._probe.rotation = Math.max(-0.4, Math.min(0.4, sx * 0.03));
  }

  // ---- Collecte : orbes qui tombent en spirale vers l'horizon + débris ----
  _spawnCollect(rt) {
    var S = this.S, P = this._plan.params, self = this;
    while (S.orbSpawned < P.total && rt >= S.orbSpawned * (P.duration - 3) / P.total) {
      var relic = P.kind === 'relique';
      var x = 80 + Math.random() * (this.W - 160);
      var spr = this.add.image(x, 215, relic ? 'bh_run_shard' : 'bh_run_orb').setDepth(15).setBlendMode(Phaser.BlendModes.ADD);
      spr.setTint(relic ? 0x8fe3ff : NEBUSTION.Economy.RES[P.resId].color);
      if (!relic) spr.setScale(1.05);
      this.tweens.add({ targets: spr, alpha: 0.65, duration: 260, yoyo: true, repeat: -1 });
      S.ents.push({ type: 'orb', x: x, y: 215, vx: 0, vy: 150 * P.speedMult, r: 20, spr: spr, spin: relic ? 1.5 : 0, pull: 1 });
      S.orbSpawned++;
    }
  }
  _spawnDodge(rt) {
    var S = this.S, P = this._plan.params;
    if (rt >= 1.2 && rt >= S.nextWave && rt < P.duration - 1.6) {
      S.nextWave = rt + P.waveEvery;
      var gapW = 240;
      S.waves.push({ y: 470 + Math.random() * (this.H - 780), gapX: 130 + Math.random() * (this.W - 260), gapW: gapW, t: 0, warn: 1.0, live: 0.45 });
    }
  }
  _spawnHazards(rt) {
    var S = this.S, P = this._plan.params;
    if (rt < S.nextHazard || rt > P.duration - 0.8) return;
    S.nextHazard = rt + P.hazardEvery * (0.7 + Math.random() * 0.6);
    var size = 0.7 + Math.random() * 0.6, x = 60 + Math.random() * (this.W - 120);
    var aimed = Math.random() < 0.3, vy = (170 + Math.random() * 60) * P.speedMult;
    var spr = this.add.image(x, 205, 'bh_run_debris').setDepth(16).setScale(size);
    S.ents.push({ type: 'debris', x: x, y: 205, vx: aimed ? (S.probe.x - x) * 0.3 : (Math.random() - 0.5) * 80, vy: vy, r: 20 * size, spr: spr, spin: (Math.random() - 0.5) * 4, pull: 0.5 });
  }

  _stepEntities(dt) {
    var S = this.S, pr = S.probe, cx = this.W / 2, P = this._plan.params, i, e, d;
    for (i = 0; i < S.ents.length; i++) {
      e = S.ents[i];
      e.vx += (cx - e.x) * 0.35 * e.pull * dt; e.vx *= (1 - 0.15 * dt);   // attraction du trou noir : trajectoires courbes
      e.x += e.vx * dt; e.y += e.vy * dt;
      e.spr.setPosition(e.x, e.y); e.spr.rotation += e.spin * dt;
      if (e.y > this.H + 50 || e.x < -70 || e.x > this.W + 70) { e.dead = true; continue; }
      d = Math.sqrt((e.x - pr.x) * (e.x - pr.x) + (e.y - pr.y) * (e.y - pr.y));
      if (e.type === 'orb' && d < e.r + 26) {
        e.dead = true; S.got++;
        this.fx.burst(P.kind === 'cache' ? P.resId : 'crystal', e.x, e.y, 8);
        this.fx.text(e.x, e.y - 20, '+1', P.kind === 'cache' ? NEBUSTION.Economy.RES[P.resId].hex : '#8fe3ff', 24, 40);
        this._sfx('ui_click', 0.5);
      } else if (e.type === 'debris' && d < e.r + 13) {
        e.dead = true; this.fx.burst('dust', e.x, e.y, 8);
        this._hitProbe();
      }
    }
    this._sweep(S.ents);
  }

  _sweep(list) {
    for (var i = list.length - 1; i >= 0; i--) { if (list[i].dead) { if (list[i].spr) list[i].spr.destroy(); list.splice(i, 1); } }
  }

  // ---- Marée : bandes horizontales avec une brèche ----
  _stepWaves(dt) {
    var S = this.S, g = this._waveG, pr = S.probe, w = this.W, i, wv, hit;
    g.clear();
    for (i = S.waves.length - 1; i >= 0; i--) {
      wv = S.waves[i]; wv.t += dt;
      var live = wv.t >= wv.warn, gx0 = wv.gapX - wv.gapW / 2, gx1 = wv.gapX + wv.gapW / 2, y0 = wv.y - 24;
      g.fillStyle(0xff4d6d, live ? 0.75 : 0.16 + 0.1 * Math.sin(wv.t * 18));
      g.fillRect(0, y0, gx0, 48); g.fillRect(gx1, y0, w - gx1, 48);
      if (!live) { g.lineStyle(2, 0x8fe3ff, 0.8); g.strokeRect(gx0, y0, wv.gapW, 48); }
      if (live && !S.over && S.invuln <= 0 && Math.abs(pr.y - wv.y) < 34 && (pr.x < gx0 || pr.x > gx1)) { this.fx.burst('dust', pr.x, pr.y, 10); this._hitProbe(); }
      if (wv.t >= wv.warn + wv.live) S.waves.splice(i, 1);
    }
  }

  // ---- Combat : ennemi (vrai sprite), tirs de la sonde automatiques, tirs ennemis à esquiver ----
  _stepFight(dt) {
    var S = this.S, P = this._plan.params, E = S.enemy, pr = S.probe, w = this.W, self = this, i, b, s, d;
    if (E.dead) { this._sweep(S.bullets); this._sweep(S.eshots); return; }
    E.t += dt;
    E.x = w / 2 + Math.sin(E.t * 0.75 * Math.min(1.6, P.speedMult)) * w * (P.boss ? 0.28 : 0.24); E.y = E.by + Math.sin(E.t * 1.7) * 18;
    E.spr.setPosition(E.x, E.y);

    // Tirs ennemis
    E.cd -= dt;
    if (E.cd <= 0) {
      E.cd = P.enemyFireEvery; E.volley++;
      var aim = Math.atan2(pr.y - E.y, pr.x - E.x), spd = Math.min(520, 300 * P.speedMult);
      var fire = function (a, sp) {
        var spr = self.add.image(E.x, E.y + 30, 'bh_run_orb').setTint(0xff4d6d).setBlendMode(Phaser.BlendModes.ADD).setScale(0.6).setDepth(17);
        S.eshots.push({ x: E.x, y: E.y + 30, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, spr: spr });
      };
      if (!P.boss) {
        if (E.volley % 2) fire(aim, spd); else [-0.3, 0, 0.3].forEach(function (o) { fire(aim + o, spd * 0.9); });
      } else {
        [-0.5, -0.25, 0, 0.25, 0.5].forEach(function (o) { fire(aim + o, spd * 0.9); });
        if (E.volley % 4 === 0) for (var k = 0; k < 14; k++) fire(k / 14 * Math.PI * 2, spd * 0.55);
      }
      this._sfx('attack', 0.35);
    }
    for (i = 0; i < S.eshots.length; i++) {
      s = S.eshots[i]; s.x += s.vx * dt; s.y += s.vy * dt; s.spr.setPosition(s.x, s.y);
      if (s.x < -30 || s.x > w + 30 || s.y > this.H + 30 || s.y < 150) { s.dead = true; continue; }
      d = (s.x - pr.x) * (s.x - pr.x) + (s.y - pr.y) * (s.y - pr.y);
      if (d < 21 * 21) { s.dead = true; if (S.invuln <= 0) this._hitProbe(); }
    }
    this._sweep(S.eshots);

    // Tirs de la sonde (2 tirs / 0,18 s). Dégâts par tir calés sur la puissance de l'équipe.
    S.fireCd -= dt;
    if (S.fireCd <= 0) {
      S.fireCd = 0.18;
      [-11, 11].forEach(function (ox) {
        var spr = self.add.image(pr.x + ox, pr.y - 26, 'bh_run_orb').setTint(0x8fe3ff).setBlendMode(Phaser.BlendModes.ADD).setScale(0.3, 0.9).setDepth(18);
        S.bullets.push({ x: pr.x + ox, y: pr.y - 26, spr: spr });
      });
    }
    var dmg = P.playerDps * 0.18 / 2 / 0.35;   // 2 tirs / 0,18 s ; playerDps suppose ~35 % de tirs au but
    for (i = 0; i < S.bullets.length; i++) {
      b = S.bullets[i]; b.y -= 900 * dt; b.spr.setPosition(b.x, b.y);
      if (b.y < 200) { b.dead = true; continue; }
      d = (b.x - E.x) * (b.x - E.x) + (b.y - E.y) * (b.y - E.y);
      if (d < (E.r + 8) * (E.r + 8)) {
        b.dead = true; E.hp -= dmg;
        this.fx.sparkle('core', b.x, b.y);
        E.spr.setTint(0xffb0a0); this.time.delayedCall(60, function () { if (E.spr.active) E.spr.clearTint(); });
        if (E.hp <= 0) { this._killEnemy(); break; }
      }
    }
    this._sweep(S.bullets);
  }

  _killEnemy() {
    var S = this.S, E = S.enemy; E.dead = true; E.hp = 0;
    this.fx.burst('core', E.x, E.y, 40); this.fx.ring(E.x, E.y, 0xffd166, 3.4); this.fx.shake(220, 0.008); this.fx.vibrate(60);
    this.tweens.add({ targets: E.spr, alpha: 0, scaleX: E.baseScale * 1.4, scaleY: E.baseScale * 1.4, duration: 450 });
    var self = this; this.time.delayedCall(500, function () { self._finish('win'); });
  }

  _hitProbe() {
    var S = this.S, P = this._plan.params, pr = S.probe;
    if (S.over || S.invuln > 0) return;
    S.invuln = 0.9; S.damage += P.hitDmg; S.hits++;
    this.fx.shake(120, 0.006); this.fx.vibrate(35); this.fx.ring(pr.x, pr.y, 0xff4d6d, 1.4);
    this.fx.text(pr.x, pr.y - 40, '-' + P.hitDmg, '#ff4d6d', 26, 50);
    this._sfx('hit', 0.6);
    if (S.damage >= this._startInteg) this._finish('destroyed');
  }

  _sfx(name, vol) { try { if (window.nebustionPlaySfx) window.nebustionPlaySfx(name, { volume: vol || 1 }); } catch (e) { /* ignore */ } }

  // =====================================================================
  // Fin d'épreuve : calcule la performance et rend la main à BlackHoleScene
  // =====================================================================
  _finish(reason) {
    var S = this.S, P = this._plan.params, self = this;
    if (S.over) return;
    S.over = true;
    var destroyed = reason === 'destroyed';
    var dmg = destroyed ? this._startInteg : Math.min(S.damage, this._startInteg);
    var perf = { score: 0, win: false, damage: dmg, resId: P.resId, summary: '' }, headline, hex;
    if (P.mode === 'collect') {
      perf.score = S.got / P.total; perf.win = !destroyed && S.got > 0;
      perf.summary = (P.kind === 'cache' ? 'Récolte : ' : 'Fragments captés : ') + S.got + ' / ' + P.total + ' (' + Math.round(perf.score * 100) + ' %)';
      headline = perf.score >= 0.8 ? 'EXCELLENT' : (perf.score >= 0.4 ? 'RÉCOLTE TERMINÉE' : 'MAIGRE BUTIN');
    } else if (P.mode === 'dodge') {
      perf.score = dmg === 0 ? 1 : 0; perf.win = !destroyed;
      perf.summary = dmg === 0 ? 'Esquive parfaite : aucun impact' : 'Impacts subis : ' + S.hits;
      headline = destroyed ? 'SONDE DÉTRUITE' : (dmg === 0 ? 'ESQUIVE PARFAITE' : 'MARÉE TRAVERSÉE');
    } else {
      var E = S.enemy, dealt = 1 - Math.max(0, E.hp) / P.enemyHp;
      perf.win = !destroyed && E.hp <= 0; perf.score = perf.win ? 1 : Math.max(0, Math.min(1, dealt));
      perf.summary = perf.win ? E.name + ' neutralisé' : E.name + ' : ' + Math.round(dealt * 100) + ' % des dégâts infligés';
      headline = perf.win ? 'VICTOIRE' : (destroyed ? 'SONDE DÉTRUITE' : 'ÉCHEC');
    }
    if (destroyed && P.mode !== 'fight') headline = 'SONDE DÉTRUITE';
    hex = (perf.win && !destroyed) ? '#5fd97a' : '#ff9a7b';
    this._sfx(perf.win ? 'victory' : 'defeat', 0.7);

    var w = this.W, h = this.H, ov = this.add.container(w / 2, h * 0.44).setDepth(150).setAlpha(0);
    ov.add(this.add.rectangle(0, 0, w, 170, 0x05070f, 0.82));
    ov.add(this.add.text(0, -32, headline, { fontFamily: 'Arial, sans-serif', fontSize: '36px', fontStyle: '900', color: hex, stroke: '#05070f', strokeThickness: 6 }).setOrigin(0.5));
    ov.add(this.add.text(0, 26, perf.summary, { fontFamily: 'Arial, sans-serif', fontSize: '18px', color: '#eaf2ff', align: 'center', wordWrap: { width: w - 80 } }).setOrigin(0.5));
    this.tweens.add({ targets: ov, alpha: 1, duration: 220 });
    this.time.delayedCall(1500, function () { self._close(perf); });
  }

  _close(perf) {
    var parent = this._parentKey, cb = this._onDone;
    this._onDone = null;
    this.scene.resume(parent);
    this.scene.stop();
    if (cb) cb(perf);
  }
};
