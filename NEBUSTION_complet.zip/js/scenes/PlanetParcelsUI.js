/**
 * NEBUSTION - PlanetParcelsUI (extension de PlanetScene, donc aussi d'ExoPlanetScene)
 * PARCELLES à acheter sur les planètes (données/règles : js/data/Parcels.js).
 *
 * Les parcelles sont dessinées SUR la sphère : chaque contour est une suite de points pris le long des méridiens et des
 * parallèles, projetés avec la même rotation que la planète. Les bords épousent donc la courbure : larges au centre du
 * globe, écrasés puis coupés net sur l'horizon. Rien n'est dessiné hors du mode « parcelles » (ni pendant le placement
 * d'une construction sur Nexus-01, où l'on voit ce qu'on possède) : la planète garde son aspect et ses FPS.
 *
 * Parcours : bouton PARCELLES (Nexus-01 : à côté de CONSTRUIRE ; mondes de la Nouvelle Galaxie : dans la fiche du monde)
 *  → on tourne la planète, on touche une parcelle → panneau (prix, état) → ACHETER.
 * Couleurs : vert = à toi · or = achetable (voisine de ton territoire) · gris = trop loin · blanc = sélection.
 */
(function () {
  'use strict';
  var PS = NEBUSTION.PlanetScene;
  if (!PS || !NEBUSTION.Parcels) return;
  var PC = function () { return NEBUSTION.Parcels; };
  var FONT = 'Arial, sans-serif';
  var C_OWN = 0x5dff9a, C_BUY = 0xffd166, C_LOCK = 0x6b7aa8, C_BAD = 0xff5b6e;
  var PANEL_H = 200;

  function nowMs() { return (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now(); }
  function isConvex(pts) {
    var n = pts.length, sign = 0, i, a, b, c, cr;
    for (i = 0; i < n; i++) {
      a = pts[i]; b = pts[(i + 1) % n]; c = pts[(i + 2) % n];
      cr = (b.x - a.x) * (c.y - b.y) - (b.y - a.y) * (c.x - b.x);
      if (Math.abs(cr) < 1e-9) continue;
      if (!sign) sign = cr > 0 ? 1 : -1; else if ((cr > 0 ? 1 : -1) !== sign) return false;
    }
    return true;
  }

  // ------------------------------------------------------------------ enveloppes de méthodes existantes
  var origApply = PS.prototype._applySphereTransform;
  var origBlocks = PS.prototype._uiBlocks;
  var origInfo = PS.prototype._showInfoPanel;
  var origHarvest = PS.prototype.harvest;
  var origUpgrade = PS.prototype.openUpgrade;
  var origStruct = PS.prototype._showStructBar;

  Object.assign(PS.prototype, {

    /** Dessin des parcelles à chaque frame (après la mise à jour de la sphère). */
    _applySphereTransform: function () {
      origApply.apply(this, arguments);
      if (this._pcGfx) this._pcDraw();
    },
    /** Le panneau de parcelles ouvert bloque la rotation par glissé, comme les autres panneaux. */
    _uiBlocks: function (pointer) {
      if (this._pcOpen && pointer.y > this.scale.height - PANEL_H - 128) return true;
      return origBlocks.apply(this, arguments);
    },
    // Pendant le mode parcelles, toucher un bâtiment / gisement ne fait rien (le toucher sert à choisir une parcelle).
    _showInfoPanel: function () { if (this._pcOpen) return; return origInfo.apply(this, arguments); },
    harvest: function () { if (this._pcOpen) return; return origHarvest.apply(this, arguments); },
    openUpgrade: function () { if (this._pcOpen) return; return origUpgrade.apply(this, arguments); },
    _showStructBar: origStruct ? function () { if (this._pcOpen) return; return origStruct.apply(this, arguments); } : undefined,

    // ------------------------------------------------------------------ mise en place
    /** worldId : 'nexus' ou l'id d'un monde de la Nouvelle Galaxie (pyros, aqualis, rubea, glacia). Sans effet sur une géante gazeuse. */
    _initParcels: function (worldId) {
      var W = PC().WORLDS[worldId];
      if (!W || !W.solid || !NEBUSTION.Resources || !NEBUSTION.Resources.state) return;
      this._pcWorld = worldId; this._pcOpen = false; this._pcSel = null; this._pcDirty = true; this._pcShown = false;
      this._pcLast = { y: NaN, p: NaN, mode: '', sel: null, t: 0 };
      this._pcState();
      this._pcGfx = this.add.graphics().setDepth(-0.5);
      this._pcLabels = [];
      this._pcBuildPanel();
      if (worldId === 'nexus') {
        var h = this.scale.height, y = this._btnY || (h - 172);
        this._pcBtn = new NEBUSTION.Button(this, 287, y, {
          width: 190, height: 50, label: 'PARCELLES', accentColor: 0x5dff9a, fontSize: '17px',
          onClick: () => this._pcEnter()
        });
        this._pcBtn.setDepth(1200);
      }
    },

    /** État des parcelles, recréé (territoire de départ + constructions existantes) s'il manque dans la sauvegarde. */
    _pcState: function () {
      var R = NEBUSTION.Resources, s = R.state.parcels;
      if (!s || !s.worlds || !s.worlds[this._pcWorld]) s = R.state.parcels = PC().normalizeState(s, R.state.planetBuild);
      return s;
    },

    /** Peut-on construire ici (Nexus-01) ? Toujours vrai si les parcelles ne sont pas actives. */
    _pcCanBuild: function (lon, lat) {
      if (!this._pcGfx || this._pcWorld !== 'nexus') return true;
      return PC().canBuild(this._pcState(), 'nexus', lon, lat);
    },

    // ------------------------------------------------------------------ panneau du bas
    _pcBuildPanel: function () {
      var w = this.scale.width, h = this.scale.height, self = this;
      var panel = this.add.container(w / 2, h + 320).setDepth(1105);
      var bg = this.add.graphics();
      bg.fillGradientStyle(0x101a33, 0x101a33, 0x0a1020, 0x0a1020, 0.98);
      bg.fillRoundedRect(-w * 0.47, -PANEL_H / 2, w * 0.94, PANEL_H, 22);
      bg.lineStyle(2, C_OWN, 0.6); bg.strokeRoundedRect(-w * 0.47, -PANEL_H / 2, w * 0.94, PANEL_H, 22);
      panel.add(bg);
      panel.add(this.add.rectangle(0, 0, w * 0.94, PANEL_H, 0x000000, 0.001).setInteractive());   // bloque les touchers vers ce qui est dessous
      var title = this.add.text(-w * 0.44, -74, '', { fontFamily: FONT, fontSize: '25px', fontStyle: 'bold', color: '#eaf2ff' }).setOrigin(0, 0.5);
      var status = this.add.text(-w * 0.44, -52, '', { fontFamily: FONT, fontSize: '17px', color: '#8ea0c8', wordWrap: { width: w * 0.86 } }).setOrigin(0, 0);
      var close = this.add.text(w * 0.44, -74, '✕', { fontFamily: FONT, fontSize: '30px', color: '#a9b8dc' }).setOrigin(0.5).setInteractive({ useHandCursor: true });
      close.on('pointerdown', () => self._pcExit());
      panel.add([title, status, close]);
      var slots = [], k;
      for (k = 0; k < 3; k++) {
        var ic = this.add.image(0, 10, 'tex_icon_crystal').setDisplaySize(24, 24).setVisible(false);
        var tx = this.add.text(0, 10, '', { fontFamily: FONT, fontSize: '19px', fontStyle: 'bold', color: '#eaf2ff' }).setOrigin(0, 0.5).setVisible(false);
        panel.add([ic, tx]); slots.push({ icon: ic, text: tx });
      }
      var left = new NEBUSTION.Button(this, -w * 0.44 + 105, 62, { width: 210, height: 52, label: 'FERMER', accentColor: 0x394869, fontSize: '18px', onClick: () => self._pcExit() });
      var right = new NEBUSTION.Button(this, w * 0.44 - 170, 62, { width: 340, height: 52, label: 'ACHETER', accentColor: C_OWN, fontSize: '19px', onClick: function () {} });
      panel.add([left, right]);
      this._pcPanel = panel; this._pcTitle = title; this._pcStatus = status; this._pcCost = slots; this._pcRight = right;
      this._pcClosedY = h + 320; this._pcOpenY = h - 128 - PANEL_H / 2;
    },

    _pcSetCost: function (cost) {
      var w = this.scale.width, E = NEBUSTION.Economy, R = NEBUSTION.Resources;
      var keys = cost ? Object.keys(cost) : [], x = -w * 0.44, i, slot, id;
      for (i = 0; i < 3; i++) {
        slot = this._pcCost[i];
        if (i < keys.length) {
          id = keys[i];
          slot.icon.setTexture('tex_icon_' + id).setDisplaySize(24, 24).setPosition(x + 12, 10).setVisible(true);
          slot.text.setText(E.fmt(cost[id], 0)).setColor(R.get(id) + 1e-9 >= cost[id] ? '#eaf2ff' : '#ff8fa3').setPosition(x + 30, 10).setVisible(true);
          x += 30 + slot.text.width + 20;
        } else { slot.icon.setVisible(false); slot.text.setVisible(false); }
      }
    },

    /** Texte et boutons du panneau selon la parcelle choisie (aucune / à moi / achetable / trop loin). */
    _pcRefreshPanel: function () {
      if (!this._pcPanel) return;
      var Pc = PC(), st = this._pcState(), wid = this._pcWorld, W = Pc.WORLDS[wid], self = this;
      var owned = Pc.ownedCount(st, wid), total = Pc.totalCells(), cell = this._pcSel ? Pc.get(this._pcSel) : null;
      var title, status, color = '#8ea0c8', cost = null, right = { label: 'ACHETER', color: 0x394869, disabled: true, fn: function () {} };
      var useTxt = wid === 'nexus' ? 'Il faut posséder une parcelle pour y construire.'
        : 'Chaque parcelle : +' + Math.round(Pc.COLONY_BONUS_EACH * 100) + ' % de production de la colonie (actuel : +' + Math.round(Pc.colonyBonus(st, wid) * 100) + ' %).';
      if (!cell) {
        title = 'Parcelles · ' + W.name;
        status = owned + ' / ' + total + ' possédées. Touche une parcelle sur la planète (glisse pour la tourner). ' + useTxt;
        cost = Pc.price(wid, Pc.paidCount(st, wid));
        if (owned >= total) { cost = null; status = 'Toute la planète t\'appartient (' + total + ' parcelles). ' + useTxt; }
      } else if (Pc.isOwned(st, wid, cell.id)) {
        title = 'Parcelle ' + cell.name + ' · à toi';
        status = wid === 'nexus' ? 'Tu peux construire ici. Touche une autre parcelle pour voir ses infos.' : useTxt;
        color = '#7dffb0';
        if (wid === 'nexus') right = { label: 'CONSTRUIRE', color: 0xffd166, disabled: false, fn: function () { self._pcExit(); if (self._openCatalog) self._openCatalog(); } };
      } else if (Pc.isBuyable(st, wid, cell.id)) {
        cost = Pc.price(wid, Pc.paidCount(st, wid));
        var afford = NEBUSTION.Resources.canAfford(cost);
        title = 'Parcelle ' + cell.name;
        status = owned === 0 ? 'Site d\'atterrissage : ta première parcelle, choisis bien. ' + useTxt
          : (afford ? 'Disponible, voisine de ton territoire. Chaque achat renchérit la suivante.' : 'Ressources insuffisantes : récolte encore un peu.');
        color = afford ? '#ffe9a3' : '#ff8fa3';
        right = { label: 'ACHETER', color: afford ? C_OWN : 0x394869, disabled: !afford, fn: function () { self._pcBuySel(); } };
      } else {
        title = 'Parcelle ' + cell.name + ' · trop loin';
        status = 'Achète d\'abord une parcelle voisine de ton territoire (bord en commun).';
        color = '#ff8fa3';
      }
      this._pcTitle.setText(title);
      this._pcStatus.setText(status).setColor(color);
      this._pcSetCost(cost);
      this._pcRight.labelText.setText(right.label); this._pcRight.setLook(right.color, right.disabled ? '#9fb0d6' : '#eaf2ff');
      this._pcRight.onClick = right.fn; this._pcRight.setDisabled(right.disabled);
    },

    _pcEnter: function () {
      if (!this._pcGfx || this._pcOpen || this._placing) return;
      if (this._sheetOpen && this._closeSheet) this._closeSheet(true);
      if (this._barOpen && this._hideBar) this._hideBar();
      if (this._panelOpen && this._hideInfoPanel) this._hideInfoPanel();
      this._pcOpen = true; this._pcSel = null; this._pcDirty = true;
      if (this._buildBtn) this._buildBtn.setVisible(false);
      if (this._pcBtn) this._pcBtn.setVisible(false);
      this._pcRefreshPanel();
      this.tweens.add({ targets: this._pcPanel, y: this._pcOpenY, duration: 300, ease: 'Back.easeOut' });
    },

    _pcExit: function () {
      if (!this._pcOpen) return;
      this._pcOpen = false; this._pcSel = null; this._pcDirty = true;
      if (this._buildBtn) this._buildBtn.setVisible(true);
      this.tweens.add({ targets: this._pcPanel, y: this._pcClosedY, duration: 240, ease: 'Sine.easeIn' });
    },

    // ------------------------------------------------------------------ toucher / achat
    /** Toucher (sans glissé) sur la planète en mode parcelles : choisit la parcelle sous le doigt. */
    _onParcelTap: function (pointer) {
      if (!this._pcOpen || this._uiBlocks(pointer)) return;
      var pt = this._unprojectSphere(pointer.x, pointer.y);
      var c = pt ? PC().cellAt(pt.lonDeg, pt.latDeg) : null;
      this._pcSel = c ? c.id : null;
      this._pcDirty = true;
      this._pcRefreshPanel();
    },

    _pcBuySel: function () {
      var Pc = PC(), R = NEBUSTION.Resources, E = NEBUSTION.Economy, id = this._pcSel, wid = this._pcWorld;
      if (!id) return;
      this._pcState();
      var res = Pc.buy(R, wid, id), cell = Pc.get(id);
      if (!res.ok) {
        var msg = { cost: 'Ressources insuffisantes', loin: 'Parcelle trop loin', possedee: 'Déjà à toi' }[res.reason] || 'Impossible';
        var sub = null;
        if (res.reason === 'cost' && res.cost) {
          var miss = Object.keys(res.cost).filter(function (rid) { return R.get(rid) + 1e-9 < res.cost[rid]; });
          sub = 'Il manque : ' + miss.slice(0, 2).map(function (rid) { return E.fmt(Math.ceil(res.cost[rid] - R.get(rid)), 0) + ' ' + E.RES[rid].short; }).join('  •  ');
        }
        if (this.fx) { this.fx.toast(msg, sub); this.fx.vibrate(15); }
        this._pcRefreshPanel();
        return;
      }
      var p = this._projectSphere(cell.lonC, cell.latC);
      if (this.fx) {
        this.fx.ring(p.x, p.y, C_OWN, 2);
        this.fx.burst('crystal', p.x, p.y, 16);
        this.fx.text(p.x, p.y - 40, 'PARCELLE ' + cell.name, '#7dffb0', 28, 70);
        var W = Pc.WORLDS[wid];
        if (W.use === 'colony') this.fx.toast('Parcelle ' + cell.name + ' achetée', 'Colonie de ' + W.name + ' : +' + Math.round(Pc.colonyBonus(R.state.parcels, wid) * 100) + ' % de production');
        this.fx.vibrate(25);
      }
      try { if (window.nebustionPlaySfx) window.nebustionPlaySfx('build'); } catch (e) { /* son facultatif */ }
      this._pcDirty = true;
      this._pcRefreshPanel();
    },

    // ------------------------------------------------------------------ dessin sur la sphère
    _pcLabel: function (i) {
      var t = this._pcLabels[i];
      if (!t) {
        t = this.add.text(0, 0, '', { fontFamily: FONT, fontSize: '15px', fontStyle: 'bold', color: '#ffffff', stroke: '#050810', strokeThickness: 3 }).setOrigin(0.5).setDepth(-0.4);
        this._pcLabels[i] = t;
      }
      return t;
    },

    _pcHideLabels: function (from) {
      for (var i = from || 0; i < this._pcLabels.length; i++) if (this._pcLabels[i].visible) this._pcLabels[i].setVisible(false);
    },

    /**
     * Redessine la grille : chaque parcelle = contour suivant méridiens/parallèles, projeté avec la rotation courante, coupé net sur
     * l'horizon (points de la moitié cachée retirés, puis arc de l'horizon). Redessiné seulement si la vue a changé.
     */
    _pcDraw: function () {
      var mode = this._pcOpen ? 'buy' : (this._placing && this._pcWorld === 'nexus' ? 'build' : '');
      var g = this._pcGfx, L = this._pcLast;
      // Le bouton PARCELLES suit la visibilité de CONSTRUIRE (caché quand un panneau de construction est ouvert).
      if (this._pcBtn) {
        var vis = !(this._pcOpen || this._sheetOpen || this._barOpen || this._placing);
        if (vis !== this._pcBtn.visible) this._pcBtn.setVisible(vis);
      }
      if (!mode) {
        if (this._pcShown) { g.clear(); this._pcHideLabels(); this._pcShown = false; this._pcDirty = false; }
        return;
      }
      if (this._pcOpen) this._idleTime = 0;   // pas de rotation automatique pendant qu'on choisit une parcelle
      var nowT = nowMs(), moved = L.y !== this._rotYaw || L.p !== this._rotPitch;
      if (!this._pcDirty && !moved && L.mode === mode && L.sel === this._pcSel && !(this._pcSel && nowT - L.t > 80)) return;
      L.y = this._rotYaw; L.p = this._rotPitch; L.mode = mode; L.sel = this._pcSel; L.t = nowT;
      this._pcDirty = false; this._pcShown = true;

      var Pc = PC(), st = this._pcState(), wid = this._pcWorld, cells = Pc.CELLS;
      var cy = Math.cos(this._rotYaw), sy = Math.sin(this._rotYaw), cp = Math.cos(this._rotPitch), sp = Math.sin(this._rotPitch);
      var CX = this._planetCX, CY = this._planetCY, R = this._planetR;
      var pulse = 0.5 + 0.5 * Math.sin(nowT / 220), labelN = 0, i, k, c, m, v, ring, n, pts, sel;
      // Table des parcelles possédées (recherche instantanée) : plus rapide qu'un indexOf par parcelle et par frame.
      var ownList = Pc.ownedList(st, wid), ownSet = {}, blank = ownList.length === 0;
      for (k = 0; k < ownList.length; k++) ownSet[ownList[k]] = true;
      g.clear();

      for (i = 0; i < cells.length; i++) {
        c = cells[i]; m = Pc.mesh(c);
        // centre : rejette d'emblée ce qui est nettement derrière la planète
        var ca = m.center[0] * cy + m.center[2] * sy, cza = -m.center[0] * sy + m.center[2] * cy;
        var cxu = ca, cyu = m.center[1] * cp - cza * sp, czu = m.center[1] * sp + cza * cp;
        if (czu < -0.42) continue;
        ring = m.ring; n = ring.length;
        var ux = [], uy = [], uz = [];
        for (k = 0; k < n; k++) {
          v = ring[k];
          var xa = v[0] * cy + v[2] * sy, za = -v[0] * sy + v[2] * cy;
          ux.push(xa); uy.push(v[1] * cp - za * sp); uz.push(v[1] * sp + za * cp);
        }
        // coupe sur l'horizon (z = 0) : on garde les points visibles et on insère les points d'entrée/sortie sur le limbe
        pts = [];
        for (k = 0; k < n; k++) {
          var b = (k + 1) % n, ain = uz[k] >= 0, bin = uz[b] >= 0;
          if (ain) pts.push({ x: ux[k], y: uy[k], limb: 0 });
          if (ain !== bin) {
            var t = uz[k] / (uz[k] - uz[b]), qx = ux[k] + (ux[b] - ux[k]) * t, qy = uy[k] + (uy[b] - uy[k]) * t, ql = Math.sqrt(qx * qx + qy * qy) || 1;
            pts.push({ x: qx / ql, y: qy / ql, limb: bin ? 2 : 1 });   // 1 = sortie, 2 = entrée
          }
        }
        if (pts.length < 3) continue;
        // entre une sortie et l'entrée suivante, le contour longe l'horizon (arc de cercle) et non une corde
        var full = [], q, a0, a1, d, steps, s2, pa, pb;
        for (q = 0; q < pts.length; q++) {
          pa = pts[q]; pb = pts[(q + 1) % pts.length]; full.push(pa);
          if (pa.limb === 1 && pb.limb === 2) {
            a0 = Math.atan2(pa.y, pa.x); a1 = Math.atan2(pb.y, pb.x); d = a1 - a0;
            while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI;
            steps = Math.ceil(Math.abs(d) / 0.12);
            for (s2 = 1; s2 < steps; s2++) full.push({ x: Math.cos(a0 + d * s2 / steps), y: Math.sin(a0 + d * s2 / steps), limb: 0 });
          }
        }
        var scr = [], ax = 0, ay = 0;
        for (q = 0; q < full.length; q++) { var X = CX + full[q].x * R, Y = CY - full[q].y * R; scr.push({ x: X, y: Y }); ax += X; ay += Y; }
        ax /= scr.length; ay /= scr.length;

        var owned = !!ownSet[c.id], buyable = false;
        if (!owned) {
          if (blank) buyable = true;
          else { var nbs = Pc.neighbors(c), z2; for (z2 = 0; z2 < nbs.length; z2++) if (ownSet[nbs[z2].id]) { buyable = true; break; } }
        }
        sel = (c.id === this._pcSel);
        var fade = Math.min(1, Math.max(0.12, (czu + 0.12) / 0.5));
        var col, fillA, lineW, lineA;
        if (mode === 'buy') {
          if (owned) { col = C_OWN; fillA = 0.14; lineW = 1.6; lineA = 0.75; }
          else if (buyable) { col = C_BUY; fillA = 0.10; lineW = 1.6; lineA = 0.85; }
          else { col = C_LOCK; fillA = 0; lineW = 1; lineA = 0.35; }
        } else {   // placement d'une construction : ce qui est à moi en vert, le reste voilé de rouge sombre
          if (owned) { col = C_OWN; fillA = 0.06; lineW = 1.2; lineA = 0.5; } else { col = C_BAD; fillA = 0; lineW = 1; lineA = 0.28; }
        }
        var conv = isConvex(scr), fillPoly = function (color, alpha) {
          g.fillStyle(color, alpha);
          if (conv) g.fillPoints(scr, true);
          else { var f; for (f = 0; f < scr.length; f++) g.fillTriangle(ax, ay, scr[f].x, scr[f].y, scr[(f + 1) % scr.length].x, scr[(f + 1) % scr.length].y); }
        };
        if (mode === 'buy' && !owned && !buyable) fillPoly(0x000000, 0.28 * fade);
        else if (mode === 'build' && !owned) fillPoly(0x000000, 0.36 * fade);
        if (fillA > 0) fillPoly(col, fillA * fade);
        if (sel) fillPoly(0xffffff, (0.14 + 0.12 * pulse) * fade);
        g.lineStyle(lineW, col, lineA * fade); g.strokePoints(scr, true);
        if (sel) {
          g.lineStyle(7, col, 0.28 * fade); g.strokePoints(scr, true);
          g.lineStyle(3, 0xffffff, (0.75 + 0.25 * pulse) * fade); g.strokePoints(scr, true);
        }

        // nom de la parcelle (D10, C7…) au centre, seulement quand elle est bien de face
        if (mode === 'buy' && czu > 0.4 && labelN < 44) {
          var lt = this._pcLabel(labelN++), sc2 = 0.62 + 0.38 * czu, lc = owned ? '#b9ffd2' : (buyable ? '#ffe9a3' : '#8a97bd');
          if (lt._nm !== c.name) { lt._nm = c.name; lt.setText(c.name); }
          if (lt._cl !== lc) { lt._cl = lc; lt.setColor(lc); }
          lt.setPosition(CX + cxu * R, CY - cyu * R).setScale(sc2).setAlpha((owned ? 0.75 : (buyable ? 0.95 : 0.5)) * fade).setVisible(true);
        }
      }
      this._pcHideLabels(labelN);
    }
  });
  if (!PS.prototype._showStructBar) delete PS.prototype._showStructBar;
})();
