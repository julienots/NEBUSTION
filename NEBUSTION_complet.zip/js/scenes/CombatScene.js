/**
 * NEBUSTION - CombatScene
 * L'arène de combat spatial (Phaser). Elle ne contient AUCUNE règle de combat : elle pilote
 * NEBUSTION.CombatEngine (pas de simulation fixes de 50 ms) et traduit ses événements en
 * animations lisibles et légères pour Android :
 *  - fond 2.5D animé (étoiles en parallaxe, planète, astéroïdes, sol en perspective) ;
 *  - 5 héros (portraits réels) contre 1 à 3 ennemis / 1 boss, barres de vie, bouclier, énergie ;
 *  - projectiles, coups de mêlée, impacts, particules (6 émetteurs partagés, aucune création
 *    de masse), chiffres flottants MIS EN RÉSERVE (12 textes réutilisés, débit limité) ;
 *  - boutons de compétence / ultime par héros (utilisables en AUTO comme en MANUEL) ;
 *  - mode AUTO / MANUEL, vitesse ×1/×2/×3, pause, barre de boss à phases ;
 *  - écran de victoire / défaite : étoiles, ressources, XP, fragments, montées de niveau.
 * Les récompenses sont créditées UNE SEULE FOIS via NEBUSTION.Combat.grantRewards.
 * Mode INVASION (module 5C) : init({ planetId }) → même arène, mêmes héros, mêmes animations ; les ennemis viennent de la
 * défense d'une planète (vagues successives), les récompenses/conquêtes passent par NEBUSTION.Combat.grantInvasionRewards.
 */
window.NEBUSTION = window.NEBUSTION || {};

// =====================================================================
// Vue d'une unité (héros ou ennemi) : sprite, ombre, barres, statuts
// =====================================================================
NEBUSTION.CombatUnitView = class CombatUnitView {
  constructor(scene, unit, x, y, size, isHero, bossBar) {
    this.scene = scene;
    this.unit = unit;
    this.isHero = isHero;
    this.size = size;
    this.baseX = x; this.baseY = y;
    this.bossBar = !!bossBar;            // boss : pas de petite barre (grande barre en haut)
    this.dead = false;
    this.targetHp = unit.hp; this.shownHp = unit.hp; this.ghostHp = unit.hp;
    this._barKey = '';
    this._statusKey = '';
    this._breakKey = '';
    this.lastNumAt = 0;
    this.focusRing = scene.add.graphics().setDepth(150);
    this.breakBar = scene.add.graphics().setDepth(145);

    this.container = scene.add.container(x, y).setDepth(100 + y / 10);
    this.shadow = scene.add.image(0, size * 0.48, 'tex_shadow').setDisplaySize(size * 0.95, size * 0.24).setAlpha(0.75);
    this.body = scene.add.container(0, 0);
    this.float = scene.add.container(0, 0);

    var H = NEBUSTION.Heroes, w, h;
    if (isHero) {
      w = size * 0.79; h = size;
      this.sprite = scene.add.image(0, 0, unit.portraitKey).setDisplaySize(w, h);
      var hero = H.get(unit.heroId), rarity = H.RARITIES[hero.rarity];
      this.frame = scene.add.graphics();
      this.frame.lineStyle(3, rarity.color, 0.95);
      this.frame.strokeRoundedRect(-w / 2, -h / 2, w, h, 10);
      this.float.add([this.sprite, this.frame]);
      // Skin équipé (module Personnalisation) : teinte + aura légère ; purement visuel, aucun effet sur les stats.
      var skin = NEBUSTION.SkinManager && NEBUSTION.SkinManager.equippedSkin('hero', unit.heroId);
      if (skin) {
        var fx = NEBUSTION.SkinFX.attach(scene, this.float, this.sprite, skin, w, h, { light: true });
        this.skinTint = fx ? fx.tint : null;
      }
    } else {
      w = size; h = size;
      this.sprite = scene.add.image(0, 0, unit.textureKey).setDisplaySize(w, h);
      this.float.add(this.sprite);
    }
    this.bubble = scene.add.image(0, 0, 'tex_shield_bubble').setDisplaySize(size * 1.1, size * 1.1).setAlpha(0);
    this.float.add(this.bubble);
    this.body.add(this.float);

    this.hpBar = scene.add.graphics();
    this.hpBar.y = -h / 2 - 16;
    this.status = scene.add.text(0, -h / 2 - 40, '', { fontFamily: 'Arial, sans-serif', fontSize: '17px' }).setOrigin(0.5);
    this.container.add([this.shadow, this.body, this.hpBar, this.breakBar, this.focusRing, this.status]);

    // Cibler un ennemi directement pendant le combat : le verrouillage est volontairement
    // séparé des boutons de compétences pour permettre de préparer une chaîne d'attaques.
    if (!isHero) {
      this.hitZone = scene.add.zone(0, 0, size * 1.05, size * 1.05).setInteractive({ useHandCursor: true });
      this.hitZone.on('pointerdown', function () { if (scene._focusEnemy) scene._focusEnemy(this.unit); }.bind(this));
      this.container.add(this.hitZone);
    }

    // Flottement (respiration) : un seul tween par unité, décalé pour éviter l'effet « chorégraphie »
    scene.tweens.add({
      targets: this.float, y: -6 - Math.random() * 3, duration: 850 + Math.random() * 500,
      yoyo: true, repeat: -1, ease: 'Sine.easeInOut', delay: Math.random() * 700
    });
  }

  get cx() { return this.container.x; }
  get cy() { return this.container.y - this.size * 0.05; }

  flash() {
    var s = this.sprite, scene = this.scene;
    if (!s || this.dead) return;
    s.setTintFill(0xffffff);
    var self = this;
    scene.time.delayedCall(70, function () {
      if (!s.active) return;
      s.clearTint();
      if (self.skinTint !== null && self.skinTint !== undefined) s.setTint(self.skinTint);   // restaure la teinte du skin
    });
  }

  /** Recul + « punch » à l'impact (sans toucher à la position de base). */
  knock(dirX, dirY, power) {
    var b = this.body, scene = this.scene;
    if (this.dead) return;
    scene.tweens.killTweensOf(b);
    b.x = 0; b.y = 0; b.scale = 1;
    scene.tweens.add({ targets: b, x: dirX * power, y: dirY * power, scale: 0.94, duration: 70, yoyo: true, ease: 'Sine.easeOut',
      onComplete: function () { if (b.active) { b.x = 0; b.y = 0; b.scale = 1; } } });
  }

  lunge(dx, dy, ms) {
    var b = this.body, scene = this.scene;
    if (this.dead) return;
    scene.tweens.killTweensOf(b);
    b.x = 0; b.y = 0; b.scale = 1;
    scene.tweens.add({ targets: b, x: dx, y: dy, duration: ms, yoyo: true, ease: 'Cubic.easeOut',
      onComplete: function () { if (b.active) { b.x = 0; b.y = 0; } } });
  }

  die(big) {
    var self = this, scene = this.scene;
    if (this.dead) return;
    this.dead = true;
    this.hpBar.setVisible(false);
    this.status.setText('');
    scene.tweens.killTweensOf(this.body);
    scene.tweens.add({
      targets: this.body, alpha: 0, scale: big ? 1.25 : 0.55, angle: this.isHero ? 0 : (Math.random() < 0.5 ? -25 : 25),
      y: this.isHero ? 14 : 0, duration: big ? 900 : 480, ease: 'Cubic.easeIn'
    });
    scene.tweens.add({ targets: this.shadow, alpha: 0, duration: 400 });
  }

  /** Statuts affichés au-dessus de l'unité (max 3 glyphes). */
  updateStatus(engine) {
    var u = this.unit, s = '';
    if (!u.alive) return;
    if (u.stunTime > 0) s += '💫';
    if (u.tauntUntil > engine.time) s += '🎯';
    if (u.dots.length) s += u.dots[0].kind === 'burn' ? '🔥' : (u.dots[0].kind === 'poison' ? '☠️' : '🩸');
    if (u.missUntil > engine.time) s += '🌑';
    if (engine._m(u, 'spd') < 1) s += '❄';
    if (u.mods.some(function (m) { return m.mult > 1 && m.until > engine.time; })) s += '▲';
    s = s.length > 6 ? s.slice(0, 6) : s;
    if (s !== this._statusKey) { this._statusKey = s; this.status.setText(s); }
    var focused = !this.isHero && this.scene.engine && this.scene.engine.focusTargetUid === u.uid;
    this.focusRing.clear();
    if (focused && u.alive) {
      this.focusRing.lineStyle(3, 0x00e5ff, 0.95);
      this.focusRing.strokeEllipse(0, 0, this.size * 1.08, this.size * 1.08);
      this.focusRing.lineStyle(1, 0x7fe8ff, 0.55);
      this.focusRing.strokeEllipse(0, 0, this.size * 1.18, this.size * 1.18);
    }
    if (!this.isHero && !this.bossBar && u.alive) {
      var bg = Math.max(0, Math.min(1, (u.breakGauge == null ? 100 : u.breakGauge) / 100));
      var bw = this.size * 0.72, bx = -bw / 2, by = this.size * 0.54;
      this.breakBar.clear();
      this.breakBar.fillStyle(0x05070f, 0.85); this.breakBar.fillRoundedRect(bx - 1, by - 1, bw + 2, 7, 3);
      this.breakBar.fillStyle(u.breakUntil > this.scene.engine.time ? 0xffd166 : 0x9d6cff, 1);
      this.breakBar.fillRoundedRect(bx, by, bw * bg, 5, 2);
      if (u.breakUntil > this.scene.engine.time) {
        this.breakBar.lineStyle(2, 0xffd166, 0.9); this.breakBar.strokeRoundedRect(bx - 2, by - 2, bw + 4, 9, 3);
      }
    } else { this.breakBar.clear(); }
    var sh = u.shield > 0 ? 0.55 : 0;
    if (this.bubble.alpha !== sh) this.bubble.setAlpha(sh);
  }

  updateBars(dt) {
    var u = this.unit;
    if (this.dead) return;
    var max = Math.max(1, u.maxHp);
    this.shownHp += (this.targetHp - this.shownHp) * Math.min(1, dt * 12);
    if (Math.abs(this.targetHp - this.shownHp) < 0.5) this.shownHp = this.targetHp;
    if (this.ghostHp < this.shownHp) this.ghostHp = this.shownHp;
    else this.ghostHp = Math.max(this.shownHp, this.ghostHp - max * 0.4 * dt);
    if (this.bossBar) return;

    var w = this.isHero ? 96 : 84;
    var hp = Math.round(this.shownHp / max * 96), gh = Math.round(this.ghostHp / max * 96);
    var sh = Math.round(Math.min(1, u.shield / max) * 48);
    var en = this.isHero ? Math.round(u.energy) : 0;
    var key = hp + '|' + gh + '|' + sh + '|' + en;
    if (key === this._barKey) return;
    this._barKey = key;

    var g = this.hpBar, f = this.shownHp / max;
    g.clear();
    g.fillStyle(0x05070f, 0.85); g.fillRoundedRect(-w / 2 - 2, -6, w + 4, this.isHero ? 15 : 12, 4);
    g.fillStyle(0xffffff, 0.55); g.fillRect(-w / 2, -4, w * (this.ghostHp / max), 7);
    var col = f > 0.5 ? 0x5fd97a : (f > 0.25 ? 0xffb84d : 0xff4d5e);
    if (!this.isHero) col = f > 0.25 ? 0xff6a5e : 0xff2d3d;
    g.fillStyle(col, 1); g.fillRect(-w / 2, -4, w * f, 7);
    if (u.shield > 0) { g.fillStyle(0x7fe8ff, 0.95); g.fillRect(-w / 2, -4, w * Math.min(1, u.shield / max), 3); }
    if (this.isHero) {
      g.fillStyle(0x2a2f44, 1); g.fillRect(-w / 2, 5, w, 3);
      g.fillStyle(u.energy >= 100 ? 0xffd166 : 0xb47bff, 1); g.fillRect(-w / 2, 5, w * (u.energy / 100), 3);
    }
  }
};

// =====================================================================
// Scène de combat
// =====================================================================
NEBUSTION.CombatScene = class CombatScene extends Phaser.Scene {
  constructor() {
    super('CombatScene');
  }

  init(data) {
    data = data || {};
    var EN = NEBUSTION.Enemies, C = NEBUSTION.Combat;
    this.isInvasion = !!data.planetId;
    if (this.isInvasion) {
      this.planetId = data.planetId;
      this.difficulty = 'normal'; // la difficulté d'une invasion vient de la défense de la planète, pas d'un choix
    } else {
      this.stageId = EN.stage(data.stageId) ? data.stageId : EN.firstStageId();
      this.difficulty = EN.DIFFICULTIES[data.difficulty] ? data.difficulty : C.getDifficulty();
    }
  }

  create() {
    var self = this, w = this.scale.width, h = this.scale.height;
    var C = NEBUSTION.Combat;

    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(400, 5, 7, 15);
    this.tweens.timeScale = 1;
    this.time.timeScale = 1;

    this._ready = false;
    this.mode = 'auto';
    this.speed = 1;
    this.paused = false;
    this.ended = false;
    this._acc = 0;
    this._granted = null;
    this.views = {};
    this.heroViews = [];
    this.enemyViews = [];
    this.bossView = null;
    this._resultShown = false;
    // La même instance de scène est réutilisée à chaque combat : tout l'état par-combat est remis à zéro ici.
    this._leaving = false;
    this.resultLayer = null;
    this._ts = null; this._rage = null; this._alive = null; this._comboKey = ''; this._focusKey = '';
    this.bossBarGfx = null;

    var battle = null;
    if (this.isInvasion) {
      // Invasion valide seulement si : scan valide, planète non conquise, atteignable, équipe de 5 héros.
      var GM = NEBUSTION.GalaxyManager, EEM = NEBUSTION.EmpireEvolutionManager, nowT = Date.now();
      var okInv = GM.canInvade(this.planetId, nowT).ok && EEM.isReachable(this.planetId) && C.getTeam().length === 5;
      battle = okInv ? C.buildInvasionBattle(this.planetId, this.mode) : null;
      if (!battle) {
        // Scan expiré / planète déjà conquise / hors de portée : retour sans risque à la Galaxie (aucune récompense).
        this._leaving = true;
        this.scene.start('GalaxyScene', { navKey: 'galaxy', title: 'Galaxie', planetId: this.planetId });
        return;
      }
    } else {
      battle = C.buildBattle(this.stageId, this.difficulty, this.mode);
    }
    this.battle = battle;
    this.engine = battle.engine;
    this.stageDef = this.isInvasion
      ? { id: this.planetId, name: battle.planet ? battle.planet.name : 'Invasion', kind: 'invasion' }
      : battle.stageDef;
    this.isBossStage = this.stageDef.kind === 'boss';

    this._buildBackground();
    this._buildParticles();
    this._buildFloatPool();
    this._layoutHeroes();
    this._layoutEnemies();
    this._buildArenaMechanics();
    this._buildTopBar();
    this._buildCards();
    this._buildOverlays();

    this._bossShown = 1; this._bossGhost = 1; this._bossKey = '';
    if (this.bossView) this._buildBossBar();

    this.events.once('shutdown', function () {
      self.tweens.timeScale = 1; self.time.timeScale = 1;
    });

    this._ready = true;
    // Petite annonce d'ouverture (nom du stage / du boss / de la planète envahie)
    var openLabel = this.isInvasion ? ('⚔ INVASION — ' + this.stageDef.name) : (this.isBossStage ? '☠ ' + this.stageDef.name : this.stageDef.name);
    this._banner(openLabel, this.isBossStage ? '#ff6a78' : '#eaf2ff', this.isBossStage ? 26 : 24, 1500);
  }

  // =====================================================================
  // Décor 2.5D
  // =====================================================================
  _buildBackground() {
    var self = this, w = this.scale.width, h = this.scale.height;
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });

    // Planète lointaine (plan 1) + halo de boss
    this.bgPlanet = this.add.image(w * 0.2, 300, 'tex_planet_nexus').setScale(0.5).setAlpha(0.55).setDepth(-65);
    this.tweens.add({ targets: this.bgPlanet, angle: 360, duration: 300000, repeat: -1, ease: 'Linear' });
    if (this.isBossStage) {
      this.bossGlow = this.add.image(w / 2, 380, 'tex_glow_red').setDisplaySize(900, 700).setAlpha(0.22).setBlendMode(Phaser.BlendModes.ADD).setDepth(-55);
      this.tweens.add({ targets: this.bossGlow, alpha: 0.4, duration: 1400, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    }

    // Sol en perspective (plan 3) sous les héros
    this.floor = this.add.image(w / 2, 840, 'tex_arena_floor').setDepth(-40).setAlpha(0.9);
    this.tweens.add({ targets: this.floor, alpha: 0.6, duration: 2600, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });

    // Plateformes lumineuses sous chaque camp
    var pads = this.add.graphics().setDepth(-30);
    pads.lineStyle(2, 0xff4d6d, 0.35); pads.strokeEllipse(w / 2, 470, 620, 130);
    pads.lineStyle(1.5, 0xff4d6d, 0.18); pads.strokeEllipse(w / 2, 470, 460, 92);
    pads.lineStyle(2, 0x00e5ff, 0.4); pads.strokeEllipse(w / 2, 830, 690, 300);
    pads.lineStyle(1.5, 0x00e5ff, 0.2); pads.strokeEllipse(w / 2, 830, 500, 210);

    // Astéroïdes en dérive (plans 2 et 4 : lents derrière, rapides devant)
    this.rocks = [];
    for (var i = 0; i < 5; i++) {
      var near = i >= 3;
      var img = this.add.image(Math.random() * w, 200 + Math.random() * 760, i % 2 ? 'tex_asteroid_a' : 'tex_asteroid_b')
        .setScale(near ? 0.9 : 0.35 + Math.random() * 0.25).setAlpha(near ? 0.55 : 0.4).setDepth(near ? 60 : -45);
      img.setAngle(Math.random() * 360);
      this.rocks.push({ img: img, vx: near ? 26 + Math.random() * 14 : 6 + Math.random() * 6, spin: (Math.random() - 0.5) * 12 });
    }

    // Éclair blanc plein écran (ultimes, nova de boss) et voile sombre (cinématique d'ultime)
    this.flashRect = this.add.rectangle(w / 2, h / 2, w, h, 0xffffff, 1).setAlpha(0).setDepth(890);
    this.dimRect = this.add.rectangle(w / 2, h / 2, w, h, 0x02040a, 1).setAlpha(0).setDepth(880);
  }

  // =====================================================================
  // Particules partagées (6 émetteurs, jamais recréés)
  // =====================================================================
  _buildParticles() {
    var self = this;
    function mk(key, extra) {
      var cfg = {
        emitting: false, lifespan: { min: 260, max: 560 }, speed: { min: 60, max: 210 }, angle: { min: 0, max: 360 },
        scale: { start: 0.5, end: 0 }, alpha: { start: 1, end: 0 }, blendMode: 'ADD'
      };
      Object.keys(extra || {}).forEach(function (k) { cfg[k] = extra[k]; });
      return self.add.particles(0, 0, key, cfg).setDepth(520);
    }
    this.pfx = {
      hit: mk('tex_glow_orange'),
      crit: mk('tex_glow_gold', { scale: { start: 0.8, end: 0 }, speed: { min: 90, max: 280 } }),
      hurt: mk('tex_glow_red'),
      heal: mk('tex_glow_green', { speed: { min: 20, max: 90 }, gravityY: -120, lifespan: { min: 500, max: 900 } }),
      ice: mk('tex_glow_ice'),
      boom: mk('tex_glow_orange', { scale: { start: 1.1, end: 0 }, speed: { min: 80, max: 340 }, lifespan: { min: 400, max: 900 } })
    };
  }

  // =====================================================================
  // Textes flottants (réserve réutilisée : aucune création en plein combat)
  // =====================================================================
  _buildFloatPool() {
    this.floats = [];
    for (var i = 0; i < 12; i++) {
      var t = this.add.text(0, 0, '', {
        fontFamily: 'Arial, sans-serif', fontSize: '22px', fontStyle: 'bold', color: '#ffffff',
        stroke: '#05070f', strokeThickness: 5
      }).setOrigin(0.5).setDepth(700).setVisible(false);
      t._inUse = false;
      this.floats.push(t);
    }
    this.banner = this.add.text(this.scale.width / 2, 270, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '28px', fontStyle: '900', color: '#ffffff',
      stroke: '#05070f', strokeThickness: 7, align: 'center'
    }).setOrigin(0.5).setDepth(950).setAlpha(0);
  }

  /** Affiche un texte flottant ; renvoie false si la réserve est pleine (le chiffre est alors ignoré). */
  _float(x, y, text, color, size, opts) {
    opts = opts || {};
    var t = null, i;
    for (i = 0; i < this.floats.length; i++) { if (!this.floats[i]._inUse) { t = this.floats[i]; break; } }
    if (!t) {
      if (!opts.priority) return false;
      t = this.floats[0]; this.tweens.killTweensOf(t);
    }
    var self = this;
    t._inUse = true;
    t.setText(text).setColor(color).setFontSize(size).setPosition(x, y).setAlpha(opts.alpha || 1).setScale(opts.pop ? 0.6 : 1).setVisible(true);
    if (opts.pop) this.tweens.add({ targets: t, scale: 1.15, duration: 120, yoyo: true, ease: 'Back.easeOut' });
    this.tweens.add({ targets: t, y: y - (opts.rise || 46), duration: opts.dur || 750, ease: 'Cubic.easeOut' });
    this.tweens.add({
      targets: t, alpha: 0, delay: (opts.dur || 750) * 0.55, duration: (opts.dur || 750) * 0.45,
      onComplete: function () { t._inUse = false; t.setVisible(false); }
    });
    return true;
  }

  _banner(text, color, size, holdMs) {
    var b = this.banner;
    this.tweens.killTweensOf(b);
    b.setText(text).setColor(color).setFontSize(size).setAlpha(0).setScale(0.7);
    this.tweens.add({ targets: b, alpha: 1, scale: 1, duration: 180, ease: 'Back.easeOut' });
    this.tweens.add({ targets: b, alpha: 0, delay: 180 + (holdMs || 900), duration: 350 });
  }

  // =====================================================================
  // Placement des unités
  // =====================================================================
  _layoutHeroes() {
    var w = this.scale.width;
    var order = { tank: 0, assassin: 1, damage: 2, dps: 3, control: 4, sniper: 5, support: 6, healer: 7 };
    var idx = this.battle.playerUnits.map(function (u, i) { return i; });
    idx.sort(function (a, b) {
      var ua = this.battle.playerUnits[a], ub = this.battle.playerUnits[b];
      return (order[ua.role] === undefined ? 4 : order[ua.role]) - (order[ub.role] === undefined ? 4 : order[ub.role]);
    }.bind(this));
    // les 2 rôles les plus « de mêlée » occupent la ligne avant
    var slots = [
      { x: 235, y: 905, size: 150 }, { x: 485, y: 905, size: 150 },
      { x: 110, y: 742, size: 134 }, { x: 360, y: 722, size: 134 }, { x: 610, y: 742, size: 134 }
    ];
    var n = idx.length;
    if (n < 5) { // équipe incomplète (ne devrait pas arriver) : répartition simple
      slots = []; for (var s = 0; s < n; s++) slots.push({ x: w * (s + 1) / (n + 1), y: 820, size: 140 });
    }
    this.heroViews = new Array(n);
    var self = this;
    idx.forEach(function (unitIdx, k) {
      var u = self.battle.playerUnits[unitIdx], sl = slots[k];
      var v = new NEBUSTION.CombatUnitView(self, u, sl.x, sl.y, sl.size, true, false);
      self.views[u.uid] = v; self.heroViews[unitIdx] = v;
    });
  }

  /** Vagues successives (invasions) : reconstruit UNIQUEMENT le camp ennemi, les héros restent en place. */
  _layoutEnemies() {
    var self = this;
    var enemies = this.battle.enemyUnits, m = enemies.length;
    var epos;
    if (m === 1) epos = [[360, 400]];
    else if (m === 2) epos = [[225, 410], [495, 410]];
    else epos = [[130, 445], [360, 385], [590, 445]];
    this.enemyViews = [];
    this.bossView = null;
    enemies.forEach(function (u, i) {
      var boss = u.isBoss;
      var size = boss ? 300 : (m >= 3 ? 138 : 158);
      var p = epos[i] || [360, 400];
      var v = new NEBUSTION.CombatUnitView(self, u, p[0], boss ? 390 : p[1], size, false, boss);
      self.views[u.uid] = v; self.enemyViews.push(v);
      if (boss) self.bossView = v;
    });
  }

  /** Invasion : la vague en cours est vaincue, il en reste d'autres — enchaîne sans écran de résultat. */
  _advanceWave() {
    var self = this, idx = this.battle.waveIndex + 1;
    this.battle.waveIndex = idx;
    this._banner('VAGUE ' + (idx + 1) + ' / ' + this.battle.waveCount, '#ffd166', 26, 1100);
    this.time.delayedCall(900, function () {
      if (self._leaving || self.ended) return;
      var CE = NEBUSTION.CombatEngine;
      var carriedTime = self.engine.time;
      // La Frappe du Commandant et les objets restants sont conservés d'une vague à l'autre (même équipe, même combat).
      var carriedStrike = self.engine.strikeCharge;
      var carriedItems = {};
      Object.keys(self.engine.items).forEach(function (id) { carriedItems[id] = self.engine.items[id].charges; });
      var newEnemies = self.battle.buildWave(idx);
      self.battle.enemyUnits = newEnemies;
      self.enemyViews.forEach(function (v) {
        if (!v || !v.container) return;
        [v.float, v.body, v.shadow, v.container].forEach(function (o) { if (o) self.tweens.killTweensOf(o); });
        v.container.destroy();
      });
      var engine = new CE.CombatEngine(self.battle.playerUnits, newEnemies, { mode: self.mode, skipPassiveInit: true, startTime: carriedTime, items: carriedItems });
      engine.strikeCharge = carriedStrike;
      self.engine = engine; self.battle.engine = engine;
      self._redrawItemBar();
      self._layoutEnemies();
      if (self.diffOrWaveText) self.diffOrWaveText.setText('Vague ' + (idx + 1) + ' / ' + self.battle.waveCount);
    });
  }

  // =====================================================================
  // Mécaniques d'attaque : HUD tactique placé directement dans l'arène
  // =====================================================================
  _buildArenaMechanics() {
    var self = this, w = this.scale.width;
    var g = this.add.graphics().setDepth(740);
    // Bande centrale : elle occupe l'espace libre entre les ennemis et les héros.
    g.fillStyle(0x05070f, 0.78);
    g.fillRoundedRect(w / 2 - 265, 535, 530, 92, 18);
    g.lineStyle(2, 0x243654, 0.95);
    g.strokeRoundedRect(w / 2 - 265, 535, 530, 92, 18);
    g.lineStyle(1, 0x00e5ff, 0.22);
    g.strokeRoundedRect(w / 2 - 255, 545, 510, 72, 14);

    this.arenaMechanics = {
      bg: g,
      combo: this.add.text(w / 2 - 170, 557, 'COMBO ×0', {
        fontFamily: 'Arial, sans-serif', fontSize: '18px', fontStyle: 'bold', color: '#8fd8ff',
        stroke: '#05070f', strokeThickness: 4
      }).setOrigin(0.5).setDepth(812),
      comboSub: this.add.text(w / 2 - 170, 585, 'Bonus dégâts : +0%', {
        fontFamily: 'Arial, sans-serif', fontSize: '12px', color: '#7a89ad'
      }).setOrigin(0.5).setDepth(812),
      focus: this.add.text(w / 2 + 10, 557, 'CIBLE : AUTO', {
        fontFamily: 'Arial, sans-serif', fontSize: '15px', fontStyle: 'bold', color: '#7fe8ff',
        stroke: '#05070f', strokeThickness: 4
      }).setOrigin(0.5).setDepth(812),
      break: this.add.text(w / 2 + 10, 585, 'RUPTURE : —', {
        fontFamily: 'Arial, sans-serif', fontSize: '12px', color: '#9d6cff'
      }).setOrigin(0.5).setDepth(812),
      hint: this.add.text(w / 2 + 188, 571, 'ATTAQUES\nTACTIQUES', {
        fontFamily: 'Arial, sans-serif', fontSize: '10px', fontStyle: 'bold', color: '#ffd166',
        align: 'center', stroke: '#05070f', strokeThickness: 3
      }).setOrigin(0.5).setDepth(812)
    };
    this.comboText = this.arenaMechanics.combo;
    this.focusText = this.arenaMechanics.focus;

    // Petit repère visuel au centre de l'arène : les attaques et compétences
    // convergent vers cette ligne sans recouvrir les personnages.
    this.attackLane = this.add.graphics().setDepth(510);
    this.attackLane.lineStyle(2, 0x00e5ff, 0.14);
    this.attackLane.lineBetween(w / 2 - 210, 655, w / 2 + 210, 655);
    this.attackLane.lineStyle(1, 0xffd166, 0.10);
    this.attackLane.lineBetween(w / 2 - 130, 665, w / 2 + 130, 665);
  }

  // =====================================================================
  // Barre supérieure : pause, titre, minuterie, mode, vitesse
  // =====================================================================
  _buildTopBar() {
    var self = this, w = this.scale.width;
    var EN = NEBUSTION.Enemies;
    var bar = this.add.graphics().setDepth(800);
    bar.fillGradientStyle(0x05070f, 0x05070f, 0x05070f, 0x05070f, 0.92, 0.92, 0.0, 0.0);
    bar.fillRect(0, 0, w, 180);

    this.pauseBtn = new NEBUSTION.Button(this, 52, 50, {
      width: 68, height: 56, label: '❚❚', fontSize: '20px', accentColor: 0x7a89ad,
      onClick: function () { self._setPaused(true); }
    });
    this.pauseBtn.setDepth(810);

    this.add.text(w / 2, 34, this.stageDef.name, {
      fontFamily: 'Arial, sans-serif', fontSize: '17px', fontStyle: 'bold', color: '#eaf2ff',
      wordWrap: { width: 400 }, align: 'center'
    }).setOrigin(0.5).setDepth(810);
    this.diffOrWaveText = this.add.text(w / 2, 64,
      this.isInvasion ? ('Vague 1 / ' + this.battle.waveCount) : ('Difficulté : ' + EN.DIFFICULTIES[this.difficulty].name), {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#9aa5c0'
    }).setOrigin(0.5).setDepth(810);

    this.timerText = this.add.text(w - 24, 50, '0:00', {
      fontFamily: 'Arial, sans-serif', fontSize: '22px', fontStyle: 'bold', color: '#eaf2ff'
    }).setOrigin(1, 0.5).setDepth(810);
    this.rageText = this.add.text(w - 24, 76, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', fontStyle: 'bold', color: '#ff4d5e'
    }).setOrigin(1, 0.5).setDepth(810);

    this.modeBtn = new NEBUSTION.Button(this, 200, 122, {
      width: 290, height: 52, label: '', fontSize: '17px', accentColor: 0x00e5ff,
      onClick: function () { self._toggleMode(); }
    });
    this.modeBtn.setDepth(810);
    this.modeLabel = this.add.text(200, 122, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '16px', fontStyle: 'bold', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(812);

    this.speedBtn = new NEBUSTION.Button(this, 470, 122, {
      width: 130, height: 52, label: '', fontSize: '17px', accentColor: 0xffd166,
      onClick: function () { self._cycleSpeed(); }
    });
    this.speedBtn.setDepth(810);
    this.speedLabel = this.add.text(470, 122, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '18px', fontStyle: 'bold', color: '#ffd166'
    }).setOrigin(0.5).setDepth(812);

    this.aliveText = this.add.text(w - 24, 122, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '14px', color: '#a9b8dc', align: 'right'
    }).setOrigin(1, 0.5).setDepth(810);

    // COMBO/CIBLE sont affichés dans la zone de combat, pas dans la barre supérieure.
    this.comboText = null;
    this.focusText = null;

    this._buildStrikeGauge();
    this._buildItemBar();
    this._refreshModeLabels();
  }

  // =====================================================================
  // Frappe du Commandant : jauge + bouton (attaque spéciale du joueur, hors héros)
  // =====================================================================
  _buildStrikeGauge() {
    var self = this, w = this.scale.width, y = 162;
    var c = this.add.container(w / 2, y).setDepth(810);
    var bg = this.add.graphics();
    var label = this.add.text(0, 0, '', { fontFamily: 'Arial, sans-serif', fontSize: '12px', fontStyle: 'bold', color: '#8ea0c8' }).setOrigin(0.5);
    c.add([bg, label]);
    c.setSize(480, 20).setInteractive({ useHandCursor: true });
    c.on('pointerdown', function () { self._tapCommanderStrike(); });
    this._strikeUi = { c: c, bg: bg, label: label };
    this._redrawStrikeGauge();
  }

  _redrawStrikeGauge() {
    if (!this._strikeUi || this.ended) return;
    var e = this.engine, ready = e.strikeReady(), pct = Math.max(0, Math.min(1, e.strikeProgress()));
    var g = this._strikeUi, w = 470, h = 14;
    g.bg.clear();
    g.bg.fillStyle(0x0d1a33, 0.85); g.bg.fillRoundedRect(-w / 2, -h / 2, w, h, 7);
    g.bg.fillStyle(ready ? 0xffd166 : 0x9d6cff, ready ? 1 : 0.85); g.bg.fillRoundedRect(-w / 2, -h / 2, w * pct, h, 7);
    g.bg.lineStyle(1.5, ready ? 0xffd166 : 0x4a3f80, 1); g.bg.strokeRoundedRect(-w / 2, -h / 2, w, h, 7);
    g.label.setColor(ready ? '#05070f' : '#eaf2ff');
    g.label.setText(ready ? '⚡ FRAPPE DU COMMANDANT PRÊTE — TOUCHER' : '⚡ Commandant ' + Math.round(pct * 100) + ' %');
  }

  _tapCommanderStrike() {
    if (this.paused || this.ended || !this.engine || this.engine.isOver()) return;
    if (!this.engine.strikeReady()) return;
    this.engine.requestCommanderStrike();
    this._ring(this.scale.width / 2, 480, 0xffd166, 2.2, 895);
    this.cameras.main.shake(220, 0.006);
    this.cameras.main.flash(160, 255, 209, 102);
    this._banner('⚡ FRAPPE DU COMMANDANT', '#ffd166', 26, 900);
    var self = this;
    this.enemyViews.forEach(function (v) {
      if (!v || !v.unit.alive) return;
      self._ring(v.cx, v.cy, 0xffd166, 1.3);
      if (self.pfx && self.pfx.boom) self.pfx.boom.explode(10, v.cx, v.cy);
    });
  }

  // =====================================================================
  // Objets/consommables de combat (charges limitées, effet immédiat sur toute l'équipe/tous les ennemis)
  // =====================================================================
  _buildItemBar() {
    var self = this, w = this.scale.width;
    var defs = (NEBUSTION.CombatItems ? NEBUSTION.CombatItems.list() : []).filter(function (d) { return d.effect; });
    if (!defs.length) return;
    var y = 210, cw = 46, gap = 8, totalW = defs.length * cw + (defs.length - 1) * gap, x0 = w / 2 - totalW / 2 + cw / 2;
    this._itemCards = [];
    defs.forEach(function (def, i) {
      var x = x0 + i * (cw + gap);
      var c = self.add.container(x, y).setDepth(810);
      var bg = self.add.circle(0, 0, 21, 0x0d1a33, 0.85).setStrokeStyle(1.5, 0x3a5fa0, 0.9);
      var icon = self.add.text(0, -3, def.icon, { fontFamily: 'Arial, sans-serif', fontSize: '19px' }).setOrigin(0.5);
      var ct = self.add.text(0, 16, '×' + self.engine.items[def.id].charges, { fontFamily: 'Arial, sans-serif', fontSize: '10px', fontStyle: 'bold', color: '#ffd166' }).setOrigin(0.5);
      c.add([bg, icon, ct]);
      c.setSize(42, 42).setInteractive({ useHandCursor: true });
      c.on('pointerdown', function () { self._tapItem(def.id); });
      self._itemCards.push({ id: def.id, bg: bg, ct: ct, container: c });
    });
    this._redrawItemBar();
  }

  _redrawItemBar() {
    if (!this._itemCards) return;
    var self = this;
    this._itemCards.forEach(function (k) {
      var charges = self.engine.items[k.id].charges;
      k.ct.setText('×' + charges);
      k.container.setAlpha(charges > 0 ? 1 : 0.35);
    });
  }

  _tapItem(itemId) {
    if (this.paused || this.ended || !this.engine || this.engine.isOver()) return;
    var it = this.engine.items[itemId];
    if (!it || it.charges <= 0) return;
    var def = NEBUSTION.CombatItems.get(itemId);
    var ok = this.engine.useItem(itemId);
    if (!ok) return;
    this._redrawItemBar();
    this._banner(def.icon + ' ' + def.name, '#7dff9a', 20, 700);
    var self = this;
    this.heroViews.forEach(function (v) { if (v && v.unit.alive) self._ring(v.cx, v.cy, 0x7dff9a, 0.9); });
    if (def.effect === 'stunAoe') this.enemyViews.forEach(function (v) { if (v && v.unit.alive) self._ring(v.cx, v.cy, 0xffffff, 0.9); });
  }

  _refreshModeLabels() {
    this.modeLabel.setText(this.mode === 'auto' ? '⚙ MODE AUTO' : '✋ MODE MANUEL');
    this.modeLabel.setColor(this.mode === 'auto' ? '#00e5ff' : '#ffb84d');
    this.speedLabel.setText('×' + this.speed);
    if (this.hintText) this.hintText.setText(this.mode === 'manual'
      ? 'Touchez une compétence ou un ultime chargé pour le lancer'
      : 'AUTO : les compétences partent seules — touchez pour les déclencher à la main');
  }

  _toggleMode() {
    this.mode = this.mode === 'auto' ? 'manual' : 'auto';
    this.engine.setMode(this.mode);
    this._refreshModeLabels();
  }

  _cycleSpeed() {
    this.speed = this.speed >= 3 ? 1 : this.speed + 1;
    this.tweens.timeScale = this.speed;
    this.time.timeScale = this.speed;
    this._refreshModeLabels();
  }

  // =====================================================================
  // Barre de boss (grande barre en haut de l'arène)
  // =====================================================================
  _buildBossBar() {
    var w = this.scale.width, u = this.bossView.unit;
    this.bossBarGfx = this.add.graphics().setDepth(805);
    this.bossName = this.add.text(30, 176, u.name, {
      fontFamily: 'Arial, sans-serif', fontSize: '15px', fontStyle: 'bold', color: '#ffb0b8',
      stroke: '#05070f', strokeThickness: 4
    }).setDepth(806);
    this.bossPhaseText = this.add.text(w - 30, 176, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', fontStyle: 'bold', color: '#ffd166',
      stroke: '#05070f', strokeThickness: 4
    }).setOrigin(1, 0).setDepth(806);
    this._updatePhaseText();
  }

  _updatePhaseText() {
    if (!this.bossView) return;
    var u = this.bossView.unit;
    this.bossPhaseText.setText('PHASE ' + (u.phase + 1) + ' / ' + ((u.phaseThresholds || []).length + 1));
  }

  _drawBossBar(dt) {
    if (!this.bossView) return;
    var u = this.bossView.unit, max = Math.max(1, u.maxHp);
    var v = this.bossView;
    var f = v.shownHp / max, gh = v.ghostHp / max;
    var bg = Math.max(0, Math.min(1, (u.breakGauge == null ? 100 : u.breakGauge) / 100));
    var key = Math.round(f * 200) + '|' + Math.round(gh * 200) + '|' + u.phase + '|' + Math.round(bg * 100) + '|' + (u.breakUntil > this.engine.time ? 1 : 0);
    if (key === this._bossKey) return;
    this._bossKey = key;
    var g = this.bossBarGfx, x = 30, y = 198, bw = this.scale.width - 60, bh = 18;
    g.clear();
    g.fillStyle(0x05070f, 0.9); g.fillRoundedRect(x - 3, y - 3, bw + 6, bh + 6, 8);
    g.fillStyle(0xffffff, 0.55); g.fillRoundedRect(x, y, bw * gh, bh, 6);
    g.fillStyle(0xff4d5e, 1); g.fillRoundedRect(x, y, Math.max(0, bw * f), bh, 6);
    // repères de phase
    g.lineStyle(2, 0xffd166, 0.9);
    (u.phaseThresholds || []).forEach(function (t) { g.lineBetween(x + bw * t, y - 3, x + bw * t, y + bh + 3); });
    // Jauge de rupture : les compétences peuvent briser un boss et créer une fenêtre de vulnérabilité.
    g.fillStyle(0x05070f, 0.9); g.fillRoundedRect(x, y + 25, bw, 8, 3);
    g.fillStyle(u.breakUntil > this.engine.time ? 0xffd166 : 0x9d6cff, 1); g.fillRoundedRect(x, y + 25, bw * bg, 8, 3);
    if (u.breakUntil > this.engine.time) { g.lineStyle(2, 0xffd166, 0.9); g.strokeRoundedRect(x - 1, y + 24, bw + 2, 10, 4); }
  }

  // =====================================================================
  // Cartes de héros : compétence + ultime
  // =====================================================================
  _buildCards() {
    var self = this, w = this.scale.width;
    var H = NEBUSTION.Heroes;
    var n = this.battle.playerUnits.length;
    var cardW = 132, gap = 10, total = n * cardW + (n - 1) * gap, x0 = (w - total) / 2;
    this.cards = [];
    var skillY = 1092, ultY = 1174;

    this.hintText = this.add.text(w / 2, 1226, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#7a89ad', align: 'center'
    }).setOrigin(0.5).setDepth(810);

    this.battle.playerUnits.forEach(function (unit, i) {
      var cx = x0 + cardW / 2 + i * (cardW + gap);
      var hero = H.get(unit.heroId), rarity = H.RARITIES[hero.rarity];

      // portrait rogné (visage) comme fond du bouton de compétence
      var img = self.add.image(cx, skillY, unit.portraitKey).setDepth(806);
      var fw = img.width || 300, fh = img.height || 380;
      var cw = fw * 0.93, ch = cw * (78 / cardW);
      var s = cardW / cw;
      img.setScale(s);
      img.setCrop(fw * 0.035, fh * 0.05, cw, ch);
      img.y = skillY + (fh / 2 - (fh * 0.05 + ch / 2)) * s;

      var gfx = self.add.graphics().setDepth(808);
      var nameT = self.add.text(cx - cardW / 2 + 8, skillY - 34, unit.name, {
        fontFamily: 'Arial, sans-serif', fontSize: '13px', fontStyle: 'bold', color: '#ffffff',
        stroke: '#05070f', strokeThickness: 4
      }).setDepth(809);
      var skillT = self.add.text(cx, skillY + 20, '', {
        fontFamily: 'Arial, sans-serif', fontSize: '12px', fontStyle: 'bold', color: '#ffffff',
        stroke: '#05070f', strokeThickness: 4, align: 'center', wordWrap: { width: cardW - 10 }
      }).setOrigin(0.5).setDepth(809);
      var ultT = self.add.text(cx, ultY, '', {
        fontFamily: 'Arial, sans-serif', fontSize: '12px', fontStyle: 'bold', color: '#ffffff',
        stroke: '#05070f', strokeThickness: 4, align: 'center', wordWrap: { width: cardW - 10 }
      }).setOrigin(0.5).setDepth(809);

      var zSkill = self.add.zone(cx, skillY, cardW, 78).setInteractive({ useHandCursor: true }).setDepth(830);
      zSkill.on('pointerdown', function () { self._tapSkill(i); });
      var zUlt = self.add.zone(cx, ultY, cardW, 52).setInteractive({ useHandCursor: true }).setDepth(830);
      zUlt.on('pointerdown', function () { self._tapUlt(i); });

      self.cards.push({
        unit: unit, cx: cx, skillY: skillY, ultY: ultY, w: cardW, gfx: gfx, img: img, rarity: rarity,
        nameT: nameT, skillT: skillT, ultT: ultT, key: '', skillTxt: '', ultTxt: ''
      });
    });
    this._refreshModeLabels();
  }

  _focusEnemy(unit) {
    if (this.paused || this.ended || !this.engine || this.engine.isOver() || !unit || !unit.alive) return;
    this.engine.setFocusTarget(unit.uid);
    var v = this.views[unit.uid];
    if (v) this._ring(v.cx, v.cy, 0x00e5ff, 1.0, 825);
    this._float(v ? v.cx : this.scale.width / 2, v ? v.cy - 70 : 330, 'CIBLE VERROUILLÉE', '#7fe8ff', 15, { priority: true, pop: true });
  }

  _tapSkill(i) {
    var c = this.cards[i], u = c.unit;
    if (this.paused || this.ended || this.engine.isOver()) return;
    if (this.engine.skillReady(u)) {
      this.engine.requestSkill(u.uid);
      this._ring(c.cx, c.skillY, 0xffffff, 0.8, 815);
    } else {
      var v = this.views[u.uid];
      if (v && u.alive) v.knock(1, 0, 5);
    }
  }

  _tapUlt(i) {
    var c = this.cards[i], u = c.unit;
    if (this.paused || this.ended || this.engine.isOver()) return;
    if (this.engine.ultReady(u)) {
      this.engine.requestUltimate(u.uid);
      this._ring(c.cx, c.ultY, 0xffd166, 0.9, 815);
    }
  }

  _drawCard(c, time) {
    var u = c.unit, e = this.engine;
    var cdFrac = u.skillCooldown > 0 ? Math.min(1, u.skillCooldown / Math.max(0.1, u.skillCooldownMax)) : 0;
    var ready = e.skillReady(u), ultReady = e.ultReady(u);
    var hpQ = Math.round(u.hp / Math.max(1, u.maxHp) * 60);
    var key = [u.alive ? 1 : 0, Math.round(cdFrac * 40), ready ? 1 : 0, Math.round(u.energy / 2.5), ultReady ? 1 : 0,
      hpQ, u.stunTime > 0 ? 1 : 0, this.mode, ultReady && (Math.floor(time / 350) % 2)].join('|');
    if (key === c.key) return;
    c.key = key;

    var g = c.gfx, x = c.cx - c.w / 2, y = c.skillY - 39, ux = x, uy = c.ultY - 26;
    g.clear();
    // --- bouton de compétence ---
    g.fillStyle(0x05070f, u.alive ? 0.34 : 0.85); g.fillRoundedRect(x, y, c.w, 78, 10);
    if (u.alive && cdFrac > 0) { g.fillStyle(0x05070f, 0.62); g.fillRoundedRect(x, y, c.w, 78 * cdFrac, 10); }
    g.lineStyle(ready ? 3 : 2, ready ? 0xffd166 : (u.alive ? c.rarity.color : 0x394869), ready ? 1 : 0.7);
    g.strokeRoundedRect(x, y, c.w, 78, 10);
    // PV (sous le bouton)
    g.fillStyle(0x05070f, 0.9); g.fillRect(x + 6, y + 70, c.w - 12, 5);
    g.fillStyle(hpQ > 30 ? 0x5fd97a : (hpQ > 15 ? 0xffb84d : 0xff4d5e), 1);
    g.fillRect(x + 6, y + 70, (c.w - 12) * (u.hp / Math.max(1, u.maxHp)), 5);
    // --- bouton d'ultime ---
    var frac = Math.min(1, u.energy / 100);
    g.fillStyle(0x0a0f1e, 0.95); g.fillRoundedRect(ux, uy, c.w, 52, 10);
    if (u.alive) { g.fillStyle(ultReady ? 0xffd166 : 0x6c3ce9, ultReady ? 0.85 : 0.75); g.fillRoundedRect(ux + 3, uy + 3, Math.max(6, (c.w - 6) * frac), 46, 8); }
    g.lineStyle(ultReady ? 3 : 2, ultReady ? 0xffffff : 0x4a3a9a, ultReady ? 1 : 0.8);
    g.strokeRoundedRect(ux, uy, c.w, 52, 10);

    var st = !u.alive ? '✕ K.O.' : (u.stunTime > 0 ? '💫 étourdi' : (ready ? 'PRÊT' : u.skillCooldown.toFixed(1) + ' s'));
    var skillTxt = u.alive ? u.activeName + '\n' + st : st;
    if (skillTxt !== c.skillTxt) { c.skillTxt = skillTxt; c.skillT.setText(skillTxt); }
    c.skillT.setColor(ready ? '#ffd166' : '#e8efff');
    var ultTxt = !u.alive ? '' : (ultReady ? '★ ' + u.ultimateName + ' ★' : 'ULTIME ' + Math.floor(u.energy) + '%');
    if (ultTxt !== c.ultTxt) { c.ultTxt = ultTxt; c.ultT.setText(ultTxt); }
    c.ultT.setColor(ultReady ? '#1a1206' : '#ffffff');
    c.img.setAlpha(u.alive ? 1 : 0.25);
  }

  // =====================================================================
  // Pause / superpositions
  // =====================================================================
  _buildOverlays() {
    this.pauseLayer = null; // construit à la demande (et détruit à la reprise : un conteneur simplement masqué garderait ses zones tactiles actives)
  }

  _buildPauseLayer() {
    var self = this, w = this.scale.width, h = this.scale.height;
    var layer = this.add.container(0, 0).setDepth(1400);
    var bg = this.add.rectangle(w / 2, h / 2, w, h, 0x02040a, 0.82).setInteractive();
    layer.add(bg);
    layer.add(this.add.text(w / 2, h / 2 - 180, 'PAUSE', {
      fontFamily: 'Arial, sans-serif', fontSize: '44px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5).setShadow(0, 0, '#00e5ff', 14, true, true));
    var resume = new NEBUSTION.Button(this, w / 2, h / 2 - 40, {
      width: 380, height: 76, label: 'REPRENDRE', accentColor: 0x00e5ff, fontSize: '24px',
      onClick: function () { self._setPaused(false); }
    });
    var quit = new NEBUSTION.Button(this, w / 2, h / 2 + 70, {
      width: 380, height: 76, label: 'ABANDONNER', accentColor: 0xff4d5e, fontSize: '24px',
      onClick: function () { self._abandon(); }
    });
    layer.add([resume, quit]);
    layer.add(this.add.text(w / 2, h / 2 + 150, 'Abandonner ne rapporte aucune récompense.', {
      fontFamily: 'Arial, sans-serif', fontSize: '14px', color: '#7a89ad'
    }).setOrigin(0.5));
    this.pauseLayer = layer;
  }

  _setPaused(p) {
    if (this.ended && p) return;
    this.paused = p;
    if (p && !this.pauseLayer) this._buildPauseLayer();
    if (!p && this.pauseLayer) { this.pauseLayer.destroy(); this.pauseLayer = null; }
  }

  _abandon() {
    if (this._leaving) return;
    this._leaving = true;
    if (this.isInvasion) this._goGalaxy(this.planetId); else this._goPrep(this.stageId);
  }

  /** Retour à la carte galactique (invasion) : la fiche de la planète attaquée est sélectionnée. */
  _goGalaxy(planetId) {
    var self = this;
    this._leaving = true;
    this.cameras.main.fadeOut(300, 5, 7, 15);
    this.cameras.main.once('camerafadeoutcomplete', function () { self.scene.start('GalaxyScene', { navKey: 'galaxy', title: 'Galaxie', planetId: planetId }); });
  }

  _goPrep(stageId) {
    var self = this;
    this.cameras.main.fadeOut(300, 5, 7, 15);
    this.cameras.main.once('camerafadeoutcomplete', function () { self.scene.start('CombatPrepScene', { stageId: stageId }); });
  }

  // =====================================================================
  // Boucle : moteur à pas fixe + événements -> animations
  // =====================================================================
  update(time, delta) {
    if (!this._ready) return;
    var dt = Math.min(delta || 16, 100) / 1000;
    var i, STEP = 0.05;

    // décor
    var w = this.scale.width;
    for (i = 0; i < this.rocks.length; i++) {
      var r = this.rocks[i];
      r.img.x -= r.vx * dt; r.img.angle += r.spin * dt;
      if (r.img.x < -120) { r.img.x = w + 120; r.img.y = 200 + Math.random() * 760; }
    }

    var events = [];
    if (!this.paused && !this.engine.isOver()) {
      this._acc += dt * this.speed;
      var steps = 0;
      while (this._acc >= STEP && steps < 8 && !this.engine.isOver()) {
        this.engine.update(STEP); this._acc -= STEP; steps++;
      }
      if (steps >= 8) this._acc = 0;
      events = this.engine.consumeEvents();
    } else if (this.engine.isOver()) {
      events = this.engine.consumeEvents();
    }
    if (events.length) this._handleEvents(events);

    // barres, statuts, cartes, minuterie
    for (i = 0; i < this.battle.playerUnits.length; i++) this._tickView(this.heroViews[i], dt);
    for (i = 0; i < this.enemyViews.length; i++) this._tickView(this.enemyViews[i], dt);
    if (this.bossView) this._drawBossBar(dt);
    for (i = 0; i < this.cards.length; i++) this._drawCard(this.cards[i], time);

    var t = Math.floor(this.engine.time);
    var ts = Math.floor(t / 60) + ':' + ('0' + (t % 60)).slice(-2);
    if (ts !== this._ts) { this._ts = ts; this.timerText.setText(ts); }
    var rage = this.engine.isEnraged() ? 'RAGE ×' + this.engine.enrageMult().toFixed(1) : '';
    if (rage !== this._rage) { this._rage = rage; this.rageText.setText(rage); }
    var combo = this.engine.combo || 0;
    var comboKey = combo + '|' + Math.round((this.engine.comboMultiplier ? this.engine.comboMultiplier() : 1) * 100);
    if (comboKey !== this._comboKey) {
      this._comboKey = comboKey;
      var bonus = combo ? Math.round((this.engine.comboMultiplier() - 1) * 100) : 0;
      if (this.comboText) {
        this.comboText.setText('COMBO ×' + combo).setColor(combo >= 5 ? '#ffd166' : '#8fd8ff');
        if (this.arenaMechanics && this.arenaMechanics.comboSub) this.arenaMechanics.comboSub.setText('Bonus dégâts : +' + bonus + '%');
      }
    }
    var focusUid = this.engine.focusTargetUid;
    var focusUnit = focusUid ? this.engine.all.find(function (u) { return u.uid === focusUid && u.alive; }) : null;
    var focusLabel = focusUnit ? 'CIBLE : ' + focusUnit.name : 'CIBLE : AUTO';
    if (focusLabel !== this._focusKey) {
      this._focusKey = focusLabel;
      if (this.focusText) this.focusText.setText(focusLabel);
    }
    if (this.arenaMechanics && this.arenaMechanics.break) {
      var focusedTarget = focusUnit;
      var breakPct = focusedTarget ? Math.max(0, Math.round(focusedTarget.breakGauge == null ? 100 : focusedTarget.breakGauge)) : 0;
      this.arenaMechanics.break.setText(focusedTarget ? ('RUPTURE : ' + breakPct + '%') : 'RUPTURE : —');
      this.arenaMechanics.break.setColor(focusedTarget && focusedTarget.breakUntil > this.engine.time ? '#ffd166' : '#9d6cff');
    }
    var alive = 'Héros ' + this.engine.aliveOf('player').length + '/' + this.battle.playerUnits.length +
      '  ·  Ennemis ' + this.engine.aliveOf('enemy').length;
    if (alive !== this._alive) { this._alive = alive; this.aliveText.setText(alive); }
    this._redrawStrikeGauge();
  }

  _tickView(v, dt) {
    if (!v) return;
    v.updateBars(dt);
    v.updateStatus(this.engine);
  }

  /** Traduit les événements du moteur en animations. `ctx.delay` = retard (ms) de l'effet en cours. */
  _handleEvents(events) {
    var self = this, ctx = { delay: 0 };
    events.forEach(function (e) {
      var a = self.views[e.uid], t = self.views[e.targetUid];
      switch (e.type) {
        case 'attack': ctx.delay = self._playAttack(a, t); break;
        case 'skill': ctx.delay = self._castFx(a, e.name, false); break;
        case 'ultimate': ctx.delay = self._castFx(a, e.name, true); break;
        case 'damage': self._onDamage(e, a, t, ctx); break;
        case 'miss': self._later(ctx.delay, function () { if (t) self._float(t.cx, t.cy - 30, 'RATÉ', '#9aa5c0', 18); }); break;
        case 'heal': self._later(ctx.delay, function () { self._onHeal(e, t); }); break;
        case 'shield': self._later(ctx.delay, function () { if (t) self._ring(t.cx, t.cy, 0x7fe8ff, 0.9); }); break;
        case 'buff': self._later(ctx.delay, function () { if (t) { self._ring(t.cx, t.cy, 0xffd166, 0.8); self._float(t.cx, t.cy - 60, '▲', '#ffd166', 20); } }); break;
        case 'debuff': self._later(ctx.delay, function () { if (t) { self.pfx.ice.explode(5, t.cx, t.cy); } }); break;
        case 'stun': self._later(ctx.delay, function () { if (t) { self._float(t.cx, t.cy - 70, '💫', '#ffffff', 26, { priority: true }); self.pfx.ice.explode(8, t.cx, t.cy - 20); } }); break;
        case 'taunt': if (a) self._ring(a.cx, a.cy, 0xff8a3d, 1.0); break;
        case 'cleanse': self._later(ctx.delay, function () { if (t) { self.pfx.heal.explode(6, t.cx, t.cy); } }); break;
        case 'extra': self._later(ctx.delay, function () { if (t) { self._float(t.cx, t.cy - 70, '⚡ Action !', '#ffd166', 16, { priority: true }); self._ring(t.cx, t.cy, 0xffd166, 0.9); } }); break;
        case 'combo': self._later(0, function () { var mult = Math.round(((e.multiplier || 1) - 1) * 100); self._float(self.scale.width / 2 - 170, 615, '×' + e.combo + '  +' + mult + '%', '#7fe8ff', 15, { priority: e.combo >= 5, pop: true, rise: 26, dur: 500 }); }); break;
        case 'comboReset': self._later(0, function () { self._banner('COMBO ROMPU', '#7a89ad', 16, 500); }); break;
        case 'focus': if (self.focusText) self.focusText.setText(e.targetUid ? 'CIBLE : VERROUILLÉE' : 'CIBLE : AUTO'); break;
        case 'break': self._later(ctx.delay, function () { if (t && e.broken) { self._float(t.cx, t.cy - 90, '⚡ BRISÉ !', '#ffd166', 24, { priority: true, pop: true, rise: 70 }); self.pfx.boom.explode(12, t.cx, t.cy); self.cameras.main.shake(180, 0.003); } }); break;
        case 'reaction': self._later(ctx.delay, function () { if (t) { var labels = { combustion: '🔥 COMBUSTION', corrosion: '☠ CORROSION', thermal: '❄ CHOC THERMIQUE' }; self._float(t.cx, t.cy - 95, labels[e.kind] || 'RÉACTION', '#dca8ff', 20, { priority: true, pop: true, rise: 64 }); self._ring(t.cx, t.cy, 0xdca8ff, 1.1); } }); break;
        case 'revive': self._later(ctx.delay, function () { self._onRevive(e, t); }); break;
        case 'death': self._later(ctx.delay + 80, function () { self._onDeath(a); }); break; // l'événement porte `uid` (l'unité morte)
        case 'phase': ctx.delay = self._onPhase(a, e); break;
        case 'bossNova': self._flash(0.55, 260); self.cameras.main.shake(320, 0.006); break;
        case 'victory':
          if (self.isInvasion && self.battle.waveIndex < self.battle.waveCount - 1) self._advanceWave();
          else self._onEnd(true);
          break;
        case 'defeat': self._onEnd(false); break;
        default: break;
      }
    });
  }

  _later(ms, fn) {
    if (!ms || ms <= 0) { fn(); return; }
    this.time.delayedCall(ms, fn);
  }

  // ---- styles d'attaque -------------------------------------------------
  _isRanged(v) {
    if (!v) return true;
    var u = v.unit;
    if (u.side === 'player') return ['zyra', 'korvax', 'drakor', 'rexar', 'targon', 'elys', 'vortex'].indexOf(u.heroId) < 0;
    return ['corvex_juggernaut', 'steel_golem', 'stellar_vampire', 'spore_swarm', 'voltaic_hunter'].indexOf(u.enemyId) < 0;
  }

  _colorOf(v) {
    var H = NEBUSTION.Heroes, EN = NEBUSTION.Enemies, hex = '#ffffff';
    if (v) {
      if (v.unit.side === 'player') { var h = H.get(v.unit.heroId); hex = (h && h.visual && h.visual.accent) || '#8fd8ff'; }
      else { var d = EN.get(v.unit.enemyId); hex = (d && d.visual && d.visual.color) || '#ff6a5e'; }
    }
    return parseInt(hex.replace('#', ''), 16);
  }

  /** Attaque de base : élan (mêlée) ou projectile (distance). Renvoie le délai avant l'impact (ms). */
  _playAttack(a, t) {
    if (!a || !t) return 0;
    var dx = t.cx - a.cx, dy = t.cy - a.cy, dist = Math.sqrt(dx * dx + dy * dy) || 1;
    if (this._isRanged(a)) {
      var flight = Math.max(140, Math.min(300, dist * 0.42));
      this._projectile(a.cx, a.cy - 10, t.cx, t.cy, this._colorOf(a), flight);
      a.lunge(dx / dist * -6, dy / dist * -6, 90);
      return flight;
    }
    var len = Math.min(70, dist * 0.35);
    a.lunge(dx / dist * len, dy / dist * len, 110);
    return 110;
  }

  _projectile(x0, y0, x1, y1, color, flight) {
    var self = this;
    var p = this.add.image(x0, y0, 'tex_proj').setTint(color).setBlendMode(Phaser.BlendModes.ADD).setDepth(500)
      .setRotation(Math.atan2(y1 - y0, x1 - x0)).setScale(0.9);
    this.tweens.add({
      targets: p, x: x1, y: y1, duration: flight, ease: 'Quad.easeIn',
      onComplete: function () { p.destroy(); }
    });
  }

  /** Lancement d'une compétence / d'un ultime : anneau, nom, cinématique légère. Renvoie le retard des effets (ms). */
  _castFx(v, name, ult) {
    if (!v) return 0;
    var enemy = v.unit.side === 'enemy';
    var col = this._colorOf(v);
    this._ring(v.cx, v.cy, col, ult ? 1.8 : 1.0);
    this._float(v.cx, v.cy - v.size * 0.62 - 28, name, enemy ? '#ff8a94' : '#ffe9a8', ult ? 20 : 16, { priority: true, dur: 950, rise: 30 });
    if (ult) {
      this._flash(0.35, 220);
      this.tweens.add({ targets: this.dimRect, alpha: 0.45, duration: 160, yoyo: true, hold: 300 });
      this.cameras.main.shake(260, 0.004);
      this._banner((enemy ? '⚠ ' : '★ ') + name + (enemy ? ' ⚠' : ' ★'), enemy ? '#ff6a78' : '#ffd166', 26, 700);
      this.pfx.crit.explode(14, v.cx, v.cy);
      return 420;
    }
    v.lunge(0, v.unit.side === 'player' ? -22 : 22, 140);
    return 220;
  }

  _onDamage(e, a, t, ctx) {
    var self = this;
    if (!t) return;
    var delay;
    if (e.dot || e.reflect) delay = 0;
    else if (e.late) delay = 0;
    else delay = ctx.delay;

    // Coups de compétence : projectile / coup de mêlée lancé au moment de l'effet
    var strike = (e.skill && !e.dot && !e.reflect && a && a !== t);
    var run = function () {
      if (strike) {
        var flight = 0;
        if (self._isRanged(a)) {
          flight = e.late ? 110 : 170;
          self._projectile(a.cx, a.cy - 10, t.cx, t.cy, self._colorOf(a), flight);
        } else if (!e.late) { flight = 70; }
        self._later(flight, function () { self._impact(e, a, t); });
      } else {
        self._impact(e, a, t);
      }
    };
    this._later(delay, run);
  }

  /** Effet d'impact + chiffre + mise à jour de la barre de vie (à l'arrivée du coup). */
  _impact(e, a, t) {
    if (!t) return;
    t.targetHp = Math.max(0, t.targetHp - e.amount);
    var enemyTarget = t.unit.side === 'enemy';
    var dirX = a ? Math.sign(t.cx - a.cx) : 0, dirY = a ? Math.sign(t.cy - a.cy) : (enemyTarget ? -1 : 1);
    if (e.dot) {
      // dégâts sur la durée : discrets (un chiffre par seconde et par unité, sans effet lourd)
      var now = this.time.now || 0;
      if (now - t.lastNumAt > 900) { t.lastNumAt = now; this._float(t.cx + 16, t.cy - 24, String(e.amount), '#ff9a5e', 14, { alpha: 0.85, rise: 28, dur: 600 }); }
      return;
    }
    t.flash();
    t.knock(dirX, dirY, e.crit ? 14 : 8);
    var pf = e.crit ? this.pfx.crit : (enemyTarget ? this.pfx.hit : this.pfx.hurt);
    pf.explode(e.crit ? 10 : (e.skill ? 7 : 4), t.cx, t.cy);
    if (e.crit || e.skill) {
      var sp = this.add.image(t.cx, t.cy, 'tex_spark').setBlendMode(Phaser.BlendModes.ADD).setDepth(510)
        .setTint(e.crit ? 0xffd166 : (enemyTarget ? 0xffffff : 0xff8a94)).setScale(0.2).setAlpha(0.95);
      this.tweens.add({ targets: sp, scale: e.crit ? 1.15 : 0.8, alpha: 0, duration: 260, ease: 'Cubic.easeOut', onComplete: function () { sp.destroy(); } });
    }
    if (e.absorbed > 0 && e.amount <= 1) { this._float(t.cx, t.cy - 30, 'ABSORBÉ', '#7fe8ff', 15); return; }

    // Lisibilité : coups de base discrets, compétences plus gros, critiques mis en avant.
    var size = e.crit ? 30 : (e.skill ? 24 : 18);
    var color = e.crit ? '#ffd166' : (enemyTarget ? '#ffffff' : '#ff8a94');
    var txt = String(e.amount) + (e.crit ? '!' : '');
    this._float(t.cx + (Math.random() * 24 - 12), t.cy - t.size * 0.3, txt, color, size,
      { priority: e.crit, alpha: e.skill || e.crit ? 1 : 0.85, rise: e.crit ? 64 : 44, pop: e.crit });
    if (e.crit && enemyTarget) this.cameras.main.shake(70, 0.0018);
  }

  _onHeal(e, t) {
    if (!t) return;
    t.targetHp = Math.min(t.unit.maxHp, t.targetHp + e.amount);
    if (e.passive) return; // régénération passive : la barre monte, sans chiffre ni particule
    this.pfx.heal.explode(7, t.cx, t.cy);
    this._float(t.cx, t.cy - t.size * 0.3, '+' + e.amount, '#7dff9a', e.amount > t.unit.maxHp * 0.18 ? 24 : 18, { rise: 50 });
  }

  _onRevive(e, t) {
    if (!t) return;
    t.targetHp = t.unit.hp; t.shownHp = t.unit.hp; t.ghostHp = t.unit.hp;
    this._ring(t.cx, t.cy, 0xeafcff, 1.6);
    this.pfx.heal.explode(16, t.cx, t.cy);
    this._float(t.cx, t.cy - 70, 'ÉTERNITÉ !', '#eafcff', 22, { priority: true, dur: 1100 });
    this._flash(0.25, 240);
  }

  _onDeath(t) {
    if (!t) return;
    var big = t.unit.isBoss;
    t.targetHp = 0;
    this.pfx.boom.explode(big ? 30 : 14, t.cx, t.cy);
    this._ring(t.cx, t.cy, t.unit.side === 'enemy' ? 0xff8a3d : 0x7a89ad, big ? 3.4 : 1.7);
    if (big) {
      this._flash(0.7, 500);
      this.cameras.main.shake(700, 0.01);
      for (var i = 0; i < 4; i++) {
        var self = this;
        this.time.delayedCall(140 * i, function () { self.pfx.boom.explode(14, t.cx + (Math.random() - 0.5) * 200, t.cy + (Math.random() - 0.5) * 200); });
      }
    } else if (t.unit.side === 'player') {
      this.cameras.main.shake(120, 0.003);
    }
    t.die(big);
  }

  _onPhase(a, e) {
    if (!a) return 0;
    this._banner('⚠ PHASE ' + (e.phase + 1) + ' ⚠', '#ff6a78', 34, 900);
    this._updatePhaseText();
    this._ring(a.cx, a.cy, 0xff4d5e, 3.0);
    this.pfx.boom.explode(24, a.cx, a.cy);
    this.cameras.main.shake(450, 0.007);
    this._flash(0.4, 300);
    return 380;
  }

  _flash(alpha, ms) {
    this.tweens.killTweensOf(this.flashRect);
    this.flashRect.setAlpha(alpha);
    this.tweens.add({ targets: this.flashRect, alpha: 0, duration: ms, ease: 'Cubic.easeOut' });
  }

  /** Anneau lumineux qui s'étend (texture partagée, détruit à la fin). */
  _ring(x, y, color, size, depth) {
    var r = this.add.image(x, y, 'tex_ring_soft').setTint(color).setBlendMode(Phaser.BlendModes.ADD)
      .setDepth(depth || 515).setScale(0.15).setAlpha(0.95);
    this.tweens.add({ targets: r, scale: size || 1.2, alpha: 0, duration: 520, ease: 'Cubic.easeOut', onComplete: function () { r.destroy(); } });
  }

  // =====================================================================
  // Fin de combat : récompenses (UNE seule fois) et écran de résultat
  // =====================================================================
  _onEnd(win) {
    if (this.ended) return;
    this.ended = true;
    var self = this;
    // On resynchronise les barres avec l'état final, puis on laisse respirer le dernier coup.
    var wait = win ? (this.bossView ? 1700 : 900) : 1100;
    this.time.delayedCall(wait, function () { self._showResult(); });
  }

  _showResult() {
    if (this._resultShown) return;
    this._resultShown = true;
    var self = this, w = this.scale.width, h = this.scale.height;
    var C = NEBUSTION.Combat, EN = NEBUSTION.Enemies, E = NEBUSTION.Economy, H = NEBUSTION.Heroes;
    var result = this.engine.getResult();
    var win = !!result.win;

    this.tweens.timeScale = 1; this.time.timeScale = 1;
    var inv = this.isInvasion;
    // crédite + sauvegarde, une seule fois (invasion : + résolution de la conquête et réaction de l'empire)
    var grant = inv ? C.grantInvasionRewards(this.battle.spec, result, this.planetId) : C.grantRewards(this.stageDef, this.difficulty, result);
    this._granted = grant;

    var layer = this.add.container(0, 0).setDepth(1300);
    this.resultLayer = layer;
    var dim = this.add.rectangle(w / 2, h / 2, w, h, 0x02040a, 0.86).setInteractive();
    layer.add(dim);

    var pw = 640, ph = 930, py = h / 2 - 10;
    var panel = this.add.graphics();
    panel.fillGradientStyle(0x151d33, 0x151d33, 0x0a0f1e, 0x0a0f1e, 0.98);
    panel.fillRoundedRect(w / 2 - pw / 2, py - ph / 2, pw, ph, 24);
    panel.lineStyle(3, win ? 0xffd166 : 0xff4d5e, 0.95);
    panel.strokeRoundedRect(w / 2 - pw / 2, py - ph / 2, pw, ph, 24);
    layer.add(panel);
    var top = py - ph / 2;

    layer.add(this.add.text(w / 2, top + 58, win ? (inv && grant.conquered ? 'PLANÈTE CONQUISE !' : 'VICTOIRE !') : 'DÉFAITE', {
      fontFamily: 'Arial, sans-serif', fontSize: (inv && win && grant.conquered) ? '38px' : '46px', fontStyle: '900', color: win ? '#ffd166' : '#ff6a78'
    }).setOrigin(0.5).setShadow(0, 0, win ? '#ffd166' : '#ff4d5e', 14, true, true));
    layer.add(this.add.text(w / 2, top + 100, this.stageDef.name, {
      fontFamily: 'Arial, sans-serif', fontSize: '16px', color: '#9aa5c0', align: 'center', wordWrap: { width: pw - 60 }
    }).setOrigin(0.5));

    // Étoiles (apparition successive)
    for (var s = 0; s < 3; s++) {
      (function (s) {
        var got = s < grant.stars;
        var star = self.add.text(w / 2 + (s - 1) * 92, top + 172, got ? '★' : '☆', {
          fontFamily: 'Arial, sans-serif', fontSize: '76px', color: got ? '#ffd166' : '#3a4866'
        }).setOrigin(0.5).setAlpha(0).setScale(0.3);
        layer.add(star);
        self.tweens.add({ targets: star, alpha: 1, scale: 1, duration: 320, delay: 350 + s * 260, ease: 'Back.easeOut' });
      })(s);
    }

    var secs = Math.round(result.timeSec);
    layer.add(this.add.text(w / 2, top + 244, 'Durée ' + Math.floor(secs / 60) + ':' + ('0' + (secs % 60)).slice(-2) +
      '   ·   Survivants ' + result.survivors + '/' + result.totalPlayers +
      '   ·   ' + (inv ? ('Invasion · ' + this.battle.waveCount + ' vague' + (this.battle.waveCount > 1 ? 's' : '')) : EN.DIFFICULTIES[this.difficulty].name), {
      fontFamily: 'Arial, sans-serif', fontSize: '15px', color: '#a9b8dc'
    }).setOrigin(0.5));

    // Récompenses
    var y = top + 290;
    layer.add(this.add.text(w / 2, y, win ? 'RÉCOMPENSES' : 'RÉCOMPENSES DE CONSOLATION', {
      fontFamily: 'Arial, sans-serif', fontSize: '15px', fontStyle: 'bold', color: '#00e5ff'
    }).setOrigin(0.5));
    y += 34;
    var items = [], full = false;
    E.ORDER.forEach(function (rid) {
      var r = grant.rewards[rid];
      if (!r) return;
      var got = grant.granted[rid] || 0;
      if (got < r - 0.5) full = true;
      items.push({ rid: rid, amount: r, got: got });
    });
    var cols = 3, cellW = 190;
    items.forEach(function (it, i) {
      var col = i % cols, row = Math.floor(i / cols);
      var count = Math.min(cols, items.length - row * cols);
      var x = w / 2 - (count * cellW) / 2 + cellW / 2 + col * cellW, yy = y + row * 60;
      var ic = self.add.image(x - 44, yy + 20, 'tex_icon_' + it.rid).setDisplaySize(40, 40).setAlpha(0);
      var tx = self.add.text(x - 16, yy + 20, '+' + E.fmtGain(it.amount), {
        fontFamily: 'Arial, sans-serif', fontSize: '22px', fontStyle: 'bold', color: E.RES[it.rid].hex
      }).setOrigin(0, 0.5).setAlpha(0);
      layer.add([ic, tx]);
      self.tweens.add({ targets: [ic, tx], alpha: 1, duration: 260, delay: 1100 + i * 110 });
    });
    y += Math.ceil(items.length / cols) * 60 + 8;
    if (full) {
      layer.add(this.add.text(w / 2, y, '⚠ Stockage plein : une partie des ressources est perdue', {
        fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#ffb84d'
      }).setOrigin(0.5));
      y += 24;
    }

    layer.add(this.add.text(w / 2, y + 10, 'XP joueur  +' + grant.rewards.xp, {
      fontFamily: 'Arial, sans-serif', fontSize: '20px', fontStyle: 'bold', color: '#c7d1ea'
    }).setOrigin(0.5));
    y += 44;

    // Invasion : conquête + réaction de l'empire (mêmes modules IA que la carte : EmpireEvolutionManager)
    if (inv) y = this._invasionInfo(layer, y, grant, win);

    // Fragments de héros (par héros) + montées de niveau
    if (grant.rewards.fragments > 0) {
      layer.add(this.add.text(w / 2, y, 'Fragments de héros  +' + grant.rewards.fragments + ' pour chacun des ' + grant.fragmentHeroes.length + ' héros', {
        fontFamily: 'Arial, sans-serif', fontSize: '16px', fontStyle: 'bold', color: '#ffb0e0'
      }).setOrigin(0.5));
      y += 34;
      var ups = grant.levelUps || [];
      if (ups.length) {
        ups.slice(0, inv ? 3 : 5).forEach(function (u, i) {
          var hero = H.get(u.heroId);
          layer.add(self.add.text(w / 2, y + i * 26, '⬆ ' + hero.name + ' passe au niveau ' + u.level + ' !', {
            fontFamily: 'Arial, sans-serif', fontSize: '17px', fontStyle: 'bold', color: '#7dff9a'
          }).setOrigin(0.5));
        });
        y += Math.min(inv ? 3 : 5, ups.length) * 26 + 10;
      } else {
        layer.add(this.add.text(w / 2, y, 'Prochain niveau : ' + C.FRAGMENTS_PER_LEVEL + ' fragments par niveau', {
          fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#7a89ad'
        }).setOrigin(0.5));
        y += 30;
      }
    }

    // Objet d'équipement trouvé (combat/invasion)
    if (grant.equipDrop) {
      var EQ = NEBUSTION.Equipment, drop = grant.equipDrop, dr = EQ.RARITIES[drop.rarity];
      layer.add(this.add.text(w / 2, y, 'Objet trouvé : ' + EQ.itemName(drop.slot, drop.rarity), {
        fontFamily: 'Arial, sans-serif', fontSize: '16px', fontStyle: 'bold', color: dr.hex
      }).setOrigin(0.5));
      y += 30;
    }

    // Boutons
    var by = top + ph - 214;
    if (inv) { this._invasionButtons(layer, by, win); this._finishResult(layer, win, top); return; }
    var next = EN.nextStageId(this.stageId);
    var canNext = win && next && C.isStageUnlocked(next);
    var retry = new NEBUSTION.Button(this, w / 2 - (canNext ? 158 : 0), by, {
      width: canNext ? 300 : 420, height: 70, label: 'REJOUER', accentColor: 0x00e5ff, fontSize: '22px',
      onClick: function () { self._restart(self.stageId); }
    });
    layer.add(retry);
    if (canNext) {
      var nextBtn = new NEBUSTION.Button(this, w / 2 + 158, by, {
        width: 300, height: 70, label: 'STAGE SUIVANT', accentColor: 0xffd166, fontSize: '20px',
        onClick: function () { self._restart(next); }
      });
      layer.add(nextBtn);
    }
    var prep = new NEBUSTION.Button(this, w / 2, by + 92, {
      width: 420, height: 62, label: 'PRÉPARATION', accentColor: 0x7a89ad, fontSize: '19px',
      onClick: function () { self._goPrep(win && next ? next : self.stageId); }
    });
    layer.add(prep);
    var menu = new NEBUSTION.Button(this, w / 2, by + 168, {
      width: 420, height: 52, label: 'Retour au menu', accentColor: 0x394869, fontSize: '16px',
      onClick: function () {
        self.cameras.main.fadeOut(300, 5, 7, 15);
        self.cameras.main.once('camerafadeoutcomplete', function () { self.scene.start('MainMenuScene'); });
      }
    });
    layer.add(menu);

    this._finishResult(layer, win, top);
  }

  _finishResult(layer, win, top) {
    var w = this.scale.width;
    layer.setAlpha(0);
    this.tweens.add({ targets: layer, alpha: 1, duration: 300 });
    if (win) { this.pfx.crit.explode(20, w / 2, top + 172); }
  }

  /** Résultat d'invasion : conquête (colonie + revenus) et réaction de l'empire vaincu / vainqueur. Retourne le nouvel y. */
  _invasionInfo(layer, y, grant, win) {
    var w = this.scale.width, G = NEBUSTION.Galaxy, GM = NEBUSTION.GalaxyManager, EEM = NEBUSTION.EmpireEvolutionManager, E = NEBUSTION.Economy;
    var self = this, planet = G.planet(this.planetId);
    function line(txt, color, size, bold) {
      layer.add(self.add.text(w / 2, y, txt, { fontFamily: 'Arial, sans-serif', fontSize: (size || 15) + 'px', fontStyle: bold ? 'bold' : 'normal', color: color, align: 'center', wordWrap: { width: 580 } }).setOrigin(0.5));
      y += 26;
    }
    if (win && grant.conquered) {
      var inc = GM.colonyIncomeOf(this.planetId), parts = [];
      E.ORDER.forEach(function (rid) { if (inc[rid]) parts.push('+' + E.fmtGain(inc[rid]) + ' ' + E.RES[rid].short + '/h'); });
      line('⚑ ' + planet.name + ' rejoint votre empire', '#7dff9a', 17, true);
      if (parts.length) line('Revenus : ' + parts.slice(0, 3).join('  '), '#a9f5c0', 13, false);
    } else if (win) {
      line('Victoire, mais le scan a expiré : planète non conquise', '#ffb84d', 14, true);
    } else {
      line('Défense tenue : la planète reste à l\'empire', '#ff8a94', 15, true);
    }
    var eid = grant.empire || planet.empire;
    if (eid && EEM) {
      var es = EEM.empireStatus(eid, Date.now());
      if (es) {
        var em = G.empire(eid), post = { defensive: 'défensive', balanced: 'équilibrée', offensive: 'offensive' }[es.posture] || '—';
        var reaction = (win && grant.conquered) ? em.name + ' encaisse la perte' : (win ? em.name + ' est ébranlé' : em.name + ' se renforce');
        line(reaction + ' · ' + es.owned + '/' + es.total + ' planètes · doctrine ' + (es.strategy || '—') + ' (' + post + ') · alerte ' + es.alert + '/3', em.hex, 12, false);
      }
    }
    return y + 6;
  }

  /** Boutons de fin d'invasion : victoire → Galaxie / Héros ; défaite → Réessayer (si le scan tient encore) / Galaxie. */
  _invasionButtons(layer, by, win) {
    var self = this, w = this.scale.width, GM = NEBUSTION.GalaxyManager, EEM = NEBUSTION.EmpireEvolutionManager;
    var canRetry = !win && GM.canInvade(this.planetId, Date.now()).ok && EEM.isReachable(this.planetId);
    var pid = this.planetId;
    var first = win
      ? new NEBUSTION.Button(this, w / 2, by, { width: 420, height: 70, label: 'RETOUR À LA GALAXIE', accentColor: 0xffd166, fontSize: '21px', onClick: function () { if (!self._leaving) self._goGalaxy(pid); } })
      : new NEBUSTION.Button(this, w / 2, by, { width: 420, height: 70, label: canRetry ? 'RÉESSAYER' : 'SCAN EXPIRÉ', accentColor: canRetry ? 0x00e5ff : 0x394869, fontSize: '22px', disabled: !canRetry, onClick: function () { self._restart(); } });
    layer.add(first);
    var second = win
      ? new NEBUSTION.Button(this, w / 2, by + 92, { width: 420, height: 62, label: 'HÉROS', accentColor: 0xff4d9e, fontSize: '19px', onClick: function () { self._leaveTo('HeroesScene', { navKey: 'heroes', title: 'Héros' }); } })
      : new NEBUSTION.Button(this, w / 2, by + 92, { width: 420, height: 62, label: 'GALAXIE', accentColor: 0xffd166, fontSize: '19px', onClick: function () { if (!self._leaving) self._goGalaxy(pid); } });
    layer.add(second);
    var menu = new NEBUSTION.Button(this, w / 2, by + 168, {
      width: 420, height: 52, label: 'Retour au menu', accentColor: 0x394869, fontSize: '16px',
      onClick: function () { self._leaveTo('MainMenuScene', {}); }
    });
    layer.add(menu);
  }

  _leaveTo(sceneKey, data) {
    if (this._leaving) return;
    this._leaving = true;
    var self = this;
    this.cameras.main.fadeOut(300, 5, 7, 15);
    this.cameras.main.once('camerafadeoutcomplete', function () { self.scene.start(sceneKey, data); });
  }

  _restart(stageId) {
    if (this._leaving) return;
    this._leaving = true;
    var self = this;
    this.cameras.main.fadeOut(300, 5, 7, 15);
    this.cameras.main.once('camerafadeoutcomplete', function () {
      if (self.isInvasion) self.scene.start('CombatScene', { planetId: self.planetId });
      else self.scene.start('CombatScene', { stageId: stageId, difficulty: self.difficulty });
    });
  }
};
