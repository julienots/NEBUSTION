/**
 * NEBUSTION - PlanetBuildUI (extension de PlanetScene)
 * Constructions à PLACEMENT LIBRE sur Nexus-01 (données/règles : js/data/PlanetBuild.js).
 *
 * Parcours : bouton CONSTRUIRE → catalogue → on choisit un bâtiment → un aperçu apparaît sur la planète
 * (vert = libre, rouge = impossible) → on touche la planète pour le déplacer, on la tourne du doigt pour
 * viser ailleurs → POSER ICI. Toucher une construction posée : DÉPLACER (gratuit) ou RECYCLER (50 %).
 * Les constructions sont ancrées à la surface (longitude/latitude) comme les bâtiments d'origine :
 * inclinées selon le sol, pastille lumineuse au sol, cachées derrière la planète.
 */
(function () {
  'use strict';
  var PS = NEBUSTION.PlanetScene;
  if (!PS) return;
  var PB = function () { return NEBUSTION.PlanetBuild; };
  var FONT = 'Arial, sans-serif';

  function setTxt(obj, str) { if (obj._last === str) return; obj._last = str; obj.setText(str); }

  Object.assign(PS.prototype, {

    // ------------------------------------------------------------------ mise en place
    _initBuild: function () {
      var R = NEBUSTION.Resources, h = this.scale.height;
      if (!PB() || !R || !R.state) return;
      if (!R.state.planetBuild) R.state.planetBuild = PB().defaultState();
      R.state.planetBuild.items.forEach((it) => this._addStruct(it));
      this._buildSheet();
      this._buildBar();
      this._btnY = h - 172;
      this._buildBtn = new NEBUSTION.Button(this, 96, this._btnY, {
        width: 168, height: 50, label: 'CONSTRUIRE', accentColor: 0xffd166, fontSize: '17px',
        onClick: () => this._openCatalog()
      });
      this._buildBtn.setDepth(1200);
    },

    /** Autres emplacements occupés : bâtiments, gisements et constructions posées. */
    _occupied: function () {
      var out = [], L = NEBUSTION.PlanetLayout, R = NEBUSTION.Resources;
      L.buildings.forEach(function (b) { out.push({ lon: b.lonDeg, lat: b.latDeg }); });
      Object.keys(L.nodes).forEach(function (k) { out.push({ lon: L.nodes[k].lonDeg, lat: L.nodes[k].latDeg }); });
      R.state.planetBuild.items.forEach(function (it) { out.push({ id: it.id, lon: it.lon, lat: it.lat }); });
      return out;
    },

    // ------------------------------------------------------------------ constructions posées
    _makeStructBox: function (def, ghost) {
      var container = this.add.container(0, 0).setDepth(0).setVisible(false);
      var box = { container: container, scale: 0.95, hit: null, deco: { dx: 0, dy: 0, ds: 1 }, tapEnabled: true, alphaMul: ghost ? 0.8 : 1, anim: null };
      this._drawStructure(container, def, box);
      if (!ghost) {
        box.hit = (def.tall ? this.add.zone(0, -62, 100, 176) : this.add.zone(0, -34, 100, 120)).setOrigin(0.5).setInteractive({ useHandCursor: true });
        container.add(box.hit);
      }
      return box;
    },

    _addStruct: function (item) {
      var def = PB().CATALOG[item.type];
      if (!def) return null;
      var box = this._makeStructBox(def, false);
      box.item = item;
      this._structs[item.id] = box;
      this._sphereAnchors.push({ type: 'struct', key: item.id, lonDeg: item.lon, latDeg: item.lat, box: box, color: def.color, padR: 44 });
      box.hit.on('pointerdown', () => {
        if (this._placing || this._sheetOpen) return;
        this._showStructBar(item.id);
      });
      return box;
    },

    _removeAnchor: function (predicate) {
      for (var i = this._sphereAnchors.length - 1; i >= 0; i--) if (predicate(this._sphereAnchors[i])) this._sphereAnchors.splice(i, 1);
    },

    _structAnchor: function (id) {
      for (var i = 0; i < this._sphereAnchors.length; i++) if (this._sphereAnchors[i].type === 'struct' && this._sphereAnchors[i].key === id) return this._sphereAnchors[i];
      return null;
    },

    // ------------------------------------------------------------------ catalogue
    _buildSheet: function () {
      var w = this.scale.width, h = this.scale.height, self = this;
      var cols = 4, cw = 156, ch = 112, gap = 8, x0 = -((cols * cw + (cols - 1) * gap) / 2) + cw / 2;
      var extra = (Math.max(2, Math.ceil(PB().ORDER.length / cols)) - 2) * (ch + 8);   // hauteur ajoutée si plus de 2 rangées de cartes
      this._sheetExtra = extra;
      var sheet = this.add.container(w / 2, h + 500).setDepth(1105);
      var bg = this.add.graphics();
      bg.fillGradientStyle(0x101a33, 0x101a33, 0x0a1020, 0x0a1020, 0.98);
      bg.fillRoundedRect(-w * 0.47, -170, w * 0.94, 340 + extra, 22);
      bg.lineStyle(2, 0xffd166, 0.6); bg.strokeRoundedRect(-w * 0.47, -170, w * 0.94, 340 + extra, 22);
      sheet.add(bg);
      sheet.add(this.add.rectangle(0, extra / 2, w * 0.94, 340 + extra, 0x000000, 0.001).setInteractive());   // bloque les taps vers la planète
      sheet.add(this.add.text(-w * 0.44, -148, 'Construire sur Nexus-01', { fontFamily: FONT, fontSize: '24px', fontStyle: 'bold', color: '#eaf2ff' }).setOrigin(0, 0.5));
      var close = this.add.text(w * 0.44, -148, '✕', { fontFamily: FONT, fontSize: '30px', color: '#a9b8dc' }).setOrigin(0.5).setInteractive({ useHandCursor: true });
      close.on('pointerdown', () => this._closeSheet());
      sheet.add(close);

      this._cards = [];
      PB().ORDER.forEach(function (type, i) {
        var def = PB().CATALOG[type], col = i % cols, row = Math.floor(i / cols);
        var cx = x0 + col * (cw + gap), cy = -80 + row * (ch + 8) + ch / 2 - 0;
        var cg = self.add.graphics();
        var icon = self.add.text(cx, cy - 34, def.icon, { fontFamily: FONT, fontSize: '32px' }).setOrigin(0.5);
        var name = self.add.text(cx, cy - 4, def.name, { fontFamily: FONT, fontSize: '14px', fontStyle: 'bold', color: '#eaf2ff', align: 'center', wordWrap: { width: cw - 14 } }).setOrigin(0.5);
        var costs = [], k;
        for (k = 0; k < 2; k++) {
          costs.push({
            icon: self.add.image(0, cy + 26, 'tex_icon_crystal').setDisplaySize(18, 18).setVisible(false),
            text: self.add.text(0, cy + 26, '', { fontFamily: FONT, fontSize: '14px', fontStyle: 'bold', color: '#eaf2ff' }).setOrigin(0, 0.5).setVisible(false)
          });
        }
        var cnt = self.add.text(cx, cy + 48, '', { fontFamily: FONT, fontSize: '12px', color: '#8ea0c8' }).setOrigin(0.5);
        var zone = self.add.zone(cx, cy, cw, ch).setInteractive({ useHandCursor: true });
        zone.on('pointerdown', function () { self._onCardTap(type); });
        sheet.add([cg, icon, name, costs[0].icon, costs[0].text, costs[1].icon, costs[1].text, cnt, zone]);
        self._cards.push({ type: type, cx: cx, cy: cy, cw: cw, ch: ch, cg: cg, icon: icon, name: name, costs: costs, cnt: cnt });
      });
      sheet.add(this.add.text(0, 161 + extra, 'Touche un bâtiment, puis la planète pour le poser. Recyclage : 50 % rendus.', { fontFamily: FONT, fontSize: '14px', color: '#8ea0c8' }).setOrigin(0.5));

      this._sheet = sheet;
      this._sheetClosedY = h + 500;
      this._sheetOpenY = h - 300 - extra;
    },

    _openCatalog: function () {
      if (this._placing || this._sheetOpen) return;
      if (this._panelOpen && this._hideInfoPanel) this._hideInfoPanel();
      if (this._barOpen) this._hideBar();
      this._sheetOpen = true; this._sheetAcc = 0;
      this._refreshCatalog();
      this._buildBtn.setPosition(-400, this._btnY);
      this.tweens.add({ targets: this._sheet, y: this._sheetOpenY, duration: 300, ease: 'Back.easeOut' });
    },

    _closeSheet: function (keepBtnHidden) {
      if (!this._sheetOpen) return;
      this._sheetOpen = false;
      this.tweens.add({ targets: this._sheet, y: this._sheetClosedY, duration: 240, ease: 'Sine.easeIn' });
      if (!keepBtnHidden) this._buildBtn.setPosition(96, this._btnY);
    },

    /** Coût, quantité et disponibilité de chaque carte (rafraîchi ~3 fois/s tant que le catalogue est ouvert). */
    _refreshCatalog: function () {
      var R = NEBUSTION.Resources, E = NEBUSTION.Economy, P = PB(), st = R.state.planetBuild, total = st.items.length;
      this._cards.forEach(function (c) {
        var def = P.CATALOG[c.type], owned = P.count(st, c.type), maxed = owned >= def.maxCount || total >= P.MAX_TOTAL;
        var cost = P.cost(c.type, owned), afford = !maxed && R.canAfford(cost);
        var g = c.cg;
        g.clear();
        g.fillStyle(0x0d1428, 0.96); g.fillRoundedRect(c.cx - c.cw / 2, c.cy - c.ch / 2, c.cw, c.ch, 14);
        g.lineStyle(2, maxed ? 0x394869 : def.color, afford ? 0.95 : 0.45); g.strokeRoundedRect(c.cx - c.cw / 2, c.cy - c.ch / 2, c.cw, c.ch, 14);
        c.icon.setAlpha(maxed ? 0.35 : 1); c.name.setAlpha(maxed ? 0.5 : 1);
        setTxt(c.cnt, maxed ? (owned >= def.maxCount ? 'Maximum atteint' : 'Limite atteinte') : (owned + ' / ' + def.maxCount + (def.badge ? '  ·  ' + def.badge : ' posé' + (owned > 1 ? 's' : ''))));
        var keys = maxed ? [] : Object.keys(cost), widths = [], i, tot = 0, slot, id;
        for (i = 0; i < 2; i++) {
          slot = c.costs[i];
          if (i < keys.length) {
            id = keys[i];
            slot.icon.setTexture('tex_icon_' + id).setDisplaySize(18, 18).setVisible(true);
            setTxt(slot.text, E.fmt(cost[id], 0));
            slot.text.setColor(R.get(id) + 1e-9 >= cost[id] ? '#eaf2ff' : '#ff8fa3').setVisible(true);
            widths[i] = 18 + 4 + slot.text.width; tot += widths[i] + (i ? 12 : 0);
          } else { slot.icon.setVisible(false); slot.text.setVisible(false); }
        }
        var x = c.cx - tot / 2;
        for (i = 0; i < keys.length; i++) { slot = c.costs[i]; slot.icon.x = x + 9; slot.text.x = x + 22; x += widths[i] + 12; }
      });
    },

    _onCardTap: function (type) {
      var R = NEBUSTION.Resources, E = NEBUSTION.Economy, P = PB(), st = R.state.planetBuild, def = P.CATALOG[type];
      var owned = P.count(st, type), cost = P.cost(type, owned);
      if (st.items.length >= P.MAX_TOTAL) { this.fx.toast('Limite atteinte', P.MAX_TOTAL + ' constructions au maximum sur la planète.'); return; }
      if (owned >= def.maxCount) { this.fx.toast('Maximum atteint', def.name + ' : ' + def.maxCount + ' exemplaires.'); return; }
      if (!R.canAfford(cost)) {
        var miss = Object.keys(cost).filter(function (id) { return R.get(id) + 1e-9 < cost[id]; });
        var shown = miss.slice(0, 2).map(function (id) { return E.fmt(Math.ceil(cost[id] - R.get(id)), 0) + ' ' + E.RES[id].short; }).join('  •  ');
        this.fx.toast('Ressources insuffisantes', 'Il manque : ' + shown, miss[0]);
        this.fx.vibrate(15);
        return;
      }
      this._startPlacement(type, null);
    },

    // ------------------------------------------------------------------ barre du bas (placement / gestion)
    _buildBar: function () {
      var w = this.scale.width, h = this.scale.height, self = this;
      var bar = this.add.container(w / 2, h + 300).setDepth(1105);
      var bg = this.add.graphics();
      bg.fillGradientStyle(0x101a33, 0x101a33, 0x0a1020, 0x0a1020, 0.98);
      bg.fillRoundedRect(-w * 0.47, -85, w * 0.94, 170, 22);
      bg.lineStyle(2, 0x2e9eff, 0.6); bg.strokeRoundedRect(-w * 0.47, -85, w * 0.94, 170, 22);
      bar.add(bg);
      bar.add(this.add.rectangle(0, 0, w * 0.94, 170, 0x000000, 0.001).setInteractive());
      var title = this.add.text(-w * 0.44, -58, '', { fontFamily: FONT, fontSize: '25px', fontStyle: 'bold', color: '#eaf2ff' }).setOrigin(0, 0.5);
      var status = this.add.text(-w * 0.44, -26, '', { fontFamily: FONT, fontSize: '17px', color: '#8ea0c8', wordWrap: { width: w * 0.86 } }).setOrigin(0, 0.5);
      var close = this.add.text(w * 0.44, -58, '✕', { fontFamily: FONT, fontSize: '30px', color: '#a9b8dc' }).setOrigin(0.5).setInteractive({ useHandCursor: true });
      close.on('pointerdown', () => { if (self._placing) self._cancelPlacement(); else self._hideBar(); });
      bar.add([title, status, close]);
      var slots = [], k;
      for (k = 0; k < 3; k++) {
        var ic = this.add.image(0, 8, 'tex_icon_crystal').setDisplaySize(24, 24).setVisible(false);
        var tx = this.add.text(0, 8, '', { fontFamily: FONT, fontSize: '19px', fontStyle: 'bold', color: '#eaf2ff' }).setOrigin(0, 0.5).setVisible(false);
        bar.add([ic, tx]); slots.push({ icon: ic, text: tx });
      }
      var left = new NEBUSTION.Button(this, -w * 0.44 + 105, 54, { width: 210, height: 52, label: 'ANNULER', accentColor: 0x394869, fontSize: '18px', onClick: function () {} });
      var right = new NEBUSTION.Button(this, w * 0.44 - 170, 54, { width: 340, height: 52, label: 'POSER ICI', accentColor: 0x7dffb0, fontSize: '19px', onClick: function () {} });
      bar.add([left, right]);
      this._bar = bar; this._barTitle = title; this._barStatus = status; this._barCost = slots; this._barLeft = left; this._barRight = right; this._barClose = close;
      this._barClosedY = h + 300; this._barOpenY = h - 215;
    },

    /** cfg : title, status, statusColor, cost (ou null), left {label, color, onClick}, right {label, color, onClick, disabled}, closable. */
    _showBar: function (cfg) {
      var w = this.scale.width, E = NEBUSTION.Economy, R = NEBUSTION.Resources;
      this._barTitle.setText(cfg.title);
      this._barStatus.setText(cfg.status || '').setColor(cfg.statusColor || '#8ea0c8');
      this._barClose.setVisible(cfg.closable !== false);
      var keys = cfg.cost ? Object.keys(cfg.cost) : [], x = -w * 0.44, i, slot, id;
      for (i = 0; i < 3; i++) {
        slot = this._barCost[i];
        if (i < keys.length) {
          id = keys[i];
          slot.icon.setTexture('tex_icon_' + id).setDisplaySize(24, 24).setPosition(x + 12, 8).setVisible(true);
          slot.text.setText(E.fmt(cfg.cost[id], 0)).setColor(R.get(id) + 1e-9 >= cfg.cost[id] ? '#eaf2ff' : '#ff8fa3').setPosition(x + 30, 8).setVisible(true);
          x += 30 + slot.text.width + 20;
        } else { slot.icon.setVisible(false); slot.text.setVisible(false); }
      }
      this._barLeft.labelText.setText(cfg.left.label); this._barLeft.setLook(cfg.left.color, '#eaf2ff'); this._barLeft.onClick = cfg.left.onClick;
      this._barRight.labelText.setText(cfg.right.label); this._barRight.setLook(cfg.right.color, cfg.right.disabled ? '#9fb0d6' : '#eaf2ff'); this._barRight.onClick = cfg.right.onClick;
      this._barRight.setDisabled(!!cfg.right.disabled);
      if (!this._barOpen) {
        this._barOpen = true;
        this._buildBtn.setPosition(-400, this._btnY);
        this.tweens.add({ targets: this._bar, y: this._barOpenY, duration: 300, ease: 'Back.easeOut' });
      }
    },

    _hideBar: function () {
      if (!this._barOpen) return;
      this._barOpen = false; this._selStruct = null; this._recycleArm = null;
      this.tweens.add({ targets: this._bar, y: this._barClosedY, duration: 240, ease: 'Sine.easeIn' });
      if (!this._sheetOpen) this._buildBtn.setPosition(96, this._btnY);
    },

    // ------------------------------------------------------------------ placement
    _startPlacement: function (type, moveId) {
      var P = PB(), def = P.CATALOG[type], R = NEBUSTION.Resources;
      this._closeSheet(true);
      if (this._panelOpen && this._hideInfoPanel) this._hideInfoPanel();
      var start;
      if (moveId) { var it = P.find(R.state.planetBuild, moveId); start = { lonDeg: it.lon, latDeg: it.lat }; var real = this._structs[moveId]; if (real) real.alphaMul = 0.3; }
      else start = this._unprojectSphere(this._planetCX, this._planetCY - this._planetR * 0.05) || { lonDeg: 0, latDeg: 0 };
      this._placing = { type: type, moveId: moveId || null, lon: start.lonDeg, lat: start.latDeg, valid: false, free: false, afford: true };
      this._ghostBox = this._makeStructBox(def, true);
      this._ghostAnchor = { type: 'struct', ghost: true, key: '__ghost', lonDeg: start.lonDeg, latDeg: start.latDeg, box: this._ghostBox, color: def.color, padR: 44 };
      this._sphereAnchors.push(this._ghostAnchor);
      var spot = this._findFreeSpot(start.lonDeg, start.latDeg);
      this._setGhostAt(spot.lon, spot.lat);
      this._barOpen = false;   // _showBar l'ouvre (et masque le bouton)
      this._refreshPlacementBar();
    },

    /** Autour d'un point de départ, le premier emplacement libre et bien visible (spirale de 8° à 70°). */
    _findFreeSpot: function (lon, lat) {
      var P = PB(), pl = this._placing, occ = this._occupied(), d, a, r = Math.PI / 180, c, la2, lo2, p;
      if (P.spotOk(lon, lat, occ, pl.moveId)) return { lon: lon, lat: lat };
      for (d = 8; d <= 70; d += 6) {
        for (a = 0; a < 360; a += 30) {
          la2 = Math.asin(Math.sin(lat * r) * Math.cos(d * r) + Math.cos(lat * r) * Math.sin(d * r) * Math.cos(a * r));
          lo2 = lon * r + Math.atan2(Math.sin(a * r) * Math.sin(d * r) * Math.cos(lat * r), Math.cos(d * r) - Math.sin(lat * r) * Math.sin(la2));
          c = { lon: P.normLon(lo2 / r), lat: la2 / r };
          p = this._projectSphere(c.lon, c.lat);
          if (p.z > 0.4 && P.spotOk(c.lon, c.lat, occ, pl.moveId)) return c;
        }
      }
      return { lon: lon, lat: lat };
    },

    _setGhostAt: function (lon, lat) {
      var P = PB(), R = NEBUSTION.Resources, pl = this._placing, a = this._ghostAnchor;
      if (!pl) return;
      lon = P.normLon(lon); lat = Math.max(-P.MAX_LAT, Math.min(P.MAX_LAT, lat));
      a.lonDeg = lon; a.latDeg = lat; pl.lon = lon; pl.lat = lat;
      pl.free = P.spotOk(lon, lat, this._occupied(), pl.moveId);
      pl.afford = pl.moveId ? true : R.canAfford(P.cost(pl.type, P.count(R.state.planetBuild, pl.type)));
      pl.valid = pl.free && pl.afford;
      this._refreshPlacementBar();
    },

    _refreshPlacementBar: function () {
      var P = PB(), R = NEBUSTION.Resources, pl = this._placing;
      if (!pl) return;
      var def = P.CATALOG[pl.type], moving = !!pl.moveId;
      var status, color;
      if (!pl.free) { status = 'Trop près d\'un autre bâtiment : touche ailleurs.'; color = '#ff8fa3'; }
      else if (!pl.afford) { status = 'Ressources insuffisantes.'; color = '#ff8fa3'; }
      else { status = 'Emplacement libre. Touche la planète pour déplacer, glisse pour la tourner.'; color = '#7dffb0'; }
      this._showBar({
        title: (moving ? 'Déplacer : ' : '') + def.name, status: status, statusColor: color, closable: false,
        cost: moving ? null : P.cost(pl.type, P.count(R.state.planetBuild, pl.type)),
        left: { label: 'ANNULER', color: 0x394869, onClick: () => this._cancelPlacement() },
        right: { label: moving ? 'DÉPLACER ICI' : 'POSER ICI', color: pl.valid ? 0x7dffb0 : 0x394869, disabled: !pl.valid, onClick: () => this._confirmPlacement() }
      });
    },

    _onPlacementTap: function (pointer) {
      if (!this._placing || this._uiBlocks(pointer)) return;
      var pt = this._unprojectSphere(pointer.x, pointer.y);
      if (pt) this._setGhostAt(pt.lonDeg, pt.latDeg);
    },

    _endPlacement: function () {
      var pl = this._placing;
      if (pl && pl.moveId && this._structs[pl.moveId]) this._structs[pl.moveId].alphaMul = 1;
      this._removeAnchor(function (a) { return a.ghost; });
      if (this._ghostBox) { this._ghostBox.container.destroy(); this._ghostBox = null; }
      this._ghostAnchor = null; this._placing = null;
      this._hideBar();
    },

    _cancelPlacement: function () { this._endPlacement(); },

    _confirmPlacement: function () {
      var P = PB(), R = NEBUSTION.Resources, E = NEBUSTION.Economy, pl = this._placing;
      if (!pl) return;
      if (!pl.valid) { this.fx.vibrate(15); this.fx.toast(pl.free ? 'Ressources insuffisantes' : 'Emplacement occupé', pl.free ? 'Récolte encore un peu.' : 'Choisis un endroit plus dégagé.'); return; }
      var others = this._occupied(), def = P.CATALOG[pl.type], res, box, item;
      res = pl.moveId ? P.move(R, pl.moveId, pl.lon, pl.lat, others) : P.place(R, pl.type, pl.lon, pl.lat, others);
      if (!res.ok) {
        var msg = { spot: 'Emplacement occupé', cost: 'Ressources insuffisantes', max: 'Maximum atteint', total: 'Limite atteinte' }[res.reason] || 'Impossible';
        this.fx.toast(msg, def.name); this._setGhostAt(pl.lon, pl.lat); return;
      }
      if (pl.moveId) {
        var an = this._structAnchor(pl.moveId); item = res.item;
        if (an) { an.lonDeg = item.lon; an.latDeg = item.lat; }
        box = this._structs[pl.moveId];
      } else {
        box = this._addStruct(res.item);
      }
      var gc = this._ghostBox.container, gx = gc.x, gy = gc.y;
      this.fx.ring(gx, gy - 20, def.color, 2);
      this.fx.burst('crystal', gx, gy - 10, 16);
      this.fx.text(gx, gy - 70, pl.moveId ? 'DÉPLACÉ' : 'CONSTRUIT', '#7dffb0', 30, 70);
      if (!pl.moveId && def.effect && def.effect.production) {
        this.fx.toast(def.name + ' active', 'Production totale +' + Math.round(P.productionBonus(R.state.planetBuild) * 100) + ' % au total');
      }
      this.fx.vibrate(25);
      try { if (window.nebustionPlaySfx) window.nebustionPlaySfx('build'); } catch (e) { /* son facultatif */ }
      this._endPlacement();
    },

    // ------------------------------------------------------------------ gestion d'une construction posée
    _showStructBar: function (id) {
      var P = PB(), R = NEBUSTION.Resources, it = P.find(R.state.planetBuild, id);
      if (!it) return;
      var def = P.CATALOG[it.type], owned = P.count(R.state.planetBuild, it.type), c = P.cost(it.type, owned - 1);
      if (this._panelOpen && this._hideInfoPanel) this._hideInfoPanel();
      this._selStruct = id; this._recycleArm = null;
      var refund = Object.keys(c).map((rid) => Math.floor(c[rid] * P.REFUND) + ' ' + NEBUSTION.Economy.RES[rid].short).join(' • ');
      this._showBar({
        title: def.name, status: def.info, statusColor: '#8ea0c8', cost: null,
        left: { label: 'DÉPLACER', color: def.color, onClick: () => { this._hideBar(); this._startPlacement(it.type, id); } },
        right: { label: 'RECYCLER  +' + refund, color: 0xff5b6e, onClick: () => this._recycleStruct(id, refund) }
      });
    },

    /** Recyclage en deux temps : un premier toucher arme le bouton (« CONFIRMER »), un second dans les 3 s recycle. */
    _recycleStruct: function (id, refundText) {
      var P = PB(), R = NEBUSTION.Resources, now = Date.now();
      if (this._recycleArm !== id || now > (this._recycleArmUntil || 0)) {
        this._recycleArm = id; this._recycleArmUntil = now + 3000;
        this._barRight.labelText.setText('CONFIRMER LE RECYCLAGE ?');
        this.time.delayedCall(3000, () => { if (this._recycleArm === id && this._barOpen && this._selStruct === id) { this._recycleArm = null; this._barRight.labelText.setText('RECYCLER  +' + refundText); } });
        return;
      }
      var box = this._structs[id], gx = box ? box.container.x : 0, gy = box ? box.container.y : 0;
      var res = P.recycle(R, id);
      if (!res.ok) return;
      this._removeAnchor(function (a) { return a.type === 'struct' && a.key === id; });
      if (box) box.container.destroy();
      delete this._structs[id];
      this.fx.ring(gx, gy - 20, 0xff5b6e, 1.6);
      this.fx.text(gx, gy - 60, 'RECYCLÉ', '#ffb0bb', 26, 60);
      this._hideBar();
    },

    // ------------------------------------------------------------------ dessin des constructions
    /** Dessine une construction autour de l'origine (pied au sol en (0,0), le haut vers -y) ; renseigne box.anim(t). */
    _drawStructure: function (container, def, box) {
      var self = this, color = def.color, id = def.id, ADD = Phaser.BlendModes.ADD, g = this.add.graphics();
      function poly(pts, fill, a) { g.fillStyle(fill, a); g.fillPoints(pts, true); }
      function box3(cx, by, hw, h, base, rows) {
        var dy = hw * 0.5, L = { x: cx - hw, y: by }, F = { x: cx, y: by + dy }, Rr = { x: cx + hw, y: by }, Bk = { x: cx, y: by - dy };
        poly([L, F, { x: F.x, y: F.y - h }, { x: L.x, y: L.y - h }], self._shade(base, 0.5), 1);
        poly([F, Rr, { x: Rr.x, y: Rr.y - h }, { x: F.x, y: F.y - h }], self._shade(base, 0.8), 1);
        var T = [{ x: L.x, y: L.y - h }, { x: F.x, y: F.y - h }, { x: Rr.x, y: Rr.y - h }, { x: Bk.x, y: Bk.y - h }];
        poly(T, self._shade(base, 1.3), 1);
        if (rows) {
          var lit = self._mixColor(color, 0xffffff, 0.4), r, v0, v1;
          var a0 = { x: F.x + (Rr.x - F.x) * 0.2, y: F.y + (Rr.y - F.y) * 0.2 }, a1 = { x: F.x + (Rr.x - F.x) * 0.8, y: F.y + (Rr.y - F.y) * 0.8 };
          for (r = 0; r < rows; r++) {
            v0 = 0.14 + r * 0.78 / rows; v1 = v0 + 0.78 / rows * 0.5;
            poly([{ x: a0.x, y: a0.y - v0 * h }, { x: a1.x, y: a1.y - v0 * h }, { x: a1.x, y: a1.y - v1 * h }, { x: a0.x, y: a0.y - v1 * h }], lit, 0.9);
          }
        }
        g.lineStyle(2, color, 0.95); g.strokePoints(T, true);
        g.lineStyle(2.4, color, 0.9); g.lineBetween(F.x, F.y, F.x, F.y - h);
        g.lineStyle(1.4, color, 0.45); g.lineBetween(L.x, L.y, L.x, L.y - h); g.lineBetween(Rr.x, Rr.y, Rr.x, Rr.y - h);
        return { top: { x: cx, y: by - h } };
      }
      function cyl(cx, by, rx, h, base) {
        var ry = rx * 0.5;
        g.fillStyle(self._shade(base, 0.62), 1); g.fillRect(cx - rx, by - h, rx * 2, h); g.fillEllipse(cx, by, rx * 2, ry * 2);
        g.fillStyle(self._shade(base, 0.9), 1); g.fillRect(cx - rx * 0.1, by - h, rx * 1.1, h);
        g.fillStyle(self._shade(base, 1.3), 1); g.fillEllipse(cx, by - h, rx * 2, ry * 2);
        g.lineStyle(2, color, 0.9); g.strokeEllipse(cx, by - h, rx * 2, ry * 2);
        g.lineStyle(1.6, color, 0.55); g.lineBetween(cx - rx, by, cx - rx, by - h); g.lineBetween(cx + rx, by, cx + rx, by - h);
        return { top: by - h };
      }

      container.add(this.add.image(0, -30, 'tex_glow_white').setTint(color).setDisplaySize(140, 110).setAlpha(0.18).setBlendMode(ADD));
      g.fillStyle(0x000000, 0.4); g.fillEllipse(6, 12, 100, 32);
      box3(0, 4, 40, 7, 0x1a2745, 0);
      var base = this._mixColor(0x2a3d66, color, 0.22), anim = null, i;

      if (id === 'beacon') {
        g.lineStyle(4, color, 0.95); g.lineBetween(0, -4, 0, -96);
        g.lineStyle(2, 0xffffff, 0.6); g.lineBetween(-6, -30, 6, -30); g.lineBetween(-5, -56, 5, -56);
        container.add(g);
        var beam = this.add.image(0, -96, 'tex_glow_white').setTint(color).setBlendMode(ADD).setOrigin(0.5, 1).setDisplaySize(46, 300).setAlpha(0.35);
        var orb = this.add.circle(0, -98, 7, 0xffffff, 1).setBlendMode(ADD);
        container.add([beam, orb]);
        anim = function (t) { var k = 0.5 + 0.5 * Math.sin(t * 0.004); beam.setAlpha(0.22 + 0.25 * k); orb.setScale(0.9 + 0.35 * k); };
      } else if (id === 'pylon') {
        box3(0, -2, 13, 56, base, 4);
        container.add(g);
        var rings = [];
        for (i = 0; i < 3; i++) {
          var rg = this.add.graphics(); rg.lineStyle(3, color, 0.9); rg.strokeEllipse(0, 0, 52 - i * 8, 18 - i * 2); rg.setPosition(0, -74 - i * 13);
          container.add(rg); rings.push(rg);
        }
        var pcore = this.add.image(0, -100, 'tex_glow_white').setTint(color).setDisplaySize(44, 44).setBlendMode(ADD);
        var pspark = this.add.circle(0, -100, 5, 0xffffff, 1).setBlendMode(ADD);
        container.add([pcore, pspark]);
        anim = function (t) {
          for (var k = 0; k < 3; k++) rings[k].setAlpha(0.3 + 0.7 * Math.max(0, Math.sin(t * 0.005 - k * 0.9)));
          pcore.setAlpha(0.6 + 0.4 * Math.sin(t * 0.006));
        };
      } else if (id === 'radar') {
        var r1 = box3(0, -2, 24, 24, base, 2);
        g.lineStyle(3, color, 0.9); g.lineBetween(0, r1.top.y, 0, r1.top.y - 22);
        container.add(g);
        var dg = this.add.graphics();
        dg.lineStyle(3, color, 0.9); dg.lineBetween(0, 0, 0, -8);
        dg.fillStyle(this._mixColor(color, 0xffffff, 0.5), 0.95); dg.fillEllipse(0, -12, 46, 18);
        dg.lineStyle(2, color, 1); dg.strokeEllipse(0, -12, 46, 18);
        dg.fillStyle(0xffffff, 1); dg.fillCircle(0, -14, 3);
        dg.setPosition(0, r1.top.y - 22); container.add(dg);
        anim = function (t) { dg.setScale(0.25 + 0.75 * Math.abs(Math.cos(t * 0.0018)), 1); };
      } else if (id === 'silo') {
        cyl(-22, -4, 15, 44, base); cyl(20, 2, 15, 38, base);
        var s3 = cyl(-2, -10, 18, 62, base);
        g.lineStyle(2, color, 0.5); g.lineBetween(-20, -40, 16, -40); g.lineBetween(-20, -26, 16, -26);
        container.add(g);
        var lamp = this.add.circle(-2, s3.top - 10, 4, color, 1).setBlendMode(ADD);
        container.add(lamp);
        anim = function (t) { lamp.setAlpha(0.35 + 0.65 * Math.abs(Math.sin(t * 0.004))); };
      } else if (id === 'dome') {
        g.fillStyle(0x0a1224, 0.9); g.fillEllipse(0, -2, 104, 40);
        g.lineStyle(2.5, color, 0.9); g.strokeEllipse(0, -2, 104, 40);
        box3(-2, -8, 9, 14, base, 1); box3(-26, 0, 11, 16, base, 1); box3(20, 2, 12, 24, base, 2);
        g.fillStyle(this._mixColor(color, 0xffffff, 0.3), 0.20); g.fillEllipse(0, -24, 100, 76);
        g.lineStyle(2.5, this._mixColor(color, 0xffffff, 0.5), 0.9); g.strokeEllipse(0, -24, 100, 76);
        g.lineStyle(1.5, color, 0.5); g.strokeEllipse(0, -24, 58, 76); g.strokeEllipse(0, -24, 20, 76);
        g.fillStyle(0xffffff, 0.35); g.fillEllipse(-24, -46, 14, 26);
        container.add(g);
        var dcore = this.add.image(0, -20, 'tex_glow_white').setTint(color).setDisplaySize(70, 56).setBlendMode(ADD);
        container.add(dcore);
        anim = function (t) { dcore.setAlpha(0.35 + 0.35 * Math.sin(t * 0.003)); };
      } else if (id === 'garden') {
        box3(0, -2, 36, 16, base, 0);
        poly([{ x: -36, y: -18 }, { x: 0, y: 0 }, { x: 36, y: -18 }, { x: 0, y: -36 }], 0x9dffb0, 0.28);
        container.add(g);
        var tg = this.add.graphics(), spots = [[-18, -20, 9], [16, -24, 9], [24, -12, 7], [-4, -30, 8], [-26, -10, 7]];
        spots.forEach(function (s) { tg.fillStyle(0x1f6b34, 1); tg.fillRect(s[0] - 1.5, s[1] - 4, 3, 8); tg.fillStyle(0x38b558, 1); tg.fillCircle(s[0], s[1] - 8, s[2]); tg.fillStyle(0x7dffa0, 0.5); tg.fillCircle(s[0] - 2, s[1] - 11, s[2] * 0.45); });
        tg.lineStyle(4, 0x1f6b34, 1); tg.lineBetween(0, -12, 0, -46);
        tg.fillStyle(0x38b558, 1); tg.fillCircle(0, -52, 12); tg.fillStyle(0x7dffa0, 0.5); tg.fillCircle(-3, -56, 6);
        tg.lineStyle(2, color, 0.9); tg.strokePoints([{ x: -36, y: -18 }, { x: 0, y: 0 }, { x: 36, y: -18 }, { x: 0, y: -36 }], true);
        container.add(tg);
        anim = function (t) { tg.setRotation(0.025 * Math.sin(t * 0.002)); };
      } else if (id === 'turret') {
        var t1 = box3(0, -2, 28, 26, this._mixColor(0x2a2f45, color, 0.2), 2), ty = t1.top.y;
        g.fillStyle(0x2b3350, 1); g.fillRect(-16, ty - 14, 32, 14); g.fillEllipse(0, ty, 32, 16);
        g.fillStyle(0x3e4a70, 1); g.fillEllipse(0, ty - 14, 32, 16);
        g.lineStyle(2, color, 0.95); g.strokeEllipse(0, ty - 14, 32, 16);
        container.add(g);
        var gun = this.add.graphics();
        gun.lineStyle(8, 0x1d2238, 1); gun.lineBetween(2, -3, 30, -16); gun.lineBetween(-3, 3, 25, -10);
        gun.lineStyle(3, color, 0.95); gun.lineBetween(2, -3, 30, -16); gun.lineBetween(-3, 3, 25, -10);
        gun.fillStyle(0xffffff, 0.9); gun.fillCircle(30, -16, 3);
        gun.setPosition(0, ty - 14); container.add(gun);
        anim = function (t) { gun.setRotation(0.32 * Math.sin(t * 0.0012) - 0.1); };
      } else if (id === 'tower') {
        var TH = 118, hwAt = function (yy) { return 22 - 16 * ((-yy - 4) / (TH - 4)); };
        var leg = [{ x: -22, y: -4 }, { x: -6, y: -TH }, { x: 6, y: -TH }, { x: 22, y: -4 }];
        poly(leg, this._shade(base, 0.75), 1);
        poly([{ x: -14, y: -9 }, { x: -3, y: -TH + 7 }, { x: 3, y: -TH + 7 }, { x: 14, y: -9 }], 0x0a1224, 0.9);
        g.lineStyle(2.6, color, 0.95); g.strokePoints(leg, true);
        var seg = 6, sy = (TH - 12) / seg, j, y0, y1, h0, h1;
        g.lineStyle(1.6, color, 0.6);
        for (j = 0; j < seg; j++) {   // croisillons en treillis
          y0 = -8 - j * sy; y1 = y0 - sy; h0 = hwAt(y0) - 3; h1 = hwAt(y1) - 3;
          g.lineBetween(-h0, y0, h1, y1); g.lineBetween(h0, y0, -h1, y1); g.lineBetween(-h1, y1, h1, y1);
        }
        g.fillStyle(0x2b3350, 1); g.fillEllipse(0, -TH, 40, 14);
        g.lineStyle(2.2, color, 0.95); g.strokeEllipse(0, -TH, 40, 14);
        g.lineStyle(3, 0xffffff, 0.85); g.lineBetween(0, -TH, 0, -TH - 26);
        container.add(g);
        var tbeam = this.add.image(0, -TH - 26, 'tex_glow_white').setTint(color).setBlendMode(ADD).setOrigin(0.5, 1).setDisplaySize(34, 260).setAlpha(0.3);
        var twaves = [], tw;
        for (i = 0; i < 3; i++) {   // ondes de relais qui s'étendent depuis le sommet
          tw = this.add.graphics(); tw.lineStyle(3, color, 0.9); tw.strokeEllipse(0, 0, 64, 24); tw.setPosition(0, -TH - 26);
          container.add(tw); twaves.push(tw);
        }
        var tlamp = this.add.circle(0, -TH - 28, 5, 0xffffff, 1).setBlendMode(ADD);
        container.add([tbeam, tlamp]);
        anim = function (t) {
          var ph;
          for (var q = 0; q < 3; q++) { ph = ((t * 0.00075) + q / 3) % 1; twaves[q].setScale(0.25 + 1.5 * ph, 0.25 + 1.5 * ph).setAlpha(0.85 * (1 - ph)); }
          tbeam.setAlpha(0.20 + 0.16 * Math.sin(t * 0.004));
          tlamp.setAlpha(0.35 + 0.65 * Math.abs(Math.sin(t * 0.005))); tlamp.setScale(0.9 + 0.3 * Math.abs(Math.sin(t * 0.005)));
        };
      } else {   // reactor
        cyl(0, 0, 30, 26, base);
        g.fillStyle(0x0a1224, 0.9); g.fillRoundedRect(-14, -80, 28, 56, 12);
        g.lineStyle(2.5, color, 0.95); g.strokeRoundedRect(-14, -80, 28, 56, 12);
        container.add(g);
        var rcore = this.add.image(0, -52, 'tex_glow_white').setTint(color).setDisplaySize(64, 64).setBlendMode(ADD);
        var rspark = this.add.circle(0, -52, 7, 0xffffff, 0.95).setBlendMode(ADD);
        var d1 = this.add.circle(0, -52, 3.5, this._mixColor(color, 0xffffff, 0.6), 1).setBlendMode(ADD);
        var d2 = this.add.circle(0, -52, 3.5, this._mixColor(color, 0xffffff, 0.6), 1).setBlendMode(ADD);
        container.add([rcore, rspark, d1, d2]);
        anim = function (t) {
          var a = t * 0.004;
          d1.setPosition(Math.cos(a) * 30, -52 + Math.sin(a) * 11); d2.setPosition(Math.cos(a + Math.PI) * 30, -52 + Math.sin(a + Math.PI) * 11);
          rcore.setAlpha(0.55 + 0.4 * Math.sin(t * 0.007)); rspark.setScale(0.8 + 0.4 * Math.sin(t * 0.009));
        };
      }
      if (box) box.anim = anim;
    }
  });
})();
