/**
 * NEBUSTION - ModsScene
 * Écran « 🧩 Mods et plugins » (ouvert depuis le panneau ⚙ Paramètres) : liste les mods fournis
 * avec le jeu (voir mods/manifest.js -> NEBUSTION.ModsCatalog) et un interrupteur par mod.
 * Activer/désactiver un mod joue une petite animation « installation… » (spinner + barre de
 * progression, purement visuelle) puis enregistre le choix dans localStorage via
 * NEBUSTION.ModsCatalog.setPref(). Les mods se chargent au tout début du jeu (voir index.html),
 * donc un changement ne prend effet qu'au prochain lancement : un bouton « Recharger le jeu »
 * en bas de l'écran applique le changement immédiatement.
 *
 * Liste déroulante : même principe qu'en Boutique/Héros (voir ShopScene.js, HeroesScene.js) —
 * UNE seule zone gère le glissement ET le tap, les interrupteurs ne sont donc pas des objets
 * interactifs individuels mais des zones de tap testées manuellement au relâchement, pour ne
 * jamais entrer en conflit avec le défilement (molette PC comprise).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.ModsScene = class ModsScene extends Phaser.Scene {
  constructor() { super('ModsScene'); }

  init(data) {
    this.returnTo = (data && data.returnTo) || 'PlanetScene';
    this.busy = false;
    this.scrollY = 0;
    this.maxScroll = 0;
    this._cards = [];
  }

  create() {
    var self = this, w = this.scale.width, h = this.scale.height;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(250, 5, 7, 15);
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });
    this.fx = new NEBUSTION.FX(this);
    this.hud = NEBUSTION.HUD.attach(this);

    this._txt(w / 2, 128, 'MODS & PLUGINS', 26, '#eaf2ff', { fontStyle: '900' })
      .setOrigin(0.5).setDepth(50).setShadow(0, 0, '#7a2cff', 12, true, true);
    this._txt(w / 2, 162, 'Active ou désactive les extensions du jeu', 14, '#8e9cc0')
      .setOrigin(0.5).setDepth(50);

    // ---------- Zone déroulante (masquée) : liste des mods ----------
    this.listTop = 210;
    this.listBottom = h - 92;   // juste au-dessus des boutons Retour / Recharger
    this.rows = this.add.container(0, this.listTop).setDepth(50);
    this.listMaskGfx = this.make.graphics();
    this.rows.setMask(this.listMaskGfx.createGeometryMask());

    this._buildScroll();
    this._buildRows();

    var backBtn = new NEBUSTION.Button(this, 96, h - 64, {
      width: 148, height: 52, label: '← Retour', accentColor: 0x394869, fontSize: '17px',
      onClick: function () { if (!self.busy) self._close(); }
    });
    backBtn.setDepth(60);

    this.reloadBtn = new NEBUSTION.Button(this, w - 130, h - 64, {
      width: 216, height: 52, label: '🔄 Recharger le jeu', accentColor: 0xff8a3c, fontSize: '15px',
      onClick: function () { if (!self.busy) window.location.reload(); }
    });
    this.reloadBtn.setDepth(60);

    this._buildOverlay();
  }

  _txt(x, y, str, size, color, extra) {
    var st = { fontFamily: 'Arial, sans-serif', fontSize: size + 'px', color: color || '#eaf2ff', resolution: 2 };
    if (extra) Object.keys(extra).forEach(function (k) { st[k] = extra[k]; });
    return this.add.text(x, y, str, st);
  }

  // ---------- Défilement (glissement + molette PC) ----------
  _buildScroll() {
    var self = this, w = this.scale.width, viewH = this.listBottom - this.listTop;
    this.listMaskGfx.clear();
    this.listMaskGfx.fillStyle(0xffffff, 1);
    this.listMaskGfx.fillRect(0, this.listTop, w, viewH);

    var dragging = false, startY = 0, startScroll = 0, moved = 0;
    var zone = this.add.zone(0, this.listTop, w, viewH).setOrigin(0).setInteractive().setDepth(55);
    zone.on('pointerdown', function (p) {
      if (self.busy) return;
      dragging = true; startY = p.y; startScroll = self.scrollY || 0; moved = 0;
    });
    this.input.on('pointermove', function (p) {
      if (!dragging || self.busy) return;
      var dy = p.y - startY;
      moved = Math.max(moved, Math.abs(dy));
      self.scrollY = Phaser.Math.Clamp(startScroll - dy, 0, self.maxScroll || 0);
      self.rows.y = self.listTop - self.scrollY;
    });
    zone.on('pointerup', function (p) {
      var wasTap = dragging && moved <= 14;
      dragging = false;
      if (wasTap && !self.busy) self._onListTap(p.x, p.y);
    });
    this.input.on('pointerup', function () { dragging = false; });
    this.input.on('pointerupoutside', function () { dragging = false; });
    // Molette (PC)
    this.input.on('wheel', function (p, objs, dx, dy) {
      if (self.busy) return;
      self.scrollY = Phaser.Math.Clamp((self.scrollY || 0) + (dy || 0), 0, self.maxScroll || 0);
      self.rows.y = self.listTop - self.scrollY;
    });
  }

  /** Teste un tap contre les zones interactives déclarées par chaque carte (card._hits). */
  _onListTap(px, py) {
    var ly = py - this.rows.y;
    var cards = this._cards || [];
    for (var i = 0; i < cards.length; i++) {
      var c = cards[i], hits = c._hits || [];
      var lx = px - c.x;
      for (var j = 0; j < hits.length; j++) {
        var hit = hits[j];
        if (lx >= hit.x && lx <= hit.x + hit.w && (ly - c.y) >= hit.y && (ly - c.y) <= hit.y + hit.h) {
          hit.fn();
          return true;
        }
      }
    }
    return false;
  }

  // ---------- Liste des mods ----------
  _buildRows() {
    var self = this, w = this.scale.width, CAT = NEBUSTION.ModsCatalog;
    this.rows.removeAll(true);
    this._cards = [];
    var cardW = w - 64, cardX = w / 2, y = 8, cardH = 122, gap = 14;

    (CAT ? CAT.AVAILABLE : []).forEach(function (item) {
      var enabled = CAT.isEnabled(item);
      var card = self.add.container(cardX, y + cardH / 2);

      var bg = self.add.graphics();
      self._drawCard(bg, cardW, cardH, enabled);
      card.add(bg);

      card.add(self._txt(-cardW / 2 + 18, -cardH / 2 + 24, item.name, 16, '#eaf2ff', { fontStyle: 'bold' }).setOrigin(0, 0.5));
      card.add(self._txt(-cardW / 2 + 18, -cardH / 2 + 54, item.desc, 12, '#8e9cc0', {
        wordWrap: { width: cardW - 110 }, lineSpacing: 3
      }).setOrigin(0, 0));

      var statusTxt = self._txt(-cardW / 2 + 18, cardH / 2 - 16,
        enabled ? '● Actif' : '○ Inactif', 12, enabled ? '#7dffb0' : '#6b7aa0', { fontStyle: 'bold' }).setOrigin(0, 0.5);
      card.add(statusTxt);

      var toggleX = cardW / 2 - 34, toggleY = -cardH / 2 + 24;
      var toggle = self._makeToggleVisual(card, toggleX, toggleY);
      self._drawToggle(toggle, enabled);

      // Zone de tap manuelle (élargie autour du switch, cf. _onListTap) : évite tout conflit
      // avec la zone de glissement qui couvre toute la liste.
      card._hits = [{
        x: toggleX - 30, y: toggleY - 20, w: 60, h: 40,
        fn: function () { self._toggleMod(item, toggle, bg, statusTxt, cardW, cardH); }
      }];

      self.rows.add(card);
      self._cards.push(card);
      y += cardH + gap;
    });

    if (!CAT || !CAT.AVAILABLE || !CAT.AVAILABLE.length) {
      this.rows.add(this._txt(w / 2, y + 30, 'Aucun mod disponible pour le moment.', 14, '#8e9cc0').setOrigin(0.5));
      y += 60;
    }

    var viewH = this.listBottom - this.listTop;
    this.maxScroll = Math.max(0, y - viewH + 8);
    this.scrollY = Math.min(this.scrollY || 0, this.maxScroll);
    this.rows.y = this.listTop - this.scrollY;
  }

  _drawCard(g, cw, ch, enabled) {
    g.clear();
    g.fillStyle(0x101a33, 1);
    g.fillRoundedRect(-cw / 2, -ch / 2, cw, ch, 14);
    g.lineStyle(1.5, enabled ? 0x2fbf6a : 0x394869, 0.9);
    g.strokeRoundedRect(-cw / 2, -ch / 2, cw, ch, 14);
  }

  // ---------- Interrupteur (purement visuel : le tap est géré par card._hits + _onListTap) ----------
  _makeToggleVisual(parent, x, y) {
    var s = this, track = s.add.graphics(), pill = s.add.container(x, y), knob = s.add.circle(0, 0, 10, 0xffffff, 1);
    pill.add([track, knob]);
    parent.add(pill);
    return { pill: pill, track: track, knob: knob };
  }

  _drawToggle(t, on) {
    var w = 44, h = 22;
    t.track.clear();
    t.track.fillStyle(on ? 0x2ee6a6 : 0x2a3557, 1);
    t.track.fillRoundedRect(-w / 2, -h / 2, w, h, h / 2);
    var tx = on ? (w / 2 - h / 2) : -(w / 2 - h / 2);
    this.tweens.add({ targets: t.knob, x: tx, duration: 140, ease: 'Sine.easeOut' });
  }

  // ---------- Activation / désactivation avec animation d'installation ----------
  _toggleMod(item, toggle, cardBg, statusTxt, cardW, cardH) {
    if (this.busy) return;
    var self = this, CAT = NEBUSTION.ModsCatalog;
    var willEnable = !CAT.isEnabled(item);
    this._runInstallAnim(item.name, willEnable, function () {
      CAT.setPref(item.file, willEnable);
      self._drawToggle(toggle, willEnable);
      self._drawCard(cardBg, cardW, cardH, willEnable);
      statusTxt.setText(willEnable ? '● Actif' : '○ Inactif');
      statusTxt.setColor(willEnable ? '#7dffb0' : '#6b7aa0');
      self.fx.toast(
        willEnable ? (item.name + ' installé ✅') : (item.name + ' désinstallé'),
        'Touchez « Recharger le jeu » pour appliquer',
        null
      );
    });
  }

  // ---------- Overlay plein écran : spinner + barre de progression ----------
  _buildOverlay() {
    var w = this.scale.width, h = this.scale.height;
    var ov = this.add.container(0, 0).setDepth(999).setVisible(false).setAlpha(0);
    ov.add(this.add.rectangle(w / 2, h / 2, w, h, 0x03050c, 0.82).setInteractive());

    var ring = this.add.graphics();
    ring.lineStyle(5, 0x00e5ff, 1);
    ring.beginPath(); ring.arc(0, 0, 34, Phaser.Math.DegToRad(-90), Phaser.Math.DegToRad(140));
    ring.strokePath();
    ring.setPosition(w / 2, h / 2 - 70);
    ov.add(ring);

    var label = this._txt(w / 2, h / 2 + 4, '', 17, '#eaf2ff', { fontStyle: 'bold', align: 'center', wordWrap: { width: w - 140 } }).setOrigin(0.5);
    ov.add(label);

    var barW = 240, barH = 10;
    var barBg = this.add.graphics();
    barBg.fillStyle(0x1c2b4a, 1); barBg.fillRoundedRect(w / 2 - barW / 2, h / 2 + 42, barW, barH, barH / 2);
    ov.add(barBg);
    var barFill = this.add.graphics();
    ov.add(barFill);

    this.overlay = { container: ov, ring: ring, label: label, barFill: barFill, barW: barW, barH: barH, barX: w / 2 - barW / 2, barY: h / 2 + 42 };
  }

  /** Anime une fausse installation/désinstallation pendant ~1.3 s puis appelle onDone(). */
  _runInstallAnim(modName, installing, onDone) {
    var self = this, ov = this.overlay, DURATION = 1300;
    this.busy = true;
    ov.label.setText((installing ? 'Installation de ' : 'Désinstallation de ') + modName + '\u2026');
    ov.barFill.clear();
    ov.container.setVisible(true);
    this.tweens.add({ targets: ov.container, alpha: 1, duration: 140, ease: 'Sine.easeOut' });

    this._spinTween = this.tweens.add({
      targets: ov.ring, rotation: Math.PI * 2, duration: 900, repeat: -1, ease: 'Linear'
    });

    var progress = { v: 0 };
    this.tweens.add({
      targets: progress, v: 1, duration: DURATION, ease: 'Sine.easeInOut',
      onUpdate: function () {
        ov.barFill.clear();
        ov.barFill.fillStyle(0x00e5ff, 1);
        var fw = Math.max(ov.barH, ov.barW * progress.v);
        ov.barFill.fillRoundedRect(ov.barX, ov.barY, fw, ov.barH, ov.barH / 2);
      },
      onComplete: function () {
        if (self._spinTween) { self._spinTween.stop(); self._spinTween = null; }
        self.tweens.add({
          targets: ov.container, alpha: 0, duration: 160, ease: 'Sine.easeIn', delay: 120,
          onComplete: function () { ov.container.setVisible(false); self.busy = false; onDone(); }
        });
      }
    });
  }

  // ---------- Fermeture ----------
  _close() {
    var self = this;
    this.cameras.main.fadeOut(200, 5, 7, 15);
    this.cameras.main.once('camerafadeoutcomplete', function () { self.scene.start(self.returnTo); });
  }
};
