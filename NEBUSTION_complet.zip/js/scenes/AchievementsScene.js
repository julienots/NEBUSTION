/**
 * NEBUSTION - AchievementsScene (étape 10)
 * Onglet « Quotidien » : calendrier 7 jours en boucle, réclamation. Onglet « Succès » :
 * progression permanente (paliers bronze/argent/or). Onglet « Long terme » : mêmes paliers,
 * objectifs à horizon de plusieurs jours/semaines.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.AchievementsScene = class AchievementsScene extends NEBUSTION.ProgressScene {
  constructor() { super('AchievementsScene'); }

  _hubKey() { return 'achievements'; }
  _titleText() { return 'SUCCÈS'; }
  _accent() { return 0x5fd97a; }
  _accentHex() { return '#5fd97a'; }
  _defaultTab() { return 'daily'; }
  _tabDefs() { return [{ id: 'daily', label: 'Quotidien' }, { id: 'achv', label: 'Succès' }, { id: 'goals', label: 'Long terme' }]; }

  _badgeContent(c) {
    var AM = NEBUSTION.AchievementsManager;
    var n = AM.claimableCount() + (AM.dailyStatus().available ? 1 : 0);
    this._badgePill(c, 'xp', String(n), this._accent(), this._accentHex());
  }

  _renderTab(w) {
    if (this.tab === 'achv') return this._renderList(w, 'succes');
    if (this.tab === 'goals') return this._renderList(w, 'longterme');
    return this._renderDaily(w);
  }

  // ================= Onglet Quotidien =================
  _renderDaily(w) {
    var self = this, AM = NEBUSTION.AchievementsManager, cards = [];
    var st = AM.dailyStatus();

    var head = this._card(120, this._accent(), { glow: st.available });
    head.add(this._txt(24, 24, 'Série actuelle : ' + st.streak + ' jour' + (st.streak > 1 ? 's' : ''), 19, '#eaf2ff', { fontStyle: 'bold' }));
    head.add(this._txt(24, 52, 'Record : ' + st.bestStreak + ' jours', 14, '#a9b8dc'));
    if (st.available) {
      this._btn(head, head._cw - 130, 78, 190, 44, 'RÉCLAMER JOUR ' + st.nextStreak, 0x5fd97a, false, function () { self._claimDaily(); });
    } else {
      head.add(this._txt(24, 90, 'Revenez demain pour la prochaine récompense.', 14, '#8e9cc0'));
    }
    cards.push(head);

    var cal = this._card(150, this._accent(), { dim: true });
    cal.add(this._txt(24, 20, 'Calendrier (7 jours, en boucle)', 14, '#8e9cc0', { fontStyle: 'bold' }));
    var n = 7, gap = 8, cw2 = cal._cw - 48, cell = (cw2 - gap * (n - 1)) / n;
    for (var i = 1; i <= n; i++) {
      var x = 24 + (i - 1) * (cell + gap);
      var done = i <= st.doneInCycle;
      var isNext = st.available && i === st.cycleDay;
      var g = this.add.graphics();
      g.fillStyle(done ? 0x1a3a24 : (isNext ? 0x2a2008 : 0x121a30), 1);
      g.fillRoundedRect(x, 48, cell, cell + 30, 10);
      g.lineStyle(2, done ? 0x5fd97a : (isNext ? 0xffd166 : 0x2b3a5c), done || isNext ? 1 : 0.6);
      g.strokeRoundedRect(x, 48, cell, cell + 30, 10);
      cal.add(g);
      cal.add(this._txt(x + cell / 2, 62, 'J' + i, 12, '#8e9cc0', { fontStyle: 'bold' }).setOrigin(0.5));
      var rw = NEBUSTION.Achievements.dailyReward(i);
      var items = this._rewardItems(rw);
      if (rw.gem) { var gi = this.add.graphics(); this._drawGem(gi, x + cell / 2, 48 + cell / 2 + 6, 12, 0xe6c6ff); cal.add(gi); }
      else if (items[0]) { this._iconNode(cal, items[0].kind, x + cell / 2, 48 + cell / 2 + 6, 26, null); }
      if (done) { var ck = this.add.graphics(); this._drawCheck(ck, x + cell - 12, 58, 0.7, 0x5fd97a); cal.add(ck); }
    }
    cards.push(cal);
    return { cards: cards, footer: null };
  }

  _claimDaily() {
    var self = this, AM = NEBUSTION.AchievementsManager, r = AM.claimDaily();
    if (!r.ok) { this._refreshAll(false); return; }
    var rows = this._rewardItems({ res: r.granted, gem: r.granted.gems });
    this._reveal('RÉCOMPENSE QUOTIDIENNE', 'Jour ' + r.streak, rows, null, this._accent(), function () { self._refreshAll(false); });
  }

  // ================= Onglets Succès / Long terme =================
  _renderList(w, category) {
    var self = this, AM = NEBUSTION.AchievementsManager, cards = [];
    AM.list(category).forEach(function (a) {
      var h = 168, card = self._card(h, a.maxed ? 0xffd166 : self._accent(), { dim: a.maxed && !a.claimable });
      card.add(self._txt(24, 22, a.name, 18, '#eaf2ff', { fontStyle: 'bold' }));
      var tierLabel = a.claimed < a.tiers.length ? NEBUSTION.Achievements.TIERS[Math.min(a.claimed, 2)].toUpperCase() : 'TERMINÉ';
      self._chip(card, 24, 48, tierLabel, NEBUSTION.Achievements.TIER_COLOR[NEBUSTION.Achievements.TIERS[Math.min(a.claimed, 2)]] || 0xffd166, 12);
      var target = a.nextTarget != null ? a.nextTarget : a.tiers[a.tiers.length - 1];
      var prevTarget = a.claimed > 0 ? a.tiers[a.claimed - 1] : 0;
      var frac = target > prevTarget ? Math.max(0, Math.min(1, (a.value - prevTarget) / (target - prevTarget))) : 1;
      self._bar(card, 24, 82, card._cw - 48, 12, frac, a.maxed ? 0xffd166 : self._accent());
      card.add(self._txt(24, 104, self._fmt(a.value) + ' / ' + self._fmt(target) + ' ' + a.unit, 13, '#a9b8dc'));
      var tierDots = 'Paliers : ';
      for (var i = 0; i < a.tiers.length; i++) tierDots += (i < a.claimed ? '★' : (i < a.reached ? '☆' : '·')) + ' ';
      card.add(self._txt(24, 126, tierDots + '(' + a.tiers.join(' / ') + ')', 12, '#6d7c9c'));
      if (a.claimable) {
        var rw = a.rewards[a.claimed];
        var items = self._rewardItems({ res: rw, gem: rw.gem });
        self._rewardRow(card, 24, 148, items, 18, { font: 13 });
        self._btn(card, card._cw - 96, 80, 150, 44, 'RÉCLAMER', 0x5fd97a, false, function () { self._claim(a.id); });
      } else if (a.maxed) {
        self._btn(card, card._cw - 96, 80, 150, 44, 'TERMINÉ', 0xffd166, true, null, null);
      } else {
        self._btn(card, card._cw - 96, 80, 150, 44, 'EN COURS', 0x394869, true, null, 'Continuez à progresser.');
      }
      cards.push(card);
    });
    return { cards: cards, footer: null };
  }
  _claim(id) {
    var self = this, AM = NEBUSTION.AchievementsManager, r = AM.claim(id);
    if (!r.ok) { this._refreshAll(false); return; }
    var rows = this._rewardItems({ res: r.reward, gem: r.reward.gem });
    this._reveal('SUCCÈS ' + (r.tierName || '').toUpperCase(), NEBUSTION.Achievements.get(id).name, rows, null, this._accent(), function () { self._refreshAll(false); });
  }
};
