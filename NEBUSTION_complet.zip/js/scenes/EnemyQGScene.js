/**
 * NEBUSTION - EnemyQGScene
 * QG d'un empire ennemi, présenté comme le QG d'un JOUEUR adverse (pseudo, niveau, vraie base isométrique
 * avec ses structures) : on peut le visiter, l'observer, puis l'attaquer avec la flotte de vaisseaux.
 *
 * Réutilise le rendu 2.5D de QGScene (hérite de ses méthodes de dessin/pan). Le contenu de la base vient de
 * NEBUSTION.BotBases (déduit de l'état réel de l'empire). L'ISSUE de l'attaque est tirée par
 * NEBUSTION.QGAttackManager.attack() (butin, recharge, traumatisme de l'empire : effets réels) ; la scène
 * ne fait que la mettre en scène (vaisseaux, tirs, explosions). Les structures « détruites » à l'écran sont
 * un effet visuel de la visite : ce qui persiste, c'est le traumatisme de l'empire, qui réduit ses tourelles
 * la prochaine fois que tu reviens.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.EnemyQGScene = class EnemyQGScene extends NEBUSTION.QGScene {
  constructor() { super('EnemyQGScene'); }

  init(data) { this._initData = data || {}; }

  create(data) {
    var w = this.scale.width;
    var eid = (data && data.eid) || (this._initData && this._initData.eid);
    var variant = (data && data.variant) || (this._initData && this._initData.variant) || 0;
    var Gal = NEBUSTION.Galaxy, EM = NEBUSTION.EmpireEvolutionManager, BB = NEBUSTION.BotBases;
    if (!eid || !Gal || !Gal.empire(eid) || !EM || !BB || !NEBUSTION.QGAttackManager) { this.scene.start('QGScene'); return; }

    this.eid = eid;
    this.variant = variant;
    this.E = Gal.empire(eid);
    this._es = EM.state(Date.now()).e[eid];
    this.bot = { profile: BB.profile(eid, this._es.evo), layout: BB.layout(eid, this._es.evo, this._es.hurt || 0, variant) };
    this.destroyed = {};
    this._busy = false;
    this._showPlus = false;

    this.G = NEBUSTION.QGGrid;
    var self = this;
    // Adaptateur : QGScene lit la base via GM.isUnlocked / GM.structureAt, ici celles du bot.
    this.GM = {
      isUnlocked: function (x, y) { return !!self.bot.layout.unlocked[self.G.key(x, y)]; },
      structureAt: function (x, y) { var k = self.G.key(x, y); return self.destroyed[k] ? null : (self.bot.layout.cells[k] || null); }
    };

    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(250, 5, 7, 15);
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });

    this._initIsoGeometry(this.E.color);
    this.viewport = { x: w * 0.055, y: 236, w: w - w * 0.11, h: 610 };

    this._buildCellTextures();
    this._buildShipTexture();
    this.fx = new NEBUSTION.FX(this);

    this._buildEnemyHeader();
    this._buildEnemyInfo();
    this._buildGridLayer();
    this._buildPanTarget();
    this._buildActionCard();

    this.add.text(w / 2, this.viewport.y + this.viewport.h + 20, '↔ Glisse pour inspecter sa base ↕', {
      fontFamily: 'Arial, sans-serif', fontSize: '14px', color: '#5c6b8a'
    }).setOrigin(0.5).setDepth(50);

    this._refreshGrid();
    this.hud = NEBUSTION.HUD.attach(this);
    this.events.once('shutdown', () => { this._teardownPan(); });
  }

  // ---------- En-tête : identité du « joueur » ----------
  _buildEnemyHeader() {
    var w = this.scale.width, E = this.E, p = this.bot.profile;
    this.add.text(w / 2, 96, 'QG · ' + p.handle, {
      fontFamily: 'Arial, sans-serif', fontSize: '24px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(50).setShadow(0, 0, E.hex, 10, true, true);
    this.add.text(w / 2, 126, E.name + ' · ' + p.rank + ' niv. ' + p.level, {
      fontFamily: 'Arial, sans-serif', fontSize: '15px', fontStyle: 'bold', color: E.hex
    }).setOrigin(0.5).setDepth(50);

    var back = this.add.text(28, 126, '‹ Retour', {
      fontFamily: 'Arial, sans-serif', fontSize: '16px', color: '#00e5ff'
    }).setOrigin(0, 0.5).setDepth(60).setInteractive({ useHandCursor: true });
    back.on('pointerdown', () => { if (!this._busy) this.scene.start('QGScene'); });
  }

  _buildEnemyInfo() {
    var w = this.scale.width, y = 174;
    var st = { fontFamily: 'Arial, sans-serif', fontSize: '15px', fontStyle: 'bold', color: '#eaf2ff' };
    this._defChip = this.add.text(w * 0.055, y, '', st).setOrigin(0, 0.5).setDepth(50);
    this._atkChip = this.add.text(w / 2, y, '', st).setOrigin(0.5, 0.5).setDepth(50);
    this._pctChip = this.add.text(w * 0.945, y, '', st).setOrigin(1, 0.5).setDepth(50);
    this._compText = this.add.text(w / 2, 204, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#8ea0c8'
    }).setOrigin(0.5).setDepth(50);
  }

  // Remplace la barre de bonus du QG joueur : défense de l'ennemi, puissance de ta flotte, chance de victoire.
  _refreshInfoBar() {
    if (!this._defChip) return;
    var QA = NEBUSTION.QGAttack, SH = NEBUSTION.ShipManager, es = this._es, BB = NEBUSTION.BotBases;
    var atk = QA.attackPower(SH ? SH.fleetPower() : 0), def = QA.defensePower(es.evo, es.hurt || 0);
    var pct = Math.round(QA.victoryChance(atk, def) * 100);
    this._defChip.setText('🛡️ Défense ' + Math.round(def));
    this._atkChip.setText('⚔ Ta flotte ' + Math.round(atk));
    this._pctChip.setText('🎯 ' + pct + ' %').setColor(pct >= 50 ? '#5fd97a' : '#ff8fa3');
    var c = BB.structureCounts(this.bot.layout, this.destroyed);
    this._compText.setText('🗼 ' + c.turret + ' tourelles · 🔋 ' + c.generator + ' générateurs · 🛢️ ' + c.silo + ' silos · Traumatisme ' + Math.round((es.hurt || 0) * 100) + ' %');
    this._refreshActionCard();
  }

  // ---------- Carte joueur + bouton d'attaque ----------
  _buildActionCard() {
    var w = this.scale.width, E = this.E, p = this.bot.profile;
    var ch = 340, top = this.viewport.y + this.viewport.h + 44;
    var card = this.add.container(w / 2, top + ch / 2).setDepth(50);
    var cw = w * 0.9;
    var bg = this.add.graphics();
    bg.fillGradientStyle(0x101a33, 0x101a33, 0x0a1020, 0x0a1020, 0.96);
    bg.fillRoundedRect(-cw / 2, -ch / 2, cw, ch, 20);
    bg.lineStyle(2, E.color, 0.7);
    bg.strokeRoundedRect(-cw / 2, -ch / 2, cw, ch, 20);
    card.add(bg);

    // avatar du « joueur »
    var av = this.add.graphics();
    av.fillStyle(E.color, 0.22); av.fillCircle(-cw / 2 + 56, -ch / 2 + 56, 34);
    av.lineStyle(3, E.color, 0.95); av.strokeCircle(-cw / 2 + 56, -ch / 2 + 56, 34);
    card.add(av);
    card.add(this.add.text(-cw / 2 + 56, -ch / 2 + 56, p.handle.charAt(0).toUpperCase(), {
      fontFamily: 'Arial, sans-serif', fontSize: '32px', fontStyle: '900', color: E.hex
    }).setOrigin(0.5));
    card.add(this.add.text(-cw / 2 + 108, -ch / 2 + 40, p.handle, {
      fontFamily: 'Arial, sans-serif', fontSize: '24px', fontStyle: 'bold', color: '#eaf2ff'
    }).setOrigin(0, 0.5));
    card.add(this.add.text(-cw / 2 + 108, -ch / 2 + 70, p.rank + ' · niv. ' + p.level + ' · QG niv. ' + p.qgLevel + ' · ' + E.name, {
      fontFamily: 'Arial, sans-serif', fontSize: '14px', color: '#8ea0c8'
    }).setOrigin(0, 0.5));

    this._cardStatus = this.add.text(0, -ch / 2 + 118, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '14px', fontStyle: 'bold', color: '#8ea0c8', align: 'center', wordWrap: { width: cw * 0.9 }
    }).setOrigin(0.5);
    card.add(this._cardStatus);

    this._atkBtn = new NEBUSTION.Button(this, 0, ch / 2 - 140, {
      width: cw * 0.9, height: 64, label: ' ', accentColor: 0xff6b6b, fontSize: '20px',
      onClick: () => this._onAttackPressed()
    });
    card.add(this._atkBtn);

    // Module 18 : MODE COMBAT — déploie tes troupes (Caserne) autour de sa base, façon Clash of Clans.
    var combatBtn = new NEBUSTION.Button(this, 0, ch / 2 - 62, {
      width: cw * 0.9, height: 64, label: '🪖 MODE COMBAT · DÉPLOYER MES TROUPES', accentColor: 0xffd166, fontSize: '16px',
      onClick: () => { if (!this._busy && NEBUSTION.QGBattleScene) this.scene.start('QGBattleScene', { eid: this.eid, variant: this.variant }); }
    });
    card.add(combatBtn);
    this._card = card;
  }

  _refreshActionCard() {
    if (!this._atkBtn) return;
    var AM = NEBUSTION.QGAttackManager, now = Date.now();
    var can = AM.canAttack(this.eid, now), label, status = '', disabled = true, look = 0x5c6b8a;
    if (this._busy) { label = 'COMBAT EN COURS…'; status = 'Ta flotte engage le QG.'; }
    else if (can.ok) { label = '⚔ ATTAQUER ' + this.bot.profile.handle.toUpperCase(); disabled = false; look = 0xff6b6b; status = 'Détruis ses tourelles pour piller ses réserves.'; }
    else if (can.reason === 'recharge') { label = 'RECHARGE ' + (this._timeLeft(AM.cooldownRemaining(this.eid, now)) || ''); status = 'Tu as déjà attaqué ce commandant récemment.'; }
    else if (can.reason === 'flotte_vide') { label = 'FLOTTE VIDE'; status = 'Assemble des vaisseaux (onglet Vaisseaux) avant d\'attaquer.'; }
    else if (can.reason === 'vaincu') { label = 'EMPIRE VAINCU'; status = 'Ce commandant n\'a plus aucune planète.'; }
    else { label = 'INDISPONIBLE'; }
    if (this._atkBtn.labelText) this._atkBtn.labelText.setText(label);
    this._atkBtn.setLook(look, '#eaf2ff');
    this._atkBtn.setDisabled(disabled);
    this._cardStatus.setText(status);
  }

  // ---------- Cases : les parcelles détruites brûlent ----------
  _buildCellNode(col, row, animate) {
    var c = super._buildCellNode(col, row, animate);
    if (this.destroyed && this.destroyed[this.G.key(col, row)]) {
      var fire = this.add.image(0, -8, 'tex_glow_white').setDisplaySize(96, 64).setTint(0xff8a3d)
        .setAlpha(0.75).setBlendMode(Phaser.BlendModes.ADD);
      c.add(fire);
      c.add(this.add.text(0, -10, '🔥', { fontSize: '32px' }).setOrigin(0.5));
      this._trackTween(c, this.tweens.add({ targets: fire, alpha: 0.25, scaleX: fire.scaleX * 0.8, duration: 380 + Math.random() * 300, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' }));
    }
    return c;
  }

  // Tap sur une structure : indice sur son rôle (pas de panneau de construction ici).
  _openPanel(col, row) {
    if (this._busy) return;
    var sid = this.GM.structureAt(col, row);
    if (!sid) return;
    var def = this.G.STRUCTURES[sid];
    var role = { generator: 'Alimente sa production.', silo: 'Stocke ses ressources (butin).', turret: 'Défense : cible prioritaire.' };
    this.fx.toast(def.icon + ' ' + def.name, role[sid] || '');
  }

  // ---------- Attaque ----------
  _onAttackPressed() {
    if (this._busy) return;
    var res = NEBUSTION.QGAttackManager.attack(this.eid, Date.now());
    if (!res.ok) { this.fx.shake(100, 0.003); this._refreshInfoBar(); return; }
    this._playBattle(res.result);
  }

  _buildShipTexture() {
    this._genTex('qgiso_ship', 64, 64, function (g) {
      g.fillStyle(0x6f81a5, 1); g.fillTriangle(32, 60, 4, 16, 60, 16);
      g.fillStyle(0xdfe8ff, 1); g.fillTriangle(32, 52, 16, 18, 48, 18);
      g.fillStyle(0x2a3550, 1); g.fillTriangle(32, 38, 26, 22, 38, 22);
      g.lineStyle(2, 0xffffff, 0.8); g.strokeTriangle(32, 60, 4, 16, 60, 16);
    });
  }

  _sfx(name) { try { if (window.nebustionPlaySfx) window.nebustionPlaySfx(name, { volume: 0.45 }); } catch (e) { /* ignore */ } }
  _after(ms, fn) { return this.time.delayedCall(ms, fn); }

  // Position écran du centre (un peu au-dessus du sol) d'une parcelle.
  _screenOf(key) {
    var k = this.G.parseKey(key), p = this._tilePos(k.x, k.y);
    return { x: this.gridLayer.x + p.x, y: this.gridLayer.y + p.y - 50 };
  }

  _baseFocus() {
    var keys = Object.keys(this.bot.layout.cells), G = this.G, sx = 0, sy = 0;
    if (!keys.length) keys = Object.keys(this.bot.layout.unlocked);
    keys.forEach((k) => { var q = G.parseKey(k), p = this._tilePos(q.x, q.y); sx += p.x; sy += p.y; });
    return { x: sx / Math.max(1, keys.length), y: sy / Math.max(1, keys.length) - 30 };
  }

  _ensureFxLayer() {
    if (this._fxLayer) return this._fxLayer;
    var v = this.viewport;
    var m = this.make.graphics({ x: 0, y: 0, add: false });
    m.fillStyle(0xffffff);
    m.fillRoundedRect(v.x, v.y, v.w, v.h, 18);
    this._fxLayer = this.add.container(0, 0).setDepth(45);
    this._fxLayer.setMask(m.createGeometryMask());
    return this._fxLayer;
  }

  _playBattle(result) {
    this._busy = true;
    this._refreshActionCard();
    var v = this.viewport;
    var plan = NEBUSTION.BotBases.battlePlan(this.bot.layout, result.victory, (Date.now() ^ 0x5bd1e995) >>> 0);
    var f = this._baseFocus();
    var tx = this._clampAxis(v.x + v.w / 2 - f.x, this.contentW, v.x, v.w);
    var ty = this._clampAxis(v.y + v.h / 2 - f.y, this.contentH, v.y, v.h);
    this.tweens.add({
      targets: this.gridLayer, x: tx, y: ty, duration: 450, ease: 'Sine.easeInOut',
      onComplete: () => this._battleStart(result, plan)
    });
  }

  _spawnFleet() {
    var v = this.viewport, SH = NEBUSTION.ShipManager, layer = this._ensureFxLayer();
    var uids = SH ? SH.getFleet() : [], n = Math.max(1, Math.min(3, uids.length)), ships = [];
    var RAR = NEBUSTION.Ships ? NEBUSTION.Ships.RARITIES : {};
    for (var i = 0; i < n; i++) {
      var sh = uids[i] && SH ? SH.get(uids[i]) : null;
      var color = (sh && RAR[sh.rarity] && RAR[sh.rarity].color) || 0x9aa5c0;
      var hx = v.x + v.w / 2 + (i - (n - 1) / 2) * 120, hy = v.y + 92 + (i % 2) * 26;
      var c = this.add.container(hx, v.y - 50);
      var flame = this.add.image(0, -30, 'tex_glow_white').setDisplaySize(46, 46).setTint(0x54c8ff).setAlpha(0.8).setBlendMode(Phaser.BlendModes.ADD);
      var img = this.add.image(0, 0, 'qgiso_ship').setTint(color).setScale(0.95);
      c.add([flame, img]);
      layer.add(c);
      this.tweens.add({ targets: c, y: hy, duration: 650, ease: 'Back.easeOut', delay: i * 120 });
      ships.push({ c: c, img: img, x: hx, y: hy, color: color });
    }
    return ships;
  }

  _shoot(fx, fy, tx, ty, color, dur, onHit) {
    var p = this.add.image(fx, fy, 'tex_glow_white').setDisplaySize(34, 34).setTint(color).setBlendMode(Phaser.BlendModes.ADD);
    this._ensureFxLayer().add(p);
    this.tweens.add({ targets: p, x: tx, y: ty, duration: dur, ease: 'Sine.easeIn', onComplete: () => { p.destroy(); if (onHit) onHit(); } });
  }

  _impact(x, y, color, big) {
    this.fx.ring(x, y, color, big ? 1.7 : 0.9);
    this.fx.burst('energy', x, y, big ? 18 : 8);
    this.fx.shake(big ? 140 : 70, big ? 0.006 : 0.003);
  }

  _hitShip(ship) {
    ship.img.setTint(0xff6b6b);
    this.tweens.add({ targets: ship.c, x: ship.x + 8, duration: 60, yoyo: true, repeat: 2 });
    this._after(200, () => { if (ship.img && ship.img.active) ship.img.setTint(ship.color); });
  }

  _destroyStructure(key) {
    if (this.destroyed[key]) return;
    var k = this.G.parseKey(key), pos = this._screenOf(key);
    this.destroyed[key] = true;
    this._impact(pos.x, pos.y, 0xffb36b, true);
    this._refreshCell(k.x, k.y, false);
    this._refreshInfoBar();
  }

  _battleStart(result, plan) {
    var ships = this._spawnFleet(), E = this.E, STEP = 560;
    this._sfx('attack');
    var rounds = plan.order.length;
    plan.order.forEach((tg, i) => {
      this._after(750 + i * STEP, () => {
        var ship = ships[i % ships.length], pos = this._screenOf(tg.key);
        this._shoot(ship.x, ship.y + 14, pos.x, pos.y, 0x9fe8ff, 260, () => {
          if (tg.kind === 'destroy') this._destroyStructure(tg.key);
          else this._impact(pos.x, pos.y, tg.kind === 'damage' ? 0xffb36b : 0x7bdfff, false);
          this._sfx('hit');
        });
        // riposte d'une tourelle encore debout
        var alive = plan.turrets.filter((t) => !this.destroyed[t]);
        if (alive.length) {
          var tp = this._screenOf(alive[i % alive.length]);
          this._after(120, () => this._shoot(tp.x, tp.y - 24, ship.x, ship.y, E.color, 320, () => this._hitShip(ship)));
        }
      });
    });
    this._after(750 + rounds * STEP + 600, () => this._battleEnd(result, plan, ships));
  }

  _battleEnd(result, plan, ships) {
    var E = this.E, Ec = NEBUSTION.Economy, handle = this.bot.profile.handle, w = this.scale.width, v = this.viewport;
    var i = 0;
    if (result.victory) {
      // réaction en chaîne sur les structures restantes
      plan.rest.forEach((k) => { this._after(140 * (i++), () => this._destroyStructure(k)); });
      this.cameras.main.flash(180, 95, 217, 122);
      var parts = Object.keys(result.loot).map((id) => Ec.fmt(result.loot[id], 0) + ' ' + Ec.RES[id].short).join(' · ');
      this.fx.toast('💥 QG de ' + handle + ' pris d\'assaut !', 'Butin : ' + parts, 'crystal');
      this._sfx('victory');
    } else {
      this.fx.shake(140, 0.005);
      this.fx.toast('🛡️ Attaque repoussée', 'Le QG de ' + handle + ' a tenu bon.');
      this._sfx('defeat');
    }
    var banner = this.add.text(w / 2, v.y + v.h / 2 - 40, result.victory ? 'VICTOIRE' : 'REPOUSSÉ', {
      fontFamily: 'Arial, sans-serif', fontSize: '52px', fontStyle: '900', color: result.victory ? '#5fd97a' : '#ff8fa3'
    }).setOrigin(0.5).setDepth(2000).setScale(0.6).setAlpha(0).setShadow(0, 0, result.victory ? '#5fd97a' : '#ff6b6b', 16, true, true);
    this.tweens.add({ targets: banner, scale: 1, alpha: 1, duration: 320, ease: 'Back.easeOut' });

    ships.forEach((s, idx) => {
      this.tweens.add({ targets: s.c, y: v.y - 90, alpha: 0, duration: 700, delay: 500 + idx * 100, ease: 'Sine.easeIn',
        onComplete: () => s.c.destroy() });
    });
    var wait = 1700 + i * 140;
    if (NEBUSTION.QGMatchmakingManager) NEBUSTION.QGMatchmakingManager.clearCurrent();
    this._after(wait, () => {
      this.tweens.add({ targets: banner, alpha: 0, duration: 300, onComplete: () => banner.destroy() });
      this._busy = false;
      this._refreshInfoBar();
    });
  }
};
