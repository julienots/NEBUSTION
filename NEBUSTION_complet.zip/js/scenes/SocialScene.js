/**
 * NEBUSTION - SocialScene
 * Écran « Social » : Chat, Joueurs (vrais + bots uniques), Clan (vrais + bots), Amis / cadeaux reçus.
 * Toute la logique est dans NEBUSTION.SocialManager / NEBUSTION.Social ; cette scène ne fait que l'affichage.
 * Liste défilante au doigt (une seule zone gère glissement ET tap, comme SideRail), fiches en fenêtres modales,
 * champs de saisie = vrais <input> DOM superposés au canvas (même technique que AccountScene).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.SocialScene = class SocialScene extends Phaser.Scene {
  constructor() { super('SocialScene'); }

  init(data) {
    this.returnTo = (data && data.returnTo) || 'MainMenuScene';
    this.tab = (data && data.tab) || 'chat';
    this.filter = 'all'; this.clanSub = 'members';
    this.modal = null; this.chat = null; this.regions = []; this.scroll = 0; this.contentH = 0; this._drag = null;
    this.top = 250; this.bottom = 1096; this._domY = {}; this._dead = false;
  }

  create() {
    var self = this, w = this.scale.width, h = this.scale.height;
    this.SM = NEBUSTION.SocialManager; this.SO = NEBUSTION.Social;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(250, 5, 7, 15);
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });
    this.fx = new NEBUSTION.FX(this);
    this._txt(w / 2, 140, 'SOCIAL', 29, '#eaf2ff', { fontStyle: '900' }).setOrigin(0.5).setDepth(50).setShadow(0, 0, '#00e5ff', 12, true, true);
    this.subtitle = this._txt(w / 2, 174, '', 15, '#8e9cc0').setOrigin(0.5).setDepth(50);

    this.tabLayer = this.add.container(0, 0).setDepth(55);
    this.fixed = this.add.container(0, 0).setDepth(52);
    this.view = this.add.container(0, 0).setDepth(51);
    this._maskG = this.make.graphics({ x: 0, y: 0, add: false });
    this.view.setMask(this._maskG.createGeometryMask());

    this.hit = this.add.zone(w / 2, 0, w, 10).setInteractive().setDepth(53);
    this.hit.on('pointerdown', function (p) { if (self.modal) return; self._drag = { y: p.y, sy: p.y, moved: false, x: p.x }; });
    this.input.on('pointermove', function (p) {
      var d = self._drag; if (!d || !p.isDown) return;
      if (!d.moved && Math.abs(p.y - d.sy) > 9) d.moved = true;
      if (d.moved) { self.scroll = self._clampScroll(self.scroll - (p.y - d.y)); self.view.y = self.top - self.scroll; }
      d.y = p.y;
    });
    this.input.on('pointerup', function (p) {
      var d = self._drag; self._drag = null; if (!d || d.moved || self.modal) return;
      self._tap(p.x, p.y - self.top + self.scroll);
    });
    this.input.on('wheel', function (p, o, dx, dy) { if (self.modal) return; self.scroll = self._clampScroll(self.scroll + dy * 0.6); self.view.y = self.top - self.scroll; });

    // Champs DOM
    this.dom = {
      chat: this._field('Écris un message…', 140),
      name: this._field('Nom du clan (3-20)', 20),
      tag: this._field('TAG (2-4)', 4)
    };
    this.dom.chat.addEventListener('keydown', function (e) { if (e.key === 'Enter') self._sendChat(); });
    this.sendBtn = new NEBUSTION.Button(this, w - 92, 1136, { width: 128, height: 52, label: 'Envoyer', accentColor: 0x00e5ff, fontSize: '17px', onClick: function () { self._sendChat(); } });
    this.sendBtn.setDepth(60).setVisible(false);

    var back = new NEBUSTION.Button(this, 96, h - 64, { width: 148, height: 52, label: '← Retour', accentColor: 0x394869, fontSize: '17px', onClick: function () { self._close(); } });
    back.setDepth(60);
    this.hud = NEBUSTION.HUD.attach(this);

    this.scale.on('resize', this._layoutDom, this);
    this.events.once('shutdown', this._onShutdown, this);
    this._buildTabs();
    this._setTab(this.tab);

    // Cadeaux des vrais joueurs reçus hors ligne + profil public à jour
    this.SM.publishProfile(true);
    this.SM.pullRealGifts().then(function (n) { if (n && !self._dead && self.tab === 'friends') self._render(); });
  }

  // ------------------------------------------------------------------ Outils
  _txt(x, y, str, size, color, extra) {
    var st = { fontFamily: 'Arial, sans-serif', fontSize: size + 'px', color: color || '#eaf2ff', resolution: 2 };
    if (extra) Object.keys(extra).forEach(function (k) { st[k] = extra[k]; });
    return this.add.text(x, y, str, st);
  }
  _domRect(gx, gy, gw, gh) {
    var canvas = this.sys.game.canvas, rect = canvas.getBoundingClientRect();
    var sx = rect.width / this.scale.width, sy = rect.height / this.scale.height;
    return { left: rect.left + gx * sx, top: rect.top + gy * sy, width: gw * sx, height: gh * sy, fontSize: Math.max(12, 15 * sx) };
  }
  _field(ph, max) {
    var el = document.createElement('input');
    el.className = 'nebu-field'; el.type = 'text'; el.placeholder = ph; el.maxLength = max; el.autocomplete = 'off'; el.style.display = 'none';
    document.body.appendChild(el); return el;
  }
  _layoutDom() {
    var self = this, w = this.scale.width, spec = {
      chat: this._domY.chat !== undefined ? [24, this._domY.chat - 28, w - 24 - 168, 56] : null,
      name: this._domY.name !== undefined ? [w / 2 - 250, this._domY.name - 28, 500, 56] : null,
      tag: this._domY.tag !== undefined ? [w / 2 - 250, this._domY.tag - 28, 500, 56] : null
    };
    Object.keys(this.dom).forEach(function (k) {
      var el = self.dom[k], s = spec[k]; if (!el) return;
      if (!s) { el.style.display = 'none'; return; }
      var r = self._domRect(s[0], s[1], s[2], s[3]);
      el.style.left = r.left + 'px'; el.style.top = r.top + 'px'; el.style.width = r.width + 'px'; el.style.height = r.height + 'px'; el.style.fontSize = r.fontSize + 'px'; el.style.display = 'block';
    });
    this.sendBtn.setVisible(this._domY.chat !== undefined);
  }
  _onShutdown() {
    this._dead = true;
    if (this.chat) { this.chat.stop(); this.chat = null; }
    var self = this; Object.keys(this.dom || {}).forEach(function (k) { var el = self.dom[k]; if (el && el.parentNode) el.parentNode.removeChild(el); });
    this.scale.off('resize', this._layoutDom, this);
  }
  _close() {
    var self = this; this._domY = {}; this._layoutDom();
    this.cameras.main.fadeOut(200, 5, 7, 15);
    this.cameras.main.once('camerafadeoutcomplete', function () { self.scene.start(self.returnTo); });
  }
  _toast(t, s) { try { this.fx.toast(t, s); } catch (e) { /* ignore */ } }
  _fmt(n) { n = Math.round(n || 0); return n >= 1e6 ? (n / 1e6).toFixed(1) + 'M' : (n >= 10000 ? (n / 1000).toFixed(1) + 'k' : String(n)); }
  _hue(hue, l) { return Phaser.Display.Color.HSLToColor(((hue % 360) / 360), 0.65, l || 0.55).color; }

  // ------------------------------------------------------------------ Liste défilante
  _setViewport(top, bottom) {
    this.top = top; this.bottom = bottom;
    this._maskG.clear(); this._maskG.fillStyle(0xffffff, 1); this._maskG.fillRect(0, top, this.scale.width, bottom - top);
    this.hit.setPosition(this.scale.width / 2, (top + bottom) / 2); this.hit.setSize(this.scale.width, bottom - top);
    if (this.hit.input && this.hit.input.hitArea) { this.hit.input.hitArea.width = this.scale.width; this.hit.input.hitArea.height = bottom - top; }
  }
  _clampScroll(s) { return Math.max(0, Math.min(Math.max(0, this.contentH - (this.bottom - this.top)), s)); }
  _resetList(keepScroll) {
    var keep = keepScroll ? this.scroll : 0;
    this.view.removeAll(true); this.regions = []; this.contentH = 0; this.scroll = keep; this.view.y = this.top - this.scroll;
  }
  _endList(h, stickBottom) {
    this.contentH = h;
    var maxS = Math.max(0, h - (this.bottom - this.top));
    this.scroll = stickBottom ? maxS : this._clampScroll(this.scroll);
    this.view.y = this.top - this.scroll;
  }
  _region(x0, y0, x1, y1, fn) { this.regions.push({ x0: x0, y0: y0, x1: x1, y1: y1, fn: fn }); }
  _tap(x, ly) {
    for (var i = this.regions.length - 1; i >= 0; i--) { var r = this.regions[i]; if (x >= r.x0 && x <= r.x1 && ly >= r.y0 && ly <= r.y1) { r.fn(); return; } }
  }
  _pill(layer, x, y, w, h, label, color, active) {
    var g = this.add.graphics();
    g.fillStyle(active ? color : 0x0b1224, active ? 0.28 : 0.9); g.fillRoundedRect(x - w / 2, y - h / 2, w, h, h * 0.35);
    g.lineStyle(2, color, active ? 1 : 0.5); g.strokeRoundedRect(x - w / 2, y - h / 2, w, h, h * 0.35);
    layer.add(g);
    layer.add(this._txt(x, y, label, h > 40 ? 17 : 15, active ? '#ffffff' : '#a9b8dc', { fontStyle: 'bold' }).setOrigin(0.5));
  }
  _avatar(layer, x, y, r, av) {
    var g = this.add.graphics(), col = this._hue(av.hue, 0.5);
    g.fillStyle(col, 1); if (av.shape === 1) g.fillRoundedRect(x - r, y - r, r * 2, r * 2, r * 0.35); else g.fillCircle(x, y, r);
    g.lineStyle(2, 0xffffff, 0.35); if (av.shape === 1) g.strokeRoundedRect(x - r, y - r, r * 2, r * 2, r * 0.35); else g.strokeCircle(x, y, r);
    layer.add(g);
    layer.add(this._txt(x, y, av.glyph, Math.round(r * 0.95), '#ffffff', { fontStyle: 'bold' }).setOrigin(0.5));
  }
  _statusOf(p) {
    if (p.status === 'online') return { txt: 'En ligne', col: '#5fd97a', dot: 0x5fd97a };
    if (p.status === 'away') return { txt: 'Absent', col: '#ffb84d', dot: 0xffb84d };
    return { txt: 'Vu ' + this.SO.agoText(Date.now() - (p.lastSeen || 0)), col: '#6b7aa0', dot: 0x4a5878 };
  }

  // ------------------------------------------------------------------ Onglets
  _buildTabs() {
    var self = this, w = this.scale.width, tabs = [['chat', '💬 CHAT'], ['players', '👥 JOUEURS'], ['clan', '🛡 CLAN'], ['friends', '⭐ AMIS']];
    this._tabDefs = tabs;
    var tw = (w - 32) / 4;
    tabs.forEach(function (t, i) {
      var z = self.add.zone(16 + tw * i + tw / 2, 214, tw, 50).setInteractive({ useHandCursor: true }).setDepth(56);
      z.on('pointerup', function () { if (self.modal) return; self._setTab(t[0]); });
      self._tabZones = (self._tabZones || []).concat([z]);
    });
    this._drawTabs();
  }
  _drawTabs() {
    var self = this, w = this.scale.width, tw = (w - 32) / 4;
    this.tabLayer.removeAll(true);
    var badge = this.SM.inbox().length;
    this._tabDefs.forEach(function (t, i) {
      var x = 16 + tw * i + tw / 2, a = self.tab === t[0];
      self._pill(self.tabLayer, x, 214, tw - 8, 46, t[1], 0x00e5ff, a);
      if (t[0] === 'friends' && badge > 0) { var g = self.add.graphics(); g.fillStyle(0xff4d6d, 1); g.fillCircle(x + tw / 2 - 16, 194, 10); self.tabLayer.add(g); self.tabLayer.add(self._txt(x + tw / 2 - 16, 194, String(Math.min(9, badge)), 12, '#fff', { fontStyle: 'bold' }).setOrigin(0.5)); }
      if (t[0] === 'clan' && self.SM.chestReady()) { var g2 = self.add.graphics(); g2.fillStyle(0xffd166, 1); g2.fillCircle(x + tw / 2 - 16, 194, 8); self.tabLayer.add(g2); }
    });
  }
  _setTab(tab) {
    this.tab = tab;
    if (this.chat) { this.chat.stop(); this.chat = null; }
    this.scroll = 0; this._drawTabs(); this._render();
  }
  _render() {
    if (this._dead) return;
    this.fixed.removeAll(true); this._domY = {};
    if (this.tab === 'chat') this._renderChat('global', null, 'Canal général');
    else if (this.tab === 'players') this._renderPlayers();
    else if (this.tab === 'clan') this._renderClan();
    else this._renderFriends();
    this._layoutDom();
  }

  // ------------------------------------------------------------------ Chat (général ou clan)
  _renderChat(channel, opts, title, topOverride) {
    var self = this, w = this.scale.width, top = topOverride || 256;
    this._chatChannel = channel; this._chatOpts = opts;
    this._setViewport(top, 1096);
    this._domY.chat = 1136;
    this.subtitle.setText(this.SM.online() ? 'Connecté · les vrais joueurs te lisent' : 'Mode hors compte · discussion avec les joueurs de la galaxie');
    if (!topOverride) this.fixed.add(this._txt(24, 236, title, 15, '#7a89ad'));
    this._resetList();
    if (this.chat) this.chat.stop();
    this._chatFirst = true;
    this.chat = this.SM.watchChat(channel, opts || {}, function (list) { self._drawChat(list); });
  }
  _drawChat(list) {
    if (this._dead || !this.chat || (this.tab !== 'chat' && !(this.tab === 'clan' && this.clanSub === 'chat'))) return;
    var w = this.scale.width, maxS = Math.max(0, this.contentH - (this.bottom - this.top)), atBottom = this._chatFirst || this.scroll >= maxS - 40;
    this._resetList(true);
    var y = 10, self = this;
    if (!list.length) this.view.add(this._txt(w / 2, 40, 'Aucun message pour l\'instant. Lance la discussion !', 16, '#6b7aa0').setOrigin(0.5));
    list.forEach(function (m) {
      var col = m.mine ? '#00e5ff' : '#' + ('000000' + self._hue(self.SO.hash(String(m.from)) % 360, 0.68).toString(16)).slice(-6);
      var head = self._txt(28, y, m.name + (m.real ? '  ✓' : ''), 16, col, { fontStyle: 'bold' });
      var tm = new Date(m.t), hh = ('0' + tm.getHours()).slice(-2) + ':' + ('0' + tm.getMinutes()).slice(-2);
      var stamp = self._txt(w - 28, y + 2, hh, 12, '#5c6b8a').setOrigin(1, 0);
      var body = self._txt(28, y + 22, m.text, 17, '#e3ebff', { wordWrap: { width: w - 84 } });
      self.view.add([head, stamp, body]);
      if (!m.mine && m.from && m.from !== 'me') { var yy = y; self._region(20, yy, 300, yy + 22, function () { self._openProfile(m.from); }); }
      y += 22 + body.height + 14;
    });
    this._chatFirst = false;
    this._endList(y + 10, atBottom);
  }
  _sendChat() {
    var self = this, el = this.dom.chat; if (!this.chat || !el || this.modal) return;
    var text = el.value; if (!String(text).trim()) return;
    var res = this.chat.send(text);
    Promise.resolve(res).then(function (r) {
      if (r && r.ok) { el.value = ''; if (self.chat) { self._chatFirst = true; self.chat.refresh(); } }
      else if (r) self._toast('Message non envoyé', r.error);
    });
  }

  // ------------------------------------------------------------------ Joueurs
  _renderPlayers() {
    var self = this, w = this.scale.width;
    this._setViewport(330, 1096);
    this.subtitle.setText('Joueurs de la galaxie');
    var f = [['all', 'Tous'], ['online', 'En ligne'], ['friends', 'Amis']], fw = 150;
    f.forEach(function (o, i) {
      var x = 24 + fw / 2 + i * (fw + 12);
      self._pill(self.fixed, x, 278, fw, 40, o[1], 0x4fc3ff, self.filter === o[0]);
      var z = self.add.zone(x, 278, fw, 44).setInteractive({ useHandCursor: true }); self.fixed.add(z);
      z.on('pointerup', function () { if (self.modal) return; self.filter = o[0]; self._render(); });
    });
    this._resetList();
    this.view.add(this._txt(w / 2, 40, 'Chargement…', 16, '#6b7aa0').setOrigin(0.5));
    var token = this._tok = (this._tok || 0) + 1;
    this.SM.listPlayers({ filter: this.filter }).then(function (res) {
      if (self._dead || token !== self._tok || self.tab !== 'players') return;
      self._resetList();
      var y = 6;
      var real = res.list.filter(function (p) { return !p.isBot; }).length;
      self.fixed.add(self._txt(w - 24, 278, '🟢 ' + res.list.filter(function (p) { return p.status === 'online'; }).length + ' en ligne · ' + real + ' réels', 14, '#8e9cc0').setOrigin(1, 0.5));
      if (!res.realOk && res.realError) {
        var note = self._txt(w / 2, y + 4, 'ℹ ' + res.realError, 14, '#ffb27a', { align: 'center', wordWrap: { width: w - 60 } }).setOrigin(0.5, 0); self.view.add(note); y += note.height + 14;
      }
      if (!res.list.length) self.view.add(self._txt(w / 2, y + 40, self.filter === 'friends' ? 'Aucun ami pour l\'instant.\nAjoute des joueurs depuis leur fiche.' : 'Personne ici.', 16, '#6b7aa0', { align: 'center' }).setOrigin(0.5, 0));
      res.list.forEach(function (p) { self._playerRow(p, y); y += 96; });
      self._endList(y + 20);
    });
  }
  _playerRow(p, y) {
    var self = this, w = this.scale.width, st = this._statusOf(p), mine = this.SM.isFriend(p.id);
    var g = this.add.graphics(); g.fillStyle(0x0d1730, 0.85); g.fillRoundedRect(16, y, w - 32, 86, 16); g.lineStyle(1.5, p.isBot ? 0x22304f : 0x2e9eff, p.isBot ? 0.8 : 0.9); g.strokeRoundedRect(16, y, w - 32, 86, 16);
    this.view.add(g);
    this._avatar(this.view, 68, y + 43, 28, p.avatar);
    var dot = this.add.graphics(); dot.fillStyle(st.dot, 1); dot.fillCircle(88, y + 64, 8); dot.lineStyle(2, 0x0d1730, 1); dot.strokeCircle(88, y + 64, 8); this.view.add(dot);
    var nm = p.name + (p.clanTag ? '  [' + p.clanTag + ']' : '') + (mine ? '  ⭐' : '') + (p.isBot && this.SO.SHOW_BOT_TAG ? '  BOT' : '');
    this.view.add(this._txt(112, y + 14, nm, 21, '#eaf2ff', { fontStyle: 'bold' }));
    this.view.add(this._txt(112, y + 42, 'Nv. ' + p.level + '  ·  ⚡ ' + this._fmt(p.power) + '  ·  ' + p.arch, 14, '#a9b8dc'));
    this.view.add(this._txt(112, y + 62, st.txt + (p.isBot ? '' : '  ·  vrai joueur'), 13, st.col, { fontStyle: p.isBot ? 'normal' : 'bold' }));
    this.view.add(this._txt(w - 40, y + 43, '›', 32, '#5c6b8a').setOrigin(0.5));
    this._region(16, y, w - 16, y + 86, function () { self._openProfilePlayer(p); });
  }

  // ------------------------------------------------------------------ Fiche joueur (modale)
  _openProfile(id) {
    var self = this;
    this.SM.playerById(id).then(function (p) { if (p && !self._dead && !self.modal) self._openProfilePlayer(p); });
  }
  _openModal(hh) {
    var self = this, w = this.scale.width, h = this.scale.height;
    this._closeModal();
    var c = this.add.container(0, 0).setDepth(500);
    var shade = this.add.rectangle(w / 2, h / 2, w, h, 0x000000, 0.72).setInteractive();
    c.add(shade);
    var pw = 640, py = h / 2 - hh / 2;
    var g = this.add.graphics(); g.fillStyle(0x0b1224, 0.98); g.fillRoundedRect(w / 2 - pw / 2, py, pw, hh, 22); g.lineStyle(2, 0x00e5ff, 0.7); g.strokeRoundedRect(w / 2 - pw / 2, py, pw, hh, 22);
    c.add(g);
    this.modal = c; this._modalTop = py; this._domY_saved = this._domY; this._domY = {}; this._layoutDom();
    return c;
  }
  _closeModal() {
    if (this.modal) { this.modal.destroy(true); this.modal = null; }
    if (this._domY_saved) { this._domY = this._domY_saved; this._domY_saved = null; this._layoutDom(); }
  }
  _mBtn(c, x, y, w, label, color, fn) {
    var b = new NEBUSTION.Button(this, x, y, { width: w, height: 54, label: label, accentColor: color, fontSize: '17px', onClick: fn });
    c.add(b); return b;
  }
  _openProfilePlayer(p) {
    var self = this, SM = this.SM, w = this.scale.width, cx = w / 2, H = 720, c = this._openModal(H), y0 = this._modalTop;
    var m = SM.me(), chance = this.SO.duelChance(m.power, p.power), st = this._statusOf(p);
    this._avatar(c, cx, y0 + 76, 44, p.avatar);
    c.add(this._txt(cx, y0 + 140, p.name + (p.clanTag ? '  [' + p.clanTag + ']' : ''), 26, '#ffffff', { fontStyle: 'bold' }).setOrigin(0.5));
    c.add(this._txt(cx, y0 + 172, p.arch + '  ·  ' + st.txt, 15, st.col).setOrigin(0.5));
    if (p.bio) c.add(this._txt(cx, y0 + 214, '“' + p.bio + '”', 15, '#a9b8dc', { align: 'center', wordWrap: { width: 540 } }).setOrigin(0.5));
    c.add(this._txt(cx - 140, y0 + 272, 'NIVEAU', 12, '#6b7aa0').setOrigin(0.5)); c.add(this._txt(cx - 140, y0 + 296, String(p.level), 26, '#ffd166', { fontStyle: 'bold' }).setOrigin(0.5));
    c.add(this._txt(cx + 140, y0 + 272, 'PUISSANCE', 12, '#6b7aa0').setOrigin(0.5)); c.add(this._txt(cx + 140, y0 + 296, this._fmt(p.power), 26, '#ff7b8a', { fontStyle: 'bold' }).setOrigin(0.5));
    var info = this._txt(cx, y0 + 352, 'Duel amical : ' + Math.round(chance * 100) + ' % de chances · ' + SM.duelsLeft() + ' restants aujourd\'hui', 14, '#8e9cc0', { align: 'center', wordWrap: { width: 560 } }).setOrigin(0.5);
    c.add(info);
    var friendBtn = this._mBtn(c, cx - 150, y0 + 420, 270, SM.isFriend(p.id) ? '★ Retirer des amis' : '☆ Ajouter en ami', 0xffd166, function () {
      var r = SM.toggleFriend(p.id); if (!r.ok) return self._toast('Impossible', r.error);
      friendBtn.labelText.setText(r.friend ? '★ Retirer des amis' : '☆ Ajouter en ami'); self._drawTabs();
    });
    this._mBtn(c, cx + 150, y0 + 420, 270, '🎁 Cadeau · 100 💎 (' + SM.giftsLeft() + ')', 0x5fd97a, function () {
      SM.sendGift(p).then(function (r) {
        if (!r.ok) return self._toast('Cadeau impossible', r.error);
        info.setText('Cadeau envoyé à ' + p.name + (r.back ? ' — il te répondra peut-être 😉' : ' !')); self._toast('🎁 Cadeau envoyé', p.name);
      });
    });
    this._mBtn(c, cx - 150, y0 + 494, 270, '⚔ Duel amical', 0xff4d6d, function () {
      var r = SM.duel(p); if (!r.ok) return self._toast('Duel impossible', r.error);
      var rw = Object.keys(r.reward).map(function (k) { return '+' + r.reward[k] + ' ' + ({ crystal: '💎', metal: '⚙' }[k] || k); }).join('  ');
      info.setText((r.win ? '🏆 VICTOIRE ! ' : '💥 Défaite… ') + rw + '\n(' + self._fmt(r.myPower) + ' ⚡ contre ' + self._fmt(r.theirPower) + ' ⚡ · ' + SM.duelsLeft() + ' duels restants)');
      info.setColor(r.win ? '#7dffb0' : '#ffb27a');
    });
    var clanBtnLabel = p.clanId ? '🛡 Voir son clan' : '🛡 Sans clan';
    this._mBtn(c, cx + 150, y0 + 494, 270, clanBtnLabel, 0x4fc3ff, function () {
      if (!p.clanId) return;
      var isBot = !!self.SO.botClanById(p.clanId);
      SM.clanView(p.clanId, isBot).then(function (v) { if (v) self._openClanModal(v); });
    });
    this._mBtn(c, cx, y0 + 590, 300, 'Fermer', 0x394869, function () { self._closeModal(); });
  }

  // ------------------------------------------------------------------ Clan
  _renderClan() {
    var self = this, w = this.scale.width, mc = this.SM.myClan();
    this.subtitle.setText(mc ? 'Ton clan' : 'Rejoins ou crée un clan');
    if (mc) return this._renderMyClan(mc);
    this._setViewport(330, 1096);
    var b = new NEBUSTION.Button(this, w / 2, 284, { width: w - 48, height: 54, label: '＋ Créer un clan  (' + this.SO.CFG.CLAN_CREATE_COST + ' 💎)', accentColor: 0xffd166, fontSize: '18px', onClick: function () { if (!self.modal) self._openCreateClan(); } });
    this.fixed.add(b);
    this._resetList(); this.view.add(this._txt(w / 2, 40, 'Chargement…', 16, '#6b7aa0').setOrigin(0.5));
    var token = this._tok = (this._tok || 0) + 1;
    this.SM.listClans().then(function (res) {
      if (self._dead || token !== self._tok || self.tab !== 'clan' || self.SM.myClan()) return;
      self._resetList(); var y = 6;
      if (!res.realOk && res.realError) { var note = self._txt(w / 2, y + 4, 'ℹ ' + res.realError, 14, '#ffb27a', { align: 'center', wordWrap: { width: w - 60 } }).setOrigin(0.5, 0); self.view.add(note); y += note.height + 14; }
      res.list.forEach(function (c) { self._clanRow(c, y); y += 108; });
      self._endList(y + 20);
    });
  }
  _clanRow(c, y) {
    var self = this, w = this.scale.width;
    var g = this.add.graphics(); g.fillStyle(0x0d1730, 0.85); g.fillRoundedRect(16, y, w - 32, 98, 16); g.lineStyle(1.5, c.color, 0.7); g.strokeRoundedRect(16, y, w - 32, 98, 16);
    g.fillStyle(c.color, 0.9); g.fillRoundedRect(30, y + 17, 64, 64, 14); this.view.add(g);
    this.view.add(this._txt(62, y + 49, c.glyph, 30, '#0b1224', { fontStyle: 'bold' }).setOrigin(0.5));
    this.view.add(this._txt(110, y + 12, c.name + '  [' + c.tag + ']' + (!c.isBot ? '  ✓' : '') + (c.isBot && this.SO.SHOW_BOT_TAG ? '  BOT' : ''), 20, '#ffffff', { fontStyle: 'bold' }));
    this.view.add(this._txt(110, y + 40, 'Nv. ' + c.level + '  ·  ' + c.size + '/' + this.SO.CLAN_MAX + ' membres  ·  ⚡ ' + this._fmt(c.power) + (c.online ? '  ·  🟢 ' + c.online : ''), 14, '#a9b8dc'));
    this.view.add(this._txt(110, y + 64, (c.open ? '' : '🔒 Sur invitation · ') + 'Niv. joueur ' + c.minLevel + '+ · ' + (c.motto || ''), 13, '#6b7aa0', { wordWrap: { width: w - 190 } }));
    this.view.add(this._txt(w - 40, y + 49, '›', 32, '#5c6b8a').setOrigin(0.5));
    this._region(16, y, w - 16, y + 98, function () { self.SM.clanView(c.id, c.isBot).then(function (v) { if (v && !self._dead) self._openClanModal(v); }); });
  }
  _openClanModal(v) {
    var self = this, SM = this.SM, w = this.scale.width, cx = w / 2, H = 860, c = this._openModal(H), y0 = this._modalTop;
    c.add(this._txt(cx, y0 + 40, v.glyph + '  ' + v.name + '  [' + v.tag + ']', 24, '#ffffff', { fontStyle: 'bold' }).setOrigin(0.5));
    c.add(this._txt(cx, y0 + 76, v.motto || '', 14, '#a9b8dc').setOrigin(0.5));
    c.add(this._txt(cx, y0 + 106, 'Niveau ' + v.level + '  ·  ' + v.size + '/' + this.SO.CLAN_MAX + ' membres  ·  ⚡ ' + this._fmt(v.power), 15, '#ffd166').setOrigin(0.5));
    var rows = v.members.slice().sort(function (a, b) { return b.power - a.power; }).slice(0, 9);
    rows.forEach(function (mb, i) {
      var yy = y0 + 150 + i * 46, role = mb.role === 'leader' ? '👑 ' : (mb.role === 'officer' ? '⭐ ' : '');
      c.add(self._txt(cx - 280, yy, role + mb.name, 16, mb.status === 'online' ? '#e3ebff' : '#8e9cc0', { fontStyle: mb.role === 'leader' ? 'bold' : 'normal' }));
      c.add(self._txt(cx + 280, yy, 'Nv.' + mb.level + '  ⚡ ' + self._fmt(mb.power) + (mb.status === 'online' ? '  🟢' : ''), 14, '#a9b8dc').setOrigin(1, 0));
    });
    if (v.size > rows.length) c.add(this._txt(cx, y0 + 150 + rows.length * 46 + 4, '… et ' + (v.size - rows.length) + ' autres membres', 13, '#6b7aa0').setOrigin(0.5, 0));
    var info = this._txt(cx, y0 + H - 170, '', 14, '#ffb27a', { align: 'center', wordWrap: { width: 560 } }).setOrigin(0.5); c.add(info);
    var mine = SM.myClan() && SM.myClan().id === v.id;
    if (!mine) {
      this._mBtn(c, cx - 150, y0 + H - 110, 270, v.open ? 'Rejoindre le clan' : '🔒 Sur invitation', v.open ? 0x5fd97a : 0x394869, function () {
        SM.joinClan(v).then(function (r) {
          if (!r.ok) { info.setText(r.error); return; }
          self._closeModal(); self._toast('🛡 Bienvenue dans ' + v.name, '[' + v.tag + ']'); self.clanSub = 'members'; self._drawTabs(); self._render();
        });
      });
    }
    this._mBtn(c, mine ? cx : cx + 150, y0 + H - 110, mine ? 300 : 270, 'Fermer', 0x394869, function () { self._closeModal(); });
  }
  _openCreateClan() {
    var self = this, SM = this.SM, w = this.scale.width, cx = w / 2, H = 520, c = this._openModal(H), y0 = this._modalTop;
    c.add(this._txt(cx, y0 + 44, 'Créer un clan', 26, '#ffffff', { fontStyle: 'bold' }).setOrigin(0.5));
    c.add(this._txt(cx, y0 + 84, 'Coût : ' + this.SO.CFG.CLAN_CREATE_COST + ' 💎 · 30 membres max · vrais joueurs', 14, '#a9b8dc').setOrigin(0.5));
    var info = this._txt(cx, y0 + 296, SM.online() ? '' : 'Connecte-toi (Paramètres → Compte) pour créer un vrai clan.', 14, '#ffb27a', { align: 'center', wordWrap: { width: 560 } }).setOrigin(0.5); c.add(info);
    this._domY_saved = this._domY_saved || {}; this._domY = { name: y0 + 150, tag: y0 + 222 }; this._layoutDom();
    this._mBtn(c, cx - 150, y0 + H - 60, 270, 'Créer', 0x5fd97a, function () {
      var nm = self.dom.name.value, tg = self.dom.tag.value;
      SM.createClan(nm, String(tg).toUpperCase(), '').then(function (r) {
        if (!r.ok) { info.setText(r.error); return; }
        self.dom.name.value = ''; self.dom.tag.value = ''; self._domY_saved = {}; self._closeModal(); self._toast('🛡 Clan créé !', nm); self._drawTabs(); self._render();
      });
    });
    this._mBtn(c, cx + 150, y0 + H - 60, 270, 'Annuler', 0x394869, function () { self._domY_saved = {}; self._closeModal(); self._render(); });
  }

  _renderMyClan(mc) {
    var self = this, SM = this.SM, w = this.scale.width, SO = this.SO;
    this._setViewport(500, 1096);
    this.fixed.add(this._txt(w / 2, 262, 'Chargement du clan…', 15, '#6b7aa0').setOrigin(0.5));
    var token = this._tok = (this._tok || 0) + 1;
    SM.clanView(mc.id, mc.kind === 'bot').then(function (v) {
      if (self._dead || token !== self._tok || self.tab !== 'clan') return;
      self.fixed.removeAll(true);
      if (!v) { self.fixed.add(self._txt(w / 2, 300, 'Clan introuvable (supprimé ?).', 16, '#ffb27a').setOrigin(0.5)); self.fixed.add(new NEBUSTION.Button(self, w / 2, 360, { width: 280, height: 54, label: 'Quitter ce clan', accentColor: 0xff4d6d, fontSize: '17px', onClick: function () { SM.leaveClan().then(function () { self._render(); }); } })); return; }
      self._clanV = v;
      var g = self.add.graphics(); g.fillStyle(0x0d1730, 0.9); g.fillRoundedRect(16, 240, w - 32, 128, 18); g.lineStyle(2, v.color, 0.85); g.strokeRoundedRect(16, 240, w - 32, 128, 18);
      g.fillStyle(v.color, 0.95); g.fillRoundedRect(32, 256, 72, 72, 16); self.fixed.add(g);
      self.fixed.add(self._txt(68, 292, v.glyph, 34, '#0b1224', { fontStyle: 'bold' }).setOrigin(0.5));
      self.fixed.add(self._txt(120, 254, v.name + '  [' + v.tag + ']', 22, '#ffffff', { fontStyle: 'bold' }));
      self.fixed.add(self._txt(120, 284, 'Nv. ' + v.level + '  ·  ' + v.size + '/' + SO.CLAN_MAX + ' membres  ·  ⚡ ' + self._fmt(v.power), 14, '#a9b8dc'));
      self.fixed.add(self._txt(120, 306, v.motto || '', 13, '#6b7aa0', { wordWrap: { width: w - 160 } }));
      var pr = SO.clanLevelProgress(v.xp), bar = self.add.graphics();
      bar.fillStyle(0x1a2540, 1); bar.fillRoundedRect(32, 344, w - 64, 12, 6); bar.fillStyle(v.color, 1); bar.fillRoundedRect(32, 344, Math.max(8, (w - 64) * pr.ratio), 12, 6); self.fixed.add(bar);
      self.fixed.add(self._txt(w - 32, 330, 'XP clan ' + pr.cur + ' / ' + pr.need, 12, '#8e9cc0').setOrigin(1, 0.5));
      var ready = SM.chestReady();
      var chest = new NEBUSTION.Button(self, 130, 412, { width: 232, height: 52, label: ready ? '🎁 Coffre du jour' : '✔ Coffre pris', accentColor: ready ? 0xffd166 : 0x394869, fontSize: '16px', onClick: function () {
        var r = SM.claimChest(v.level); if (!r.ok) return self._toast('Coffre', r.error);
        self._toast('🎁 Coffre du clan', Object.keys(r.reward).map(function (k) { return '+' + r.reward[k]; }).join(' ')); self._drawTabs(); self._render();
      } });
      var don = new NEBUSTION.Button(self, w / 2 + 6, 412, { width: 232, height: 52, label: '💎 Donner ' + SO.CFG.CLAN_DONATE + ' (' + SM.donateLeft() + ')', accentColor: 0x5fd97a, fontSize: '16px', onClick: function () {
        SM.donate().then(function (r) { if (!r.ok) return self._toast('Don impossible', r.error); self._toast('Merci !', '+' + r.xp + ' XP pour le clan'); self._render(); });
      } });
      var lv = new NEBUSTION.Button(self, w - 118, 412, { width: 200, height: 52, label: 'Quitter', accentColor: 0xff4d6d, fontSize: '16px', onClick: function () {
        if (self.modal) return; self._confirmLeave(v);
      } });
      self.fixed.add([chest, don, lv]);
      [['members', 'Membres'], ['chat', 'Discussion']].forEach(function (o, i) {
        var x = 24 + 160 + i * 332; self._pill(self.fixed, x, 466, 320, 40, o[1], 0x4fc3ff, self.clanSub === o[0]);
        var z = self.add.zone(x, 466, 320, 44).setInteractive({ useHandCursor: true }); self.fixed.add(z);
        z.on('pointerup', function () { if (self.modal) return; self.clanSub = o[0]; self._render(); });
      });
      if (self.clanSub === 'chat') {
        if (self.chat) { self.chat.stop(); self.chat = null; }
        self._domY = {}; self._renderChatInClan(v);
      } else {
        if (self.chat) { self.chat.stop(); self.chat = null; }
        self._domY = {}; self._layoutDom(); self._setViewport(500, 1096); self._resetList();
        var y = 6; v.members.slice().sort(function (a, b) { return b.power - a.power; }).forEach(function (mb) { self._memberRow(mb, y); y += 84; });
        self._endList(y + 20);
      }
    });
  }
  _renderChatInClan(v) {
    var mc = this.SM.myClan();
    this._setViewport(500, 1096); this._domY.chat = 1136;
    var self = this; this._resetList(); this._chatFirst = true;
    this.chat = this.SM.watchChat('clan:' + mc.id, this.SM.clanChatOpts(v), function (list) { self._drawChat(list); });
    this._layoutDom();
  }
  _memberRow(mb, y) {
    var self = this, w = this.scale.width, r = this.SO.hash(String(mb.id));
    var g = this.add.graphics(); g.fillStyle(0x0d1730, 0.85); g.fillRoundedRect(16, y, w - 32, 74, 14); this.view.add(g);
    this._avatar(this.view, 62, y + 37, 24, { hue: r % 360, glyph: mb.role === 'leader' ? '♛' : '●', shape: r % 3 });
    this.view.add(this._txt(100, y + 12, (mb.role === 'leader' ? '👑 ' : (mb.role === 'officer' ? '⭐ ' : '')) + mb.name, 19, '#eaf2ff', { fontStyle: 'bold' }));
    this.view.add(this._txt(100, y + 40, 'Nv. ' + mb.level + '  ·  ⚡ ' + this._fmt(mb.power) + (mb.status === 'online' ? '  ·  🟢 en ligne' : ''), 14, '#a9b8dc'));
    this.view.add(this._txt(w - 40, y + 37, '›', 30, '#5c6b8a').setOrigin(0.5));
    this._region(16, y, w - 16, y + 74, function () { if (mb.id && mb.id !== self.SM.me().uid) self._openProfile(mb.id); });
  }
  _confirmLeave(v) {
    var self = this, w = this.scale.width, cx = w / 2, c = this._openModal(300), y0 = this._modalTop;
    c.add(this._txt(cx, y0 + 70, 'Quitter « ' + v.name + ' » ?', 22, '#ffffff', { fontStyle: 'bold', align: 'center', wordWrap: { width: 560 } }).setOrigin(0.5));
    c.add(this._txt(cx, y0 + 122, 'Tu pourras en rejoindre un autre à tout moment.', 14, '#a9b8dc').setOrigin(0.5));
    this._mBtn(c, cx - 150, y0 + 220, 270, 'Quitter', 0xff4d6d, function () { self.SM.leaveClan().then(function (r) { self._closeModal(); if (!r.ok) self._toast('Impossible', r.error); self._drawTabs(); self._render(); }); });
    this._mBtn(c, cx + 150, y0 + 220, 270, 'Rester', 0x394869, function () { self._closeModal(); });
  }

  // ------------------------------------------------------------------ Amis + cadeaux reçus
  _renderFriends() {
    var self = this, w = this.scale.width, SM = this.SM;
    this._setViewport(250, 1096);
    this.subtitle.setText('Amis et cadeaux');
    this._resetList(); this.view.add(this._txt(w / 2, 40, 'Chargement…', 16, '#6b7aa0').setOrigin(0.5));
    var token = this._tok = (this._tok || 0) + 1;
    SM.listPlayers({ filter: 'friends' }).then(function (res) {
      if (self._dead || token !== self._tok || self.tab !== 'friends') return;
      self._resetList(); var y = 6, inbox = SM.inbox();
      self.view.add(self._txt(24, y, '🎁 CADEAUX REÇUS (' + inbox.length + ')', 15, '#ffd166', { fontStyle: 'bold' })); y += 32;
      if (!inbox.length) { self.view.add(self._txt(24, y, 'Aucun cadeau en attente. Envoie-en pour recevoir en retour !', 14, '#6b7aa0')); y += 34; }
      inbox.forEach(function (gm) {
        var g = self.add.graphics(); g.fillStyle(0x1a2a1e, 0.9); g.fillRoundedRect(16, y, w - 32, 70, 14); g.lineStyle(1.5, 0x5fd97a, 0.7); g.strokeRoundedRect(16, y, w - 32, 70, 14); self.view.add(g);
        self.view.add(self._txt(32, y + 12, '🎁 ' + gm.name + (gm.real ? '  ✓' : ''), 18, '#eaf2ff', { fontStyle: 'bold' }));
        self.view.add(self._txt(32, y + 40, '+' + gm.amount + ' 💎 cristaux', 14, '#8fdca0'));
        self._pill(self.view, w - 110, y + 35, 150, 42, 'Réclamer', 0x5fd97a, true);
        self._region(w - 190, y, w - 16, y + 70, function () {
          var r = SM.claimGift(gm.id); if (!r.ok) return self._toast('Cadeau', r.error);
          self._toast('🎁 Cadeau reçu', '+' + r.amount + ' 💎 de ' + r.name); self._drawTabs(); self._render();
        });
        y += 80;
      });
      y += 10;
      self.view.add(self._txt(24, y, '⭐ MES AMIS (' + res.list.length + ')', 15, '#ffd166', { fontStyle: 'bold' })); y += 34;
      if (!res.list.length) { self.view.add(self._txt(w / 2, y + 30, 'Aucun ami pour l\'instant.\nOuvre la fiche d\'un joueur pour l\'ajouter.', 15, '#6b7aa0', { align: 'center' }).setOrigin(0.5, 0)); y += 100; }
      res.list.forEach(function (p) { self._playerRow(p, y); y += 96; });
      self._endList(y + 20);
    });
  }
};
