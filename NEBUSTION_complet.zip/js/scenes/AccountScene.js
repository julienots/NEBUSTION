/**
 * NEBUSTION - AccountScene
 * Écran « Compte » (ouvert depuis le panneau ⚙ Paramètres, présent sur toute scène avec HUD) :
 * connexion / création de compte (e-mail + mot de passe, via NEBUSTION.CloudSave = Firebase),
 * statut connecté (synchronisation manuelle, déconnexion), et résolution de conflit quand un
 * appareil ET un compte ont chacun leur propre progression.
 *
 * Phaser ne fournit pas de vrai champ de texte : les champs e-mail/mot de passe sont de vrais
 * <input> DOM superposés au canvas (voir _field/_layoutFields), repositionnés à chaque
 * redimensionnement et retirés à la fermeture de l'écran.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.AccountScene = class AccountScene extends Phaser.Scene {
  constructor() { super('AccountScene'); }

  init(data) {
    this.returnTo = (data && data.returnTo) || 'PlanetScene';
    this.mode = 'status';   // 'status' | 'login' | 'signup' | 'conflict'
    this.busy = false;
    this._fields = {};
    this._offAuth = null;
  }

  create() {
    var self = this, w = this.scale.width, h = this.scale.height;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(250, 5, 7, 15);
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });
    this.fx = new NEBUSTION.FX(this);

    this._txt(w / 2, 136, 'COMPTE', 29, '#eaf2ff', { fontStyle: '900' }).setOrigin(0.5).setDepth(50).setShadow(0, 0, '#00e5ff', 12, true, true);
    this._txt(w / 2, 172, 'Ta progression, toujours disponible', 16, '#8e9cc0').setOrigin(0.5).setDepth(50);

    this.content = this.add.container(0, 0).setDepth(50);

    // Champs DOM (créés une fois, affichés/masqués/repositionnés selon l'écran courant)
    this._fields.email = this._field('email', 'Adresse e-mail', 'email');
    this._fields.pass = this._field('pass', 'Mot de passe (6 car. min.)', 'password');
    this._fields.pass2 = this._field('pass2', 'Confirme le mot de passe', 'password');

    var backBtn = new NEBUSTION.Button(this, 96, h - 64, {
      width: 148, height: 52, label: '← Retour', accentColor: 0x394869, fontSize: '17px',
      onClick: function () { self._close(); }
    });
    backBtn.setDepth(60);

    this.hud = NEBUSTION.HUD.attach(this);

    if (NEBUSTION.CloudSave && NEBUSTION.CloudSave.isReady()) {
      this._offAuth = NEBUSTION.CloudSave.onAuthChange(function () { if (self.mode === 'status') self._renderStatus(); });
      this._offConflict = NEBUSTION.CloudSave.onConflict(function () { if (self.mode === 'status') self._renderStatus(); });
    }

    this.scale.on('resize', this._layoutFields, this);
    this.events.once('shutdown', this._onShutdown, this);

    this._renderStatus();
  }

  // ---------- Utilitaires texte ----------
  _txt(x, y, str, size, color, extra) {
    var st = { fontFamily: 'Arial, sans-serif', fontSize: size + 'px', color: color || '#eaf2ff', resolution: 2 };
    if (extra) Object.keys(extra).forEach(function (k) { st[k] = extra[k]; });
    return this.add.text(x, y, str, st);
  }

  // ---------- Champs DOM ----------
  _field(id, placeholder, type) {
    var el = document.createElement('input');
    el.className = 'nebu-field';
    el.type = type; el.placeholder = placeholder;
    el.autocomplete = type === 'email' ? 'email' : 'current-password';
    el.style.display = 'none';
    document.body.appendChild(el);
    return el;
  }

  /** Convertit un rectangle en coordonnées de jeu (720×1280) vers des pixels CSS réels
   *  (le canvas est redimensionné/centré par Phaser Scale.FIT). */
  _domRect(gx, gy, gw, gh) {
    var canvas = this.sys.game.canvas, rect = canvas.getBoundingClientRect();
    var sx = rect.width / this.scale.width, sy = rect.height / this.scale.height;
    return { left: rect.left + gx * sx, top: rect.top + gy * sy, width: gw * sx, height: gh * sy, fontSize: Math.max(12, 15 * sx) };
  }

  _layoutFields() {
    var w = this.scale.width, FW = w - 120, FH = 58, FX = 60;
    var show = {};
    if (this.mode === 'login') { show.email = 420; show.pass = 492; }
    else if (this.mode === 'signup') { show.email = 396; show.pass = 464; show.pass2 = 532; }
    var self = this;
    ['email', 'pass', 'pass2'].forEach(function (id) {
      var el = self._fields[id];
      if (!el) return;
      if (show[id] !== undefined) {
        var r = self._domRect(FX, show[id] - FH / 2, FW, FH);
        el.style.left = r.left + 'px'; el.style.top = r.top + 'px';
        el.style.width = r.width + 'px'; el.style.height = r.height + 'px';
        el.style.fontSize = r.fontSize + 'px';
        el.style.display = 'block';
      } else {
        el.style.display = 'none';
      }
    });
  }

  // ---------- Écran : statut (connecté / invité) ----------
  _renderStatus() {
    var self = this, w = this.scale.width, CS = NEBUSTION.CloudSave;
    this.mode = 'status';
    this.content.removeAll(true);
    this._layoutFields();

    if (NEBUSTION.AdminMode && NEBUSTION.AdminMode.isActive()) {
      this.content.add(this._txt(w / 2, 220, '🛠 Mode Atelier actif — ouvre-le depuis \u2699 Param\u00e8tres', 13, '#7dffb0', { align: 'center', wordWrap: { width: w - 100 } }).setOrigin(0.5));
    }

    if (!CS || !CS.isReady()) {
      if (CS && !CS.isConfigured()) {
        this.content.add(this._txt(w / 2, 380, 'La sauvegarde en ligne n\u2019est pas encore\nconfigur\u00e9e pour cette version du jeu.', 18, '#ffb27a', { align: 'center', wordWrap: { width: w - 100 } }).setOrigin(0.5));
        this.content.add(this._txt(w / 2, 470, 'Ta progression reste sauvegard\u00e9e normalement\nsur cet appareil (hors ligne).', 15, '#8e9cc0', { align: 'center', wordWrap: { width: w - 100 } }).setOrigin(0.5));
        return;
      }
      var lastEmail = CS && CS.lastKnownEmail && CS.lastKnownEmail();
      if (lastEmail) {
        this.content.add(this._txt(w / 2, 356, 'Connect\u00e9 (hors ligne)', 18, '#8fdca0', { fontStyle: 'bold' }).setOrigin(0.5));
        this.content.add(this._txt(w / 2, 392, lastEmail, 19, '#eaf2ff', { fontStyle: 'bold', wordWrap: { width: w - 100 } }).setOrigin(0.5));
        this.content.add(this._txt(w / 2, 452, 'Pas de connexion internet pour le moment : tu peux\ncontinuer \u00e0 jouer normalement, rien n\u2019est perdu.\nLa sauvegarde en ligne reprendra d\u00e8s le retour du r\u00e9seau.', 15, '#8e9cc0', { align: 'center', wordWrap: { width: w - 100 } }).setOrigin(0.5));
      } else {
        this.content.add(this._txt(w / 2, 380, 'Pas de connexion internet pour le moment.', 18, '#ffb27a', { align: 'center', wordWrap: { width: w - 100 } }).setOrigin(0.5));
        this.content.add(this._txt(w / 2, 470, 'Ta progression reste sauvegard\u00e9e normalement\nsur cet appareil (hors ligne).', 15, '#8e9cc0', { align: 'center', wordWrap: { width: w - 100 } }).setOrigin(0.5));
      }
      return;
    }

    var user = CS.currentUser();
    if (user && CS.getPendingConflict()) { this._renderConflict(CS.getPendingConflict()); return; }   // un choix est attendu : rien n'est envoyé d'ici là
    if (user) {
      this.content.add(this._txt(w / 2, 372, 'Connect\u00e9', 18, '#8fdca0', { fontStyle: 'bold' }).setOrigin(0.5));
      this.content.add(this._txt(w / 2, 408, user.email, 21, '#eaf2ff', { fontStyle: 'bold', wordWrap: { width: w - 100 } }).setOrigin(0.5));
      this.content.add(this._txt(w / 2, 452, 'Ta sauvegarde est automatiquement\nenvoy\u00e9e en ligne.', 15, '#8e9cc0', { align: 'center' }).setOrigin(0.5));
      var ls = CS.getLastSync(), lsTxt, lsCol = '#8e9cc0';
      if (ls.ok === false) { lsTxt = 'Dernier envoi \u00e9chou\u00e9 : ' + (ls.error || 'erreur') + '\nTa progression reste sauvegard\u00e9e sur l\u2019appareil.'; lsCol = '#ffb27a'; }
      else if (ls.ok && ls.at) { lsTxt = 'Derni\u00e8re sauvegarde en ligne : ' + this._fmtDate(ls.at); lsCol = '#8fdca0'; }
      else if (!CS.isGateOpen()) { lsTxt = 'Pas encore synchronis\u00e9 : touche \u00ab Synchroniser maintenant \u00bb.'; lsCol = '#ffd166'; }
      else { lsTxt = 'Pas encore d\u2019envoi depuis l\u2019ouverture du jeu.'; }
      this.content.add(this._txt(w / 2, 506, lsTxt, 14, lsCol, { align: 'center', wordWrap: { width: w - 100 } }).setOrigin(0.5));

      this.content.add(new NEBUSTION.Button(this, w / 2, 560, {
        width: w - 120, height: 60, label: 'Synchroniser maintenant', accentColor: 0x00e5ff,
        onClick: function () { self._manualSync(); }
      }));
      this.content.add(new NEBUSTION.Button(this, w / 2, 636, {
        width: w - 120, height: 60, label: 'Se d\u00e9connecter', accentColor: 0x394869,
        onClick: function () {
          CS.signOut().then(function () { self.fx.toast('D\u00e9connect\u00e9', null, null); self._renderStatus(); });
        }
      }));
    } else {
      this.content.add(this._txt(w / 2, 372, 'Invit\u00e9', 18, '#ffd166', { fontStyle: 'bold' }).setOrigin(0.5));
      this.content.add(this._txt(w / 2, 412, 'Cr\u00e9e un compte pour ne jamais perdre ta\nprogression, m\u00eame en changeant de t\u00e9l\u00e9phone.', 15, '#8e9cc0', { align: 'center', wordWrap: { width: w - 100 } }).setOrigin(0.5));

      this.content.add(new NEBUSTION.Button(this, w / 2, 512, {
        width: w - 120, height: 60, label: 'Se connecter', accentColor: 0x00e5ff,
        onClick: function () { self._renderAuthForm('login'); }
      }));
      this.content.add(new NEBUSTION.Button(this, w / 2, 588, {
        width: w - 120, height: 60, label: 'Cr\u00e9er un compte', accentColor: 0x2fbf6a,
        onClick: function () { self._renderAuthForm('signup'); }
      }));
    }
  }

  // ---------- Écran : formulaire connexion / inscription ----------
  _renderAuthForm(mode) {
    var self = this, w = this.scale.width;
    this.mode = mode;
    this.content.removeAll(true);
    this._fields.email.value = ''; this._fields.pass.value = ''; this._fields.pass2.value = '';
    this._layoutFields();

    this.content.add(this._txt(w / 2, 344, mode === 'login' ? 'Se connecter' : 'Cr\u00e9er un compte', 20, '#eaf2ff', { fontStyle: '900' }).setOrigin(0.5));

    var submitY = mode === 'login' ? 566 : 610;
    this.content.add(new NEBUSTION.Button(this, w / 2, submitY, {
      width: w - 120, height: 60, label: mode === 'login' ? 'Se connecter' : 'Cr\u00e9er le compte', accentColor: 0x00e5ff,
      onClick: function () { self._submitAuthForm(mode); }
    }));

    var y2 = submitY + 74;
    this.content.add(new NEBUSTION.Button(this, w / 2, y2, {
      width: w - 120, height: 50, label: mode === 'login' ? 'Cr\u00e9er un compte \u00e0 la place' : 'J\u2019ai d\u00e9j\u00e0 un compte', accentColor: 0x394869, fontSize: '16px',
      onClick: function () { self._renderAuthForm(mode === 'login' ? 'signup' : 'login'); }
    }));

    var y3 = y2 + 62;
    if (mode === 'login') {
      this.content.add(new NEBUSTION.Button(this, w / 2, y3, {
        width: w - 120, height: 44, label: 'Mot de passe oubli\u00e9 ?', accentColor: 0x394869, fontSize: '15px',
        onClick: function () { self._forgotPassword(); }
      }));
      y3 += 60;
    }
    this.content.add(new NEBUSTION.Button(this, w / 2, y3, {
      width: w - 120, height: 44, label: 'Annuler', accentColor: 0x394869, fontSize: '15px',
      onClick: function () { self._renderStatus(); }
    }));
  }

  _submitAuthForm(mode) {
    var self = this, CS = NEBUSTION.CloudSave;
    if (this.busy) return;
    var email = (this._fields.email.value || '').trim();
    var pass = this._fields.pass.value || '';
    var pass2 = this._fields.pass2.value || '';

    // Compte Atelier local (Admin / Admin) : déverrouille les outils de création (voir
    // js/data/AdminMode.js). Ne passe jamais par Firebase, purement local à cet appareil,
    // et disponible uniquement depuis l'écran de connexion (pas la création de compte).
    if (mode === 'login' && NEBUSTION.AdminMode && NEBUSTION.AdminMode.checkCredentials(email, pass)) {
      NEBUSTION.AdminMode.setActive(true);
      this.fx.toast('Mode Atelier déverrouillé', 'Accessible depuis \u2699 Param\u00e8tres', null);
      return this._renderStatus();
    }

    if (!email || !pass) return this.fx.toast('Champs manquants', 'Renseigne ton e-mail et ton mot de passe', null);
    if (mode === 'signup' && pass !== pass2) return this.fx.toast('Les mots de passe ne correspondent pas', null, null);
    if (pass.length < 6) return this.fx.toast('Mot de passe trop court', '6 caract\u00e8res minimum', null);
    this.busy = true;
    var task = mode === 'login' ? CS.signIn(email, pass) : CS.signUp(email, pass);
    task.then(function () {
      self.busy = false;
      self.fx.toast(mode === 'login' ? 'Connect\u00e9' : 'Compte cr\u00e9\u00e9', null, null);
      self._afterAuthSuccess();
    }).catch(function (err) {
      self.busy = false;
      self.fx.toast(mode === 'login' ? 'Connexion impossible' : 'Inscription impossible', err && err.message, null);
    });
  }

  _forgotPassword() {
    var self = this, email = (this._fields.email.value || '').trim();
    if (!email) return this.fx.toast('Renseigne ton e-mail', 'Puis retente \u00ab\u00a0Mot de passe oubli\u00e9\u00a0\u00bb', null);
    NEBUSTION.CloudSave.resetPassword(email).then(function () {
      self.fx.toast('E-mail envoy\u00e9', 'V\u00e9rifie ta bo\u00eete de r\u00e9ception', null);
    }).catch(function (err) { self.fx.toast('Envoi impossible', err && err.message, null); });
  }

  _fmtDate(t) {
    var d = new Date(t), p = function (n) { return (n < 10 ? '0' : '') + n; };
    return p(d.getDate()) + '/' + p(d.getMonth() + 1) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  }
  _fmtSummary(sm) {
    var h = Math.floor(sm.playSec / 3600), m = Math.floor((sm.playSec % 3600) / 60);
    return (h ? h + ' h ' : '') + m + ' min de jeu \u00b7 ' + sm.stars + ' \u2605 \u00b7 b\u00e2timents niv. ' + sm.buildingLevels + ' \u00b7 ' + sm.conquered + ' conqu\u00eate(s)\nSauvegard\u00e9 le ' + (sm.savedAt ? this._fmtDate(sm.savedAt) : '?');
  }

  /** Compare l'appareil et le compte (connexion, ou « Synchroniser » quand les envois sont bloqués) puis agit :
   *  envoi, restauration du compte ou écran de choix. Ne perd jamais de progression en silence. */
  _reconcile() {
    var self = this, CS = NEBUSTION.CloudSave, R = NEBUSTION.Resources;
    var baseline = (R.loadInfo && R.loadInfo.state && Number(R.loadInfo.state.savedAt)) || 0;
    CS.sync(R.state, { baseline: baseline, isNew: R.isNewGame, atStart: false }).then(function (res) {
      if (res.action === 'adopted') return self._reloadSoon('Sauvegarde du compte restaur\u00e9e\u2026');
      if (res.action === 'conflict') return self._renderConflict(res.cloud);
      if (res.action === 'pushed') self.fx.toast('Sauvegarde envoy\u00e9e', '\u00c0 jour sur ton compte', null);
      else self.fx.toast('Synchronisation impossible', 'V\u00e9rifie ta connexion puis r\u00e9essaie', null);
      self._renderStatus();
    });
  }

  /** Après connexion/inscription réussie. */
  _afterAuthSuccess() { this._reconcile(); }

  // ---------- Écran : conflit (deux parties différentes : appareil ET compte) ----------
  _renderConflict(cloud) {
    var self = this, w = this.scale.width, R = NEBUSTION.Resources, CS = NEBUSTION.CloudSave;
    this.mode = 'conflict';
    this.content.removeAll(true);
    this._layoutFields();
    var loc = CS.summarize(R.state), cl = CS.summarize(cloud);

    this.content.add(this._txt(w / 2, 300, 'Deux parties trouv\u00e9es', 22, '#ffd166', { fontStyle: '900', align: 'center' }).setOrigin(0.5));
    this.content.add(this._txt(w / 2, 344, 'Rien n\u2019est envoy\u00e9 ni effac\u00e9 tant que tu n\u2019as pas choisi.', 14, '#c9d4ea', { align: 'center', wordWrap: { width: w - 100 } }).setOrigin(0.5));

    this.content.add(this._txt(w / 2, 400, 'CET APPAREIL', 15, '#8fdca0', { fontStyle: 'bold' }).setOrigin(0.5));
    this.content.add(this._txt(w / 2, 448, this._fmtSummary(loc), 15, '#eaf2ff', { align: 'center', wordWrap: { width: w - 100 } }).setOrigin(0.5));
    this.content.add(new NEBUSTION.Button(this, w / 2, 524, {
      width: w - 120, height: 60, label: 'Garder cet appareil', accentColor: 0x2fbf6a, fontSize: '17px',
      onClick: function () {
        CS.keepLocal(R.state).then(function (ok) {
          self.fx.toast(ok ? 'Partie de l\u2019appareil conserv\u00e9e' : 'Envoi \u00e9chou\u00e9', ok ? 'Envoy\u00e9e sur ton compte' : 'V\u00e9rifie ta connexion', null);
          self._renderStatus();
        });
      }
    }));

    this.content.add(this._txt(w / 2, 606, 'PARTIE DU COMPTE', 15, '#00e5ff', { fontStyle: 'bold' }).setOrigin(0.5));
    this.content.add(this._txt(w / 2, 654, this._fmtSummary(cl), 15, '#eaf2ff', { align: 'center', wordWrap: { width: w - 100 } }).setOrigin(0.5));
    this.content.add(new NEBUSTION.Button(this, w / 2, 730, {
      width: w - 120, height: 60, label: 'Utiliser la partie du compte', accentColor: 0x00e5ff, fontSize: '17px',
      onClick: function () { if (CS.useCloud()) self._reloadSoon('Sauvegarde du compte restaur\u00e9e\u2026'); }
    }));
    this.content.add(this._txt(w / 2, 800, 'Celle que tu ne gardes pas est effac\u00e9e.\n(L\u2019ancienne partie de l\u2019appareil est tout de m\u00eame\nconserv\u00e9e en copie de secours sur cet appareil.)', 13, '#8e9cc0', { align: 'center', wordWrap: { width: w - 100 } }).setOrigin(0.5));
  }

  _reloadSoon(msg) {
    var w = this.scale.width, h = this.scale.height;
    this.content.removeAll(true);
    this._layoutFields();
    this.content.add(this._txt(w / 2, h / 2, msg, 20, '#eaf2ff', { fontStyle: 'bold', align: 'center', wordWrap: { width: w - 100 } }).setOrigin(0.5));
    this.time.delayedCall(700, function () { window.location.reload(); });
  }

  // ---------- Synchronisation manuelle (déjà connecté) ----------
  _manualSync() {
    var self = this, CS = NEBUSTION.CloudSave;
    if (CS.getPendingConflict()) return this._renderConflict(CS.getPendingConflict());
    this.fx.toast('Synchronisation\u2026', null, null);
    if (!CS.isGateOpen()) return this._reconcile();   // envois bloqués (lecture impossible au démarrage) : on refait la comparaison d'abord
    CS.pushSave(NEBUSTION.Resources.state, { force: true }).then(function (ok) {
      if (CS.getPendingConflict()) return;   // un autre appareil a joué entre-temps : l'écran de choix s'affiche
      self.fx.toast(ok ? 'Sauvegarde envoy\u00e9e' : 'Envoi \u00e9chou\u00e9', ok ? '\u00c0 jour sur ton compte' : 'V\u00e9rifie ta connexion', null);
      self._renderStatus();
    });
  }

  // ---------- Fermeture / nettoyage ----------
  _close() {
    var self = this;
    this.cameras.main.fadeOut(200, 5, 7, 15);
    this.cameras.main.once('camerafadeoutcomplete', function () { self.scene.start(self.returnTo); });
  }

  _onShutdown() {
    var self = this;
    ['email', 'pass', 'pass2'].forEach(function (id) {
      var el = self._fields[id];
      if (el && el.parentNode) el.parentNode.removeChild(el);
    });
    if (this._offAuth) this._offAuth();
    if (this._offConflict) this._offConflict();
    this.scale.off('resize', this._layoutFields, this);
  }
};
