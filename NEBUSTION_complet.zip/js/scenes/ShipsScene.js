/**
 * NEBUSTION - ShipsScene
 * Première version (réduite) du module Vaisseaux : hangar (jusqu'à 3 vaisseaux en flotte),
 * acquisition, amélioration. La flotte sélectionnée applique un bonus en pourcentage à toute
 * l'équipe de héros en combat (voir ShipManager.fleetBonus + CombatManager.combinedBonus).
 * Accessible depuis CombatPrepScene (bouton "Flotte").
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.ShipsScene = class ShipsScene extends Phaser.Scene {
  constructor() { super('ShipsScene'); }

  create() {
    var w = this.scale.width, h = this.scale.height;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(250, 5, 7, 15);
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });

    this.add.text(w / 2, 96, 'FLOTTE', {
      fontFamily: 'Arial, sans-serif', fontSize: '24px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(50).setShadow(0, 0, '#00e5ff', 10, true, true);

    this.add.text(w / 2, 126, 'Jusqu\'à 3 vaisseaux actifs · bonus appliqué à toute l\'équipe', {
      fontFamily: 'Arial, sans-serif', fontSize: '12px', color: '#7a89ad'
    }).setOrigin(0.5).setDepth(50);

    var backBtn = this.add.text(28, 126, '‹ Retour', {
      fontFamily: 'Arial, sans-serif', fontSize: '16px', color: '#00e5ff'
    }).setOrigin(0, 0.5).setDepth(60).setInteractive({ useHandCursor: true });
    backBtn.on('pointerdown', () => this.scene.start('CombatPrepScene'));

    // Accès aux skins de vaisseaux (module Personnalisation).
    var skinsBtn = this.add.text(w - 28, 126, 'Skins ›', {
      fontFamily: 'Arial, sans-serif', fontSize: '16px', fontStyle: 'bold', color: '#b47bff'
    }).setOrigin(1, 0.5).setDepth(60).setInteractive({ useHandCursor: true });
    skinsBtn.on('pointerdown', () => this.scene.start('SkinsScene', { tab: 'ship', from: 'ShipsScene' }));

    this.craftY = 156;
    this._buildAcquireRow();

    this.listTop = this.craftY + 84;
    this.listBottom = h - 24;
    this._buildHangar();

    this.hud = NEBUSTION.HUD.attach(this);
  }

  // ---------- Acquisition rapide (vaisseau commun, coût en cristal/énergie) ----------
  _buildAcquireRow() {
    var self = this, w = this.scale.width, SH = NEBUSTION.Ships;
    this.add.text(24, this.craftY - 14, 'Acquérir (commun) :', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#7a89ad'
    }).setDepth(40);

    var n = SH.CLASS_ORDER.length;
    var slotW = (w - 24 - (n - 1) * 8) / n;
    SH.CLASS_ORDER.forEach(function (classId, i) {
      var cls = SH.CLASS_INDEX[classId];
      var x = 12 + slotW / 2 + i * (slotW + 8);
      var cost = SH.acquireCost('commun');
      var btn = new NEBUSTION.Button(self, x, self.craftY + 26, {
        width: slotW - 4, height: 54, fontSize: '11px', accentColor: 0x4fd1ff,
        label: cls.name,
        onClick: function () {
          var res = NEBUSTION.ShipManager.acquire(classId, 'commun');
          if (res.ok) self._refresh(); else self._toast(res.reason === 'ressources' ? 'Ressources insuffisantes' : 'Erreur');
        }
      }).setDepth(45);
      if (btn.labelText) btn.labelText.y -= 8;
      var im1 = self.add.image(-16, 17, 'tex_icon_crystal').setDisplaySize(16, 16);
      var t1 = self.add.text(-6, 17, String(cost.crystal), { fontFamily: 'Arial, sans-serif', fontSize: '11px', fontStyle: 'bold', color: '#c8d4f0' }).setOrigin(0, 0.5);
      var im2 = self.add.image(t1.x + t1.width + 12, 17, 'tex_icon_energy').setDisplaySize(16, 16);
      var t2 = self.add.text(im2.x + 10, 17, String(cost.energy), { fontFamily: 'Arial, sans-serif', fontSize: '11px', fontStyle: 'bold', color: '#c8d4f0' }).setOrigin(0, 0.5);
      btn.add([im1, t1, im2, t2]);
    });
  }

  // ---------- Hangar (liste des vaisseaux possédés) ----------
  _buildHangar() {
    var self = this, w = this.scale.width;
    this.listContainer = this.add.container(0, this.listTop).setDepth(40);
    this._refreshList();

    var viewH = this.listBottom - this.listTop;
    this.listMaskGfx = this.make.graphics();
    this.listMaskGfx.fillRect(0, this.listTop, w, viewH);
    this.listContainer.setMask(this.listMaskGfx.createGeometryMask());

    var dragging = false, startY = 0, startScroll = 0;
    var zone = this.add.zone(0, this.listTop, w, viewH).setOrigin(0).setInteractive().setDepth(41);
    zone.on('pointerdown', function (p) { dragging = true; startY = p.y; startScroll = self.scrollY || 0; });
    this.input.on('pointermove', function (p) {
      if (!dragging) return;
      self.scrollY = Phaser.Math.Clamp(startScroll - (p.y - startY), 0, self.maxScroll || 0);
      self.listContainer.y = self.listTop - self.scrollY;
    });
    this.input.on('pointerup', function () { dragging = false; });
    this.input.on('pointerupoutside', function () { dragging = false; });
  }

  _refreshList() {
    var self = this, w = this.scale.width, SH = NEBUSTION.Ships, SM = NEBUSTION.ShipManager;
    this.listContainer.removeAll(true);

    var ships = SM.list().sort(function (a, b) {
      return SH.RARITIES[b.rarity].order - SH.RARITIES[a.rarity].order || b.level - a.level;
    });

    if (!ships.length) {
      this.listContainer.add(this.add.text(w / 2, 30, 'Aucun vaisseau pour le moment. Acquérez-en un ci-dessus.', {
        fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#7a89ad', align: 'center', wordWrap: { width: w - 60 }
      }).setOrigin(0.5, 0));
      this.maxScroll = 0;
      return;
    }

    var rowH = 92, gap = 8;
    ships.forEach(function (ship, i) {
      var row = self._buildShipRow(ship, w, rowH, SH, SM);
      row.y = i * (rowH + gap);
      self.listContainer.add(row);
    });

    var viewH = this.listBottom - this.listTop;
    this.maxScroll = Math.max(0, ships.length * (rowH + gap) - viewH);
    this.scrollY = Math.min(this.scrollY || 0, this.maxScroll);
    this.listContainer.y = this.listTop - this.scrollY;
  }

  _buildShipRow(ship, w, rowH, SH, SM) {
    var self = this;
    var rarity = SH.RARITIES[ship.rarity];
    var cls = SH.CLASS_INDEX[ship.classId];
    var inFleet = SM.isInFleet(ship.uid);
    var row = this.add.container(0, 0);

    var bg = this.add.graphics();
    bg.fillStyle(0x121a30, 0.9);
    bg.fillRoundedRect(12, 0, w - 24, rowH - 8, 12);
    bg.lineStyle(1.5, rarity.color, inFleet ? 0.95 : 0.5);
    bg.strokeRoundedRect(12, 0, w - 24, rowH - 8, 12);
    row.add(bg);

    // Icône vectorielle du vaisseau, avec son skin équipé (module Personnalisation).
    var shipSkin = NEBUSTION.SkinManager && NEBUSTION.SkinManager.equippedSkin('ship', ship.uid);
    var icon = NEBUSTION.SkinFX.drawShip(this, ship.classId, shipSkin, 52, rarity.color);
    icon.setPosition(58, (rowH - 8) / 2);
    row.add(icon);
    if (shipSkin) NEBUSTION.SkinFX.attach(this, row, icon, shipSkin, 70, 70, { light: true });

    row.add(this.add.text(96, 12, SH.shipName(ship.classId, ship.rarity), {
      fontFamily: 'Arial, sans-serif', fontSize: '14px', fontStyle: 'bold', color: rarity.hex
    }));
    row.add(this.add.text(96, 34, 'Niveau ' + ship.level + '/' + SH.MAX_LEVEL + (inFleet ? '  ·  dans la flotte' : ''), {
      fontFamily: 'Arial, sans-serif', fontSize: '11.5px', color: inFleet ? '#5fd97a' : '#7a89ad'
    }));

    var bonus = SH.bonusFor(ship.classId, ship.rarity, ship.level);
    var bonusStr = Object.keys(bonus).map(function (k) { return '+' + Math.round(bonus[k] * 1000) / 10 + '% ' + k; }).join('  ');
    row.add(this.add.text(96, 54, cls.desc.split(' : ')[0] + ' — ' + bonusStr, {
      fontFamily: 'Arial, sans-serif', fontSize: '11px', color: '#9aa5c0', wordWrap: { width: w - 268 }
    }));

    var btnX = w - 32;
    var fleetLabel = inFleet ? 'Retirer' : (SM.getFleet().length >= SH.FLEET_MAX ? 'Flotte pleine' : 'Ajouter');
    var fleetBtn = this.add.text(btnX, 22, fleetLabel, {
      fontFamily: 'Arial, sans-serif', fontSize: '12px', fontStyle: 'bold',
      color: inFleet ? '#ff6b6b' : (SM.getFleet().length >= SH.FLEET_MAX ? '#4a5578' : '#00e5ff')
    }).setOrigin(1, 0.5);
    if (inFleet || SM.getFleet().length < SH.FLEET_MAX) {
      fleetBtn.setInteractive({ useHandCursor: true });
      fleetBtn.on('pointerdown', function () { NEBUSTION.ShipManager.toggleFleet(ship.uid); self._refresh(); });
    }
    row.add(fleetBtn);

    var upCost = SH.upgradeCost(ship.rarity, ship.level);
    var upBtn = this.add.text(btnX, 46, ship.level >= SH.MAX_LEVEL ? 'Niveau max' : 'Améliorer', {
      fontFamily: 'Arial, sans-serif', fontSize: '11.5px', fontStyle: 'bold',
      color: ship.level >= SH.MAX_LEVEL ? '#4a5578' : '#ffd166'
    }).setOrigin(1, 0.5);
    row.add(upBtn);
    if (ship.level < SH.MAX_LEVEL) {
      var upIcon = this.add.image(btnX - upBtn.width - 20, 46, 'tex_icon_crystal').setDisplaySize(15, 15).setOrigin(1, 0.5);
      var upCostTxt = this.add.text(upIcon.x - 4, 46, String(upCost.crystal), { fontFamily: 'Arial, sans-serif', fontSize: '11px', color: '#c8d4f0' }).setOrigin(1, 0.5);
      row.add([upIcon, upCostTxt]);
      upBtn.setInteractive({ useHandCursor: true });
      upBtn.on('pointerdown', function () {
        var res = NEBUSTION.ShipManager.upgrade(ship.uid);
        if (res.ok) self._refresh(); else self._toast('Ressources insuffisantes');
      });
    }

    return row;
  }

  _refresh() { this.scene.restart(); }

  _toast(msg) {
    var w = this.scale.width;
    var t = this.add.text(w / 2, this.scale.height - 160, msg, {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', fontStyle: 'bold', color: '#ff6b6b',
      backgroundColor: '#0a0f1e', padding: { x: 12, y: 8 }
    }).setOrigin(0.5).setDepth(500);
    this.tweens.add({ targets: t, alpha: 0, delay: 900, duration: 400, onComplete: function () { t.destroy(); } });
  }
};
