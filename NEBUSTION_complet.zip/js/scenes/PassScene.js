/**
 * NEBUSTION - PassScene
 * Pass de saison (étape 8) : bannière de saison + compte à rebours, niveau/XP Pass, deux onglets
 * « Récompenses » (30 niveaux, piste gratuite à gauche / piste Premium à droite) et « Missions »
 * (quotidiennes + hebdomadaires). Cartes d'objets avec effets de rareté, animation de déblocage plein écran.
 * Toute la logique vient de NEBUSTION.Pass (données) + NEBUSTION.PassManager (état) ; l'achat du Premium
 * passe par NEBUSTION.PassBilling (aucun paiement réel/simulé : voir ce fichier).
 *
 * Entrées : UNE seule zone gère le glissement ET le tap sur la liste (comme ShopScene) ; les cartes et
 * boutons de la liste ne sont pas interactifs, ils déclarent des zones de tap (this._hits).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.PassScene = class PassScene extends Phaser.Scene {
  constructor() { super('PassScene'); }

  init(data) {
    this.tab = (data && data.tab === 'missions') ? 'missions' : 'rewards';
    this.scrollY = 0;
    this.maxScroll = 0;
    this._hits = [];
    this._fxTweens = [];
    this._hdrTweens = [];
    this._overlay = null;
    this._cdText = null;
    this._firstOpen = true;
    this._autoScroll = true;   // à l'ouverture : la liste se place sur le niveau en cours
    this._activeRows = {};     // lignes de récompenses actuellement construites (défilement virtualisé)
    this._rwRangeKey = null;
  }

  create() {
    var w = this.scale.width, h = this.scale.height;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(250, 5, 7, 15);
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });
    this.fx = new NEBUSTION.FX(this);
    this.PM = NEBUSTION.PassManager;
    this.P = NEBUSTION.Pass;
    try { this.PM.touch(); } catch (e) { /* ignore */ }
    this._seasonNumber = this.PM.season().number;

    this._txt(24, 136, 'PASS DE SAISON', 29, '#eaf2ff', { fontStyle: '900' }).setOrigin(0, 0.5).setDepth(50).setShadow(0, 0, '#ffd166', 12, true, true);

    this.hdr = this.add.container(0, 0).setDepth(50);
    this.tabsY = 372;
    this.stripY = 420;
    this.listTop = 444;
    this.listBottom = h - 128;
    this.stripC = this.add.container(0, this.stripY).setDepth(46);
    this.tabsBar = this.add.container(0, this.tabsY).setDepth(47);
    this.listContainer = this.add.container(0, this.listTop).setDepth(40);
    this.listMaskGfx = this.make.graphics();
    this.listContainer.setMask(this.listMaskGfx.createGeometryMask());
    this._buildScroll();

    this._buildHeader();
    this._buildTabs();
    this._render(true);
    this.hud = NEBUSTION.HUD.attach(this);
    new NEBUSTION.BottomNav(this, 'pass');

    var self = this;
    this.time.addEvent({ delay: 1000, loop: true, callback: function () { self._tick(); } });
    this._tick();
  }

  // ---------- Utilitaires ----------
  _txt(x, y, str, size, color, extra) {
    var st = { fontFamily: 'Arial, sans-serif', fontSize: size + 'px', color: color || '#eaf2ff', resolution: 2 };
    if (extra) Object.keys(extra).forEach(function (k) { st[k] = extra[k]; });
    return this.add.text(x, y, str, st);
  }
  _image(x, y, key) { return this.textures.exists(key) ? this.add.image(x, y, key) : null; }
  _fitWidth(t, maxW) { var tw = t.width || 0; if (tw > maxW && tw > 0) t.setScale(maxW / tw); return t; }
  _loop(cfg, hdr) { var tw = this.tweens.add(cfg); (hdr ? this._hdrTweens : this._fxTweens).push(tw); return tw; }
  _stop(arr) { (arr || []).forEach(function (t) { try { if (t && t.stop) t.stop(); } catch (e) { /* ignore */ } }); }
  _mix(c1, c2, t) {
    var r = Math.round(((c1 >> 16) & 255) * t + ((c2 >> 16) & 255) * (1 - t)), g = Math.round(((c1 >> 8) & 255) * t + ((c2 >> 8) & 255) * (1 - t)), b = Math.round((c1 & 255) * t + (c2 & 255) * (1 - t));
    return (r << 16) | (g << 8) | b;
  }
  _rar(id) { return this.P.RARITIES[id] || this.P.RARITIES.commun; }
  _fmtCountdown(ms) {
    ms = Math.max(0, Math.floor(ms / 1000));
    var d = Math.floor(ms / 86400), hh = Math.floor((ms % 86400) / 3600), mm = Math.floor((ms % 3600) / 60), ss = ms % 60;
    var p = function (n) { return (n < 10 ? '0' : '') + n; };
    return d > 0 ? d + 'j ' + p(hh) + 'h ' + p(mm) + 'm' : p(hh) + ':' + p(mm) + ':' + p(ss);
  }
  _fmt(n) { return NEBUSTION.Economy.fmt(n); }

  _drawGem(g, x, y, r, color) {
    g.fillStyle(color, 1); g.fillTriangle(x, y - r, x - r, y - r * 0.15, x + r, y - r * 0.15);
    g.fillStyle(color, 0.7); g.fillTriangle(x - r, y - r * 0.15, x + r, y - r * 0.15, x, y + r);
    g.lineStyle(Math.max(1.5, r * 0.08), 0xffffff, 0.55);
    g.lineBetween(x - r, y - r * 0.15, x + r, y - r * 0.15); g.lineBetween(x, y - r, x, y + r);
  }
  _drawLock(g, x, y, s, color, alpha) {
    g.fillStyle(color, alpha); g.fillRoundedRect(x - 8 * s, y - 2 * s, 16 * s, 12 * s, 3 * s);
    g.lineStyle(2.4 * s, color, alpha); g.strokeCircle(x, y - 4 * s, 5 * s);
  }
  _drawCheck(g, x, y, s, color) {
    g.lineStyle(4 * s, color, 1); g.lineBetween(x - 7 * s, y, x - 2 * s, y + 6 * s); g.lineBetween(x - 2 * s, y + 6 * s, x + 8 * s, y - 6 * s);
  }
  _drawCrown(g, x, y, s, color) {
    g.fillStyle(color, 1);
    g.fillTriangle(x - 12 * s, y + 8 * s, x - 12 * s, y - 8 * s, x - 3 * s, y + 8 * s);
    g.fillTriangle(x - 7 * s, y + 8 * s, x, y - 12 * s, x + 7 * s, y + 8 * s);
    g.fillTriangle(x + 3 * s, y + 8 * s, x + 12 * s, y - 8 * s, x + 12 * s, y + 8 * s);
    g.fillRect(x - 12 * s, y + 8 * s, 24 * s, 4 * s);
  }

  // ---------- Bannière de saison + niveau / XP ----------
  _buildHeader() {
    var self = this, w = this.scale.width, PM = this.PM, P = this.P;
    this._stop(this._hdrTweens); this._hdrTweens = [];
    this.hdr.removeAll(true);
    var si = PM.season(), th = si.theme, lv = PM.level(), c1 = th.color, c2 = th.color2;

    // Bannière
    var bx = 12, by = 166, bw = w - 24, bh = 104;
    var g = this.add.graphics();
    g.fillGradientStyle(this._mix(c1, 0x0a1224, 0.32), this._mix(c2, 0x0a1224, 0.22), 0x0a1224, 0x0a1224, 1);
    g.fillRoundedRect(bx, by, bw, bh, 20);
    g.lineStyle(2.5, c1, 0.9); g.strokeRoundedRect(bx, by, bw, bh, 20);
    g.lineStyle(1.5, c2, 0.45); g.strokeRoundedRect(bx + 5, by + 5, bw - 10, bh - 10, 16);
    this.hdr.add(g);
    // étoiles scintillantes
    for (var i = 0; i < 7; i++) {
      var st = this.add.circle(bx + 140 + ((i * 83) % 330), by + 14 + ((i * 37) % 76), 1.6 + (i % 3) * 0.6, 0xffffff, 0.8);
      this.hdr.add(st);
      this._loop({ targets: st, alpha: 0.15, duration: 700 + i * 170, yoyo: true, repeat: -1, delay: i * 130 }, true);
    }
    // emblème (astre + anneau orbital qui tourne)
    var em = this.add.container(bx + 62, by + bh / 2);
    var eg = this.add.graphics();
    eg.fillStyle(c1, 0.16); eg.fillCircle(0, 0, 44); eg.fillStyle(c1, 0.95); eg.fillCircle(0, 0, 21); eg.fillStyle(0xffffff, 0.5); eg.fillCircle(-7, -7, 7);
    eg.lineStyle(3, c2, 0.9); eg.strokeEllipse(0, 0, 84, 26);
    em.add(eg);
    em.setAngle(-18);
    this.hdr.add(em);
    this._loop({ targets: em, scale: 1.07, duration: 1400, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' }, true);

    this.hdr.add(this._txt(bx + 122, by + 24, 'Saison ' + si.number, 22, '#c9d4ea', { fontStyle: 'bold' }).setOrigin(0, 0.5));
    var nm = this._txt(bx + 122, by + 56, th.name, 34, '#ffffff', { fontStyle: '900' }).setOrigin(0, 0.5).setShadow(0, 0, th.hex, 14, true, true);
    this._fitWidth(nm, 330);
    this.hdr.add(nm);
    var tg = this._txt(bx + 122, by + 86, th.tagline, 17, '#a9b8dc').setOrigin(0, 0.5);
    this._fitWidth(tg, 340);
    this.hdr.add(tg);

    // Compte à rebours
    this.hdr.add(this._txt(bx + bw - 18, by + 26, 'Fin de saison', 18, '#c9d4ea').setOrigin(1, 0.5));
    this._cdText = this._txt(bx + bw - 18, by + 58, this._fmtCountdown(si.msLeft), 30, '#ffd166', { fontStyle: 'bold' }).setOrigin(1, 0.5);
    this.hdr.add(this._cdText);
    var pgW = 190, pgX = bx + bw - 18 - pgW, pgY = by + 84, pct = Math.max(0, Math.min(1, 1 - si.msLeft / si.totalMs));
    var pg = this.add.graphics();
    pg.fillStyle(0x000000, 0.5); pg.fillRoundedRect(pgX, pgY, pgW, 10, 5);
    pg.fillStyle(c2, 1); pg.fillRoundedRect(pgX, pgY, Math.max(10, pgW * pct), 10, 5);
    this.hdr.add(pg);

    // Ligne niveau + XP + « Tout réclamer »
    var ly = 314;
    var med = this.add.container(58, ly);
    var mg = this.add.graphics();
    mg.fillStyle(c1, 0.22); mg.fillCircle(0, 0, 40);
    mg.fillGradientStyle(0x24386e, 0x24386e, 0x0b1224, 0x0b1224, 1); mg.fillCircle(0, 0, 32);
    mg.lineStyle(4, c1, 1); mg.strokeCircle(0, 0, 32);
    mg.lineStyle(2, c2, 0.8); mg.strokeCircle(0, 0, 38);
    med.add(mg);
    med.add(this._txt(0, -9, 'Niveau', 14, '#a9b8dc').setOrigin(0.5));
    med.add(this._txt(0, 9, String(lv.level), 27, '#ffffff', { fontStyle: '900' }).setOrigin(0.5));
    this.hdr.add(med);
    this._loop({ targets: med, scale: 1.06, duration: 1100, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' }, true);

    var barX = 112, barW = 372, barY = ly + 6;
    this.hdr.add(this._txt(barX, ly - 20, 'XP Pass', 20, '#eaf2ff', { fontStyle: 'bold' }).setOrigin(0, 0.5));
    this.hdr.add(this._txt(barX + barW, ly - 20, lv.maxed ? 'Niveau maximum' : this._fmt(lv.into) + ' / ' + this._fmt(lv.need) + '  →  niv. ' + (lv.level + 1), 18, '#a9b8dc').setOrigin(1, 0.5));
    var bg = this.add.graphics();
    bg.fillStyle(0x000000, 0.55); bg.fillRoundedRect(barX, barY - 9, barW, 22, 11);
    bg.lineStyle(2, 0x394869, 0.9); bg.strokeRoundedRect(barX, barY - 9, barW, 22, 11);
    this.hdr.add(bg);
    var fill = this.add.graphics();
    this.hdr.add(fill);
    var drawFill = function (k) {
      fill.clear();
      var fw = Math.max(0, Math.min(1, k)) * barW;
      if (fw < 1) return;
      fw = Math.max(fw, 14);
      fill.fillGradientStyle(c1, c2, c1, c2, 1); fill.fillRoundedRect(barX, barY - 9, fw, 22, 11);
      fill.fillStyle(0xffffff, 0.22); fill.fillRoundedRect(barX + 4, barY - 6, Math.max(4, fw - 8), 6, 3);
    };
    if (this._firstOpen) {
      var ctr = this.tweens.addCounter({ from: 0, to: lv.pct, duration: 700, ease: 'Cubic.easeOut', onUpdate: function (tw) { drawFill(tw.getValue()); } });
      this._hdrTweens.push(ctr);
      drawFill(0);
    } else drawFill(lv.pct);
    this._firstOpen = false;

    // Bouton « Tout réclamer » (contextuel : récompenses ou missions selon l'onglet)
    var count = this.tab === 'rewards' ? PM.claimableList().length : PM.readyMissionCount();
    var cbx = w - 12 - 100, cby = ly, cw = 200, ch = 60, on = count > 0;
    var btn = this.add.container(cbx, cby);
    var bgg = this.add.graphics();
    bgg.fillGradientStyle(on ? 0x2fbf6a : 0x1a2233, on ? 0x2fbf6a : 0x1a2233, on ? 0x17803f : 0x11172a, on ? 0x17803f : 0x11172a, 1);
    bgg.fillRoundedRect(-cw / 2, -ch / 2, cw, ch, 18);
    bgg.lineStyle(2.5, on ? 0x9dffc0 : 0x394869, on ? 1 : 0.7); bgg.strokeRoundedRect(-cw / 2, -ch / 2, cw, ch, 18);
    btn.add(bgg);
    btn.add(this._fitWidth(this._txt(0, on ? -8 : 0, 'Tout réclamer', 22, on ? '#04140a' : '#5c6b8a', { fontStyle: '900' }).setOrigin(0.5), cw - 20));
    if (on) btn.add(this._txt(0, 14, count + (count > 1 ? ' disponibles' : ' disponible'), 15, '#0a3a1c', { fontStyle: 'bold' }).setOrigin(0.5));
    this.hdr.add(btn);
    if (on) this._loop({ targets: btn, scale: 1.05, duration: 650, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' }, true);
    var z = this.add.zone(cbx, cby, cw, ch).setInteractive({ useHandCursor: true });
    z.on('pointerup', function () { if (!self._overlay) self._onClaimAll(); });
    this.hdr.add(z);
  }

  // ---------- Onglets ----------
  _buildTabs() {
    var self = this, w = this.scale.width, gap = 8, cw = (w - 24 - gap) / 2;
    this.tabsBar.removeAll(true);
    this._tabDraw = [];
    var defs = [{ id: 'rewards', label: 'Récompenses' }, { id: 'missions', label: 'Missions' }];
    defs.forEach(function (t, i) {
      var x = 12 + cw / 2 + i * (cw + gap);
      var g = self.add.graphics();
      var label = self._txt(x, 0, t.label, 24, '#8e9cc0', { fontStyle: 'bold' }).setOrigin(0.5);
      var badge = self.add.graphics();
      var zone = self.add.zone(x, 0, cw, 52).setInteractive({ useHandCursor: true });
      zone.on('pointerup', function () {
        if (self._overlay || self.tab === t.id) return;
        self.tab = t.id; self._autoScroll = true; self._buildHeader(); self._refreshTabs(); self._render(true);
      });
      self.tabsBar.add([g, label, badge, zone]);
      self._tabDraw.push({ id: t.id, g: g, label: label, badge: badge, x: x, cw: cw });
    });
    this._refreshTabs();
  }

  _refreshTabs() {
    var self = this, PM = this.PM;
    this._tabDraw.forEach(function (t) {
      var active = self.tab === t.id;
      t.g.clear();
      t.g.fillGradientStyle(active ? 0x24386e : 0x101a33, active ? 0x24386e : 0x101a33, active ? 0x132048 : 0x0a1122, active ? 0x132048 : 0x0a1122, 0.97);
      t.g.fillRoundedRect(t.x - t.cw / 2, -26, t.cw, 52, 16);
      t.g.lineStyle(active ? 3 : 1.5, active ? 0xffd166 : 0x394869, active ? 0.95 : 0.75);
      t.g.strokeRoundedRect(t.x - t.cw / 2, -26, t.cw, 52, 16);
      t.label.setColor(active ? '#eaf2ff' : '#8e9cc0');
      var n = t.id === 'rewards' ? PM.claimableList().length : PM.readyMissionCount();
      t.badge.clear();
      if (n > 0) {
        var bx = t.x + t.cw / 2 - 22, by = -14;
        t.badge.fillStyle(0xff4d5e, 1); t.badge.fillCircle(bx, by, 14);
        t.badge.lineStyle(2, 0xffffff, 0.9); t.badge.strokeCircle(bx, by, 14);
        if (!t.badgeTxt) { t.badgeTxt = self._txt(bx, by, '', 17, '#ffffff', { fontStyle: 'bold' }).setOrigin(0.5); self.tabsBar.add(t.badgeTxt); }
        t.badgeTxt.setText(String(n)).setVisible(true).setPosition(bx, by);
      } else if (t.badgeTxt) t.badgeTxt.setVisible(false);
    });
  }

  // ---------- Défilement + tap (une seule zone) ----------
  _buildScroll() {
    var self = this, w = this.scale.width, viewH = this.listBottom - this.listTop;
    this.listMaskGfx.clear();
    this.listMaskGfx.fillStyle(0xffffff, 1);
    this.listMaskGfx.fillRect(0, this.listTop, w, viewH);
    var dragging = false, startY = 0, startScroll = 0, moved = 0;
    var zone = this.add.zone(0, this.listTop, w, viewH).setOrigin(0).setInteractive().setDepth(41);
    zone.on('pointerdown', function (p) { if (self._overlay) return; dragging = true; startY = p.y; startScroll = self.scrollY || 0; moved = 0; });
    this.input.on('pointermove', function (p) {
      if (!dragging || self._overlay) return;
      var dy = p.y - startY;
      moved = Math.max(moved, Math.abs(dy));
      self.scrollY = Math.max(0, Math.min(self.maxScroll || 0, startScroll - dy));
      self.listContainer.y = self.listTop - self.scrollY;
      self._updateVisibleRows();
    });
    zone.on('pointerup', function (p) {
      var wasTap = dragging && moved <= 14;
      dragging = false;
      if (wasTap && !self._overlay) self._onListTap(p.x, p.y);
    });
    this.input.on('pointerup', function () { dragging = false; });
    this.input.on('pointerupoutside', function () { dragging = false; });
    this.input.on('wheel', function (p, objs, dx, dy) {
      if (self._overlay) return;
      self.scrollY = Math.max(0, Math.min(self.maxScroll || 0, (self.scrollY || 0) + (dy || 0)));
      self.listContainer.y = self.listTop - self.scrollY;
      self._updateVisibleRows();
    });
  }

  _onListTap(px, py) {
    var ly = py - this.listContainer.y;
    for (var i = 0; i < this._hits.length; i++) {
      var h = this._hits[i];
      if (px >= h.x && px <= h.x + h.w && ly >= h.y && ly <= h.y + h.h) { h.fn(); return true; }
    }
    return false;
  }

  // ---------- Compte à rebours (1 s) ----------
  _tick() {
    var PM = this.PM;
    var si = PM.season();
    if (si.number !== this._seasonNumber) { this.scene.restart({ tab: this.tab }); return; }   // nouvelle saison : tout est rechargé
    if (this._cdText) this._cdText.setText(this._fmtCountdown(si.msLeft));
    if (this._stripTimers) {
      this._stripTimers.d.setText('Quotidiennes : ' + this._fmtCountdown(PM.msUntilReset('daily')));
      this._stripTimers.w.setText('Hebdo : ' + this._fmtCountdown(PM.msUntilReset('weekly')));
    }
  }

  // ---------- Rendu du contenu ----------
  // Perf : la piste « Récompenses » (30 niveaux × 2 pistes = jusqu'à 60 cartes, chacune avec plusieurs
  // Graphics + tweens en boucle) n'est plus construite en bloc. Seules les lignes visibles (+ une marge
  // tampon) sont instanciées ; le reste est recyclé au fil du défilement (voir _updateVisibleRows).
  _render(animate) {
    this._stop(this._fxTweens); this._fxTweens = [];
    this._hits = [];
    this._stripTimers = null;
    this._stopActiveRows();
    this.listContainer.removeAll(true);
    this.stripC.removeAll(true);
    var total = this.tab === 'rewards' ? this._renderRewards() : this._renderMissions();
    var viewH = this.listBottom - this.listTop;
    this.maxScroll = Math.max(0, total - viewH + 8);
    if (this._autoScroll) { this.scrollY = this.tab === 'rewards' ? (this._curTarget || 0) : 0; this._autoScroll = false; }
    this.scrollY = Math.max(0, Math.min(this.scrollY || 0, this.maxScroll));
    this.listContainer.y = this.listTop - this.scrollY;
    if (this.tab === 'rewards') this._updateVisibleRows(true);
    this._refreshTabs();
  }

  _renderRewards() {
    var self = this, w = this.scale.width, PM = this.PM, P = this.P;
    var levels = PM.levels(), cur = PM.level().level, premium = PM.isPremium();
    var th = PM.season().theme;
    var ROW = 190, CARD_W = 292, CARD_H = 172, cxL = 12 + CARD_W / 2, cxR = w - 12 - CARD_W / 2, spineX = w / 2;

    // Bandeau de colonnes (fixe)
    var sg = this.add.graphics();
    sg.fillStyle(0x101a33, 0.96); sg.fillRoundedRect(12, -18, CARD_W, 36, 12);
    sg.lineStyle(2, 0x5f7bb0, 0.9); sg.strokeRoundedRect(12, -18, CARD_W, 36, 12);
    sg.fillGradientStyle(0x4a3a10, 0x4a3a10, 0x2a2008, 0x2a2008, 1); sg.fillRoundedRect(w - 12 - CARD_W, -18, CARD_W, 36, 12);
    sg.lineStyle(2.5, 0xffd166, premium ? 1 : 0.85); sg.strokeRoundedRect(w - 12 - CARD_W, -18, CARD_W, 36, 12);
    this.stripC.add(sg);
    this.stripC.add(this._txt(cxL, 0, 'Gratuit', 21, '#c9d4ea', { fontStyle: 'bold' }).setOrigin(0.5));
    var cg = this.add.graphics(); this._drawCrown(cg, cxR - 96, 0, 0.9, 0xffd166); this.stripC.add(cg);
    this.stripC.add(this._txt(cxR + 6, 0, premium ? 'Premium actif' : 'Premium', 21, '#ffd166', { fontStyle: 'bold' }).setOrigin(0.5));
    if (!premium) {
      var pz = this.add.zone(cxR, 0, CARD_W, 36).setInteractive({ useHandCursor: true });
      pz.on('pointerup', function () { if (!self._overlay) self._openPremiumModal(); });
      this.stripC.add(pz);
    }

    // Géométrie de la piste, retenue pour la construction virtualisée des lignes (_updateVisibleRows)
    this._rwLevels = levels;
    this._rwCur = cur;
    this._rwGeom = { ROW: ROW, CARD_W: CARD_W, CARD_H: CARD_H, cxL: cxL, cxR: cxR, spineX: spineX, th: th };
    this._activeRows = {};
    this._rwRangeKey = null;

    // Pied de liste (un seul élément fixe, pas besoin de le virtualiser)
    var endY = 4 + levels.length * ROW;
    this.listContainer.add(this._txt(w / 2, endY + 22, 'Récompenses non réclamées perdues à la fin de la saison', 18, '#7d8db4').setOrigin(0.5));
    this._curTarget = Math.max(0, 4 + Math.max(0, Math.min(cur - 1, levels.length - 1)) * ROW - 10);   // ouverture : niveau en cours en haut de la liste
    return endY + 60;
  }

  /** Construit/détruit uniquement les lignes (niveau + 2 cartes) visibles dans la fenêtre de défilement,
   *  avec une petite marge tampon au-dessus/en dessous pour un défilement fluide. Appelé au premier rendu,
   *  puis à chaque fois que la plage de lignes visibles change pendant le glissement/la molette. */
  _updateVisibleRows(force) {
    if (this.tab !== 'rewards' || !this._rwGeom) return;
    var geom = this._rwGeom, ROW = geom.ROW, levels = this._rwLevels;
    if (!levels || !levels.length) return;
    var viewH = this.listBottom - this.listTop, BUFFER = 2;
    var first = Math.max(0, Math.floor(this.scrollY / ROW) - BUFFER);
    var last = Math.min(levels.length - 1, Math.ceil((this.scrollY + viewH) / ROW) + BUFFER);
    var key = first + ':' + last;
    if (!force && this._rwRangeKey === key) return;
    this._rwRangeKey = key;
    var active = this._activeRows, idx, i;
    for (idx in active) { i = +idx; if (i < first || i > last) this._destroyRow(i); }
    for (i = first; i <= last; i++) { if (!active[i]) this._buildRow(i); }
    var hits = [];
    for (idx in active) { hits = hits.concat(active[idx].hits); }
    this._hits = hits;
  }

  _buildRow(i) {
    var geom = this._rwGeom, L = this._rwLevels[i], cur = this._rwCur, th = geom.th, P = this.P;
    var y0 = 4 + i * geom.ROW, cy = y0 + geom.CARD_H / 2 + 2, reached = L.level <= cur;
    var row = this.add.container(0, 0);
    var rowData = { row: row, tweens: [], hits: [] };
    this._activeRows[i] = rowData;
    var line = this.add.graphics();
    line.fillStyle(reached && L.level < cur ? th.color : 0x2a3557, reached && L.level < cur ? 0.9 : 0.8);
    line.fillRect(geom.spineX - 3, y0 - 4, 6, geom.ROW);
    row.add(line);
    // Nœud de niveau
    var node = this.add.container(geom.spineX, cy);
    var ng = this.add.graphics();
    var isCur = L.level === cur + 1 || (cur >= P.MAX_LEVEL && L.level === P.MAX_LEVEL);
    if (reached) { ng.fillStyle(th.color, 0.25); ng.fillCircle(0, 0, 34); }
    ng.fillGradientStyle(reached ? this._mix(th.color, 0xffffff, 0.75) : 0x1a2440, reached ? this._mix(th.color, 0xffffff, 0.75) : 0x1a2440, reached ? th.color : 0x0b1224, reached ? th.color : 0x0b1224, 1);
    ng.fillCircle(0, 0, 27);
    ng.lineStyle(3, reached ? 0xffffff : (isCur ? th.color2 : 0x394869), 0.9); ng.strokeCircle(0, 0, 27);
    node.add(ng);
    node.add(this._txt(0, 0, String(L.level), L.level >= 10 ? 25 : 27, reached ? '#04101c' : '#7d8db4', { fontStyle: '900' }).setOrigin(0.5));
    row.add(node);
    if (L.level === cur && cur > 0) rowData.tweens.push(this.tweens.add({ targets: node, scale: 1.14, duration: 700, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' }));
    this.listContainer.add(row);
    this._reward(L, 'free', geom.cxL, cy, geom.CARD_W, geom.CARD_H, rowData);
    this._reward(L, 'premium', geom.cxR, cy, geom.CARD_W, geom.CARD_H, rowData);
  }

  _destroyRow(i) {
    var rd = this._activeRows[i];
    if (!rd) return;
    this._stop(rd.tweens);
    try { rd.row.destroy(true); } catch (e) { /* ignore */ }
    delete this._activeRows[i];
  }

  _stopActiveRows() {
    var self = this;
    Object.keys(this._activeRows || {}).forEach(function (k) { self._destroyRow(+k); });
    this._activeRows = {};
    this._rwRangeKey = null;
  }

  /** Carte de récompense (piste free/premium d'un niveau) : fond de rareté, glow, étincelles, icône, statut.
   *  `collector` (optionnel) est le panier {row, tweens, hits} de la ligne virtualisée qui possède cette
   *  carte : les tweens en boucle et la zone de tap y sont rangés pour pouvoir être détruits proprement
   *  quand la ligne sort de la fenêtre visible, au lieu de s'accumuler pour toute la piste. */
  _reward(L, track, cx, cy, cw, ch, collector) {
    var self = this, PM = this.PM, P = this.P;
    var rw = L[track], rar = this._rar(rw.rarity), col = rar.color, st = PM.status(L.level, track);
    var isPrem = track === 'premium', ri = P.RARITY_ORDER.indexOf(rw.rarity);   // 0 commun … 4 mythique
    var addTween = function (cfg) { var tw = self.tweens.add(cfg); (collector ? collector.tweens : self._fxTweens).push(tw); return tw; };
    var card = this.add.container(cx, cy);
    var g = this.add.graphics();
    var top = this._mix(col, 0x0b1224, isPrem ? 0.3 : 0.22), bot = this._mix(col, 0x060a16, 0.07);
    g.fillGradientStyle(top, top, bot, bot, 1);
    g.fillRoundedRect(-cw / 2, -ch / 2, cw, ch, 20);
    g.lineStyle(ri >= 2 ? 3.5 : 2.5, col, st === 'locked' ? 0.6 : 1); g.strokeRoundedRect(-cw / 2, -ch / 2, cw, ch, 20);
    if (isPrem) { g.lineStyle(1.5, 0xffd166, 0.7); g.strokeRoundedRect(-cw / 2 + 5, -ch / 2 + 5, cw - 10, ch - 10, 16); }
    card.add(g);

    // Halo de rareté (rare et +) : pulsation
    if (ri >= 1 && st !== 'claimed') {
      var halo = this.add.graphics();
      halo.lineStyle(6, col, 0.35); halo.strokeRoundedRect(-cw / 2 - 3, -ch / 2 - 3, cw + 6, ch + 6, 23);
      card.add(halo);
      halo.setAlpha(0.25);
      addTween({ targets: halo, alpha: ri >= 3 ? 1 : 0.8, duration: ri >= 3 ? 700 : 1100, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    }
    // Plaque lumineuse derrière l'icône
    var plate = this.add.graphics();
    plate.fillStyle(col, 0.10); plate.fillCircle(0, -36, 48);
    plate.fillStyle(col, 0.16); plate.fillCircle(0, -36, 39);
    plate.fillStyle(0x000000, 0.28); plate.fillCircle(0, -36, 31);
    card.add(plate);
    card.add(this._icon(rw, 0, -36, 74, collector));

    // Étincelles (épique et +)
    if (ri >= 2 && st !== 'claimed') {
      var n = ri >= 3 ? 5 : 3;
      for (var s = 0; s < n; s++) {
        var sx = -cw / 2 + 24 + ((s * 97 + L.level * 31) % (cw - 48)), sy = -ch / 2 + 22 + ((s * 53 + L.level * 17) % 74);
        var sp = this.add.circle(sx, sy, 2.4, 0xffffff, 0.95);
        card.add(sp); sp.setAlpha(0.1);
        addTween({ targets: sp, alpha: 1, scale: 1.9, duration: 650 + s * 130, yoyo: true, repeat: -1, delay: s * 260 });
      }
    }
    // Reflet balayant (légendaire / mythique)
    if (ri >= 3 && st !== 'claimed') {
      var shine = this.add.rectangle(-cw / 2 - 20, -10, 30, ch + 20, 0xffffff, 0.16);
      shine.setAngle(18); shine.setBlendMode(Phaser.BlendModes.ADD);
      card.add(shine); shine.setAlpha(0);
      addTween({ targets: shine, x: cw / 2 + 20, duration: 1700, repeat: -1, repeatDelay: 1500, ease: 'Sine.easeInOut', delay: (L.level % 5) * 300 });
      addTween({ targets: shine, alpha: 0.5, duration: 850, yoyo: true, repeat: -1, repeatDelay: 1500 + 0, delay: (L.level % 5) * 300 });
    }

    // Textes
    var rl = this._txt(-cw / 2 + 14, -ch / 2 + 15, rw.kind === 'hero' ? 'HÉROS · ' + rar.name : rar.name, 15, rar.hex, { fontStyle: 'bold' }).setOrigin(0, 0.5);
    this._fitWidth(rl, cw - 60);
    card.add(rl);
    var lb = this._txt(0, 20, rw.label, 21, '#ffffff', { fontStyle: 'bold' }).setOrigin(0.5);
    this._fitWidth(lb, cw - 22);
    card.add(lb);
    var dt = this._txt(0, 43, rw.detail, 17, '#b9c6e6').setOrigin(0.5);
    this._fitWidth(dt, cw - 22);
    card.add(dt);

    // Bandeau de statut
    var sy2 = ch / 2 - 19, stripW = cw - 24;
    var sg = this.add.graphics();
    var stTxt = '', stCol = '#ffffff';
    if (st === 'available') {
      sg.fillGradientStyle(0x3fe07f, 0x3fe07f, 0x17803f, 0x17803f, 1); sg.fillRoundedRect(-stripW / 2, sy2 - 14, stripW, 28, 10);
      sg.lineStyle(2, 0xb8ffd0, 0.95); sg.strokeRoundedRect(-stripW / 2, sy2 - 14, stripW, 28, 10);
      stTxt = 'RÉCLAMER'; stCol = '#04140a';
    } else if (st === 'claimed') {
      sg.fillStyle(0x000000, 0.35); sg.fillRoundedRect(-stripW / 2, sy2 - 14, stripW, 28, 10);
      stTxt = 'Réclamé'; stCol = '#8fdca0';
    } else if (st === 'premium_locked') {
      sg.fillStyle(0x3a2c08, 0.95); sg.fillRoundedRect(-stripW / 2, sy2 - 14, stripW, 28, 10);
      sg.lineStyle(2, 0xffd166, 0.95); sg.strokeRoundedRect(-stripW / 2, sy2 - 14, stripW, 28, 10);
      stTxt = 'Premium requis'; stCol = '#ffd166';
    } else {
      sg.fillStyle(0x000000, 0.4); sg.fillRoundedRect(-stripW / 2, sy2 - 14, stripW, 28, 10);
      stTxt = 'Niveau ' + L.level; stCol = '#8e9cc0';
    }
    card.add(sg);
    var stT = this._txt(st === 'locked' || st === 'premium_locked' ? 10 : 0, sy2, stTxt, 18, stCol, { fontStyle: 'bold' }).setOrigin(0.5);
    card.add(stT);
    this._fitWidth(stT, stripW - 50);
    var stHalf = stT.width * stT.scaleX / 2;
    if (st === 'locked' || st === 'premium_locked') { var lg = this.add.graphics(); this._drawLock(lg, stT.x - stHalf - 14, sy2 + 1, 0.85, st === 'locked' ? 0x8e9cc0 : 0xffd166, 1); card.add(lg); }
    if (st === 'claimed') { var ck = this.add.graphics(); this._drawCheck(ck, stT.x - stHalf - 16, sy2, 0.8, 0x8fdca0); card.add(ck); }
    if (st === 'available') addTween({ targets: sg, alpha: 0.7, duration: 600, yoyo: true, repeat: -1 });

    // Voile sur les cartes verrouillées / réclamées
    if (st === 'claimed') { var vg = this.add.graphics(); vg.fillStyle(0x05070f, 0.5); vg.fillRoundedRect(-cw / 2, -ch / 2, cw, ch - 36, 20); card.add(vg); }
    else if (st === 'locked' || st === 'premium_locked') { var vg2 = this.add.graphics(); vg2.fillStyle(0x05070f, 0.32); vg2.fillRoundedRect(-cw / 2, -ch / 2, cw, ch - 36, 20); card.add(vg2); }
    if (isPrem && st !== 'claimed' && !PM.isPremium()) {
      var cg = this.add.graphics(); this._drawCrown(cg, cw / 2 - 26, -ch / 2 + 20, 0.8, 0xffd166); card.add(cg);
    }
    (collector ? collector.row : this.listContainer).add(card);

    // Zone de tap
    (collector ? collector.hits : this._hits).push({ x: cx - cw / 2, y: cy - ch / 2, w: cw, h: ch, fn: function () {
      self.tweens.add({ targets: card, scale: 0.95, duration: 70, yoyo: true });
      self._onCardTap(L.level, track);
    } });
    return card;
  }

  // ---------- Icône d'une récompense (dans un carré de `size` px, centrée en x,y) ----------
  // `collector` (optionnel) : voir _reward — permet de rattacher le tween d'orbite d'un skin à sa ligne.
  _icon(rw, x, y, size, collector) {
    var c = this.add.container(x, y), g;
    if (rw.kind === 'res') {
      var im = this._image(0, 0, 'tex_icon_' + rw.res);
      if (im) { im.setDisplaySize(size * 0.8, size * 0.8); c.add(im); }
      else { g = this.add.graphics(); g.fillStyle(NEBUSTION.Economy.RES[rw.res].color, 1); g.fillCircle(0, 0, size * 0.3); c.add(g); }
    } else if (rw.kind === 'gems') {
      g = this.add.graphics(); this._drawGem(g, 0, 0, size * 0.34, NEBUSTION.Shop.GEM.color); c.add(g);
    } else if (rw.kind === 'frag' || rw.kind === 'hero') {
      var key = NEBUSTION.Heroes.portraitKey(rw.heroId), pi = this._image(0, 0, key), sz = rw.kind === 'hero' ? size * 1.0 : size * 0.88;
      g = this.add.graphics();
      var hc = this._rar(rw.rarity).color;
      g.lineStyle(3, hc, 0.95); g.strokeCircle(0, 0, sz / 2 + 2);
      if (pi) { pi.setDisplaySize(sz - 4, sz - 4); c.add(pi); } else { g.fillStyle(0x1a2440, 1); g.fillCircle(0, 0, sz / 2); }
      c.add(g);
      if (rw.kind === 'frag') {   // éclat de fragment en coin
        var fg = this.add.graphics();
        fg.fillStyle(0xffd166, 1); fg.fillTriangle(sz / 2 - 6, -4, sz / 2 + 10, 12, sz / 2 - 6, 24); fg.fillStyle(0xfff1a8, 1); fg.fillTriangle(sz / 2 - 6, -4, sz / 2 - 6, 24, sz / 2 - 20, 12);
        c.add(fg);
      }
    } else if (rw.kind === 'troop') {
      c.add(this.add.text(0, 0, rw.icon || '🪖', { fontSize: Math.round(size * 0.62) + 'px' }).setOrigin(0.5));
    } else if (rw.kind === 'skin') {
      var sk = NEBUSTION.Skins.get(rw.skinId), aura = sk ? sk.aura : 0x00e5ff, hull = sk && sk.hull ? sk.hull : 0x1f3352, tint = sk && sk.tint ? sk.tint : aura;
      g = this.add.graphics();
      g.fillStyle(aura, 0.20); g.fillCircle(0, 0, size * 0.5); g.lineStyle(2, aura, 0.7); g.strokeCircle(0, 0, size * 0.46);
      if (rw.target === 'ship') {
        g.fillStyle(hull, 1); g.fillTriangle(0, -size * 0.36, -size * 0.28, size * 0.3, size * 0.28, size * 0.3);
        g.lineStyle(3, aura, 1); g.strokeTriangle(0, -size * 0.36, -size * 0.28, size * 0.3, size * 0.28, size * 0.3);
        g.fillStyle(aura, 1); g.fillCircle(-size * 0.13, size * 0.34, 4); g.fillCircle(size * 0.13, size * 0.34, 4); g.fillCircle(0, -size * 0.06, 5);
      } else if (rw.target === 'building') {
        g.fillStyle(hull, 1); g.fillRoundedRect(-size * 0.3, -size * 0.06, size * 0.6, size * 0.34, 6);
        g.lineStyle(3, aura, 1); g.strokeRoundedRect(-size * 0.3, -size * 0.06, size * 0.6, size * 0.34, 6);
        g.fillStyle(aura, 0.95); g.fillTriangle(-size * 0.22, -size * 0.06, size * 0.22, -size * 0.06, 0, -size * 0.34);
        g.fillStyle(0xffffff, 0.8); g.fillCircle(0, size * 0.1, 4);
      } else {
        g.fillStyle(tint, 1); g.fillCircle(0, -size * 0.15, size * 0.14);
        g.fillTriangle(-size * 0.28, size * 0.3, size * 0.28, size * 0.3, 0, -size * 0.02);
        g.lineStyle(3, aura, 1); g.strokeCircle(0, -size * 0.15, size * 0.14); g.strokeTriangle(-size * 0.28, size * 0.3, size * 0.28, size * 0.3, 0, -size * 0.02);
      }
      c.add(g);
      if (sk && (sk.fx === 'orbit' || sk.fx === 'sparkle' || sk.fx === 'pulse' || sk.fx === 'flame')) {
        var orb = this.add.container(0, 0), og = this.add.graphics();
        og.fillStyle(aura, 1); og.fillCircle(size * 0.46, 0, 4.5); og.fillCircle(-size * 0.46, 0, 3.5);
        orb.add(og); c.add(orb);
        var otw = this.tweens.add({ targets: orb, angle: 360, duration: 3600, repeat: -1 });
        (collector ? collector.tweens : this._fxTweens).push(otw);
      }
    }
    return c;
  }

  // ---------- Tap sur une carte ----------
  _onCardTap(level, track) {
    var PM = this.PM, st = PM.status(level, track);
    if (st === 'available') return this._claimCard(level, track);
    if (st === 'premium_locked') return this._openPremiumModal();
    if (st === 'locked') return this.fx.toast('Niveau ' + level + ' requis', 'Gagnez de l\'XP Pass avec les missions', null);
    return this.fx.toast('Déjà réclamé', null, null);
  }

  _explain(res) {
    if (res.reason === 'stockage') {
      var nm = this.P.RES_NAMES[res.res] || 'ressource';
      this.fx.toast('Stockage plein : ' + nm, 'Dépensez-en puis réclamez de nouveau', null);
    } else this.fx.toast('Réclamation impossible', null, null);
  }

  _claimCard(level, track) {
    var res = this.PM.claim(level, track);
    if (!res.ok) return this._explain(res);
    this._showReveal([res], 0, []);
  }

  _onClaimAll() {
    var PM = this.PM;
    if (this.tab === 'missions') {
      var m = PM.claimAllMissions();
      if (!m.ok) return this.fx.toast('Aucune mission terminée', null, null);
        this._afterMissionClaim(m.xp, m.from, m.to);
      return;
    }
    var r = PM.claimAll();
    if (!r.ok) {
      if (r.blocked.length) return this._explain(r.blocked[0]);
      return this.fx.toast('Rien à réclamer', 'Montez de niveau avec les missions', null);
    }
    this._showReveal(r.claimed, 0, r.blocked);
  }

  // ---------- Missions ----------
  _renderMissions() {
    var self = this, w = this.scale.width, PM = this.PM;
    // Bandeau (fixe) : compte à rebours des deux listes
    var sg = this.add.graphics();
    sg.fillStyle(0x101a33, 0.96); sg.fillRoundedRect(12, -18, w - 24, 36, 12);
    sg.lineStyle(2, 0x5f7bb0, 0.9); sg.strokeRoundedRect(12, -18, w - 24, 36, 12);
    this.stripC.add(sg);
    var td = this._txt(w * 0.27, 0, '', 19, '#c9d4ea', { fontStyle: 'bold' }).setOrigin(0.5);
    var tw = this._txt(w * 0.73, 0, '', 19, '#c9d4ea', { fontStyle: 'bold' }).setOrigin(0.5);
    this.stripC.add([td, tw]);
    this._stripTimers = { d: td, w: tw };

    var y = 6;
    var sections = [{ kind: 'daily', title: 'Missions quotidiennes' }, { kind: 'weekly', title: 'Missions hebdomadaires' }];
    sections.forEach(function (sec) {
      self.listContainer.add(self._txt(24, y + 18, sec.title, 24, '#ffffff', { fontStyle: '900' }).setOrigin(0, 0.5));
      y += 44;
      PM.missions(sec.kind).forEach(function (m) { self._missionCard(m, w / 2, y + 54, w - 24, 108); y += 122; });
      y += 10;
    });
    this.listContainer.add(this._txt(w / 2, y + 12, 'Chaque mission terminée donne de l\'XP Pass', 18, '#7d8db4').setOrigin(0.5));
    this._tick();
    return y + 50;
  }

  _missionCard(m, cx, cy, cw, ch) {
    var self = this, PM = this.PM, th = PM.season().theme;
    var card = this.add.container(cx, cy), g = this.add.graphics();
    var ready = m.status === 'ready', done = m.status === 'claimed';
    var edge = ready ? 0x5fe08a : (done ? 0x394869 : th.color);
    g.fillGradientStyle(ready ? 0x143a25 : 0x14203f, ready ? 0x143a25 : 0x14203f, 0x0a1224, 0x0a1224, 1);
    g.fillRoundedRect(-cw / 2, -ch / 2, cw, ch, 18);
    g.lineStyle(2.5, edge, done ? 0.6 : 0.95); g.strokeRoundedRect(-cw / 2, -ch / 2, cw, ch, 18);
    card.add(g);
    var lb = this._txt(-cw / 2 + 22, -24, m.label, 23, done ? '#8e9cc0' : '#ffffff', { fontStyle: 'bold' }).setOrigin(0, 0.5);
    this._fitWidth(lb, cw - 230);
    card.add(lb);
    // Barre de progression
    var barX = -cw / 2 + 22, barW = cw - 320, barY = 22;
    var bg = this.add.graphics();
    bg.fillStyle(0x000000, 0.55); bg.fillRoundedRect(barX, barY - 10, barW, 20, 10);
    var pct = Math.min(1, m.p / m.target);
    if (pct > 0) { bg.fillGradientStyle(th.color, th.color2, th.color, th.color2, 1); bg.fillRoundedRect(barX, barY - 10, Math.max(14, barW * pct), 20, 10); }
    bg.lineStyle(2, 0x394869, 0.9); bg.strokeRoundedRect(barX, barY - 10, barW, 20, 10);
    card.add(bg);
    card.add(this._txt(barX + barW + 12, barY, m.p + ' / ' + m.target, 19, '#c9d4ea', { fontStyle: 'bold' }).setOrigin(0, 0.5));
    // XP + bouton
    var bx = cw / 2 - 84, bw = 132, bh = 52;
    card.add(this._txt(bx, -30, '+' + m.xp + ' XP', 22, '#ffd166', { fontStyle: '900' }).setOrigin(0.5));
    var bb = this.add.graphics();
    if (ready) {
      bb.fillGradientStyle(0x3fe07f, 0x3fe07f, 0x17803f, 0x17803f, 1); bb.fillRoundedRect(bx - bw / 2, 4, bw, bh - 8, 14);
      bb.lineStyle(2, 0xb8ffd0, 1); bb.strokeRoundedRect(bx - bw / 2, 4, bw, bh - 8, 14);
      card.add(bb); card.add(this._txt(bx, 24, 'Réclamer', 19, '#04140a', { fontStyle: '900' }).setOrigin(0.5));
      this._loop({ targets: bb, alpha: 0.7, duration: 600, yoyo: true, repeat: -1 });
    } else if (done) {
      card.add(bb); this._drawCheck(bb, bx, 24, 1.0, 0x8fdca0);
    } else {
      bb.fillStyle(0x000000, 0.4); bb.fillRoundedRect(bx - bw / 2, 4, bw, bh - 8, 14);
      card.add(bb); card.add(this._txt(bx, 24, 'En cours', 18, '#7d8db4', { fontStyle: 'bold' }).setOrigin(0.5));
    }
    this.listContainer.add(card);
    if (ready) this._hits.push({ x: cx - cw / 2, y: cy - ch / 2, w: cw, h: ch, fn: function () {
      var r = PM.claimMission(m.kind, m.id);
      if (!r.ok) return self._explain(r);
      self._afterMissionClaim(r.xp, r.from, r.to);
    } });
  }

  _afterMissionClaim(xp, from, to) {
    this._buildHeader();
    this._render(false);
    this.fx.toast('+' + xp + ' XP Pass', to > from ? 'Niveau ' + to + ' atteint ! Récompenses disponibles' : null, null);
    if (to > from) { this.fx.vibrate(30); this._levelFlash(to); }
  }

  _levelFlash(level) {
    var w = this.scale.width, th = this.PM.season().theme;
    var t = this._txt(w / 2, 560, 'NIVEAU ' + level, 64, '#ffffff', { fontStyle: '900' }).setOrigin(0.5).setDepth(1150).setAlpha(0).setScale(0.6);
    t.setShadow(0, 0, th.hex, 24, true, true);
    this.tweens.add({ targets: t, alpha: 1, scale: 1.1, duration: 320, ease: 'Back.easeOut' });
    this.tweens.add({ targets: t, alpha: 0, y: 500, delay: 1000, duration: 500, onComplete: function () { t.destroy(); } });
  }

  // ---------- Animation de déblocage plein écran ----------
  _showReveal(results, extra, blocked) {
    var self = this, w = this.scale.width, h = this.scale.height, P = this.P;
    // La récompense mise en avant : la plus rare de la liste
    var main = results.slice().sort(function (a, b) { return P.RARITY_ORDER.indexOf(b.reward.rarity) - P.RARITY_ORDER.indexOf(a.reward.rarity); })[0];
    var rw = main.reward, rar = this._rar(rw.rarity), col = rar.color, ri = P.RARITY_ORDER.indexOf(rw.rarity);
    var ov = this.add.container(0, 0).setDepth(1200);
    this._overlay = { c: ov, ready: false };

    var dim = this.add.rectangle(w / 2, h / 2, w, h, 0x02040a, 0.9);
    ov.add(dim); dim.setAlpha(0);
    this.tweens.add({ targets: dim, alpha: 1, duration: 220 });

    var cx = w / 2, cy = h / 2 - 70;
    // Rayons rotatifs
    var rays = this.add.container(cx, cy), rg = this.add.graphics(), N = 14, R = 620;
    for (var i = 0; i < N; i++) {
      var a0 = (i / N) * Math.PI * 2, a1 = a0 + (Math.PI * 2 / N) * 0.42;
      rg.fillStyle(col, 0.15); rg.fillTriangle(0, 0, Math.cos(a0) * R, Math.sin(a0) * R, Math.cos(a1) * R, Math.sin(a1) * R);
    }
    rays.add(rg); ov.add(rays); rays.setAlpha(0);
    this.tweens.add({ targets: rays, alpha: 1, duration: 500 });
    this.tweens.add({ targets: rays, angle: 360, duration: 14000, repeat: -1 });

    // Anneaux d'onde de choc
    for (var k = 0; k < 3; k++) {
      var ring = this.add.graphics();
      ring.lineStyle(6, col, 0.9); ring.strokeCircle(0, 0, 90);
      ring.setPosition(cx, cy); ring.setScale(0.2); ring.setAlpha(0.9);
      ov.add(ring);
      this.tweens.add({ targets: ring, scale: 3.2 + k * 0.5, alpha: 0, duration: 900 + k * 200, delay: 120 + k * 170, ease: 'Cubic.easeOut' });
    }
    // Étincelles projetées
    var sparks = 18 + ri * 8;
    for (var s = 0; s < sparks; s++) {
      var ang = Math.random() * Math.PI * 2, dist = 150 + Math.random() * 260;
      var sp = this.add.circle(cx, cy, 3 + Math.random() * 4, s % 3 === 0 ? 0xffffff : col, 1);
      ov.add(sp); sp.setAlpha(0);
      this.tweens.add({ targets: sp, x: cx + Math.cos(ang) * dist, y: cy + Math.sin(ang) * dist + 40, alpha: 0.95, delay: 200 + Math.random() * 200, duration: 700 + Math.random() * 500, ease: 'Cubic.easeOut',
        onComplete: (function (o) { return function () { self.tweens.add({ targets: o, alpha: 0, duration: 400 }); }; })(sp) });
    }

    // Carte / icône qui surgit
    var card = this.add.container(cx, cy);
    var plate = this.add.graphics();
    plate.fillStyle(col, 0.16); plate.fillCircle(0, 0, 170); plate.fillStyle(col, 0.24); plate.fillCircle(0, 0, 130);
    plate.fillGradientStyle(this._mix(col, 0x0b1224, 0.35), this._mix(col, 0x0b1224, 0.35), 0x060a16, 0x060a16, 1); plate.fillCircle(0, 0, 100);
    plate.lineStyle(5, col, 1); plate.strokeCircle(0, 0, 100);
    card.add(plate);
    var ic = this._icon(rw, 0, 0, 170);
    card.add(ic);
    ov.add(card);
    card.setScale(0.1); card.setAlpha(0);
    this.tweens.add({ targets: card, scale: 1, alpha: 1, duration: 620, delay: 120, ease: 'Back.easeOut' });
    this._loop({ targets: card, scale: 1.05, duration: 1100, yoyo: true, repeat: -1, delay: 800, ease: 'Sine.easeInOut' });

    // Textes
    var head = this._txt(cx, cy - 250, results.length > 1 ? 'RÉCOMPENSES RÉCLAMÉES' : 'RÉCOMPENSE DÉBLOQUÉE', 26, '#ffd166', { fontStyle: '900' }).setOrigin(0.5);
    var name = this._txt(cx, cy + 190, rw.label, 38, '#ffffff', { fontStyle: '900' }).setOrigin(0.5).setShadow(0, 0, rar.hex, 16, true, true);
    this._fitWidth(name, w - 60);
    var chipT = (rw.kind === 'hero' ? 'HÉROS · ' : '') + rar.name;
    var chip = this._txt(cx, cy + 232, chipT, 24, rar.hex, { fontStyle: 'bold' }).setOrigin(0.5);
    var det = this._txt(cx, cy + 268, rw.detail, 26, '#c9d4ea').setOrigin(0.5);
    this._fitWidth(det, w - 60);
    var texts = [head, name, chip, det];
    var ty = cy + 306;
    if (main.dup) { texts.push(this._txt(cx, ty, 'Skin déjà possédé : converti en ' + main.convertedGems + ' Prismes', 21, '#e6c6ff').setOrigin(0.5)); ty += 34; }
    else if (rw.kind === 'skin') { texts.push(this._txt(cx, ty, 'Ajouté à votre collection de skins', 21, '#a9b8dc').setOrigin(0.5)); ty += 34; }
    if (results.length > 1) { texts.push(this._txt(cx, ty, '+ ' + (results.length - 1) + ' autre' + (results.length > 2 ? 's' : '') + ' récompense' + (results.length > 2 ? 's' : ''), 24, '#8fdca0', { fontStyle: 'bold' }).setOrigin(0.5)); ty += 34; }
    if (blocked && blocked.length) { texts.push(this._txt(cx, ty, blocked.length + ' non réclamée' + (blocked.length > 1 ? 's' : '') + ' : stockage plein', 21, '#ff8a8a').setOrigin(0.5)); ty += 34; }
    texts.forEach(function (t, idx) { ov.add(t); t.setAlpha(0); self.tweens.add({ targets: t, alpha: 1, delay: 450 + idx * 90, duration: 350 }); });
    var hint = this._txt(cx, h - 190, 'Touchez pour continuer', 22, '#8e9cc0').setOrigin(0.5);
    ov.add(hint); hint.setAlpha(0);
    this.tweens.add({ targets: hint, alpha: 1, delay: 1100, duration: 300 });
    this._loop({ targets: hint, alpha: 0.4, duration: 800, yoyo: true, repeat: -1, delay: 1500 });

    // Retours
    this.fx.vibrate(ri >= 3 ? 60 : 25);
    if (ri >= 3) this.fx.shake(260, 0.006);
    this.time.delayedCall(700, function () { if (self._overlay) self._overlay.ready = true; });

    var zone = this.add.zone(0, 0, w, h).setOrigin(0).setInteractive();
    zone.on('pointerup', function () { if (self._overlay && self._overlay.ready) self._closeOverlay(); });
    ov.add(zone);
  }

  _closeOverlay() {
    var o = this._overlay;
    if (!o) return;
    this._overlay = null;
    var self = this;
    this.tweens.add({ targets: o.c, alpha: 0, duration: 200, onComplete: function () { o.c.destroy(); } });
    this._buildHeader();
    this._render(false);
  }

  // ---------- Fenêtre Premium (aucun paiement : voir PassBilling) ----------
  _openPremiumModal() {
    var self = this, w = this.scale.width, h = this.scale.height, PM = this.PM, P = this.P;
    if (this._overlay) return;
    var Billing = NEBUSTION.PassBilling, avail = Billing && Billing.isAvailable();
    var th = PM.season().theme;
    var ov = this.add.container(0, 0).setDepth(1200);
    this._overlay = { c: ov, ready: true };
    var dim = this.add.rectangle(w / 2, h / 2, w, h, 0x02040a, 0.86);
    ov.add(dim);
    var pw = w - 60, ph = 800, px = 30, py = h / 2 - ph / 2 - 20;
    var g = this.add.graphics();
    g.fillGradientStyle(0x2a2008, 0x2a2008, 0x0a1224, 0x0a1224, 1); g.fillRoundedRect(px, py, pw, ph, 26);
    g.lineStyle(3.5, 0xffd166, 1); g.strokeRoundedRect(px, py, pw, ph, 26);
    g.lineStyle(1.5, th.color, 0.6); g.strokeRoundedRect(px + 7, py + 7, pw - 14, ph - 14, 21);
    ov.add(g);
    var cg = this.add.graphics(); this._drawCrown(cg, w / 2, py + 56, 2.2, 0xffd166); ov.add(cg);
    ov.add(this._txt(w / 2, py + 118, 'Pass Premium', 40, '#ffd166', { fontStyle: '900' }).setOrigin(0.5).setShadow(0, 0, '#ffd166', 14, true, true));
    ov.add(this._txt(w / 2, py + 156, 'Saison ' + PM.season().number + ' · ' + th.name, 22, '#c9d4ea').setOrigin(0.5));
    var lv = P.levelsFor(PM.state().season), hero = lv[19].premium, leg = lv[29].premium;
    var perks = [
      '30 récompenses Premium en plus de la piste gratuite',
      hero.label + ' : ' + hero.amount + ' fragments (niveau 20)',
      'Skin légendaire « ' + leg.label + ' » (niveau 30)',
      'Skins épiques, Prismes, ressources et fragments'
    ];
    perks.forEach(function (t, i) {
      var yy = py + 214 + i * 56, pg = self.add.graphics(); self._drawCheck(pg, px + 44, yy, 0.9, 0xffd166); ov.add(pg);
      var pt = self._txt(px + 68, yy, t, 22, '#eaf2ff').setOrigin(0, 0.5); self._fitWidth(pt, pw - 96); ov.add(pt);
    });
    // Mention claire : pas de paiement
    var note = avail ? 'Achat via Google Play.' : 'Les achats intégrés Android ne sont pas encore activés. En attendant, vous pouvez obtenir le Premium en échange de ressources du jeu.';
    var nt = this._txt(w / 2, py + 470, note, 20, avail ? '#a9b8dc' : '#ffb27a', { align: 'center', wordWrap: { width: pw - 60 } }).setOrigin(0.5);
    ov.add(nt);

    var hits = [];
    var mkBtn = function (yy, label, accent, txtCol, fn) {
      var bw = pw - 80, bh = 60, bg = self.add.graphics();
      bg.fillGradientStyle(accent, accent, self._mix(accent, 0x000000, 0.6), self._mix(accent, 0x000000, 0.6), 1);
      bg.fillRoundedRect(w / 2 - bw / 2, yy - bh / 2, bw, bh, 18); bg.lineStyle(2.5, 0xffffff, 0.5); bg.strokeRoundedRect(w / 2 - bw / 2, yy - bh / 2, bw, bh, 18);
      ov.add(bg); ov.add(self._fitWidth(self._txt(w / 2, yy, label, 24, txtCol, { fontStyle: '900' }).setOrigin(0.5), bw - 20));
      hits.push({ x: w / 2 - bw / 2, y: yy - bh / 2, w: bw, h: bh, fn: fn });
    };
    var by = py + 610;
    // Paiement provisoire en ressources (pas un paiement réel)
    if (!PM.isPremium()) {
      var price = Billing.resourcePrice(), affordable = Billing.canPayWithResources(), E = NEBUSTION.Economy;
      var priceTxt = E.ORDER.filter(function (id) { return price[id] > 0; }).map(function (id) { return self._fmt(price[id]) + ' ' + E.RES[id].short.toLowerCase(); }).join(' · ');
      ov.add(this._txt(w / 2, py + 545, 'Prix en ressources :\n' + priceTxt, 18, affordable ? '#8fe3ff' : '#ffb27a', { align: 'center', wordWrap: { width: pw - 60 } }).setOrigin(0.5));
      mkBtn(by, 'Payer avec des ressources', affordable ? 0x4fc3ff : 0x394869, affordable ? '#06121f' : '#9fb0d6', function () {
        var r = Billing.payWithResources();
        if (r.ok) { self._closeModal(); self.fx.toast('Pass Premium activé', 'Payé avec des ressources', null); }
        else if (r.reason === 'ressources') self.fx.toast('Ressources insuffisantes', priceTxt, null);
        else self.fx.toast('Achat non effectué', null, null);
      });
      by += 72;
    }
    if (avail) mkBtn(by, 'Acheter le Pass Premium', 0xffd166, '#2a1c00', function () {
      Billing.purchasePremium().then(function (r) { self._closeModal(); if (r.ok) self.fx.toast('Pass Premium activé', null, null); else self.fx.toast('Achat non effectué', null, null); });
    }); else mkBtn(by, 'Fermer', 0x3a4a78, '#ffffff', function () { self._closeModal(); });
    if (NEBUSTION.DEBUG) mkBtn(by + 72, PM.isPremium() ? 'TEST : retirer le Premium' : 'TEST : activer le Premium (debug)', 0x8a4dff, '#ffffff', function () {
      PM.debugSetPremium(!PM.isPremium()); self._closeModal();
    });
    var zone = this.add.zone(0, 0, w, h).setOrigin(0).setInteractive();
    zone.on('pointerup', function (p) {
      for (var i = 0; i < hits.length; i++) { var t = hits[i]; if (p.x >= t.x && p.x <= t.x + t.w && p.y >= t.y && p.y <= t.y + t.h) { t.fn(); return; } }
      if (p.x < px || p.x > px + pw || p.y < py || p.y > py + ph) self._closeModal();
    });
    ov.add(zone);
    ov.setAlpha(0); this.tweens.add({ targets: ov, alpha: 1, duration: 180 });
  }

  _closeModal() {
    var o = this._overlay;
    if (!o) return;
    this._overlay = null;
    o.c.destroy();
    this._buildHeader();
    this._render(false);
  }
};
