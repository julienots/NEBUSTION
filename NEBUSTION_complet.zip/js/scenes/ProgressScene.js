/**
 * NEBUSTION - ProgressScene (classe de base des écrans de l'étape 10)
 * Socle commun de ExpeditionScene, EventScene, PrestigeScene et AchievementsScene : en-tête, barre de
 * navigation entre ces 4 sections, onglets, liste à défilement (UNE zone gère glissement ET tap, comme
 * ShopScene/PassScene), cartes à « zones de tap », boutons dessinés, barres de progression, fenêtres
 * modales (confirmation / résultat) et petits pictogrammes.
 *
 * Les sous-classes fournissent : _hubKey(), _titleText(), _accent(), _tabDefs(), _renderTab(w), _buildBadge().
 * Aucune logique de jeu ici : tout vient des Managers (Expedition/Event/Prestige/Achievements).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.PROGRESS_HUB = [
  { key: 'expedition', label: 'Expéditions', scene: 'ExpeditionScene', color: 0x4fc3ff },
  { key: 'event', label: 'Événement', scene: 'EventScene', color: 0xb47bff },
  { key: 'prestige', label: 'Prestige', scene: 'PrestigeScene', color: 0xffd166 },
  { key: 'achievements', label: 'Succès', scene: 'AchievementsScene', color: 0x5fd97a },
  { key: 'nebustion', label: 'Nebustion', scene: 'NebustionScene', color: 0x8a2be2 },
  { key: 'codex', label: 'Codex', scene: 'CodexScene', color: 0xff4d5e }
];

/** Nombre d'éléments « à réclamer / à faire » par section (pastille rouge de la barre de navigation). */
NEBUSTION.progressBadges = function () {
  var out = { expedition: 0, event: 0, prestige: 0, achievements: 0, nebustion: 0, codex: 0 };
  try { if (NEBUSTION.ExpeditionManager) out.expedition = NEBUSTION.ExpeditionManager.readyCount(); } catch (e) { /* ignore */ }
  try {
    var EM = NEBUSTION.EventManager;
    if (EM && EM.isActive()) out.event = EM.claimableCount() + (EM.attemptsLeft() > 0 && !EM.bossStatus().defeated ? 1 : 0);
  } catch (e) { /* ignore */ }
  try { if (NEBUSTION.PrestigeManager && NEBUSTION.PrestigeManager.canPrestige().ok) out.prestige = 1; } catch (e) { /* ignore */ }
  try {
    var AM = NEBUSTION.AchievementsManager;
    if (AM) out.achievements = AM.claimableCount() + (AM.dailyStatus().available ? 1 : 0);
  } catch (e) { /* ignore */ }
  try {
    var NM = NEBUSTION.NebustionManager;
    if (NM && NM.isUnlocked() && NM.canActivateSanctuary()) out.nebustion = 1;
  } catch (e) { /* ignore */ }
  try { if (NEBUSTION.CodexManager) out.codex = NEBUSTION.CodexManager.unseenCount(); } catch (e) { /* ignore */ }
  return out;
};

NEBUSTION.ProgressScene = class ProgressScene extends Phaser.Scene {
  constructor(key) { super(key); }

  // ---------- À surcharger ----------
  _hubKey() { return 'expedition'; }
  _titleText() { return ''; }
  _accent() { return 0x00e5ff; }
  _accentHex() { return '#00e5ff'; }
  _defaultTab() { return null; }
  _tabDefs() { return []; }
  _renderTab(w) { return { cards: [], footer: null }; }
  _badgeContent(c) { /* contenu du badge à droite du titre (c : conteneur ancré à droite, x négatif) */ }
  _onTick() { /* appelé chaque seconde */ }

  // ---------- Cycle de vie ----------
  init(data) {
    this.tab = (data && data.tab) || this._defaultTab();
    this.scrollY = 0;
    this.maxScroll = 0;
    this._cards = [];
    this._fxTweens = [];
    this._live = [];
    this._modal = null;
    this._animate = true;
  }

  create() {
    var w = this.scale.width, h = this.scale.height;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(250, 5, 7, 15);
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });
    this.fx = new NEBUSTION.FX(this);

    this._txt(20, 138, this._titleText(), 27, '#eaf2ff', { fontStyle: '900' })
      .setOrigin(0, 0.5).setDepth(50).setShadow(0, 0, this._accentHex(), 12, true, true);
    this.badge = this.add.container(w - 16, 138).setDepth(60);
    this._buildBadge();

    this.hubY = 190;
    this.hubC = this.add.container(0, this.hubY).setDepth(45);
    this._buildHub();

    this.tabsY = 240;
    this._buildTabs();

    this.listTop = this.tabsY + 34;
    this.listBottom = h - 132;
    this.listContainer = this.add.container(0, this.listTop).setDepth(40);
    this.listMaskGfx = this.make.graphics();
    this.listContainer.setMask(this.listMaskGfx.createGeometryMask());
    this._buildScroll();

    this._render(true);
    this.hud = NEBUSTION.HUD.attach(this);
    new NEBUSTION.BottomNav(this, null);

    var self = this;
    this.time.addEvent({ delay: 1000, loop: true, callback: function () { self._tickLive(); } });
  }

  _buildBadge() { this.badge.removeAll(true); this._badgeContent(this.badge); }

  /** Pastille d'en-tête (icône + texte), ancrée à droite : retourne sa largeur. */
  _badgePill(c, kind, text, color, colorHex) {
    var t = this._txt(0, 0, text, 22, '#eaf2ff', { fontStyle: 'bold' }).setOrigin(0, 0.5);
    var pw = 62 + (t.width || 60), ph = 44;
    var g = this.add.graphics();
    g.fillStyle(0x151d33, 0.95); g.fillRoundedRect(-pw, -ph / 2, pw, ph, 22);
    g.lineStyle(2, color, 0.9); g.strokeRoundedRect(-pw, -ph / 2, pw, ph, 22);
    c.add(g);
    this._iconNode(c, kind, -pw + 28, 0, 30, colorHex);
    t.setPosition(-pw + 50, 0);
    c.add(t);
    return pw;
  }

  // ---------- Utilitaires ----------
  _txt(x, y, str, size, color, extra) {
    var st = { fontFamily: 'Arial, sans-serif', fontSize: size + 'px', color: color || '#eaf2ff', resolution: 2 };
    if (extra) Object.keys(extra).forEach(function (k) { st[k] = extra[k]; });
    return this.add.text(x, y, str, st);
  }
  _image(x, y, key) { return this.textures.exists(key) ? this.add.image(x, y, key) : null; }
  _loop(cfg) { var tw = this.tweens.add(cfg); this._fxTweens.push(tw); return tw; }
  _stopFx() {
    (this._fxTweens || []).forEach(function (t) { try { if (t && t.stop) t.stop(); } catch (e) { /* ignore */ } });
    this._fxTweens = [];
  }
  _fitWidth(t, maxW) { var tw = t.width || 0; if (tw > maxW && tw > 0) t.setScale(maxW / tw); return t; }
  _fmt(n) { return NEBUSTION.Economy.fmt(n); }
  _mix(c1, c2, t) {
    var r = Math.round(((c1 >> 16) & 255) * t + ((c2 >> 16) & 255) * (1 - t)), g = Math.round(((c1 >> 8) & 255) * t + ((c2 >> 8) & 255) * (1 - t)), b = Math.round((c1 & 255) * t + (c2 & 255) * (1 - t));
    return (r << 16) | (g << 8) | b;
  }
  _hex(c) { return '#' + ('000000' + (c >>> 0).toString(16)).slice(-6); }
  _fmtMs(ms) {
    ms = Math.max(0, Math.floor(ms / 1000));
    var d = Math.floor(ms / 86400), hh = Math.floor((ms % 86400) / 3600), mm = Math.floor((ms % 3600) / 60), ss = ms % 60;
    var p = function (n) { return (n < 10 ? '0' : '') + n; };
    return d > 0 ? d + 'j ' + p(hh) + 'h ' + p(mm) + 'm' : p(hh) + ':' + p(mm) + ':' + p(ss);
  }
  _fmtDuration(sec) {
    if (sec <= 0) return 'Instantanée';
    if (sec < 3600) return Math.round(sec / 60) + ' min';
    var h = sec / 3600;
    return (h % 1 === 0 ? h : h.toFixed(1)) + ' h';
  }

  // ---------- Pictogrammes ----------
  _drawGem(g, x, y, r, color) {
    g.fillStyle(color, 1); g.fillTriangle(x, y - r, x - r, y - r * 0.15, x + r, y - r * 0.15);
    g.fillStyle(color, 0.7); g.fillTriangle(x - r, y - r * 0.15, x + r, y - r * 0.15, x, y + r);
    g.lineStyle(Math.max(1.5, r * 0.08), 0xffffff, 0.55);
    g.lineBetween(x - r, y - r * 0.15, x + r, y - r * 0.15); g.lineBetween(x, y - r, x, y + r);
  }
  _drawRelic(g, x, y, r, color) {
    // relique cosmique : losange allongé + anneau
    g.fillStyle(color, 0.25); g.fillCircle(x, y, r * 1.05);
    g.fillStyle(color, 1); g.fillTriangle(x, y - r, x - r * 0.62, y, x + r * 0.62, y);
    g.fillStyle(color, 0.65); g.fillTriangle(x - r * 0.62, y, x + r * 0.62, y, x, y + r);
    g.lineStyle(Math.max(1.5, r * 0.09), 0xffffff, 0.6); g.strokeCircle(x, y, r * 1.05);
  }
  _drawShard(g, x, y, r, color) {
    g.fillStyle(color, 1); g.fillTriangle(x - r * 0.7, y + r, x, y - r, x + r * 0.7, y + r);
    g.lineStyle(Math.max(1.5, r * 0.1), 0xffffff, 0.5); g.lineBetween(x, y - r, x, y + r);
  }
  _drawCheck(g, x, y, s, color) {
    g.lineStyle(4 * s, color, 1); g.lineBetween(x - 7 * s, y, x - 2 * s, y + 6 * s); g.lineBetween(x - 2 * s, y + 6 * s, x + 8 * s, y - 6 * s);
  }
  _drawLock(g, x, y, s, color, alpha) {
    g.fillStyle(color, alpha); g.fillRoundedRect(x - 8 * s, y - 2 * s, 16 * s, 12 * s, 3 * s);
    g.lineStyle(2.4 * s, color, alpha); g.strokeCircle(x, y - 4 * s, 5 * s);
  }
  _drawBolt(g, x, y, s, color) {
    g.fillStyle(color, 1);
    g.fillTriangle(x + 2 * s, y - 12 * s, x - 8 * s, y + 3 * s, x + 1 * s, y + 3 * s);
    g.fillTriangle(x - 2 * s, y + 12 * s, x + 8 * s, y - 3 * s, x - 1 * s, y - 3 * s);
  }
  _drawStar(g, x, y, r, color) {
    g.fillStyle(color, 1);
    g.fillTriangle(x, y - r, x - r * 0.35, y, x + r * 0.35, y);
    g.fillTriangle(x, y + r, x - r * 0.35, y, x + r * 0.35, y);
    g.fillTriangle(x - r, y, x, y - r * 0.35, x, y + r * 0.35);
    g.fillTriangle(x + r, y, x, y - r * 0.35, x, y + r * 0.35);
  }

  /** Icône d'une récompense/monnaie dans `parent` (conteneur). kind: ressource (dust...), 'gem', 'relic', 'frag', 'xp', 'ecoin'. */
  _iconNode(parent, kind, x, y, size, colorHex) {
    var E = NEBUSTION.Economy;
    if (E.RES[kind]) {
      var ic = this._image(x, y, 'tex_icon_' + kind);
      if (ic) { ic.setDisplaySize(size, size); parent.add(ic); return; }
    }
    var g = this.add.graphics();
    if (kind === 'gem') this._drawGem(g, x, y, size * 0.45, NEBUSTION.Shop.GEM.color);
    else if (kind === 'relic') this._drawRelic(g, x, y, size * 0.42, 0xffd166);
    else if (kind === 'frag') this._drawShard(g, x, y, size * 0.4, 0x8fe3ff);
    else if (kind === 'ecoin') this._drawStar(g, x, y, size * 0.48, colorHex || 0xffd166);
    else if (kind === 'xp') { g.fillStyle(0x5fd97a, 1); g.fillCircle(x, y, size * 0.4); }
    else { g.fillStyle(E.RES[kind] ? E.RES[kind].color : 0x9aa5c0, 1); g.fillCircle(x, y, size * 0.4); }
    parent.add(g);
  }

  /** Ligne de récompenses [{kind, amount, label?}] : icône + « +N ». Retourne la largeur occupée. */
  _rewardRow(parent, x, y, items, size, opts) {
    opts = opts || {};
    var cx = x, self = this, fs = opts.font || 20;
    items.forEach(function (it) {
      if (!it || !(it.amount > 0)) return;
      self._iconNode(parent, it.kind, cx + size / 2, y, size, it.color);
      var t = self._txt(cx + size + 4, y, (opts.plain ? '' : '+') + self._fmt(it.amount) + (it.label ? ' ' + it.label : ''), fs, it.hex || opts.color || '#eaf2ff', { fontStyle: 'bold' }).setOrigin(0, 0.5);
      parent.add(t);
      cx += size + 4 + (t.width || 40) + 16;
    });
    return cx - x;
  }

  /** Convertit un objet de récompense {res:{}, gems, fragments, xp}/{dust:N}/{gem:N} en éléments pour _rewardRow. */
  _rewardItems(rw) {
    var out = [];
    if (!rw) return out;
    var E = NEBUSTION.Economy, src = rw.res || rw;
    E.ORDER.forEach(function (id) { if (src[id] > 0) out.push({ kind: id, amount: src[id] }); });
    var g = rw.gem || rw.gems;
    if (g > 0) out.push({ kind: 'gem', amount: g, hex: '#e6c6ff' });
    return out;
  }

  // ---------- Barre de navigation entre les 4 sections ----------
  _buildHub() {
    var self = this, w = this.scale.width, items = NEBUSTION.PROGRESS_HUB, gap = 6;
    var cw = (w - 20 - gap * (items.length - 1)) / items.length, badges = NEBUSTION.progressBadges();
    this.hubC.removeAll(true);
    items.forEach(function (it, i) {
      var x = 10 + cw / 2 + i * (cw + gap), active = it.key === self._hubKey();
      var g = self.add.graphics();
      g.fillGradientStyle(active ? self._mix(it.color, 0x0a1224, 0.35) : 0x101a33, active ? self._mix(it.color, 0x0a1224, 0.35) : 0x101a33, 0x0a1122, 0x0a1122, 0.97);
      g.fillRoundedRect(x - cw / 2, -19, cw, 38, 12);
      g.lineStyle(active ? 3 : 1.5, it.color, active ? 0.95 : 0.55);
      g.strokeRoundedRect(x - cw / 2, -19, cw, 38, 12);
      self.hubC.add(g);
      var t = self._txt(x, 0, it.label, 17, active ? '#ffffff' : '#9fb0d6', { fontStyle: 'bold' }).setOrigin(0.5);
      self._fitWidth(t, cw - 22);
      self.hubC.add(t);
      if (badges[it.key] > 0) {
        var dot = self.add.graphics();
        dot.fillStyle(0xff4d5e, 1); dot.fillCircle(x + cw / 2 - 12, -11, 8);
        dot.lineStyle(2, 0x05070f, 1); dot.strokeCircle(x + cw / 2 - 12, -11, 8);
        self.hubC.add(dot);
      }
      var zone = self.add.zone(x, 0, cw, 38).setInteractive({ useHandCursor: true });
      zone.on('pointerup', function () {
        if (self._modal || active) return;
        self.scene.start(it.scene, {});
      });
      self.hubC.add(zone);
    });
  }

  // ---------- Onglets ----------
  _drawTab(t, active) {
    t.g.clear();
    var acc = this._accent();
    t.g.fillGradientStyle(active ? 0x24386e : 0x101a33, active ? 0x24386e : 0x101a33, active ? 0x132048 : 0x0a1122, active ? 0x132048 : 0x0a1122, 0.97);
    t.g.fillRoundedRect(t.x - t.cw / 2, -21, t.cw, 42, 13);
    t.g.lineStyle(active ? 3 : 1.5, active ? acc : 0x394869, active ? 0.95 : 0.75);
    t.g.strokeRoundedRect(t.x - t.cw / 2, -21, t.cw, 42, 13);
    t.label.setColor(active ? '#eaf2ff' : '#8e9cc0');
  }
  _buildTabs() {
    var self = this, w = this.scale.width, tabs = this._tabDefs();
    this.tabsBar = this.add.container(0, this.tabsY).setDepth(45);
    this._tabDraw = [];
    if (tabs.length < 2) return;
    var gap = 6, cw = (w - 20 - gap * (tabs.length - 1)) / tabs.length;
    tabs.forEach(function (t, i) {
      var x = 10 + cw / 2 + i * (cw + gap);
      var g = self.add.graphics();
      var label = self._txt(x, 0, t.label, 20, '#8e9cc0', { fontStyle: 'bold' }).setOrigin(0.5);
      self._fitWidth(label, cw - 14);
      var zone = self.add.zone(x, 0, cw, 42).setInteractive({ useHandCursor: true });
      zone.on('pointerup', function () {
        if (self._modal || self.tab === t.id || self._tabLocked) return;
        self.tab = t.id; self.scrollY = 0; self._render(true);
      });
      self.tabsBar.add([g, label, zone]);
      var rec = { id: t.id, g: g, label: label, cw: cw, x: x };
      self._tabDraw.push(rec);
      self._drawTab(rec, self.tab === t.id);
    });
  }
  _refreshTabs() {
    var self = this;
    this._tabDraw.forEach(function (t) { self._drawTab(t, self.tab === t.id); });
  }

  // ---------- Zone de liste : défilement + tap ----------
  _buildScroll() {
    var self = this, w = this.scale.width, viewH = this.listBottom - this.listTop;
    this.listMaskGfx.clear();
    this.listMaskGfx.fillStyle(0xffffff, 1);
    this.listMaskGfx.fillRect(0, this.listTop, w, viewH);

    var dragging = false, startY = 0, startScroll = 0, moved = 0;
    var zone = this.add.zone(0, this.listTop, w, viewH).setOrigin(0).setInteractive().setDepth(41);
    this.listZone = zone;
    zone.on('pointerdown', function (p) { if (self._modal) return; dragging = true; startY = p.y; startScroll = self.scrollY || 0; moved = 0; });
    this.input.on('pointermove', function (p) {
      if (!dragging || self._modal) return;
      var dy = p.y - startY;
      moved = Math.max(moved, Math.abs(dy));
      self.scrollY = Phaser.Math.Clamp(startScroll - dy, 0, self.maxScroll || 0);
      self.listContainer.y = self.listTop - self.scrollY;
    });
    zone.on('pointerup', function (p) {
      var wasTap = dragging && moved <= 14;
      dragging = false;
      if (wasTap && !self._modal) self._onListTap(p.x, p.y);
    });
    this.input.on('pointerup', function () { dragging = false; });
    this.input.on('pointerupoutside', function () { dragging = false; });
    this.input.on('wheel', function (p, objs, dx, dy) {
      if (self._modal) return;
      self.scrollY = Phaser.Math.Clamp((self.scrollY || 0) + (dy || 0), 0, self.maxScroll || 0);
      self.listContainer.y = self.listTop - self.scrollY;
    });
  }

  /** Redimensionne la zone de liste (ex. barre d'action collée en bas de l'écran de préparation). */
  _layoutList(top, bottom) {
    this.listTop = top; this.listBottom = bottom;
    var w = this.scale.width, viewH = bottom - top;
    this.listMaskGfx.clear();
    this.listMaskGfx.fillStyle(0xffffff, 1);
    this.listMaskGfx.fillRect(0, top, w, viewH);
    if (this.listZone) { this.listZone.setPosition(0, top); this.listZone.setSize(w, viewH); }
  }

  _onListTap(px, py) {
    var lx = px, ly = py - this.listContainer.y;
    var cards = this._cards || [];
    for (var i = 0; i < cards.length; i++) {
      var c = cards[i], hits = c._hits || [];
      for (var j = 0; j < hits.length; j++) {
        var h = hits[j];
        if (lx >= 12 + h.x && lx <= 12 + h.x + h.w && ly >= c.y + h.y && ly <= c.y + h.y + h.h) {
          if (h.btn) this.tweens.add({ targets: h.btn, scale: 0.94, duration: 70, yoyo: true, ease: 'Sine.easeOut' });
          h.fn();
          return true;
        }
      }
    }
    return false;
  }

  // ---------- Rendu ----------
  _render(animate) {
    this._refreshTabs();
    this._stopFx();
    this._live = [];
    this._cardSeq = 0;
    this._animate = animate !== false;
    this.listContainer.removeAll(true);
    var w = this.scale.width;
    var r = this._renderTab(w) || { cards: [] };
    var y = 4;
    r.cards.forEach(function (c) { c.y = y; y += c._cardH + 14; });
    this._cards = r.cards;
    this.listContainer.add(r.cards);
    if (r.footer) { r.footer.y = y + 2; this.listContainer.add(r.footer); y += r.footerH || 44; }
    var viewH = this.listBottom - this.listTop;
    this.maxScroll = Math.max(0, y - viewH + 8);
    this.scrollY = Math.min(this.scrollY || 0, this.maxScroll);
    this.listContainer.y = this.listTop - this.scrollY;
  }

  /** Redessine l'en-tête (badge, pastilles) puis la liste, en gardant la position de défilement. */
  _refreshAll(animate) {
    if (this.badge) this._buildBadge();
    this._buildHub();
    this._render(animate === true);
  }

  _tickLive() {
    var i, l = this._live || [];
    for (i = 0; i < l.length; i++) {
      var it = l[i];
      try { if (it.t && it.t.active !== false) it.t.setText(it.fn()); } catch (e) { /* ignore */ }
    }
    this._onTick();
  }
  /** Enregistre un texte mis à jour chaque seconde (compte à rebours). */
  _liveText(textObj, fn) { this._live.push({ t: textObj, fn: fn }); textObj.setText(fn()); return textObj; }

  // ---------- Cartes ----------
  /** Carte vide (conteneur) : fond dégradé, liseré d'accent. _hits : zones de tap (relatives à la carte). */
  _card(h, accent, opts) {
    opts = opts || {};
    var w = this.scale.width, cw = w - 24, dim = !!opts.dim;
    var c = this.add.container(12, 0);
    c._cardH = h; c._hits = []; c._cw = cw;
    var glow = this._image(cw / 2, h / 2, 'tex_glow_white');
    if (glow && !dim) {
      glow.setDisplaySize(cw + 80, h + 80).setTint(accent).setBlendMode(Phaser.BlendModes.ADD).setAlpha(opts.glow ? 0.16 : 0.08);
      c.add(glow);
      if (opts.glow) this._loop({ targets: glow, alpha: 0.3, duration: 1100, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    }
    var bg = this.add.graphics();
    bg.fillGradientStyle(0x18223d, 0x18223d, 0x0a1122, 0x0a1122, 0.97);
    bg.fillRoundedRect(0, 0, cw, h, 20);
    bg.lineStyle(3, accent, dim ? 0.3 : 0.9);
    bg.strokeRoundedRect(0, 0, cw, h, 20);
    bg.fillStyle(accent, dim ? 0.25 : 0.85);
    bg.fillRoundedRect(28, 0, cw - 56, 4, 2);
    c.add(bg);
    return c;
  }

  /** Bouton dessiné dans une carte + zone de tap. `why` : texte affiché si le bouton est désactivé et touché. */
  _btn(card, cx, cy, bw, bh, label, accent, disabled, fn, why) {
    var self = this;
    var b = this.add.container(cx, cy);
    var g = this.add.graphics();
    var top = disabled ? 0x1a2233 : 0x1f2c52, bot = disabled ? 0x11172a : 0x0b1224;
    g.fillGradientStyle(top, top, bot, bot, 1);
    g.fillRoundedRect(-bw / 2, -bh / 2, bw, bh, bh * 0.3);
    g.lineStyle(2.5, accent, disabled ? 0.45 : 0.95);
    g.strokeRoundedRect(-bw / 2, -bh / 2, bw, bh, bh * 0.3);
    b.add(g);
    var t = this._txt(0, 0, label, bh >= 56 ? 22 : 19, disabled ? '#6d7c9c' : '#eaf2ff', { fontStyle: 'bold' }).setOrigin(0.5);
    this._fitWidth(t, bw - 14);
    b.add(t);
    card.add(b);
    var handler = disabled ? (why ? function () { self.fx.toast(why, null, null); } : null) : fn;
    if (handler) card._hits.push({ x: cx - bw / 2, y: cy - bh / 2, w: bw, h: bh, fn: handler, btn: b });
    return b;
  }

  /** Simple zone de tap sans dessin. */
  _tapZone(card, x, y, w, h, fn) { card._hits.push({ x: x, y: y, w: w, h: h, fn: fn }); }

  _bar(parent, x, y, w, h, frac, color, bgAlpha) {
    frac = Math.max(0, Math.min(1, frac || 0));
    var g = this.add.graphics();
    g.fillStyle(0x070c18, 0.95); g.fillRoundedRect(x, y, w, h, h / 2);
    if (frac > 0) { g.fillStyle(color, 1); g.fillRoundedRect(x, y, Math.max(h, w * frac), h, h / 2); }
    g.lineStyle(1.5, color, 0.55); g.strokeRoundedRect(x, y, w, h, h / 2);
    parent.add(g);
    return g;
  }

  _chip(parent, x, y, label, color, size) {
    size = size || 14;
    var t = this._txt(0, 0, label, size, this._hex(color), { fontStyle: 'bold' }).setOrigin(0.5);
    var pw = Math.max(44, (t.width || 40) + 18), ph = size + 12;
    var g = this.add.graphics();
    g.fillStyle(color, 0.18); g.fillRoundedRect(x, y, pw, ph, ph / 2.4);
    g.lineStyle(1.5, color, 0.85); g.strokeRoundedRect(x, y, pw, ph, ph / 2.4);
    parent.add(g);
    t.setPosition(x + pw / 2, y + ph / 2);
    parent.add(t);
    return pw;
  }

  /** Vignette de héros (portrait + liseré de rareté). */
  _heroThumb(parent, heroId, x, y, w, h, dim) {
    var H = NEBUSTION.Heroes, hero = H.get(heroId);
    if (!hero) return;
    var rar = H.RARITIES[hero.rarity] || H.RARITIES.commun;
    var img = this._image(x + w / 2, y + h / 2, H.portraitKey(heroId));
    if (img) { img.setDisplaySize(w, h); if (dim) img.setAlpha(0.4); parent.add(img); }
    else { var f = this.add.graphics(); f.fillStyle(0x121a30, 1); f.fillRoundedRect(x, y, w, h, 8); parent.add(f); }
    var b = this.add.graphics();
    b.lineStyle(2, rar.color, dim ? 0.4 : 0.9); b.strokeRoundedRect(x, y, w, h, 8);
    parent.add(b);
  }

  // ---------- Fenêtres modales ----------
  /**
   * cfg: { title, sub?, accent?, height?, build(panel, pw, ph)?, buttons:[{label, accent?, disabled?, fn, keep?}] }
   * Les zones de tap sont en coordonnées écran (une seule zone « dim » reçoit tous les appuis : aucun conflit d'entrées).
   */
  _openModal(cfg) {
    if (this._modal) return null;
    var self = this, w = this.scale.width, h = this.scale.height;
    var pw = w - 56, ph = cfg.height || 460, cx = w / 2, cy = h / 2 - 30, acc = cfg.accent || this._accent();
    var overlay = this.add.container(0, 0).setDepth(1100);
    var dim = this.add.rectangle(0, 0, w, h, 0x000000, 0.72).setOrigin(0).setInteractive();
    overlay.add(dim);
    var panel = this.add.container(cx, cy).setScale(0.9).setAlpha(0);
    overlay.add(panel);
    var bg = this.add.graphics();
    bg.fillGradientStyle(0x1a2247, 0x1a2247, 0x0b1224, 0x0b1224, 0.99);
    bg.fillRoundedRect(-pw / 2, -ph / 2, pw, ph, 26);
    bg.lineStyle(3, acc, 0.95);
    bg.strokeRoundedRect(-pw / 2, -ph / 2, pw, ph, 26);
    panel.add(bg);
    panel.add(this._txt(0, -ph / 2 + 32, cfg.title, 24, '#eaf2ff', { fontStyle: 'bold', align: 'center', wordWrap: { width: pw - 50 } }).setOrigin(0.5, 0.5));
    if (cfg.sub) panel.add(this._txt(0, -ph / 2 + 68, cfg.sub, 17, '#a9b8dc', { align: 'center', wordWrap: { width: pw - 70 } }).setOrigin(0.5, 0));
    if (cfg.build) cfg.build(panel, pw, ph);

    var btns = cfg.buttons || [], by = ph / 2 - 52, hits = [];
    var n = btns.length, bw = n > 1 ? (pw - 60) / 2 : Math.min(320, pw - 80);
    btns.forEach(function (b, i) {
      var bx = n > 1 ? (i === 0 ? -bw / 2 - 8 : bw / 2 + 8) : 0;
      var bc = self.add.container(bx, by);
      var g = self.add.graphics(), dis = !!b.disabled, top = dis ? 0x1a2233 : 0x1f2c52, bot = dis ? 0x11172a : 0x0b1224;
      g.fillGradientStyle(top, top, bot, bot, 1);
      g.fillRoundedRect(-bw / 2, -30, bw, 60, 18);
      g.lineStyle(2.5, b.accent || acc, dis ? 0.45 : 0.95);
      g.strokeRoundedRect(-bw / 2, -30, bw, 60, 18);
      bc.add(g);
      var t = self._txt(0, 0, b.label, 22, dis ? '#6d7c9c' : '#eaf2ff', { fontStyle: 'bold' }).setOrigin(0.5);
      self._fitWidth(t, bw - 16);
      bc.add(t);
      panel.add(bc);
      hits.push({ x: cx + bx - bw / 2, y: cy + by - 30, w: bw, h: 60, fn: function () {
        if (dis) { return; }
        if (self._modal && self._modal.busy) return;
        if (self._modal) self._modal.busy = true;
        if (!b.keep) self._closeModal();
        if (b.fn) b.fn();
        if (b.keep && self._modal) self._modal.busy = false;
      }, disabled: dis });
    });
    dim.on('pointerup', function (p) {
      if (!self._modal) return;
      var px = p.x, py = p.y;
      for (var i = 0; i < hits.length; i++) {
        var q = hits[i];
        if (px >= q.x && px <= q.x + q.w && py >= q.y && py <= q.y + q.h) { q.fn(); return; }
      }
      if (cfg.dismiss !== false && (px < cx - pw / 2 || px > cx + pw / 2 || py < cy - ph / 2 || py > cy + ph / 2)) self._closeModal();
    });
    this._modal = { overlay: overlay, dim: dim, hits: hits, busy: false, panel: panel };
    this.tweens.add({ targets: panel, scale: 1, alpha: 1, duration: 200, ease: 'Back.easeOut' });
    return this._modal;
  }

  _closeModal() {
    var m = this._modal;
    if (!m) return;
    this._modal = null;
    var overlay = m.overlay;
    try { m.dim.disableInteractive(); } catch (e) { /* ignore */ }
    this.tweens.add({ targets: overlay, alpha: 0, duration: 140, onComplete: function () { overlay.destroy(); } });
  }

  /** Fenêtre de résultat : lignes de récompenses [{kind, amount, label?, note?}] + textes libres. */
  _reveal(title, sub, rows, notes, accent, onClose) {
    var self = this, rowH = 44, list = (rows || []).filter(function (r) { return r && r.amount > 0; });
    var noteLines = (notes || []).filter(Boolean);
    var ph = Math.min(1000, 190 + list.length * rowH + noteLines.length * 30 + (sub ? 40 : 0) + 84);
    var m = this._openModal({
      title: title, sub: sub, accent: accent, height: ph,
      build: function (panel, pw, mh) {
        var y = -mh / 2 + (sub ? 132 : 96);
        list.forEach(function (r) {
          self._iconNode(panel, r.kind, -pw / 2 + 60, y, 34, r.color);
          panel.add(self._txt(-pw / 2 + 92, y, '+' + self._fmt(r.amount) + (r.label ? '  ' + r.label : ''), 24, r.hex || '#ffe9a3', { fontStyle: 'bold' }).setOrigin(0, 0.5));
          if (r.note) panel.add(self._txt(pw / 2 - 26, y, r.note, 15, '#ff9a7b', { align: 'right' }).setOrigin(1, 0.5));
          y += rowH;
        });
        noteLines.forEach(function (n) {
          panel.add(self._txt(0, y + 6, n, 18, '#a9b8dc', { align: 'center', wordWrap: { width: pw - 60 } }).setOrigin(0.5, 0));
          y += 30;
        });
      },
      buttons: [{ label: 'Super !', accent: accent || this._accent(), fn: onClose }]
    });
    if (m) { try { this.fx.ring(this.scale.width / 2, this.scale.height / 2 - 100, accent || this._accent(), 1.8); } catch (e) { /* ignore */ } }
    return m;
  }

  /** Confirmation d'une action : titre, lignes, boutons Annuler / libellé de confirmation. */
  _confirm(title, lines, confirmLabel, onConfirm, opts) {
    opts = opts || {};
    var self = this, ls = (lines || []).filter(Boolean);
    var est = 0; ls.forEach(function (l) { est += 26 + Math.ceil((l.length || 1) / 34) * 22; });
    return this._openModal({
      title: title, accent: opts.accent, height: Math.max(340, Math.min(900, 190 + est + (opts.extraH || 0))),
      build: function (panel, pw, mh) {
        var y = -mh / 2 + 84;
        ls.forEach(function (l) {
          var t = self._txt(0, y, l, 19, opts.warnColor && l.indexOf('⚠') === 0 ? '#ffb347' : '#c7d3f0', { align: 'center', wordWrap: { width: pw - 60 } }).setOrigin(0.5, 0);
          panel.add(t);
          y += (t.height || 24) + 12;
        });
      },
      buttons: [{ label: opts.cancelLabel || 'Annuler', accent: 0x394869 }, { label: confirmLabel || 'Confirmer', accent: opts.confirmAccent || 0x00e5ff, fn: onConfirm }]
    });
  }
};
