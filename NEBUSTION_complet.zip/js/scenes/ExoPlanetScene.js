/**
 * NEBUSTION - ExoPlanetScene
 * Les planètes du système solaire de la « Nouvelle Galaxie » (SolarSystemScene) : on touche une planète et on
 * arrive sur la MÊME sorte de planète 3D que Nexus-01 — une vraie sphère texturée que l'on tourne du doigt
 * (inertie, rotation lente au repos, nuages qui dérivent, lumière fixe, côté nuit). Chaque monde a son rendu :
 * Pyros (lave incandescente), Aqualis (océans + lune), Rubéa (désert), Goliath (géante gazeuse + grande tempête),
 * Saturnia (géante à anneaux), Glacia (banquise).
 *
 * La scène hérite de PlanetScene et en réutilise tout le moteur de sphère (projection, rotation, glissé, rendu
 * par pixel : voir PlanetRender.js) ; seuls les éléments propres à Nexus-01 (bâtiments, gisements, drones)
 * sont absents. Les rendus par monde sont dans NEBUSTION.PlanetRender (paramètre `biome`).
 */
window.NEBUSTION = window.NEBUSTION || {};

/** Fiches des mondes (id = celui de SolarSystemScene._planetDefs). */
NEBUSTION.ExoPlanets = (function () {
  'use strict';
  var LIST = [
    { id: 'pyros', name: 'Pyros', biome: 'lava', kind: 'Monde volcanique', diameter: '9 800 km', temp: '+480 °C', gravity: '0,9 g', atm: 0xff6a2a, r: 0.40,
      desc: 'Une croûte de basalte fissurée où coulent des rivières de lave. Le côté nuit reste embrasé.' },
    { id: 'aqualis', name: 'Aqualis', biome: 'ocean', kind: 'Monde océanique', diameter: '14 200 km', temp: '+18 °C', gravity: '1,0 g', atm: 0x62c0ff, r: 0.40, moon: true,
      desc: 'Des océans à perte de vue, quelques archipels et une lune fidèle. Le monde le plus accueillant du système.' },
    { id: 'rubea', name: 'Rubéa', biome: 'desert', kind: 'Désert rocheux', diameter: '11 000 km', temp: '−20 °C', gravity: '0,7 g', atm: 0xff9a6a, r: 0.39,
      desc: 'Dunes rouille, canyons profonds et tempêtes de poussière. Du givre seulement aux pôles.' },
    { id: 'goliath', name: 'Goliath', biome: 'gas', kind: 'Géante gazeuse', diameter: '138 000 km', temp: '−150 °C', gravity: '2,4 g', atm: 0xffc890, r: 0.43, startYaw: -0.55,
      desc: 'Aucun sol : des bandes de nuages géantes et une tempête grande comme plusieurs planètes.' },
    { id: 'saturnia', name: 'Saturnia', biome: 'ringgas', kind: 'Géante à anneaux', diameter: '116 000 km', temp: '−180 °C', gravity: '1,1 g', atm: 0xffe6a8, r: 0.235, ring: true, startPitch: -0.42,
      desc: 'Une géante pâle entourée d\'anneaux de glace et de roche, aussi larges que vingt mondes.' },
    { id: 'glacia', name: 'Glacia', biome: 'ice', kind: 'Monde glacé', diameter: '8 600 km', temp: '−190 °C', gravity: '0,6 g', atm: 0x9fe8ff, r: 0.39,
      desc: 'Une banquise sans fin zébrée de crevasses bleues, et des mers gelées qui reflètent l\'étoile.' }
  ];
  var BY = {};
  LIST.forEach(function (p) { BY[p.id] = p; });
  return { list: LIST, get: function (id) { return BY[id] || null; } };
})();

NEBUSTION.ExoPlanetScene = class ExoPlanetScene extends NEBUSTION.PlanetScene {
  constructor() {
    super('ExoPlanetScene');
  }

  init(data) {
    this._planetId = (data && data.planetId) || 'aqualis';
    this._from = (data && data.from) || 'SolarSystemScene';
    this._pendingOpenKey = null;
  }

  create() {
    var w = this.scale.width, h = this.scale.height;
    var def = NEBUSTION.ExoPlanets.get(this._planetId) || NEBUSTION.ExoPlanets.list[0];
    this._def = def; this._biome = def.biome; this._rimColor = def.atm;
    this._busy = false;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(350, 5, 7, 15);

    // Mêmes variables d'état que PlanetScene.create() : le moteur de sphère hérité s'en sert.
    this.nodes = {}; this.drones = []; this.pod = null;
    this._buildingBoxes = {}; this._buildingDefs = {};
    this._panelOpen = false; this._sheetOpen = false; this._barOpen = false; this._placing = null; this._structs = {};
    this._sphereAnchors = []; this._terrainAnchors = [];
    this._rotYaw = def.startYaw || 0; this._rotPitch = def.startPitch !== undefined ? def.startPitch : -0.16;
    this._rotVelYaw = 0; this._rotVelPitch = 0;
    this._dragging = false; this._dragMoved = 0; this._idleTime = 0;
    this._cloudRot = 0; this._lastRend = null; this._sphereImg = null; this._sphereR = null; this._slowCount = 0;
    this._ringPitch = NaN; this._moonA = 0.8;

    NEBUSTION.SceneBackground.build(this, { withPlanet: false });
    this._buildSphere();
    this._buildRingsAndMoon();
    this._buildHeader();
    this._buildInfoCard();
    this._setupPlanetDrag();
    this._applySphereTransform();
    this._updateExtras(0, 0);

    this.hud = NEBUSTION.HUD.attach(this);
    new NEBUSTION.BottomNav(this, 'galaxy');
  }

  // ------------------------------------------------------------------ sphère (rendu propre au monde)
  _buildSphere() {
    var w = this.scale.width, h = this.scale.height, def = this._def, ADD = Phaser.BlendModes.ADD;
    this._planetCX = w / 2;
    this._planetCY = h * 0.50;
    this._planetR = w * def.r;
    var cx = this._planetCX, cy = this._planetCY, R = this._planetR;

    // Atmosphère : halos à la couleur du monde (le liséré de bord est déjà dans la texture).
    this.add.image(cx, cy, 'tex_glow_white').setBlendMode(ADD).setTint(def.atm)
      .setDisplaySize(R * 2.7, R * 2.7).setAlpha(0.20).setDepth(-6);
    this.add.image(cx, cy - R * 0.06, 'tex_glow_white').setBlendMode(ADD).setTint(def.atm)
      .setDisplaySize(R * 2.25, R * 2.25).setAlpha(0.14).setDepth(-5);

    var st = (NEBUSTION.Settings && NEBUSTION.Settings.get && NEBUSTION.Settings.get()) || {};
    this._sphereRes = (st.batterySaver || st.reducedFX) ? 160 : 192;
    this._sphereR = this._makeSphereRenderer(this._sphereRes);
    this._sphereGfx = this.add.graphics().setDepth(0);
    this._roofGfx = null; this._roofDirty = false;
  }

  /** Comme PlanetScene, mais avec le biome du monde et aucun point d'ancrage (pas de base construite ici). */
  _makeSphereRenderer(res) {
    var r = null;
    try { r = NEBUSTION.PlanetRender ? NEBUSTION.PlanetRender.create(this, res, null, this._biome) : null; } catch (e) { r = null; }
    if (!r) return null;
    var size = this._planetR * 2 * res / (res - 3);
    if (this._sphereImg) this._sphereImg.setTexture(r.key);
    else this._sphereImg = this.add.image(this._planetCX, this._planetCY, r.key).setDepth(-1);
    this._sphereImg.setDisplaySize(size, size);
    this._lastRend = null;
    return r;
  }

  // ------------------------------------------------------------------ anneaux et lune
  _buildRingsAndMoon() {
    var def = this._def;
    if (def.ring) {
      this._ringBack = this.add.graphics().setDepth(-2);
      this._ringFront = this.add.graphics().setDepth(1);
    }
    if (def.moon) {
      var ST = NEBUSTION.SolarTextures;
      var key = ST.ensurePlanet(this, { id: 'lune', type: 'rock', seed: 7, c1: [176, 176, 184], c2: [110, 110, 120] });
      this._moon = this.add.image(0, 0, key).setDisplaySize(44, 44);
      this._moonShade = this.add.image(0, 0, ST.ensureShade(this)).setDisplaySize(44, 44).setRotation(Math.atan2(0.48, 0.52));   // face sombre à l'opposé du soleil (haut-gauche)
    }
  }

  /**
   * Anneaux : demi-anneaux concentriques dans le plan équatorial, vus sous l'angle donné par le basculement
   * courant (_rotPitch) — ils s'ouvrent ou se referment quand on incline la planète. La moitié lointaine passe
   * derrière le globe, la moitié proche devant. Redessinés seulement si l'inclinaison a changé.
   */
  _drawRings() {
    var pitch = this._rotPitch;
    if (Math.abs(pitch - this._ringPitch) < 0.0015) return;
    this._ringPitch = pitch;
    var cx = this._planetCX, cy = this._planetCY, R = this._planetR, sp = Math.sin(pitch), roll = -0.30;
    var cr = Math.cos(roll), sr = Math.sin(roll), gb = this._ringBack, gf = this._ringFront;
    gb.clear(); gf.clear();
    var S = 40, k, i, rho, a, phi, x, y, pts, prof, col;
    for (rho = 1.30; rho <= 2.06; rho += 0.02) {
      // profil de luminosité : anneau intérieur voile, bande principale, division, anneau extérieur
      prof = rho < 1.46 ? 0.22 : (rho < 1.86 ? 0.78 : (rho < 1.93 ? 0.10 : 0.52));
      prof *= 0.85 + 0.15 * Math.sin(rho * 71);
      col = rho < 1.86 ? 0xe9d6a4 : 0xc9b382;
      for (k = 0; k < 2; k++) {
        pts = [];
        for (i = 0; i <= S; i++) {
          phi = (k ? Math.PI : 0) + i / S * Math.PI;                       // k=0 : moitié proche ; k=1 : moitié lointaine
          x = Math.cos(phi) * rho * R; y = Math.sin(phi) * rho * R * sp;
          pts.push({ x: cx + x * cr - y * sr, y: cy + x * sr + y * cr });
        }
        (k ? gb : gf).lineStyle(R * 0.02 * 1.25 + 1, col, prof * (k ? 0.85 : 1));
        (k ? gb : gf).strokePoints(pts, false);
      }
    }
  }

  _updateExtras(time, delta) {
    if (this._def.ring) this._drawRings();
    if (this._moon) {
      this._moonA += 0.00055 * (delta || 0);
      var m = this._moonA, s = Math.sin(m), rr = this._planetR * 1.62;
      var mx = this._planetCX + Math.cos(m) * rr, my = this._planetCY - this._planetR * 0.18 + s * rr * 0.16 - Math.cos(m) * rr * 0.06;
      var k = 0.9 + 0.2 * s, front = s > 0;
      this._moon.setPosition(mx, my).setDisplaySize(44 * k, 44 * k).setDepth(front ? 2 : -3);
      this._moonShade.setPosition(mx, my).setDisplaySize(44 * k, 44 * k).setDepth(front ? 3 : -3);
    }
  }

  update(time, delta) {
    this._updatePlanetRotation(delta);
    this._updateExtras(time, delta);
  }

  // ------------------------------------------------------------------ interface
  _buildHeader() {
    var w = this.scale.width, self = this, def = this._def;
    var back = new NEBUSTION.Button(this, 46, 126, {
      width: 56, height: 44, accentColor: 0x6c3ce9,
      iconDraw: function (g) {
        g.lineStyle(2.5, 0x6c3ce9, 1);
        g.lineBetween(8, 0, -8, 0); g.lineBetween(-8, 0, -1, -7); g.lineBetween(-8, 0, -1, 7);
      },
      onClick: function () { self._goBack(); }
    });
    back.setDepth(1200);
    var glow = '#' + ('000000' + def.atm.toString(16)).slice(-6);
    this.add.text(w / 2, 126, def.name.toUpperCase(), {
      fontFamily: 'Arial, sans-serif', fontSize: '28px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(50).setShadow(0, 0, glow, 12, true, true);
    this.add.text(w / 2, 156, def.kind + '  ·  Système Héliora', {
      fontFamily: 'Arial, sans-serif', fontSize: '15px', color: '#8ea0c8'
    }).setOrigin(0.5).setDepth(50);
  }

  _buildInfoCard() {
    var w = this.scale.width, h = this.scale.height, def = this._def;
    var ch = 150, cy = h - 250, cw = 640;
    var g = this.add.graphics().setDepth(70);
    g.fillStyle(0x0b1224, 0.80); g.fillRoundedRect(w / 2 - cw / 2, cy - ch / 2, cw, ch, 16);
    g.lineStyle(1.5, def.atm, 0.45); g.strokeRoundedRect(w / 2 - cw / 2, cy - ch / 2, cw, ch, 16);
    this.add.text(w / 2, cy - 52, 'Ø ' + def.diameter + '   ·   ' + def.temp + '   ·   ' + def.gravity, {
      fontFamily: 'Arial, sans-serif', fontSize: '17px', fontStyle: 'bold', color: '#dfeaff'
    }).setOrigin(0.5).setDepth(71);
    this.add.text(w / 2, cy - 8, def.desc, {
      fontFamily: 'Arial, sans-serif', fontSize: '14px', color: '#aab8d8', align: 'center', wordWrap: { width: cw - 50 }
    }).setOrigin(0.5).setDepth(71);
    this.add.text(w / 2, cy + 52, 'Glisse pour faire tourner la planète', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#7a89ad'
    }).setOrigin(0.5).setDepth(71);
  }

  _goBack() {
    if (this._busy) return;
    this._busy = true;
    var from = this._from;
    this.cameras.main.fadeOut(300, 0, 0, 0);
    this.cameras.main.once('camerafadeoutcomplete', () => { this.scene.start(from, { from: 'UniverseScene' }); });
  }
};
