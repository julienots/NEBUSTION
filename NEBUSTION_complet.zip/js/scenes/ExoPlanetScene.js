/**
 * NEBUSTION - ExoPlanetScene
 * Les planètes du système solaire de la « Nouvelle Galaxie » (SolarSystemScene) : on touche une planète et on
 * arrive sur la MÊME sorte de planète 3D que Nexus-01 — une vraie sphère texturée que l'on tourne du doigt
 * (inertie, rotation lente au repos, nuages qui dérivent, lumière fixe, côté nuit). Chaque monde a son rendu :
 * Pyros (lave incandescente), Aqualis (océans + lune), Rubéa (désert), Goliath (géante gazeuse + grande tempête),
 * Saturnia (géante à anneaux), Glacia (banquise).
 *
 * La scène hérite de PlanetScene et en réutilise tout le moteur de sphère (projection, rotation, glissé, rendu
 * par pixel : voir PlanetRender.js) ; seuls les éléments propres à Nexus-01 (bâtiments, gisements, drones)
 * sont absents. Les rendus par monde sont dans NEBUSTION.PlanetRender (paramètre `biome`).
 */
window.NEBUSTION = window.NEBUSTION || {};

/** Fiches des mondes (id = celui de SolarSystemScene._planetDefs). */
NEBUSTION.ExoPlanets = (function () {
  'use strict';
  var LIST = [
    { id: 'pyros', name: 'Pyros', biome: 'lava', kind: 'Monde volcanique', diameter: '9 800 km', temp: '+480 °C', gravity: '0,9 g', atm: 0xff6a2a, r: 0.40,
      desc: 'Une croûte de basalte fissurée où coulent des rivières de lave. Le côté nuit reste embrasé.' },
    { id: 'aqualis', name: 'Aqualis', biome: 'ocean', kind: 'Monde océanique', diameter: '14 200 km', temp: '+18 °C', gravity: '1,0 g', atm: 0x62c0ff, r: 0.40, moon: true,
      desc: 'Des océans à perte de vue, quelques archipels et une lune fidèle. Le monde le plus accueillant du système.' },
    { id: 'rubea', name: 'Rubéa', biome: 'desert', kind: 'Désert rocheux', diameter: '11 000 km', temp: '−20 °C', gravity: '0,7 g', atm: 0xff9a6a, r: 0.39,
      desc: 'Dunes rouille, canyons profonds et tempêtes de poussière. Du givre seulement aux pôles.' },
    { id: 'goliath', name: 'Goliath', biome: 'gas', kind: 'Géante gazeuse', diameter: '138 000 km', temp: '−150 °C', gravity: '2,4 g', atm: 0xffc890, r: 0.43, startYaw: -0.55,
      desc: 'Aucun sol : des bandes de nuages géantes et une tempête grande comme plusieurs planètes.' },
    { id: 'saturnia', name: 'Saturnia', biome: 'ringgas', kind: 'Géante à anneaux', diameter: '116 000 km', temp: '−180 °C', gravity: '1,1 g', atm: 0xffe6a8, r: 0.235, ring: true, startPitch: -0.42,
      desc: 'Une géante pâle entourée d\'anneaux de glace et de roche, aussi larges que vingt mondes.' },
    { id: 'glacia', name: 'Glacia', biome: 'ice', kind: 'Monde glacé', diameter: '8 600 km', temp: '−190 °C', gravity: '0,6 g', atm: 0x9fe8ff, r: 0.39,
      desc: 'Une banquise sans fin zébrée de crevasses bleues, et des mers gelées qui reflètent l\'étoile.' }
  ];
  var BY = {};
  LIST.forEach(function (p) { BY[p.id] = p; });
  return { list: LIST, get: function (id) { return BY[id] || null; } };
})();

NEBUSTION.ExoPlanetScene = class ExoPlanetScene extends NEBUSTION.PlanetScene {
  constructor() {
    super('ExoPlanetScene');
  }

  init(data) {
    this._planetId = (data && data.planetId) || 'aqualis';
    this._from = (data && data.from) || 'SolarSystemScene';
    this._pendingOpenKey = null;
  }

  create() {
    var w = this.scale.width, h = this.scale.height;
    var def = NEBUSTION.ExoPlanets.get(this._planetId) || NEBUSTION.ExoPlanets.list[0];
    this._def = def; this._biome = def.biome; this._rimColor = def.atm;
    this._busy = false;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(350, 5, 7, 15);

    // Mêmes variables d'état que PlanetScene.create() : le moteur de sphère hérité s'en sert.
    this.nodes = {}; this.drones = []; this.pod = null;
    this._buildingBoxes = {}; this._buildingDefs = {};
    this._panelOpen = false; this._sheetOpen = false; this._barOpen = false; this._placing = null; this._structs = {};
    this._sphereAnchors = []; this._terrainAnchors = [];
    this._rotYaw = def.startYaw || 0; this._rotPitch = def.startPitch !== undefined ? def.startPitch : -0.16;
    this._rotVelYaw = 0; this._rotVelPitch = 0;
    this._dragging = false; this._dragMoved = 0; this._idleTime = 0;
    this._cloudRot = 0; this._lastRend = null; this._sphereImg = null; this._sphereR = null; this._slowCount = 0;
    this._ringPitch = NaN; this._moonA = 0.8;

    NEBUSTION.SceneBackground.build(this, { withPlanet: false });
    this._buildSphere();
    this._buildRingsAndMoon();
    this._buildHeader();
    if (this._initParcels) this._initParcels(def.id);   // parcelles à acheter (PlanetParcelsUI.js) ; sans effet sur les géantes gazeuses
    this._buildInfoCard();
    this._setupPlanetDrag();
    this._applySphereTransform();
    this._updateExtras(0, 0);

    this.hud = NEBUSTION.HUD.attach(this);
    new NEBUSTION.BottomNav(this, 'galaxy');
    this.fx = new NEBUSTION.FX(this);
    this._colonyC = null; this._colonyTimer = null;
    this.events.once('shutdown', () => { this._closeColony(); });
  }

  // ------------------------------------------------------------------ sphère (rendu propre au monde)
  _buildSphere() {
    var w = this.scale.width, h = this.scale.height, def = this._def, ADD = Phaser.BlendModes.ADD;
    this._planetCX = w / 2;
    this._planetCY = h * 0.50;
    this._planetR = w * def.r;
    var cx = this._planetCX, cy = this._planetCY, R = this._planetR;

    // Atmosphère : halos à la couleur du monde (le liséré de bord est déjà dans la texture).
    this.add.image(cx, cy, 'tex_glow_white').setBlendMode(ADD).setTint(def.atm)
      .setDisplaySize(R * 2.7, R * 2.7).setAlpha(0.20).setDepth(-6);
    this.add.image(cx, cy - R * 0.06, 'tex_glow_white').setBlendMode(ADD).setTint(def.atm)
      .setDisplaySize(R * 2.25, R * 2.25).setAlpha(0.14).setDepth(-5);

    var st = (NEBUSTION.Settings && NEBUSTION.Settings.get && NEBUSTION.Settings.get()) || {};
    this._sphereRes = (st.batterySaver || st.reducedFX) ? 160 : 192;
    this._sphereR = this._makeSphereRenderer(this._sphereRes);
    this._sphereGfx = this.add.graphics().setDepth(0);
    this._roofGfx = null; this._roofDirty = false;
  }

  /** Comme PlanetScene, mais avec le biome du monde et aucun point d'ancrage (pas de base construite ici). */
  _makeSphereRenderer(res) {
    var r = null;
    try { r = NEBUSTION.PlanetRender ? NEBUSTION.PlanetRender.create(this, res, null, this._biome) : null; } catch (e) { r = null; }
    if (!r) return null;
    var size = this._planetR * 2 * res / (res - 3);
    if (this._sphereImg) this._sphereImg.setTexture(r.key);
    else this._sphereImg = this.add.image(this._planetCX, this._planetCY, r.key).setDepth(-1);
    this._sphereImg.setDisplaySize(size, size);
    this._lastRend = null;
    return r;
  }

  // ------------------------------------------------------------------ anneaux et lune
  _buildRingsAndMoon() {
    var def = this._def;
    if (def.ring) {
      this._ringBack = this.add.graphics().setDepth(-2);
      this._ringFront = this.add.graphics().setDepth(1);
    }
    if (def.moon) {
      var ST = NEBUSTION.SolarTextures;
      var key = ST.ensurePlanet(this, { id: 'lune', type: 'rock', seed: 7, c1: [176, 176, 184], c2: [110, 110, 120] });
      this._moon = this.add.image(0, 0, key).setDisplaySize(44, 44);
      this._moonShade = this.add.image(0, 0, ST.ensureShade(this)).setDisplaySize(44, 44).setRotation(Math.atan2(0.48, 0.52));   // face sombre à l'opposé du soleil (haut-gauche)
    }
  }

  /**
   * Anneaux : demi-anneaux concentriques dans le plan équatorial, vus sous l'angle donné par le basculement
   * courant (_rotPitch) — ils s'ouvrent ou se referment quand on incline la planète. La moitié lointaine passe
   * derrière le globe, la moitié proche devant. Redessinés seulement si l'inclinaison a changé.
   */
  _drawRings() {
    var pitch = this._rotPitch;
    if (Math.abs(pitch - this._ringPitch) < 0.0015) return;
    this._ringPitch = pitch;
    var cx = this._planetCX, cy = this._planetCY, R = this._planetR, sp = Math.sin(pitch), roll = -0.30;
    var cr = Math.cos(roll), sr = Math.sin(roll), gb = this._ringBack, gf = this._ringFront;
    gb.clear(); gf.clear();
    var S = 40, k, i, rho, a, phi, x, y, pts, prof, col;
    for (rho = 1.30; rho <= 2.06; rho += 0.02) {
      // profil de luminosité : anneau intérieur voile, bande principale, division, anneau extérieur
      prof = rho < 1.46 ? 0.22 : (rho < 1.86 ? 0.78 : (rho < 1.93 ? 0.10 : 0.52));
      prof *= 0.85 + 0.15 * Math.sin(rho * 71);
      col = rho < 1.86 ? 0xe9d6a4 : 0xc9b382;
      for (k = 0; k < 2; k++) {
        pts = [];
        for (i = 0; i <= S; i++) {
          phi = (k ? Math.PI : 0) + i / S * Math.PI;                       // k=0 : moitié proche ; k=1 : moitié lointaine
          x = Math.cos(phi) * rho * R; y = Math.sin(phi) * rho * R * sp;
          pts.push({ x: cx + x * cr - y * sr, y: cy + x * sr + y * cr });
        }
        (k ? gb : gf).lineStyle(R * 0.02 * 1.25 + 1, col, prof * (k ? 0.85 : 1));
        (k ? gb : gf).strokePoints(pts, false);
      }
    }
  }

  _updateExtras(time, delta) {
    if (this._def.ring) this._drawRings();
    if (this._moon) {
      this._moonA += 0.00055 * (delta || 0);
      var m = this._moonA, s = Math.sin(m), rr = this._planetR * 1.62;
      var mx = this._planetCX + Math.cos(m) * rr, my = this._planetCY - this._planetR * 0.18 + s * rr * 0.16 - Math.cos(m) * rr * 0.06;
      var k = 0.9 + 0.2 * s, front = s > 0;
      this._moon.setPosition(mx, my).setDisplaySize(44 * k, 44 * k).setDepth(front ? 2 : -3);
      this._moonShade.setPosition(mx, my).setDisplaySize(44 * k, 44 * k).setDepth(front ? 3 : -3);
    }
  }

  update(time, delta) {
    this._updatePlanetRotation(delta);
    this._updateExtras(time, delta);
  }

  // ------------------------------------------------------------------ interface
  _buildHeader() {
    var w = this.scale.width, self = this, def = this._def;
    var back = new NEBUSTION.Button(this, 46, 126, {
      width: 56, height: 44, accentColor: 0x6c3ce9,
      iconDraw: function (g) {
        g.lineStyle(2.5, 0x6c3ce9, 1);
        g.lineBetween(8, 0, -8, 0); g.lineBetween(-8, 0, -1, -7); g.lineBetween(-8, 0, -1, 7);
      },
      onClick: function () { self._goBack(); }
    });
    back.setDepth(1200);
    var glow = '#' + ('000000' + def.atm.toString(16)).slice(-6);
    this.add.text(w / 2, 126, def.name.toUpperCase(), {
      fontFamily: 'Arial, sans-serif', fontSize: '28px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(50).setShadow(0, 0, glow, 12, true, true);
    this.add.text(w / 2, 156, def.kind + '  ·  Système Héliora', {
      fontFamily: 'Arial, sans-serif', fontSize: '15px', color: '#8ea0c8'
    }).setOrigin(0.5).setDepth(50);
  }

  _buildInfoCard() {
    var w = this.scale.width, h = this.scale.height, def = this._def;
    var ch = 150, cy = h - 250, cw = 640;
    var g = this.add.graphics().setDepth(70);
    g.fillStyle(0x0b1224, 0.80); g.fillRoundedRect(w / 2 - cw / 2, cy - ch / 2, cw, ch, 16);
    g.lineStyle(1.5, def.atm, 0.45); g.strokeRoundedRect(w / 2 - cw / 2, cy - ch / 2, cw, ch, 16);
    this.add.text(w / 2, cy - 52, 'Ø ' + def.diameter + '   ·   ' + def.temp + '   ·   ' + def.gravity, {
      fontFamily: 'Arial, sans-serif', fontSize: '17px', fontStyle: 'bold', color: '#dfeaff'
    }).setOrigin(0.5).setDepth(71);
    this.add.text(w / 2, cy - 8, def.desc, {
      fontFamily: 'Arial, sans-serif', fontSize: '14px', color: '#aab8d8', align: 'center', wordWrap: { width: cw - 50 }
    }).setOrigin(0.5).setDepth(71);
    var hasParcels = !!(this._pcGfx && this._pcEnter);
    this.add.text(w / 2, cy + 30, hasParcels ? 'Glisse pour faire tourner la planète' : 'Glisse pour faire tourner la planète' + (NEBUSTION.Parcels && NEBUSTION.Parcels.WORLDS[def.id] && !NEBUSTION.Parcels.WORLDS[def.id].solid ? '  ·  Géante gazeuse : pas de parcelles' : ''), {
      fontFamily: 'Arial, sans-serif', fontSize: '12px', color: '#7a89ad'
    }).setOrigin(0.5).setDepth(71);
    var self = this, CM = NEBUSTION.ColonyManager, on = CM && CM.isColonized(def.id);
    this._colBtn = new NEBUSTION.Button(this, hasParcels ? w / 2 - 156 : w / 2, cy + 58, {
      width: hasParcels ? 300 : 360, height: 40, accentColor: on ? 0x5fd97a : def.atm, fontSize: '18px',
      label: on ? '🏗️ Ma colonie' : '🚀 Coloniser ' + def.name,
      onClick: function () { self._openColony(); }
    });
    this._colBtn.setDepth(72);
    if (hasParcels) {
      // Parcelles : on tourne la planète, on touche une parcelle, on l'achète (+1 % de production de la colonie par parcelle).
      this._pcMainBtn = new NEBUSTION.Button(this, w / 2 + 156, cy + 58, {
        width: 300, height: 40, accentColor: 0xffd166, fontSize: '18px', label: '🗺️ Parcelles',
        onClick: function () { self._pcEnter(); }
      });
      this._pcMainBtn.setDepth(72);
    }
  }

  _goBack() {
    if (this._busy) return;
    this._busy = true;
    var from = this._from;
    this.cameras.main.fadeOut(300, 0, 0, 0);
    this.cameras.main.once('camerafadeoutcomplete', () => { this.scene.start(from, { from: 'UniverseScene' }); });
  }

  // ------------------------------------------------------------------ colonie
  _fmtN(n) { try { return NEBUSTION.Economy.fmt(n); } catch (e) { return String(Math.floor(n)); } }
  _fmtRate(v) { var x = v < 10 ? Math.round(v * 10) / 10 : Math.round(v); return String(x).replace('.', ','); }
  _resShort(id) { var r = NEBUSTION.Economy.RES[id]; return r ? r.short : id; }
  _resHex(id) { var r = NEBUSTION.Economy.RES[id]; return r ? r.hex : '#ffffff'; }
  _costStr(cost) { var self = this; return Object.keys(cost || {}).map(function (k) { return self._fmtN(cost[k]) + ' ' + self._resShort(k); }).join(' + '); }
  _bundleStr(b) { var self = this, k = Object.keys(b || {}); return k.length ? k.map(function (i) { return '+' + self._fmtN(b[i]) + ' ' + self._resShort(i); }).join('  ') : '—'; }

  _closeColony() {
    if (this._colonyTimer) { try { this._colonyTimer.remove(false); } catch (e) { /* ignore */ } this._colonyTimer = null; }
    if (this._colonyC) { try { this._colonyC.destroy(true); } catch (e) { /* ignore */ } this._colonyC = null; }
    this._colPend = null; this._colGo = null;
  }

  _openColony() {
    if (this._busy || this._colonyC || !NEBUSTION.ColonyManager) return;
    this._renderColony();
    var self = this;
    this._colonyTimer = this.time.addEvent({ delay: 1000, loop: true, callback: function () { self._tickColony(); } });
  }

  /** Met à jour seulement le texte « en attente » (sans recréer les boutons : un appui en cours ne se perd pas). */
  _tickColony() {
    var CM = NEBUSTION.ColonyManager, id = this._def.id;
    if (!this._colPend || !CM.isColonized(id)) return;
    var p = CM.pending(id, Date.now());
    this._colPend.setText('En attente : ' + this._bundleStr(p) + (CM.isFull(id, Date.now()) ? '   (plein)' : ''));
  }

  _colZone(c, x, y, w, h, fn) {
    var z = this.add.zone(x, y, w, h).setInteractive({ useHandCursor: true });
    z.on('pointerup', fn); c.add(z); return z;
  }

  _colBtn2(c, x, y, bw, bh, label, sub, accent, disabled, fn) {
    var g = this.add.graphics();
    g.fillStyle(disabled ? 0x141c30 : 0x1c2a52, 1); g.fillRoundedRect(x - bw / 2, y - bh / 2, bw, bh, 12);
    g.lineStyle(2, accent, disabled ? 0.4 : 0.95); g.strokeRoundedRect(x - bw / 2, y - bh / 2, bw, bh, 12);
    c.add(g);
    var t = this.add.text(x, y - (sub ? 9 : 0), label, { fontFamily: 'Arial, sans-serif', fontSize: '18px', fontStyle: 'bold', color: disabled ? '#6d7c9c' : '#eaf2ff' }).setOrigin(0.5);
    if (t.width > bw - 12) t.setScale((bw - 12) / t.width);
    c.add(t);
    if (sub) {
      var t2 = this.add.text(x, y + 13, sub, { fontFamily: 'Arial, sans-serif', fontSize: '12px', color: disabled ? '#5a6788' : '#ffd166' }).setOrigin(0.5);
      if (t2.width > bw - 12) t2.setScale((bw - 12) / t2.width);
      c.add(t2);
    }
    this._colZone(c, x, y, bw, bh, fn);
  }

  _renderColony() {
    var self = this, w = this.scale.width, h = this.scale.height, def = this._def, id = def.id;
    var CM = NEBUSTION.ColonyManager, K = NEBUSTION.Colonies, D = K.get(id), R = NEBUSTION.Resources;
    if (!D) return;
    this._closeColony();
    var on = CM.isColonized(id), now = Date.now();
    var pw = w - 50, ph = on ? 800 : 520, cx = w / 2, cy = h / 2;
    var c = this.add.container(0, 0).setDepth(1400); this._colonyC = c;
    var dim = this.add.rectangle(0, 0, w, h, 0x000000, 0.82).setOrigin(0).setInteractive(); c.add(dim);
    var g = this.add.graphics();
    g.fillGradientStyle(0x1a2247, 0x1a2247, 0x0b1224, 0x0b1224, 0.99); g.fillRoundedRect(cx - pw / 2, cy - ph / 2, pw, ph, 24);
    g.lineStyle(3, def.atm, 0.95); g.strokeRoundedRect(cx - pw / 2, cy - ph / 2, pw, ph, 24);
    c.add(g);
    var top = cy - ph / 2, left = cx - pw / 2;
    function T(x, y, s, size, color, extra) { var t = self.add.text(x, y, s, Object.assign({ fontFamily: 'Arial, sans-serif', fontSize: size + 'px', color: color }, extra || {})); c.add(t); return t; }

    T(cx, top + 34, (on ? 'COLONIE · ' : 'COLONISER · ') + def.name.toUpperCase(), 26, '#eaf2ff', { fontStyle: '900' }).setOrigin(0.5);
    // fermer
    var xg = this.add.graphics(); xg.lineStyle(3, 0x9fb0d8, 1); var xx = left + pw - 40, xy = top + 34;
    xg.lineBetween(xx - 9, xy - 9, xx + 9, xy + 9); xg.lineBetween(xx - 9, xy + 9, xx + 9, xy - 9); c.add(xg);
    this._colZone(c, xx, xy, 60, 60, function () { self._closeColony(); });

    if (!on) {
      T(cx, top + 92, def.kind, 18, '#8ea0c8').setOrigin(0.5);
      T(cx, top + 130, 'Fonde une colonie pour exploiter ce monde : 3 installations qui produisent en continu, même hors ligne (jusqu\'à ' + K.CAP_HOURS + ' h de stock).', 17, '#aab8d8', { align: 'center', wordWrap: { width: pw - 70 } }).setOrigin(0.5, 0);
      var y = top + 250;
      D.inst.forEach(function (d) {
        T(left + 44, y, d.icon + '  ' + d.name, 19, '#dfeaff', { fontStyle: 'bold' });
        T(left + pw - 44, y + 2, self._resShort(d.res), 16, self._resHex(d.res)).setOrigin(1, 0);
        y += 40;
      });
      T(cx, top + 392, 'Bonus : +' + Math.round(K.COLONY_BONUS * 100) + ' % de production sur TOUTES tes colonies, par colonie fondée.', 15, '#5fd97a', { align: 'center', wordWrap: { width: pw - 70 } }).setOrigin(0.5, 0);
      var can = R.canAfford(D.colonize);
      this._colBtn2(c, cx, top + ph - 62, pw - 80, 72, '🚀 FONDER LA COLONIE', this._costStr(D.colonize), def.atm, !can, function () {
        var r = CM.colonize(id, Date.now());
        if (r.ok) { self.fx.toast('Colonie fondée sur ' + def.name, '3 installations niveau 1', null); self.fx.vibrate(40); self._renderColony(); self._refreshColBtn(); }
        else self.fx.toast('Ressources insuffisantes', self._costStr(D.colonize), null);
      });
      return;
    }

    // ----- colonie active
    var rates = CM.rates(id), rk = Object.keys(rates);
    T(cx, top + 78, rk.length ? rk.map(function (k) { return self._fmtRate(rates[k] * 60) + ' ' + self._resShort(k) + '/min'; }).join('  ·  ') : '—', 16, '#a9b8dc', { align: 'center', wordWrap: { width: pw - 60 } }).setOrigin(0.5, 0);
    T(cx, top + 112, 'Bonus colonies : ×' + String(CM.bonusMult().toFixed(2)).replace('.', ',') + '  (' + CM.count() + '/' + K.IDS.length + ' colonies)' + (CM.planetMult(id) > 1 ? '  ·  Parcelles : +' + Math.round((CM.planetMult(id) - 1) * 100) + ' %' : ''), 14, '#5fd97a').setOrigin(0.5, 0);
    this._colPend = T(cx, top + 148, '', 18, '#ffe9a3', { fontStyle: 'bold', align: 'center', wordWrap: { width: pw - 60 } }).setOrigin(0.5, 0);
    this._tickColony();
    var pend = CM.pendingTotal(id, now) > 0;
    this._colBtn2(c, cx, top + 236, pw - 80, 64, '📥 RÉCOLTER', null, 0x5fd97a, !pend, function () {
      var r = CM.collect(id, Date.now());
      if (r.ok) { self.fx.toast('Récolte : ' + self._bundleStr(r.gained), r.partial ? 'Stockage presque plein : le reste attend' : null, null); self.fx.vibrate(25); self._renderColony(); }
      else self.fx.toast(r.reason === 'plein' ? 'Stockage plein' : 'Rien à récolter', null, null);
    });

    var y2 = top + 300;
    D.inst.forEach(function (d) {
      var lv = CM.level(id, d.id), max = lv >= K.MAX_LEVEL, rowH = 130;
      var rg = self.add.graphics(); rg.fillStyle(0x0b1224, 0.75); rg.fillRoundedRect(left + 20, y2, pw - 40, rowH - 10, 14);
      rg.lineStyle(1.5, def.atm, 0.4); rg.strokeRoundedRect(left + 20, y2, pw - 40, rowH - 10, 14); c.add(rg);
      T(left + 40, y2 + 14, d.icon + '  ' + d.name, 20, '#eaf2ff', { fontStyle: 'bold' });
      T(left + 40, y2 + 46, 'Niv. ' + lv + '/' + K.MAX_LEVEL + '  ·  ' + self._resShort(d.res) + ' ' + self._fmtRate(K.rateAt(id, d.id, lv) * CM.bonusMult() * CM.planetMult(id) * 60) + '/min', 15, self._resHex(d.res));
      if (!max) T(left + 40, y2 + 70, '→ Niv. ' + (lv + 1) + ' : ' + self._fmtRate(K.rateAt(id, d.id, lv + 1) * CM.bonusMult() * CM.planetMult(id) * 60) + '/min', 13, '#7a89ad');
      var bx = left + pw - 40 - 130, by = y2 + (rowH - 10) / 2;
      if (max) {
        T(bx, by, 'MAX', 22, '#ffd166', { fontStyle: 'bold' }).setOrigin(0.5);
      } else {
        var cost = K.upgradeCost(id, d.id, lv), afford = R.canAfford(cost);
        self._colBtn2(c, bx, by, 240, 70, 'AMÉLIORER', self._costStr(cost), def.atm, !afford, function () {
          var r = CM.upgrade(id, d.id, Date.now());
          if (r.ok) { self.fx.toast(d.name + ' → niv. ' + r.level, null, null); self.fx.vibrate(20); self._renderColony(); }
          else self.fx.toast(r.reason === 'max' ? 'Niveau maximum' : 'Ressources insuffisantes', r.cost ? self._costStr(r.cost) : null, null);
        });
      }
      y2 += rowH;
    });
    T(cx, top + ph - 28, 'Production hors ligne : ' + K.CAP_HOURS + ' h max. Touche « Récolter » régulièrement.', 13, '#7a89ad').setOrigin(0.5);
  }

  _refreshColBtn() {
    if (!this._colBtn || !this._colBtn.labelText) return;
    var on = NEBUSTION.ColonyManager.isColonized(this._def.id);
    this._colBtn.labelText.setText(on ? '🏗️ Ma colonie' : '🚀 Coloniser ' + this._def.name);
  }
};
