/**
 * NEBUSTION - ShopScene
 * Boutique Galactique (étape 7/10) : 5 onglets — Quotidien / Héros / Équipement / Skins / Événement.
 * Monnaie gratuite = ressources déjà en jeu (dust/crystal/energy/core/metal) ; monnaie premium =
 * Prismes (NEBUSTION.Shop.GEM), gagnés en jeu (cadeau quotidien, offres « Prismes bonus »).
 * Toute donnée provient de js/data/Shop.js + js/systems/ShopManager.js.
 *
 * Entrées tactiles : UNE seule zone sur la liste gère le glissement ET le tap (comme HeroesScene).
 * Les boutons des cartes ne sont donc PAS interactifs : chaque carte déclare des « zones de tap »
 * (card._hits) testées au relâchement si le doigt n'a presque pas bougé. La fenêtre de confirmation
 * fonctionne de la même façon (zones en coordonnées écran) — aucun conflit d'entrées possible.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.ShopScene = class ShopScene extends Phaser.Scene {
  constructor() { super('ShopScene'); }

  init(data) {
    this.tab = (data && data.tab === 'cards') ? 'heroes' : ((data && data.tab) || 'daily');
    this.equipRarity = 'rare';
    // Onglet Héros : ouvre sur le héros demandé (ex. depuis la Collection), sinon sur le premier héros à recruter.
    var allHeroes = NEBUSTION.Heroes.all(), hIdx = 0, wanted = data && data.heroId, found = false;
    for (var hi = 0; hi < allHeroes.length; hi++) {
      if (wanted ? allHeroes[hi].id === wanted : !NEBUSTION.Combat.isUnlocked(allHeroes[hi].id)) { hIdx = hi; found = true; break; }
    }
    this.heroIndex = found ? hIdx : 0;
    this.scrollY = 0;
    this.maxScroll = 0;
    this._cards = [];
    this._fxTweens = [];
    this._modal = null;
  }

  create() {
    var w = this.scale.width, h = this.scale.height;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(250, 5, 7, 15);
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });
    this.fx = new NEBUSTION.FX(this);

    var shopTitle = this._txt(20, 173, 'BOUTIQUE GALACTIQUE', 29, '#eaf2ff', { fontStyle: '900' })
      .setOrigin(0, 0.5).setDepth(50).setShadow(0, 0, '#e6c6ff', 12, true, true);
    this._fitWidth(shopTitle, Math.max(150, w - 190));

    // Décalés sous la barre de ressources permanente (HUD, depth 1200, jusqu'à y≈104) pour ne
    // plus jamais s'y superposer, quelle que soit la largeur d'écran.
    this.gemsBadge = this.add.container(w - 16, 148).setDepth(60);
    this._buildGemsBadge();
    this.xonBadge = this.add.container(w - 16, 198).setDepth(60);
    this._buildXonBadge();

    this.tabsY = 256;
    this._buildTabs();

    this.listTop = this.tabsY + 40;
    this.listBottom = h - 132;
    this.listContainer = this.add.container(0, this.listTop).setDepth(40);
    this.listMaskGfx = this.make.graphics();
    this.listContainer.setMask(this.listMaskGfx.createGeometryMask());
    this._buildScroll();

    this._render(true);
    this.hud = NEBUSTION.HUD.attach(this);
    new NEBUSTION.BottomNav(this, 'shop');
  }

  // ---------- Petits utilitaires ----------
  _txt(x, y, str, size, color, extra) {
    var st = { fontFamily: 'Arial, sans-serif', fontSize: size + 'px', color: color || '#eaf2ff', resolution: 2 };
    if (extra) Object.keys(extra).forEach(function (k) { st[k] = extra[k]; });
    return this.add.text(x, y, str, st);
  }

  /** Image seulement si la texture existe (jamais de cadre vert « texture manquante »). */
  _image(x, y, key) {
    if (!this.textures.exists(key)) return null;
    return this.add.image(x, y, key);
  }

  /** Tween d'ambiance mémorisé pour être arrêté au prochain rendu de la liste. */
  _loop(cfg) {
    var tw = this.tweens.add(cfg);
    this._fxTweens.push(tw);
    return tw;
  }

  _stopFx() {
    (this._fxTweens || []).forEach(function (t) { try { if (t && t.stop) t.stop(); } catch (e) { /* ignore */ } });
    this._fxTweens = [];
  }

  _fitWidth(t, maxW) {
    var tw = t.width || 0;
    if (tw > maxW && tw > 0) t.setScale(maxW / tw);
    return t;
  }

  // ---------- Badge Prismes ----------
  _drawGem(g, x, y, r, color) {
    g.fillStyle(color, 1);
    g.fillTriangle(x, y - r, x - r, y - r * 0.15, x + r, y - r * 0.15);
    g.fillStyle(color, 0.7);
    g.fillTriangle(x - r, y - r * 0.15, x + r, y - r * 0.15, x, y + r);
    g.lineStyle(Math.max(1.5, r * 0.08), 0xffffff, 0.55);
    g.lineBetween(x - r, y - r * 0.15, x + r, y - r * 0.15);
    g.lineBetween(x, y - r, x, y + r);
  }

  _buildGemsBadge() {
    var K = NEBUSTION.Shop;
    this.gemsBadge.removeAll(true);
    var bw = 168, bh = 46;
    var g = this.add.graphics();
    g.fillStyle(0x1d1533, 0.95);
    g.fillRoundedRect(-bw, -bh / 2, bw, bh, 23);
    g.lineStyle(2, K.GEM.color, 0.85);
    g.strokeRoundedRect(-bw, -bh / 2, bw, bh, 23);
    this.gemsBadge.add(g);
    var gemGfx = this.add.graphics();
    this._drawGem(gemGfx, -bw + 28, 0, 14, K.GEM.color);
    this.gemsBadge.add(gemGfx);
    this.gemsBadge.add(this._txt(-bw + 52, 0, NEBUSTION.Economy.fmt(NEBUSTION.ShopManager.gems()), 24, '#eaf2ff', { fontStyle: 'bold' }).setOrigin(0, 0.5));
  }

  // ---------- Jeton Xon : emblème unique dessiné directement dans Phaser ----------
  _drawXon(g, x, y, r, color) {
    var pts = [];
    for (var i = 0; i < 8; i++) {
      var a = -Math.PI / 8 + i * Math.PI / 4;
      pts.push({ x: x + Math.cos(a) * r, y: y + Math.sin(a) * r });
    }
    g.fillStyle(0x070b19, 1); g.fillPoints(pts, true);
    g.lineStyle(Math.max(2, r * 0.12), color, 0.95); g.strokePoints(pts, true);
    g.lineStyle(Math.max(1, r * 0.06), 0xffffff, 0.7); g.strokeCircle(x, y, r * 0.66);
    g.fillStyle(color, 0.18); g.fillCircle(x, y, r * 0.58);
    g.lineStyle(Math.max(2, r * 0.12), 0xffffff, 0.9);
    g.lineBetween(x - r * 0.30, y - r * 0.30, x + r * 0.30, y + r * 0.30);
    g.lineBetween(x + r * 0.30, y - r * 0.30, x - r * 0.30, y + r * 0.30);
    g.fillStyle(0xffffff, 0.95); g.fillCircle(x - r * 0.22, y - r * 0.27, Math.max(1.5, r * 0.07));
  }

  _buildXonBadge() {
    var K = NEBUSTION.Shop;
    this.xonBadge.removeAll(true);
    var bw = 142, bh = 42;
    var g = this.add.graphics();
    g.fillGradientStyle(0x0d2630, 0x11152d, 0x071018, 0x0b0b1a, 0.98);
    g.fillRoundedRect(-bw, -bh / 2, bw, bh, 21);
    g.lineStyle(2, K.XON.color, 0.95); g.strokeRoundedRect(-bw, -bh / 2, bw, bh, 21);
    this.xonBadge.add(g);
    var xg = this.add.graphics(); this._drawXon(xg, -bw + 24, 0, 13, K.XON.color); this.xonBadge.add(xg);
    this.xonBadge.add(this._txt(-bw + 47, 0, NEBUSTION.Economy.fmt(NEBUSTION.ShopManager.xon()), 22, '#eaf2ff', { fontStyle: 'bold' }).setOrigin(0, 0.5));
    this.xonBadge.add(this._txt(-18, 0, 'XON', 13, K.XON.hex, { fontStyle: 'bold' }).setOrigin(1, 0.5));
  }

  // ---------- Onglets ----------
  _tabDefs() {
    return [
      { id: 'daily', label: 'Quotidien' },
      { id: 'heroes', label: 'Héros' },
      { id: 'equipment', label: 'Équip.' },
      { id: 'troops', label: 'Troupes' },
      { id: 'skins', label: 'Skins' },
      { id: 'event', label: 'Évén.' }
    ];
  }

  _drawTab(t, active) {
    t.g.clear();
    t.g.fillGradientStyle(active ? 0x24386e : 0x101a33, active ? 0x24386e : 0x101a33, active ? 0x132048 : 0x0a1122, active ? 0x132048 : 0x0a1122, 0.97);
    t.g.fillRoundedRect(t.x - t.cw / 2, -24, t.cw, 48, 14);
    t.g.lineStyle(active ? 3 : 1.5, active ? 0x00e5ff : 0x394869, active ? 0.95 : 0.75);
    t.g.strokeRoundedRect(t.x - t.cw / 2, -24, t.cw, 48, 14);
    t.label.setColor(active ? '#eaf2ff' : '#8e9cc0');
  }

  _buildTabs() {
    var self = this, w = this.scale.width, tabs = this._tabDefs();
    this.tabsBar = this.add.container(0, this.tabsY).setDepth(45);
    var gap = 6, cw = (w - 20 - gap * (tabs.length - 1)) / tabs.length;
    this._tabDraw = [];
    tabs.forEach(function (t, i) {
      var x = 10 + cw / 2 + i * (cw + gap);
      var g = self.add.graphics();
      var label = self._txt(x, 0, t.label, 21, '#8e9cc0', { fontStyle: 'bold' }).setOrigin(0.5);
      self._fitWidth(label, cw - 14);
      var zone = self.add.zone(x, 0, cw, 48).setInteractive({ useHandCursor: true });
      zone.on('pointerup', function () {
        if (self._modal || self.tab === t.id) return;
        self.tab = t.id; self.scrollY = 0; self._render(true);
      });
      self.tabsBar.add([g, label, zone]);
      var rec = { id: t.id, g: g, label: label, cw: cw, x: x };
      self._tabDraw.push(rec);
      self._drawTab(rec, self.tab === t.id);
    });
  }

  _refreshTabs() {
    var self = this;
    this._tabDraw.forEach(function (t) { self._drawTab(t, self.tab === t.id); });
  }

  // ---------- Défilement + tap (une seule zone) ----------
  _buildScroll() {
    var self = this, w = this.scale.width, viewH = this.listBottom - this.listTop;
    this.listMaskGfx.clear();
    this.listMaskGfx.fillStyle(0xffffff, 1);
    this.listMaskGfx.fillRect(0, this.listTop, w, viewH);

    var dragging = false, startY = 0, startScroll = 0, moved = 0;
    var zone = this.add.zone(0, this.listTop, w, viewH).setOrigin(0).setInteractive().setDepth(41);
    zone.on('pointerdown', function (p) { if (self._modal) return; dragging = true; startY = p.y; startScroll = self.scrollY || 0; moved = 0; });
    this.input.on('pointermove', function (p) {
      if (!dragging || self._modal) return;
      var dy = p.y - startY;
      moved = Math.max(moved, Math.abs(dy));
      self.scrollY = Phaser.Math.Clamp(startScroll - dy, 0, self.maxScroll || 0);
      self.listContainer.y = self.listTop - self.scrollY;
    });
    zone.on('pointerup', function (p) {
      var wasTap = dragging && moved <= 14;
      dragging = false;
      if (wasTap && !self._modal) self._onListTap(p.x, p.y);
    });
    this.input.on('pointerup', function () { dragging = false; });
    this.input.on('pointerupoutside', function () { dragging = false; });
    // Molette (PC)
    this.input.on('wheel', function (p, objs, dx, dy) {
      if (self._modal) return;
      self.scrollY = Phaser.Math.Clamp((self.scrollY || 0) + (dy || 0), 0, self.maxScroll || 0);
      self.listContainer.y = self.listTop - self.scrollY;
    });
  }

  _onListTap(px, py) {
    var lx = px, ly = py - this.listContainer.y;
    var cards = this._cards || [];
    for (var i = 0; i < cards.length; i++) {
      var c = cards[i], hits = c._hits || [];
      for (var j = 0; j < hits.length; j++) {
        var h = hits[j];
        if (lx >= 12 + h.x && lx <= 12 + h.x + h.w && ly >= c.y + h.y && ly <= c.y + h.y + h.h) {
          if (h.btn) this.tweens.add({ targets: h.btn, scale: 0.94, duration: 70, yoyo: true, ease: 'Sine.easeOut' });
          h.fn();
          return true;
        }
      }
    }
    return false;
  }

  // ---------- Rendu du contenu par onglet ----------
  _render(animate) {
    this._refreshTabs();
    this._stopFx();
    this._cardSeq = 0;
    this._animate = animate !== false;
    this.listContainer.removeAll(true);
    var w = this.scale.width;
    var cards, footer = null;
    if (this.tab === 'daily') { var r = this._renderDaily(w); cards = r.cards; footer = r.footer; }
    else if (this.tab === 'heroes') cards = this._renderHeroes(w);
    else if (this.tab === 'equipment') cards = this._renderEquipment(w);
    else if (this.tab === 'troops') cards = this._renderTroops(w);
    else if (this.tab === 'skins') cards = this._renderSkins(w);
    else if (this.tab === 'event') cards = this._renderEvent(w);
    else cards = this._renderCards(w);

    var y = 4;
    cards.forEach(function (c) { c.y = y; y += c._cardH + 16; });
    this._cards = cards;
    this.listContainer.add(cards);
    if (footer) { footer.y = y + 4; this.listContainer.add(footer); y += 48; }

    var viewH = this.listBottom - this.listTop;
    this.maxScroll = Math.max(0, y - viewH + 8);
    this.scrollY = Math.min(this.scrollY || 0, this.maxScroll);
    this.listContainer.y = this.listTop - this.scrollY;
  }

  // ---------- Bouton dessiné (non interactif : le tap est géré par _hits) ----------
  _drawButton(parent, cx, cy, bw, bh, label, accent, disabled, size) {
    var b = this.add.container(cx, cy);
    var g = this.add.graphics();
    g.fillGradientStyle(disabled ? 0x1a2233 : 0x1f2c52, disabled ? 0x1a2233 : 0x1f2c52, disabled ? 0x11172a : 0x0b1224, disabled ? 0x11172a : 0x0b1224, 1);
    g.fillRoundedRect(-bw / 2, -bh / 2, bw, bh, bh * 0.3);
    g.lineStyle(2.5, accent, disabled ? 0.5 : 0.95);
    g.strokeRoundedRect(-bw / 2, -bh / 2, bw, bh, bh * 0.3);
    b.add(g);
    var t = this._txt(0, 0, label, size || 22, disabled ? (accent === 0x5fd97a ? '#8fdca0' : '#5c6b8a') : '#eaf2ff', { fontStyle: 'bold' }).setOrigin(0.5);
    this._fitWidth(t, bw - 16);
    b.add(t);
    parent.add(b);
    return b;
  }

  // ---------- Emblème (vignette de l'objet) ----------
  _emblem(em, spec, acc) {
    var K = NEBUSTION.Shop, E = NEBUSTION.Economy;
    spec = spec || {};
    if (spec.type === 'icon' || spec.type === 'hero' || spec.type === 'card') {
      var im = this._image(0, 0, spec.key);
      if (im) {
        var s = spec.type === 'hero' ? 88 : (spec.type === 'card' ? 86 : 62);
        im.setDisplaySize(s, s);
        em.add(im);
        return;
      }
    }
    if (spec.type === 'emoji') {
      em.add(this.add.text(0, 0, spec.icon, { fontSize: '54px' }).setOrigin(0.5));
      return;
    }
    if (spec.type === 'pack') {
      var ids = spec.ids || ['dust', 'crystal', 'energy'], pos = [[-15, 14], [15, 14], [0, -14]];
      for (var i = 0; i < Math.min(3, ids.length); i++) {
        var pi = this._image(pos[i][0], pos[i][1], 'tex_icon_' + ids[i]);
        if (pi) { pi.setDisplaySize(40, 40); em.add(pi); }
      }
      return;
    }
    var g = this.add.graphics();
    if (spec.type === 'slot' && NEBUSTION.EquipmentScene && NEBUSTION.EquipmentScene.prototype._drawSlotIcon) {
      NEBUSTION.EquipmentScene.prototype._drawSlotIcon.call(null, g, spec.slot, 0, 0, acc);
      g.setScale(1.9);
    } else if (spec.type === 'star') {
      g.fillStyle(acc, 0.35); g.lineStyle(3, acc, 0.95);
      g.fillTriangle(-6, 0, 6, 0, 0, -34); g.fillTriangle(-6, 0, 6, 0, 0, 34);
      g.fillTriangle(0, -6, 0, 6, -34, 0); g.fillTriangle(0, -6, 0, 6, 34, 0);
      g.strokeTriangle(-8, 0, 8, 0, 0, -34); g.strokeTriangle(-8, 0, 8, 0, 0, 34);
      g.strokeTriangle(0, -8, 0, 8, -34, 0); g.strokeTriangle(0, -8, 0, 8, 34, 0);
      g.fillStyle(0xffffff, 0.9); g.fillCircle(0, 0, 5);
    } else {
      this._drawGem(g, 0, 0, 30, K.GEM.color);
    }
    em.add(g);
  }

  // ---------- Carte générique premium (cadre lueur de rareté, emblème animé, étincelles) ----------
  _buildCard(w, o) {
    var self = this, cw = w - 24, ch = o.h || 164, acc = o.accent, owned = !!o.owned;
    var fxl = owned ? 0 : (o.fx || 0);
    var c = this.add.container(12, 0);
    c._cardH = ch; c._hits = [];

    // Lueur additive derrière la carte (pulsation pour les raretés élevées).
    var glow = this._image(cw / 2, ch / 2, 'tex_glow_white');
    if (glow) {
      glow.setDisplaySize(cw + 90, ch + 90).setTint(acc).setBlendMode(Phaser.BlendModes.ADD).setAlpha(owned ? 0.05 : 0.13);
      c.add(glow);
      if (fxl >= 1) this._loop({ targets: glow, alpha: fxl >= 3 ? 0.36 : 0.24, duration: fxl >= 3 ? 900 : 1500, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    }

    var bg = this.add.graphics();
    bg.fillGradientStyle(0x18223d, 0x18223d, 0x0a1122, 0x0a1122, 0.97);
    bg.fillRoundedRect(0, 0, cw, ch, 20);
    bg.lineStyle(3, acc, owned ? 0.3 : 0.9);
    bg.strokeRoundedRect(0, 0, cw, ch, 20);
    // Liseré de rareté sur le bord haut.
    bg.fillStyle(acc, owned ? 0.25 : 0.85);
    bg.fillRoundedRect(28, 0, cw - 56, 4, 2);
    c.add(bg);

    // Emblème.
    var tx = 20;
    if (!o.noEmblem) {
      var ex = 16, ey = 16, es = 96;
      var eg = this.add.graphics();
      eg.fillStyle(0x070c18, 0.95); eg.fillRoundedRect(ex, ey, es, es, 20);
      eg.fillStyle(acc, owned ? 0.05 : 0.16); eg.fillRoundedRect(ex + 4, ey + 4, es - 8, es - 8, 17);
      eg.lineStyle(2.5, acc, owned ? 0.3 : 0.9); eg.strokeRoundedRect(ex, ey, es, es, 20);
      c.add(eg);
      var em = this.add.container(ex + es / 2, ey + es / 2);
      this._emblem(em, o.emblem, acc);
      em.setAlpha(owned ? 0.45 : 1);
      c.add(em);
      if (!owned) this._loop({ targets: em, y: em.y - 4, duration: 1300 + (this._cardSeq || 0) * 90, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
      tx = 130;
    }

    // Badge (coin haut droit).
    var bwid = 0;
    if (o.badge) {
      bwid = 26 + o.badge.length * 10;
      var bb = this.add.graphics();
      bb.fillStyle(acc, owned ? 0.5 : 0.95);
      bb.fillRoundedRect(cw - bwid - 16, 14, bwid, 30, 15);
      c.add(bb);
      c.add(this._txt(cw - bwid / 2 - 16, 29, o.badge, 14, '#05070f', { fontStyle: 'bold' }).setOrigin(0.5));
    }
    var maxTitleW = cw - tx - (bwid ? bwid + 32 : 20);

    if (o.rarityLabel) {
      c.add(this._txt(tx, 16, o.rarityLabel.toUpperCase(), 15, '#' + ('000000' + acc.toString(16)).slice(-6), { fontStyle: 'bold' }));
    }
    var title = this._txt(tx, o.rarityLabel ? 38 : 24, o.title, 26, '#eaf2ff', { fontStyle: 'bold' });
    this._fitWidth(title, maxTitleW);
    c.add(title);

    var textY = o.subY || 76;
    if (o.sub) {
      var sub = this._txt(tx, textY, o.sub, 19, '#a9b8dc');
      this._fitWidth(sub, cw - tx - 20);
      c.add(sub);
    }
    if (o.desc) {
      c.add(this._txt(tx, textY, o.desc, 17, '#8e9cc0', { wordWrap: { width: cw - tx - 210 } }));
    }
    if (o.note) c.add(this._txt(tx, ch - 44, o.note, 17, '#8e9cc0'));
    if (o.extra) o.extra(c, cw, ch);

    // Rangée du bas : prix à gauche, bouton à droite.
    var rowY = ch - 32;
    if (o.cost && !owned) {
      var price = this._priceNode(o.cost, 22);
      price.setPosition(22, rowY);
      c.add(price);
    }
    var actLabel = owned ? (o.ownedLabel || 'Possédé') : (o.buyLabel || 'Acheter');
    var btn = this._drawButton(c, cw - 20 - 92, rowY, 184, 58, actLabel, owned ? 0x5fd97a : acc, owned, 22);
    if (!owned && o.onBuy) c._hits.push({ x: cw - 20 - 184, y: rowY - 29, w: 184, h: 58, fn: o.onBuy, btn: btn });

    // Étincelles pour les raretés élevées (animation de scintillement).
    if (fxl >= 2) {
      var n = fxl >= 3 ? 5 : 3;
      for (var i = 0; i < n; i++) {
        var sp = this._image(30 + ((i * 137 + (this._cardSeq || 0) * 53) % (cw - 60)), 12 + ((i * 61) % (ch - 40)), 'tex_glow_white');
        if (!sp) continue;
        sp.setDisplaySize(16 + (i % 3) * 6, 16 + (i % 3) * 6).setTint(i % 2 ? 0xffffff : acc).setBlendMode(Phaser.BlendModes.ADD).setAlpha(0);
        c.add(sp);
        this._loop({ targets: sp, alpha: 0.9, duration: 500 + i * 130, delay: i * 350 + ((this._cardSeq || 0) * 120) % 700, yoyo: true, repeat: -1, repeatDelay: 900 + i * 200, ease: 'Sine.easeInOut' });
      }
    }

    // Animation d'entrée (fondu + glissement latéral) : uniquement lors d'un changement d'onglet.
    if (this._animate) {
      var seq = (this._cardSeq = (this._cardSeq || 0) + 1);
      c.setAlpha(0); c.x = 12 + 36;
      this.tweens.add({ targets: c, alpha: 1, x: 12, duration: 280, ease: 'Cubic.easeOut', delay: Math.min(260, seq * 45) });
    } else {
      this._cardSeq = (this._cardSeq || 0) + 1;
    }
    return c;
  }

  // ---------- Ligne de prix (icônes ressources + Prismes), rouge si non finançable ----------
  _priceNode(cost, size) {
    var self = this, K = NEBUSTION.Shop, E = NEBUSTION.Economy, SM = NEBUSTION.ShopManager;
    size = size || 22;
    var c = this.add.container(0, 0);
    var x = 0, ic = size + 8;
    Object.keys(cost).forEach(function (id) {
      var one = {}; one[id] = cost[id];
      var col = SM.canAfford(one) ? (id === 'gem' ? K.GEM.hex : (id === 'xon' ? K.XON.hex : '#dbe5ff')) : '#ff7b7b';
      if (id === 'gem') {
        var g = self.add.graphics();
        self._drawGem(g, x + ic / 2, 0, ic / 2 - 1, K.GEM.color);
        c.add(g);
      } else if (id === 'xon') {
        var xg = self.add.graphics(); self._drawXon(xg, x + ic / 2, 0, ic / 2 - 1, K.XON.color); c.add(xg);
      } else {
        var icon = self._image(x + ic / 2, 0, 'tex_icon_' + id);
        if (icon) { icon.setDisplaySize(ic, ic); c.add(icon); }
      }
      var t = self._txt(x + ic + 6, 0, E.fmt(cost[id]), size, col, { fontStyle: 'bold' }).setOrigin(0, 0.5);
      c.add(t);
      x += ic + 6 + (t.width || 40) + 18;
    });
    c._w = x - 18;
    return c;
  }

  // ---------- Onglet Quotidien ----------
  _dailyAccent(o) {
    var E = NEBUSTION.Economy;
    if (o.kind === 'gems') return 0xffd166;
    if (o.kind === 'bundle') return 0xb47bff;
    if (o.kind === 'equipment') return (NEBUSTION.Equipment.RARITIES[o.rarity] || {}).color || 0x00e5ff;
    var first = Object.keys(o.res || {})[0];
    return (E.RES[first] || {}).color || 0x4fd1ff;
  }

  _dailyEmblem(o) {
    if (o.kind === 'gems') return { type: 'gem' };
    if (o.kind === 'equipment') return { type: 'slot', slot: o.slot };
    if (o.kind === 'bundle') return { type: 'pack', ids: Object.keys(o.res) };
    return { type: 'icon', key: 'tex_icon_' + Object.keys(o.res)[0] };
  }

  _renderDaily(w) {
    var self = this, SM = NEBUSTION.ShopManager, K = NEBUSTION.Shop;
    var cards = SM.dailyOffers().map(function (o) {
      var owned = SM.isPurchasedToday(o.id);
      var accent = self._dailyAccent(o), sub = self._offerSub(o);
      var fx = o.kind === 'bundle' || o.kind === 'gems' ? 2 : (o.kind === 'equipment' && o.rarity === 'rare' ? 1 : 0);
      return self._buildCard(w, {
        accent: accent, title: o.label, sub: sub, cost: o.cost, owned: owned, ownedLabel: 'Acheté', badge: 'QUOTIDIEN',
        emblem: self._dailyEmblem(o), fx: fx,
        onBuy: function () { self._confirmBuy(o.label, sub, o.cost, function () { return SM.buyDaily(o.id); }); }
      });
    });

    var giftOk = SM.giftAvailable();
    var giftCard = this._buildCard(w, {
      h: 150, accent: 0x5fd97a, title: 'Cadeau quotidien', sub: '+' + K.DAILY_GIFT_GEMS + ' Prismes offerts',
      note: 'Se renouvelle chaque jour', owned: !giftOk, ownedLabel: 'Réclamé', buyLabel: 'Réclamer', badge: 'GRATUIT',
      emblem: { type: 'gem' }, fx: 2,
      onBuy: function () {
        var res = SM.claimDailyGift();
        if (res.ok) {
          self._buildGemsBadge(); self._buildXonBadge();
          self.fx.toast('Cadeau réclamé', '+' + res.amount + ' Prismes', null);
          self.fx.ring(self.scale.width / 2, self.listTop + 80, 0xe6c6ff, 1.6);
          self._render(false);
        }
      }
    });
    cards.unshift(giftCard);

    var footer = this._txt(w / 2, 0, 'Nouvelles offres dans ' + this._fmtMs(SM.msUntilRefresh()), 20, '#8e9cc0').setOrigin(0.5, 0);
    return { cards: cards, footer: footer };
  }

  _offerSub(o) {
    var E = NEBUSTION.Economy;
    if (o.kind === 'resource' || o.kind === 'bundle') {
      return Object.keys(o.res).map(function (id) { return '+' + E.fmt(o.res[id]) + ' ' + E.RES[id].short; }).join('  ·  ');
    }
    if (o.kind === 'gems') return '+' + o.amount + ' Prismes';
    if (o.kind === 'equipment') {
      var Q = NEBUSTION.Equipment;
      return Q.RARITIES[o.rarity].name + ' · ' + Q.SLOTS[o.slot].name;
    }
    return '';
  }

  _fmtMs(ms) {
    var totalMin = Math.max(0, Math.ceil(ms / 60000));
    var hh = Math.floor(totalMin / 60), mm = totalMin % 60;
    return hh + ' h ' + (mm < 10 ? '0' : '') + mm + ' min';
  }

  // Cartes personnalisées : elles appartiennent directement à l'onglet Héros.
  _appendCustomCards(cards, w) {
    var custom = this._renderCards(w);
    return cards.concat(custom || []);
  }

  // ---------- Onglet Héros (paquets de fragments) ----------
  _renderHeroes(w) {
    var self = this, H = NEBUSTION.Heroes, SM = NEBUSTION.ShopManager, C = NEBUSTION.Combat;
    var heroes = H.all();
    if (this.heroIndex >= heroes.length) this.heroIndex = 0;
    var hero = heroes[this.heroIndex];

    var cw = w - 24, ph = 116;
    var picker = this.add.container(12, 0);
    picker._cardH = ph; picker._hits = [];
    var bg = this.add.graphics();
    bg.fillGradientStyle(0x1a2140, 0x1a2140, 0x0d1226, 0x0d1226, 0.97);
    bg.fillRoundedRect(0, 0, cw, ph, 20);
    bg.lineStyle(3, 0xb47bff, 0.85); bg.strokeRoundedRect(0, 0, cw, ph, 20);
    picker.add(bg);
    var img = this._image(cw / 2 - 150, ph / 2, H.portraitKey(hero.id));
    if (img) { img.setDisplaySize(84, 84); picker.add(img); }
    picker.add(this._txt(cw / 2 - 94, 26, hero.name, 30, '#eaf2ff', { fontStyle: 'bold' }));
    var locked = !C.isUnlocked(hero.id);
    // Un Dieu obtenu par fragments (shop.fragmentsToUnlock, ex. Aetherion) affiche sa progression
    // plutôt que « À recruter », puisqu'il n'y a rien à acheter directement pour le débloquer.
    var fragGated = !!(hero.shop && hero.shop.fragmentsToUnlock);
    var frags = fragGated ? (NEBUSTION.Resources.state.combat.fragments[hero.id] || 0) : 0;
    var lockedLabel = fragGated ? ('Fragments ' + Math.min(frags, hero.shop.fragmentsToUnlock) + ' / ' + hero.shop.fragmentsToUnlock) : 'À recruter';
    picker.add(this._txt(cw / 2 - 94, 66, (locked ? lockedLabel : 'Niveau ' + C.heroLevel(hero.id)) + '  ·  ' + (this.heroIndex + 1) + '/' + heroes.length, 20, locked ? '#ffd166' : '#a9b8dc', locked ? { fontStyle: 'bold' } : undefined));
    [[-1, 46, '‹'], [1, cw - 46, '›']].forEach(function (a) {
      picker.add(self._txt(a[1], ph / 2 - 2, a[2], 64, '#00e5ff', { fontStyle: 'bold' }).setOrigin(0.5));
      picker._hits.push({ x: a[1] - 46, y: 0, w: 92, h: ph, fn: function () { self.heroIndex = (self.heroIndex + a[0] + heroes.length) % heroes.length; self._render(false); } });
    });
    if (this._animate) { picker.setAlpha(0); this.tweens.add({ targets: picker, alpha: 1, duration: 250 }); }

    var cards = [picker];
    if (locked && !fragGated) {   // héros exclusif de la Boutique : recrutement (les fragments ne s'achètent qu'après)
      var rar = H.RARITIES[hero.rarity], role = H.ROLES[hero.role], hcost = hero.shop.cost, rarityLabel = hero.rarityLabel || rar.name;
      cards.push(self._buildCard(w, {
        accent: rar.color, rarityLabel: rarityLabel + ' · ' + role.name, title: 'Recruter ' + hero.name,
        desc: '« ' + hero.title + ' » Rejoint votre collection et devient utilisable en combat.',
        cost: hcost, badge: 'NOUVEAU HÉROS', emblem: { type: 'hero', key: H.portraitKey(hero.id) }, fx: (hero.rarity === 'epique') ? 2 : 3,
        onBuy: function () {
          self._confirmBuy('Recruter ' + hero.name, hero.name + ' rejoint immédiatement votre collection (niveau 1). Vous pourrez ensuite acheter ses fragments.', hcost, function () { return SM.buyHero(hero.id); });
        }
      }));
      return self._appendCustomCards(cards, w);
    }
    if (fragGated) {   // Dieu obtenu uniquement par fragments : pas de recrutement direct, juste une progression
      var gRar = H.RARITIES[hero.rarity], gRole = H.ROLES[hero.role], gRarityLabel = hero.rarityLabel || gRar.name;
      cards.push(self._buildCard(w, {
        accent: gRar.color, rarityLabel: gRarityLabel + ' · ' + gRole.name,
        title: locked ? ('Invoquer ' + hero.name) : hero.name + ', invoqué',
        desc: '« ' + hero.title + ' » Ce Dieu Supérieur ne se recrute pas contre des Prismes : rassemblez ' +
          hero.shop.fragmentsToUnlock + ' fragments pour l\'invoquer. Progression : ' +
          Math.min(frags, hero.shop.fragmentsToUnlock) + ' / ' + hero.shop.fragmentsToUnlock + '.',
        owned: !locked, ownedLabel: 'Invoqué', badge: locked ? 'DIEU CÉLESTE' : 'INVOQUÉ',
        emblem: { type: 'hero', key: H.portraitKey(hero.id) }, fx: 3
      }));
    }
    NEBUSTION.Shop.HERO_PACKS.forEach(function (p, i) {
      var accent = [0x4fd1ff, 0xb47bff, 0xffd166][i] || 0x4fd1ff;
      cards.push(self._buildCard(w, {
        accent: accent, rarityLabel: ['Petit paquet', 'Paquet moyen', 'Grand paquet'][i] || 'Paquet',
        title: '+' + p.amount + ' fragments', sub: 'Pour ' + hero.name + ' — monte son niveau', cost: p.cost, badge: 'HÉROS',
        emblem: { type: 'hero', key: H.portraitKey(hero.id) }, fx: i + 1,
        onBuy: function () {
          self._confirmBuy('+' + p.amount + ' fragments — ' + hero.name, 'Les fragments sont appliqués immédiatement à ' + hero.name + '.', p.cost, function () { return SM.buyHeroPack(p.id, hero.id); });
        }
      }));
    });
    return self._appendCustomCards(cards, w);
  }

  // ---------- Onglet Équipement ----------
  _renderEquipment(w) {
    var self = this, Q = NEBUSTION.Equipment, K = NEBUSTION.Shop, SM = NEBUSTION.ShopManager;
    var cw = w - 24, chH = 60;
    var chips = this.add.container(12, 0);
    chips._cardH = chH; chips._hits = [];
    var gap = 10, bw = (cw - gap * 2) / 3;
    K.EQUIPMENT_RARITIES.forEach(function (rid, i) {
      var active = self.equipRarity === rid, rar = Q.RARITIES[rid], x = i * (bw + gap);
      var g = self.add.graphics();
      g.fillGradientStyle(active ? 0x24386e : 0x101a33, active ? 0x24386e : 0x101a33, active ? 0x132048 : 0x0a1122, active ? 0x132048 : 0x0a1122, 0.97);
      g.fillRoundedRect(x, 0, bw, chH, 16);
      g.lineStyle(active ? 3 : 1.5, rar.color, active ? 0.95 : 0.55);
      g.strokeRoundedRect(x, 0, bw, chH, 16);
      chips.add(g);
      chips.add(self._txt(x + bw / 2, chH / 2, rar.name, 24, active ? rar.hex : '#8e9cc0', { fontStyle: 'bold' }).setOrigin(0.5));
      chips._hits.push({ x: x, y: 0, w: bw, h: chH, fn: function () { if (self.equipRarity !== rid) { self.equipRarity = rid; self._render(false); } } });
    });

    var rid = this.equipRarity, rar = Q.RARITIES[rid], cost = K.EQUIPMENT_PRICE[rid];
    var fx = rid === 'legendaire' ? 3 : (rid === 'epique' ? 2 : 1);
    var cards = [chips];
    Q.SLOT_ORDER.forEach(function (slot) {
      cards.push(self._buildCard(w, {
        accent: rar.color, rarityLabel: rar.name, title: Q.SLOTS[slot].name,
        desc: 'Objet neuf, niveau 1, prêt à équiper ou à fusionner.',
        cost: cost, badge: 'ÉQUIPEMENT', emblem: { type: 'slot', slot: slot }, fx: fx,
        onBuy: function () {
          self._confirmBuy(rar.name + ' — ' + Q.SLOTS[slot].name, 'Un nouvel objet niveau 1 rejoindra votre inventaire.', cost, function () { return SM.buyEquipment(slot, rid); });
        }
      }));
    });
    return cards;
  }

  // ---------- Onglet Troupes (module 18) : soldats, barbares, vaisseaux… déployés en mode combat ----------
  _renderTroops(w) {
    var self = this, T = NEBUSTION.Troops, TM = NEBUSTION.TroopManager, SM = NEBUSTION.ShopManager, E = NEBUSTION.Economy;
    var cw = w - 24, chH = 60;
    if (!this.troopQty) this.troopQty = 1;
    var chips = this.add.container(12, 0);
    chips._cardH = chH; chips._hits = [];
    var gap = 10, qs = [1, 5, 10], bw = (cw - gap * 2) / 3;
    qs.forEach(function (q, i) {
      var active = self.troopQty === q, x = i * (bw + gap);
      var g = self.add.graphics();
      g.fillGradientStyle(active ? 0x24386e : 0x101a33, active ? 0x24386e : 0x101a33, active ? 0x132048 : 0x0a1122, active ? 0x132048 : 0x0a1122, 0.97);
      g.fillRoundedRect(x, 0, bw, chH, 16);
      g.lineStyle(active ? 3 : 1.5, 0xffd166, active ? 0.95 : 0.45);
      g.strokeRoundedRect(x, 0, bw, chH, 16);
      chips.add(g);
      chips.add(self._txt(x + bw / 2, chH / 2, '×' + q, 26, active ? '#ffd166' : '#8e9cc0', { fontStyle: 'bold' }).setOrigin(0.5));
      chips._hits.push({ x: x, y: 0, w: bw, h: chH, fn: function () { if (self.troopQty !== q) { self.troopQty = q; self._render(false); } } });
    });

    var q = this.troopQty, cards = [chips];
    var info = this._txt(w / 2, 20, 'Armée : ' + TM.used() + ' / ' + TM.capacity() + ' places' + (TM.discount() > 0 ? '  ·  Remise −' + Math.round(TM.discount() * 100) + ' %' : ''), 20, TM.free() > 0 ? '#ffd166' : '#ff8fa3', { fontStyle: 'bold' }).setOrigin(0.5, 0);
    var infoBox = this.add.container(0, 0, [info]);
    infoBox._cardH = 44; infoBox._hits = [];
    cards.push(infoBox);

    T.ORDER.forEach(function (tid) {
      var def = T.get(tid), cost = TM.cost(tid, q), st = TM.stats(tid);
      var stats = 'Niv. ' + TM.level(tid) + ' · PV ' + st.hp + ' · ' + (def.blast ? 'Explosif ' + st.blast : 'DPS ' + st.dps) + ' · ' + def.space + ' pl.' + (def.fly ? ' · vole' : '');
      var fx = def.space >= 8 ? 3 : (def.space >= 4 ? 2 : (def.space >= 2 ? 1 : 0));
      cards.push(self._buildCard(w, {
        h: 176, accent: def.color, title: def.name + (q > 1 ? ' ×' + q : ''), sub: stats, subY: 70,
        note: def.desc.length > 44 ? def.desc.slice(0, 43) + '…' : def.desc, badge: 'EN STOCK ' + TM.count(tid),
        cost: cost, emblem: { type: 'emoji', icon: def.icon }, fx: fx,
        onBuy: function () {
          if (def.space * q > TM.free()) { self.fx.toast('Armée pleine', 'Améliore le Hangar pour gagner des places.'); return; }
          self._confirmBuy(def.name + ' ×' + q, def.desc, cost, function () { return SM.buyTroop(tid, q); });
        }
      }));
    });
    return cards;
  }

  // ---------- Onglet Skins ----------
  _renderSkins(w) {
    var self = this, K = NEBUSTION.Skins, SM = NEBUSTION.SkinManager;
    var unowned = K.SKINS.filter(function (s) { return !SM.isOwned(s.id); });
    if (!unowned.length) {
      var msg = this._txt(w / 2, 40, 'Toute la collection de skins est déjà possédée !\nBravo, collectionneur.', 24, '#a9b8dc', { align: 'center', wordWrap: { width: w - 60 } }).setOrigin(0.5, 0);
      var holder = this.add.container(0, 0, [msg]);
      holder._cardH = 140; holder._hits = [];
      return [holder];
    }
    return unowned.map(function (s) {
      var rar = K.RARITIES[s.rarity], cost = K.cost(s.rarity);
      var fx = rar.order >= 4 ? 3 : (rar.order >= 3 ? 2 : (rar.order >= 2 ? 1 : 0));
      return self._buildCard(w, {
        h: 176, accent: rar.color, rarityLabel: rar.name + ' · ' + K.TARGET_NAMES[s.target],
        title: s.name, desc: s.desc, cost: cost, badge: 'SKIN', emblem: { type: 'star' }, fx: fx,
        onBuy: function () { self._confirmBuy(s.name, s.desc, cost, function () { return SM.buy(s.id); }); }
      });
    });
  }

  // ---------- Cartes personnalisées affichées dans Héros ----------
  _cardAccent(card) {
    var r = String(card.rarity || '').toLowerCase();
    if (r === 'mythique') return 0xff5ce1;
    if (r === 'legendaire' || r === 'légendaire') return 0xffb84d;
    if (r === 'epique' || r === 'épique') return 0xb47bff;
    if (r === 'rare') return 0x4fd1ff;
    return 0x8e9cc0;
  }

  _renderCards(w) {
    var self = this, SM = NEBUSTION.ShopManager;
    var list = SM.customCards ? SM.customCards() : [];
    if (!list.length) {
      var msg = this._txt(w / 2, 60, 'Aucune carte personnalisée dans la Boutique.', 24, '#a9b8dc', {
        align: 'center', wordWrap: { width: w - 60 }
      }).setOrigin(0.5, 0);
      var holder = this.add.container(0, 0, [msg]);
      holder._cardH = 150; holder._hits = [];
      return [holder];
    }

    return list.map(function (card) {
      var owned = SM.isCustomCardOwned(card.id);
      var acc = self._cardAccent(card);
      var st = card.stats && card.stats.level1 ? card.stats.level1 : {};
      var growth = card.stats && card.stats.growthPerLevel ? card.stats.growthPerLevel : {};
      var h = 330;
      var statsLine = 'PV ' + (st.hp || 0) + ' · ATQ ' + (st.attack || 0) +
        ' · DEF ' + (st.defense || 0) + ' · VIT ' + (st.speed || 0);
      var growthLine = 'Évolution / niveau : +' + (growth.hp || 0) + ' PV · +' +
        (growth.attack || 0) + ' ATQ · +' + (growth.defense || 0) + ' DEF · +' + (growth.speed || 0) + ' VIT';
      return self._buildCard(w, {
        h: h, accent: acc,
        rarityLabel: String(card.rarity || 'Commun') + ' · Niv. ' + (card.level ? card.level.start : 1) + ' → ' + (card.level ? card.level.max : 1),
        title: card.name,
        desc: card.description,
        badge: 'CARTE',
        owned: owned, ownedLabel: 'Obtenue',
        buyLabel: Object.keys(card.cost || {}).length ? 'Acheter' : 'Obtenir',
        cost: card.cost || {},
        emblem: { type: 'card', key: card.imageKey || '' },
        fx: String(card.rarity || '').toLowerCase() === 'mythique' ? 3 : 2,
        extra: function (c, cw) {
          c.add(self._txt(130, 132, statsLine, 17, '#dbe5ff', { wordWrap: { width: cw - 150 } }));
          c.add(self._txt(130, 162, growthLine, 15, '#8e9cc0', { wordWrap: { width: cw - 150 } }));
          if (card.ability) c.add(self._txt(20, 210, 'CAPACITÉ — ' + card.ability, 17, '#ffe9a3', {
            wordWrap: { width: cw - 40 }
          }));
          if (card.level && card.level.max) {
            c.add(self._txt(20, 274, 'Niveau maximum : ' + card.level.max, 16, '#8e9cc0'));
          }
        },
        onBuy: function () {
          var cost = card.cost || {};
          var desc = card.description || '';
          self._confirmBuy(card.name, desc, cost, function () {
            return SM.buyCustomCard(card.id);
          });
        }
      });
    });
  }

  // ---------- Onglet Événement ----------
  _renderEvent(w) {
    var self = this, SM = NEBUSTION.ShopManager, offer = SM.eventOffer(), E = NEBUSTION.Economy;
    var bought = SM.isEventBought();
    var ids = Object.keys(offer.contents);
    var rows = ids.length, ch = 176 + rows * 44 + 84;
    var card = this._buildCard(w, {
      h: ch, accent: 0xffd166, rarityLabel: 'Offre limitée', title: offer.name,
      cost: offer.cost, owned: bought, ownedLabel: 'Obtenue', badge: 'ÉVÉNEMENT', noEmblem: true, fx: 3,
      extra: function (c, cw) {
        c.add(self._txt(20, 76, offer.desc, 19, '#a9b8dc', { wordWrap: { width: cw - 40 } }));
        c.add(self._txt(20, 140, 'CONTENU DE L\'OFFRE', 15, '#ffd166', { fontStyle: 'bold' }));
        ids.forEach(function (id, i) {
          var y = 176 + i * 44 + 16;
          if (id === 'gem') {
            var g = self.add.graphics(); self._drawGem(g, 36, y, 15, NEBUSTION.Shop.GEM.color); c.add(g);
          } else if (id === 'xon') {
            var xg = self.add.graphics(); self._drawXon(xg, 36, y, 15, NEBUSTION.Shop.XON.color); c.add(xg);
          } else {
            var ic = self._image(36, y, 'tex_icon_' + id);
            if (ic) { ic.setDisplaySize(34, 34); c.add(ic); }
          }
          var label = id === 'gem' ? 'Prismes' : (id === 'xon' ? 'Jetons Xon' : E.RES[id].name);
          c.add(self._txt(66, y, '+' + E.fmt(offer.contents[id]) + '  ' + label, 24, '#ffe9a3', { fontStyle: 'bold' }).setOrigin(0, 0.5));
        });
      },
      onBuy: function () {
        self._confirmBuy(offer.name, offer.desc, offer.cost, function () { return SM.buyEvent(); });
      }
    });
    return [card];
  }

  // ---------- Confirmation d'achat (obligatoire avant chaque achat) ----------
  _confirmBuy(title, desc, cost, doBuy) {
    if (this._modal) return;
    var self = this, w = this.scale.width, h = this.scale.height, SM = NEBUSTION.ShopManager;
    var pw = w - 56, ph = 410, cx = w / 2, cy = h / 2 - 30;
    var can = SM.canAfford(cost);

    var overlay = this.add.container(0, 0).setDepth(1100);
    var dim = this.add.rectangle(0, 0, w, h, 0x000000, 0.7).setOrigin(0).setInteractive();
    overlay.add(dim);

    var panel = this.add.container(cx, cy).setScale(0.9).setAlpha(0);
    overlay.add(panel);
    var bg = this.add.graphics();
    bg.fillGradientStyle(0x1a2247, 0x1a2247, 0x0b1224, 0x0b1224, 0.99);
    bg.fillRoundedRect(-pw / 2, -ph / 2, pw, ph, 26);
    bg.lineStyle(3, 0x00e5ff, 0.9);
    bg.strokeRoundedRect(-pw / 2, -ph / 2, pw, ph, 26);
    panel.add(bg);

    panel.add(this._txt(0, -ph / 2 + 34, 'CONFIRMER L\'ACHAT', 18, '#8e9cc0', { fontStyle: 'bold' }).setOrigin(0.5));
    var t = this._txt(0, -ph / 2 + 68, title, 28, '#eaf2ff', { fontStyle: 'bold', align: 'center', wordWrap: { width: pw - 60 } }).setOrigin(0.5, 0);
    panel.add(t);
    if (desc) {
      panel.add(this._txt(0, -ph / 2 + 68 + (t.height || 34) + 12, desc, 19, '#a9b8dc', { align: 'center', wordWrap: { width: pw - 70 } }).setOrigin(0.5, 0));
    }
    var price = this._priceNode(cost, 26);
    price.setPosition(-price._w / 2, 44);
    panel.add(price);
    if (!can) {
      panel.add(this._txt(0, 88, 'Ressources insuffisantes', 20, '#ff7b7b', { fontStyle: 'bold' }).setOrigin(0.5));
    }

    var by = ph / 2 - 56;
    var cancelBtn = this._drawButton(panel, -pw / 4 - 4, by, 250, 68, 'Annuler', 0x394869, false, 26);
    var confirmBtn = this._drawButton(panel, pw / 4 + 4, by, 250, 68, 'Confirmer', can ? 0x00e5ff : 0x394869, !can, 26);

    // Zones de tap (coordonnées écran).
    var hits = [
      { x: cx - pw / 4 - 4 - 125, y: cy + by - 34, w: 250, h: 68, fn: function () { self._closeConfirm(); } },
      { x: cx + pw / 4 + 4 - 125, y: cy + by - 34, w: 250, h: 68, fn: function () {
          if (!can || self._modal.busy) return;
          self._modal.busy = true;
          var res = doBuy();
          self._closeConfirm();
          if (res && res.ok) {
            self._buildGemsBadge(); self._buildXonBadge();
            self.fx.toast('Achat réussi', title, null);
            self.fx.ring(w / 2, self.listTop + 80, 0xffd166, 1.6);
            self._render(false);
          } else {
            var reason = res && res.reason === 'ressources' ? 'Ressources insuffisantes' : (res && res.reason === 'deja' ? 'Déjà obtenu / réclamé' : 'Achat impossible');
            self.fx.toast(reason, null, null);
          }
      } }
    ];
    dim.on('pointerup', function (p) {
      if (!self._modal) return;
      var px = p.x, py = p.y;
      for (var i = 0; i < hits.length; i++) {
        var q = hits[i];
        if (px >= q.x && px <= q.x + q.w && py >= q.y && py <= q.y + q.h) { q.fn(); return; }
      }
      // Tap hors du panneau = annuler.
      if (px < cx - pw / 2 || px > cx + pw / 2 || py < cy - ph / 2 || py > cy + ph / 2) self._closeConfirm();
    });

    this._modal = { overlay: overlay, dim: dim, hits: hits, busy: false };
    this.tweens.add({ targets: panel, scale: 1, alpha: 1, duration: 200, ease: 'Back.easeOut' });
  }

  _closeConfirm() {
    var m = this._modal;
    if (!m) return;
    this._modal = null;
    var overlay = m.overlay;
    try { m.dim.disableInteractive(); } catch (e) { /* ignore */ }
    this.tweens.add({ targets: overlay, alpha: 0, duration: 140, onComplete: function () { overlay.destroy(); } });
  }
};
