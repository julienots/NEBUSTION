/**
 * NEBUSTION - ExpeditionScene (étape 10)
 * Onglet « En cours » : expéditions actives (compte à rebours, réclamation, annulation avec
 * confirmation, Tout réclamer) + petit historique récent.
 * Onglet « Missions » : catalogue filtrable par difficulté, aperçu de récompense, verrous ;
 * toucher une mission débloquée ouvre un écran de préparation (choix des héros, récompense
 * estimée en direct, barre d'action collée en bas, bouton Auto).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.ExpeditionScene = class ExpeditionScene extends NEBUSTION.ProgressScene {
  constructor() { super('ExpeditionScene'); }

  init(data) {
    super.init(data);
    this.prep = null;
    this.missionFilter = 'all';
  }

  _hubKey() { return 'expedition'; }
  _titleText() { return 'EXPÉDITIONS'; }
  _accent() { return 0x4fc3ff; }
  _accentHex() { return '#4fc3ff'; }
  _defaultTab() { return 'active'; }
  _tabDefs() { return [{ id: 'active', label: 'En cours' }, { id: 'missions', label: 'Missions' }]; }

  _badgeContent(c) {
    var XM = NEBUSTION.ExpeditionManager;
    this._badgePill(c, 'frag', XM.usedSlots() + '/' + XM.maxSlots(), this._accent(), this._accentHex());
  }

  // ---------- Rendu ----------
  _renderTab(w) {
    if (this.prep) return this._renderPrep(w);
    return this.tab === 'active' ? this._renderActive(w) : this._renderMissions(w);
  }

  // ================= Onglet « En cours » =================
  _renderActive(w) {
    var self = this, XM = NEBUSTION.ExpeditionManager, now = Date.now();
    var list = XM.listActive(now), cards = [];
    if (!list.length) {
      var empty = this._card(150, 0x394869, {});
      empty.add(this._txt(24, 46, 'Aucune expédition en cours.', 19, '#c7d3f0', { fontStyle: 'bold' }));
      empty.add(this._txt(24, 82, 'Rendez-vous dans l\'onglet Missions pour envoyer vos héros.', 15, '#8e9cc0', { wordWrap: { width: w - 72 } }));
      cards.push(empty);
    } else {
      list.forEach(function (x) { cards.push(self._activeCard(x, w)); });
    }
    // Historique récent (compact)
    var st = NEBUSTION.Resources.state.expeditions;
    var recent = (st && st.history || []).slice(-5).reverse();
    if (recent.length) {
      var h = this._card(40 + recent.length * 34, 0x233657, { dim: true });
      h.add(this._txt(24, 26, 'Historique récent', 15, '#8e9cc0', { fontStyle: 'bold' }));
      recent.forEach(function (r, i) {
        var m = NEBUSTION.Expeditions.mission(r.missionId);
        var label = (m ? (NEBUSTION.Expeditions.TYPES[m.typeId].name + ' · ' + NEBUSTION.Expeditions.DIFFICULTIES[m.difficultyId].name) : 'Mission');
        var d = new Date(r.at);
        var when = d.toLocaleDateString('fr-FR') + ' ' + ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
        h.add(self._txt(24, 50 + i * 34, label + '  ·  ' + when, 14, r.success !== false ? '#a9b8dc' : '#ff9a7b'));
      });
      cards.push(h);
    }
    if (XM.readyCount(now) > 0) {
      var bw = w - 24;
      var claimAllC = this.add.container(12, 0);
      var bg = this.add.graphics();
      bg.fillGradientStyle(0x1f2c52, 0x1f2c52, 0x0b1224, 0x0b1224, 1);
      bg.fillRoundedRect(0, 0, bw, 56, 18);
      bg.lineStyle(2.5, this._accent(), 0.95);
      bg.strokeRoundedRect(0, 0, bw, 56, 18);
      claimAllC.add(bg);
      claimAllC.add(this._txt(bw / 2, 28, 'TOUT RÉCLAMER (' + XM.readyCount(now) + ')', 20, '#eaf2ff', { fontStyle: 'bold' }).setOrigin(0.5));
      claimAllC._cardH = 56; claimAllC._hits = [{ x: 0, y: 0, w: bw, h: 56, fn: function () { self._claimAll(); } }];
      cards.unshift(claimAllC);
    }
    return { cards: cards, footer: null };
  }

  _activeCard(x, w) {
    var self = this, entry = x.entry, m = x.mission, ready = x.ready;
    var t = NEBUSTION.Expeditions.TYPES[m.typeId], d = NEBUSTION.Expeditions.DIFFICULTIES[m.difficultyId];
    var h = 168;
    var card = this._card(h, ready ? 0x5fd97a : d.color, { glow: ready });
    card.add(this._txt(24, 26, m.name, 19, '#eaf2ff', { fontStyle: 'bold' }));
    var sub = t.name + ' · ' + d.name;
    card.add(this._txt(24, 50, sub, 14, this._hex(d.color), { fontStyle: 'bold' }));
    // héros envoyés
    var hx = 24, hs = 44;
    entry.heroIds.forEach(function (hid, i) { self._heroThumb(card, hid, hx + i * (hs + 6), 68, hs, hs, false); });
    // temps restant / prêt
    var rightX = card._cw - 24;
    if (ready) {
      card.add(this._txt(rightX, 68 + 22, 'PRÊTE', 22, '#5fd97a', { fontStyle: '900' }).setOrigin(1, 0.5));
    } else {
      var tt = this._txt(rightX, 68 + 22, this._fmtMs(x.msLeft), 22, '#eaf2ff', { fontStyle: '900' }).setOrigin(1, 0.5);
      card.add(tt);
      this._liveText(tt, function () {
        var left = NEBUSTION.ExpeditionManager.timeLeft(entry);
        if (left <= 0) { self._render(false); }
        return self._fmtMs(left);
      });
    }
    // barre de progression
    var elapsed = Date.now() - entry.startedAt, dur = Math.max(1, entry.endsAt - entry.startedAt);
    this._bar(card, 24, 132, card._cw - 48, 10, elapsed / dur, ready ? 0x5fd97a : d.color);
    // boutons
    if (ready) {
      this._btn(card, card._cw - 96, 132 + 30, 150, 44, 'RÉCLAMER', 0x5fd97a, false, function () { self._claimOne(entry.id); });
    } else {
      this._btn(card, card._cw - 96, 132 + 30, 150, 44, 'ANNULER', 0xff4d6d, false, function () { self._confirmCancel(entry, m); });
    }
    return card;
  }

  _claimOne(entryId) {
    var self = this, r = NEBUSTION.ExpeditionManager.claim(entryId);
    if (!r.ok) { this.fx.toast('Réclamation impossible', r.reason || '', null); this._refreshAll(false); return; }
    this._showRewardReveal([r]);
  }
  _claimAll() {
    var self = this, res = NEBUSTION.ExpeditionManager.claimAll();
    if (!res.length) { this._refreshAll(false); return; }
    this._showRewardReveal(res);
  }
  _showRewardReveal(results) {
    var self = this, rows = [], notes = [];
    var totals = {};
    results.forEach(function (r) {
      var rw = r.reward;
      Object.keys(rw.res).forEach(function (id) { if (rw.res[id] > 0) totals[id] = (totals[id] || 0) + rw.res[id]; });
      totals.gem = (totals.gem || 0) + (rw.gems || 0);
      totals.frag = (totals.frag || 0) + (rw.fragments || 0) * r.heroIds.length;
      totals.xp = (totals.xp || 0) + rw.xp;
    });
    var E = NEBUSTION.Economy;
    E.ORDER.forEach(function (id) { if (totals[id] > 0) rows.push({ kind: id, amount: totals[id], color: E.RES[id].color, hex: E.RES[id].hex }); });
    if (totals.gem > 0) rows.push({ kind: 'gem', amount: totals.gem, hex: '#e6c6ff' });
    if (totals.frag > 0) rows.push({ kind: 'frag', amount: totals.frag, hex: '#8fe3ff' });
    if (totals.xp > 0) rows.push({ kind: 'xp', amount: totals.xp, hex: '#5fd97a', label: 'XP' });
    if (results.length > 1) notes.push(results.length + ' expéditions réclamées');
    this._reveal(results.length > 1 ? 'EXPÉDITIONS TERMINÉES' : 'EXPÉDITION TERMINÉE', null, rows, notes, this._accent(), function () { self._refreshAll(false); });
  }

  _confirmCancel(entry, m) {
    var self = this;
    this._confirm('Annuler l\'expédition ?', ['⚠ ' + m.name + ' : les héros seront libérés immédiatement.', 'Aucune récompense n\'est due (aucun coût n\'a été prélevé).'],
      'Annuler l\'expédition', function () {
        NEBUSTION.ExpeditionManager.cancel(entry.id);
        self.fx.toast('Expédition annulée', null, null);
        self._refreshAll(false);
      }, { accent: 0xff4d6d, confirmAccent: 0xff4d6d, cancelLabel: 'Retour', warnColor: true });
  }

  // ================= Onglet « Missions » =================
  _renderMissions(w) {
    var self = this, XM = NEBUSTION.ExpeditionManager, now = Date.now();
    var cards = [];
    // Filtre de difficulté
    var filt = this._card(56, 0x233657, { dim: true });
    var order = ['all'].concat(NEBUSTION.Expeditions.DIFF_ORDER);
    var gap = 6, cw2 = filt._cw, chipW = (cw2 - 24 - gap * (order.length - 1)) / order.length;
    order.forEach(function (id, i) {
      var x = 12 + i * (chipW + gap), active = self.missionFilter === id;
      var color = id === 'all' ? self._accent() : NEBUSTION.Expeditions.DIFFICULTIES[id].color;
      var g = self.add.graphics();
      g.fillStyle(color, active ? 0.85 : 0.12); g.fillRoundedRect(x, 8, chipW, 40, 11);
      g.lineStyle(2, color, active ? 1 : 0.5); g.strokeRoundedRect(x, 8, chipW, 40, 11);
      filt.add(g);
      var label = id === 'all' ? 'Toutes' : NEBUSTION.Expeditions.DIFFICULTIES[id].name;
      var t = self._txt(x + chipW / 2, 28, label, 13, active ? '#0a0f1e' : '#eaf2ff', { fontStyle: 'bold' }).setOrigin(0.5);
      self._fitWidth(t, chipW - 8);
      filt.add(t);
      filt._hits.push({ x: x, y: 8, w: chipW, h: 40, fn: function () { self.missionFilter = id; self._render(false); } });
    });
    cards.push(filt);

    var missions = XM.availableMissions(now).filter(function (m) { return self.missionFilter === 'all' || m.difficultyId === self.missionFilter; });
    var typeOrder = { eclair: 0, courte: 1, longue: 2, epique: 3 };
    missions.sort(function (a, b) { return (typeOrder[a.typeId] - typeOrder[b.typeId]) || (NEBUSTION.Expeditions.DIFF_ORDER.indexOf(a.difficultyId) - NEBUSTION.Expeditions.DIFF_ORDER.indexOf(b.difficultyId)); });
    missions.forEach(function (m) { cards.push(self._missionCard(m, w, now)); });
    return { cards: cards, footer: null };
  }

  _missionCard(m, w, now) {
    var self = this, XM = NEBUSTION.ExpeditionManager, EX = NEBUSTION.Expeditions;
    var t = EX.TYPES[m.typeId], d = EX.DIFFICULTIES[m.difficultyId];
    var h = 150, cw = w - 24;
    var lockReason = XM.lockReason(m);
    var cooldown = XM.cooldownLeft(m.id, now);
    var card = this._card(h, d.color, { dim: !!lockReason });
    card.add(this._txt(24, 24, m.name, 18, '#eaf2ff', { fontStyle: 'bold' }));
    var chipW = this._chip(card, 24, 46, t.name.toUpperCase(), this._accent(), 12);
    this._chip(card, 24 + chipW + 8, 46, d.name.toUpperCase(), d.color, 12);
    card.add(this._txt(24, 78, 'Puissance conseillée ' + this._fmt(m.powerReq) + '  ·  ' + m.minHeroes + '-' + m.maxHeroes + ' héros  ·  Niv. ' + m.minLevel + '+', 13, '#a9b8dc'));
    card.add(this._txt(24, 100, this._fmtDuration(m.durationSec) + (m.cooldownSec > 0 ? '  ·  recharge ' + this._fmtDuration(m.cooldownSec) : ''), 13, '#8e9cc0'));
    // aperçu de récompense (échelle neutre)
    var preview = EX.rewardsFor(m, m.powerReq, now | 0, null, {});
    var items = this._rewardItems(preview);
    this._rewardRow(card, 24, 128, items.slice(0, 4), 20, { font: 13 });

    if (lockReason) {
      var cover = this.add.graphics();
      cover.fillStyle(0x05070f, 0.55); cover.fillRoundedRect(0, 0, cw, h, 20);
      card.add(cover);
      card.add(this._txt(cw - 24, 24, '🔒', 22, '#ffd166').setOrigin(1, 0));
      card.add(this._txt(cw / 2, h / 2 + 10, lockReason, 15, '#ffd166', { fontStyle: 'bold', align: 'center', wordWrap: { width: cw - 60 } }).setOrigin(0.5));
      return card;
    }
    if (cooldown > 0) {
      this._btn(card, cw - 96, 128, 150, 40, 'RECHARGE ' + this._fmtMs(cooldown), 0x394869, true, null, 'Cette mission recharge encore.');
    } else if (XM.freeSlots() <= 0) {
      this._btn(card, cw - 96, 128, 150, 40, 'EMPLACEMENTS PLEINS', 0x394869, true, null, 'Réclamez une expédition pour libérer un emplacement.');
    } else {
      this._btn(card, cw - 96, 128, 150, 40, 'PRÉPARER', d.color, false, function () { self._enterPrep(m.id); });
    }
    return card;
  }

  // ================= Écran de préparation =================
  _enterPrep(missionId) {
    this.prep = { missionId: missionId, heroIds: [] };
    this._tabLocked = true;
    this._layoutList(this.listTop, this.scale.height - 132 - 86);
    this._buildPrepBar();
    this._render(true);
  }
  _exitPrep() {
    this.prep = null;
    this._tabLocked = false;
    if (this._prepBar) { this._prepBar.destroy(); this._prepBar = null; }
    this._layoutList(this.listTop, this.scale.height - 132);
    this.tab = 'missions';
    this._render(true);
  }

  _buildPrepBar() {
    var self = this, w = this.scale.width, h = this.scale.height;
    var y = h - 132 - 84;
    var bar = this.add.container(0, y).setDepth(900);
    var bg = this.add.graphics();
    bg.fillGradientStyle(0x0a1020, 0x0a1020, 0x05070f, 0x05070f, 0.98);
    bg.fillRect(0, 0, w, 86);
    bg.lineStyle(2, 0x1c2b4a, 1); bg.lineBetween(0, 0, w, 0);
    bar.add(bg);
    var autoW = 130, launchW = w - autoW - 68;
    var autoBtn = this.add.container(24 + autoW / 2, 43);
    var ag = this.add.graphics();
    ag.fillGradientStyle(0x1f2c52, 0x1f2c52, 0x0b1224, 0x0b1224, 1); ag.fillRoundedRect(-autoW / 2, -26, autoW, 52, 16);
    ag.lineStyle(2, 0x4fc3ff, 0.9); ag.strokeRoundedRect(-autoW / 2, -26, autoW, 52, 16);
    autoBtn.add(ag); autoBtn.add(this._txt(0, 0, 'AUTO', 18, '#eaf2ff', { fontStyle: 'bold' }).setOrigin(0.5));
    bar.add(autoBtn);
    var lz = this.add.zone(24, 17, autoW, 52).setOrigin(0).setInteractive({ useHandCursor: true });
    lz.on('pointerup', function () { self._autoPickPrep(); });
    bar.add(lz);

    var launchBtn = this.add.container(24 + autoW + 20 + launchW / 2, 43);
    var lg = this.add.graphics();
    launchBtn.add(lg);
    var lt = this._txt(0, 0, 'LANCER', 20, '#eaf2ff', { fontStyle: '900' }).setOrigin(0.5);
    launchBtn.add(lt);
    bar.add(launchBtn);
    this._prepLaunchDraw = function (enabled) {
      lg.clear();
      lg.fillGradientStyle(enabled ? 0x1f2c52 : 0x1a2233, enabled ? 0x1f2c52 : 0x1a2233, enabled ? 0x0b1224 : 0x11172a, enabled ? 0x0b1224 : 0x11172a, 1);
      lg.fillRoundedRect(-launchW / 2, -26, launchW, 52, 16);
      lg.lineStyle(2.5, enabled ? self._accent() : 0x394869, enabled ? 0.95 : 0.45);
      lg.strokeRoundedRect(-launchW / 2, -26, launchW, 52, 16);
      lt.setColor(enabled ? '#eaf2ff' : '#6d7c9c');
    };
    this._prepLaunchDraw(false);
    var lz2 = this.add.zone(24 + autoW + 20, 17, launchW, 52).setOrigin(0).setInteractive({ useHandCursor: true });
    lz2.on('pointerup', function () { self._doLaunchPrep(); });
    bar.add(lz2);

    var back = this._txt(w - 20, y - 16, '◀ Retour', 15, '#8e9cc0', { fontStyle: 'bold' }).setOrigin(1, 0.5).setInteractive({ useHandCursor: true }).setDepth(901);
    back.on('pointerup', function () { self._exitPrep(); });
    this._prepBackBtn = back;
    this._prepBar = bar;
  }

  _autoPickPrep() {
    var m = NEBUSTION.Expeditions.mission(this.prep.missionId), XM = NEBUSTION.ExpeditionManager, H = NEBUSTION.Heroes, C = NEBUSTION.Combat;
    var list = H.all().filter(function (h) { return XM.heroEligibility(h.id, m).ok; })
      .map(function (h) { return { id: h.id, power: XM.heroPower(h.id) }; })
      .sort(function (a, b) { return b.power - a.power; });
    this.prep.heroIds = list.slice(0, m.maxHeroes).map(function (x) { return x.id; });
    this._render(false);
  }

  _doLaunchPrep() {
    var m = NEBUSTION.Expeditions.mission(this.prep.missionId);
    var chk = NEBUSTION.ExpeditionManager.canLaunch(m.id, this.prep.heroIds);
    if (!chk.ok) { this.fx.toast('Envoi impossible', this._launchReasonText(chk), null); return; }
    var self = this, r = NEBUSTION.ExpeditionManager.launch(m.id, this.prep.heroIds);
    if (!r.ok) { this.fx.toast('Envoi impossible', this._launchReasonText(r), null); return; }
    this._exitPrep();
    this.tab = 'active';
    this._refreshAll(false);
    if (r.reward) this._showRewardReveal([r]);
    else this.fx.toast('Expédition envoyée', m.name, null);
  }

  _launchReasonText(r) {
    var map = { verrouille: 'Mission verrouillée.', recharge: 'En recharge.', emplacements: 'Aucun emplacement libre.', occupe: 'Un héros choisi est déjà occupé.', niveau: 'Niveau insuffisant.', heros_min: 'Pas assez de héros choisis.', heros_max: 'Trop de héros choisis.', invalide: 'Sélection invalide.' };
    return map[r.reason] || 'Impossible.';
  }

  _renderPrep(w) {
    var self = this, m = NEBUSTION.Expeditions.mission(this.prep.missionId), XM = NEBUSTION.ExpeditionManager, H = NEBUSTION.Heroes, C = NEBUSTION.Combat;
    var t = NEBUSTION.Expeditions.TYPES[m.typeId], d = NEBUSTION.Expeditions.DIFFICULTIES[m.difficultyId];
    var cards = [];
    var teamPower = XM.teamPowerOf(this.prep.heroIds);
    var preview = NEBUSTION.Expeditions.rewardsFor(m, teamPower, Date.now() | 0, NEBUSTION.Resources.rates(), { heroCount: this.prep.heroIds.length, roleMatch: this.prep.heroIds.some(function (id) { var h = H.get(id); return h && h.role === m.favoredRole; }) });

    var head = this._card(150, d.color, { glow: true });
    head.add(this._txt(24, 24, m.name, 20, '#eaf2ff', { fontStyle: 'bold' }));
    head.add(this._txt(24, 50, t.name + ' · ' + d.name + '  ·  ' + m.minHeroes + '-' + m.maxHeroes + ' héros  ·  rôle favorisé : ' + (NEBUSTION.Heroes.ROLES[m.favoredRole] ? NEBUSTION.Heroes.ROLES[m.favoredRole].name : m.favoredRole), 13, '#a9b8dc', { wordWrap: { width: head._cw - 48 } }));
    head.add(this._txt(24, 92, 'Puissance envoyée : ' + this._fmt(teamPower) + ' / ' + this._fmt(m.powerReq) + ' conseillée', 15, teamPower >= m.powerReq ? '#5fd97a' : '#ffb84d', { fontStyle: 'bold' }));
    var items = this._rewardItems(preview).concat(preview.xp > 0 ? [{ kind: 'xp', amount: preview.xp, hex: '#5fd97a', label: 'XP' }] : []);
    this._rewardRow(head, 24, 120, items.slice(0, 4), 22, { font: 14 });
    cards.push(head);

    var list = H.all().map(function (h) {
      return { id: h.id, hero: h, level: C.heroLevel(h.id), power: XM.heroPower(h.id), elig: XM.heroEligibility(h.id, m) };
    }).sort(function (a, b) {
      var aok = a.elig.ok ? 0 : 1, bok = b.elig.ok ? 0 : 1;
      return (aok - bok) || (b.power - a.power);
    });
    list.forEach(function (e) { cards.push(self._heroRowCard(e, m, w)); });

    if (this._prepLaunchDraw) this._prepLaunchDraw(this.prep.heroIds.length >= m.minHeroes && this.prep.heroIds.length <= m.maxHeroes && teamPower >= 0);
    return { cards: cards, footer: null };
  }

  _heroRowCard(e, m, w) {
    var self = this, H = NEBUSTION.Heroes, rarity = H.RARITIES[e.hero.rarity];
    var selected = this.prep.heroIds.indexOf(e.id) >= 0;
    var h = 96, cw = w - 24;
    var card = this._card(h, selected ? this._accent() : 0x2b3a5c, { dim: !e.elig.ok && !selected });
    this._heroThumb(card, e.id, 12, 12, 72, 72, !e.elig.ok);
    card.add(this._txt(96, 26, e.hero.name, 17, '#eaf2ff', { fontStyle: 'bold' }));
    card.add(this._txt(96, 50, H.ROLES[e.hero.role].name + '  ·  Niv. ' + e.level + '  ·  ⚡' + this._fmt(e.power), 13, rarity.hex));
    if (!e.elig.ok) {
      var reason = e.elig.reason === 'occupe' ? 'En expédition' : (e.elig.reason === 'niveau' ? 'Niveau ' + e.elig.need + ' requis' : 'Indisponible');
      card.add(this._txt(96, 70, reason, 13, '#ff9a7b', { fontStyle: 'bold' }));
    } else if (selected) {
      var checkG = this.add.graphics(); this._drawCheck(checkG, cw - 30, h / 2, 1.1, this._accent()); card.add(checkG);
    }
    var self2 = this;
    if (e.elig.ok || selected) {
      card._hits.push({ x: 0, y: 0, w: cw, h: h, fn: function () { self2._toggleHeroPrep(e.id, m); } });
    } else {
      card._hits.push({ x: 0, y: 0, w: cw, h: h, fn: function () { self2.fx.toast('Héros indisponible', null, null); } });
    }
    return card;
  }

  _toggleHeroPrep(id, m) {
    var i = this.prep.heroIds.indexOf(id);
    if (i >= 0) this.prep.heroIds.splice(i, 1);
    else {
      if (this.prep.heroIds.length >= m.maxHeroes) { this.fx.toast('Équipe complète', 'Maximum ' + m.maxHeroes + ' héros pour cette mission.', null); return; }
      this.prep.heroIds.push(id);
    }
    this._render(false);
  }
};
