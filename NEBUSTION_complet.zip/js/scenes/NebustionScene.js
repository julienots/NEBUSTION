/**
 * NEBUSTION - NebustionScene
 * Écran du module « grand méchant » (débloqué après la victoire sur OMEGA-KRELL) : onglet
 * Sanctuaire (jauge de corruption galactique, achat/activation de la contre-mesure), onglet
 * Avant-postes (3 stages farmables + accès au boss final NEBUSTION), onglet Symtor (dilemme :
 * nourrir avec l'Éclat Souillé fait monter la Résonance jusqu'à corrompre le Symtor).
 *
 * Toute la logique vit dans NEBUSTION.NebustionManager ; cet écran ne fait que l'afficher et
 * relayer les taps, comme PrestigeScene/EventScene (même classe de base ProgressScene).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.NebustionScene = class NebustionScene extends NEBUSTION.ProgressScene {
  constructor() { super('NebustionScene'); }

  _hubKey() { return 'nebustion'; }
  _titleText() { return 'NEBUSTION'; }
  _accent() { return 0x8a2be2; }
  _accentHex() { return '#8a2be2'; }
  _defaultTab() { return 'sanctuary'; }
  _tabDefs() { return [{ id: 'sanctuary', label: 'Sanctuaire' }, { id: 'outposts', label: 'Avant-postes' }, { id: 'symtor', label: 'Symtor' }]; }

  _badgeContent(c) {
    var NM = NEBUSTION.NebustionManager;
    if (!NM.isUnlocked()) { this._badgePill(c, 'frag', 'Verrouillé', 0x394869, '#8e9cc0'); return; }
    this._badgePill(c, 'frag', this._fmt(NM.shards()), this._accent(), this._accentHex());
  }

  _renderTab(w) {
    var NM = NEBUSTION.NebustionManager;
    if (!NM.isUnlocked()) return this._renderLocked(w);
    if (this.tab === 'outposts') return this._renderOutposts(w);
    if (this.tab === 'symtor') return this._renderSymtor(w);
    return this._renderSanctuary(w);
  }

  // ================= Verrouillé =================
  _renderLocked(w) {
    var card = this._card(260, 0x394869, { dim: true });
    card.add(this._txt(24, 30, 'Signal inconnu', 20, '#eaf2ff', { fontStyle: 'bold' }));
    card.add(this._txt(24, 66, 'Quelque chose d\'immense dormait derrière OMEGA-KRELL. Vaincez-le pour révéler la vérité.', 15, '#a9b8dc', { wordWrap: { width: card._cw - 48 } }));
    card.add(this._txt(24, 130, 'Objectif : vaincre OMEGA-KRELL, Le Cataclysme', 15, '#ff9a7b', { fontStyle: 'bold' }));
    var self = this;
    this._btn(card, card._cw / 2, 200, card._cw - 48, 46, 'ALLER AU COMBAT', this._accent(), false, function () {
      self.scene.start('CombatPrepScene', { stageId: 'boss_omega_krell' });
    });
    return { cards: [card], footer: null };
  }

  // ================= Onglet Sanctuaire =================
  _renderSanctuary(w) {
    var self = this, NM = NEBUSTION.NebustionManager, cards = [];
    var pct = NM.pct(), rate = NM.rateInfo().perHour;

    var head = this._card(150, this._accent(), { glow: pct >= 80 });
    head.add(this._txt(24, 24, 'Jauge de corruption galactique', 17, '#eaf2ff', { fontStyle: 'bold' }));
    var barColor = pct >= 80 ? 0xff4d5e : (pct >= 50 ? 0xffb347 : this._accent());
    this._bar(head, 24, 54, head._cw - 48, 20, pct / 100, barColor);
    head.add(this._txt(head._cw / 2, 64, pct.toFixed(1) + ' %', 15, '#eaf2ff', { fontStyle: 'bold' }).setOrigin(0.5));
    head.add(this._txt(24, 96, '+' + (rate * 100).toFixed(2) + ' %/h' + (rate > 0 ? ' (' + (100 / Math.max(rate, 0.0001) / 24).toFixed(1) + ' j avant 100 %)' : ''), 14, '#a9b8dc'));
    head.add(this._txt(24, 122, pct >= 80 ? '⚠ Critique : les avant-postes sont beaucoup plus durs.' : 'Plus la jauge est haute, plus les avant-postes corrompus sont durs (et payants).', 12, pct >= 80 ? '#ff9a7b' : '#6d7c9c', { wordWrap: { width: head._cw - 48 } }));
    cards.push(head);

    var lvl = NM.sanctuaryLevel(), maxLvl = NEBUSTION.Nebustion.CFG.SANCTUARY_MAX_LEVEL;
    var sanct = this._card(lvl >= maxLvl ? 130 : 190, this._accent(), {});
    sanct.add(this._txt(24, 22, 'Sanctuaire — niveau ' + lvl + ' / ' + maxLvl, 18, '#eaf2ff', { fontStyle: 'bold' }));
    sanct.add(this._txt(24, 50, lvl > 0 ? ('Ralentit la corruption de ' + NM.sanctuaryDecayPct() + ' %.') : 'Pas encore construit : la corruption progresse à vitesse maximale.', 14, '#a9b8dc', { wordWrap: { width: sanct._cw - 48 } }));
    if (lvl >= maxLvl) {
      this._btn(sanct, sanct._cw / 2, 100, sanct._cw - 48, 44, 'NIVEAU MAXIMUM', 0x394869, true, null, null);
    } else {
      var cost = NM.sanctuaryCost(), R = NEBUSTION.Resources;
      var affordable = true, costTxt = [];
      Object.keys(cost).forEach(function (id) {
        var have = (R.state.res && R.state.res[id]) || 0;
        if (have < cost[id]) affordable = false;
        costTxt.push(self._fmt(cost[id]) + ' ' + (NEBUSTION.Economy.RES[id] ? NEBUSTION.Economy.RES[id].name : id));
      });
      sanct.add(this._txt(24, 82, costTxt.join('  ·  '), 13, affordable ? '#c7d3f0' : '#ff9a7b'));
      this._btn(sanct, sanct._cw / 2, 126, sanct._cw - 48, 44, lvl > 0 ? 'AMÉLIORER LE SANCTUAIRE' : 'CONSTRUIRE LE SANCTUAIRE', this._accent(), !affordable, function () { self._upgradeSanctuary(); }, 'Ressources insuffisantes.');
    }
    cards.push(sanct);

    var act = this._card(150, this._accent(), { dim: lvl === 0 });
    act.add(this._txt(24, 22, 'Activation manuelle', 17, '#eaf2ff', { fontStyle: 'bold' }));
    act.add(this._txt(24, 50, 'Purifie immédiatement ' + NEBUSTION.Nebustion.CFG.SANCTUARY_PURIFY_PCT + ' % de la jauge. Une fois toutes les ' + Math.round(NEBUSTION.Nebustion.CFG.SANCTUARY_ACTIVATE_COOLDOWN_MS / 3600000) + ' h.', 13, '#a9b8dc', { wordWrap: { width: act._cw - 48 } }));
    if (lvl === 0) {
      this._btn(act, act._cw / 2, 108, act._cw - 48, 44, 'SANCTUAIRE REQUIS', 0x394869, true, null, null);
    } else if (NM.canActivateSanctuary()) {
      this._btn(act, act._cw / 2, 108, act._cw - 48, 44, 'ACTIVER', this._accent(), false, function () { self._activateSanctuary(); });
    } else {
      var cdT = this._txt(act._cw / 2, 108, '', 20, '#8e9cc0', { fontStyle: 'bold' }).setOrigin(0.5);
      act.add(cdT);
      this._liveText(cdT, function () { return 'Prochaine activation dans ' + self._fmtMs(NM.sanctuaryCooldownRemainingMs()); });
    }
    cards.push(act);

    return { cards: cards, footer: null };
  }

  _upgradeSanctuary() {
    var r = NEBUSTION.NebustionManager.upgradeSanctuary();
    if (!r.ok) { this.fx.toast('Achat refusé', r.reason === 'cost' ? 'Ressources insuffisantes.' : '', null); this._refreshAll(false); return; }
    this.fx.toast('Sanctuaire amélioré', 'Niveau ' + r.level, null);
    this._refreshAll(false);
  }
  _activateSanctuary() {
    var r = NEBUSTION.NebustionManager.activateSanctuary();
    if (!r.ok) { this.fx.toast('Activation impossible', null, null); this._refreshAll(false); return; }
    this.fx.toast('Sanctuaire activé', '-' + r.amount.toFixed(1) + ' % de corruption', null);
    this._refreshAll(false);
  }

  // ================= Onglet Avant-postes =================
  _renderOutposts(w) {
    var self = this, NM = NEBUSTION.NebustionManager, D = NEBUSTION.Nebustion, C = NEBUSTION.Combat, EN = NEBUSTION.Enemies, cards = [];

    var intro = this._card(90, this._accent(), { dim: true });
    intro.add(this._txt(24, 22, 'Avant-postes rejouables', 16, '#eaf2ff', { fontStyle: 'bold' }));
    intro.add(this._txt(24, 48, 'Chaque victoire rapporte de l\'Éclat Souillé et purifie la jauge de ' + D.CFG.OUTPOST_PURIFY_PCT + ' %.', 13, '#a9b8dc', { wordWrap: { width: intro._cw - 48 } }));
    cards.push(intro);

    D.CFG.OUTPOST_STAGE_IDS.forEach(function (id) {
      var stage = EN.stage(id), stars = C.stageStars(id), unlocked = C.isStageUnlocked(id);
      var h = 130, card = self._card(h, self._accent(), { dim: !unlocked });
      card.add(self._txt(24, 22, stage ? stage.name : id, 18, '#eaf2ff', { fontStyle: 'bold' }));
      card.add(self._txt(24, 50, stars > 0 ? ('Meilleur score : ' + '★'.repeat(stars) + '☆'.repeat(3 - stars)) : 'Jamais vaincu', 14, stars > 0 ? '#ffe9a3' : '#8e9cc0'));
      if (!unlocked) {
        self._btn(card, card._cw - 96, 96, 150, 44, 'VERROUILLÉ', 0x394869, true, null, 'Terminez l\'avant-poste précédent.');
      } else {
        self._btn(card, card._cw - 96, 96, 150, 44, 'COMBATTRE', self._accent(), false, function () { self.scene.start('CombatPrepScene', { stageId: id }); });
      }
      cards.push(card);
    });

    var bossId = D.CFG.BOSS_STAGE_ID, bossUnlocked = C.isStageUnlocked(bossId), bossStars = C.stageStars(bossId);
    var bossCard = self._card(150, 0xff4d5e, { dim: !bossUnlocked, glow: bossUnlocked && bossStars === 0 });
    bossCard.add(self._txt(24, 24, 'NEBUSTION, l\'Éveil Primordial', 19, '#ffb3bd', { fontStyle: 'bold' }));
    bossCard.add(self._txt(24, 52, bossStars > 0 ? 'Vaincu — ' + '★'.repeat(bossStars) + '☆'.repeat(3 - bossStars) : 'Le boss final du module.', 14, bossStars > 0 ? '#ffe9a3' : '#a9b8dc'));
    if (!bossUnlocked) {
      self._btn(bossCard, bossCard._cw / 2, 108, bossCard._cw - 48, 44, 'VERROUILLÉ', 0x394869, true, null, 'Vainquez les 3 avant-postes.');
    } else {
      self._btn(bossCard, bossCard._cw / 2, 108, bossCard._cw - 48, 44, bossStars > 0 ? 'REJOUER' : 'AFFRONTER', 0xff4d5e, false, function () { self.scene.start('CombatPrepScene', { stageId: bossId }); });
    }
    cards.push(bossCard);

    return { cards: cards, footer: null };
  }

  // ================= Onglet Symtor =================
  _renderSymtor(w) {
    var self = this, NM = NEBUSTION.NebustionManager, D = NEBUSTION.Nebustion, cards = [];
    var res = NM.resonance(), corrupted = NM.symtorCorrupted(), shards = NM.shards();

    var head = this._card(180, corrupted ? 0xff4d5e : this._accent(), { glow: corrupted });
    head.add(this._txt(24, 24, 'Le dilemme du Symtor', 19, '#eaf2ff', { fontStyle: 'bold' }));
    head.add(this._txt(24, 52, 'Nourrir le Symtor avec de l\'Éclat Souillé le rend plus puissant... mais le corrompt peu à peu.', 13, '#a9b8dc', { wordWrap: { width: head._cw - 48 } }));
    this._bar(head, 24, 96, head._cw - 48, 18, res / 100, corrupted ? 0xff4d5e : this._accent());
    head.add(this._txt(head._cw / 2, 105, 'Résonance : ' + res.toFixed(0) + ' %', 14, '#eaf2ff', { fontStyle: 'bold' }).setOrigin(0.5));
    head.add(this._txt(24, 134, corrupted ? '⚠ Le Symtor est corrompu : il appelle Nebustion en continu (+' + (D.CFG.CORRUPTED_SYMTOR_EXTRA_RATE_PER_HOUR * 100).toFixed(0) + ' %/h).' : 'Le Symtor est encore sain.', 14, corrupted ? '#ff9a7b' : '#5fd97a', { fontStyle: 'bold', wordWrap: { width: head._cw - 48 } }));
    cards.push(head);

    var feed = this._card(150, this._accent(), { dim: corrupted });
    feed.add(this._txt(24, 22, 'Nourrir avec de l\'Éclat Souillé', 16, '#eaf2ff', { fontStyle: 'bold' }));
    feed.add(this._txt(24, 50, 'Coût : ' + D.CFG.SHARDS_PER_FEED + ' Éclat Souillé  ·  Possédés : ' + self._fmt(shards), 14, '#a9b8dc'));
    feed.add(self._txt(24, 76, '+' + D.CFG.RESONANCE_PER_FEED + ' % de Résonance à chaque fois.', 12, '#6d7c9c'));
    if (corrupted) {
      this._btn(feed, feed._cw / 2, 116, feed._cw - 48, 40, 'DÉJÀ CORROMPU', 0x394869, true, null, null);
    } else {
      var can = shards >= D.CFG.SHARDS_PER_FEED;
      this._btn(feed, feed._cw / 2, 116, feed._cw - 48, 40, 'NOURRIR LE SYMTOR', this._accent(), !can, function () { self._feed(); }, 'Éclat Souillé insuffisant.');
    }
    cards.push(feed);

    var note = this._card(110, 0x394869, { dim: true });
    note.add(this._txt(24, 22, corrupted ? 'Purification' : 'À savoir', 15, '#8e9cc0', { fontStyle: 'bold' }));
    note.add(this._txt(24, 48, corrupted ? 'Lever la corruption du Symtor demandera un objet rare de fin de jeu, pas encore disponible.' : 'Nourrir le Symtor est optionnel : c\'est un pari entre puissance immédiate et risque à long terme.', 13, '#a9b8dc', { wordWrap: { width: note._cw - 48 } }));
    cards.push(note);

    return { cards: cards, footer: null };
  }

  _feed() {
    var r = NEBUSTION.NebustionManager.feedTaintedToSymtor();
    if (!r.ok) { this.fx.toast('Nourrissage impossible', null, null); this._refreshAll(false); return; }
    if (r.justCorrupted) this.fx.toast('Le Symtor est corrompu...', 'Résonance à 100 %', null);
    else this.fx.toast('Symtor nourri', 'Résonance ' + r.resonance.toFixed(0) + ' %', null);
    this._refreshAll(false);
  }
};
