/**
 * NEBUSTION - MainMenuScene
 * Hub central du jeu : fond spatial profond en parallaxe (étoiles, nébuleuses),
 * planète Nexus-01 en rotation lente, HUD de ressources, et navigation vers
 * les 6 sections du jeu via la BottomNav (barre de menu fixe et dépliée, en bas de l'écran) ;
 * lance le tutoriel au premier passage. Les 8 raccourcis additionnels (Galaxie, Héros, Combat,
 * Boutique, Expéditions, Événement, Prestige, Succès) sont regroupés dans un rail vertical sur le
 * bord gauche de l'écran.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.MainMenuScene = class MainMenuScene extends Phaser.Scene {
  constructor() {
    super('MainMenuScene');
  }

  create() {
    var w = this.scale.width, h = this.scale.height;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(400, 5, 7, 15);

    NEBUSTION.SceneBackground.build(this, { withPlanet: true });

    // --- En-tête : logo + HUD ressources ---
    var header = this.add.text(w / 2, 150, 'NEBUSTION', {
      fontFamily: 'Arial, sans-serif',
      fontSize: '28px',
      fontStyle: '900',
      color: '#eaf2ff'
    }).setOrigin(0.5).setShadow(0, 0, '#00e5ff', 12, true, true);
    header.setDepth(50);

    this.hud = NEBUSTION.HUD.attach(this);

    // --- Titre de section ---
    this.add.text(w / 2, 192, 'Nexus-01 — Secteur Aube', {
      fontFamily: 'Arial, sans-serif',
      fontSize: '15px',
      color: '#7a89ad'
    }).setOrigin(0.5).setDepth(50);

    // --- Bouton central d'action rapide : entrer sur la planète ---
    var enterBtn = new NEBUSTION.Button(this, w / 2, h * 0.6, {
      width: 260,
      height: 72,
      label: 'ENTRER SUR NEXUS-01',
      accentColor: 0x00e5ff,
      fontSize: '18px',
      onClick: () => {
        this.cameras.main.fadeOut(300, 5, 7, 15);
        this.cameras.main.once('camerafadeoutcomplete', () => {
          this.scene.start('PlanetScene', { navKey: 'planet', title: 'Planète' });
        });
      }
    });
    enterBtn.setDepth(50);
    this.tweens.add({ targets: enterBtn, y: enterBtn.y - 8, duration: 1600, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });

    // --- Raccourcis vers les autres sections (rail vertical, bord gauche) ---
    this._buildSideRail();

    // --- Autres galaxies visibles autour de Nexus-01 (aperçu de l'Univers, touchables) ---
    this._buildOrbitGalaxies();

    // --- Navigation : barre de menu fixe et dépliée, en bas de l'écran ---
    new NEBUSTION.BottomNav(this, null);

    // --- Tutoriel d'accueil : une seule fois (rejouable via Paramètres → « Revoir le tutoriel ») ---
    if (NEBUSTION.TutorialManager && NEBUSTION.TutorialOverlay && NEBUSTION.TutorialManager.shouldShow()) {
      this.time.delayedCall(900, () => { if (this.scene.isActive()) NEBUSTION.TutorialOverlay.show(this); });
    }
  }

  /** Galaxies voisines de la Voie Aube, dispersées autour de Nexus-01 et visibles dès l'arrivée
   *  sur l'accueil (même style que le disque central, couleurs différentes). Toucher l'une d'elles
   *  la fait grossir puis y entre (ou affiche sa condition de déblocage) — NEBUSTION.UniverseMap. */
  _buildOrbitGalaxies() {
    var U = NEBUSTION.Universe;
    if (!U || !NEBUSTION.UniverseMap) return;
    var w = this.scale.width;
    var layout = {
      ecarlate: { x: w * 0.135, y: 248, size: 108, tilt: -0.22, depth: 20 },
      glacial: { x: w * 0.865, y: 248, size: 108, tilt: -0.34, depth: 20 },
      kaelis: { x: w / 2, y: 878, size: 82, tilt: -0.18, depth: 20 }
    };
    U.GALAXIES.forEach((g) => {
      if (g.id === 'aube') return;   // déjà représentée par Nexus-01, au centre
      var L = layout[g.id];
      if (!L) return;
      NEBUSTION.UniverseMap.buildNode(this, g, L.x, L.y, L);
    });
  }

  _buildSideRail() {
    var w = this.scale.width, h = this.scale.height;
    var items = [
      { label: 'Galaxie', key: 'galaxy', color: 0x6c3ce9 },
      { label: 'Héros', key: 'heroes', color: 0xff4d9e },
      { label: 'Combat', key: 'combat', color: 0xff4d6d },
      { label: 'Boutique', key: 'shop', color: 0xffd166 },
      { label: 'Expéditions', key: 'expedition', color: 0x4fc3ff },
      { label: 'Événement', key: 'event', color: 0xff7bd1 },
      { label: 'Prestige', key: 'prestige', color: 0xffd166 },
      { label: 'Succès', key: 'achievements', color: 0x5fd97a }
    ];
    var targets = {
      heroes: 'HeroesScene', combat: 'CombatPrepScene', galaxy: 'UniverseScene', shop: 'ShopScene',
      expedition: 'ExpeditionScene', event: 'EventScene', prestige: 'PrestigeScene', achievements: 'AchievementsScene'
    };

    var barH = (NEBUSTION.BottomNav && NEBUSTION.BottomNav.HANDLE) ? NEBUSTION.BottomNav.HANDLE.h : 92;
    var railW = 76, top = 214, bottom = h - barH - 8;
    var cellH = (bottom - top) / items.length;

    var bg = this.add.graphics();
    bg.fillGradientStyle(0x0d1730, 0x0d1730, 0x05070f, 0x05070f, 0.92, 0.92, 0.97, 0.97);
    bg.fillRect(0, top, railW, bottom - top);
    bg.lineStyle(2, 0x2a3d6e, 0.9);
    bg.lineBetween(railW, top, railW, bottom);
    bg.setDepth(49);

    items.forEach((item, i) => {
      var y = top + cellH * i + cellH / 2;
      var btn = new NEBUSTION.Button(this, railW / 2, y, {
          width: railW - 12,
          height: Math.min(cellH - 8, 86),
          accentColor: item.color,
          onClick: () => {
            var target = targets[item.key] || 'PlaceholderScene';
            var data = { navKey: item.key, title: item.label };
            if (target === 'UniverseScene') data.from = 'MainMenuScene';
            this.cameras.main.fadeOut(250, 5, 7, 15);
            this.cameras.main.once('camerafadeoutcomplete', () => {
              this.scene.start(target, data);
            });
          },
          iconDraw: (g) => {
            g.lineStyle(2.5, item.color, 1);
            var iy = 0;
            switch (item.key) {
              case 'galaxy':
                g.strokeCircle(0, iy, 5);
                g.strokeCircle(0, iy, 12);
                break;
              case 'heroes':
                g.strokeCircle(0, iy - 6, 6);
                g.strokeTriangle(-10, iy + 8, 10, iy + 8, 0, iy - 2);
                break;
              case 'combat':
                g.lineBetween(-9, iy - 9, 9, iy + 9);
                g.lineBetween(-9, iy + 9, 9, iy - 9);
                break;
              case 'shop':
                g.strokeRoundedRect(-11, iy - 8, 22, 16, 3);
                break;
              case 'expedition':
                g.lineBetween(0, iy - 11, 0, iy + 11);
                g.lineBetween(0, iy - 11, -7, iy - 3);
                g.lineBetween(0, iy - 11, 7, iy - 3);
                break;
              case 'event':
                g.strokeCircle(0, iy, 11);
                g.lineBetween(0, iy - 5, 0, iy + 2);
                g.fillStyle(item.color, 1); g.fillCircle(0, iy + 7, 1.6);
                break;
              case 'prestige':
                g.strokeTriangle(0, iy - 11, -10, iy + 8, 10, iy + 8);
                break;
              case 'achievements':
                g.strokeCircle(0, iy - 2, 9);
                g.lineBetween(-5, iy + 6, -3, iy + 13);
                g.lineBetween(5, iy + 6, 3, iy + 13);
                break;
            }
          }
      });
      btn.setDepth(50);
    });
  }
};
