/**
 * NEBUSTION - EquipmentScene
 * Module Équipement complet : ouvert depuis la fiche d'un héros (bouton "Équipement" dans
 * HeroesScene). 5 emplacements (arme / armure / module / réacteur / artefact), fabrication,
 * équiper/déséquiper, amélioration, fusion et démantèlement. Inventaire avec filtre par
 * emplacement et tri. Les bonus sont réellement appliqués en combat (voir
 * CombatEngine.makeHeroUnit + CombatManager). Objets aussi obtenus en combat/invasion
 * (EquipmentManager.maybeDropFromCombat) et en farm (caisses de ravitaillement, voir SupplyPod).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.EquipmentScene = class EquipmentScene extends Phaser.Scene {
  constructor() { super('EquipmentScene'); }

  init(data) { this.heroId = (data && data.heroId) || null; this.filterSlot = (data && data.filterSlot) || null; this.sortMode = (data && data.sortMode) || 'rarete'; }

  create() {
    var w = this.scale.width, h = this.scale.height;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(250, 5, 7, 15);
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });

    var H = NEBUSTION.Heroes;
    this.hero = H.get(this.heroId) || H.all()[0];
    this.heroId = this.hero.id;

    this.add.text(w / 2, 96, 'ÉQUIPEMENT', {
      fontFamily: 'Arial, sans-serif', fontSize: '24px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(50).setShadow(0, 0, '#00e5ff', 10, true, true);

    this.add.text(w / 2, 126, this.hero.name, {
      fontFamily: 'Arial, sans-serif', fontSize: '15px', fontStyle: 'bold', color: '#7a89ad'
    }).setOrigin(0.5).setDepth(50);

    var backBtn = this.add.text(28, 126, '‹ Retour', {
      fontFamily: 'Arial, sans-serif', fontSize: '16px', color: '#00e5ff'
    }).setOrigin(0, 0.5).setDepth(60).setInteractive({ useHandCursor: true });
    backBtn.on('pointerdown', () => this.scene.start('HeroesScene'));

    var self = this;
    this._loadCustomTemplateTextures(function () {
      self.slotsY = 152;
      self._buildSlots();

      self.craftY = self._slotsBottom + 34;
      self._buildCraftRow();

      self.customCraftY = self._craftBottom + 26;
      self._buildCustomCraftRow();

      self.filterY = (self._customCraftBottom || self._craftBottom) + 26;
      self._buildFilterBar();

      self.listTop = self.filterY + 34;
      self.listBottom = h - 24;
      self._buildInventory();

      self.hud = NEBUSTION.HUD.attach(self);
    });
  }

  // ---------- Images des objets personnalisés (Atelier créateur, onglet Équipement) ----------
  // Même principe que HeroTextures/EnemyTextures : une image envoyée dans l'Atelier remplace
  // l'icône vectorielle générique, sans rien changer au reste du module.
  _loadCustomTemplateTextures(onDone) {
    var self = this, EQ = NEBUSTION.Equipment;
    var templates = (NEBUSTION.EquipmentManager.templates() || []).filter(function (t) { return t.portrait; });
    var queued = 0, finished = false, guard = null;

    function finish() {
      if (finished) return;
      finished = true;
      if (guard) guard.stop();
      if (onDone) onDone();
    }

    templates.forEach(function (t) {
      var key = EQ.itemIconKey(t.id);
      if (!self.textures.exists(key)) { self.load.image(key, t.portrait); queued++; }
    });

    if (queued === 0) { finish(); return; }
    self.load.once('complete', finish);
    guard = NEBUSTION.LoaderGuard.watch(self, finish);
    self.load.start();
  }

  // ---------- Icônes vectorielles d'emplacement (aucune texture externe requise ; primitives
  // limitées aux méthodes Graphics standard — pas de beginPath/moveTo/lineTo à la main) ----------
  _drawSlotIcon(gfx, slotId, cx, cy, color) {
    gfx.lineStyle(2.5, color, 0.95);
    gfx.fillStyle(color, 0.28);
    if (slotId === 'weapon') {
      // Lame (triangle) + garde + poignée.
      gfx.fillTriangle(cx - 6, cy + 16, cx + 10, cy - 16, cx + 16, cy - 10);
      gfx.strokeTriangle(cx - 6, cy + 16, cx + 10, cy - 16, cx + 16, cy - 10);
      gfx.lineBetween(cx - 12, cy + 10, cx - 2, cy + 20);
      gfx.lineBetween(cx - 18, cy + 16, cx - 12, cy + 22);
    } else if (slotId === 'armor') {
      // Écusson : triangle haut + triangle bas assemblés.
      gfx.fillTriangle(cx - 14, cy - 8, cx + 14, cy - 8, cx, cy - 18);
      gfx.fillTriangle(cx - 14, cy - 8, cx + 14, cy - 8, cx, cy + 18);
      gfx.strokeTriangle(cx - 14, cy - 8, cx + 14, cy - 8, cx, cy - 18);
      gfx.strokeTriangle(cx - 14, cy - 8, cx + 14, cy - 8, cx, cy + 18);
    } else if (slotId === 'module') {
      gfx.strokeCircle(cx, cy, 13); gfx.fillCircle(cx, cy, 5);
      for (var i = 0; i < 6; i++) {
        var a = i * Math.PI / 3;
        gfx.lineBetween(cx + Math.cos(a) * 13, cy + Math.sin(a) * 13, cx + Math.cos(a) * 18, cy + Math.sin(a) * 18);
      }
    } else if (slotId === 'reactor') {
      // Éclair : 2 triangles imbriqués.
      gfx.fillTriangle(cx + 8, cy - 16, cx - 8, cy + 2, cx + 2, cy + 2);
      gfx.fillTriangle(cx + 2, cy + 2, cx - 6, cy + 16, cx + 10, cy - 4);
      gfx.strokeTriangle(cx + 8, cy - 16, cx - 8, cy + 2, cx + 2, cy + 2);
      gfx.strokeTriangle(cx + 2, cy + 2, cx - 6, cy + 16, cx + 10, cy - 4);
    } else { // artifact — gemme (losange = 2 triangles)
      gfx.fillTriangle(cx - 13, cy - 2, cx + 13, cy - 2, cx, cy - 16);
      gfx.fillTriangle(cx - 13, cy - 2, cx + 13, cy - 2, cx, cy + 16);
      gfx.strokeTriangle(cx - 13, cy - 2, cx + 13, cy - 2, cx, cy - 16);
      gfx.strokeTriangle(cx - 13, cy - 2, cx + 13, cy - 2, cx, cy + 16);
    }
  }

  // ---------- Icône d'un objet (image personnalisée si le modèle en a une, sinon icône vectorielle) ----------
  _addItemIcon(cx, cy, slot, color, size, portraitTemplateId) {
    var EQ = NEBUSTION.Equipment;
    if (portraitTemplateId) {
      var key = EQ.itemIconKey(portraitTemplateId);
      if (this.textures.exists(key)) return this.add.image(cx, cy, key).setDisplaySize(size, size);
    }
    var gfx = this.add.graphics();
    this._drawSlotIcon(gfx, slot, cx, cy, color);
    return gfx;
  }

  // ---------- Emplacements équipés : grille 3 + 2 (5 emplacements) ----------
  _buildSlots() {
    var self = this, w = this.scale.width, EQ = NEBUSTION.Equipment;
    var cols = 3, slotW = (w - 24 - 16) / cols, boxH = 160, rowGap = 16;
    var row2Offset = (cols * (slotW + 8) - 8 - (2 * slotW + 8)) / 2;

    EQ.SLOT_ORDER.forEach(function (slot, i) {
      var row = Math.floor(i / cols), col = i % cols;
      var x = (row === 1 ? (12 + row2Offset) : 12) + slotW / 2 + col * (slotW + 8);
      var y = self.slotsY + 80 + row * (boxH + rowGap);
      var c = self.add.container(x, y).setDepth(40);
      var item = NEBUSTION.EquipmentManager.equippedItem(self.heroId, slot);
      var rarity = item ? EQ.RARITIES[item.rarity] : null;
      var color = rarity ? rarity.color : 0x3a4a72;

      var bg = self.add.graphics();
      bg.fillStyle(0x121a30, 0.9);
      bg.fillRoundedRect(-slotW / 2, -boxH / 2, slotW, boxH, 14);
      bg.lineStyle(2, color, item ? 0.9 : 0.4);
      bg.strokeRoundedRect(-slotW / 2, -boxH / 2, slotW, boxH, 14);
      c.add(bg);

      var iconNode = self._addItemIcon(0, -boxH / 2 + 28, slot, color, 40, item && item.templateId);
      c.add(iconNode);

      c.add(self.add.text(0, -boxH / 2 + 54, item && item.custom ? item.displayName : EQ.SLOTS[slot].name.toUpperCase(), {
        fontFamily: 'Arial, sans-serif', fontSize: '11px', fontStyle: 'bold', color: '#7a89ad'
      }).setOrigin(0.5));

      if (item) {
        c.add(self.add.text(0, -6, 'Niv. ' + item.level, {
          fontFamily: 'Arial, sans-serif', fontSize: '18px', fontStyle: '900', color: rarity.hex
        }).setOrigin(0.5));
        c.add(self.add.text(0, 18, rarity.name, {
          fontFamily: 'Arial, sans-serif', fontSize: '11px', color: rarity.hex
        }).setOrigin(0.5));
        var unequipBtn = self.add.text(0, boxH / 2 - 16, 'Retirer', {
          fontFamily: 'Arial, sans-serif', fontSize: '12px', fontStyle: 'bold', color: '#ff6b6b'
        }).setOrigin(0.5).setInteractive({ useHandCursor: true });
        unequipBtn.on('pointerdown', function () {
          NEBUSTION.EquipmentManager.unequip(self.heroId, slot);
          self._refresh();
        });
        c.add(unequipBtn);
      } else {
        c.add(self.add.text(0, 6, 'Vide', {
          fontFamily: 'Arial, sans-serif', fontSize: '14px', color: '#4a5578'
        }).setOrigin(0.5));
      }
    });

    this._slotsBottom = this.slotsY + 80 + boxH / 2 + (boxH + rowGap) * Math.floor((EQ.SLOT_ORDER.length - 1) / cols);
  }

  // ---------- Fabrication (grille 3 + 2, boutons faits main pour intégrer les icônes réelles) ----------
  _buildCraftRow() {
    var self = this, w = this.scale.width, EQ = NEBUSTION.Equipment;
    this.add.text(24, this.craftY - 14, 'Fabriquer (commun) :', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#7a89ad'
    }).setDepth(40);

    var cols = 3, slotW = (w - 24 - 16) / cols, btnH = 56, rowGap = 8;
    var row2Offset = (cols * (slotW + 8) - 8 - (2 * slotW + 8)) / 2;

    EQ.SLOT_ORDER.forEach(function (slot, i) {
      var row = Math.floor(i / cols), col = i % cols;
      var x = (row === 1 ? (12 + row2Offset) : 12) + slotW / 2 + col * (slotW + 8);
      var y = self.craftY + 22 + row * (btnH + rowGap);
      var cost = EQ.craftCost(slot, 'commun');

      var c = self.add.container(x, y).setDepth(45);
      var bg = self.add.graphics();
      bg.fillGradientStyle(0x151d33, 0x151d33, 0x0b1224, 0x0b1224, 1);
      bg.fillRoundedRect(-slotW / 2, -btnH / 2, slotW, btnH, 12);
      bg.lineStyle(2, 0x4fd1ff, 0.7);
      bg.strokeRoundedRect(-slotW / 2, -btnH / 2, slotW, btnH, 12);
      c.add(bg);
      c.add(self.add.text(0, -btnH / 2 + 15, EQ.SLOTS[slot].name, {
        fontFamily: 'Arial, sans-serif', fontSize: '12.5px', fontStyle: 'bold', color: '#eaf2ff'
      }).setOrigin(0.5));
      var im1 = self.add.image(-26, btnH / 2 - 15, 'tex_icon_metal').setDisplaySize(18, 18);
      var t1 = self.add.text(-14, btnH / 2 - 15, String(cost.metal), { fontFamily: 'Arial, sans-serif', fontSize: '12px', fontStyle: 'bold', color: '#c8d4f0' }).setOrigin(0, 0.5);
      var im2 = self.add.image(16, btnH / 2 - 15, 'tex_icon_core').setDisplaySize(18, 18);
      var t2 = self.add.text(28, btnH / 2 - 15, String(cost.core), { fontFamily: 'Arial, sans-serif', fontSize: '12px', fontStyle: 'bold', color: '#c8d4f0' }).setOrigin(0, 0.5);
      c.add([im1, t1, im2, t2]);

      var zone = self.add.zone(0, 0, slotW, btnH).setInteractive({ useHandCursor: true });
      zone.on('pointerdown', function () {
        var res = NEBUSTION.EquipmentManager.craft(slot, 'commun');
        if (res.ok) self._refresh(); else self._toast(res.reason === 'ressources' ? 'Ressources insuffisantes' : 'Erreur');
      });
      c.add(zone);
    });

    this._craftBottom = this.craftY + 22 + btnH / 2 + (btnH + rowGap) * Math.floor((EQ.SLOT_ORDER.length - 1) / cols);
  }

  // ---------- Fabrication des objets personnalisés (Atelier créateur) : liste verticale, une ligne
  // par modèle créé, image/nom/coût, même formule de coût que le générique de son emplacement. ----------
  _buildCustomCraftRow() {
    var self = this, w = this.scale.width, EQ = NEBUSTION.Equipment;
    var templates = NEBUSTION.EquipmentManager.templates();
    if (!templates.length) { this._customCraftBottom = this._craftBottom; return; }

    this.add.text(24, this.customCraftY - 14, 'Créations personnalisées :', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#7a89ad'
    }).setDepth(40);

    var rowH = 56, gap = 8;
    templates.forEach(function (tpl, i) {
      var rarity = EQ.RARITIES[tpl.rarity];
      var cost = EQ.craftCost(tpl.slot, tpl.rarity);
      var y = self.customCraftY + 20 + i * (rowH + gap);

      var c = self.add.container(w / 2, y).setDepth(45);
      var bg = self.add.graphics();
      bg.fillStyle(0x121a30, 0.9);
      bg.fillRoundedRect(-(w - 24) / 2, -rowH / 2, w - 24, rowH, 12);
      bg.lineStyle(2, rarity.color, 0.8);
      bg.strokeRoundedRect(-(w - 24) / 2, -rowH / 2, w - 24, rowH, 12);
      c.add(bg);

      var iconNode = self._addItemIcon(-(w - 24) / 2 + 30, 0, tpl.slot, rarity.color, 36, tpl.id);
      c.add(iconNode);

      c.add(self.add.text(-(w - 24) / 2 + 58, -12, tpl.name, {
        fontFamily: 'Arial, sans-serif', fontSize: '13px', fontStyle: 'bold', color: rarity.hex
      }));
      c.add(self.add.text(-(w - 24) / 2 + 58, 10, EQ.SLOTS[tpl.slot].name + ' · ' + rarity.name, {
        fontFamily: 'Arial, sans-serif', fontSize: '11px', color: '#7a89ad'
      }));

      var btnX = (w - 24) / 2 - 16;
      var im1 = self.add.image(btnX - 70, -6, 'tex_icon_metal').setDisplaySize(16, 16).setOrigin(0.5);
      var t1 = self.add.text(btnX - 60, -6, String(cost.metal), { fontFamily: 'Arial, sans-serif', fontSize: '11px', fontStyle: 'bold', color: '#c8d4f0' }).setOrigin(0, 0.5);
      var im2 = self.add.image(btnX - 24, -6, 'tex_icon_core').setDisplaySize(16, 16).setOrigin(0.5);
      var t2 = self.add.text(btnX - 14, -6, String(cost.core), { fontFamily: 'Arial, sans-serif', fontSize: '11px', fontStyle: 'bold', color: '#c8d4f0' }).setOrigin(0, 0.5);
      c.add([im1, t1, im2, t2]);

      var craftBtn = self.add.text(btnX, 16, 'Fabriquer', {
        fontFamily: 'Arial, sans-serif', fontSize: '12px', fontStyle: 'bold', color: '#00e5ff'
      }).setOrigin(1, 0.5).setInteractive({ useHandCursor: true });
      craftBtn.on('pointerdown', function () {
        var res = NEBUSTION.EquipmentManager.craftTemplate(tpl.id);
        if (res.ok) self._refresh(); else self._toast(res.reason === 'ressources' ? 'Ressources insuffisantes' : 'Erreur');
      });
      c.add(craftBtn);
    });

    this._customCraftBottom = this.customCraftY + 20 + templates.length * (rowH + gap) - gap + rowH / 2;
  }

  // ---------- Filtre par emplacement + tri ----------
  _buildFilterBar() {
    var self = this, w = this.scale.width, EQ = NEBUSTION.Equipment;
    this.filterBar = this.add.container(0, this.filterY).setDepth(40);
    var chips = [{ id: null, label: 'Tous' }].concat(EQ.SLOT_ORDER.map(function (s) { return { id: s, label: EQ.SLOTS[s].name }; }));
    var gap = 6, cw = (w - 24 - gap * (chips.length - 1)) / chips.length;
    this._filterChips = [];
    chips.forEach(function (ch, i) {
      var x = 12 + cw / 2 + i * (cw + gap);
      var active = self.filterSlot === ch.id;
      var g = self.add.graphics();
      g.fillStyle(active ? 0x1c3a5a : 0x121a30, 0.95);
      g.fillRoundedRect(x - cw / 2, -13, cw, 26, 13);
      g.lineStyle(1.4, active ? 0x4fd1ff : 0x2a3860, 0.9);
      g.strokeRoundedRect(x - cw / 2, -13, cw, 26, 13);
      var t = self.add.text(x, 0, ch.label, {
        fontFamily: 'Arial, sans-serif', fontSize: '10.5px', fontStyle: 'bold', color: active ? '#4fd1ff' : '#9aa5c0'
      }).setOrigin(0.5).setScale(Math.min(1, (cw - 6) / 60));
      var zone = self.add.zone(x, 0, cw, 26).setInteractive({ useHandCursor: true });
      zone.on('pointerdown', function () { self.filterSlot = ch.id; self._refresh(); });
      self.filterBar.add([g, t, zone]);
    });

    var sortLabels = { rarete: 'Tri : Rareté ▾', niveau: 'Tri : Niveau ▾', nom: 'Tri : Nom A-Z' };
    var sortBtn = this.add.text(w - 16, 34, sortLabels[this.sortMode], {
      fontFamily: 'Arial, sans-serif', fontSize: '12px', fontStyle: 'bold', color: '#ffd166'
    }).setOrigin(1, 0.5).setDepth(40).setInteractive({ useHandCursor: true });
    var order = ['rarete', 'niveau', 'nom'];
    sortBtn.on('pointerdown', function () {
      self.sortMode = order[(order.indexOf(self.sortMode) + 1) % order.length];
      self._refresh();
    });
  }

  // ---------- Inventaire (liste filtrée/triée, avec fusion) ----------
  _buildInventory() {
    var self = this, w = this.scale.width;
    this.listContainer = this.add.container(0, this.listTop).setDepth(40);
    this._refreshList();

    var viewH = this.listBottom - this.listTop;
    this.listMaskGfx = this.make.graphics();
    this.listMaskGfx.fillRect(0, this.listTop, w, viewH);
    this.listContainer.setMask(this.listMaskGfx.createGeometryMask());

    var dragging = false, startY = 0, startScroll = 0;
    // Zone de défilement placée SOUS les lignes interactives : elle ne doit jamais intercepter
    // les boutons « Équiper », « Améliorer », « Fusionner » ou « Démanteler ».
    var zone = this.add.zone(0, this.listTop, w, viewH).setOrigin(0).setInteractive().setDepth(35);
    zone.on('pointerdown', function (p) { dragging = true; startY = p.y; startScroll = self.scrollY || 0; });
    this.input.on('pointermove', function (p) {
      if (!dragging) return;
      self.scrollY = Phaser.Math.Clamp(startScroll - (p.y - startY), 0, self.maxScroll || 0);
      self.listContainer.y = self.listTop - self.scrollY;
    });
    this.input.on('pointerup', function () { dragging = false; });
    this.input.on('pointerupoutside', function () { dragging = false; });
  }

  _sortItems(items, EQ) {
    var mode = this.sortMode;
    if (mode === 'niveau') {
      return items.sort(function (a, b) { return b.level - a.level || EQ.RARITIES[b.rarity].order - EQ.RARITIES[a.rarity].order; });
    }
    if (mode === 'nom') {
      return items.sort(function (a, b) {
        return (a.displayName || EQ.itemName(a.slot, a.rarity)).localeCompare(b.displayName || EQ.itemName(b.slot, b.rarity));
      });
    }
    return items.sort(function (a, b) { return EQ.RARITIES[b.rarity].order - EQ.RARITIES[a.rarity].order || b.level - a.level; });
  }

  _refreshList() {
    var self = this, w = this.scale.width, EQ = NEBUSTION.Equipment, EM = NEBUSTION.EquipmentManager;
    this.listContainer.removeAll(true);

    var items = EM.list();
    if (this.filterSlot) items = items.filter(function (it) { return it.slot === self.filterSlot; });
    items = this._sortItems(items, EQ);

    if (!items.length) {
      this.listContainer.add(this.add.text(w / 2, 30, this.filterSlot ? 'Aucun objet de ce type pour le moment.' : 'Aucun objet pour le moment. Fabriquez-en un ci-dessus.', {
        fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#7a89ad', align: 'center', wordWrap: { width: w - 60 }
      }).setOrigin(0.5, 0));
      this.maxScroll = 0;
      return;
    }

    var rowH = 108, gap = 8;
    items.forEach(function (item, i) {
      var row = self._buildItemRow(item, w, rowH, EQ, EM);
      row.y = i * (rowH + gap);
      self.listContainer.add(row);
    });

    var viewH = this.listBottom - this.listTop;
    this.maxScroll = Math.max(0, items.length * (rowH + gap) - viewH);
    this.scrollY = Math.min(this.scrollY || 0, this.maxScroll);
    this.listContainer.y = this.listTop - this.scrollY;
  }

  _buildItemRow(item, w, rowH, EQ, EM) {
    var self = this;
    var rarity = EQ.RARITIES[item.rarity];
    var equipped = EM.isEquipped(item.uid);
    var row = this.add.container(0, 0);

    var bg = this.add.graphics();
    bg.fillStyle(0x121a30, 0.9);
    bg.fillRoundedRect(12, 0, w - 24, rowH - 8, 12);
    bg.lineStyle(1.5, rarity.color, equipped ? 0.95 : 0.5);
    bg.strokeRoundedRect(12, 0, w - 24, rowH - 8, 12);
    row.add(bg);

    var iconNode = this._addItemIcon(40, rowH / 2 - 4, item.slot, rarity.color, 40, item.templateId);
    row.add(iconNode);

    row.add(this.add.text(64, 12, item.displayName || EQ.itemName(item.slot, item.rarity), {
      fontFamily: 'Arial, sans-serif', fontSize: '14px', fontStyle: 'bold', color: rarity.hex
    }));
    row.add(this.add.text(64, 34, 'Niveau ' + item.level + '/' + EQ.MAX_LEVEL + (equipped ? '  ·  équipé' : ''), {
      fontFamily: 'Arial, sans-serif', fontSize: '11.5px', color: equipped ? '#5fd97a' : '#7a89ad'
    }));

    var bonus = EQ.bonusFor(item.slot, item.rarity, item.level);
    var bonusStr = Object.keys(bonus).map(function (k) { return '+' + bonus[k] + ' ' + k; }).join('  ');
    row.add(this.add.text(64, 54, bonusStr, {
      fontFamily: 'Arial, sans-serif', fontSize: '11px', color: '#9aa5c0'
    }));

    var btnX = w - 32;
    var equipBtn = this.add.text(btnX, 14, equipped ? 'Sur ce héros' : 'Équiper', {
      fontFamily: 'Arial, sans-serif', fontSize: '12px', fontStyle: 'bold',
      color: equipped ? '#4a5578' : '#00e5ff'
    }).setOrigin(1, 0.5);
    if (!equipped) {
      equipBtn.setInteractive({ useHandCursor: true });
      equipBtn.on('pointerdown', function () { NEBUSTION.EquipmentManager.equip(self.heroId, item.uid); self._refresh(); });
    }
    row.add(equipBtn);

    var upCost = EQ.upgradeCost(item.rarity, item.level);
    var upLabel = item.level >= EQ.MAX_LEVEL ? 'Niveau max' : 'Améliorer';
    var upBtn = this.add.text(btnX, 36, upLabel, {
      fontFamily: 'Arial, sans-serif', fontSize: '11.5px', fontStyle: 'bold',
      color: item.level >= EQ.MAX_LEVEL ? '#4a5578' : '#ffd166'
    }).setOrigin(1, 0.5);
    row.add(upBtn);
    if (item.level < EQ.MAX_LEVEL) {
      var upIcon = this.add.image(btnX - upBtn.width - 20, 36, 'tex_icon_metal').setDisplaySize(16, 16).setOrigin(1, 0.5);
      var upCostTxt = this.add.text(upIcon.x - 4, 36, String(upCost.metal), { fontFamily: 'Arial, sans-serif', fontSize: '11px', color: '#c8d4f0' }).setOrigin(1, 0.5);
      row.add([upIcon, upCostTxt]);
      upBtn.setInteractive({ useHandCursor: true });
      upBtn.on('pointerdown', function () {
        var res = NEBUSTION.EquipmentManager.upgrade(item.uid);
        if (res.ok) self._refresh(); else self._toast('Ressources insuffisantes');
      });
    }

    var fusionMatch = !equipped ? EM.findFusionMatch(item.uid) : null;
    var nextRarity = fusionMatch ? EQ.nextRarity(item.rarity) : null;
    if (fusionMatch && nextRarity) {
      var fuseBtn = this.add.text(btnX, 58, 'Fusionner → ' + EQ.RARITIES[nextRarity].name, {
        fontFamily: 'Arial, sans-serif', fontSize: '11px', fontStyle: 'bold', color: '#b47bff'
      }).setOrigin(1, 0.5).setInteractive({ useHandCursor: true });
      fuseBtn.on('pointerdown', function () {
        var res = NEBUSTION.EquipmentManager.fuse(item.uid, fusionMatch);
        if (res.ok) self._refresh(); else self._toast('Fusion impossible');
      });
      row.add(fuseBtn);
    } else if (!equipped) {
      var dismantleBtn = this.add.text(btnX, 58, 'Démanteler', {
        fontFamily: 'Arial, sans-serif', fontSize: '11px', color: '#ff6b6b'
      }).setOrigin(1, 0.5).setInteractive({ useHandCursor: true });
      dismantleBtn.on('pointerdown', function () { NEBUSTION.EquipmentManager.dismantle(item.uid); self._refresh(); });
      row.add(dismantleBtn);
    }

    return row;
  }

  _refresh() {
    this.scene.restart({ heroId: this.heroId, filterSlot: this.filterSlot, sortMode: this.sortMode });
  }

  _toast(msg) {
    var w = this.scale.width;
    var t = this.add.text(w / 2, this.scale.height - 160, msg, {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', fontStyle: 'bold', color: '#ff6b6b',
      backgroundColor: '#0a0f1e', padding: { x: 12, y: 8 }
    }).setOrigin(0.5).setDepth(500);
    this.tweens.add({ targets: t, alpha: 0, delay: 900, duration: 400, onComplete: function () { t.destroy(); } });
  }
};
