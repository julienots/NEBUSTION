/**
 * NEBUSTION - SkinsScene
 * Personnalisation (étape 6/10, 3e volet) : skins de héros, vaisseaux et bâtiments.
 *  - 3 onglets (Héros / Vaisseaux / Bâtiments), sélecteur de cible (‹ nom ›)
 *  - APERÇU animé avant sélection : toucher une carte = voir le rendu sans rien acheter ni équiper
 *  - inventaire de cosmétiques : cartes « Possédé / Équipé / prix », filtre Tout / Possédés, compteur de collection
 *  - actions : Acheter (ressources) → Équiper → Retirer ; effet visuel à l'équipement
 * Accessible depuis HeroesScene (fiche héros), ShipsScene (en-tête) et PlanetScene (fiche bâtiment).
 * Données d'entrée : { tab: 'hero'|'ship'|'building', targetId, from: clé de scène de retour }.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.SkinsScene = class SkinsScene extends Phaser.Scene {
  constructor() { super('SkinsScene'); }

  init(data) {
    data = data || {};
    this.tab = NEBUSTION.Skins.TARGET_TYPES.indexOf(data.tab) >= 0 ? data.tab : 'hero';
    this.wantTarget = data.targetId || null;
    this.from = data.from || 'MainMenuScene';
    this.filterOwned = false;
    this.sel = null;          // skin en aperçu : id, 'std' (apparence d'origine) ou null (= skin actuellement équipé)
    this.tIndex = 0;
    this.previewFx = null;
    this.previewKill = [];
  }

  create() {
    var w = this.scale.width;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(250, 5, 7, 15);
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });

    this.add.text(w / 2, 128, 'PERSONNALISATION', {
      fontFamily: 'Arial, sans-serif', fontSize: '24px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(50).setShadow(0, 0, '#b47bff', 10, true, true);

    // y=128 : sous la zone tactile du HUD (y 10..106), sinon le bouton serait inatteignable
    var backBtn = this.add.text(28, 128, '‹ Retour', {
      fontFamily: 'Arial, sans-serif', fontSize: '16px', color: '#00e5ff'
    }).setOrigin(0, 0.5).setDepth(60).setInteractive({ useHandCursor: true });
    var self = this;
    backBtn.on('pointerdown', function () { self.scene.start(self.from); });

    this.dyn = this.add.container(0, 0).setDepth(30);
    this._loadTargets();
    if (this.wantTarget) {
      var i = this.targets.findIndex(function (t) { return t.id === self.wantTarget; });
      if (i >= 0) this.tIndex = i;
    }
    this._render();
    this.hud = NEBUSTION.HUD.attach(this);
  }

  // ---------- Cibles ----------
  _loadTargets() {
    var H = NEBUSTION.Heroes, E = NEBUSTION.Economy, SH = NEBUSTION.Ships, SM = NEBUSTION.ShipManager;
    if (this.tab === 'hero') {
      this.targets = H.all().filter(function (h) { return NEBUSTION.Combat.isUnlocked(h.id); }).map(function (h) { return { id: h.id, name: h.name }; });
    } else if (this.tab === 'ship') {
      this.targets = SM.list().sort(function (a, b) {
        return SH.RARITIES[b.rarity].order - SH.RARITIES[a.rarity].order || b.level - a.level || (a.uid < b.uid ? -1 : 1);
      }).map(function (s) {
        return { id: s.uid, name: SH.shipName(s.classId, s.rarity) + ' · Nv.' + s.level, classId: s.classId, rarity: s.rarity };
      });
    } else {
      this.targets = NEBUSTION.Skins.BUILDING_TARGETS.map(function (id) { return { id: id, name: E.BUILDINGS[id].name }; });
    }
    if (this.tIndex >= this.targets.length) this.tIndex = 0;
  }

  _switchTab(tab) {
    if (tab === this.tab) return;
    this.tab = tab; this.tIndex = 0; this.sel = null; this.wantTarget = null;
    this._loadTargets();
    this._render();
  }

  // ---------- Rendu ----------
  _priceStr(cost) {
    var icons = { crystal: '◆', energy: '⚡', dust: '✦', core: '●' };
    return Object.keys(cost).map(function (k) { return (icons[k] || k) + cost[k]; }).join(' ');
  }

  _clearPreview() {
    try { this.tweens.killTweensOf(this.previewKill); } catch (e) { /* ignore */ }
    this.previewKill = [];
    if (this.previewFx) { this.previewFx.destroy(); this.previewFx = null; }
  }

  _render() {
    var self = this, w = this.scale.width, K = NEBUSTION.Skins, SM = NEBUSTION.SkinManager, H = NEBUSTION.Heroes;
    this._clearPreview();
    this.dyn.removeAll(true);
    var L = this.dyn;

    // --- Onglets ---
    var tabW = (w - 48 - 16) / 3;
    K.TARGET_TYPES.forEach(function (type, i) {
      var x = 24 + i * (tabW + 8), active = type === self.tab;
      var g = self.add.graphics();
      g.fillStyle(active ? 0x1d2a52 : 0x0d1428, 0.95);
      g.fillRoundedRect(x, 158, tabW, 38, 10);
      g.lineStyle(active ? 2 : 1, active ? 0xb47bff : 0x394869, active ? 0.95 : 0.7);
      g.strokeRoundedRect(x, 158, tabW, 38, 10);
      var col = SM.collection().byType[type];
      var t = self.add.text(x + tabW / 2, 177, K.TARGET_NAMES[type] + '  ' + col.owned + '/' + col.total, {
        fontFamily: 'Arial, sans-serif', fontSize: '13px', fontStyle: 'bold', color: active ? '#eaf2ff' : '#7a89ad'
      }).setOrigin(0.5);
      var z = self.add.zone(x, 158, tabW, 38).setOrigin(0).setInteractive({ useHandCursor: true });
      z.on('pointerdown', function () { self._switchTab(type); });
      L.add([g, t, z]);
    });

    var targets = this.targets, n = targets.length;

    // --- Sélecteur de cible ---
    if (n > 1) {
      [[-1, 40, '‹'], [1, w - 40, '›']].forEach(function (a) {
        var arrow = self.add.text(a[1], 232, a[2], { fontFamily: 'Arial, sans-serif', fontSize: '38px', color: '#00e5ff' })
          .setOrigin(0.5).setInteractive({ useHandCursor: true });
        arrow.on('pointerdown', function () { self.tIndex = (self.tIndex + a[0] + n) % n; self.sel = null; self._render(); });
        L.add(arrow);
      });
    }

    var stageY = 268, stageH = 236, cx = w / 2, cy = stageY + stageH / 2 + 4;
    this.stageCy = cy;
    var stage = this.add.graphics();
    stage.fillGradientStyle(0x121a30, 0x121a30, 0x0a0f1e, 0x0a0f1e, 0.95);
    stage.fillRoundedRect(24, stageY, w - 48, stageH, 18);
    L.add(stage);

    if (!n) {
      L.add(this.add.text(w / 2, 232, K.TARGET_NAMES[this.tab], { fontFamily: 'Arial, sans-serif', fontSize: '20px', fontStyle: 'bold', color: '#eaf2ff' }).setOrigin(0.5));
      stage.lineStyle(1.5, 0x394869, 0.7); stage.strokeRoundedRect(24, stageY, w - 48, stageH, 18);
      L.add(this.add.text(w / 2, cy, 'Aucun vaisseau pour le moment.\nAcquérez-en un depuis « Flotte ».', {
        fontFamily: 'Arial, sans-serif', fontSize: '14px', color: '#7a89ad', align: 'center'
      }).setOrigin(0.5));
      this._buildFooter(L);
      return;
    }

    var target = targets[this.tIndex];
    L.add(this.add.text(w / 2, 226, target.name, { fontFamily: 'Arial, sans-serif', fontSize: '19px', fontStyle: 'bold', color: '#eaf2ff' }).setOrigin(0.5));
    L.add(this.add.text(w / 2, 248, (this.tIndex + 1) + ' / ' + n, { fontFamily: 'Arial, sans-serif', fontSize: '12px', color: '#7a89ad' }).setOrigin(0.5));

    var equippedId = SM.equippedId(this.tab, target.id);
    var previewId = this.sel === null ? equippedId : (this.sel === 'std' ? null : this.sel);
    var skin = previewId ? K.get(previewId) : null;

    // --- Aperçu animé ---
    var floor = this.add.graphics();
    floor.fillStyle(0x000000, 0.35); floor.fillEllipse(cx, stageY + stageH - 34, 200, 34);
    stage.lineStyle(2, skin ? K.RARITIES[skin.rarity].color : 0x394869, 0.85);
    stage.strokeRoundedRect(24, stageY, w - 48, stageH, 18);
    L.add(floor);

    if (this.tab === 'hero') {
      var img = this.add.image(cx, cy, H.portraitKey(target.id)).setDisplaySize(176, 224);
      L.add(img);
      this.previewFx = NEBUSTION.SkinFX.attach(this, L, img, skin, 176, 224);
    } else if (this.tab === 'ship') {
      var ship = NEBUSTION.SkinFX.drawShip(this, target.classId, skin, 170, NEBUSTION.Ships.RARITIES[target.rarity].color);
      ship.setPosition(cx, cy);
      L.add(ship);
      this.previewKill = (ship.fxTargets || []).slice();
      this.previewFx = NEBUSTION.SkinFX.attach(this, L, ship, skin, 190, 200);
    } else {
      var bld = NEBUSTION.SkinFX.drawBuilding(this, target.id, skin, 170);
      bld.setPosition(cx, cy + 96);
      L.add(bld);
      this.previewKill = (bld.fxTargets || []).slice();
      this.previewFx = NEBUSTION.SkinFX.attach(this, L, bld, skin, 200, 200, { x: cx, y: cy });
    }

    // --- Fiche du skin ---
    var infoY = stageY + stageH + 14;
    var rar = skin ? K.RARITIES[skin.rarity] : null;
    L.add(this.add.text(24, infoY, skin ? skin.name : 'Standard', {
      fontFamily: 'Arial, sans-serif', fontSize: '18px', fontStyle: 'bold', color: rar ? rar.hex : '#eaf2ff'
    }));
    L.add(this.add.text(w - 24, infoY + 3, skin ? (rar.name + ' · ' + K.FX[skin.fx]) : 'Apparence d\'origine', {
      fontFamily: 'Arial, sans-serif', fontSize: '12px', color: '#9aa5c0'
    }).setOrigin(1, 0));
    L.add(this.add.text(24, infoY + 26, skin ? skin.desc : 'Aucun skin appliqué : rendu par défaut du jeu.', {
      fontFamily: 'Arial, sans-serif', fontSize: '12.5px', color: '#7a89ad', wordWrap: { width: w - 48 }
    }));

    // --- Bouton d'action ---
    var btnY = infoY + 78;
    var cfg;
    if (!skin) {
      cfg = equippedId ? { label: 'RETIRER LE SKIN', accent: 0xff6b6b, act: 'unequip' }
                       : { label: 'APPARENCE ACTUELLE', accent: 0x394869, disabled: true };
    } else if (equippedId === skin.id) {
      cfg = { label: 'ÉQUIPÉ  ·  RETIRER', accent: 0x5fd97a, act: 'unequip' };
    } else if (SM.isOwned(skin.id)) {
      cfg = { label: 'ÉQUIPER', accent: 0x00e5ff, act: 'equip' };
    } else if (skin.exclusive) {
      cfg = { label: '🏆 RÉCOMPENSE DU PASS DORÉ', accent: 0xffd166, disabled: true };
    } else {
      var cost = K.cost(skin.rarity), can = NEBUSTION.Resources.canAfford(cost);
      cfg = { label: 'ACHETER  ' + this._priceStr(cost), accent: can ? 0xffd166 : 0x5c6b8a, act: 'buy' };
    }
    var btn = new NEBUSTION.Button(this, cx, btnY, {
      width: w - 48, height: 54, label: cfg.label, fontSize: '17px', accentColor: cfg.accent, disabled: !!cfg.disabled,
      onClick: function () { self._act(cfg.act, target, skin); }
    });
    L.add(btn);

    // --- Grille de cartes (inventaire de cosmétiques) ---
    var entries = [{ std: true }].concat(K.forTarget(this.tab).filter(function (s) { return !self.filterOwned || SM.isOwned(s.id); }));
    var cw = (w - 48 - 12) / 2, ch = 116, gy = btnY + 48;
    entries.forEach(function (en, i) {
      var col = i % 2, row = Math.floor(i / 2);
      self._buildCard(L, en, 24 + col * (cw + 12), gy + row * (ch + 10), cw, ch, equippedId, previewId);
    });
    this._buildFooter(L);
  }

  _buildCard(L, en, x0, y0, cw, ch, equippedId, previewId) {
    var self = this, K = NEBUSTION.Skins, SM = NEBUSTION.SkinManager;
    var isStd = !!en.std;
    var rar = isStd ? null : K.RARITIES[en.rarity];
    var owned = isStd || SM.isOwned(en.id);
    var isEquipped = isStd ? !equippedId : equippedId === en.id;
    var isPreview = isStd ? previewId === null : previewId === en.id;

    var g = this.add.graphics();
    g.fillStyle(isPreview ? 0x1a2647 : 0x121a30, 0.95);
    g.fillRoundedRect(x0, y0, cw, ch, 12);
    g.lineStyle(isPreview ? 3 : 1.5, isPreview ? 0x00e5ff : (rar ? rar.color : 0x394869), isPreview ? 0.95 : 0.55);
    g.strokeRoundedRect(x0, y0, cw, ch, 12);
    L.add(g);

    var sx = x0 + 48, sy = y0 + ch / 2;
    if (isStd) {
      L.add(this.add.circle(sx, sy, 22, 0x394869, 1));
      L.add(this.add.circle(sx, sy, 14, 0x0a0f1e, 1));
    } else {
      L.add(this.add.image(sx, sy, 'tex_glow_white').setDisplaySize(96, 96).setTint(en.aura).setBlendMode(Phaser.BlendModes.ADD).setAlpha(0.85));
      L.add(this.add.circle(sx, sy, 21, 0x000000, 0.35).setStrokeStyle(2, rar.color, 0.9));
      L.add(this.add.circle(sx, sy, 15, en.hull, 1).setStrokeStyle(3, en.aura, 1));
      L.add(this.add.circle(sx, sy, 6, (en.aura2 !== undefined ? en.aura2 : en.aura), 1).setBlendMode(Phaser.BlendModes.ADD));
    }

    var tx = x0 + 92;
    L.add(this.add.text(tx, y0 + 14, isStd ? 'Standard' : en.name, {
      fontFamily: 'Arial, sans-serif', fontSize: '14px', fontStyle: 'bold', color: rar ? rar.hex : '#eaf2ff'
    }));
    L.add(this.add.text(tx, y0 + 36, isStd ? 'Apparence d\'origine' : (rar.name + ' · ' + K.FX[en.fx]), {
      fontFamily: 'Arial, sans-serif', fontSize: '11.5px', color: '#7a89ad'
    }));
    var status, color;
    if (isEquipped) { status = '✓ ÉQUIPÉ'; color = '#5fd97a'; }
    else if (owned) { status = 'Possédé'; color = '#00e5ff'; }
    else if (en.crate) { status = '📦 Caisses & Forge'; color = '#ffb3f0'; }
    else if (en.exclusive) { status = '🏆 Pass Doré'; color = '#ffd166'; }
    else { status = this._priceStr(K.cost(en.rarity)); color = '#ffd166'; }
    L.add(this.add.text(tx, y0 + ch - 36, status, {
      fontFamily: 'Arial, sans-serif', fontSize: '12px', fontStyle: 'bold', color: color, wordWrap: { width: cw - 100 }
    }));

    var z = this.add.zone(x0, y0, cw, ch).setOrigin(0).setInteractive({ useHandCursor: true });
    z.on('pointerdown', function () { self.sel = isStd ? 'std' : en.id; self._render(); });
    L.add(z);
  }

  _buildFooter(L) {
    var self = this, w = this.scale.width, h = this.scale.height, SM = NEBUSTION.SkinManager;
    var col = SM.collection();
    L.add(this.add.text(24, h - 34, 'Collection : ' + col.owned + '/' + col.total + '  ·  équipés : ' + SM.equippedCount(), {
      fontFamily: 'Arial, sans-serif', fontSize: '12.5px', color: '#7a89ad'
    }).setOrigin(0, 0.5));
    var f = this.add.text(w - 24, h - 34, 'Afficher : ' + (this.filterOwned ? 'Possédés' : 'Tout') + ' ⇄', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', fontStyle: 'bold', color: '#00e5ff'
    }).setOrigin(1, 0.5).setInteractive({ useHandCursor: true });
    f.on('pointerdown', function () { self.filterOwned = !self.filterOwned; self._render(); });
    L.add(f);
  }

  // ---------- Actions ----------
  _act(act, target, skin) {
    var SM = NEBUSTION.SkinManager, tab = this.tab, res;
    if (act === 'buy') {
      res = SM.buy(skin.id);
      if (res.ok) { this._render(); this._burst(skin.aura); this._toast('Skin acheté : ' + skin.name, '#5fd97a'); }
      else this._toast(res.reason === 'ressources' ? 'Ressources insuffisantes' : 'Achat impossible', '#ff6b6b');
    } else if (act === 'equip') {
      res = SM.equip(tab, target.id, skin.id);
      if (res.ok) { this.sel = null; this._render(); this._burst(skin.aura); this._toast('Skin équipé', '#00e5ff'); }
      else this._toast('Équipement impossible', '#ff6b6b');
    } else if (act === 'unequip') {
      res = SM.unequip(tab, target.id);
      this.sel = null; this._render();
      if (res.ok) this._toast('Skin retiré', '#9aa5c0');
    }
  }

  _burst(color) {
    var self = this, cx = this.scale.width / 2, cy = this.stageCy || 390, ADD = Phaser.BlendModes.ADD;
    var ring = this.add.image(cx, cy, 'tex_ring_soft').setTint(color).setBlendMode(ADD).setScale(0.2).setAlpha(0.9).setDepth(200);
    this.tweens.add({ targets: ring, scaleX: 3.2, scaleY: 3.2, alpha: 0, duration: 520, ease: 'Sine.easeOut', onComplete: function () { ring.destroy(); } });
    for (var i = 0; i < 8; i++) {
      var a = (i / 8) * Math.PI * 2;
      var sp = this.add.image(cx, cy, 'tex_spark').setTint(color).setBlendMode(ADD).setScale(0.3).setDepth(200);
      this.tweens.add({
        targets: sp, x: cx + Math.cos(a) * 150, y: cy + Math.sin(a) * 110, alpha: 0, duration: 560, ease: 'Cubic.easeOut',
        onComplete: (function (o) { return function () { o.destroy(); }; })(sp)
      });
    }
  }

  _toast(msg, color) {
    var w = this.scale.width;
    var t = this.add.text(w / 2, this.scale.height - 80, msg, {
      fontFamily: 'Arial, sans-serif', fontSize: '14px', fontStyle: 'bold', color: color || '#eaf2ff',
      backgroundColor: '#0a0f1e', padding: { x: 14, y: 9 }
    }).setOrigin(0.5).setDepth(500);
    this.tweens.add({ targets: t, alpha: 0, delay: 1000, duration: 400, onComplete: function () { t.destroy(); } });
  }
};
