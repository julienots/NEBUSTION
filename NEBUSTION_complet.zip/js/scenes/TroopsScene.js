/**
 * NEBUSTION - TroopsScene (Caserne)
 * Vue de ton ARMÉE : stock de chaque troupe, places utilisées / capacité (12 + 4 par niveau de Hangar).
 * L'ACHAT des troupes se fait dans la BOUTIQUE (onglet « Troupes ») : le bouton ci-dessous y mène directement.
 * Les troupes se déploient ensuite en MODE COMBAT autour d'un QG ennemi (QGBattleScene).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.TroopsScene = class TroopsScene extends Phaser.Scene {
  constructor() { super('TroopsScene'); }

  create() {
    var w = this.scale.width, T = NEBUSTION.Troops, TM = NEBUSTION.TroopManager;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(250, 5, 7, 15);
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });
    this.fx = new NEBUSTION.FX(this);

    this.add.text(w / 2, 96, 'CASERNE · MON ARMÉE', {
      fontFamily: 'Arial, sans-serif', fontSize: '24px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(50).setShadow(0, 0, '#ffd166', 10, true, true);
    var back = this.add.text(28, 126, '‹ Retour', { fontFamily: 'Arial, sans-serif', fontSize: '16px', color: '#00e5ff' })
      .setOrigin(0, 0.5).setDepth(60).setInteractive({ useHandCursor: true });
    back.on('pointerdown', () => this.scene.start('QGScene'));

    var used = TM.used(), cap = TM.capacity();
    this.add.text(w / 2, 166, 'Armée : ' + used + ' / ' + cap + ' places', {
      fontFamily: 'Arial, sans-serif', fontSize: '16px', fontStyle: 'bold', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(50);
    var bonus = [];
    if (TM.armyBonus && TM.armyBonus() > 0) bonus.push('🏕️ Casernes +' + TM.armyBonus() + ' places');
    if (TM.discount && TM.discount() > 0) bonus.push('🔧 Ateliers −' + Math.round(TM.discount() * 100) + ' % prix');
    if (bonus.length) this._bonusText = this.add.text(w / 2, 214, bonus.join('   ·   '), { fontFamily: 'Arial, sans-serif', fontSize: '12px', color: '#7dffb2' }).setOrigin(0.5).setDepth(50);
    var bw = w * 0.7, bx = (w - bw) / 2, g = this.add.graphics().setDepth(50);
    g.fillStyle(0x1b2540, 1); g.fillRoundedRect(bx, 190, bw, 10, 5);
    g.fillStyle(used >= cap ? 0xff6b6b : 0xffd166, 1); g.fillRoundedRect(bx, 190, Math.max(6, bw * Math.min(1, used / Math.max(1, cap))), 10, 5);

    // Grille compacte 2 colonnes : une carte par type de troupe
    this._cards = [];
    var cols = 2, gap = 10, cw = (w - 40 - gap) / cols, top = 226;
    // 20 types de troupes : la hauteur des cartes s'adapte pour que tout tienne (bouton boutique compris).
    var nRows = Math.ceil(T.ORDER.length / cols), ch = Math.max(60, Math.min(92, Math.floor((this.scale.height - top - 170) / nRows) - 8));
    T.ORDER.forEach((tid, i) => {
      var def = T.get(tid), n = TM.count(tid), col = i % cols, row = Math.floor(i / cols);
      var x = 20 + cw / 2 + col * (cw + gap), y = top + ch / 2 + row * (ch + 8);
      var c = this.add.container(x, y).setDepth(40).setAlpha(n > 0 ? 1 : 0.5);
      var bg = this.add.graphics();
      bg.fillStyle(def.color, n > 0 ? 0.16 : 0.06); bg.fillRoundedRect(-cw / 2, -ch / 2, cw, ch, 14);
      bg.lineStyle(1.5, def.color, n > 0 ? 0.7 : 0.3); bg.strokeRoundedRect(-cw / 2, -ch / 2, cw, ch, 14);
      c.add(bg);
      c.add(this.add.text(-cw / 2 + 32, 0, def.icon, { fontSize: '36px' }).setOrigin(0.5));
      c.add(this.add.text(-cw / 2 + 64, -26, def.name, { fontFamily: 'Arial, sans-serif', fontSize: '14px', fontStyle: 'bold', color: '#eaf2ff' }).setOrigin(0, 0.5));
      var st = TM.stats(tid);
      c.add(this.add.text(-cw / 2 + 64, -4, 'PV ' + st.hp + ' · ' + (def.blast ? 'Explosif ' + st.blast : 'DPS ' + st.dps), { fontFamily: 'Arial, sans-serif', fontSize: '11px', color: '#ffd166' }).setOrigin(0, 0.5));
      c.add(this.add.text(-cw / 2 + 64, 14, 'Niv. ' + TM.level(tid) + ' · ' + def.space + ' pl.' + (def.fly ? ' · vole' : ''), { fontFamily: 'Arial, sans-serif', fontSize: '11px', color: '#8ea0c8' }).setOrigin(0, 0.5));
      c.add(this.add.text(cw / 2 - 12, 0, '×' + n, { fontFamily: 'Arial, sans-serif', fontSize: '22px', fontStyle: 'bold', color: n > 0 ? '#eaf2ff' : '#5c6b8a' }).setOrigin(1, 0.5));
      bg.setInteractive(new Phaser.Geom.Rectangle(-cw / 2, -ch / 2, cw, ch), Phaser.Geom.Rectangle.Contains);
      bg.on('pointerdown', () => this.openUpgrade(tid));
      this._cards.push(c);
    });

    var rows = Math.ceil(T.ORDER.length / cols), by = top + rows * (ch + 8) + 44;
    var shopBtn = new NEBUSTION.Button(this, w / 2, by, {
      width: w * 0.86, height: 64, label: '🛒 ACHETER DES TROUPES (BOUTIQUE)', fontSize: '17px', accentColor: 0xffd166,
      onClick: () => this.openShop()
    });
    shopBtn.setDepth(50);
    this.add.existing(shopBtn);
    this.add.text(w / 2, by + 56, 'Visite un QG ennemi (⚔ Attaquer › VISITER) puis lance le MODE COMBAT pour déployer tes troupes.', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#5c6b8a', align: 'center', wordWrap: { width: w * 0.86 }
    }).setOrigin(0.5, 0).setDepth(50);

    this.hud = NEBUSTION.HUD ? NEBUSTION.HUD.attach(this) : null;
  }

  openUpgrade(tid) {
    var T = NEBUSTION.Troops, TM = NEBUSTION.TroopManager, def = T.get(tid);
    if (!def || !TM) return;
    if (this._upgradeModal) this._upgradeModal.destroy(true);
    var w = this.scale.width, h = this.scale.height, modal = this.add.container(0, 0).setDepth(500);
    var shade = this.add.rectangle(w / 2, h / 2, w, h, 0x02040b, 0.82).setInteractive();
    modal.add(shade);
    var panel = this.add.graphics(); panel.fillGradientStyle(0x162445, 0x0c1429, 0x0b1224, 0x050913, 0.99); panel.fillRoundedRect(18, h/2-230, w-36, 460, 24); panel.lineStyle(2, def.color, 0.85); panel.strokeRoundedRect(18, h/2-230, w-36, 460, 24); modal.add(panel);
    var title = this.add.text(w/2, h/2-192, def.icon + '  ' + def.name + '  ·  NIVEAU ' + TM.level(tid), {fontFamily:'Arial',fontSize:'20px',fontStyle:'bold',color:'#eaf2ff'}).setOrigin(0.5); modal.add(title);
    var hint = this.add.text(w/2, h/2-158, 'Choisis une branche. Chaque rang est permanent.', {fontFamily:'Arial',fontSize:'12px',color:'#8ea0c8'}).setOrigin(0.5); modal.add(hint);
    T.UPGRADE_ORDER.forEach((bid, i) => {
      var b = T.UPGRADE_BRANCHES[bid], lvl = TM.branchLevel(tid, bid), cost = TM.upgradeCost(tid, bid);
      var y = h/2 - 100 + i*92, enabled = !!cost && TM.canUpgrade(tid, bid);
      var g = this.add.graphics(); g.fillStyle(b.color, enabled ? 0.13 : 0.05); g.fillRoundedRect(38, y-34, w-76, 72, 16); g.lineStyle(1.5, b.color, enabled ? 0.8 : 0.25); g.strokeRoundedRect(38, y-34, w-76, 72, 16); modal.add(g);
      modal.add(this.add.text(56,y-14,b.icon+' '+b.name+'  '+lvl+'/'+b.max,{fontFamily:'Arial',fontSize:'15px',fontStyle:'bold',color:enabled?'#eaf2ff':'#697897'}).setOrigin(0,0.5));
      modal.add(this.add.text(56,y+10,b.desc + (cost ? '  ·  ' + this._costText(cost) : '  ·  MAX'),{fontFamily:'Arial',fontSize:'11px',color:enabled?'#8ea0c8':'#55617b',wordWrap:{width:w-150}}).setOrigin(0,0.5));
      if (enabled) {
        var btn = this.add.text(w-64,y,'AMÉLIORER',{fontFamily:'Arial',fontSize:'12px',fontStyle:'bold',color:'#ffd166',backgroundColor:'#16233f',padding:{left:8,right:8,top:7,bottom:7}}).setOrigin(1,0.5).setInteractive({useHandCursor:true});
        btn.on('pointerdown',()=>{ var r=TM.upgrade(tid,bid); if(r.ok){ this.fx.toast('Amélioration',''+def.name+' → Niv. '+r.level); this._upgradeModal.destroy(true); this._upgradeModal=null; this.scene.restart(); } else this.fx.toast('Impossible','Ressources insuffisantes.'); }); modal.add(btn);
      }
    });
    var close=this.add.text(w-38,h/2-200,'✕',{fontFamily:'Arial',fontSize:'24px',color:'#eaf2ff'}).setOrigin(0.5).setInteractive({useHandCursor:true}); close.on('pointerdown',()=>{modal.destroy(true);this._upgradeModal=null;}); modal.add(close);
    this._upgradeModal=modal;
  }

  _costText(c) { var R=NEBUSTION.Economy&&NEBUSTION.Economy.RES||{}; return Object.keys(c).map(k=>c[k]+' '+(R[k]?R[k].short:k)).join(' · '); }

  openShop() { this.scene.start('ShopScene', { tab: 'troops' }); }
};
