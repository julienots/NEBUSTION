/**
 * NEBUSTION - ShipFlightScene (module Exploration spatiale)
 * Écran de vol libre : le joueur pilote au joystick tactile le vaisseau construit au Hangar, dans un
 * monde 2D parsemé de zones spéciales (planètes, épaves, anomalies). Approcher une zone la débloque
 * (récompense en ressources versée une seule fois, via FlightZoneManager). Les héros de l'équipe de
 * combat actuelle (NEBUSTION.Combat.getTeam()) sont affichés en escorte, purement cosmétique.
 *
 * Aucune logique de jeu ici : les données viennent de NEBUSTION.FlightZones, l'état persistant de
 * NEBUSTION.FlightZoneManager (state.flightZones, couvert par la sauvegarde automatique existante).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.ShipFlightScene = class ShipFlightScene extends Phaser.Scene {
  constructor() { super('ShipFlightScene'); }

  create() {
    var w = this.scale.width, h = this.scale.height;
    var FZ = NEBUSTION.FlightZones, FZM = NEBUSTION.FlightZoneManager;
    this.W = w; this.H = h;
    this.world = FZ.WORLD;

    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(300, 5, 7, 15);
    this.cameras.main.setBounds(0, 0, this.world.w, this.world.h);

    // Sécurité : cet écran suppose un vaisseau déjà construit au Hangar (contrôlé aussi depuis PlanetScene).
    if (!FZM.hasShip()) {
      this.cameras.main.fadeOut(200, 5, 7, 15);
      this.cameras.main.once('camerafadeoutcomplete', () => this.scene.start('PlanetScene'));
      return;
    }

    this.fx = new NEBUSTION.FX(this);
    this.hud = NEBUSTION.HUD.attach(this);

    this._vel = { x: 0, y: 0 };
    this._heading = -Math.PI / 2;
    this._joyVec = { x: 0, y: 0 };
    this._zoneNodes = {};
    this._trailT = 0;

    this._buildStarfield();
    this._buildWorldDecor();
    this._buildZones();
    this._buildShip();
    this._buildHeroDock();
    this._buildTopBar();
    this._buildJoystick();

    this.cameras.main.startFollow(this.shipContainer, true, 0.12, 0.12);
    this._updateZoneLabels(true);
  }

  // =====================================================================
  // Décor
  // =====================================================================
  _buildStarfield() {
    var w = this.W, h = this.H;
    this._starsFar = this.add.tileSprite(0, 0, w, h, 'tex_starfield_far').setOrigin(0).setScrollFactor(0).setDepth(-100);
    this._starsNear = this.add.tileSprite(0, 0, w, h, 'tex_starfield_near').setOrigin(0).setAlpha(0.85).setScrollFactor(0).setDepth(-90);
  }

  _buildWorldDecor() {
    // Quelques nébuleuses statiques dans le monde, purement décoratives (profondeur négative, sous les zones).
    var G = this.add.graphics().setDepth(-60);
    var spots = [
      { x: 400, y: 500, c: 0x6c3ce9 }, { x: 2100, y: 900, c: 0x00e5ff },
      { x: 900, y: 1900, c: 0xff4d9e }, { x: 1900, y: 2000, c: 0x2e9eff }
    ];
    spots.forEach((s) => {
      G.fillStyle(s.c, 0.06);
      G.fillCircle(s.x, s.y, 420);
      G.fillStyle(s.c, 0.04);
      G.fillCircle(s.x, s.y, 620);
    });
  }

  // =====================================================================
  // Zones spéciales
  // =====================================================================
  _buildZones() {
    var FZ = NEBUSTION.FlightZones, FZM = NEBUSTION.FlightZoneManager;
    FZ.all().forEach((z) => {
      var unlocked = FZM.isUnlocked(z.id);
      var container = this.add.container(z.x, z.y).setDepth(Math.round(z.y));

      var inner = Phaser.Display.Color.HexStringToColor(z.typeDef.inner || '#8fa0c8').color;
      var atmo = Phaser.Display.Color.HexStringToColor(z.typeDef.atmo || z.typeDef.inner || '#8fa0c8').color;

      var glow = this.add.graphics();
      glow.fillStyle(atmo, unlocked ? 0.22 : 0.1);
      glow.fillCircle(0, 0, z.r * 1.8);
      container.add(glow);

      var ring = this.add.graphics();
      ring.lineStyle(2, atmo, unlocked ? 0.9 : 0.35);
      ring.strokeCircle(0, 0, z.r + 10);
      container.add(ring);

      var body = this.add.graphics();
      body.fillStyle(inner, unlocked ? 1 : 0.55);
      body.fillCircle(0, 0, z.r);
      body.lineStyle(2, atmo, 0.9);
      body.strokeCircle(0, 0, z.r);
      container.add(body);

      if (!unlocked) {
        var lock = this.add.text(0, 0, '?', {
          fontFamily: 'Arial, sans-serif', fontSize: Math.round(z.r * 0.9) + 'px', fontStyle: '900', color: 'rgba(10,16,32,0.75)'
        }).setOrigin(0.5);
        container.add(lock);
      } else {
        var check = this.add.graphics();
        check.lineStyle(3, 0x0a1020, 0.85);
        check.lineBetween(-z.r * 0.32, 0, -z.r * 0.06, z.r * 0.3);
        check.lineBetween(-z.r * 0.06, z.r * 0.3, z.r * 0.36, -z.r * 0.32);
        container.add(check);
      }

      var label = this.add.text(0, z.r + 22, z.name, {
        fontFamily: 'Arial, sans-serif', fontSize: '17px', fontStyle: 'bold', color: unlocked ? '#7dffb0' : '#8ea0c8'
      }).setOrigin(0.5).setAlpha(0);
      container.add(label);

      this.tweens.add({ targets: [glow], scale: 1.12, duration: 1600 + (z.r * 8 % 700), yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });

      this._zoneNodes[z.id] = { def: z, container: container, glow: glow, ring: ring, body: body, label: label, unlocked: unlocked };
    });
  }

  _updateZoneLabels(force) {
    var sx = this.shipContainer.x, sy = this.shipContainer.y;
    Object.keys(this._zoneNodes).forEach((id) => {
      var n = this._zoneNodes[id];
      var d = Phaser.Math.Distance.Between(sx, sy, n.container.x, n.container.y);
      var near = d < n.def.r + 320;
      var targetA = near ? 1 : 0;
      if (force || Math.abs(n.label.alpha - targetA) > 0.02) {
        this.tweens.add({ targets: n.label, alpha: targetA, duration: 220 });
      }
    });
  }

  /** Vérifie chaque frame si le vaisseau entre dans une zone non débloquée. */
  _checkZoneReach() {
    var FZM = NEBUSTION.FlightZoneManager;
    var sx = this.shipContainer.x, sy = this.shipContainer.y;
    var self = this;
    Object.keys(this._zoneNodes).forEach(function (id) {
      var n = self._zoneNodes[id];
      if (n.unlocked) return;
      var d = Phaser.Math.Distance.Between(sx, sy, n.container.x, n.container.y);
      if (d <= n.def.r + 26) self._unlockZone(id);
    });
  }

  _unlockZone(id) {
    var FZM = NEBUSTION.FlightZoneManager;
    var res = FZM.unlock(id);
    if (!res.ok) return;
    var n = this._zoneNodes[id];
    n.unlocked = true;
    n.glow.clear();
    var atmo = Phaser.Display.Color.HexStringToColor(n.def.typeDef.atmo || n.def.typeDef.inner || '#8fa0c8').color;
    n.glow.fillStyle(atmo, 0.22);
    n.glow.fillCircle(0, 0, n.def.r * 1.8);
    n.ring.clear();
    n.ring.lineStyle(2, atmo, 0.9);
    n.ring.strokeCircle(0, 0, n.def.r + 10);
    n.body.clear();
    var inner = Phaser.Display.Color.HexStringToColor(n.def.typeDef.inner || '#8fa0c8').color;
    n.body.fillStyle(inner, 1);
    n.body.fillCircle(0, 0, n.def.r);
    n.body.lineStyle(2, atmo, 0.9);
    n.body.strokeCircle(0, 0, n.def.r);
    n.label.setColor('#7dffb0');

    // Nettoie le "?" et pose le crochet de validation.
    n.container.list.slice().forEach((child) => { if (child.text === '?') child.destroy(); });
    var check = this.add.graphics();
    check.lineStyle(3, 0x0a1020, 0.85);
    check.lineBetween(-n.def.r * 0.32, 0, -n.def.r * 0.06, n.def.r * 0.3);
    check.lineBetween(-n.def.r * 0.06, n.def.r * 0.3, n.def.r * 0.36, -n.def.r * 0.32);
    n.container.add(check);

    this.fx.ring(n.container.x, n.container.y, atmo, 3.4);
    this.fx.shake(140, 0.004);
    this.fx.vibrate(30);

    var rewardTxt = Object.keys(res.reward).map((rid) => {
      var def = NEBUSTION.Economy.RES[rid];
      return '+' + res.reward[rid] + ' ' + (def ? def.short : rid);
    }).join('   ');
    this.fx.toast(n.def.name + ' débloquée !', rewardTxt || n.def.desc);

    var FZM2 = NEBUSTION.FlightZoneManager;
    this._counterText.setText(FZM2.unlockedCount() + ' / ' + FZM2.totalCount() + ' zones découvertes');
  }

  // =====================================================================
  // Vaisseau
  // =====================================================================
  _buildShip() {
    var FZ = NEBUSTION.FlightZones, SM = NEBUSTION.ShipManager, Sh = NEBUSTION.Ships;
    var fleet = SM.getFleet();
    var lead = fleet.length ? SM.get(fleet[0]) : null;
    var cls = lead ? Sh.CLASS_INDEX[lead.classId] : null;
    var rarity = lead ? Sh.RARITIES[lead.rarity] : Sh.RARITIES.commun;
    var color = rarity ? rarity.color : 0x00e5ff;

    this.shipContainer = this.add.container(FZ.START.x, FZ.START.y).setDepth(9999);

    this._thrust = this.add.particles(0, 0, 'tex_glow_cyan', {
      lifespan: { min: 200, max: 360 }, speed: { min: 40, max: 120 }, scale: { start: 0.4, end: 0 },
      alpha: { start: 0.85, end: 0 }, blendMode: 'ADD', frequency: -1
    }).setDepth(9998);

    this._shipRot = this.add.container(0, 0);
    var g = this.add.graphics();
    g.fillStyle(0x0a1020, 1);
    g.fillTriangle(0, -22, -15, 16, 15, 16);
    g.lineStyle(2.5, color, 1);
    g.strokeTriangle(0, -22, -15, 16, 15, 16);
    g.fillStyle(color, 0.9);
    g.fillTriangle(0, -22, -7, 8, 7, 8);
    g.fillStyle(0xffffff, 0.9);
    g.fillCircle(0, -8, 3);
    this._shipRot.add(g);
    this.shipContainer.add(this._shipRot);

    var nameLabel = this.add.text(0, 30, cls ? cls.name : 'Vaisseau', {
      fontFamily: 'Arial, sans-serif', fontSize: '14px', fontStyle: 'bold', color: '#eaf2ff'
    }).setOrigin(0.5).setShadow(0, 0, '#000', 4, true, true);
    this.shipContainer.add(nameLabel);
  }

  _buildHeroDock() {
    var Combat = NEBUSTION.Combat, Heroes = NEBUSTION.Heroes;
    var team = (Combat && Combat.getTeam) ? Combat.getTeam().slice(0, 3) : [];
    this._heroChips = [];
    var self = this;
    team.forEach((hid, i) => {
      var hero = Heroes.get ? Heroes.get(hid) : null;
      var key = Heroes.portraitKey(hid);
      if (!this.textures.exists(key)) return;
      var ox = (i - (team.length - 1) / 2) * 26;
      var chip = this.add.container(0, 0).setDepth(9997);
      var frame = this.add.graphics();
      frame.fillStyle(0x0a1020, 0.9);
      frame.fillCircle(0, 0, 16);
      frame.lineStyle(2, 0x00e5ff, 0.9);
      frame.strokeCircle(0, 0, 16);
      var img = this.add.image(0, 0, key).setDisplaySize(26, 26);
      var mask = this.add.graphics(); mask.fillCircle(0, 0, 13);
      img.setMask(mask.createGeometryMask());
      chip.add([frame, img]);
      this._heroChips.push({ node: chip, offsetX: ox });
    });
  }

  // =====================================================================
  // Interface (barre du haut + joystick)
  // =====================================================================
  _buildTopBar() {
    var w = this.W;
    var self = this;
    var FZM = NEBUSTION.FlightZoneManager;

    var backBtn = new NEBUSTION.Button(this, 54, 126, {
      width: 56, height: 44, accentColor: 0x8ea0c8,
      iconDraw: function (g) {
        g.lineStyle(3, 0xeaf2ff, 1);
        g.lineBetween(8, 0, -8, 0);
        g.lineBetween(-8, 0, -1, -7);
        g.lineBetween(-8, 0, -1, 7);
      },
      onClick: function () {
        self.cameras.main.fadeOut(200, 5, 7, 15);
        self.cameras.main.once('camerafadeoutcomplete', function () { self.scene.start('PlanetScene'); });
      }
    });
    backBtn.setDepth(1050).setScrollFactor(0);

    this.add.text(w / 2, 116, 'EXPLORATION SPATIALE', {
      fontFamily: 'Arial, sans-serif', fontSize: '19px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(1050).setScrollFactor(0).setShadow(0, 0, '#00e5ff', 10, true, true);

    this._counterText = this.add.text(w / 2, 144, FZM.unlockedCount() + ' / ' + FZM.totalCount() + ' zones découvertes', {
      fontFamily: 'Arial, sans-serif', fontSize: '15px', color: '#8ea0c8'
    }).setOrigin(0.5).setDepth(1050).setScrollFactor(0);
  }

  _buildJoystick() {
    var h = this.H;
    var cx = 130, cy = h - 170, radius = 78, knobR = 34;
    this._joyCenter = { x: cx, y: cy };
    this._joyRadius = radius;
    this._joyActive = false;
    this._joyPointerId = null;

    var base = this.add.graphics().setDepth(1050).setScrollFactor(0);
    base.fillStyle(0x0a1020, 0.55);
    base.fillCircle(cx, cy, radius);
    base.lineStyle(2, 0x2e9eff, 0.6);
    base.strokeCircle(cx, cy, radius);

    var knob = this.add.graphics().setDepth(1051).setScrollFactor(0);
    knob.fillStyle(0x00e5ff, 0.85);
    knob.fillCircle(0, 0, knobR);
    knob.x = cx; knob.y = cy;
    this._joyKnob = knob;

    var zone = this.add.zone(0, 0, this.W, this.H).setOrigin(0).setScrollFactor(0).setDepth(1049).setInteractive();

    var self = this;
    function updateFromPointer(p) {
      var dx = p.x - cx, dy = p.y - cy;
      var dist = Math.min(radius, Math.hypot(dx, dy));
      var ang = Math.atan2(dy, dx);
      var kx = Math.cos(ang) * dist, ky = Math.sin(ang) * dist;
      knob.x = cx + kx; knob.y = cy + ky;
      var norm = dist / radius;
      self._joyVec.x = Math.cos(ang) * norm;
      self._joyVec.y = Math.sin(ang) * norm;
    }
    function resetJoy() {
      self._joyActive = false; self._joyPointerId = null;
      knob.x = cx; knob.y = cy;
      self._joyVec.x = 0; self._joyVec.y = 0;
    }

    zone.on('pointerdown', function (p) {
      if (p.x > self.W * 0.55) return;   // moitié gauche de l'écran réservée au joystick
      self._joyActive = true; self._joyPointerId = p.id;
      updateFromPointer(p);
    });
    this.input.on('pointermove', function (p) {
      if (self._joyActive && p.id === self._joyPointerId) updateFromPointer(p);
    });
    this.input.on('pointerup', function (p) {
      if (p.id === self._joyPointerId) resetJoy();
    });
    this.input.on('pointerupoutside', function (p) {
      if (p.id === self._joyPointerId) resetJoy();
    });
  }

  // =====================================================================
  // Boucle de jeu
  // =====================================================================
  update(time, delta) {
    if (!this.shipContainer) return;
    var dt = Math.min(0.05, delta / 1000);
    var jv = this._joyVec;
    var maxSpeed = 360;
    var targetVX = jv.x * maxSpeed, targetVY = jv.y * maxSpeed;
    var accel = 7;
    this._vel.x += (targetVX - this._vel.x) * Math.min(1, accel * dt);
    this._vel.y += (targetVY - this._vel.y) * Math.min(1, accel * dt);

    var nx = Phaser.Math.Clamp(this.shipContainer.x + this._vel.x * dt, 30, this.world.w - 30);
    var ny = Phaser.Math.Clamp(this.shipContainer.y + this._vel.y * dt, 30, this.world.h - 30);
    this.shipContainer.setPosition(nx, ny);

    var moving = Math.hypot(jv.x, jv.y) > 0.08;
    if (moving) {
      var targetAngle = Math.atan2(jv.y, jv.x) + Math.PI / 2;
      this._shipRot.rotation = Phaser.Math.Angle.RotateTo(this._shipRot.rotation, targetAngle, 8 * dt);
      this._trailT -= dt;
      if (this._trailT <= 0) {
        this._trailT = 0.035;
        var back = this._shipRot.rotation - Math.PI / 2;
        var bx = nx - Math.cos(back) * 18, by = ny - Math.sin(back) * 18;
        this._thrust.emitParticleAt(bx, by, 1);
      }
    }

    this._heroChips.forEach((c, i) => {
      var back = this._shipRot.rotation - Math.PI / 2;
      c.node.x = nx - Math.cos(back) * (34) + c.offsetX * Math.cos(back + Math.PI / 2);
      c.node.y = ny - Math.sin(back) * (34) + c.offsetX * Math.sin(back + Math.PI / 2);
    });

    // Parallax du fond étoilé, ancré à la caméra.
    var cam = this.cameras.main;
    this._starsFar.tilePositionX = cam.scrollX * 0.12;
    this._starsFar.tilePositionY = cam.scrollY * 0.12;
    this._starsNear.tilePositionX = cam.scrollX * 0.3;
    this._starsNear.tilePositionY = cam.scrollY * 0.3;

    this._checkZoneReach();
    this._updateZoneLabels(false);
  }
};
