/**
 * NEBUSTION - CratesScene
 * Écran « Caisses & Clés » (ouvert depuis la Boutique, onglet 📦 Caisses) : 3 onglets —
 *   Caisses : cadeau quotidien, compteurs de pitié, les 3 paliers de caisses (ouvrir / acheter caisse / acheter clé) ;
 *   Forge   : forger des clés ou fabriquer directement le skin de son choix avec des Éclats stellaires ;
 *   Butin   : historique des dernières ouvertures.
 * Toute la logique vit dans NEBUSTION.CrateManager ; cet écran affiche et relaie les taps (même base que PrestigeScene/EventScene).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.CratesScene = class CratesScene extends NEBUSTION.ProgressScene {
  constructor() { super('CratesScene'); }

  _hubKey() { return 'crates'; }
  _titleText() { return 'CAISSES & CLÉS'; }
  _accent() { return 0xffb3f0; }
  _accentHex() { return '#ffb3f0'; }
  _defaultTab() { return 'crates'; }
  _tabDefs() { return [{ id: 'crates', label: 'Caisses' }, { id: 'forge', label: 'Forge' }, { id: 'log', label: 'Butin' }]; }

  init(data) {
    super.init(data);
    this._ovFx = [];
  }

  _badgeContent(c) {
    this._badgePill(c, 'frag', this._fmt(NEBUSTION.CrateManager.shards()), 0xffb3f0, '#ffb3f0');
  }

  /** Remplace la barre de sections par deux raccourcis : Boutique / Mes skins. */
  _buildHub() {
    var self = this, w = this.scale.width, gap = 8, cw = (w - 20 - gap) / 2;
    this.hubC.removeAll(true);
    [{ label: '← Boutique', scene: 'ShopScene', color: 0xe6c6ff }, { label: '🎨 Mes skins', scene: 'SkinsScene', color: 0xb47bff }].forEach(function (it, i) {
      var x = 10 + cw / 2 + i * (cw + gap), g = self.add.graphics();
      g.fillGradientStyle(0x101a33, 0x101a33, 0x0a1122, 0x0a1122, 0.97);
      g.fillRoundedRect(x - cw / 2, -19, cw, 38, 12);
      g.lineStyle(1.5, it.color, 0.7); g.strokeRoundedRect(x - cw / 2, -19, cw, 38, 12);
      self.hubC.add(g);
      self.hubC.add(self._txt(x, 0, it.label, 18, '#dbe5ff', { fontStyle: 'bold' }).setOrigin(0.5));
      var zone = self.add.zone(x, 0, cw, 38).setInteractive({ useHandCursor: true });
      zone.on('pointerup', function () { if (self._modal) return; self.scene.start(it.scene, {}); });
      self.hubC.add(zone);
    });
  }

  _closeModal() {
    (this._ovFx || []).forEach(function (f) { try { f.destroy(); } catch (e) { /* ignore */ } });
    this._ovFx = [];
    super._closeModal();
  }

  // ================= Utilitaires de dessin =================
  _costStr(cost) {
    var E = NEBUSTION.Economy, self = this, out = [];
    Object.keys(cost || {}).forEach(function (id) {
      if (id === 'gem') out.push(self._fmt(cost[id]) + ' Prismes');
      else out.push(self._fmt(cost[id]) + ' ' + (E.RES[id] ? E.RES[id].short : id));
    });
    return out.join(' + ');
  }

  /** Bouton à deux lignes (titre + prix). */
  _btn2(card, cx, cy, bw, bh, title, sub, accent, disabled, fn, why) {
    var self = this, b = this.add.container(cx, cy), g = this.add.graphics();
    var top = disabled ? 0x1a2233 : 0x1f2c52, bot = disabled ? 0x11172a : 0x0b1224;
    g.fillGradientStyle(top, top, bot, bot, 1);
    g.fillRoundedRect(-bw / 2, -bh / 2, bw, bh, bh * 0.28);
    g.lineStyle(2.5, accent, disabled ? 0.45 : 0.95);
    g.strokeRoundedRect(-bw / 2, -bh / 2, bw, bh, bh * 0.28);
    b.add(g);
    var t1 = this._txt(0, sub ? -10 : 0, title, 19, disabled ? '#6d7c9c' : '#eaf2ff', { fontStyle: 'bold' }).setOrigin(0.5);
    this._fitWidth(t1, bw - 14); b.add(t1);
    if (sub) { var t2 = this._txt(0, 13, sub, 13, disabled ? '#5a6788' : '#ffd166').setOrigin(0.5); this._fitWidth(t2, bw - 14); b.add(t2); }
    card.add(b);
    var handler = disabled ? (why ? function () { self.fx.toast(why, null, null); } : null) : fn;
    if (handler) card._hits.push({ x: cx - bw / 2, y: cy - bh / 2, w: bw, h: bh, fn: handler, btn: b });
    return b;
  }

  _drawKey(g, x, y, s, color) {
    g.fillStyle(color, 1);
    g.fillCircle(x - s * 0.28, y, s * 0.2);
    g.fillStyle(0x0a1122, 1); g.fillCircle(x - s * 0.28, y, s * 0.08);
    g.fillStyle(color, 1);
    g.fillRoundedRect(x - s * 0.1, y - s * 0.05, s * 0.5, s * 0.1, s * 0.03);
    g.fillRect(x + s * 0.22, y, s * 0.07, s * 0.17);
    g.fillRect(x + s * 0.34, y, s * 0.07, s * 0.12);
    g.lineStyle(1.5, 0xffffff, 0.55); g.strokeCircle(x - s * 0.28, y, s * 0.2);
  }

  /** Caisse stylisée (corps métallique, couvercle, sangles, serrure lumineuse), centrée en (x, y), largeur ≈ s. */
  _drawCrate(parent, x, y, s, d) {
    var ADD = Phaser.BlendModes.ADD, c = this.add.container(x, y);
    var glow = this._image(0, 0, 'tex_glow_white');
    if (glow) { glow.setDisplaySize(s * 1.9, s * 1.6).setTint(d.color).setBlendMode(ADD).setAlpha(0.45); c.add(glow); this._loop({ targets: glow, alpha: 0.2, duration: 1200, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' }); }
    var shadow = this.add.ellipse(0, s * 0.42, s * 0.95, s * 0.16, 0x000000, 0.4); c.add(shadow);
    var g = this.add.graphics(); c.add(g);
    var bw = s, bh = s * 0.62, top = -s * 0.22, dark = this._mix(d.color2, 0x000000, 0.55), mid = d.color2, hi = this._mix(d.color, 0xffffff, 0.5);
    // corps
    g.fillGradientStyle(mid, mid, dark, dark, 1); g.fillRoundedRect(-bw / 2, top, bw, bh, 10);
    g.lineStyle(3, d.color, 0.95); g.strokeRoundedRect(-bw / 2, top, bw, bh, 10);
    // sangles verticales
    g.fillStyle(this._mix(d.color, 0x000000, 0.35), 1);
    g.fillRect(-bw * 0.32, top, bw * 0.1, bh); g.fillRect(bw * 0.22, top, bw * 0.1, bh);
    g.fillStyle(0xffffff, 0.12); g.fillRect(-bw * 0.32, top, bw * 0.03, bh); g.fillRect(bw * 0.22, top, bw * 0.03, bh);
    // rivets
    g.fillStyle(hi, 0.9);
    [[-0.42, 0.12], [0.42, 0.12], [-0.42, 0.52], [0.42, 0.52]].forEach(function (p) { g.fillCircle(p[0] * bw, top + p[1] * bh, s * 0.018); });
    // couvercle bombé
    var lidH = s * 0.3, lidY = top - lidH * 0.72;
    g.fillGradientStyle(this._mix(d.color2, 0xffffff, 0.75), this._mix(d.color2, 0xffffff, 0.75), mid, mid, 1);
    g.fillRoundedRect(-bw / 2 - 5, lidY, bw + 10, lidH, { tl: 16, tr: 16, bl: 6, br: 6 });
    g.lineStyle(3, d.color, 1); g.strokeRoundedRect(-bw / 2 - 5, lidY, bw + 10, lidH, { tl: 16, tr: 16, bl: 6, br: 6 });
    g.fillStyle(0xffffff, 0.22); g.fillRoundedRect(-bw * 0.4, lidY + 5, bw * 0.55, lidH * 0.18, 4);
    // liseré lumineux entre couvercle et corps
    g.fillStyle(d.color, 0.95); g.fillRect(-bw / 2 - 2, top - 3, bw + 4, 6);
    var seam = this.add.rectangle(0, top, bw + 4, 8, d.color, 0.6).setBlendMode(ADD); c.add(seam);
    this._loop({ targets: seam, alpha: 0.15, duration: 900, yoyo: true, repeat: -1 });
    // serrure
    var lk = this.add.graphics(); c.add(lk);
    lk.fillStyle(0x0a1122, 1); lk.fillRoundedRect(-s * 0.09, top - s * 0.05, s * 0.18, s * 0.22, 6);
    lk.lineStyle(3, d.color, 1); lk.strokeRoundedRect(-s * 0.09, top - s * 0.05, s * 0.18, s * 0.22, 6);
    lk.fillStyle(d.color, 1); lk.fillCircle(0, top + s * 0.035, s * 0.032); lk.fillRect(-s * 0.012, top + s * 0.035, s * 0.024, s * 0.07);
    parent.add(c);
    return c;
  }

  _rarityHex(r) { return NEBUSTION.Skins.RARITIES[r].hex; }
  _rarityColor(r) { return NEBUSTION.Skins.RARITIES[r].color; }

  // ================= Rendu des onglets =================
  _renderTab(w) {
    if (this.tab === 'forge') return this._renderForge(w);
    if (this.tab === 'log') return this._renderLog(w);
    return this._renderCrates(w);
  }

  // ---------- Onglet Caisses ----------
  _renderCrates(w) {
    var self = this, CM = NEBUSTION.CrateManager, K = NEBUSTION.Crates, cards = [];

    // Cadeau quotidien
    var avail = CM.dailyAvailable(Date.now()), gift = K.DAILY_GIFT;
    var gc = this._card(118, 0x5fd97a, { glow: avail });
    gc.add(this._txt(24, 20, 'Cadeau quotidien', 22, '#eaf2ff', { fontStyle: 'bold' }));
    gc.add(this._txt(24, 54, '1 Caisse Astrale + 1 Clé Astrale, chaque jour.', 16, '#a9b8dc', { wordWrap: { width: gc._cw - 250 } }));
    this._btn(gc, gc._cw - 116, 60, 200, 56, avail ? 'RÉCLAMER' : 'Demain', 0x5fd97a, !avail, function () {
      var r = CM.claimDaily(Date.now());
      if (r.ok) { self.fx.toast('Cadeau reçu !', '+1 Caisse Astrale · +1 Clé Astrale', null); self._refreshAll(false); }
    }, 'Déjà réclamé aujourd\'hui');
    cards.push(gc);

    // Pitié
    var p = CM.pity(), pc = this._card(146, 0xffd166);
    pc.add(this._txt(24, 16, 'Garanties (pitié)', 20, '#eaf2ff', { fontStyle: 'bold' }));
    pc.add(this._txt(pc._cw - 24, 20, CM.opened() + ' ouvertures', 14, '#8e9cc0').setOrigin(1, 0));
    var epicLeft = K.PITY.epic - p.epic, legLeft = K.PITY.leg - p.leg;
    pc.add(this._txt(24, 50, 'Épique garanti dans ' + epicLeft + ' ouverture' + (epicLeft > 1 ? 's' : ''), 15, this._rarityHex('epique'), { fontStyle: 'bold' }));
    this._bar(pc, 24, 74, pc._cw - 48, 14, p.epic / K.PITY.epic, this._rarityColor('epique'));
    pc.add(this._txt(24, 96, 'Légendaire garanti dans ' + legLeft + ' ouverture' + (legLeft > 1 ? 's' : ''), 15, this._rarityHex('legendaire'), { fontStyle: 'bold' }));
    this._bar(pc, 24, 120, pc._cw - 48, 14, p.leg / K.PITY.leg, this._rarityColor('legendaire'));
    cards.push(pc);

    K.TIERS.forEach(function (tier) { cards.push(self._crateCard(tier)); });

    var note = this._txt(this.scale.width / 2, 8, 'Butin : caisses de ravitaillement, victoires en combat, cadeau quotidien, boutique.\nLes doublons de skins sont recyclés en Éclats.', 14, '#7a89ad', { align: 'center', wordWrap: { width: w - 60 } }).setOrigin(0.5, 0);
    var foot = this.add.container(0, 0, [note]);
    return { cards: cards, footer: foot, footerH: 70 };
  }

  _crateCard(tier) {
    var self = this, CM = NEBUSTION.CrateManager, K = NEBUSTION.Crates, d = K.CRATES[tier];
    var nC = CM.crates(tier), nK = CM.keys(tier), can = nC > 0 && nK > 0;
    var card = this._card(352, d.color, { glow: can });
    var cw = card._cw, rx = 210, rw = cw - rx - 20;

    var holder = this.add.container(100, 150); card.add(holder);
    this._drawCrate(holder, 0, 0, 132, d);
    this._loop({ targets: holder, y: 158, duration: 1700, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });

    card.add(this._txt(rx, 20, d.name, 26, d.hex, { fontStyle: 'bold' }));
    card.add(this._txt(rx, 56, d.desc, 15, '#a9b8dc', { wordWrap: { width: rw } }));
    var cx = rx, cy = 122;
    K.chances(tier).forEach(function (o) {
      var R = NEBUSTION.Skins.RARITIES[o.rarity];
      cx += self._chip(card, cx, cy, R.name + ' ' + o.pct + '%', R.color, 13) + 6;
    });

    card.add(this._txt(rx, 166, '📦 Caisses : ' + nC, 21, nC > 0 ? '#eaf2ff' : '#6d7c9c', { fontStyle: 'bold' }));
    card.add(this._txt(rx + 210, 166, '🗝️ Clés : ' + nK, 21, nK > 0 ? '#eaf2ff' : '#6d7c9c', { fontStyle: 'bold' }));

    var why = nC <= 0 ? 'Il te faut une caisse' : 'Il te faut une clé';
    this._btn(card, rx + rw / 2, 236, rw, 62, 'OUVRIR', d.color, !can, function () { self._open(tier); }, why);

    var half = (rw - 10) / 2;
    this._btn2(card, rx + half / 2, 306, half, 58, 'Acheter caisse', this._costStr(d.crateCost), d.color, !CM.canPay(d.crateCost), function () { self._buy('crate', tier); }, 'Ressources insuffisantes');
    this._btn2(card, rx + half + 10 + half / 2, 306, half, 58, 'Acheter clé', this._costStr(d.keyCost), d.color, !CM.canPay(d.keyCost), function () { self._buy('key', tier); }, 'Ressources insuffisantes');
    return card;
  }

  _buy(kind, tier) {
    var CM = NEBUSTION.CrateManager, d = NEBUSTION.Crates.CRATES[tier];
    var r = kind === 'crate' ? CM.buyCrate(tier) : CM.buyKey(tier);
    if (r.ok) {
      this.fx.toast(kind === 'crate' ? d.name + ' achetée' : d.keyName + ' achetée', this._costStr(r.cost), null);
      this._refreshAll(false);
    } else this.fx.toast(r.reason === 'plein' ? 'Stock plein' : 'Ressources insuffisantes', null, null);
  }

  // ---------- Onglet Forge ----------
  _renderForge(w) {
    var self = this, CM = NEBUSTION.CrateManager, K = NEBUSTION.Crates, cards = [];

    var head = this._card(96, 0xffb3f0);
    head.add(this._txt(24, 16, 'Forge d\'Éclats', 24, '#eaf2ff', { fontStyle: 'bold' }));
    head.add(this._txt(24, 54, 'Éclats : ' + this._fmt(CM.shards()) + '  ·  gagnés à chaque ouverture et avec les doublons', 15, '#ffb3f0', { wordWrap: { width: head._cw - 48 } }));
    cards.push(head);

    var kc = this._card(66 + K.TIERS.length * 72, 0xffd166);
    kc.add(this._txt(24, 16, 'Forger une clé', 21, '#eaf2ff', { fontStyle: 'bold' }));
    K.TIERS.forEach(function (tier, i) {
      var d = K.CRATES[tier], y = 92 + i * 72, kg = self.add.graphics();
      self._drawKey(kg, 46, y, 46, d.color); kc.add(kg);
      kc.add(self._txt(84, y - 14, d.keyName, 19, d.hex, { fontStyle: 'bold' }));
      kc.add(self._txt(84, y + 8, 'En stock : ' + CM.keys(tier), 14, '#8e9cc0'));
      self._btn2(kc, kc._cw - 120, y, 200, 56, 'FORGER', d.keyShards + ' Éclats', d.color, CM.shards() < d.keyShards, function () {
        var r = CM.forgeKey(tier);
        if (r.ok) { self.fx.toast(d.keyName + ' forgée', '−' + r.cost + ' Éclats', null); self._refreshAll(false); }
      }, 'Pas assez d\'Éclats');
    });
    cards.push(kc);

    var list = CM.forgeList();
    var hc = this._card(64, 0xb47bff, { dim: true });
    hc.add(this._txt(24, 18, list.length ? 'Fabriquer un skin précis (' + list.length + ' disponibles)' : 'Toute la collection est possédée !', 19, '#eaf2ff', { fontStyle: 'bold' }));
    cards.push(hc);
    list.forEach(function (s) { cards.push(self._forgeSkinCard(s)); });
    return { cards: cards, footer: null };
  }

  _forgeSkinCard(s) {
    var self = this, CM = NEBUSTION.CrateManager, K = NEBUSTION.Crates, SK = NEBUSTION.Skins;
    var R = SK.RARITIES[s.rarity], cost = K.forgeSkinCost(s.id), can = CM.shards() >= cost;
    var card = this._card(104, R.color, { dim: !can });
    card.add(this._image(52, 52, 'tex_glow_white').setDisplaySize(92, 92).setTint(s.aura).setBlendMode(Phaser.BlendModes.ADD).setAlpha(0.85));
    var ic = this.add.graphics();
    ic.fillStyle(0x000000, 0.35); ic.fillCircle(52, 52, 22); ic.lineStyle(2, R.color, 0.9); ic.strokeCircle(52, 52, 22);
    ic.fillStyle(s.hull, 1); ic.fillCircle(52, 52, 15); ic.lineStyle(3, s.aura, 1); ic.strokeCircle(52, 52, 15);
    ic.fillStyle(s.aura2 !== undefined ? s.aura2 : s.aura, 1); ic.fillCircle(52, 52, 6);
    card.add(ic);
    card.add(this._txt(100, 22, s.name, 21, R.hex, { fontStyle: 'bold' }));
    card.add(this._txt(100, 52, R.name + ' · ' + SK.TARGET_NAMES[s.target] + ' · ' + SK.FX[s.fx], 14, '#8e9cc0', { wordWrap: { width: card._cw - 300 } }));
    if (s.crate) card.add(this._txt(100, 74, '📦 Exclusif aux Caisses', 13, '#ffb3f0'));
    this._btn2(card, card._cw - 100, 52, 168, 58, 'FORGER', cost + ' Éclats', R.color, !can, function () {
      self._confirm('Forger « ' + s.name + ' » ?', [s.desc, 'Coût : ' + cost + ' Éclats (il t\'en reste ' + (CM.shards() - cost) + ').'], 'Forger', function () {
        var r = CM.forgeSkin(s.id);
        if (r.ok) { self.fx.toast('Skin forgé : ' + s.name, 'Équipe-le dans Mes skins', null); try { self.fx.ring(self.scale.width / 2, 400, s.aura, 1.6); } catch (e) { /* ignore */ } self._refreshAll(false); }
        else self.fx.toast('Forge impossible', null, null);
      }, { accent: R.color });
    }, 'Pas assez d\'Éclats');
    return card;
  }

  // ---------- Onglet Butin ----------
  _renderLog(w) {
    var self = this, CM = NEBUSTION.CrateManager, K = NEBUSTION.Crates, hist = CM.history(), cards = [];
    var head = this._card(96, 0xffb3f0);
    head.add(this._txt(24, 16, 'Historique', 24, '#eaf2ff', { fontStyle: 'bold' }));
    head.add(this._txt(24, 54, CM.opened() + ' caisses ouvertes au total · ' + CM.totalCrates() + ' en stock · ' + CM.totalKeys() + ' clés', 15, '#a9b8dc', { wordWrap: { width: head._cw - 48 } }));
    cards.push(head);
    if (!hist.length) {
      var e = this._card(110, 0x394869, { dim: true });
      e.add(this._txt(e._cw / 2, 55, 'Aucune ouverture pour l\'instant.', 18, '#8e9cc0').setOrigin(0.5));
      cards.push(e);
      return { cards: cards, footer: null };
    }
    var lc = this._card(30 + hist.length * 44, 0x4fd1ff);
    hist.forEach(function (h, i) {
      var y = 26 + i * 44, R = NEBUSTION.Skins.RARITIES[h.rarity], d = K.CRATES[h.tier];
      var dot = self.add.graphics(); dot.fillStyle(R.color, 1); dot.fillCircle(30, y + 12, 8); lc.add(dot);
      var t = self._txt(50, y, h.label || '—', 17, R.hex, { fontStyle: 'bold' }); self._fitWidth(t, lc._cw - 250); lc.add(t);
      lc.add(self._txt(50, y + 21, d.name + (h.dup ? ' · doublon' : ''), 12, '#7a89ad'));
      lc.add(self._txt(lc._cw - 22, y + 4, R.name, 14, R.hex).setOrigin(1, 0));
    });
    cards.push(lc);
    return { cards: cards, footer: null };
  }

  // ================= Ouverture =================
  _open(tier) {
    var CM = NEBUSTION.CrateManager;
    var res = CM.open(tier);
    if (!res.ok) { this.fx.toast(res.reason === 'cle' ? 'Il te faut une clé' : 'Il te faut une caisse', null, null); return; }
    this._refreshAll(false);
    this._playOpen(tier, res);
  }

  _ovBtn(parent, x, y, bw, bh, label, accent, disabled, fn) {
    var b = this.add.container(x, y), g = this.add.graphics();
    var top = disabled ? 0x1a2233 : 0x1f2c52, bot = disabled ? 0x11172a : 0x0b1224;
    g.fillGradientStyle(top, top, bot, bot, 1);
    g.fillRoundedRect(-bw / 2, -bh / 2, bw, bh, 18);
    g.lineStyle(2.5, accent, disabled ? 0.45 : 0.95); g.strokeRoundedRect(-bw / 2, -bh / 2, bw, bh, 18);
    b.add(g);
    var t = this._txt(0, 0, label, 21, disabled ? '#6d7c9c' : '#eaf2ff', { fontStyle: 'bold' }).setOrigin(0.5);
    this._fitWidth(t, bw - 16); b.add(t);
    parent.add(b);
    if (!disabled) {
      var z = this.add.zone(x, y, bw, bh).setInteractive({ useHandCursor: true });
      z.on('pointerup', fn);
      parent.add(z);
    }
    return b;
  }

  _playOpen(tier, res) {
    var self = this, w = this.scale.width, h = this.scale.height, d = NEBUSTION.Crates.CRATES[tier], ADD = Phaser.BlendModes.ADD;
    var R = NEBUSTION.Skins.RARITIES[res.reward.rarity];
    var ov = this.add.container(0, 0).setDepth(1150);
    var dim = this.add.rectangle(0, 0, w, h, 0x000000, 0.88).setOrigin(0).setInteractive();
    ov.add(dim);
    var cy = h / 2 - 80;
    var aura = this._image(w / 2, cy, 'tex_glow_white');
    if (aura) { aura.setDisplaySize(w * 1.3, w * 1.3).setTint(d.color).setBlendMode(ADD).setAlpha(0); ov.add(aura); }
    var crateBox = this.add.container(w / 2, cy).setScale(0.2); ov.add(crateBox);
    this._drawCrate(crateBox, 0, 0, 200, d);
    this._modal = { overlay: ov, dim: dim, hits: [], busy: true, panel: crateBox };

    var key = this.add.graphics(); this._drawKey(key, 0, 0, 74, d.color);
    key.setPosition(w / 2 + 170, cy + 210).setAlpha(0).setRotation(-0.6); ov.add(key);

    this.tweens.add({ targets: crateBox, scale: 1, duration: 380, ease: 'Back.easeOut' });
    if (aura) this.tweens.add({ targets: aura, alpha: 0.5, duration: 500 });
    this.tweens.add({ targets: key, alpha: 1, x: w / 2 + 6, y: cy - 60, rotation: 0, duration: 520, delay: 380, ease: 'Cubic.easeInOut' });
    this.time.delayedCall(900, function () {
      if (!self._modal || self._modal.overlay !== ov) return;
      try { self.fx.vibrate(30); } catch (e) { /* ignore */ }
      self.tweens.add({ targets: key, alpha: 0, scale: 0.6, duration: 160 });
      self.tweens.add({ targets: crateBox, angle: { from: -7, to: 7 }, duration: 55, yoyo: true, repeat: 9, ease: 'Sine.easeInOut',
        onComplete: function () { crateBox.angle = 0; } });
      if (aura) self.tweens.add({ targets: aura, alpha: 0.95, scaleX: aura.scaleX * 1.25, scaleY: aura.scaleY * 1.25, duration: 620 });
    });
    this.time.delayedCall(1650, function () {
      if (!self._modal || self._modal.overlay !== ov) return;
      var flash = self.add.rectangle(0, 0, w, h, R.color, 0.85).setOrigin(0); ov.add(flash);
      self.tweens.add({ targets: flash, alpha: 0, duration: 520, onComplete: function () { flash.destroy(); } });
      try { self.fx.ring(w / 2, cy, R.color, 2.6); self.fx.shake(220, 0.006); self.fx.vibrate(60); } catch (e) { /* ignore */ }
      self.tweens.add({ targets: crateBox, scale: 2, alpha: 0, duration: 260, ease: 'Cubic.easeOut' });
      if (aura) { aura.setTint(R.color); self.tweens.add({ targets: aura, alpha: 0.35, duration: 500 }); }
      self._showReward(ov, res, tier, aura);
    });
  }

  _heroForPreview() {
    var H = NEBUSTION.Heroes, C = NEBUSTION.Combat, all = H.all();
    for (var i = 0; i < all.length; i++) if (!C || C.isUnlocked(all[i].id)) return all[i];
    return all[0];
  }

  _showReward(ov, res, tier, aura) {
    var self = this, w = this.scale.width, h = this.scale.height, rw = res.reward, K = NEBUSTION.Crates, SK = NEBUSTION.Skins;
    var R = SK.RARITIES[rw.rarity], d = K.CRATES[tier];
    var pw = w - 56, ph = 620, cx = w / 2, cyp = h / 2 - 20;
    var panel = this.add.container(cx, cyp).setScale(0.6).setAlpha(0); ov.add(panel);
    var bg = this.add.graphics();
    bg.fillGradientStyle(0x1a2247, 0x1a2247, 0x0b1224, 0x0b1224, 0.99);
    bg.fillRoundedRect(-pw / 2, -ph / 2, pw, ph, 26);
    bg.lineStyle(4, R.color, 1); bg.strokeRoundedRect(-pw / 2, -ph / 2, pw, ph, 26);
    bg.fillStyle(R.color, 0.9); bg.fillRoundedRect(-pw / 2 + 30, -ph / 2, pw - 60, 5, 2);
    panel.add(bg);
    var glow = this._image(0, -70, 'tex_glow_white');
    if (glow) { glow.setDisplaySize(pw * 0.9, 340).setTint(R.color).setBlendMode(Phaser.BlendModes.ADD).setAlpha(0.28); panel.add(glow); }

    panel.add(this._txt(0, -ph / 2 + 36, R.name.toUpperCase(), 32, R.hex, { fontStyle: '900' }).setOrigin(0.5).setShadow(0, 0, R.hex, 14, true, true));
    panel.add(this._txt(0, -ph / 2 + 74, d.name, 16, '#8e9cc0').setOrigin(0.5));

    // --- Aperçu selon le type de récompense ---
    var py = -70;
    if (rw.kind === 'skin' && rw.skin) {
      var sk = rw.skin, fxh = null;
      if (sk.target === 'hero') {
        var hero = this._heroForPreview(), key = NEBUSTION.Heroes.portraitKey(hero.id);
        if (this.textures.exists(key)) {
          var img = this.add.image(0, py, key).setDisplaySize(140, 178); panel.add(img);
          fxh = NEBUSTION.SkinFX.attach(this, panel, img, sk, 140, 178);
        }
      } else if (sk.target === 'ship') {
        var ship = NEBUSTION.SkinFX.drawShip(this, 'corvette', sk, 150); ship.setPosition(0, py); panel.add(ship);
        fxh = NEBUSTION.SkinFX.attach(this, panel, ship, sk, 170, 180);
      } else {
        var bld = NEBUSTION.SkinFX.drawBuilding(this, 'command', sk, 130); bld.setPosition(0, py + 60); panel.add(bld);
        fxh = NEBUSTION.SkinFX.attach(this, panel, bld, sk, 190, 190, { x: 0, y: py });
      }
      if (fxh) this._ovFx.push(fxh);
    } else if (rw.kind === 'fragments' && rw.hero) {
      var hk = NEBUSTION.Heroes.portraitKey(rw.hero.id);
      if (this.textures.exists(hk)) panel.add(this.add.image(0, py, hk).setDisplaySize(140, 178));
    } else if (rw.kind === 'gems') {
      this._iconNode(panel, 'gem', 0, py, 130);
    } else if (rw.kind === 'resources' && rw.bundle) {
      rw.bundle.forEach(function (b, i) {
        var yy = py - 66 + i * 40;
        self._iconNode(panel, b.id, -pw / 2 + 120, yy, 32);
        var E = NEBUSTION.Economy.RES[b.id];
        panel.add(self._txt(-pw / 2 + 156, yy, '+' + self._fmt(b.requested) + ' ' + (E ? E.short : b.id), 22, E ? E.hex : '#ffe9a3', { fontStyle: 'bold' }).setOrigin(0, 0.5));
      });
    } else {
      panel.add(this._txt(0, py, '🛠️', 96).setOrigin(0.5));
    }

    var ty = 66;
    var name = this._txt(0, ty, rw.label || '', 27, '#ffffff', { fontStyle: 'bold', align: 'center', wordWrap: { width: pw - 60 } }).setOrigin(0.5, 0);
    panel.add(name);
    panel.add(this._txt(0, ty + (name.height || 34) + 6, rw.detail || '', 16, '#a9b8dc', { align: 'center', wordWrap: { width: pw - 60 } }).setOrigin(0.5, 0));
    var sy = 190;
    if (rw.kind === 'skin') {
      if (rw.dup) panel.add(this._txt(0, sy, 'Doublon → recyclé en +' + rw.dupShards + ' Éclats', 20, '#ffb347', { fontStyle: 'bold' }).setOrigin(0.5));
      else panel.add(this._txt(0, sy, '✨ NOUVEAU SKIN !  Équipe-le dans « Mes skins »', 19, '#5fd97a', { fontStyle: 'bold' }).setOrigin(0.5));
    }
    panel.add(this._txt(0, sy + 40, '+' + res.bonusShards + ' Éclats stellaires', 19, '#ffb3f0', { fontStyle: 'bold' }).setOrigin(0.5));
    if (res.pityTriggered) panel.add(this._txt(0, sy + 72, '★ Garantie de pitié déclenchée !', 17, '#ffd166', { fontStyle: 'bold' }).setOrigin(0.5));

    // --- Boutons ---
    var CM = NEBUSTION.CrateManager, again = CM.canOpen(tier), by = ph / 2 - 52, bw = (pw - 60) / 2;
    this._ovBtn(panel, -bw / 2 - 8, by, bw, 60, again ? 'Ouvrir encore' : 'Plus de clé/caisse', d.color, !again, function () {
      if (!self._modal || self._modal.overlay !== ov) return;
      self._closeModal();
      self.time.delayedCall(160, function () { self._open(tier); });
    });
    this._ovBtn(panel, bw / 2 + 8, by, bw, 60, 'Fermer', 0x394869, false, function () { self._closeModal(); self._refreshAll(false); });
    this._modal.busy = false;

    this.tweens.add({ targets: panel, scale: 1, alpha: 1, duration: 320, ease: 'Back.easeOut' });
    if (glow) this._loop({ targets: glow, alpha: 0.12, duration: 1100, yoyo: true, repeat: -1 });
  }
};
