/**
 * NEBUSTION - SplashScene
 * Écran de lancement animé : fond spatial + logo qui apparaît avec un effet
 * d'énergie, puis transition automatique (ou au tap) vers le menu principal.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.SplashScene = class SplashScene extends Phaser.Scene {
  constructor() {
    super('SplashScene');
  }

  create() {
    var w = this.scale.width, h = this.scale.height;
    this.cameras.main.setBackgroundColor('#05070f');
    this._transitioning = false;

    // Lance la musique d'introduction dès l'écran de lancement.
    // Si le navigateur bloque l'autoplay, ExtraUIAudio la relance au premier toucher.
    try { if (window.nebustionExtraAudio) window.nebustionExtraAudio.startIntro(); } catch (_) {}

    // --- Fond spatial simple pour le splash ---
    this.add.tileSprite(0, 0, w, h, 'tex_starfield_far').setOrigin(0).setAlpha(0.8);

    var nebula = this.add.image(w * 0.5, h * 0.4, 'tex_nebula_purple').setAlpha(0.35).setBlendMode(Phaser.BlendModes.ADD);
    this.tweens.add({ targets: nebula, alpha: 0.5, duration: 3000, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });

    // Particules d'énergie ambiantes autour du logo (effet "ignition")
    this.add.particles(w / 2, h * 0.42, 'tex_glow_cyan', {
      speed: { min: 20, max: 70 },
      scale: { start: 0.5, end: 0 },
      alpha: { start: 0.8, end: 0 },
      lifespan: 1400,
      blendMode: 'ADD',
      emitZone: {
        type: 'edge',
        source: new Phaser.Geom.Circle(0, 0, 180),
        quantity: 48
      },
      frequency: 60
    });

    // --- Logo ---
    var logoContainer = this.add.container(w / 2, h * 0.42).setScale(0.3).setAlpha(0);

    var glow = this.add.text(0, 0, 'NEBUSTION', {
      fontFamily: 'Arial, sans-serif',
      fontSize: '58px',
      fontStyle: '900',
      color: '#00e5ff'
    }).setOrigin(0.5).setAlpha(0.6);
    glow.setShadow(0, 0, '#00e5ff', 30, true, true);

    var main = this.add.text(0, 0, 'NEBUSTION', {
      fontFamily: 'Arial, sans-serif',
      fontSize: '56px',
      fontStyle: '900',
      color: '#f4f9ff'
    }).setOrigin(0.5);

    var sub = this.add.text(0, 42, '— H U N T   T H E   V O I D —', {
      fontFamily: 'Arial, sans-serif',
      fontSize: '14px',
      color: '#6c3ce9',
      letterSpacing: 2
    }).setOrigin(0.5).setAlpha(0);

    logoContainer.add([glow, main, sub]);

    this.tweens.add({
      targets: logoContainer,
      scale: 1,
      alpha: 1,
      duration: 900,
      ease: 'Back.easeOut',
      onComplete: () => {
        this.tweens.add({ targets: sub, alpha: 1, duration: 500 });
        this.tweens.add({
          targets: glow,
          alpha: 0.25,
          duration: 1000,
          yoyo: true,
          repeat: -1,
          ease: 'Sine.easeInOut'
        });
      }
    });

    var hint = this.add.text(w / 2, h * 0.82, 'Toucher l\'écran pour continuer', {
      fontFamily: 'Arial, sans-serif',
      fontSize: '15px',
      color: '#7a89ad'
    }).setOrigin(0.5).setAlpha(0);

    this.tweens.add({ targets: hint, alpha: 1, duration: 600, delay: 1200 });
    this.tweens.add({ targets: hint, alpha: 0.4, duration: 800, delay: 1800, yoyo: true, repeat: -1 });

    // L'intro est lancée automatiquement à l'ouverture du splash.
    this.time.delayedCall(3200, () => this._goToMenu());
  }

  _goToMenu() {
    if (this._transitioning) return;
    // On NE coupe plus l'intro ici : elle continue de jouer dans le menu,
    // elle ne s'arrête qu'en entrant vraiment en jeu (voir PlanetScene).
    this._transitioning = true;
    this.cameras.main.fadeOut(400, 5, 7, 15);
    this.cameras.main.once('camerafadeoutcomplete', () => {
      this.scene.start('MainMenuScene');
    });
  }
};
