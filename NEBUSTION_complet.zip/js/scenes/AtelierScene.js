/**
 * NEBUSTION - AtelierScene
 * Écran « Mode Atelier », accessible uniquement une fois déverrouillé par le compte local
 * Admin / Admin (voir js/data/AdminMode.js et AccountScene). Regroupe l'accès aux outils de
 * création du jeu, qui restent de simples pages HTML autonomes dans tools/ (aucune dépendance
 * à Phaser) : l'Atelier de cartes, le Studio (héros/ennemis/équilibrage) et l'import de contenu.
 *
 * Ces outils s'ouvrent dans un nouvel onglet/fenêtre du navigateur (window.open). Dans une
 * installation en APK (voir TUTORIEL_APK_GITHUB.md), selon la configuration de la WebView,
 * l'ouverture peut se faire dans le navigateur du téléphone plutôt que dans l'app — c'est
 * normal, les fichiers .nebustion-card.json produits restent utilisables de la même façon.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.AtelierScene = class AtelierScene extends Phaser.Scene {
  constructor() { super('AtelierScene'); }

  init(data) {
    this.returnTo = (data && data.returnTo) || 'MainMenuScene';
  }

  create() {
    var self = this, w = this.scale.width, h = this.scale.height;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(250, 5, 7, 15);
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });
    this.fx = new NEBUSTION.FX(this);

    // Garde-fou : si le mode n'est plus actif (désactivé entre-temps depuis un autre écran),
    // on ne laisse jamais cet écran accessible affiché par erreur.
    if (!NEBUSTION.AdminMode || !NEBUSTION.AdminMode.isActive()) {
      this.scene.start(this.returnTo);
      return;
    }

    this.add.text(w / 2, 128, '🛠 MODE ATELIER', {
      fontFamily: 'Arial, sans-serif', fontSize: '26px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(50).setShadow(0, 0, '#7dffb0', 12, true, true);

    this.add.text(w / 2, 164, 'Outils de création — compte Admin', {
      fontFamily: 'Arial, sans-serif', fontSize: '15px', color: '#8e9cc0'
    }).setOrigin(0.5).setDepth(50);

    var tools = [
      { icon: '🃏', title: 'Atelier de cartes', desc: 'Créer une carte (Boutique) sans coder.', url: 'tools/atelier_cartes.html' },
      { icon: '🧪', title: 'Studio', desc: 'Héros, ennemis, équipement et équilibrage.', url: 'tools/studio.html' },
      { icon: '📥', title: 'Import de contenu', desc: 'Intégrer les fichiers créés dans le jeu.', url: 'tools/import.html' }
    ];

    var cardY = 250, cardH = 128, gap = 18;
    tools.forEach(function (t, i) {
      var y = cardY + i * (cardH + gap);
      var card = self.add.container(w / 2, y).setDepth(50);
      var bg = self.add.graphics();
      bg.fillGradientStyle(0x111b36, 0x111b36, 0x090f20, 0x090f20, 0.98);
      bg.fillRoundedRect(-(w - 80) / 2, -cardH / 2, w - 80, cardH, 16);
      bg.lineStyle(2, 0x00e5ff, 0.35);
      bg.strokeRoundedRect(-(w - 80) / 2, -cardH / 2, w - 80, cardH, 16);
      card.add(bg);
      card.add(self.add.text(-(w - 80) / 2 + 20, -cardH / 2 + 18, t.icon, { fontSize: '30px' }).setOrigin(0, 0));
      card.add(self.add.text(-(w - 80) / 2 + 68, -cardH / 2 + 20, t.title, {
        fontFamily: 'Arial, sans-serif', fontSize: '18px', fontStyle: 'bold', color: '#eaf2ff'
      }).setOrigin(0, 0));
      card.add(self.add.text(-(w - 80) / 2 + 68, -cardH / 2 + 50, t.desc, {
        fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#8e9cc0', wordWrap: { width: w - 180 }
      }).setOrigin(0, 0));
      var openLabel = self.add.text(0, cardH / 2 - 26, 'Ouvrir →', {
        fontFamily: 'Arial, sans-serif', fontSize: '14px', fontStyle: 'bold', color: '#7dffb0'
      }).setOrigin(0.5);
      card.add(openLabel);
      var hit = self.add.zone(0, 0, w - 80, cardH).setInteractive({ useHandCursor: true });
      card.add(hit);
      hit.on('pointerdown', function () {
        var win = window.open(t.url, '_blank');
        if (!win) self.fx.toast('Ouverture bloquée', 'Autorise les pop-up pour ouvrir l\u2019outil', null);
      });
    });

    this.add.text(w / 2, cardY + tools.length * (cardH + gap) + 12,
      'Les fichiers .nebustion-card.json / exports générés se transmettent\ntels quels pour intégration au jeu.', {
      fontFamily: 'Arial, sans-serif', fontSize: '12px', color: '#5a6a90', align: 'center', wordWrap: { width: w - 100 }
    }).setOrigin(0.5).setDepth(50);

    var deactivateBtn = new NEBUSTION.Button(this, w / 2, h - 200, {
      width: w - 120, height: 54, label: 'Désactiver le mode Atelier', accentColor: 0x394869, fontSize: '15px',
      onClick: function () {
        NEBUSTION.AdminMode.setActive(false);
        self.fx.toast('Mode Atelier désactivé', null, null);
        self._close();
      }
    });
    deactivateBtn.setDepth(50);

    var backBtn = new NEBUSTION.Button(this, w / 2, h - 128, {
      width: w - 120, height: 58, label: '← Retour', accentColor: 0x00e5ff,
      onClick: function () { self._close(); }
    });
    backBtn.setDepth(50);

    this.hud = NEBUSTION.HUD.attach(this);
  }

  _close() {
    var self = this;
    this.cameras.main.fadeOut(200, 5, 7, 15);
    this.cameras.main.once('camerafadeoutcomplete', function () { self.scene.start(self.returnTo); });
  }
};
