/**
 * NEBUSTION - BlackHoleScene
 * Gros plan détaillé du Trou Noir aperçu sur la carte Univers : disque d'accrétion animé,
 * anneau de photons, jets polaires, traînées de matière (NEBUSTION.BlackHoleTextures).
 * Le joueur peut PLONGER : un tunnel de lumière (effet de vitesse radiale) mène à une poche
 * dimensionnelle intérieure où une relique offre un aperçu narratif + une petite récompense
 * (une fois toutes les ~20 h, sauvegardé en localStorage, indépendant de la sauvegarde de partie).
 * Aucune nouvelle mécanique de jeu lourde : uniquement visuel + un petit bonus occasionnel.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.BlackHoleScene = class BlackHoleScene extends Phaser.Scene {
  constructor() {
    super('BlackHoleScene');
  }

  init(data) {
    this._from = (data && data.from) || 'UniverseScene';
  }

  create() {
    var w = this.scale.width, h = this.scale.height, self = this;
    this.cameras.main.setBackgroundColor('#020207');
    this.cameras.main.fadeIn(400, 0, 0, 0);
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });

    this.fx = new NEBUSTION.FX(this);
    this.hud = NEBUSTION.HUD.attach(this);
    this._busy = false;
    this._mode = 'closeup';
    this._diskAngle = 0;

    this.add.text(w / 2, 126, 'TROU NOIR', {
      fontFamily: 'Arial, sans-serif', fontSize: '20px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(80).setShadow(0, 0, '#ff8a3c', 12, true, true);
    this._hintText = this.add.text(w / 2, 150, 'Touchez le trou noir pour l\'observer de plus près', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#7a89ad'
    }).setOrigin(0.5).setDepth(80);

    var back = new NEBUSTION.Button(this, 46, 126, {
      width: 56, height: 44, accentColor: 0x6c3ce9,
      iconDraw: function (g) {
        g.lineStyle(2.5, 0x6c3ce9, 1);
        g.lineBetween(8, 0, -8, 0); g.lineBetween(-8, 0, -1, -7); g.lineBetween(-8, 0, -1, 7);
      },
      onClick: function () { if (!self._busy) self._returnToUniverse(); }
    });
    back.setDepth(80);

    // ---- Calque « gros plan » ----
    this.closeLayer = this.add.container(0, 0).setDepth(40);
    var cx = w / 2, cy = h * 0.5 + 20;
    var key = NEBUSTION.BlackHoleTextures.ensureCloseup(this);
    this.bhImg = this.add.image(cx, cy, key).setDisplaySize(w * 0.86, w * 0.86);
    this.closeLayer.add(this.bhImg);

    var bhHitR = w * 0.43;
    var hit = this.add.circle(cx, cy, bhHitR, 0xffffff, 0.001)
      .setInteractive(new Phaser.Geom.Circle(bhHitR, bhHitR, bhHitR), Phaser.Geom.Circle.Contains);
    hit.input.cursor = 'pointer';
    this.closeLayer.add(hit);
    hit.on('pointerup', function () { self._dive(); });

    this.diveBtn = new NEBUSTION.Button(this, w / 2, h - 150, {
      width: 300, height: 58, label: 'PLONGER', fontSize: '20px', accentColor: 0xff8a3c,
      onClick: function () { self._dive(); }
    });
    this.diveBtn.setDepth(80);

    this.add.text(w / 2, h - 96,
      'Une singularité gravitationnelle. Personne n\'est jamais vraiment revenu inchangé.',
      { fontFamily: 'Arial, sans-serif', fontSize: '12px', color: '#5c6b8a', align: 'center', wordWrap: { width: w - 80 } }
    ).setOrigin(0.5).setDepth(80);

    new NEBUSTION.BottomNav(this, 'galaxy');
  }

  update(time, delta) {
    if (this._mode !== 'closeup' || !this.bhImg || !this.bhImg.active) return;
    this._diskAngle += ((delta || 16) / 1000) * 0.06;
    this.bhImg.setRotation(this._diskAngle);
  }

  // =====================================================================
  // Plongée : tunnel de lumière puis poche dimensionnelle intérieure
  // =====================================================================
  _dive() {
    if (this._busy || this._mode !== 'closeup') return;
    this._busy = true;
    var self = this, w = this.scale.width, h = this.scale.height, cam = this.cameras.main;
    this.diveBtn.setVisible(false);
    this._hintText.setText('Vous approchez de l\'horizon des événements…');

    this.tweens.add({
      targets: this.bhImg, scaleX: this.bhImg.scaleX * 6, scaleY: this.bhImg.scaleY * 6,
      alpha: 0, duration: 900, ease: 'Cubic.easeIn'
    });

    this.time.delayedCall(500, function () { self._tunnelEffect(1300, function () { self._enterInterior(); }); });
  }

  /** Effet visuel de tunnel : traits radiaux qui filent vers le joueur, sur fond noir. */
  _tunnelEffect(durationMs, onDone) {
    var self = this, w = this.scale.width, h = this.scale.height, cx = w / 2, cy = h / 2;
    var layer = this.add.container(0, 0).setDepth(500);
    var bgFlash = this.add.rectangle(0, 0, w, h, 0x000000, 1).setOrigin(0).setDepth(499);
    var lines = [], N = 46;
    for (var i = 0; i < N; i++) {
      var ang = (i / N) * Math.PI * 2 + Math.random() * 0.06;
      var g = this.add.graphics().setDepth(500);
      var hue = Math.random() > 0.6 ? 0xffb84d : (Math.random() > 0.5 ? 0x00e5ff : 0xffffff);
      lines.push({ g: g, ang: ang, col: hue, t: Math.random() });
      layer.add(g);
    }
    var elapsed = 0, self2 = this;
    var ev = this.time.addEvent({
      delay: 16, loop: true, callback: function () {
        elapsed += 16;
        lines.forEach(function (L) {
          L.t += 0.028 + (elapsed / durationMs) * 0.05;
          if (L.t > 1) L.t -= 1;
          var r0 = 10 + L.t * w * 0.75, r1 = r0 + 60 + L.t * 140;
          var x0 = cx + Math.cos(L.ang) * r0, y0 = cy + Math.sin(L.ang) * r0;
          var x1 = cx + Math.cos(L.ang) * r1, y1 = cy + Math.sin(L.ang) * r1;
          L.g.clear();
          L.g.lineStyle(2 + L.t * 3, L.col, 0.15 + L.t * 0.7);
          L.g.lineBetween(x0, y0, x1, y1);
        });
        if (elapsed >= durationMs) {
          ev.remove(false);
          layer.destroy(); bgFlash.destroy();
          if (onDone) onDone();
        }
      }
    });
  }

  _enterInterior() {
    var self = this, w = this.scale.width, h = this.scale.height;
    this._mode = 'interior';
    this.closeLayer.setVisible(false);
    this.cameras.main.setBackgroundColor('#0a0316');

    var layer = this.add.container(0, 0).setDepth(45);
    this.interiorLayer = layer;

    // Poche dimensionnelle : nébuleuse étrange, teintes inversées, aucun repère stable
    for (var i = 0; i < 5; i++) {
      var puff = this.add.image(w * (0.2 + 0.6 * Math.random()), h * (0.3 + 0.4 * Math.random()), 'tex_nebula_purple')
        .setTint([0x7a2cff, 0x00e5ff, 0xff2e88, 0xffb84d, 0x2cffb0][i])
        .setDisplaySize(280 + Math.random() * 220, 280 + Math.random() * 220)
        .setAlpha(0.18).setBlendMode(Phaser.BlendModes.ADD);
      layer.add(puff);
      this.tweens.add({ targets: puff, alpha: 0.32, duration: 2600 + Math.random() * 1600, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    }

    this._hintText.setText('Vous êtes de l\'autre côté de l\'horizon.');
    this.add.text(w / 2, 200, '◈', { fontSize: '54px', color: '#ffe2b8' }).setOrigin(0.5).setDepth(50).setShadow(0, 0, '#ffb84d', 20, true, true);

    var lore = this._pickLore();
    this.add.text(w / 2, 280, lore, {
      fontFamily: 'Arial, sans-serif', fontSize: '15px', color: '#eaf2ff', align: 'center',
      fontStyle: 'italic', wordWrap: { width: w - 100 }
    }).setOrigin(0.5, 0).setDepth(50);

    var reward = this._claimReward();
    var ry = 420;
    if (reward) {
      this.add.text(w / 2, ry, 'Une relique cède quelque chose avant de se dissoudre :', {
        fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#a9b8dc'
      }).setOrigin(0.5).setDepth(50);
      var parts = [];
      Object.keys(reward).forEach(function (rid) {
        var R = NEBUSTION.Economy.RES[rid]; if (!R || !reward[rid]) return;
        parts.push('+' + reward[rid] + ' ' + R.short);
      });
      this.add.text(w / 2, ry + 30, parts.join('   '), {
        fontFamily: 'Arial, sans-serif', fontSize: '20px', fontStyle: '900', color: '#ffd166'
      }).setOrigin(0.5).setDepth(50);
    } else {
      this.add.text(w / 2, ry + 10, 'La relique reste silencieuse pour l\'instant — revenez plus tard.', {
        fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#7a89ad', wordWrap: { width: w - 100 }
      }).setOrigin(0.5).setDepth(50);
    }

    var upBtn = new NEBUSTION.Button(this, w / 2, h - 150, {
      width: 300, height: 58, label: 'REMONTER', fontSize: '20px', accentColor: 0x6c3ce9,
      onClick: function () { self._exitInterior(); }
    });
    upBtn.setDepth(80);
    this._interiorExitBtn = upBtn;
    this._busy = false;
  }

  _exitInterior() {
    if (this._busy) return;
    this._busy = true;
    var self = this;
    this._interiorExitBtn.setVisible(false);
    this._tunnelEffect(900, function () {
      if (self.interiorLayer) self.interiorLayer.destroy();
      self.children.list.slice().forEach(function (c) {
        if (c.depth === 50) c.destroy();
      });
      self._mode = 'closeup';
      self.cameras.main.setBackgroundColor('#020207');
      self.closeLayer.setVisible(true);
      self.bhImg.setScale(self.bhImg.scaleX / 6).setAlpha(1);
      self._hintText.setText('Touchez le trou noir pour l\'observer de plus près');
      self.diveBtn.setVisible(true);
      self._busy = false;
    });
  }

  _pickLore() {
    var LORE = [
      'Le temps s\'étire ici comme un fil qu\'on n\'ose pas rompre.',
      'Des échos de lumière, vieux de mille ans, tournent encore sans fin.',
      'Ce qui tombe ne revient jamais tout à fait le même.',
      'La Voie Aube n\'est plus qu\'un point tremblant, très loin derrière.',
      'Quelque chose, ici, se souvient d\'avoir été une étoile.',
      'L\'horizon ne garde aucune trace — seulement des promesses de lumière.'
    ];
    return LORE[Math.floor(Math.random() * LORE.length)];
  }

  /** Petite récompense, au plus une fois toutes les ~20h (indépendant de la sauvegarde de partie). */
  _claimReward() {
    var KEY = 'nebustion_blackhole_last', COOLDOWN = 20 * 3600 * 1000, now = Date.now();
    var last = 0;
    try { last = parseInt(window.localStorage.getItem(KEY) || '0', 10) || 0; } catch (e) { /* ignore */ }
    if (now - last < COOLDOWN) return null;
    try { window.localStorage.setItem(KEY, String(now)); } catch (e) { /* ignore */ }

    var reward = {
      crystal: 40 + Math.floor(Math.random() * 50),
      energy: 20 + Math.floor(Math.random() * 30),
      dust: 15 + Math.floor(Math.random() * 25)
    };
    if (Math.random() < 0.15) reward.core = 1;
    if (NEBUSTION.Resources) {
      Object.keys(reward).forEach(function (rid) { NEBUSTION.Resources.add(rid, reward[rid], 'blackhole'); });
    }
    return reward;
  }

  _returnToUniverse() {
    this._busy = true;
    var self = this, cam = this.cameras.main;
    cam.fadeOut(300, 5, 7, 15);
    cam.once('camerafadeoutcomplete', function () { self.scene.start(self._from || 'UniverseScene'); });
  }
};
