/**
 * NEBUSTION - BlackHoleScene
 * Gros plan détaillé du Trou Noir aperçu sur la carte Univers : disque d'accrétion animé,
 * anneau de photons, jets polaires, traînées de matière (NEBUSTION.BlackHoleTextures).
 *
 * Le joueur peut PLONGER : une vraie exploration à profondeurs progressives (NEBUSTION.BlackHole
 * + BlackHoleManager) — choix de trajectoire à chaque profondeur (danger visible, type exact
 * révélé à la résolution), Intégrité de sonde à préserver, Fragments de Singularité à récolter,
 * Seuils (mini-boss) tous les 5 paliers, et un Comptoir de l'Abîme pour dépenser les Fragments
 * en ressources ciblées ou en améliorations permanentes de la sonde. Remonter ne coûte jamais
 * rien de ce qui a déjà été gagné : seule l'ampleur de la descente est en jeu.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.BlackHoleScene = class BlackHoleScene extends Phaser.Scene {
  constructor() {
    super('BlackHoleScene');
  }

  init(data) {
    this._from = (data && data.from) || 'UniverseScene';
  }

  create() {
    var w = this.scale.width, h = this.scale.height, self = this;
    this.cameras.main.setBackgroundColor('#020207');
    this.cameras.main.fadeIn(400, 0, 0, 0);
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });

    this.fx = new NEBUSTION.FX(this);
    this.hud = NEBUSTION.HUD.attach(this);
    this._busy = false;
    this._mode = 'closeup';
    this._diskAngle = 0;
    this._pendingOutcome = null;

    this.add.text(w / 2, 126, 'TROU NOIR', {
      fontFamily: 'Arial, sans-serif', fontSize: '20px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(80).setShadow(0, 0, '#ff8a3c', 12, true, true);
    this._hintText = this.add.text(w / 2, 150, 'Touchez le trou noir pour l\'observer de plus près', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#7a89ad'
    }).setOrigin(0.5).setDepth(80);

    var back = new NEBUSTION.Button(this, 46, 126, {
      width: 56, height: 44, accentColor: 0x6c3ce9,
      iconDraw: function (g) {
        g.lineStyle(2.5, 0x6c3ce9, 1);
        g.lineBetween(8, 0, -8, 0); g.lineBetween(-8, 0, -1, -7); g.lineBetween(-8, 0, -1, 7);
      },
      onClick: function () { if (!self._busy && self._mode === 'closeup') self._returnToUniverse(); }
    });
    back.setDepth(80);

    // ---- État persistant (Fragments / charges / profondeur record) : visible en mode « gros plan » ----
    this._statusLine1 = this.add.text(w / 2, 182, '', { fontFamily: 'Arial, sans-serif', fontSize: '14px', color: '#a9b8dc' }).setOrigin(0.5).setDepth(80);
    this._statusLine2 = this.add.text(w / 2, 206, '', { fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#5c6b8a', fontStyle: 'bold' }).setOrigin(0.5).setDepth(80);

    // ---- Calque « gros plan » ----
    this.closeLayer = this.add.container(0, 0).setDepth(40);
    var cx = w / 2, cy = h * 0.5 + 20;
    var key = NEBUSTION.BlackHoleTextures.ensureCloseup(this);
    this.bhImg = this.add.image(cx, cy, key).setDisplaySize(w * 0.86, w * 0.86);
    this.closeLayer.add(this.bhImg);

    var bhHitR = w * 0.43;
    var hit = this.add.circle(cx, cy, bhHitR, 0xffffff, 0.001)
      .setInteractive(new Phaser.Geom.Circle(bhHitR, bhHitR, bhHitR), Phaser.Geom.Circle.Contains);
    hit.input.cursor = 'pointer';
    this.closeLayer.add(hit);
    hit.on('pointerup', function () { if (!self._busy) self._onDiveButton(); });

    this.diveBtn = new NEBUSTION.Button(this, w / 2, h - 210, {
      width: 300, height: 58, label: 'PLONGER', fontSize: '20px', accentColor: 0xff8a3c,
      onClick: function () { if (!self._busy) self._onDiveButton(); }
    });
    this.diveBtn.setDepth(80);

    this.exchangeBtn = new NEBUSTION.Button(this, w / 2, h - 148, {
      width: 220, height: 44, label: 'COMPTOIR DE L\u2019ABÎME', fontSize: '14px', accentColor: 0xffd166,
      onClick: function () { if (!self._busy) self._openExchange(); }
    });
    this.exchangeBtn.setDepth(80);

    // ---- Calque d'exploration (rempli dynamiquement à chaque plongée) ----
    this.explLayer = this.add.container(0, 0).setDepth(45).setVisible(false);
    this.interiorBgLayer = null;

    // ---- Calque du Comptoir de l'Abîme (plein écran, par-dessus tout) ----
    this.exchangeLayer = this.add.container(0, 0).setDepth(200).setVisible(false);

    new NEBUSTION.BottomNav(this, 'galaxy');

    this._refreshCloseupStatus();
    this._statusTimer = this.time.addEvent({ delay: 1000, loop: true, callback: function () { if (self._mode === 'closeup' && !self.exchangeLayer.visible) self._refreshCloseupStatus(); } });
  }

  update(time, delta) {
    if (this._mode !== 'closeup' || !this.bhImg || !this.bhImg.active) return;
    this._diskAngle += ((delta || 16) / 1000) * 0.06;
    this.bhImg.setRotation(this._diskAngle);
  }

  // =====================================================================
  // Utilitaires d'affichage
  // =====================================================================
  _hexNum(h) { return parseInt(String(h).replace('#', ''), 16); }
  _fmtMs(ms) {
    ms = Math.max(0, ms | 0);
    var totalMin = Math.ceil(ms / 60000);
    var hh = Math.floor(totalMin / 60), mm = totalMin % 60;
    if (hh > 0) return hh + ' h ' + (mm < 10 ? '0' : '') + mm + ' min';
    return mm + ' min';
  }
  _wrapText(x, y, text, size, hex, wrapWidth, style) {
    var cfg = { fontFamily: 'Arial, sans-serif', fontSize: size + 'px', color: hex, wordWrap: { width: wrapWidth } };
    if (style) Object.assign(cfg, style);
    return this.add.text(x, y, text, cfg);
  }
  _panelRow(x, y, w, h, accent) {
    var c = this.add.container(x, y);
    var g = this.add.graphics();
    g.fillGradientStyle(0x151d33, 0x151d33, 0x0b1224, 0x0b1224, 1);
    g.fillRoundedRect(0, 0, w, h, 14);
    g.lineStyle(2, accent, 0.7);
    g.strokeRoundedRect(0, 0, w, h, 14);
    c.add(g);
    return c;
  }
  _dangerFlavor(danger) {
    if (danger === 1) return 'Zone calme : peu de risques, gains modestes probables.';
    if (danger === 2) return 'Zone incertaine : gains et dangers à parts égales.';
    return 'Zone hostile : fort danger, mais butin potentiellement important.';
  }

  // =====================================================================
  // Mode « gros plan » (avant la plongée)
  // =====================================================================
  _refreshCloseupStatus() {
    var BM = NEBUSTION.BlackHoleManager, BH = NEBUSTION.BlackHole;
    var frag = BM.fragments(), charges = BM.chargesAvailable(), maxC = BH.CFG.MAX_CHARGES;
    this._statusLine1.setText('\u25C6 ' + Math.round(frag) + ' Fragments de Singularité   \u00B7   Charges ' + charges + '/' + maxC);
    var best = BM.bestZone();
    if (best) {
      this._statusLine2.setText('Profondeur record : ' + BM.maxDepthReached() + '  \u00B7  ' + best.name);
      this._statusLine2.setColor(best.hex);
    } else {
      this._statusLine2.setText('Aucune plongée enregistrée pour l\'instant.');
      this._statusLine2.setColor('#5c6b8a');
    }
    if (BM.hasActiveDive()) {
      this.diveBtn.labelText.setText('REPRENDRE LA PLONGÉE');
      this.diveBtn.setLook(0x4fc3ff, '#eaf2ff');
    } else if (charges >= 1) {
      this.diveBtn.labelText.setText('PLONGER');
      this.diveBtn.setLook(0xff8a3c, '#eaf2ff');
    } else {
      this.diveBtn.labelText.setText('PLONGER (recharge : ' + this._fmtMs(BM.msToNextCharge()) + ')');
      this.diveBtn.setLook(0x394869, '#6d7c9c');
    }
  }

  _onDiveButton() {
    var BM = NEBUSTION.BlackHoleManager;
    var r = BM.startOrResumeDive();
    if (!r.ok) {
      if (r.reason === 'no_charge') this.fx.toast('Aucune charge disponible', 'Prochaine plongée dans ' + this._fmtMs(r.msLeft), null);
      else this.fx.toast('Impossible de plonger', null, null);
      return;
    }
    this._dive();
  }

  // =====================================================================
  // Plongée : tunnel de lumière puis exploration
  // =====================================================================
  _dive() {
    if (this._busy || this._mode !== 'closeup') return;
    this._busy = true;
    var self = this;
    this.diveBtn.setVisible(false);
    this.exchangeBtn.setVisible(false);
    this._hintText.setText('Vous approchez de l\'horizon des événements\u2026');

    this.tweens.add({
      targets: this.bhImg, scaleX: this.bhImg.scaleX * 6, scaleY: this.bhImg.scaleY * 6,
      alpha: 0, duration: 900, ease: 'Cubic.easeIn'
    });

    this.time.delayedCall(500, function () { self._tunnelEffect(1300, function () { self._enterInterior(); }); });
  }

  /** Effet visuel de tunnel : traits radiaux qui filent vers le joueur, sur fond noir. */
  _tunnelEffect(durationMs, onDone) {
    var self = this, w = this.scale.width, h = this.scale.height, cx = w / 2, cy = h / 2;
    var layer = this.add.container(0, 0).setDepth(500);
    var bgFlash = this.add.rectangle(0, 0, w, h, 0x000000, 1).setOrigin(0).setDepth(499);
    var lines = [], N = 46;
    for (var i = 0; i < N; i++) {
      var ang = (i / N) * Math.PI * 2 + Math.random() * 0.06;
      var g = this.add.graphics().setDepth(500);
      var hue = Math.random() > 0.6 ? 0xffb84d : (Math.random() > 0.5 ? 0x00e5ff : 0xffffff);
      lines.push({ g: g, ang: ang, col: hue, t: Math.random() });
      layer.add(g);
    }
    var elapsed = 0;
    var ev = this.time.addEvent({
      delay: 16, loop: true, callback: function () {
        elapsed += 16;
        lines.forEach(function (L) {
          L.t += 0.028 + (elapsed / durationMs) * 0.05;
          if (L.t > 1) L.t -= 1;
          var r0 = 10 + L.t * w * 0.75, r1 = r0 + 60 + L.t * 140;
          var x0 = cx + Math.cos(L.ang) * r0, y0 = cy + Math.sin(L.ang) * r0;
          var x1 = cx + Math.cos(L.ang) * r1, y1 = cy + Math.sin(L.ang) * r1;
          L.g.clear();
          L.g.lineStyle(2 + L.t * 3, L.col, 0.15 + L.t * 0.7);
          L.g.lineBetween(x0, y0, x1, y1);
        });
        if (elapsed >= durationMs) {
          ev.remove(false);
          layer.destroy(); bgFlash.destroy();
          if (onDone) onDone();
        }
      }
    });
  }

  /** Transition légère entre deux nœuds d'exploration (bien plus rapide que le tunnel complet). */
  _flashTransition(cb) {
    var self = this, w = this.scale.width, h = this.scale.height;
    var r = this.add.rectangle(0, 0, w, h, 0xffffff, 0).setOrigin(0).setDepth(600);
    this.fx.shake(70, 0.0015);
    this.tweens.add({
      targets: r, fillAlpha: 0.3, duration: 90, yoyo: true,
      onComplete: function () { r.destroy(); if (cb) cb(); }
    });
  }

  _enterInterior() {
    var w = this.scale.width, h = this.scale.height;
    this._mode = 'interior';
    this.closeLayer.setVisible(false);
    this._statusLine1.setVisible(false); this._statusLine2.setVisible(false);
    this._hintText.setVisible(false);
    this.cameras.main.setBackgroundColor('#0a0316');

    var layer = this.add.container(0, 0).setDepth(30);
    this.interiorBgLayer = layer;
    for (var i = 0; i < 5; i++) {
      var puff = this.add.image(w * (0.2 + 0.6 * Math.random()), h * (0.3 + 0.4 * Math.random()), 'tex_nebula_purple')
        .setTint([0x7a2cff, 0x00e5ff, 0xff2e88, 0xffb84d, 0x2cffb0][i])
        .setDisplaySize(280 + Math.random() * 220, 280 + Math.random() * 220)
        .setAlpha(0.14).setBlendMode(Phaser.BlendModes.ADD);
      layer.add(puff);
      this.tweens.add({ targets: puff, alpha: 0.26, duration: 2600 + Math.random() * 1600, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    }

    if (!this._retreatBtn) {
      var self = this;
      this._retreatBtn = new NEBUSTION.Button(this, w / 2, h - 210, {
        width: 260, height: 54, label: '\u25C0 REMONTER', fontSize: '17px', accentColor: 0x6c3ce9,
        onClick: function () { self._onRetreat(); }
      });
      this._retreatBtn.setDepth(90);
    }

    this._pendingOutcome = null;
    this.explLayer.setVisible(true);
    this._retreatBtn.setVisible(true);
    this._renderExploration();
    this._busy = false;
  }

  // =====================================================================
  // Exploration : rendu de l'écran courant (choix OU résultat d'un choix)
  // =====================================================================
  _renderExploration() {
    var self = this, BM = NEBUSTION.BlackHoleManager, w = this.scale.width;
    this.explLayer.removeAll(true);
    var snap = BM.diveSnapshot();
    if (!snap) { this._exitInterior(); return; }
    var zone = snap.zone;

    this.explLayer.add(this.add.text(w / 2, 150, zone.name.toUpperCase(), {
      fontFamily: 'Arial, sans-serif', fontSize: '18px', fontStyle: '900', color: zone.hex
    }).setOrigin(0.5).setShadow(0, 0, zone.hex, 10, true, true));
    this.explLayer.add(this.add.text(w / 2, 176, 'Profondeur ' + snap.depth, {
      fontFamily: 'Arial, sans-serif', fontSize: '14px', color: '#a9b8dc'
    }).setOrigin(0.5));

    var barX = 50, barY = 208, barW = w - 100;
    var bg = this.add.graphics(); bg.fillStyle(0x11172a, 1); bg.fillRoundedRect(barX, barY, barW, 18, 9);
    this.explLayer.add(bg);
    var pct = Math.max(0, Math.min(1, snap.integrity / snap.maxIntegrity));
    var barColor = pct > 0.5 ? 0x5fd97a : (pct > 0.25 ? 0xffb84d : 0xff4d6d);
    if (pct > 0) {
      var fg = this.add.graphics(); fg.fillStyle(barColor, 1); fg.fillRoundedRect(barX, barY, Math.max(10, barW * pct), 18, 9);
      this.explLayer.add(fg);
    }
    this.explLayer.add(this.add.text(w / 2, barY + 9, 'Intégrité ' + Math.round(snap.integrity) + ' / ' + Math.round(snap.maxIntegrity), {
      fontFamily: 'Arial, sans-serif', fontSize: '12px', color: '#eaf2ff', fontStyle: 'bold'
    }).setOrigin(0.5));

    var contentTop = barY + 48;
    if (pct <= 0.25) {
      this.explLayer.add(this.add.text(w / 2, contentTop, '\u26A0 Coque critique \u2014 la moindre secousse peut être fatale à la plongée', {
        fontFamily: 'Arial, sans-serif', fontSize: '12px', color: '#ff4d6d', fontStyle: 'bold', wordWrap: { width: w - 80 }, align: 'center'
      }).setOrigin(0.5));
      contentTop += 30;
    }
    this.explLayer.add(this.add.text(w / 2, contentTop, '\u25C6 ' + Math.round(BM.fragments()) + ' Fragments de Singularité', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#8fe3ff'
    }).setOrigin(0.5));
    contentTop += 30;

    if (this._pendingOutcome) this._renderOutcome(contentTop, w);
    else this._renderChoices(contentTop, w);
  }

  _renderChoices(top, w) {
    var self = this, BM = NEBUSTION.BlackHoleManager;
    var opts = BM.currentOptions();
    this.explLayer.add(this.add.text(w / 2, top, 'Choisissez une trajectoire \u2014 chaque rencontre est une épreuve à piloter :', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#c7d3f0', fontStyle: 'bold', wordWrap: { width: w - 60 }, align: 'center'
    }).setOrigin(0.5));

    var cardH = 118, gap = 14, cw = w - 64, cardX = 32, startY = top + 30;
    opts.forEach(function (o, i) {
      var y = startY + i * (cardH + gap);
      var accentNum = self._hexNum(o.hex);
      var card = self.add.container(cardX, y);
      var g = self.add.graphics();
      g.fillGradientStyle(0x151d33, 0x151d33, 0x0b1224, 0x0b1224, 1);
      g.fillRoundedRect(0, 0, cw, cardH, 16);
      g.lineStyle(o.forced === 'abime' ? 3 : 2.5, accentNum, 0.9);
      g.strokeRoundedRect(0, 0, cw, cardH, 16);
      card.add(g);
      var labelText = (o.forced === 'abime' ? '\u26A0 ' : '') + o.label;
      card.add(self.add.text(20, 24, labelText, { fontFamily: 'Arial, sans-serif', fontSize: '16px', fontStyle: '900', color: o.hex }));
      var subtitle = o.forced === 'abime' ? 'Une rencontre majeure vous attend ici \u2014 restez prudent.' : self._dangerFlavor(o.danger);
      card.add(self._wrapText(20, 54, subtitle, 13, '#a9b8dc', cw - 40));
      var hitBg = self.add.rectangle(cw / 2, cardH / 2, cw, cardH, 0xffffff, 0.001).setInteractive({ useHandCursor: true });
      card.add(hitBg);
      hitBg.on('pointerup', function () { self._onChoose(o.idx); });
      self.explLayer.add(card);
    });
  }

  _onChoose(idx) {
    if (this._busy) return;
    var self = this, BM = NEBUSTION.BlackHoleManager;
    // Rencontre « active » (récolte, relique, marée, écho, Seuil) → épreuve temps réel dans l'arène.
    // Repos (point d'ancrage, accalmie) ou arène absente → résolution instantanée comme avant.
    var plan = BM.planNode(idx);
    if (plan.ok && plan.mode && this.scene.manager.keys['BlackHoleRunScene']) { this._playNode(idx, plan); return; }
    var res = BM.chooseNode(idx);
    if (!res.ok) { this.fx.toast('Choix impossible', null, null); this._renderExploration(); return; }
    this._flashTransition(function () {
      self._pendingOutcome = res;
      self._renderExploration();
    });
  }

  /** Ouvre l'arène temps réel par-dessus cette scène (mise en pause) ; le résultat revient par onDone(perf). */
  _playNode(idx, plan) {
    var self = this;
    this._busy = true;
    this._flashTransition(function () {
      self.scene.launch('BlackHoleRunScene', {
        plan: plan, parent: 'BlackHoleScene',
        onDone: function (perf) {
          var res = NEBUSTION.BlackHoleManager.chooseNode(idx, undefined, perf);
          self._busy = false;
          if (!res.ok) { self.fx.toast('Choix impossible', null, null); self._renderExploration(); return; }
          self._pendingPerfLine = perf && perf.summary ? perf.summary : null;
          self._pendingOutcome = res;
          self._renderExploration();
        }
      });
      self.scene.pause();
    });
  }

  _renderOutcome(top, w) {
    var self = this, res = this._pendingOutcome, o = res.outcome;
    var isAbime = o.kind === 'abime';
    var cw = w - 64, ch = 330;
    var card = this.add.container(32, top);
    var g = this.add.graphics();
    g.fillGradientStyle(0x151d33, 0x151d33, 0x0b1224, 0x0b1224, 1);
    g.fillRoundedRect(0, 0, cw, ch, 18);
    g.lineStyle(2.5, isAbime ? 0xffd166 : 0x4fc3ff, 0.9);
    g.strokeRoundedRect(0, 0, cw, ch, 18);
    card.add(g);

    var titleColor = isAbime ? '#ffd166' : '#eaf2ff';
    var title = this.add.text(24, 22, o.title, { fontFamily: 'Arial, sans-serif', fontSize: '18px', fontStyle: '900', color: titleColor });
    card.add(title);
    var body = this._wrapText(24, title.y + title.height + 8, o.body, 14, '#c7d3f0', cw - 48, { fontStyle: 'italic' });
    card.add(body);

    var y = body.y + body.height + 16;
    var rows = [];
    var E = NEBUSTION.Economy;
    Object.keys(o.resources || {}).forEach(function (id) { if (o.resources[id] > 0) rows.push({ text: '+' + Math.round(o.resources[id]) + ' ' + E.RES[id].short, hex: E.RES[id].hex }); });
    if (o.fragments > 0) rows.push({ text: '+' + Math.round(o.fragments) + ' Fragments', hex: '#8fe3ff' });
    if (o.gems > 0) rows.push({ text: '+' + o.gems + ' Prismes', hex: '#e6c6ff' });
    rows.forEach(function (r) {
      var rt = self.add.text(24, y, r.text, { fontFamily: 'Arial, sans-serif', fontSize: '15px', fontStyle: 'bold', color: r.hex });
      card.add(rt);
      y += rt.height + 4;
    });
    if (!rows.length) { var none = this.add.text(24, y, 'Rien de récupérable cette fois.', { fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#6d7c9c' }); card.add(none); y += none.height + 4; }

    if (this._pendingPerfLine) {
      var pl = this.add.text(24, y + 4, this._pendingPerfLine, { fontFamily: 'Arial, sans-serif', fontSize: '13px', fontStyle: 'bold', color: '#8fe3ff', wordWrap: { width: cw - 48 } });
      card.add(pl); y = pl.y + pl.height + 6;
    }
    if (o.success !== null) {
      var tag = this.add.text(24, y + 4, o.success ? '\u2713 Rencontre repoussée' : '\u2717 Rencontre difficile', {
        fontFamily: 'Arial, sans-serif', fontSize: '14px', fontStyle: 'bold', color: o.success ? '#5fd97a' : '#ff9a7b'
      });
      card.add(tag); y = tag.y + tag.height + 4;
    }
    if (o.integrityDelta !== 0) {
      var delta = this.add.text(24, y + 4, 'Intégrité ' + (o.integrityDelta > 0 ? '+' : '') + o.integrityDelta, {
        fontFamily: 'Arial, sans-serif', fontSize: '13px', color: o.integrityDelta > 0 ? '#5fd97a' : '#ff4d6d'
      });
      card.add(delta); y = delta.y + delta.height;
    }

    this.explLayer.add(card);

    if (res.forcedEnd) {
      this._retreatBtn.setVisible(false);
      var warn = this.add.text(32 + cw / 2, top + ch + 16, 'Intégrité épuisée \u2014 retour forcé à la surface.', {
        fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#ff4d6d', fontStyle: 'bold', wordWrap: { width: cw }, align: 'center'
      }).setOrigin(0.5, 0);
      this.explLayer.add(warn);
      var exitBtn = new NEBUSTION.Button(this, w / 2, top + ch + 70, {
        width: 260, height: 54, label: 'REMONTER', fontSize: '17px', accentColor: 0xff4d6d,
        onClick: function () { self._exitInterior(); }
      });
      this.explLayer.add(exitBtn);
    } else {
      if (o.kind === 'sanctuaire') {
        var note = this.add.text(32 + cw / 2, top + ch + 12, 'Point d\u2019ancrage stable : remonter maintenant accorde un bonus de Fragments.', {
          fontFamily: 'Arial, sans-serif', fontSize: '12px', color: '#5fd97a', wordWrap: { width: cw }, align: 'center'
        }).setOrigin(0.5, 0);
        this.explLayer.add(note);
      }
      var contBtn = new NEBUSTION.Button(this, w / 2, top + ch + (o.kind === 'sanctuaire' ? 66 : 40), {
        width: 260, height: 54, label: 'CONTINUER', fontSize: '17px', accentColor: 0x4fc3ff,
        onClick: function () { self._pendingOutcome = null; self._pendingPerfLine = null; self._renderExploration(); }
      });
      this.explLayer.add(contBtn);
    }
  }

  _onRetreat() {
    if (this._busy) return;
    var BM = NEBUSTION.BlackHoleManager;
    var r = BM.retreat();
    if (r.ok && r.bonus > 0) this.fx.toast('Extraction réussie', '+' + r.bonus + ' Fragments bonus (point d\u2019ancrage)', null);
    this._exitInterior();
  }

  _exitInterior() {
    if (this._busy) return;
    this._busy = true;
    var self = this;
    if (this._retreatBtn) this._retreatBtn.setVisible(false);
    this.explLayer.setVisible(false);
    this._tunnelEffect(900, function () {
      if (self.interiorBgLayer) { self.interiorBgLayer.destroy(); self.interiorBgLayer = null; }
      self.explLayer.removeAll(true);
      self._pendingOutcome = null; self._pendingPerfLine = null;
      self._mode = 'closeup';
      self.cameras.main.setBackgroundColor('#020207');
      self.closeLayer.setVisible(true);
      self.bhImg.setScale(self.bhImg.scaleX / 6).setAlpha(1);
      self._statusLine1.setVisible(true); self._statusLine2.setVisible(true);
      self._hintText.setVisible(true).setText('Touchez le trou noir pour l\'observer de plus près');
      self.diveBtn.setVisible(true);
      self.exchangeBtn.setVisible(true);
      self._refreshCloseupStatus();
      self._busy = false;
    });
  }

  // =====================================================================
  // Comptoir de l'Abîme : améliorations permanentes + échanges de Fragments
  // =====================================================================
  _openExchange() {
    if (this._mode !== 'closeup') return;
    this.exchangeLayer.setVisible(true);
    this._renderExchange();
  }
  _closeExchange() {
    this.exchangeLayer.setVisible(false);
    this.exchangeLayer.removeAll(true);
    this._refreshCloseupStatus();
  }

  _renderExchange() {
    this.exchangeLayer.removeAll(true);
    var self = this, w = this.scale.width, h = this.scale.height, BM = NEBUSTION.BlackHoleManager, BH = NEBUSTION.BlackHole;

    var bg = this.add.rectangle(0, 0, w, h, 0x05070f, 0.97).setOrigin(0).setInteractive();
    this.exchangeLayer.add(bg);
    this.exchangeLayer.add(this.add.text(w / 2, 90, 'COMPTOIR DE L\u2019ABÎME', { fontFamily: 'Arial, sans-serif', fontSize: '20px', fontStyle: '900', color: '#ffd166' }).setOrigin(0.5));
    this.exchangeLayer.add(this.add.text(w / 2, 120, '\u25C6 ' + Math.round(BM.fragments()) + ' Fragments de Singularité', { fontFamily: 'Arial, sans-serif', fontSize: '14px', color: '#8fe3ff' }).setOrigin(0.5));

    var closeBtn = new NEBUSTION.Button(this, w - 46, 90, {
      width: 56, height: 44, accentColor: 0xff4d6d,
      iconDraw: function (g) { g.lineStyle(2.5, 0xff4d6d, 1); g.lineBetween(-7, -7, 7, 7); g.lineBetween(-7, 7, 7, -7); },
      onClick: function () { self._closeExchange(); }
    });
    this.exchangeLayer.add(closeBtn);

    var y = 168;
    this.exchangeLayer.add(this.add.text(40, y, 'AMÉLIORATIONS DE LA SONDE', { fontFamily: 'Arial, sans-serif', fontSize: '13px', fontStyle: 'bold', color: '#6d7c9c' }));
    y += 26;
    BH.TALENT_ORDER.forEach(function (id) {
      var def = BH.TALENTS[id], lvl = BM.talentLevel(id), cost = BM.talentCost(id), rowH = 76;
      var row = self._panelRow(40, y, w - 80, rowH, 0x2b3a5c);
      row.add(self.add.text(16, 14, def.name + '  (Niv. ' + lvl + '/' + def.maxLevel + ')', { fontFamily: 'Arial, sans-serif', fontSize: '15px', fontStyle: 'bold', color: '#eaf2ff' }));
      row.add(self._wrapText(16, 40, def.desc, 12, '#a9b8dc', w - 80 - 150));
      if (cost === null) {
        row.add(self.add.text(w - 80 - 20, rowH / 2, 'MAX', { fontFamily: 'Arial, sans-serif', fontSize: '14px', fontStyle: '900', color: '#5fd97a' }).setOrigin(1, 0.5));
      } else {
        var afford = BM.fragments() >= cost;
        var buyBtn = new NEBUSTION.Button(self, w - 80 - 70, rowH / 2, {
          width: 120, height: 44, label: '\u25C6 ' + cost, fontSize: '15px', accentColor: afford ? 0xffd166 : 0x394869, disabled: !afford,
          onClick: function () { self._buyTalent(id); }
        });
        row.add(buyBtn);
      }
      self.exchangeLayer.add(row);
      y += rowH + 10;
    });

    y += 6;
    this.exchangeLayer.add(this.add.text(40, y, 'ÉCHANGES', { fontFamily: 'Arial, sans-serif', fontSize: '13px', fontStyle: 'bold', color: '#6d7c9c' }));
    y += 26;
    var offers = BM.exchangeOffers();
    offers.forEach(function (o) {
      var rowH = 64;
      var row = self._panelRow(40, y, w - 80, rowH, 0x2b3a5c);
      var label, colorHex;
      if (o.gem) {
        label = 'Prisme voilé  \u00D7' + o.amount + (o.dailyLeft !== null ? ('   (' + o.dailyLeft + '/3 aujourd\u2019hui)') : '');
        colorHex = '#e6c6ff';
      } else {
        var R = NEBUSTION.Economy.RES[o.resId];
        label = R.short + '  +' + o.amount;
        colorHex = R.hex;
      }
      row.add(self.add.text(16, rowH / 2, label, { fontFamily: 'Arial, sans-serif', fontSize: '14px', fontStyle: 'bold', color: colorHex }).setOrigin(0, 0.5));
      var buyBtn = new NEBUSTION.Button(self, w - 80 - 70, rowH / 2, {
        width: 120, height: 44, label: '\u25C6 ' + o.cost, fontSize: '15px', accentColor: o.afford ? 0x4fc3ff : 0x394869, disabled: !o.afford,
        onClick: function () { self._buyExchange(o.id); }
      });
      row.add(buyBtn);
      self.exchangeLayer.add(row);
      y += rowH + 10;
    });
  }

  _buyTalent(id) {
    var r = NEBUSTION.BlackHoleManager.buyTalent(id);
    if (!r.ok) { this.fx.toast('Achat impossible', r.reason === 'fragments' ? 'Fragments insuffisants' : null, null); return; }
    this.fx.toast(NEBUSTION.BlackHole.TALENTS[id].name, 'Niveau ' + r.level, null);
    this._renderExchange();
  }
  _buyExchange(id) {
    var r = NEBUSTION.BlackHoleManager.buyExchange(id);
    if (!r.ok) { this.fx.toast('Achat impossible', r.reason === 'limite_quotidienne' ? 'Limite quotidienne atteinte' : 'Fragments insuffisants', null); return; }
    this.fx.toast('Échange effectué', r.gem ? ('+' + r.gem + ' Prismes') : null, r.resId || null);
    this._renderExchange();
  }

  _returnToUniverse() {
    this._busy = true;
    var self = this, cam = this.cameras.main;
    cam.fadeOut(300, 5, 7, 15);
    cam.once('camerafadeoutcomplete', function () { self.scene.start(self._from || 'UniverseScene'); });
  }
};
