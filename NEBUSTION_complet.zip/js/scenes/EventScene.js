/**
 * NEBUSTION - EventScene (étape 10)
 * Événement temporaire (cycle de 14 jours, 5 jours actifs, thème tournant) : onglet « Boss »
 * (PV, tentatives restantes, puissance d'équipe, bouton d'attaque), onglet « Missions »
 * (réclamation), onglet « Boutique » (achat avec confirmation, limites). Hors événement :
 * compte à rebours avant le prochain, actions désactivées.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.EventScene = class EventScene extends NEBUSTION.ProgressScene {
  constructor() { super('EventScene'); }

  init(data) {
    super.init(data);
    try { NEBUSTION.EventManager.touch(); } catch (e) { /* ignore */ }
  }

  _hubKey() { return 'event'; }
  _titleText() { return 'ÉVÉNEMENT'; }
  _accent() { var i = this._info(); return i.theme.color; }
  _accentHex() { return this._hex(this._accent()); }
  _defaultTab() { return 'boss'; }
  _tabDefs() { return [{ id: 'boss', label: 'Boss' }, { id: 'missions', label: 'Missions' }, { id: 'shop', label: 'Boutique' }]; }

  _info() { return NEBUSTION.EventManager.info(); }

  _badgeContent(c) {
    var EM = NEBUSTION.EventManager, i = this._info();
    if (!i.active) { this._badgePill(c, 'frag', 'Inactif', 0x394869, '#8e9cc0'); return; }
    this._badgePill(c, 'gem', this._fmt(EM.currency()), i.theme.color, this._hex(i.theme.color));
  }

  _renderTab(w) {
    var i = this._info();
    if (!i.active) return this._renderInactive(w, i);
    if (this.tab === 'boss') return this._renderBoss(w, i);
    if (this.tab === 'missions') return this._renderMissions(w, i);
    return this._renderShop(w, i);
  }

  // ================= Hors événement =================
  _renderInactive(w, i) {
    var self = this;
    var card = this._card(280, 0x394869, {});
    card.add(this._txt(24, 30, 'Aucun événement en cours', 20, '#eaf2ff', { fontStyle: 'bold' }));
    card.add(this._txt(24, 62, 'Le secteur est calme. Le prochain événement approche.', 15, '#a9b8dc', { wordWrap: { width: card._cw - 48 } }));
    var nextTheme = NEBUSTION.Events.theme(i.cycleIndex + 1);
    card.add(this._txt(24, 110, 'Prochain thème : ' + nextTheme.name, 17, this._hex(nextTheme.color), { fontStyle: 'bold' }));
    var cd = this._txt(24, 140, '', 26, '#eaf2ff', { fontStyle: '900' });
    card.add(cd);
    this._liveText(cd, function () {
      var ni = NEBUSTION.EventManager.info();
      if (ni.active) { self._refreshAll(false); return ''; }
      return 'Dans ' + self._fmtMs(ni.msLeft);
    });
    card.add(this._txt(24, 190, nextTheme.tagline, 14, '#8e9cc0', { wordWrap: { width: card._cw - 48 } }));
    card.add(this._txt(24, 224, 'Missions, boss et boutique événementielle reviennent à l\'ouverture du cycle.', 13, '#6d7c9c', { wordWrap: { width: card._cw - 48 } }));
    return { cards: [card], footer: null };
  }

  // ================= Onglet Boss =================
  _renderBoss(w, i) {
    var self = this, EM = NEBUSTION.EventManager, th = i.theme, boss = EM.bossStatus();
    var cards = [];

    var head = this._card(150, th.color, { glow: true });
    head.add(this._txt(24, 22, th.name, 20, '#eaf2ff', { fontStyle: 'bold' }).setShadow(0, 0, this._hex(th.color), 10, true, true));
    head.add(this._txt(24, 48, th.tagline, 14, '#a9b8dc', { wordWrap: { width: head._cw - 48 } }));
    var cdT = this._txt(head._cw - 24, 22, '', 15, '#eaf2ff', { fontStyle: 'bold' }).setOrigin(1, 0);
    head.add(cdT);
    this._liveText(cdT, function () { return self._fmtMs(NEBUSTION.EventManager.info().msLeft) + ' restant'; });
    var dayTxt = 'Jour ' + (i.dayInCycle + 1) + ' / ' + i.activeDays + ' actifs';
    head.add(this._txt(24, 78, dayTxt, 13, '#8e9cc0'));
    cards.push(head);

    var boss2 = this._card(220, th.color, {});
    boss2.add(this._txt(boss2._cw / 2, 26, boss.name, 20, '#eaf2ff', { fontStyle: 'bold' }).setOrigin(0.5));
    var frac = boss.maxHp > 0 ? boss.hp / boss.maxHp : 0;
    this._bar(boss2, 24, 60, boss2._cw - 48, 20, frac, boss.defeated ? 0x5fd97a : th.color);
    boss2.add(this._txt(boss2._cw / 2, 70, this._fmt(boss.hp) + ' / ' + this._fmt(boss.maxHp) + ' PV', 15, '#eaf2ff', { fontStyle: 'bold' }).setOrigin(0.5));
    var attemptsLeft = EM.attemptsLeft(), power = EM.teamPower();
    boss2.add(this._txt(24, 108, 'Puissance d\'équipe : ' + this._fmt(power), 15, power > 0 ? '#c7d3f0' : '#ff9a7b', { fontStyle: 'bold' }));
    boss2.add(this._txt(24, 134, 'Tentatives restantes aujourd\'hui : ' + attemptsLeft + ' / ' + NEBUSTION.Events.maxAttempts(NEBUSTION.PrestigeManager ? NEBUSTION.PrestigeManager.count() : 0), 14, '#a9b8dc'));
    if (boss.defeated) {
      this._btn(boss2, boss2._cw / 2, 178, boss2._cw - 48, 46, 'BOSS VAINCU', 0x5fd97a, true, null, null);
    } else if (power <= 0) {
      this._btn(boss2, boss2._cw / 2, 178, boss2._cw - 48, 46, 'COMPOSEZ VOTRE ÉQUIPE', 0x394869, true, function () { self.scene.start('CombatPrepScene', { navKey: 'combat', title: 'Combat' }); }, null);
    } else if (attemptsLeft <= 0) {
      this._btn(boss2, boss2._cw / 2, 178, boss2._cw - 48, 46, 'PLUS DE TENTATIVES', 0x394869, true, null, 'Revenez demain pour de nouvelles tentatives.');
    } else {
      this._btn(boss2, boss2._cw / 2, 178, boss2._cw - 48, 46, 'ATTAQUER (' + attemptsLeft + ')', th.color, false, function () { self._attack(); });
    }
    cards.push(boss2);

    var textures = ['tex_enemy_nexus_architect', 'steel_golem', 'voltaic_hunter'].filter(function (k) { return self.textures.exists(k); });
    if (textures.length) {
      var gallery = this._card(120, th.color, { dim: true });
      gallery.add(this._txt(24, 20, 'Aperçu des forces ennemies', 13, '#8e9cc0'));
      textures.forEach(function (k, idx) { var img = self._image(60 + idx * 90, 78, k); if (img) { img.setDisplaySize(64, 64); gallery.add(img); } });
      cards.push(gallery);
    }
    return { cards: cards, footer: null };
  }

  _attack() {
    var self = this, r = NEBUSTION.EventManager.attackBoss();
    if (!r.ok) { this.fx.toast('Attaque impossible', r.reason === 'tentatives' ? 'Plus de tentatives aujourd\'hui.' : (r.reason === 'equipe' ? 'Composez votre équipe.' : ''), null); this._refreshAll(false); return; }
    var msg = (r.crit ? 'COUP CRITIQUE ! ' : '') + '-' + this._fmt(r.damage) + ' PV';
    this.fx.toast(r.defeated ? 'Boss vaincu !' : 'Attaque réussie', msg, null);
    if (r.defeated && r.reward) {
      var rows = [], E = NEBUSTION.Economy;
      Object.keys(r.reward.granted).forEach(function (id) { if (r.reward.granted[id] > 0) rows.push({ kind: id, amount: r.reward.granted[id], hex: E.RES[id] ? E.RES[id].hex : '#eaf2ff' }); });
      if (r.reward.gems > 0) rows.push({ kind: 'gem', amount: r.reward.gems, hex: '#e6c6ff' });
      if (r.reward.fragments > 0) rows.push({ kind: 'frag', amount: r.reward.fragments, hex: '#8fe3ff', label: 'par héros' });
      if (r.reward.currency > 0) rows.push({ kind: 'ecoin', amount: r.reward.currency, color: this._accent(), hex: this._accentHex(), label: this._info().theme.currency.name });
      var self2 = this;
      this._reveal('BOSS VAINCU !', null, rows, ['Le boss événementiel a été terrassé par votre équipe.'], this._accent(), function () { self2._refreshAll(false); });
    } else {
      this._refreshAll(false);
    }
  }

  // ================= Onglet Missions =================
  _renderMissions(w, i) {
    var self = this, EM = NEBUSTION.EventManager, cards = [];
    EM.missions().forEach(function (m) {
      var h = 130, card = self._card(h, i.theme.color, { dim: m.status === 'claimed' });
      card.add(self._txt(24, 24, m.label, 17, '#eaf2ff', { fontStyle: 'bold', wordWrap: { width: card._cw - 130 } }));
      var frac = m.target > 0 ? m.p / m.target : 0;
      self._bar(card, 24, 62, card._cw - 130, 14, frac, i.theme.color);
      card.add(self._txt(24, 86, m.p + ' / ' + m.target, 13, '#a9b8dc'));
      self._rewardRow(card, 24, 108, [{ kind: 'ecoin', amount: m.currency, color: self._accent(), hex: self._accentHex() }], 20, { font: 15 });
      if (m.status === 'claimed') {
        self._btn(card, card._cw - 96, h / 2, 150, 44, 'RÉCLAMÉE', 0x394869, true, null, null);
      } else if (m.status === 'ready') {
        self._btn(card, card._cw - 96, h / 2, 150, 44, 'RÉCLAMER', 0x5fd97a, false, function () { self._claimMission(m.id); });
      } else {
        self._btn(card, card._cw - 96, h / 2, 150, 44, 'EN COURS', 0x394869, true, null, 'Continuez à progresser pour la réclamer.');
      }
      cards.push(card);
    });
    return { cards: cards, footer: null };
  }
  _claimMission(id) {
    var self = this, r = NEBUSTION.EventManager.claimMission(id);
    if (!r.ok) { this._refreshAll(false); return; }
    this._reveal('MISSION TERMINÉE', null, [{ kind: 'ecoin', amount: r.currency, color: this._accent(), hex: this._accentHex(), label: this._info().theme.currency.name }], null, this._accent(), function () { self._refreshAll(false); });
  }

  // ================= Onglet Boutique =================
  _renderShop(w, i) {
    var self = this, EM = NEBUSTION.EventManager, cards = [];
    var head = this._card(70, i.theme.color, { dim: true });
    head.add(this._txt(24, 35, 'Monnaie : ' + this._fmt(EM.currency()) + ' ' + i.theme.currency.name, 17, this._hex(i.theme.color), { fontStyle: 'bold' }).setOrigin(0, 0.5));
    cards.push(head);
    EM.shopStatus().forEach(function (it) {
      var h = 128, sold = it.left <= 0, card = self._card(h, i.theme.color, { dim: sold });
      card.add(self._txt(24, 22, it.label, 17, '#eaf2ff', { fontStyle: 'bold' }));
      card.add(self._txt(24, 46, it.desc, 13, '#a9b8dc', { wordWrap: { width: card._cw - 150 } }));
      card.add(self._txt(24, 84, (it.owned || 0) + ' / ' + it.limit + ' achetés', 12, '#6d7c9c'));
      self._chip(card, card._cw - 250, 20, self._fmt(it.cost) + ' ' + i.theme.currency.name, i.theme.color, 13);
      if (sold) {
        self._btn(card, card._cw - 96, h - 34, 150, 44, 'ÉPUISÉ', 0x394869, true, null, null);
      } else {
        var afford = EM.currency() >= it.cost;
        self._btn(card, card._cw - 96, h - 34, 150, 44, 'ACHETER', i.theme.color, !afford, function () { self._confirmBuy(it); }, 'Monnaie insuffisante.');
      }
      cards.push(card);
    });
    return { cards: cards, footer: null };
  }
  _confirmBuy(it) {
    var self = this;
    this._confirm('Acheter « ' + it.label + ' » ?', [it.desc, 'Coût : ' + this._fmt(it.cost) + ' ' + this._info().theme.currency.name], 'Acheter', function () {
      var r = NEBUSTION.EventManager.buyShopItem(it.id);
      if (!r.ok) { self.fx.toast('Achat refusé', r.reason || '', null); self._refreshAll(false); return; }
      self.fx.toast('Achat effectué', it.label, null);
      self._refreshAll(false);
    }, { accent: this._accent(), confirmAccent: this._accent() });
  }
};
