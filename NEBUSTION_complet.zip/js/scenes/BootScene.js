/**
 * NEBUSTION - BootScene
 * Première scène lancée. Configure le rendu et passe immédiatement
 * au Preload, qui génère toutes les textures procédurales du jeu.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.BootScene = class BootScene extends Phaser.Scene {
  constructor() {
    super('BootScene');
  }

  create() {
    this.cameras.main.setBackgroundColor('#05070f');
    this.scene.start('PreloadScene');
  }
};
