/**
 * NEBUSTION - PlanetScene
 * Base spatiale Nexus-01 : plateforme, bâtiments (Commandement, Hangar, Laboratoire, Défense),
 * 5 gisements avec portiques d'extraction animés, drones miniers, récolte au tap,
 * caisses de ravitaillement, HUD de ressources permanent.
 * Amélioration : tap sur un bâtiment (ou sur le niveau / la flèche ▲ d'un extracteur) → panneau avec coût, effet et bouton AMÉLIORER.
 */
window.NEBUSTION = window.NEBUSTION || {};

/**
 * Emplacements d'origine (longitude/latitude en degrés) des bâtiments et gisements de Nexus-01 :
 * partagés par la scène et par le générateur de planète (la base est bâtie sur des terres émergées).
 * Longitude 0° = face à la caméra au départ ; latitude 90° = pôle haut, -90° = pôle bas.
 */
NEBUSTION.PlanetLayout = {
  buildings: [
    // Vaisseau-cargo de stockage : bâtiment déjà géré par l'économie (capacité ×1,5/niveau).
    { key: 'storage', lonDeg: -34, latDeg: 34, color: 0x2dd4bf, scale: 0.9 },
    // Amplificateur quantique (module 27B) : booste la production totale de toutes les ressources.
    { key: 'amplifier', lonDeg: 34, latDeg: 34, color: 0xffa63d, scale: 0.9 },
    { key: 'symtor', lonDeg: 0, latDeg: 44, color: 0xd77cff, scale: 1.18 },
    { key: 'qg', lonDeg: 0, latDeg: 2, color: 0x5fd97a, scale: 0.92 },
    { key: 'command', lonDeg: -46, latDeg: 6, color: 0x00e5ff, scale: 1.02 },
    { key: 'lab', lonDeg: 46, latDeg: 6, color: 0x6c3ce9, scale: 0.92 },
    { key: 'hangar', lonDeg: -42, latDeg: -30, color: 0xffd166, scale: 0.88 },
    { key: 'defense', lonDeg: 42, latDeg: -30, color: 0xff4d6d, scale: 0.82 }
  ],
  nodes: {
    crystal: { lonDeg: -78, latDeg: 10 },
    metal: { lonDeg: 78, latDeg: 10 },
    energy: { lonDeg: -66, latDeg: -46 },
    core: { lonDeg: 66, latDeg: -46 },
    dust: { lonDeg: 0, latDeg: -58 }
  }
};

/**
 * Volumes 3D simplifiés des bâtiments principaux (utilisés quand on les regarde de dessus : voir
 * PlanetScene._drawBuilding3D). Empreinte au sol en pixels (e = est, n = nord, sens anti-horaire), hauteur h,
 * et `peak` = hauteur d'un toit en pointe (0 = toit plat). Sert à voir le TOIT quand on est au-dessus.
 */
(function () {
  function rect(w, d, c) { return [[-w + c, -d], [w - c, -d], [w, -d + c], [w, d - c], [w - c, d], [-w + c, d], [-w, d - c], [-w, -d + c]]; }
  function oct(r) { var a = [], i; for (i = 0; i < 8; i++) a.push([Math.cos(Math.PI / 8 + i * Math.PI / 4) * r, Math.sin(Math.PI / 8 + i * Math.PI / 4) * r]); return a; }
  NEBUSTION.PlanetLayout.foot = {
    default: { pts: rect(44, 44, 8), h: 62, peak: 0 },
    storage: { pts: rect(66, 28, 10), h: 26, peak: 0 },
    symtor: { pts: oct(50), h: 86, peak: 62 },
    command: { pts: oct(42), h: 76, peak: 20 },
    qg: { pts: rect(48, 48, 10), h: 70, peak: 0 },
    lab: { pts: oct(40), h: 62, peak: 24 },
    hangar: { pts: rect(70, 40, 9), h: 42, peak: 0 },
    defense: { pts: rect(40, 40, 8), h: 52, peak: 18 },
    amplifier: { pts: oct(36), h: 72, peak: 32 }
  };
})();

NEBUSTION.PlanetScene = class PlanetScene extends Phaser.Scene {
  constructor(key) {
    super(key || 'PlanetScene');   // ExoPlanetScene (planètes du système solaire) hérite de ce moteur de sphère
  }

  init(data) {
    // Ouverture directe d'une structure précise (ex. depuis la planète-mère sur l'écran
    // Galaxie) : on n'atterrit plus juste sur Nexus-01 en laissant chercher le bon bâtiment.
    this._pendingOpenKey = (data && data.openBuilding) || null;
  }

  create() {
    var w = this.scale.width, h = this.scale.height;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(300, 5, 7, 15);

    this.nodes = {}; this.drones = []; this.pod = null; this._podTimer = 0; this._ambient = 0;
    this._buildingBoxes = {}; this._buildingDefs = {};
    this._infoPanelKey = null; this._panelOpen = false; this._upAcc = 0;

    // --- Planète en 3D : état de rotation (voir _buildSphere / _projectSphere / _setupPlanetDrag) ---
    this._sphereAnchors = []; this._terrainAnchors = [];
    this._rotYaw = 0; this._rotPitch = -0.16;
    this._rotVelYaw = 0; this._rotVelPitch = 0;
    this._dragging = false; this._dragMoved = 0; this._idleTime = 0;
    this._cloudRot = 0; this._lastRend = null; this._sphereImg = null; this._sphereR = null; this._slowCount = 0;
    this._structs = {}; this._placing = null; this._sheetOpen = false; this._barOpen = false; this._sheetAcc = 0;

    NEBUSTION.SceneBackground.build(this, { withPlanet: false });
    this._buildGuardianHero();
    this.fx = new NEBUSTION.FX(this);

    // Premier vrai passage "en jeu" : on coupe l'intro et on lance la musique
    // de fond spatiale (une seule fois, pas à chaque retour sur la planète).
    if (!window.__nebustionGameEntered) {
      window.__nebustionGameEntered = true;
      try { if (window.nebustionExtraAudio) window.nebustionExtraAudio.stopIntro(); } catch (_) {}
      try { if (window.nebustionBgMusic) window.nebustionBgMusic.start(); } catch (_) {}
    }

    this._buildSphere();
    this._buildBuildings();
    this._buildNodes();
    this._buildDrones();
    this._buildHeader();
    this._buildInfoPanel();
    this._setupPlanetDrag();
    if (this._initBuild) this._initBuild();   // constructions à placement libre (PlanetBuildUI.js)
    this._applySphereTransform();

    if (this._pendingOpenKey) {
      var openKey = this._pendingOpenKey;
      this.time.delayedCall(260, () => this.openUpgrade(openKey));
    }

    this.beamGfx = this.add.graphics().setDepth(1049);
    this.hud = NEBUSTION.HUD.attach(this);
    new NEBUSTION.BottomNav(this, 'planet');

    this._schedulePod();
    this.events.once('shutdown', () => {
      if (this.pod) this.pod.destroy(); this.pod = null;
      if (this._guardianFadeMask) { this._guardianFadeMask.destroy(); this._guardianFadeMask = null; }
    });
  }

  /**
   * Héros gardien : le meilleur héros de l'équipe (le plus puissant) veille sur Nexus-01,
   * immense et en transparence tout au fond du décor, comme une divinité qui observe la
   * base depuis l'espace. Rendu en mode additif à faible opacité : les étoiles et nébuleuses
   * restent toujours visibles à travers lui, aucune surface opaque n'est jamais ajoutée.
   */
  _buildGuardianHero() {
    var w = this.scale.width, h = this.scale.height;
    var H = NEBUSTION.Heroes, C = NEBUSTION.Combat;
    if (!H || !C) return;

    var heroId = null;
    try {
      var team = C.getTeam() || [];
      if (!team.length && C.defaultTeam) team = C.defaultTeam();
      var bestPower = -1;
      team.forEach(function (id) {
        var def = H.get(id);
        if (!def) return;
        var lvl = C.heroLevel ? C.heroLevel(id) : 1;
        var power = H.statsAtLevel(def, lvl).power;
        if (power > bestPower) { bestPower = power; heroId = id; }
      });
    } catch (e) { heroId = null; }
    if (!heroId) return;

    var key = H.portraitKey(heroId);
    if (!this.textures.exists(key)) return;

    var cx = w / 2, topY = 190;
    var portraitH = (NEBUSTION.HeroTextures && NEBUSTION.HeroTextures.PORTRAIT_H) || 380;
    var scale = (h * 0.6) / portraitH;

    // Aura douce derrière le héros, pour renforcer la présence divine sans jamais masquer le fond.
    var halo = this.add.image(cx, topY + h * 0.24, 'tex_glow_cyan')
      .setScale(3.6).setAlpha(0.15).setBlendMode(Phaser.BlendModes.ADD).setDepth(-56).setTint(0x8fd8ff);
    this.tweens.add({ targets: halo, alpha: 0.24, scale: 3.9, duration: 3600, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });

    var guardian = this.add.image(cx, topY, key)
      .setOrigin(0.5, 0)
      .setScale(scale)
      .setAlpha(0.17)
      .setBlendMode(Phaser.BlendModes.ADD)
      .setTint(0xcfe9ff)
      .setDepth(-55);

    // Le portrait est une image rectangulaire pleine (fond opaque) : sans masque, ses bords
    // tranchent net contre les étoiles. On applique un fondu doux sur les 4 côtés pour que
    // le héros se dissolve progressivement dans le décor, sans aucun contour visible.
    var maskKey = this._ensureGuardianFadeMask();
    var maskImg = this.make.image({ x: cx, y: topY, key: maskKey, add: false }).setOrigin(0.5, 0).setScale(scale);
    guardian.setMask(maskImg.createBitmapMask());
    this._guardianFadeMask = maskImg;

    // Dérive lente et respiration discrète : le gardien est vivant, jamais figé, jamais envahissant.
    this.tweens.add({ targets: guardian, y: topY - 16, duration: 5400, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    this.tweens.add({ targets: guardian, alpha: 0.23, duration: 3200, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });

    this._guardianHero = guardian;
    this._guardianHalo = halo;
  }

  /**
   * Génère (une seule fois, mise en cache par clé de texture) un masque de fondu doux :
   * blanc opaque au centre, transparent sur les 4 bords. Utilisé pour dissoudre les bords
   * rectangulaires nets des portraits de héros (PNG à fond plein) quand ils sont affichés
   * en grand format et en transparence, comme le héros gardien.
   */
  _ensureGuardianFadeMask() {
    var key = 'tex_guardian_fade';
    if (this.textures.exists(key)) return key;
    var w = (NEBUSTION.HeroTextures && NEBUSTION.HeroTextures.PORTRAIT_W) || 300;
    var h = (NEBUSTION.HeroTextures && NEBUSTION.HeroTextures.PORTRAIT_H) || 380;
    var tex = this.textures.createCanvas(key, w, h);
    var ctx = tex.context;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, h);
    ctx.globalCompositeOperation = 'destination-in';

    // Fondu vertical : marge fine en haut (la tête se détache déjà sur le ciel), large en bas
    // (c'est le bord qui tranchait le plus net contre la plateforme/l'espace).
    var topF = h * 0.12, botF = h * 0.32;
    var vGrad = ctx.createLinearGradient(0, 0, 0, h);
    vGrad.addColorStop(0, 'rgba(0,0,0,0)');
    vGrad.addColorStop(topF / h, 'rgba(0,0,0,1)');
    vGrad.addColorStop(1 - botF / h, 'rgba(0,0,0,1)');
    vGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = vGrad;
    ctx.fillRect(0, 0, w, h);

    // Fondu horizontal : mêmes marges à gauche et à droite.
    var sideF = w * 0.28;
    var hGrad = ctx.createLinearGradient(0, 0, w, 0);
    hGrad.addColorStop(0, 'rgba(0,0,0,0)');
    hGrad.addColorStop(sideF / w, 'rgba(0,0,0,1)');
    hGrad.addColorStop(1 - sideF / w, 'rgba(0,0,0,1)');
    hGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = hGrad;
    ctx.fillRect(0, 0, w, h);

    ctx.globalCompositeOperation = 'source-over';
    tex.refresh();
    return key;
  }

  _buildHeader() {
    var w = this.scale.width;

    // Retour explicite vers le menu central : Nexus ne doit jamais être une impasse.
    // Placé en haut à gauche, hors de la zone des bâtiments et du HUD.
    var back = new NEBUSTION.Button(this, 92, 145, {
      width: 150, height: 46, label: '← MENU CENTRAL',
      accentColor: 0x394869, fontSize: '14px',
      onClick: () => {
        try { if (this.fx) this.fx.vibrate(15); } catch (_) {}
        this.scene.start('MainMenuScene');
      }
    });
    back.setDepth(1200);

    this.add.text(w / 2, 138, 'NEXUS-01', {
      fontFamily: 'Arial, sans-serif', fontSize: '28px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(50).setShadow(0, 0, '#00e5ff', 10, true, true);

    this.add.text(w / 2, 170, 'Touchez un gisement pour récolter', {
      fontFamily: 'Arial, sans-serif', fontSize: '19px', color: '#8ea0c8'
    }).setOrigin(0.5).setDepth(50);
  }

  /**
   * Nexus-01 est une vraie planète en 3D que l'on tourne du doigt (voir _setupPlanetDrag). Le corps
   * est une sphère texturée (océans, continents, nuages, villes côté nuit — voir utils/PlanetRender.js)
   * recalculée quand la rotation change ; bâtiments, gisements, drones et constructions sont posés à la
   * surface (longitude/latitude), inclinés selon la normale du sol et cachés dès qu'ils passent derrière.
   */
  _buildSphere() {
    var w = this.scale.width, h = this.scale.height;
    this._planetCX = w / 2;
    this._planetCY = h * 0.56;
    this._planetR = w * 0.42;

    var ADD = Phaser.BlendModes.ADD;
    var cx = this._planetCX, cy = this._planetCY, R = this._planetR;

    // Atmosphère : halos lumineux autour du globe (le liséré de bord est déjà dans la texture).
    this.add.image(cx, cy, 'tex_glow_cyan').setBlendMode(ADD).setTint(0x2fb8ff)
      .setDisplaySize(R * 2.7, R * 2.7).setAlpha(0.20).setDepth(-6);
    this.add.image(cx, cy - R * 0.06, 'tex_glow_white').setBlendMode(ADD).setTint(0x66d8ff)
      .setDisplaySize(R * 2.25, R * 2.25).setAlpha(0.15).setDepth(-5);

    // Reliefs vectoriels : uniquement pour le repli si le canvas est indisponible.
    var seed = 42, rnd = function () { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; };
    for (var i = 0; i < 14; i++) {
      this._terrainAnchors.push({ lonDeg: rnd() * 360 - 180, latDeg: rnd() * 150 - 75, rw: 26 + rnd() * 46, rh: 12 + rnd() * 22 });
    }

    var st = (NEBUSTION.Settings && NEBUSTION.Settings.get && NEBUSTION.Settings.get()) || {};
    this._sphereRes = (st.batterySaver || st.reducedFX) ? 160 : 192;
    this._sphereR = this._makeSphereRenderer(this._sphereRes);

    // Calque vectoriel au-dessus du corps : liséré du bord et pastilles lumineuses posées au sol.
    this._sphereGfx = this.add.graphics().setDepth(0);
    // Vue 3D « de dessus » des bâtiments principaux (toit / murs), au-dessus des dessins de profil.
    this._roofGfx = this.add.graphics().setDepth(81); this._roofDirty = false;
  }

  /** Crée (ou recrée à une autre résolution) le rendu texturé de la planète ; null → repli vectoriel. */
  _makeSphereRenderer(res) {
    var L = NEBUSTION.PlanetLayout, anchors = L.buildings.map(function (b) { return { lon: b.lonDeg, lat: b.latDeg }; });
    Object.keys(L.nodes).forEach(function (k) { anchors.push({ lon: L.nodes[k].lonDeg, lat: L.nodes[k].latDeg }); });
    var r = null;
    try { r = NEBUSTION.PlanetRender ? NEBUSTION.PlanetRender.create(this, res, anchors) : null; } catch (e) { r = null; }
    if (!r) return null;
    var size = this._planetR * 2 * res / (res - 3);
    if (this._sphereImg) this._sphereImg.setTexture(r.key);
    else this._sphereImg = this.add.image(this._planetCX, this._planetCY, r.key).setDepth(-1);
    this._sphereImg.setDisplaySize(size, size);
    this._lastRend = null;
    return r;
  }

  /** Si le calcul de la sphère est trop lent sur cet appareil, on baisse sa résolution (256 → 192 → 160). */
  _adaptSphereRes() {
    var r = this._sphereR;
    if (!r) return;
    if (r.avgMs > 12 && this._sphereRes > 160) this._slowCount++; else this._slowCount = 0;
    if (this._slowCount > 24) {
      this._slowCount = 0;
      this._sphereRes = this._sphereRes > 192 ? 192 : 160;
      var nr = this._makeSphereRenderer(this._sphereRes);
      if (nr) this._sphereR = nr;
    }
  }

  /**
   * Projette un point (longitude/latitude en degrés, fixe à la surface de Nexus-01) à l'écran,
   * selon la rotation courante de la planète. Projection orthographique.
   * Renvoie x/y écran, z (>0 = face visible, <0 = derrière le globe), échelle et opacité (fondu près du
   * bord), profondeur d'affichage, la normale à l'écran (nx, ny) et l'inclinaison `rot` à donner à un objet
   * posé là (il « pousse » perpendiculairement au sol ; ux/uy = son vecteur « haut » à l'écran).
   */
  _projectSphere(lonDeg, latDeg) {
    var lon = lonDeg * Math.PI / 180, lat = latDeg * Math.PI / 180;
    return this._projectVec(Math.cos(lat) * Math.sin(lon), Math.sin(lat), Math.cos(lat) * Math.cos(lon));
  }

  _projectVec(x0, y0, z0) {
    var cyaw = Math.cos(this._rotYaw), syaw = Math.sin(this._rotYaw);
    var xa = x0 * cyaw + z0 * syaw;
    var za = -x0 * syaw + z0 * cyaw;

    var cpit = Math.cos(this._rotPitch), spit = Math.sin(this._rotPitch);
    var yb = y0 * cpit - za * spit;
    var zb = y0 * spit + za * cpit;

    var R = this._planetR, t = (zb + 1) / 2;
    // Bâtiments et gisements POSÉS SUR LE SOL : ils poussent dans la direction de la normale du sol, donc ils
    // s'écartent du centre du globe sur les côtés (comme de vrais bâtiments sur une sphère). L'inclinaison est
    // continue (aucun saut) et plafonnée à MAX_TILT : jamais couchés à plat ni à l'envers en bas de la planète.
    // Rien d'autre ne les fait bouger : la base reste collée au sol, sans retard ni balancement.
    var MAX_TILT = 1.15;   // radians (~66°) : 0 = toujours droit ; plus grand = plus couché sur les côtés
    var len = Math.sqrt(xa * xa + yb * yb);
    var k = Math.min(1, Math.max(0, (len - 0.08) / 0.32)); k = k * k * (3 - 2 * k);
    var tilt = len > 1e-6 ? MAX_TILT * (xa / len) * k : 0;
    return {
      x: this._planetCX + xa * R,
      y: this._planetCY - yb * R,
      z: zb, nx: xa, ny: yb,
      scale: 0.55 + 0.45 * t,
      alpha: Phaser.Math.Clamp((zb + 0.12) / 0.30, 0, 1),
      depth: Math.round(zb * 80),
      rot: tilt, ux: Math.sin(tilt), uy: -Math.cos(tilt),
      roofT: (function () { var q = Math.min(1, Math.max(0, (zb - 0.80) / 0.16)); return q * q * (3 - 2 * q); })()
    };
  }

  /** Rotation courante de la planète appliquée à un vecteur (repère caméra : x droite, y haut, z vers nous). */
  _rotVec(x0, y0, z0) {
    var cyaw = Math.cos(this._rotYaw), syaw = Math.sin(this._rotYaw);
    var xa = x0 * cyaw + z0 * syaw, za = -x0 * syaw + z0 * cyaw;
    var cp = Math.cos(this._rotPitch), sp = Math.sin(this._rotPitch);
    return { x: xa, y: y0 * cp - za * sp, z: y0 * sp + za * cp };
  }

  /** Repère du sol au point (lon, lat) : E = est, N = nord (dans le repère caméra) ; la normale V vient de la projection. */
  _basis(lonDeg, latDeg, p) {
    var lo = lonDeg * Math.PI / 180, la = latDeg * Math.PI / 180;
    var sl = Math.sin(la), cl = Math.cos(la), so = Math.sin(lo), co = Math.cos(lo);
    p.E = this._rotVec(co, 0, -so);
    p.N = this._rotVec(-sl * so, cl, -sl * co);
    p.V = { x: p.nx, y: p.ny, z: p.z };
  }

  _shade(hex, m) {
    var r = Math.min(255, ((hex >> 16) & 255) * m), g = Math.min(255, ((hex >> 8) & 255) * m), b = Math.min(255, (hex & 255) * m);
    return (r << 16) | (g << 8) | (b | 0);
  }
  _mixHex(a, b, t) {
    var r = ((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t, g = ((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t, bl = (a & 255) * (1 - t) + (b & 255) * t;
    return ((r | 0) << 16) | ((g | 0) << 8) | (bl | 0);
  }

  /**
   * Vue « depuis le dessus » : un vrai petit volume 3D (murs + toit) du bâtiment, projeté avec la rotation
   * de la planète. Quand on est juste au-dessus d'un bâtiment on voit son toit, sur les côtés on voit ses murs,
   * comme dans la réalité. Il remplace peu à peu le dessin de profil (fondu p.roofT) quand la planète tourne
   * pour amener le bâtiment sous la caméra. Base posée sur le sol, orientée avec le terrain (est/nord).
   */
  _drawBuilding3D(g, p, box, a) {
    var A = p.roofT * p.alpha * (box.alphaMul === undefined ? 1 : box.alphaMul);
    if (A < 0.01 || !p.E) return;
    var F = NEBUSTION.PlanetLayout.foot[a.key] || NEBUSTION.PlanetLayout.foot.default;
    var s = box.scale * p.scale * box.deco.ds, E = p.E, N = p.N, V = p.V, col = a.color;
    var X0 = p.x + box.deco.dx, Y0 = p.y + box.deco.dy, pts = F.pts, n = pts.length, i, H = F.h * s;
    var LX = -0.52, LY = 0.48, LZ = 0.70, ln = Math.sqrt(LX * LX + LY * LY + LZ * LZ); LX /= ln; LY /= ln; LZ /= ln;
    var wall = this._mixHex(0x1b2a4d, col, 0.22), roof = this._mixHex(0x2a3d68, col, 0.16);
    function cam(e, nn, h) { e *= s; nn *= s; return { x: e * E.x + nn * N.x + h * V.x, y: e * E.y + nn * N.y + h * V.y, z: e * E.z + nn * N.z + h * V.z }; }
    function scr(c) { return { x: X0 + c.x, y: Y0 - c.y }; }
    var self = this, base = [], top = [];
    for (i = 0; i < n; i++) { base.push(cam(pts[i][0], pts[i][1], 0)); top.push(cam(pts[i][0], pts[i][1], H)); }

    // Murs visibles (normale sortante tournée vers la caméra)
    for (i = 0; i < n; i++) {
      var j = (i + 1) % n, de = pts[j][0] - pts[i][0], dn = pts[j][1] - pts[i][1], dl = Math.sqrt(de * de + dn * dn) || 1;
      var oe = dn / dl, on = -de / dl;
      var nx = oe * E.x + on * N.x, ny = oe * E.y + on * N.y, nz = oe * E.z + on * N.z;
      if (nz < 0.02) continue;
      var lit = 0.30 + 0.70 * Math.max(0, nx * LX + ny * LY + nz * LZ);
      g.fillStyle(this._shade(wall, lit * 1.5), A);
      g.fillPoints([scr(base[i]), scr(base[j]), scr(top[j]), scr(top[i])], true);
      // bande lumineuse (fenêtres) à la couleur du bâtiment
      var h1 = H * 0.46, h2 = H * 0.60;
      var b1 = cam(pts[i][0], pts[i][1], h1 / s), b2 = cam(pts[j][0], pts[j][1], h1 / s), t1 = cam(pts[j][0], pts[j][1], h2 / s), t2 = cam(pts[i][0], pts[i][1], h2 / s);
      g.fillStyle(col, 0.55 * A * lit);
      g.fillPoints([scr(b1), scr(b2), scr(t1), scr(t2)], true);
      g.lineStyle(1.5, col, 0.45 * A); g.lineBetween(X0 + top[i].x, Y0 - top[i].y, X0 + top[j].x, Y0 - top[j].y);
    }

    if (F.peak > 0) {
      // Toit en pointe : faces triangulaires vers le sommet
      var apex = cam(0, 0, H / s + F.peak);
      for (i = 0; i < n; i++) {
        var k = (i + 1) % n, A1 = top[i], B1 = top[k];
        var ux = B1.x - A1.x, uy = B1.y - A1.y, uz = B1.z - A1.z, vx = apex.x - A1.x, vy = apex.y - A1.y, vz = apex.z - A1.z;
        var cx = uy * vz - uz * vy, cy = uz * vx - ux * vz, cz = ux * vy - uy * vx, cl = Math.sqrt(cx * cx + cy * cy + cz * cz) || 1;
        cx /= cl; cy /= cl; cz /= cl;
        if (cz < 0.02) continue;
        var l2 = 0.30 + 0.70 * Math.max(0, cx * LX + cy * LY + cz * LZ);
        g.fillStyle(this._shade(this._mixHex(roof, col, 0.35), l2 * 1.5), A);
        g.fillPoints([scr(A1), scr(B1), scr(apex)], true);
        g.lineStyle(1.2, col, 0.5 * A); g.lineBetween(X0 + A1.x, Y0 - A1.y, X0 + apex.x, Y0 - apex.y);
      }
      var ap = scr(apex);
      g.fillStyle(col, 0.35 * A); g.fillCircle(ap.x, ap.y, 9 * s);
      g.fillStyle(0xffffff, 0.9 * A); g.fillCircle(ap.x, ap.y, 3.5 * s);
    } else if (V.z > 0.02) {
      // Toit plat : dalle, panneau central et noyau lumineux (on le voit bien quand on est au-dessus)
      var lr = 0.30 + 0.70 * Math.max(0, V.x * LX + V.y * LY + V.z * LZ);
      var rp = [], ip = [], cp = [], sc2, ang, rr;
      for (i = 0; i < n; i++) rp.push(scr(top[i]));
      g.fillStyle(this._shade(roof, lr * 1.5), A); g.fillPoints(rp, true);
      g.lineStyle(2, col, 0.7 * A); g.strokePoints(rp, true);
      for (i = 0; i < n; i++) ip.push(scr(cam(pts[i][0] * 0.68, pts[i][1] * 0.68, H / s + 3)));
      g.fillStyle(this._shade(roof, lr * 0.85), A); g.fillPoints(ip, true);
      g.lineStyle(1.2, col, 0.4 * A); g.strokePoints(ip, true);
      var ext = 1e9; for (i = 0; i < n; i++) ext = Math.min(ext, Math.abs(pts[i][0]), Math.abs(pts[i][1]));
      rr = Math.max(8, ext * 0.42);
      for (i = 0; i < 12; i++) { ang = i / 12 * Math.PI * 2; cp.push(scr(cam(Math.cos(ang) * rr, Math.sin(ang) * rr, H / s + 6))); }
      g.fillStyle(col, 0.30 * A); g.fillPoints(cp, true);
      var cp2 = []; for (i = 0; i < 12; i++) { ang = i / 12 * Math.PI * 2; cp2.push(scr(cam(Math.cos(ang) * rr * 0.55, Math.sin(ang) * rr * 0.55, H / s + 7))); }
      g.fillStyle(col, 0.95 * A); g.fillPoints(cp2, true);
      var c0 = scr(cam(0, 0, H / s + 8)); g.fillStyle(0xffffff, 0.85 * A); g.fillCircle(c0.x, c0.y, 2.5 * s);
    }
  }


  /** Point de la surface visible sous un point de l'écran (inverse de la projection) ; null hors du disque. */
  _unprojectSphere(px, py) {
    var R = this._planetR, nx = (px - this._planetCX) / R, ny = -(py - this._planetCY) / R, d2 = nx * nx + ny * ny;
    if (d2 > 0.985) return null;
    var nz = Math.sqrt(1 - d2);
    var cp = Math.cos(this._rotPitch), sp = Math.sin(this._rotPitch), cy = Math.cos(this._rotYaw), sy = Math.sin(this._rotYaw);
    var y0 = ny * cp + nz * sp, za = nz * cp - ny * sp;
    var x0 = nx * cy - za * sy, z0 = nx * sy + za * cy;
    return { lonDeg: Math.atan2(x0, z0) * 180 / Math.PI, latDeg: Math.asin(Math.max(-1, Math.min(1, y0))) * 180 / Math.PI };
  }

  /** Corps de la planète : texture recalculée si la rotation a assez changé, sinon repli vectoriel ; puis liséré. */
  _redrawSphereBody(dirty) {
    var g = this._sphereGfx, cx = this._planetCX, cy = this._planetCY, R = this._planetR;
    var clearG = dirty || !this._sphereR;   // le calque vectoriel n'est redessiné que si nécessaire
    if (clearG) g.clear();

    if (this._sphereR) {
      var lr = this._lastRend, yw = this._rotYaw, pt = this._rotPitch, cd = this._cloudRot;
      var nowT = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
      // Au doigt (glissé/inertie) : rendu dès que ça bouge ; au repos (rotation lente, nuages) : au plus ~12/s.
      var active = this._dragging || this._rotVelYaw || this._rotVelPitch;
      var minGap = active ? 0 : 80, dRot = Math.abs(yw - (lr ? lr.y : 0)) + Math.abs(pt - (lr ? lr.p : 0));
      if (!lr || ((dRot > 0.0035 || Math.abs(cd - lr.c) > 0.006) && nowT - lr.t >= minGap)) {
        this._sphereR.render(yw, pt, cd);
        this._lastRend = { y: yw, p: pt, c: cd, t: nowT };
        this._adaptSphereRes();
      }
    } else {
      // Repli vectoriel (canvas indisponible) : disque sombre, cratères et grille.
      g.fillStyle(0x0e1730, 1); g.fillCircle(cx, cy, R);
      g.fillStyle(0x1c2f5c, 0.55); g.fillCircle(cx - R * 0.3, cy - R * 0.32, R * 0.8);
      g.fillStyle(0x05080f, 0.4); g.fillCircle(cx + R * 0.34, cy + R * 0.36, R * 0.68);
      var i, tb, p;
      for (i = 0; i < this._terrainAnchors.length; i++) {
        tb = this._terrainAnchors[i]; p = this._projectSphere(tb.lonDeg, tb.latDeg);
        if (p.alpha <= 0.03) continue;
        g.fillStyle(0x030509, 0.32 * p.alpha); g.fillEllipse(p.x, p.y, tb.rw * p.scale, tb.rh * p.scale);
      }
      g.lineStyle(1, 0x2e9eff, 0.16);
      var s, p1, p2, steps = 16, lonI, latI;
      for (lonI = -135; lonI <= 180; lonI += 45) {
        p1 = null;
        for (s = 0; s <= steps; s++) { p2 = this._projectSphere(lonI, -90 + (180 * s / steps)); if (p1 && p1.alpha > 0.04 && p2.alpha > 0.04) g.lineBetween(p1.x, p1.y, p2.x, p2.y); p1 = p2; }
      }
      for (latI = -60; latI <= 60; latI += 30) {
        p1 = null;
        for (s = 0; s <= steps * 2; s++) { p2 = this._projectSphere(-180 + (360 * s / (steps * 2)), latI); if (p1 && p1.alpha > 0.04 && p2.alpha > 0.04) g.lineBetween(p1.x, p1.y, p2.x, p2.y); p1 = p2; }
      }
    }

    if (clearG) {
      g.lineStyle(2, this._rimColor || 0x7fe6ff, 0.30);   // _rimColor : couleur d'atmosphère d'un autre monde (ExoPlanetScene)
      g.strokeCircle(cx, cy, R);
    }
  }

  /**
   * Pastille lumineuse posée sur le sol : un cercle du plan tangent à la sphère, donc une ellipse écrasée
   * dans le sens de la normale (plate au bord de la planète, ronde au centre). Ancre visuellement le bâtiment.
   */
  _drawPad(g, p, r, color, a) {
    if (p.alpha < 0.04) return;
    var len = Math.sqrt(p.nx * p.nx + p.ny * p.ny), mx = 0, my = -1;
    if (len > 0.02) { mx = p.nx / len; my = -p.ny / len; }
    var tx = -my, ty = mx, zz = Math.max(0.14, p.z), N = 22, pts = [], i, ph, c, s;
    for (i = 0; i < N; i++) {
      ph = i / N * Math.PI * 2; c = Math.cos(ph) * r; s = Math.sin(ph) * r * zz;
      pts.push({ x: p.x + tx * c + mx * s, y: p.y + ty * c + my * s });
    }
    g.fillStyle(color, 0.12 * a * p.alpha); g.fillPoints(pts, true);
    g.lineStyle(2, color, 0.6 * a * p.alpha); g.strokePoints(pts, true);
    var pts2 = [];
    for (i = 0; i < N; i++) {
      ph = i / N * Math.PI * 2; c = Math.cos(ph) * r * 0.6; s = Math.sin(ph) * r * 0.6 * zz;
      pts2.push({ x: p.x + tx * c + mx * s, y: p.y + ty * c + my * s });
    }
    g.lineStyle(1.5, color, 0.32 * a * p.alpha); g.strokePoints(pts2, true);
  }

  /**
   * Ombre au sol : le soleil est fixe (mêmes valeurs que PlanetRender). L'ombre est étirée dans le plan tangent
   * de la sphère, à l'opposé du soleil, plus une tache de contact sombre sous la dalle : le bâtiment est « posé ».
   */
  _drawGroundShadow(g, p, r, h) {
    if (p.alpha < 0.04) return;
    var LX = -0.52, LY = 0.48, LZ = 0.70, ln = Math.sqrt(LX * LX + LY * LY + LZ * LZ);
    LX /= ln; LY /= ln; LZ /= ln;
    var e = Math.max(0.25, LX * p.nx + LY * p.ny + LZ * p.z);          // sinus de la hauteur du soleil sur ce point
    var s3 = Math.sqrt(Math.max(1e-4, 1 - e * e));
    var dvx = -(LX - e * p.nx) / s3, dvy = -(LY - e * p.ny) / s3;      // direction de l'ombre dans le plan du sol
    var Lw = Math.min(h * 0.9, h * s3 / e);
    var ox = dvx * Lw, oy = -dvy * Lw;
    var len = Math.sqrt(p.nx * p.nx + p.ny * p.ny), mx = 0, my = -1;
    if (len > 0.02) { mx = p.nx / len; my = -p.ny / len; }
    var tx = -my, ty = mx, zz = Math.max(0.14, p.z), N = 14, pts = [], i, ph, c, q;
    for (i = 0; i < N; i++) {
      ph = i / N * Math.PI * 2; c = Math.cos(ph) * r; q = Math.sin(ph) * r * zz;
      var bx = p.x + tx * c + mx * q, by = p.y + ty * c + my * q;
      pts.push({ x: bx, y: by }, { x: bx + ox, y: by + oy });
    }
    pts.sort(function (a, b) { return a.x - b.x || a.y - b.y; });       // enveloppe convexe (chaîne monotone)
    function cross(o, a, b) { return (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x); }
    var lo = [], up = [], k;
    for (k = 0; k < pts.length; k++) { while (lo.length > 1 && cross(lo[lo.length - 2], lo[lo.length - 1], pts[k]) <= 0) lo.pop(); lo.push(pts[k]); }
    for (k = pts.length - 1; k >= 0; k--) { while (up.length > 1 && cross(up[up.length - 2], up[up.length - 1], pts[k]) <= 0) up.pop(); up.push(pts[k]); }
    lo.pop(); up.pop();
    var hull = lo.concat(up);
    g.fillStyle(0x000000, 0.30 * p.alpha); g.fillPoints(hull, true);
    var core = [];
    for (i = 0; i < N; i++) {
      ph = i / N * Math.PI * 2; c = Math.cos(ph) * r * 0.82; q = Math.sin(ph) * r * 0.82 * zz;
      core.push({ x: p.x + tx * c + mx * q, y: p.y + ty * c + my * q });
    }
    g.fillStyle(0x000000, 0.28 * p.alpha); g.fillPoints(core, true);    // tache de contact sous la dalle
  }

  /**
   * Applique la position/échelle/inclinaison/opacité/profondeur d'une « boîte » (bâtiment ou construction).
   * Le bâtiment est posé sur le sol : il pousse perpendiculairement à la surface de la planète (p.rot), sa
   * dalle est enfoncée un peu dans le sol le long de cette direction. Aucun écrasement : même forme partout.
   */
  _applyBox(box, p) {
    var deco = box.deco, c = box.container, visible = p.alpha > 0.02, canTap = p.z > 0.05;
    var k = box.scale * p.scale * deco.ds, sink = 7 * box.scale * p.scale;
    c.setPosition(p.x + deco.dx - p.ux * sink, p.y + deco.dy - p.uy * sink);   // la dalle s'enfonce un peu dans le sol
    c.setScale(k, k);
    c.setRotation(p.rot);
    c.setAlpha(p.alpha * (box.alphaMul === undefined ? 1 : box.alphaMul));
    c.setDepth(p.depth);
    c.setVisible(visible);
    if (box.art) { box.art.setAlpha(1 - p.roofT); box.art.setScale(1, 1 - 0.4 * p.roofT); box.art.setVisible(p.roofT < 0.995); }
    if (box.badge) { box.badge.setRotation(-p.rot); box.badge.setScale(1, 1); }   // le niveau reste lisible, à l'endroit
    if (box.hit && canTap !== box.tapEnabled) { box.tapEnabled = canTap; box.hit.input.enabled = canTap; }
  }

  /**
   * Repositionne tout ce qui est posé sur la sphère d'après la rotation courante : profondeur (avant/arrière),
   * échelle, inclinaison selon le sol, fondu, pastille au sol, et interactivité coupée pour ce qui est caché
   * derrière la planète. Le dépôt des drones suit le Commandement. Appelée chaque frame.
   */
  _applySphereTransform() {
    var g = this._sphereGfx, anchors = this._sphereAnchors, i, a, p, visible, canTap;
    // Pastilles et ombres au sol : redessinées seulement si la planète a tourné, si on place un bâtiment,
    // si la liste a changé, ou au moins toutes les 400 ms (planète immobile = presque aucun dessin).
    var nowT = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
    var ps = this._padState || (this._padState = { y: NaN, p: NaN, n: -1, t: 0 });
    var padsDirty = !this._sphereR || !!this._placing || !!this._ghostBox || ps.y !== this._rotYaw || ps.p !== this._rotPitch ||
      ps.n !== anchors.length || nowT - ps.t > 400;
    if (padsDirty) { ps.y = this._rotYaw; ps.p = this._rotPitch; ps.n = anchors.length; ps.t = nowT; }
    this._redrawSphereBody(padsDirty);
    var rg = this._roofGfx;
    if (rg && this._roofDirty) { rg.clear(); this._roofDirty = false; }

    for (i = 0; i < anchors.length; i++) {
      a = anchors[i];
      p = this._projectSphere(a.lonDeg, a.latDeg);

      if (a.type === 'node') {
        var node = a.ref, dx = node._deco.dx;
        visible = p.alpha > 0.02; canTap = p.z > 0.05;
        node.x = p.x; node.y = p.y;
        node.container.setPosition(p.x + dx, p.y).setScale(p.scale).setRotation(p.rot).setAlpha(p.alpha).setDepth(p.depth).setVisible(visible);
        // L'étiquette (niveau, flèche, charges) reste à l'endroit mais se place du côté OPPOSÉ au portique
        // (sous lui quand il est droit, au-dessus s'il est à l'envers, sur le côté s'il est couché).
        var hox = -p.ux * (60 + 90 * Math.abs(p.ux)) * p.scale, hoy = (-p.uy - 1) * 50 * p.scale;
        node.hud.setPosition(p.x + dx + hox, p.y + hoy).setScale(p.scale).setAlpha(p.alpha).setDepth(p.depth + 1).setVisible(visible);
        node.zone.setPosition(p.x + p.ux * 60 * p.scale, p.y + p.uy * 60 * p.scale).setDepth(p.depth);
        node.upZone.setPosition(p.x + hox, p.y + 40 * p.scale + hoy).setDepth(p.depth + 2);
        if (canTap !== node._tapEnabled) {
          node._tapEnabled = canTap;
          node.zone.input.enabled = canTap;
          node.upZone.input.enabled = canTap;
        }
        if (padsDirty) this._drawPad(g, p, 46 * p.scale, node.def.color, 0.8);
      } else {
        var box = a.box || this._buildingBoxes[a.key];
        this._applyBox(box, p);
        if (rg && a.type === 'building' && p.roofT > 0.01) {
          this._basis(a.lonDeg, a.latDeg, p);
          this._drawBuilding3D(rg, p, box, a);
          this._roofDirty = true;
        }
        var padA = 1;
        if (a.ghost) padA = 1.6;
        else if (padsDirty) this._drawGroundShadow(g, p, (a.padR || 60) * p.scale * 0.95, (a.key === 'storage' ? 40 : (a.type === 'struct' ? 72 : 105)) * box.scale * p.scale);
        if (padsDirty) this._drawPad(g, p, (a.padR || 60) * p.scale, a.ghost ? (this._placing && this._placing.valid ? 0x5dff9a : 0xff5b6e) : a.color, padA);
      }
    }

    var cmdBox = this._buildingBoxes.command;
    if (cmdBox) {
      var cb = cmdBox.container;
      this.depotBase.x = cb.x + Math.sin(cb.rotation) * 120 * cb.scaleY;
      this.depotBase.y = cb.y - Math.cos(cb.rotation) * 120 * cb.scaleY;
    }
  }

  /** Rotation continue : glissement en cours, inertie à la relâche, légère rotation automatique au repos. */
  _updatePlanetRotation(delta) {
    if (!this._dragging) {
      var damp = Math.pow(0.90, delta / 16.67);
      this._rotVelYaw *= damp; this._rotVelPitch *= damp;
      if (Math.abs(this._rotVelYaw) < 0.00003) this._rotVelYaw = 0;
      if (Math.abs(this._rotVelPitch) < 0.00003) this._rotVelPitch = 0;

      this._rotYaw += this._rotVelYaw;
      var np = this._rotPitch + this._rotVelPitch;
      if (np > 0.85 || np < -0.85) this._rotVelPitch = 0;
      this._rotPitch = Phaser.Math.Clamp(np, -0.85, 0.85);

      if (!this._rotVelYaw && !this._rotVelPitch) {
        this._idleTime += delta;
        if (this._idleTime > 2200) this._rotYaw += 0.00007 * delta;
      } else {
        this._idleTime = 0;
      }
    }
    this._cloudRot += 0.000025 * delta;   // les nuages dérivent doucement, même planète immobile
    this._applySphereTransform();
  }

  /**
   * Glisser n'importe où sur l'écran fait tourner la planète (petit seuil de mouvement pour ne
   * jamais gêner un tap sur un bâtiment ou un gisement), avec un peu d'inertie à la relâche.
   * Sens : glisser vers la droite/le bas fait tourner la surface dans le sens du doigt, comme
   * une vraie sphère qu'on ferait rouler (inverser les signes ci-dessous si ça semble inversé).
   */
  _setupPlanetDrag() {
    var self = this;
    this.input.on('pointerdown', function (pointer) {
      if (self._uiBlocks(pointer)) return;
      self._dragging = true;
      self._dragMoved = 0;
      self._dragLastX = pointer.x; self._dragLastY = pointer.y;
      self._rotVelYaw = 0; self._rotVelPitch = 0;
    });
    this.input.on('pointermove', function (pointer) {
      if (!self._dragging || !pointer.isDown) return;
      var dx = pointer.x - self._dragLastX, dy = pointer.y - self._dragLastY;
      self._dragLastX = pointer.x; self._dragLastY = pointer.y;
      self._dragMoved += Math.abs(dx) + Math.abs(dy);
      if (self._dragMoved < 20) return;
      var sens = 0.0062;
      self._rotYaw += dx * sens;
      self._rotPitch = Phaser.Math.Clamp(self._rotPitch + dy * sens, -0.85, 0.85);
      self._rotVelYaw = dx * sens; self._rotVelPitch = dy * sens;
      self._idleTime = 0;
    });
    this.input.on('pointerup', function (pointer) {
      // Tap (pas de glissé) en mode placement : la construction se pose à l'endroit touché.
      if (self._dragging && self._placing && self._dragMoved < 20 && self._onPlacementTap) self._onPlacementTap(pointer);
      self._dragging = false; self._idleTime = 0;
    });
    this.input.on('pointerupoutside', function () { self._dragging = false; });
  }

  /** Vrai si le toucher tombe sur un panneau ouvert en bas de l'écran (il ne doit pas faire tourner la planète). */
  _uiBlocks(pointer) {
    var h = this.scale.height, top = h;
    if (this._panelOpen) top = Math.min(top, h - 360);   // panneau d'amélioration : y ouvert = h-210, haut = -150
    if (this._sheetOpen) top = Math.min(top, h - 470 - (this._sheetExtra || 0));   // catalogue : centre h-300, demi-hauteur 170
    if (this._barOpen) top = Math.min(top, h - 300);     // barre de placement / gestion : centre h-215, demi-hauteur 85
    return pointer.y > top;
  }

  _buildBuildings() {
    var R = NEBUSTION.Resources, E = NEBUSTION.Economy;

    // Bâtiments répartis sur toute la sphère de Nexus-01 (plus seulement à plat sur le dessus) :
    // chacun a une longitude/latitude fixe à la surface de la planète, projetée à l'écran selon
    // la rotation courante (_projectSphere). Le SYMTOR reste au sommet, bien visible ; les autres
    // occupent les flancs et l'hémisphère arrière/inférieur, révélés en tournant la planète.
    var buildings = NEBUSTION.PlanetLayout.buildings.map(function (b) { return Object.assign({}, b); });

    buildings.forEach((b) => {
      b.label = b.key === 'symtor' ? 'Symtor' : E.BUILDINGS[b.key].name;
      // Décalage décoratif (survol/appui/rebond d'amélioration) appliqué PAR-DESSUS la position
      // et l'échelle imposées chaque frame par la sphère — jamais en conflit avec elles.
      b._deco = { dx: 0, dy: 0, ds: 1 };
      var p0 = this._projectSphere(b.lonDeg, b.latDeg);
      var container = this.add.container(p0.x, p0.y).setScale(b.scale).setDepth(p0.depth);
      this._drawBuilding(container, b);
      // Le dessin de profil est rangé dans un sous-conteneur (`art`) pour pouvoir se fondre avec la vue 3D de dessus.
      var artC = this.add.container(0, 0);
      artC.add(container.list.slice());
      container.add(artC);

      var hit = this.add.zone(0, -20, 120, 140).setOrigin(0.5).setInteractive({ useHandCursor: true });
      container.add(hit);

      this._buildingBoxes[b.key] = { container: container, art: artC, scale: b.scale, hit: hit, deco: b._deco, tapEnabled: true };
      this._buildingDefs[b.key] = b;
      this._sphereAnchors.push({ type: 'building', key: b.key, lonDeg: b.lonDeg, latDeg: b.latDeg, color: b.color, padR: 58 * b.scale });

      hit.on('pointerover', () => this.tweens.add({ targets: b._deco, ds: 1.06, duration: 120 }));
      hit.on('pointerout', () => this.tweens.add({ targets: b._deco, ds: 1, duration: 120 }));
      hit.on('pointerdown', () => {
        if (this._placing || this._sheetOpen) return;   // pas de panneau pendant qu'on place une construction
        this.tweens.add({ targets: b._deco, ds: 0.96, duration: 60, yoyo: true });
        this._showInfoPanel(b);
      });

      var beacon = this.add.circle(0, b.key === 'storage' ? -82 : (b.topY || -110), 4, b.color, 1).setBlendMode(Phaser.BlendModes.ADD);
      artC.add(beacon);
      this.tweens.add({ targets: beacon, alpha: 0.2, duration: 700 + Math.random() * 500, yoyo: true, repeat: -1 });
      // Skin de bâtiment équipé (module Personnalisation) : balise recolorée + aura et effet animé.
      var bSkin = NEBUSTION.SkinManager && NEBUSTION.SkinManager.equippedSkin('building', b.key);
      if (bSkin) {
        if (beacon.setFillStyle) beacon.setFillStyle(bSkin.aura, 1);
        NEBUSTION.SkinFX.attach(this, container, null, bSkin, 120, 150, { x: 0, y: -50 });
      }

      var badgeLevel = b.key === 'symtor' ? (NEBUSTION.SymbioteManager.state().built ? 'SYMBIOTE • BIO' : 'SYMTOR • À CONSTRUIRE') : ('Nv.' + R.level(b.key));
      var badgeY = b.key === 'symtor' ? -184 : (b.key === 'storage' ? -90 : (b.topY ? b.topY - 18 : -128));
      var badge = this.add.text(0, badgeY, badgeLevel, {
        fontFamily: 'Arial, sans-serif', fontSize: b.key === 'symtor' ? '15px' : '14px', fontStyle: 'bold',
        color: b.key === 'symtor' ? '#ffffff' : '#0b1224',
        backgroundColor: b.key === 'symtor' ? '#6f20a8' : '#eaf2ff', padding: { x: 8, y: 3 },
        stroke: b.key === 'symtor' ? '#d77cff' : undefined, strokeThickness: b.key === 'symtor' ? 2 : 0
      }).setOrigin(0.5);
      container.add(badge);
      this._buildingBoxes[b.key].badge = badge;
    });

    // Point de dépôt des drones : suit le sommet du Commandement, mis à jour chaque frame
    // par _applySphereTransform (valeur initiale ici, au centre de la planète).
    this.depotBase = { x: this._planetCX, y: this._planetCY };
  }

  _drawBuilding(container, b) {
    var g = this.add.graphics();
    var color = b.color;

    // Vaisseau-cargo dédié au Stockage : une silhouette de vaisseau en vol stationnaire,
    // pas un immeuble — coque allongée, conteneurs de fret sur le dos, réacteurs pulsants.
    if (b.key === 'storage') {
      // Vaisseau POSÉ au sol : ombre de contact, deux vérins d'atterrissage et patins.
      g.fillStyle(0x000000, 0.34);
      g.fillEllipse(-5, 21, 156, 16);
      g.lineStyle(6, 0x0e2f31, 1);
      g.lineBetween(-52, 2, -62, 19); g.lineBetween(46, 2, 56, 19);
      g.lineStyle(2, color, 0.7);
      g.lineBetween(-52, 2, -62, 19); g.lineBetween(46, 2, 56, 19);
      g.fillStyle(0x1c5a5c, 1);
      g.fillRoundedRect(-78, 17, 30, 5, 2); g.fillRoundedRect(38, 17, 30, 5, 2);
      g.lineStyle(1.5, color, 0.8);
      g.strokeRoundedRect(-78, 17, 30, 5, 2); g.strokeRoundedRect(38, 17, 30, 5, 2);

      // Ailerons arrière.
      g.fillStyle(0x0e2f31, 1);
      g.fillTriangle(-70, -34, -98, -8, -70, -4);
      g.fillTriangle(-70, 0, -98, 28, -70, 24);
      g.lineStyle(2, color, 0.6);
      g.strokeTriangle(-70, -34, -98, -8, -70, -4);
      g.strokeTriangle(-70, 0, -98, 28, -70, 24);

      // Coque principale, effilée vers l'avant (à droite).
      g.fillGradientStyle(0x123c40, 0x1c5a5c, 0x08181a, 0x08181a, 1);
      g.fillRoundedRect(-76, -32, 148, 38, 17);
      g.lineStyle(2.5, color, 0.9);
      g.strokeRoundedRect(-76, -32, 148, 38, 17);

      // Nez effilé.
      g.fillStyle(0x1c5a5c, 1);
      g.beginPath();
      g.moveTo(70, -28); g.lineTo(98, -12); g.lineTo(70, 4); g.closePath();
      g.fillPath();
      g.lineStyle(2.5, color, 0.9);
      g.beginPath();
      g.moveTo(70, -28); g.lineTo(98, -12); g.lineTo(70, 4); g.closePath();
      g.strokePath();

      // Verrière du cockpit, lumineuse.
      g.fillStyle(0xcdfff5, 0.9);
      g.fillEllipse(54, -12, 22, 12);

      // Conteneurs de fret arrimés sur le dos — le « stockage » lui-même, bien visible.
      var crateColors = [0xffd166, 0xff6ec7, 0xc9d4ea];
      for (var i = 0; i < 3; i++) {
        g.fillStyle(crateColors[i], 0.92);
        g.fillRoundedRect(-58 + i * 39, -54, 32, 22, 5);
        g.lineStyle(1.5, 0x0a1224, 0.55);
        g.strokeRoundedRect(-58 + i * 39, -54, 32, 22, 5);
      }

      // Sabords lumineux le long de la coque.
      g.fillStyle(0x9ffff0, 0.85);
      for (var p = 0; p < 4; p++) g.fillCircle(-46 + p * 26, -13, 3);

      var ship = this.add.container(0, -20);   // coque relevée sur ses vérins : les patins touchent le sol (y = 0)
      container.add(ship);
      ship.add(g);

      var label = this.add.text(0, -12, 'RAVITAILLEUR', {
        fontFamily: 'Arial, sans-serif', fontSize: '11px', fontStyle: '900', color: '#eaf2ff',
        stroke: '#08181a', strokeThickness: 3
      }).setOrigin(0.5);
      ship.add(label);

      // Réacteurs arrière : lueur additive pulsante.
      var jet1 = this.add.circle(-84, -18, 7, color, 0.85).setBlendMode(Phaser.BlendModes.ADD);
      var jet2 = this.add.circle(-84, -2, 7, color, 0.85).setBlendMode(Phaser.BlendModes.ADD);
      ship.add([jet1, jet2]);
      this.tweens.add({ targets: [jet1, jet2], alpha: 0.35, scale: 1.5, duration: 480 + Math.random() * 200, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });

      return;
    }

    // Design organique dédié au SYMTOR : silhouette plus haute, capsule centrale,
    // tentacules et noyau vivant violet. Les autres bâtiments gardent leur design techno.
    if (b.key === 'symtor') {
      g.fillStyle(0x000000, 0.42);
      g.fillEllipse(0, 8, 150, 34);

      // Aura extérieure.
      g.fillStyle(0x6b21a8, 0.16);
      g.fillCircle(0, -72, 92);
      g.lineStyle(4, 0xf0a6ff, 0.8);
      g.strokeCircle(0, -72, 72);
      g.lineStyle(2, 0x7b2cff, 0.55);
      g.strokeCircle(0, -72, 88);

      // Base bio-mécanique.
      g.fillGradientStyle(0x35115f, 0x5e1d88, 0x0a1024, 0x120b25, 1);
      g.fillRoundedRect(-62, -18, 124, 28, 12);
      g.lineStyle(3, color, 0.95);
      g.strokeRoundedRect(-62, -18, 124, 28, 12);

      // Capsule vivante.
      g.fillGradientStyle(0x8c2be8, 0xd65cff, 0x240b42, 0x0c0719, 1);
      g.fillRoundedRect(-38, -128, 76, 116, 30);
      g.lineStyle(3, 0xf0a6ff, 0.95);
      g.strokeRoundedRect(-38, -128, 76, 116, 30);
      g.fillStyle(0xeaa7ff, 0.72);
      g.fillEllipse(0, -73, 25, 60);
      g.fillStyle(0xffffff, 0.95);
      g.fillCircle(-8, -84, 5);

      // Tentacules asymétriques.
      g.lineStyle(9, 0x4d146f, 0.95);
      g.beginPath(); g.moveTo(-38, -36); g.lineTo(-68, -4); g.lineTo(-82, -34); g.strokePath();
      g.beginPath(); g.moveTo(38, -38); g.lineTo(68, -6); g.lineTo(84, -38); g.strokePath();
      g.lineStyle(5, 0xd77cff, 0.85);
      g.beginPath(); g.moveTo(-30, -24); g.lineTo(-45, 8); g.lineTo(-58, -6); g.strokePath();
      g.beginPath(); g.moveTo(30, -24); g.lineTo(48, 7); g.lineTo(60, -10); g.strokePath();

      // Couronne / énergie au sommet.
      g.lineStyle(4, 0xd77cff, 0.9);
      g.lineBetween(0, -128, 0, -154);
      g.fillStyle(0xffffff, 1);
      g.fillCircle(0, -157, 7);
      g.fillStyle(0xd77cff, 0.3);
      g.fillCircle(0, -157, 18);

      // Plaque nominative intégrée au bâtiment.
      g.fillStyle(0x090617, 0.95);
      g.fillRoundedRect(-58, -5, 116, 22, 7);
      g.lineStyle(2, 0xd77cff, 0.9);
      g.strokeRoundedRect(-58, -5, 116, 22, 7);
      container.add(g);

      var label = this.add.text(0, -73, 'SYMTOR', {
        fontFamily: 'Arial, sans-serif', fontSize: '16px', fontStyle: '900', color: '#ffffff',
        stroke: '#5d1a86', strokeThickness: 5
      }).setOrigin(0.5);
      container.add(label);

      // Pulsation permanente du noyau et des tentacules.
      var pulse = this.add.circle(0, -73, 20, 0xf0a6ff, 0.16).setBlendMode(Phaser.BlendModes.ADD);
      container.add(pulse);
      this.tweens.add({ targets: pulse, scale: 1.55, alpha: 0.02, duration: 950, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
      return;
    }

    this._drawIsoBuilding(container, g, b);
  }

  // ---- Teintes utilitaires (multiplication / mélange de couleurs 0xRRGGBB) ----
  _shade(c, f) {
    var r = Math.min(255, Math.round(((c >> 16) & 255) * f)), gg = Math.min(255, Math.round(((c >> 8) & 255) * f)), bb = Math.min(255, Math.round((c & 255) * f));
    return (r << 16) | (gg << 8) | bb;
  }
  _mixColor(a, b, t) {
    var r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t), gg = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t), bb = Math.round((a & 255) * (1 - t) + (b & 255) * t);
    return (r << 16) | (gg << 8) | bb;
  }

  /**
   * Bâtiments 3D (vue isométrique) : chaque bâtiment est fait de volumes à 3 faces (gauche sombre, droite
   * moyenne, toit clair), fenêtres allumées en perspective, arêtes néon, dalle lumineuse, ombre portée,
   * et un couronnement propre à sa fonction (QG à étages, radar, dôme de labo, hangar, tourelle).
   * Renseigne b.topY (sommet visible) pour placer la balise et le badge de niveau.
   */
  _drawIsoBuilding(container, g, b) {
    var self = this, color = b.color, key = b.key, ADD = Phaser.BlendModes.ADD;
    var seed = key.charCodeAt(0) * 17 + key.length * 31 + 3;
    function rnd() { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; }
    function P(A, B, u, v, h) { return { x: A.x + (B.x - A.x) * u, y: A.y + (B.y - A.y) * u - v * h }; }
    function poly(pts, fill, a) { g.fillStyle(fill, a); g.fillPoints(pts, true); }
    function fq(A, B, h, u0, u1, v0, v1, fill, a) { poly([P(A, B, u0, v0, h), P(A, B, u1, v0, h), P(A, B, u1, v1, h), P(A, B, u0, v1, h)], fill, a); }
    function face(A, B, h, fill) {
      poly([A, B, { x: B.x, y: B.y - h }, { x: A.x, y: A.y - h }], fill, 1);
      fq(A, B, h, 0, 1, 0, 0.22, 0x000000, 0.30);      // ombrage : plus sombre au pied
      fq(A, B, h, 0, 1, 0.22, 0.5, 0x000000, 0.12);
      fq(A, B, h, 0, 1, 0.9, 1, 0xffffff, 0.07);       // léger reflet en haut
    }
    function windows(A, B, h, cols, rows, alpha) {
      var cw = 0.76 / cols, ch = 0.74 / rows;
      for (var r = 0; r < rows; r++) for (var c = 0; c < cols; c++) {
        var u0 = 0.12 + c * cw + cw * 0.16, u1 = 0.12 + (c + 1) * cw - cw * 0.16, v0 = 0.12 + r * ch + ch * 0.2, v1 = 0.12 + (r + 1) * ch - ch * 0.2;
        var lit = rnd() > 0.22;
        fq(A, B, h, u0, u1, v0, v1, lit ? self._mixColor(color, 0xffffff, 0.35) : 0x0a1224, lit ? alpha : 0.85);
      }
    }
    function box(cx, by, hw, h, base, wc, wr) {
      var dy = hw * 0.5;
      var L = { x: cx - hw, y: by }, F = { x: cx, y: by + dy }, Rr = { x: cx + hw, y: by }, Bk = { x: cx, y: by - dy };
      face(L, F, h, self._shade(base, 0.5));
      face(F, Rr, h, self._shade(base, 0.8));
      var T = [{ x: L.x, y: L.y - h }, { x: F.x, y: F.y - h }, { x: Rr.x, y: Rr.y - h }, { x: Bk.x, y: Bk.y - h }];
      poly(T, self._shade(base, 1.3), 1);
      if (wc) { windows(L, F, h, wc, wr, 0.6); windows(F, Rr, h, wc, wr, 0.95); }
      g.lineStyle(2, color, 0.95); g.strokePoints(T, true);
      g.lineStyle(2.5, color, 0.9); g.lineBetween(F.x, F.y, F.x, F.y - h);
      g.lineStyle(1.5, color, 0.45); g.lineBetween(L.x, L.y, L.x, L.y - h); g.lineBetween(Rr.x, Rr.y, Rr.x, Rr.y - h);
      g.lineStyle(1.5, color, 0.5); g.lineBetween(L.x, L.y, F.x, F.y); g.lineBetween(F.x, F.y, Rr.x, Rr.y);
      return { L: L, F: F, R: Rr, Bk: Bk, h: h, hw: hw, dy: dy, top: { x: cx, y: by - h } };
    }

    // halo néon derrière le bâtiment
    container.add(this.add.image(0, -36, 'tex_glow_white').setTint(color).setDisplaySize(200, 150).setAlpha(0.2).setBlendMode(ADD));

    // ombre portée + dalle de fondation lumineuse
    g.fillStyle(0x000000, 0.42); g.fillEllipse(8, 24, 156, 48);
    var slab = box(0, 4, 64, 9, 0x1a2745, 0, 0);
    var ins = [{ x: slab.top.x - 52, y: slab.top.y }, { x: slab.top.x, y: slab.top.y + 26 }, { x: slab.top.x + 52, y: slab.top.y }, { x: slab.top.x, y: slab.top.y - 26 }];
    g.lineStyle(1.5, color, 0.5); g.strokePoints(ins, true);

    var by = -5, tip = -108, dish = null, orb = null, dishY = 0;
    var base = self._mixColor(0x2a3d66, color, 0.22);

    if (key === 'qg') {
      // Quartier général : trois étages en gradins + mât d'antenne
      var q1 = box(0, by, 48, 40, base, 3, 3);
      var q2 = box(0, by - 40, 34, 30, self._shade(base, 1.1), 2, 2);
      poly([{ x: -18, y: q2.top.y }, { x: 0, y: q2.top.y + 9 }, { x: 18, y: q2.top.y }, { x: 0, y: q2.top.y - 9 }], color, 0.5);
      g.lineStyle(3, color, 0.95); g.lineBetween(0, q2.top.y, 0, q2.top.y - 32);
      g.fillStyle(color, 1); g.fillCircle(0, q2.top.y - 34, 4);
      g.lineStyle(2, 0xffffff, 0.8); g.lineBetween(-9, q2.top.y - 22, 9, q2.top.y - 22);
      tip = q2.top.y - 34;
    } else if (key === 'command') {
      // Centre de commandement : haute tour + radar rotatif
      box(0, by, 42, 24, base, 3, 1);
      var c2 = box(0, by - 24, 30, 54, self._shade(base, 1.1), 2, 4);
      g.lineStyle(3, color, 0.9); g.lineBetween(16, c2.top.y + 2, 16, c2.top.y - 20);
      g.fillStyle(0xff6a78, 1); g.fillCircle(16, c2.top.y - 21, 3);
      dishY = c2.top.y - 2; tip = c2.top.y - 32;
    } else if (key === 'lab') {
      // Laboratoire : bloc vitré + dôme énergétique
      var l1 = box(0, by, 44, 46, base, 3, 3);
      var ty = l1.top.y;
      g.fillStyle(0x0a1224, 0.9); g.fillEllipse(0, ty, 54, 27);
      g.lineStyle(2.5, color, 0.95); g.strokeEllipse(0, ty, 54, 27);
      g.fillStyle(self._mixColor(color, 0xffffff, 0.35), 0.28); g.fillEllipse(0, ty - 15, 48, 46);
      g.lineStyle(2, self._mixColor(color, 0xffffff, 0.5), 0.9); g.strokeEllipse(0, ty - 15, 48, 46);
      g.fillStyle(0xffffff, 0.35); g.fillEllipse(-10, ty - 26, 10, 16);
      g.lineStyle(3, color, 0.9); g.lineBetween(0, ty - 38, 0, ty - 54);
      g.fillStyle(0xffffff, 1); g.fillCircle(0, ty - 55, 3.5);
      orb = { x: 0, y: ty - 14 }; tip = ty - 56;
    } else if (key === 'hangar') {
      // Hangar : long volume bas, grande porte à chevrons, toit à nervure
      var h1 = box(0, by, 54, 38, base, 0, 0);
      windows(h1.L, h1.F, h1.h, 3, 1, 0.6);
      // porte sur la face droite
      fq(h1.F, h1.R, h1.h, 0.16, 0.84, 0, 0.66, 0x070c18, 1);
      for (var s = 0; s < 6; s++) fq(h1.F, h1.R, h1.h, 0.16 + s * 0.113, 0.16 + s * 0.113 + 0.056, 0, 0.66, color, 0.55);
      fq(h1.F, h1.R, h1.h, 0.16, 0.84, 0.66, 0.72, color, 0.95);
      var h2 = box(0, by - 38, 38, 10, self._shade(base, 1.15), 0, 0);
      g.lineStyle(3, color, 0.9); g.lineBetween(-24, h2.top.y - 2, -24, h2.top.y - 26); g.lineBetween(26, h2.top.y - 2, 26, h2.top.y - 18);
      g.fillStyle(color, 1); g.fillCircle(-24, h2.top.y - 27, 3.5); g.fillCircle(26, h2.top.y - 19, 3);
      tip = h2.top.y - 28;
    } else if (key === 'amplifier') {
      // Amplificateur quantique : pylône fin surmonté d'anneaux d'énergie concentriques pulsants
      // et d'un noyau lumineux — silhouette bien distincte des autres bâtiments techno.
      var am1 = box(0, by, 34, 30, base, 2, 2);
      var pylonTopY = am1.top.y - 66;
      g.lineStyle(4, color, 0.95); g.lineBetween(0, am1.top.y, 0, pylonTopY);
      for (var ri = 0; ri < 3; ri++) {
        g.lineStyle(3 - ri * 0.6, color, 0.85 - ri * 0.2);
        g.strokeEllipse(0, pylonTopY - ri * 13, 46 - ri * 7, 17 - ri * 3);
      }
      g.fillStyle(0xffffff, 1); g.fillCircle(0, pylonTopY - 30, 5);
      g.fillStyle(color, 0.32); g.fillCircle(0, pylonTopY - 30, 17);
      orb = { x: 0, y: pylonTopY - 30 }; tip = pylonTopY - 34;
    } else {
      // Défense : bunker blindé + tourelle jumelée
      var d1 = box(0, by, 46, 34, self._mixColor(0x2a2f45, color, 0.2), 2, 2);
      var ty2 = d1.top.y;
      g.fillStyle(0x000000, 0.35); g.fillEllipse(0, ty2, 44, 22);
      g.fillStyle(0x2b3350, 1); g.fillRect(-19, ty2 - 16, 38, 16); g.fillEllipse(0, ty2, 38, 19);
      g.fillStyle(0x3e4a70, 1); g.fillEllipse(0, ty2 - 16, 38, 19);
      g.lineStyle(2, color, 0.95); g.strokeEllipse(0, ty2 - 16, 38, 19);
      g.lineStyle(8, 0x1d2238, 1); g.lineBetween(4, ty2 - 19, 32, ty2 - 33); g.lineBetween(-2, ty2 - 12, 26, ty2 - 26);
      g.lineStyle(3, color, 0.95); g.lineBetween(4, ty2 - 19, 32, ty2 - 33); g.lineBetween(-2, ty2 - 12, 26, ty2 - 26);
      g.fillStyle(0xffffff, 0.9); g.fillCircle(32, ty2 - 33, 3);
      // pointes de blindage aux angles
      poly([{ x: -46, y: by }, { x: -54, y: by - 22 }, { x: -40, y: by - 6 }], color, 0.85);
      poly([{ x: 46, y: by }, { x: 54, y: by - 22 }, { x: 40, y: by - 6 }], color, 0.85);
      tip = ty2 - 36;
    }

    container.add(g);
    b.topY = Math.max(-118, tip);

    if (dishY) {   // radar : la parabole « tourne » (écrasement horizontal en boucle)
      var dg = this.add.graphics();
      dg.lineStyle(3, color, 0.9); dg.lineBetween(0, 0, 0, -8);
      dg.fillStyle(this._mixColor(color, 0xffffff, 0.5), 0.95); dg.fillEllipse(0, -12, 38, 15);
      dg.lineStyle(2, color, 1); dg.strokeEllipse(0, -12, 38, 15);
      dg.fillStyle(0xffffff, 1); dg.fillCircle(0, -14, 2.5);
      dg.setPosition(0, dishY);
      container.add(dg);
      this.tweens.add({ targets: dg, scaleX: 0.25, duration: 1500, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    }
    if (orb) {     // labo : noyau énergétique qui pulse dans le dôme
      var core = this.add.image(orb.x, orb.y, 'tex_glow_white').setTint(color).setDisplaySize(40, 40).setBlendMode(ADD).setAlpha(0.9);
      var spark = this.add.circle(orb.x, orb.y, 6, 0xffffff, 0.95).setBlendMode(ADD);
      container.add([core, spark]);
      this.tweens.add({ targets: core, scale: core.scale * 1.5, alpha: 0.35, duration: 900 + Math.random() * 300, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
      this.tweens.add({ targets: spark, alpha: 0.4, duration: 600, yoyo: true, repeat: -1 });
    }
  }

  /** Éclair sur le Commandement quand un drone y dépose sa cargaison. */
  flashTower(color) {
    var box = this._buildingBoxes.command;
    if (!box || box.flashing || !box.container.visible || box.container.alpha < 0.3) return;
    box.flashing = true;
    var f = this.add.image(box.container.x + Math.sin(box.container.rotation) * 90 * box.container.scaleY, box.container.y - Math.cos(box.container.rotation) * 90 * box.container.scaleY, 'tex_glow_crystal').setScale(3.2).setAlpha(0.55).setBlendMode(Phaser.BlendModes.ADD).setDepth(1045).setTint(color);
    this.tweens.add({ targets: f, alpha: 0, duration: 420, onComplete: () => { f.destroy(); box.flashing = false; } });
  }

  // ---------- Gisements & drones ----------
  _buildNodes() {
    var E = NEBUSTION.Economy;
    // Gisements répartis sur les flancs et l'hémisphère inférieur de la sphère (près du bord
    // à l'écran, comme avant, mais désormais de vraies positions 3D qui tournent avec la planète).
    var spots = NEBUSTION.PlanetLayout.nodes;
    E.ORDER.forEach((id) => {
      var s = spots[id], p0 = this._projectSphere(s.lonDeg, s.latDeg);
      var node = new NEBUSTION.ResourceNode(this, this.fx, id, p0.x, p0.y);
      node.lonDeg = s.lonDeg; node.latDeg = s.latDeg;
      this.nodes[id] = node;
      this._sphereAnchors.push({ type: 'node', key: id, lonDeg: s.lonDeg, latDeg: s.latDeg, ref: node });
    });
  }

  _buildDrones() {
    var R = NEBUSTION.Resources, E = NEBUSTION.Economy, cmd = NEBUSTION.PlanetLayout.buildings.filter(function (b) { return b.key === 'command'; })[0];
    E.ORDER.forEach((id, i) => {
      var visible = Math.min(R.droneCount(id), 3);   // 3 drones animés max par gisement (performances)
      for (var k = 0; k < visible; k++) {
        // Dépôt au-dessus du Commandement, en coordonnées de la planète : le drone le suit quand elle tourne.
        var depot = { lonDeg: cmd.lonDeg + (i - 2) * 2.4 + k * 0.9, latDeg: cmd.latDeg + Math.abs(i - 2) * 0.7 - k * 0.6, altPx: 130 + k * 12 };
        this.drones.push(new NEBUSTION.MiningDrone(this, this.fx, this.nodes[id], depot, i + k * 5));
      }
    });
  }

  // ---------- Récolte ----------
  harvest(node, pointer) {
    if (this._placing || this._sheetOpen) return;
    var R = NEBUSTION.Resources, E = NEBUSTION.Economy, fx = this.fx;
    var res = R.tap(node.id, Date.now());
    var px = node.x, py = node.y - 96;
    if (res.ok) {
      node.pulse();
      fx.burst(node.id, node.topX, node.topY, res.crit ? 26 : 9);
      fx.gain(node.id, res.amount, px, py, res.crit);
      if (res.crit) {
        fx.ring(node.topX, node.topY, node.def.color, 1.5);
        fx.text(px, py - 46, 'CRITIQUE !', '#ffffff', 26, 40);
        fx.shake(110, 0.003);
        fx.vibrate(25);
      } else {
        fx.vibrate(8);
      }
    } else if (res.reason === 'full') {
      node.shakeDenied();
      fx.text(px, py, 'Stockage plein', '#ff8fa3', 24, 50);
    } else if (res.reason === 'empty') {
      node.shakeDenied();
      fx.text(px, py, 'Recharge… ' + Math.ceil(res.wait) + ' s', '#9fb0d6', 22, 40);
    }
  }

  // ---------- Caisses de ravitaillement ----------
  _schedulePod() {
    var E = NEBUSTION.Economy, st = NEBUSTION.Resources.state.stats;
    var interval = Phaser.Math.Between(E.CFG.POD_MIN_SEC, E.CFG.POD_MAX_SEC) * 1000;
    // Balise(s) de ravitaillement du QG (module 28) : réduit l'attente entre deux caisses (plafonné à 50 %).
    var qm = NEBUSTION.QGGridManager;
    var podCut = qm ? Math.min(0.5, qm.bonusValue('podRate')) : 0;
    interval = Math.round(interval * (1 - podCut));
    this._podAt = Math.max(Date.now() + 4000, st.lastPod + interval);
  }

  _spawnPod() {
    var panelOpen = this._infoPanel && this._infoPanel.y < this.scale.height + 100;
    var slots = [{ x: 245, y: 640 }, { x: 475, y: 640 }];
    if (!panelOpen) slots.push({ x: 240, y: 950 }, { x: 480, y: 950 });
    var s = Phaser.Utils.Array.GetRandom(slots);
    this.pod = new NEBUSTION.SupplyPod(this, this.fx, s.x, s.y, (claimed) => {
      this.pod = null;
      this._schedulePod();
    });
  }

  // ---------- Boucle ----------
  update(time, delta) {
    this._updatePlanetRotation(delta);

    var id;
    for (id in this.nodes) this.nodes[id].update(delta);

    this.beamGfx.clear();
    for (var i = 0; i < this.drones.length; i++) {
      this.drones[i].update(time, delta);
      // Pas de laser tracé vers un gisement actuellement caché derrière la planète.
      if (this.drones[i].node.container.visible) this.drones[i].drawBeam(this.beamGfx, time);
    }
    var sk;
    for (sk in this._structs) { if (this._structs[sk].anim && this._structs[sk].container.visible) this._structs[sk].anim(time); }
    if (this._ghostBox && this._ghostBox.anim) this._ghostBox.anim(time);
    if (this._sheetOpen) { this._sheetAcc += delta; if (this._sheetAcc > 300) { this._sheetAcc = 0; this._refreshCatalog(); } }

    // Poussière/vapeur d'énergie ambiante sur les gisements
    this._ambient -= delta;
    if (this._ambient <= 0) {
      this._ambient = 380;
      for (id in this.nodes) {
        var n = this.nodes[id];
        if (!n.container.visible || n.container.alpha < 0.4) continue;   // rien derrière la planète
        this.fx.sparkle(id, n.x + (Math.random() - 0.5) * 60, n.y - 70 + Math.random() * 30);
      }
    }

    if (this.pod) this.pod.update();
    else if (Date.now() >= this._podAt) this._spawnPod();

    // Panneau d'amélioration ouvert : coûts / disponibilité rafraîchis en direct (les ressources montent en continu)
    if (this._panelOpen) {
      this._upAcc += delta;
      if (this._upAcc >= 150) { this._upAcc = 0; this._refreshUpgrade(); }
    }
  }

  // ---------- Panneau d'info + amélioration (bâtiments ET extracteurs) ----------
  _buildInfoPanel() {
    var w = this.scale.width, h = this.scale.height;
    var panel = this.add.container(w / 2, h + 260).setDepth(1100);
    var TOP = -150, PH = 230;   // le fond va de y=-150 à y=+80 (le bas reste collé à la barre de navigation)

    var bg = this.add.graphics();
    bg.fillGradientStyle(0x101a33, 0x101a33, 0x0a1020, 0x0a1020, 0.98);
    bg.fillRoundedRect(-w * 0.42, TOP, w * 0.84, PH, 20);
    bg.lineStyle(2, 0x2e9eff, 0.6);
    bg.strokeRoundedRect(-w * 0.42, TOP, w * 0.84, PH, 20);
    panel.add(bg);
    panel.add(this.add.rectangle(0, TOP + PH / 2, w * 0.84, PH, 0x000000, 0.001).setInteractive());   // bloque les taps vers les gisements

    var title = this.add.text(-w * 0.36, -124, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '26px', fontStyle: 'bold', color: '#eaf2ff'
    }).setOrigin(0, 0.5);
    var level = this.add.text(-w * 0.36, -92, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '19px', color: '#8ea0c8'
    }).setOrigin(0, 0.5);
    var info = this.add.text(-w * 0.36, -62, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '17px', color: '#c8d4f0', wordWrap: { width: w * 0.72 }
    }).setOrigin(0, 0.5);
    var effect = this.add.text(-w * 0.36, -34, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '18px', fontStyle: 'bold', color: '#7dffb0', wordWrap: { width: w * 0.72 }
    }).setOrigin(0, 0.5);
    panel.add([title, level, info, effect]);

    // Coût : jusqu'à 3 ressources (icône + montant), rouge quand il en manque
    this._costSlots = [];
    for (var k = 0; k < 3; k++) {
      var ci = this.add.image(0, -3, 'tex_icon_crystal').setDisplaySize(28, 28).setVisible(false);
      var ct = this.add.text(0, -3, '', { fontFamily: 'Arial, sans-serif', fontSize: '21px', fontStyle: 'bold', color: '#eaf2ff' }).setOrigin(0, 0.5).setVisible(false);
      panel.add([ci, ct]);
      this._costSlots.push({ icon: ci, text: ct });
    }

    // Accès aux skins du bâtiment sélectionné (module Personnalisation).
    var skinsLink = this.add.text(w * 0.36, -92, 'Skins ›', {
      fontFamily: 'Arial, sans-serif', fontSize: '19px', fontStyle: 'bold', color: '#b47bff'
    }).setOrigin(1, 0.5).setInteractive({ useHandCursor: true });
    skinsLink.on('pointerdown', () => {
      if (this._infoPanelKey && this._buildingDefs[this._infoPanelKey]) this.scene.start('SkinsScene', { tab: 'building', targetId: this._infoPanelKey, from: 'PlanetScene' });
    });
    panel.add(skinsLink);

    // Accès à l'intérieur du QG (Sécurité de zone) ou au vol libre depuis le Hangar : uniquement
    // visible sur ces deux bâtiments, placé juste à gauche du lien Skins (qui reste accessible aussi).
    var enterLink = this.add.text(w * 0.36, -92, 'Entrer ›', {
      fontFamily: 'Arial, sans-serif', fontSize: '19px', fontStyle: 'bold', color: '#5fd97a'
    }).setOrigin(1, 0.5).setInteractive({ useHandCursor: true }).setVisible(false);
    enterLink.on('pointerdown', () => {
      if (this._infoPanelKey === 'symtor') { this.scene.start('SymbioteScene'); return; }
      if (this._infoPanelKey === 'hangar') {
        if (NEBUSTION.FlightZoneManager && NEBUSTION.FlightZoneManager.hasShip()) { this.scene.start('ShipFlightScene'); }
        else { this.fx.toast('Aucun vaisseau', 'Acquiers un vaisseau au Hangar avant de pouvoir piloter.'); }
        return;
      }
      this.scene.start('QGScene');
    });
    panel.add(enterLink);
    this._infoPanelEnter = enterLink;

    var closeBtn = this.add.text(w * 0.36, -124, '✕', {
      fontFamily: 'Arial, sans-serif', fontSize: '30px', color: '#a9b8dc'
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });
    closeBtn.on('pointerdown', () => this._hideInfoPanel());
    panel.add(closeBtn);

    var upgradeBtn = new NEBUSTION.Button(this, 0, 44, {
      width: w * 0.7, height: 54, label: 'AMÉLIORER', accentColor: 0x7dffb0, fontSize: '19px',
      onClick: () => this._doUpgrade()
    });
    panel.add(upgradeBtn);

    this._infoPanel = panel;
    this._infoPanelTitle = title;
    this._infoPanelLevel = level;
    this._infoPanelInfo = info;
    this._infoPanelEffect = effect;
    this._infoPanelSkins = skinsLink;
    this._upgradeBtn = upgradeBtn;
    this._panelClosedY = h + 260;
    this._panelOpenY = h - 210;
  }

  /** Ouvre le panneau d'amélioration d'un extracteur (appelé par ResourceNode : tap sur son niveau / la flèche ▲). */
  openUpgrade(key) {
    var E = NEBUSTION.Economy, def = E.BUILDINGS[key];
    if (!def || this._placing || this._sheetOpen) return;
    this._showInfoPanel({ key: key, label: def.name });
  }

  _showInfoPanel(building) {
    var E = NEBUSTION.Economy, def = E.BUILDINGS[building.key];
    this._infoPanelKey = building.key;
    this._infoPanelTitle.setText(building.label);
    if (building.key === 'symtor') {
      var ss = NEBUSTION.SymbioteManager.state();
      var cost = NEBUSTION.SymbioteManager.buildingCost();
      this._infoPanelInfo.setText(ss.built ? (ss.capsuleOpened ? 'Le symbiote vit dans le bâtiment. Nourris-le et fais-le évoluer.' : 'Une capsule organique attend son ouverture.') : 'Nouveau bâtiment vivant : construit le Symtor pour héberger une créature symbiote.');
      this._infoPanelSkins.setVisible(false);
      this._infoPanelEnter.setVisible(ss.built);
      this._infoPanelEnter.setText('Entrer ›');
      this._infoPanelEnter.setX(this._infoPanelSkins.x);
      this._panelOpen = true;
      this._lastUp = {};
      this._refreshUpgrade();
      this.tweens.add({ targets: this._infoPanel, y: this._panelOpenY, duration: 320, ease: 'Back.easeOut' });
      return;
    }
    var info = def.info || '';
    if (def.resource) {
      var n = NEBUSTION.Resources.droneCount(def.resource);
      info = E.RES[def.resource].name + '  •  ' + n + ' drone' + (n > 1 ? 's' : '') + ' minier' + (n > 1 ? 's' : '');
    }
    this._infoPanelInfo.setText(info);
    this._infoPanelSkins.setVisible(!!this._buildingDefs[building.key]);
    var isQG = building.key === 'qg';
    var isHangar = building.key === 'hangar';
    this._infoPanelEnter.setVisible(isQG || isHangar);
    this._infoPanelEnter.setText(isHangar ? 'Piloter ›' : 'Entrer ›');
    if (isQG || isHangar) {
      // Se place juste à gauche du lien Skins s'il est visible, sinon prend sa place.
      var gap = 18;
      var skinsX = this._infoPanelSkins.visible ? (this._infoPanelSkins.x - this._infoPanelSkins.width - gap) : this._infoPanelSkins.x;
      this._infoPanelEnter.setX(skinsX);
    }
    this._panelOpen = true;
    this._lastUp = {};
    this._refreshUpgrade();
    this.tweens.add({ targets: this._infoPanel, y: this._panelOpenY, duration: 320, ease: 'Back.easeOut' });
  }

  _hideInfoPanel() {
    this._panelOpen = false;
    this.tweens.add({ targets: this._infoPanel, y: this._panelClosedY, duration: 250, ease: 'Sine.easeIn' });
  }

  /** Met à jour un texte seulement s'il a changé (évite de redessiner le canvas du texte 7 fois par seconde). */
  _setText(obj, str, key) {
    if (this._lastUp[key] === str) return;
    this._lastUp[key] = str;
    obj.setText(str);
  }

  /** Niveau, effet, coût et état du bouton — appelé à l'ouverture, après chaque amélioration, puis toutes les 150 ms. */
  _refreshUpgrade() {
    var key = this._infoPanelKey;
    if (!key) return;
    var R = NEBUSTION.Resources, E = NEBUSTION.Economy;
    if (key === 'symtor') {
      var ss = NEBUSTION.SymbioteManager.state(), c = NEBUSTION.SymbioteManager.buildingCost();
      this._setText(this._infoPanelLevel, ss.built ? 'Bâtiment construit' : 'Construction requise', 'lvl');
      this._setText(this._infoPanelEffect, ss.built ? ('Défense symbiote +' + NEBUSTION.SymbioteManager.defense()) : 'Héberge une créature évolutive', 'eff');
      this._costSlots.forEach(function(slot){ slot.icon.setVisible(false); slot.text.setVisible(false); });
      var keys2 = Object.keys(c), total2=0, gap2=22, i2;
      for(i2=0;i2<keys2.length;i2++){ var id2=keys2[i2], slot2=this._costSlots[i2]; slot2.icon.setTexture('tex_icon_'+id2).setDisplaySize(28,28); this._setText(slot2.text,E.fmt(c[id2],0),'symct'+i2); slot2.text.setColor(R.get(id2)>=c[id2]?'#eaf2ff':'#ff8fa3'); slot2.icon.setVisible(!ss.built); slot2.text.setVisible(!ss.built); total2 += 28+6+slot2.text.width+(i2?gap2:0); }
      var x2=-total2/2; for(i2=0;i2<keys2.length;i2++){var sl2=this._costSlots[i2];sl2.icon.x=x2+14;sl2.text.x=x2+34;x2+=28+6+sl2.text.width+gap2;}
      var canBuy=!ss.built && R.canAfford(c);
      this._setText(this._upgradeBtn.labelText, ss.built ? 'OUVRIR LE SYMTOR  →' : (canBuy?'CONSTRUIRE LE SYMTOR':'CONSTRUIRE (ressources insuffisantes)'), 'btn');
      this._upgradeBtn.setLook(ss.built?0xd77cff:(canBuy?0x7dffb0:0x394869), '#eaf2ff');
      this._upgradeBtn.setDisabled(false);
      return;
    }
    var lvl = R.level(key), max = lvl >= E.CFG.MAX_LEVEL;
    var cost = max ? null : E.upgradeCost(key, lvl);
    var afford = !!cost && R.canAfford(cost);

    this._setText(this._infoPanelLevel, 'Niveau ' + lvl + (max ? '  •  MAXIMUM' : '  •  Statut : Opérationnel'), 'lvl');

    var eff = E.effectText(key, lvl);
    if (key === 'command' && !max && NEBUSTION.PrestigeManager && NEBUSTION.PrestigeManager.canPrestige) {
      try { var pc = NEBUSTION.PrestigeManager.canPrestige(); eff = 'Renaissance : Commandement niv. ' + pc.needCommandLevel + ' requis (actuel : ' + lvl + ')'; } catch (e) { /* texte par défaut */ }
    }
    this._setText(this._infoPanelEffect, eff, 'eff');

    // Coûts (icône + montant), centrés
    var keys = cost ? Object.keys(cost) : [], gap = 22, total = 0, i, slot, id;
    for (i = 0; i < this._costSlots.length; i++) {
      slot = this._costSlots[i];
      if (i < keys.length) {
        id = keys[i];
        slot.icon.setTexture('tex_icon_' + id);
        slot.icon.setDisplaySize(28, 28);
        this._setText(slot.text, E.fmt(cost[id], 0), 'ct' + i);
        var ok = R.get(id) + 1e-9 >= cost[id], col = ok ? '#eaf2ff' : '#ff8fa3';
        if (this._lastUp['cc' + i] !== col) { this._lastUp['cc' + i] = col; slot.text.setColor(col); }
        slot.icon.setVisible(true); slot.text.setVisible(true);
        total += 28 + 6 + slot.text.width + (i > 0 ? gap : 0);
      } else { slot.icon.setVisible(false); slot.text.setVisible(false); }
    }
    var x = -total / 2;
    for (i = 0; i < keys.length; i++) {
      slot = this._costSlots[i];
      slot.icon.x = x + 14; slot.text.x = x + 34;
      x += 28 + 6 + slot.text.width + gap;
    }

    // Bouton : vert et actif si on peut payer, sinon grisé (un tap explique ce qui manque)
    var label = max ? 'NIVEAU MAXIMUM' : (afford ? 'AMÉLIORER  →  Nv.' + (lvl + 1) : 'AMÉLIORER (ressources insuffisantes)');
    this._setText(this._upgradeBtn.labelText, label, 'btn');
    var look = max ? 'm' : (afford ? 'y' : 'n');
    if (this._lastUp.look !== look) {
      this._lastUp.look = look;
      if (look === 'y') this._upgradeBtn.setLook(0x7dffb0, '#eaf2ff');
      else this._upgradeBtn.setLook(0x394869, look === 'm' ? '#7dffb0' : '#9fb0d6');
    }
  }

  /** Tap sur AMÉLIORER : paie (tout ou rien), applique, puis effets visuels. Sinon explique ce qui manque. */
  _doUpgrade() {
    var key = this._infoPanelKey;
    if (!key || !this._panelOpen) return;
    var R = NEBUSTION.Resources, E = NEBUSTION.Economy, fx = this.fx;
    if (key === 'symtor') {
      var ss = NEBUSTION.SymbioteManager.state();
      if (!ss.built) { var br = NEBUSTION.SymbioteManager.buy(); if (br.ok) { fx.toast('SYMTOR CONSTRUIT','Entre pour ouvrir la capsule.'); this._refreshUpgrade(); return; } fx.toast('Ressources insuffisantes','Le Symtor demande 900 cristaux, 1200 métal et 700 énergie.'); return; }
      this.scene.start('SymbioteScene'); return;
    }
    var def = E.BUILDINGS[key];
    var res = R.upgradeBuilding(key);

    if (res.ok) {
      var box = this._buildingBoxes[key], bdef = this._buildingDefs[key];
      var node = def.resource ? this.nodes[def.resource] : null;
      var px, py, color;
      if (box) {
        box.badge.setText('Nv.' + res.level);
        px = box.container.x; py = box.container.y - 100; color = bdef.color;
        this.tweens.add({ targets: box.deco, ds: 1.12, duration: 150, yoyo: true, ease: 'Sine.easeOut' });
      } else if (node) {
        px = node.x; py = node.topY; color = node.def.color;
        node.pulse();
        fx.burst(node.id, node.topX, node.topY, 34);
      }
      fx.ring(px, py, color, 2.4);
      fx.text(px, py - 20, 'NIVEAU ' + res.level, '#7dffb0', 32, 80);
      fx.shake(120, 0.003);
      fx.vibrate(30);
      fx.toast(def.name + ' amélioré', 'Niveau ' + res.level, def.resource || null);
      this._lastUp = {};
      this._refreshUpgrade();
      return;
    }

    if (res.reason === 'cost') {
      var missing = [];
      Object.keys(res.cost).forEach(function (id) {
        var need = res.cost[id] - R.get(id);
        if (need > 1e-9) missing.push({ id: id, need: need });
      });
      var shown = missing.slice(0, 2).map(function (m) { return E.fmt(Math.ceil(m.need), 0) + ' ' + E.RES[m.id].short; }).join('  •  ');
      if (missing.length > 2) shown += '  •  +' + (missing.length - 2);
      fx.toast('Ressources insuffisantes', 'Il manque : ' + shown, missing.length ? missing[0].id : null);
      this.tweens.add({ targets: this._upgradeBtn, x: 8, duration: 45, yoyo: true, repeat: 2, onComplete: () => { this._upgradeBtn.x = 0; } });
      fx.vibrate(15);
    } else if (res.reason === 'max') {
      fx.toast('Niveau maximum atteint', def.name, null);
    }
    this._refreshUpgrade();
  }
};
