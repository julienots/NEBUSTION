/**
 * NEBUSTION - QGBattleScene (MODE COMBAT) — rendu ISOMÉTRIQUE 2.5D
 * Combat en temps réel façon Clash of Clans contre le QG d'un empire ennemi. Le moteur est NEBUSTION.QGBattle (pur,
 * inchangé) ; cette scène ne fait que le DESSINER et transmettre les taps.
 *
 * Rendu (même langage visuel que le QG isométrique : plateforme flottante, vraies structures en volume) :
 *  - la base ennemie est posée sur sa plateforme iso, entourée d'un terrain de déploiement ;
 *  - chaque structure (cœur, barricades, tourelles, générateurs, silos) est un volume iso animé, avec PV, impacts,
 *    ruines et flammes quand elle tombe ;
 *  - chaque troupe a SON design dessiné (2 images de marche : Marine, Berserker à hache, Tireur, Éclaireur, Grenadier,
 *    Garde-bouclier, Casseur-bombe, Spectre, vaisseaux volants avec ombre au sol, Titan chenillé, Mécha, Croiseur),
 *    se déploie par un « largage » lumineux, marche vers sa cible en se tournant vers elle, attaque, explose, disparaît.
 * Tap = déployer la troupe choisie dans la zone verte (le sol iso est converti en coordonnées de cellule du moteur).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.QGBattleScene = class QGBattleScene extends NEBUSTION.QGScene {
  constructor() { super('QGBattleScene'); }

  init(data) { this._initData = data || {}; }

  create(data) {
    var w = this.scale.width;
    var eid = (data && data.eid) || (this._initData && this._initData.eid);
    var variant = (data && data.variant) || (this._initData && this._initData.variant) || 0;
    var Gal = NEBUSTION.Galaxy, EM = NEBUSTION.EmpireEvolutionManager, BB = NEBUSTION.BotBases, QB = NEBUSTION.QGBattle;
    if (!eid || !Gal || !Gal.empire(eid) || !EM || !BB || !QB || !NEBUSTION.TroopManager || !NEBUSTION.QGAttackManager || !NEBUSTION.QGGrid) { this.scene.start('QGScene'); return; }

    this.G = NEBUSTION.QGGrid;
    this.eid = eid;
    this.variant = variant;
    this.E = Gal.empire(eid);
    var es = EM.state(Date.now()).e[eid];
    this.profile = BB.profile(eid, es.evo);
    this.lay = QB.withWalls(BB.layout(eid, es.evo, es.hurt || 0, variant), QB.wallCount(es.evo));   // même base que QB.botBase()
    this.sim = QB.create(QB.botBase(eid, es.evo, es.hurt || 0, variant), NEBUSTION.TroopManager.stock());
    this.selected = null;
    // Mécaniques de combat additionnelles : frappe orbitale (jauge), objets (charges), escouade (formation).
    this.aimMode = null;      // null | 'strike' | { item: id } : le prochain tap sur l'arène déclenche cette action
    this.squadMode = false;   // mode « Escouade » : sélection multiple de troupes déployées en une formation
    this.squad = [];
    this._bn = {}; this._un = {}; this._seen = {};
    this._shots = []; this._booms = []; this._pings = []; this._hits = [];
    this._t = 0; this._done = false; this._sfxT = 0;

    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(250, 5, 7, 15);
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });
    this.fx = new NEBUSTION.FX(this);

    // ----- Géométrie : l'arène entière (9×9 cellules) tient dans la largeur de l'écran -----
    this._initIsoGeometry(this.E.color);
    this.ws = (w - 16) / ((QB.ARENA_MAX - QB.ARENA_MIN) * this.TW);   // échelle du monde iso
    this.K = 1 / this.ws;                                               // « 1 pixel écran » en unités monde
    this.cx = w / 2;
    this.cy = 288 + 4.5 * this.TH * this.ws + 6;                        // centre du terrain = centre de la base (espace pour la jauge de frappe + les objets)
    this.arenaBottom = this.cy + 4.5 * this.TH * this.ws;

    this._buildCellTextures();      // parcelles + volumes des structures (partagés avec le QG)
    this._buildExtraTextures();     // cœur du QG + design de chaque troupe

    this._buildHeader();
    // ----- Etat de zoom/pan : le monde (arène + base) est un container qu'on peut redimensionner sans
    // toucher au moteur QGBattle.js ni aux coordonnées « cellule » (_P), qui restent en unités locales. -----
    this.worldScale = this.ws;
    this.worldX = this.cx;
    this.worldY = this.cy;
    this.world = this.add.container(this.worldX, this.worldY).setDepth(10);
    this.world.setScale(this.worldScale);
    this._buildField();
    this._buildBuildings();
    this.fxG = this.add.graphics();
    this.world.add(this.fxG);

    this._buildTray();
    this._initZoom();
    this.input.on('pointerdown', (p) => this._onTap(p));
    this._hint = this.add.text(w / 2, this.arenaBottom + 34, 'Choisis une troupe puis tape sur la zone VERTE autour de la base pour la déployer.', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#8ea0c8', align: 'center', wordWrap: { width: w * 0.9 }
    }).setOrigin(0.5, 0).setDepth(50);
    this._refreshHud();
    this._drawZone();
  }

  // ---------- iso : cellules du moteur <-> monde <-> écran ----------
  // Monde : origine = centre de la base (3,3). x et y du moteur sont en « cellules ».
  _P(x, y) { return { x: (x - y) * this.TW / 2, y: (x + y - this.G.COLS) * this.TH / 2 }; }
  // NB : _scr / _unproject passent par worldX/worldY/worldScale (et non cx/cy/ws) pour rester justes une
  // fois que le joueur a zoomé et/ou déplacé la zone de combat (voir _initZoom ci-dessous).
  _scr(x, y, h) { var p = this._P(x, y); return { x: this.worldX + p.x * this.worldScale, y: this.worldY + (p.y - (h || 0)) * this.worldScale }; }
  _px(x, y) { return this._scr(x, y === undefined ? x : y).x; }
  _py(x, y) { return this._scr(x === undefined ? y : x, y).y; }
  _unproject(sx, sy) {
    var lx = (sx - this.worldX) / this.worldScale, ly = (sy - this.worldY) / this.worldScale;
    var u = lx / (this.TW / 2), v = ly / (this.TH / 2) + this.G.COLS;
    return { x: (v + u) / 2, y: (v - u) / 2 };
  }

  // ---------- en-tête ----------
  _buildHeader() {
    var w = this.scale.width;
    this.add.text(w / 2, 96, 'MODE COMBAT · ' + this.profile.handle, {
      fontFamily: 'Arial, sans-serif', fontSize: '22px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(50).setShadow(0, 0, this.E.hex, 10, true, true);
    this._back = this.add.text(28, 126, '‹ Retour', { fontFamily: 'Arial, sans-serif', fontSize: '16px', color: '#00e5ff' })
      .setOrigin(0, 0.5).setDepth(60).setInteractive({ useHandCursor: true });
    this._back.on('pointerdown', () => this._leave());
    var st = { fontFamily: 'Arial, sans-serif', fontSize: '18px', fontStyle: 'bold', color: '#eaf2ff' };
    this._pctText = this.add.text(w * 0.06, 176, '', st).setOrigin(0, 0.5).setDepth(50);
    this._starText = this.add.text(w / 2, 176, '', { fontFamily: 'Arial, sans-serif', fontSize: '26px', color: '#ffd166' }).setOrigin(0.5).setDepth(50);
    this._timeText = this.add.text(w * 0.94, 176, '', st).setOrigin(1, 0.5).setDepth(50);
    // Trophées de QG : total actuel du joueur, visible pendant tout le combat.
    var AM = NEBUSTION.QGAttackManager;
    this._trophyText = this.add.text(w / 2, 200, '🏆 ' + (AM ? AM.trophies() : 0), {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', fontStyle: 'bold', color: '#ffd166'
    }).setOrigin(0.5, 0).setDepth(50);
    this._buildStrikeGauge();
    this._buildItemBar();
  }

  // ---------- Frappe orbitale du Commandant : jauge + bouton (tap sur l'arène pour cibler) ----------
  _buildStrikeGauge() {
    var w = this.scale.width, self = this, y = 220;
    var c = this.add.container(w / 2, y).setDepth(52);
    var bg = this.add.graphics();
    var label = this.add.text(0, -13, '⚡ FRAPPE ORBITALE', { fontFamily: 'Arial, sans-serif', fontSize: '11px', fontStyle: 'bold', color: '#8ea0c8' }).setOrigin(0.5);
    c.add([bg, label]);
    c.setSize(210, 30).setInteractive({ useHandCursor: true });
    c.on('pointerdown', function (p, lx, ly, ev) {
      if (ev && ev.stopPropagation) ev.stopPropagation();
      if (!self.sim.strikeReady() || self._done) return;
      self.squadMode = false;
      self.aimMode = (self.aimMode === 'strike') ? null : 'strike';
      self._updateHint();
      self._redrawStrikeGauge();
    });
    this._strikeGauge = { c: c, bg: bg, label: label };
    this._redrawStrikeGauge();
  }

  _redrawStrikeGauge() {
    var g = this._strikeGauge, sim = this.sim, ready = sim.strikeReady();
    var w = 200, h = 12, pct = Math.max(0, Math.min(1, sim.strikeCharge / 100));
    g.bg.clear();
    g.bg.fillStyle(0x0d1a33, 0.85); g.bg.fillRoundedRect(-w / 2, -6, w, h, 6);
    g.bg.fillStyle(ready ? 0xffd166 : 0x4fe3ff, ready ? 1 : 0.85); g.bg.fillRoundedRect(-w / 2, -6, w * pct, h, 6);
    g.bg.lineStyle(this.aimMode === 'strike' ? 3 : 1.5, ready ? 0xffd166 : 0x3a5fa0, 1); g.bg.strokeRoundedRect(-w / 2, -6, w, h, 6);
    g.label.setColor(ready ? '#ffd166' : '#8ea0c8');
    g.label.setText(ready ? (this.aimMode === 'strike' ? '⚡ TAPE POUR BOMBARDER' : '⚡ FRAPPE PRÊTE — TAPER') : '⚡ FRAPPE ORBITALE ' + Math.round(pct * 100) + ' %');
  }

  // ---------- Objets/consommables : petite barre d'icônes avec charges restantes ----------
  _buildItemBar() {
    var w = this.scale.width, self = this;
    var defs = (NEBUSTION.CombatItems ? NEBUSTION.CombatItems.list() : []).filter(function (d) { return d.qgEffect && self.sim.items[d.id]; });
    if (!defs.length) return;
    var y = 244, cw = 44, gap = 6, totalW = defs.length * cw + (defs.length - 1) * gap, x0 = w / 2 - totalW / 2 + cw / 2;
    this._itemCards = [];
    defs.forEach(function (def, i) {
      var x = x0 + i * (cw + gap);
      var c = self.add.container(x, y).setDepth(52);
      var bg = self.add.circle(0, 0, 20, 0x0d1a33, 0.85).setStrokeStyle(1.5, 0x3a5fa0, 0.9);
      var icon = self.add.text(0, -3, def.icon, { fontFamily: 'Arial, sans-serif', fontSize: '18px' }).setOrigin(0.5);
      var ct = self.add.text(0, 15, '×' + self.sim.items[def.id].charges, { fontFamily: 'Arial, sans-serif', fontSize: '10px', fontStyle: 'bold', color: '#ffd166' }).setOrigin(0.5);
      c.add([bg, icon, ct]);
      c.setSize(40, 40).setInteractive({ useHandCursor: true });
      c.on('pointerdown', function (p, lx, ly, ev) {
        if (ev && ev.stopPropagation) ev.stopPropagation();
        if (self._done || self.sim.items[def.id].charges <= 0) return;
        self.squadMode = false;
        var same = self.aimMode && self.aimMode.item === def.id;
        self.aimMode = same ? null : { item: def.id };
        self._updateHint();
        self._redrawItemBar();
      });
      this._itemCards.push({ id: def.id, bg: bg, icon: icon, ct: ct, container: c });
    }, this);
    this._redrawItemBar();
  }

  _redrawItemBar() {
    if (!this._itemCards) return;
    var self = this;
    this._itemCards.forEach(function (k) {
      var charges = self.sim.items[k.id].charges, active = self.aimMode && self.aimMode.item === k.id;
      k.bg.setStrokeStyle(active ? 3 : 1.5, active ? 0xffd166 : 0x3a5fa0, 1);
      k.ct.setText('×' + charges);
      k.container.setAlpha(charges > 0 ? 1 : 0.35);
    });
  }

  _updateHint() {
    if (!this._hint) return;
    if (this.aimMode === 'strike') this._hint.setText('Tape sur la zone à bombarder (frappe orbitale).');
    else if (this.aimMode && this.aimMode.item) {
      var def = NEBUSTION.CombatItems.get(this.aimMode.item);
      this._hint.setText('Tape sur la zone où utiliser : ' + def.name + '.');
    } else if (this.squadMode) this._hint.setText('Escouade : choisis jusqu\'à 3 troupes puis tape la zone verte pour les déployer ensemble.');
    else this._hint.setText('Choisis une troupe puis tape sur la zone VERTE autour de la base pour la déployer.');
  }

  // ---------- terrain : champ de déploiement + plateforme flottante de la base ----------
  _buildField() {
    var QB = NEBUSTION.QGBattle, G = this.G, K = this.K, self = this;
    var pts = function (arr) { return arr.map(function (p) { return { x: p.x, y: p.y }; }); };

    // 1. terrain (aire de largage) : losange sombre quadrillé
    var floor = this.add.graphics();
    this.world.add(floor);
    var A = QB.ARENA_MIN, Z = QB.ARENA_MAX;
    var T = this._P(A, A), R = this._P(Z, A), B = this._P(Z, Z), L = this._P(A, Z);
    floor.fillStyle(0x060c1c, 0.94); floor.fillPoints(pts([T, R, B, L]), true);
    var inset = 0.22, T2 = this._P(A + inset, A + inset), R2 = this._P(Z - inset, A + inset), B2 = this._P(Z - inset, Z - inset), L2 = this._P(A + inset, Z - inset);
    floor.fillStyle(0x0a1530, 1); floor.fillPoints(pts([T2, R2, B2, L2]), true);
    floor.lineStyle(1.2 * K, 0x18345f, 0.55);
    for (var i = -1; i <= 7; i++) {
      var a = this._P(i, A + inset), b = this._P(i, Z - inset), c = this._P(A + inset, i), d = this._P(Z - inset, i);
      floor.lineBetween(a.x, a.y, b.x, b.y); floor.lineBetween(c.x, c.y, d.x, d.y);
    }
    floor.lineStyle(3 * K, this.E.color, 0.65); floor.strokePoints(pts([T, R, B, L]), true);
    floor.lineStyle(1.5 * K, 0x54e7ff, 0.22); floor.strokePoints(pts([T2, R2, B2, L2]), true);
    [T, R, B, L].forEach(function (p) { floor.fillStyle(0x7bdfff, 0.9); floor.fillCircle(p.x, p.y, 4 * K); });

    // 2. plateforme + parcelles de la base (mêmes textures/fonctions que le QG iso)
    this.baseLayer = this.add.container(-this.ox, -(this.oy + 3 * this.TH));
    this.gridLayer = this.baseLayer;                 // _buildPlatform() dessine dans this.gridLayer
    this.world.add(this.baseLayer);
    this._buildPlatform();
    this._tileNodes = {};
    var oyK = this._tileCY / this._tileTexH, N = G.COLS;
    for (var s = 0; s <= 2 * (N - 1); s++) {
      for (var col = 0; col < N; col++) {
        var row = s - col;
        if (row < 0 || row >= N) continue;
        var key = G.key(col, row), unlocked = !!this.lay.unlocked[key], sid = unlocked ? this.lay.cells[key] : null;
        var tex = sid && this.textures.exists('qgiso_pad_' + sid) ? 'qgiso_pad_' + sid : (unlocked ? 'qgiso_free' : 'qgiso_locked');
        var tp = this._tilePos(col, row);
        var img = this.add.image(tp.x, tp.y, tex).setOrigin(0.5, oyK);
        this.baseLayer.add(img);
        this._tileNodes[key] = img;
      }
    }

    // 3. socle lumineux du cœur du QG (sur le sommet commun des 4 parcelles centrales)
    var cg = this.add.graphics();
    var hw = this.TW * 0.62, hh = this.TH * 0.62;
    cg.fillStyle(0x0d2a3f, 1); cg.fillPoints(pts([{ x: 0, y: -hh }, { x: hw, y: 0 }, { x: 0, y: hh }, { x: -hw, y: 0 }]), true);
    cg.lineStyle(3 * K, 0x4fe3ff, 0.9); cg.strokePoints(pts([{ x: 0, y: -hh }, { x: hw, y: 0 }, { x: 0, y: hh }, { x: -hw, y: 0 }]), true);
    cg.lineStyle(1.5 * K, 0x4fe3ff, 0.45); cg.strokePoints(pts([{ x: 0, y: -hh * 0.7 }, { x: hw * 0.7, y: 0 }, { x: 0, y: hh * 0.7 }, { x: -hw * 0.7, y: 0 }]), true);
    this.world.add(cg);

    // 4. zone de déploiement (verte) / zone interdite (rouge) — affichée quand une troupe est choisie
    this.zoneG = this.add.graphics();
    this.world.add(this.zoneG);
    this.entLayer = this.add.container(0, 0);
    this.world.add(this.entLayer);
  }

  _drawZone() {
    var g = this.zoneG, QB = NEBUSTION.QGBattle, K = this.K, A = QB.ARENA_MIN, Z = QB.ARENA_MAX, N = this.G.COLS;
    g.clear();
    if (!this.selected || this.sim.over || this._done) return;
    var d = function (o) { return o.map(function (p) { return { x: p.x, y: p.y }; }); };
    var arena = [this._P(A, A), this._P(Z, A), this._P(Z, Z), this._P(A, Z)];
    var m = 0.25, safe = [this._P(-m, -m), this._P(N + m, -m), this._P(N + m, N + m), this._P(-m, N + m)];
    g.fillStyle(0x5fd97a, 0.1); g.fillPoints(d(arena), true);
    g.lineStyle(3 * K, 0x5fd97a, 0.8); g.strokePoints(d(arena), true);
    g.fillStyle(0xff4d4d, 0.16); g.fillPoints(d(safe), true);
    g.lineStyle(3 * K, 0xff6b6b, 0.75); g.strokePoints(d(safe), true);
  }

  // ---------- structures ----------
  _buildBuildings() {
    var G = this.G;
    this.sim.buildings.forEach((b) => {
      var p = this._P(b.x, b.y);
      var c = this.add.container(p.x, p.y);
      c.setDepth(b.x + b.y);
      var isCore = b.kind === 'core';
      var img = this.add.image(0, 2, isCore ? 'qgiso_b_core' : 'qgiso_b_' + b.kind).setOrigin(0.5, 170 / 220);
      if (isCore) img.setScale(1.15);
      c.add(img);
      if (isCore) {
        var halo = this.add.image(0, -122, 'tex_glow_white').setDisplaySize(130, 130).setTint(0x4fe3ff).setAlpha(0.6).setBlendMode(Phaser.BlendModes.ADD);
        c.add(halo);
        this._trackTween(c, this.tweens.add({ targets: halo, alpha: 0.2, duration: 900, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' }));
      } else if (G.STRUCTURES[b.kind]) {
        this._addStructureFX(c, b.kind, G.STRUCTURES[b.kind]);
      }
      this.entLayer.add(c);
      this._bn[b.id] = { b: b, c: c, img: img, x: p.x, y: p.y, last: b.hp, hitT: 0, sparkCd: 0, dead: false };
    });
  }

  _syncBuildings(dt) {
    this.sim.buildings.forEach((b) => {
      var n = this._bn[b.id];
      if (!n || n.dead) return;
      if (b.hp < n.last - 0.01) { n.hitT = 0.14; }
      n.last = b.hp;
      if (n.hitT > 0) {
        n.hitT -= dt;
        n.img.setTint(0xff9a8a);
        n.c.setPosition(n.x + (Math.random() - 0.5) * 4, n.y);
        n.sparkCd -= dt;
        if (n.sparkCd <= 0) { n.sparkCd = 0.22; var s = this._scr(b.x, b.y, 40); this.fx.burst(b.kind === 'core' ? 'crystal' : 'energy', s.x, s.y, 4); }
      } else {
        n.img.clearTint();
        n.c.setPosition(n.x, n.y);
      }
    });
  }

  _destroyBuilding(id) {
    var n = this._bn[id];
    if (!n || n.dead) return;
    n.dead = true;
    var b = n.b, K = this.K;
    if (n.c._tw) n.c._tw.forEach(function (t) { t.stop(); });
    n.c.removeAll(true);
    n.c.setPosition(n.x, n.y);
    n.c.setDepth(b.x + b.y - 0.4);
    // ruines : cratère + débris + flammes
    var g = this.add.graphics();
    var big = b.kind === 'core' ? 1.5 : 1;
    g.fillStyle(0x000000, 0.55); g.fillEllipse(0, 0, 120 * big, 58 * big);
    g.fillStyle(0x20140e, 1); g.fillEllipse(0, 0, 96 * big, 44 * big);
    g.lineStyle(2 * K, 0xff8a3d, 0.5); g.strokeEllipse(0, 0, 100 * big, 46 * big);
    [[-26, -2, 12], [18, 5, 9], [-4, 10, 8], [30, -6, 7], [-38, 7, 6]].forEach(function (r) {
      g.fillStyle(0x3a4666, 1); g.fillPoints([{ x: r[0], y: r[1] - r[2] }, { x: r[0] + r[2] * 0.9, y: r[1] }, { x: r[0], y: r[1] + r[2] * 0.4 }, { x: r[0] - r[2] * 0.8, y: r[1] }], true);
      g.fillStyle(0x1a2238, 1); g.fillPoints([{ x: r[0], y: r[1] }, { x: r[0] + r[2] * 0.9, y: r[1] }, { x: r[0], y: r[1] + r[2] * 0.4 }], true);
    });
    n.c.add(g);
    var fire = this.add.image(0, -12, 'tex_glow_white').setDisplaySize(90 * big, 70 * big).setTint(0xff8a3d).setAlpha(0.8).setBlendMode(Phaser.BlendModes.ADD);
    var core = this.add.image(0, -16, 'tex_glow_white').setDisplaySize(36 * big, 46 * big).setTint(0xffe08a).setAlpha(0.9).setBlendMode(Phaser.BlendModes.ADD);
    n.c.add([fire, core]);
    this._trackTween(n.c, this.tweens.add({ targets: fire, alpha: 0.3, scaleX: fire.scaleX * 0.75, duration: 320 + Math.random() * 260, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' }));
    this._trackTween(n.c, this.tweens.add({ targets: core, alpha: 0.4, scaleY: core.scaleY * 1.3, duration: 210 + Math.random() * 160, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' }));
    // parcelle : roussie
    if (b.key && this._tileNodes[b.key]) this._tileNodes[b.key].setTint(0x6a3a26);
    this._booms.push({ x: b.x, y: b.y, r: b.kind === 'core' ? 2.4 : (b.kind === 'wall' ? 1.1 : 1.6), ttl: 0.6, ttl0: 0.6 });
    var s = this._scr(b.x, b.y, 30);
    this.fx.burst('energy', s.x, s.y, b.kind === 'core' ? 34 : 18);
    this.fx.shake(b.kind === 'core' ? 220 : 90, b.kind === 'core' ? 0.008 : 0.004);
    if (b.kind === 'core') this.cameras.main.flash(220, 79, 227, 255);
    this._sfx('hit');
  }

  // ---------- textures : cœur du QG + design de chaque troupe ----------
  _buildExtraTextures() {
    this._genTex('qgiso_b_core', 170, 220, (g) => this._drawCore(g));
    var T = NEBUSTION.Troops;
    T.ORDER.forEach((id) => {
      var def = T.get(id);
      [0, 1].forEach((f) => this._genTex('qgtr_' + id + '_' + f, 120, 110, (g) => this._drawTroop(g, def, f)));
    });
  }

  // Cœur du QG : tour à cristal d'énergie, pylônes d'angle, anneaux orbitaux — sol au centre (85,170).
  _drawCore(g) {
    var gx = 85, gy = 170, P = function (a) { return a.map(function (p) { return { x: p[0], y: p[1] }; }); };
    g.fillStyle(0x000000, 0.4); g.fillEllipse(gx, gy + 2, 164, 70);
    this._box(g, gx, gy, 74, 10, 0x2c3852, 0x1d2740, 0x131a2c, 0x4fe3ff);
    [[-62, 0], [62, 0], [0, 30], [0, -28]].forEach((o) => {
      this._cyl(g, gx + o[0], gy + o[1] - 8, 7, 28, 0x5a6a8c, 0x3c4a68, 0x252f47, 0x6a7899, 0x4fe3ff);
      g.fillStyle(0x7bdfff, 1); g.fillCircle(gx + o[0], gy + o[1] - 38, 3);
    });
    this._box(g, gx, gy - 10, 52, 40, 0x33415f, 0x222c45, 0x161d31, 0x4fe3ff);
    g.lineStyle(2, 0x4fe3ff, 0.5);
    [10, 20, 30].forEach(function (hh) { g.lineBetween(gx - 40, gy - 10 - hh + 8, gx - 14, gy - 10 - hh + 22); });
    g.fillStyle(0x5fe39a, 1); g.fillCircle(gx + 26, gy - 20, 3); g.fillStyle(0xffc86b, 1); g.fillCircle(gx + 36, gy - 27, 2.5);
    this._cyl(g, gx, gy - 52, 30, 26, 0x4a5c88, 0x33415f, 0x1f2842, 0x5f74a6, 0x4fe3ff);
    this._band(g, gx, gy - 60, 30, 3, 0x4fe3ff, 0.9); this._band(g, gx, gy - 70, 30, 2, 0x4fe3ff, 0.6);
    this._cyl(g, gx, gy - 78, 22, 10, 0x6a7899, 0x4a5673, 0x2c3450, 0x7c8bb0, 0x4fe3ff);
    // cristal
    g.fillStyle(0x2ab4d4, 1); g.fillPoints(P([[gx, gy - 146], [gx + 17, gy - 116], [gx, gy - 90], [gx - 17, gy - 116]]), true);
    g.fillStyle(0x7fe9ff, 1); g.fillPoints(P([[gx, gy - 146], [gx + 17, gy - 116], [gx, gy - 90]]), true);
    g.fillStyle(0xd4fbff, 0.95); g.fillPoints(P([[gx, gy - 138], [gx + 7, gy - 116], [gx, gy - 100], [gx - 6, gy - 116]]), true);
    g.lineStyle(2, 0xd4fbff, 0.9); g.strokePoints(P([[gx, gy - 146], [gx + 17, gy - 116], [gx, gy - 90], [gx - 17, gy - 116]]), true);
    g.lineStyle(2, 0x4fe3ff, 0.8); g.strokeEllipse(gx, gy - 116, 70, 24);
    g.lineStyle(1.5, 0x4fe3ff, 0.5); g.strokeEllipse(gx, gy - 116, 92, 32);
  }

  // Design d'une troupe (image de marche `f` = 0/1), tournée vers la DROITE. Toile 120×110, pieds à (60, 98).
  _drawTroop(g, def, f) {
    var self = this, id = def.id, c = def.color, m = function (a, b, t) { return self._mix(a, b, t); };
    var p = { c: c, d: m(c, 0x0a0f1e, 0.5), dd: m(c, 0x05070f, 0.75), l: m(c, 0xffffff, 0.5), steel: 0x9aabcf, dark: 0x1a2238, metal: 0x3a4666, skin: 0xf1c9a5, glow: 0xa8f4ff, boot: 0x111726 };
    var CX = 60, FY = 98;
    var L = function (x1, y1, x2, y2, w, col, a) { g.lineStyle(w, col, a === undefined ? 1 : a); g.lineBetween(x1, y1, x2, y2); };
    var C = function (x, y, r, col, a) { g.fillStyle(col, a === undefined ? 1 : a); g.fillCircle(x, y, r); };
    var E = function (x, y, w, h, col, a) { g.fillStyle(col, a === undefined ? 1 : a); g.fillEllipse(x, y, w, h); };
    var R = function (x, y, w, h, col, r, a) { g.fillStyle(col, a === undefined ? 1 : a); g.fillRoundedRect(x, y, w, h, r === undefined ? 3 : r); };
    var pts = function (a) { return a.map(function (q) { return { x: q[0], y: q[1] }; }); };
    var Pg = function (a, col, al) { g.fillStyle(col, al === undefined ? 1 : al); g.fillPoints(pts(a), true); };
    var S = function (a, w, col, al) { g.lineStyle(w, col, al === undefined ? 1 : al); g.strokePoints(pts(a), true); };

    // fantassin de base (jambes qui alternent, torse, bras armé vers l'avant, tête)
    var human = function (o) {
      var s = o.s || 1, sw = (f ? 1 : -1) * 7 * s, hip = FY - 23 * s, sh = FY - 50 * s, ln = o.lean || 0;
      L(CX - 4 * s, hip, CX - 4 * s + sw, FY - 3 * s, 7 * s, p.dd); C(CX - 4 * s + sw, FY - 3 * s, 4.2 * s, p.boot);
      L(CX - 8 * s + ln, sh + 4 * s, CX - 12 * s - sw * 0.5, hip + 2 * s, 5.5 * s, p.dd);
      R(CX - 11 * s + ln, FY - 53 * s, 22 * s, 31 * s, o.torso || p.c, 5 * s);
      R(CX - 11 * s + ln, FY - 41 * s, 22 * s, 5 * s, p.d, 1);
      R(CX - 11 * s + ln, FY - 53 * s, 5 * s, 31 * s, p.l, 3 * s, 0.35);
      R(CX - 11 * s + ln, FY - 27 * s, 22 * s, 4 * s, p.boot, 1);
      L(CX + 4 * s, hip, CX + 4 * s - sw, FY - 3 * s, 7.5 * s, p.d); C(CX + 4 * s - sw, FY - 3 * s, 4.6 * s, p.boot);
      L(CX + 9 * s + ln, sh + 4 * s, CX + 20 * s + ln, FY - 40 * s, 6 * s, p.d); C(CX + 21 * s + ln, FY - 40 * s, 3.6 * s, p.skin);
      C(CX - 9 * s + ln, sh + 3 * s, 5 * s, p.l); C(CX + 9 * s + ln, sh + 3 * s, 5 * s, p.l);
      var hx = CX + 2 * s + ln, hy = FY - 62 * s;
      C(hx, hy, 7.5 * s, p.skin);
      return { hx: hx, hy: hy, s: s, hX: CX + 21 * s + ln, hY: FY - 40 * s };
    };
    var helm = function (h, col, visor) {
      self._dome(g, h.hx, h.hy + 2 * h.s, 9.5 * h.s, 10.5 * h.s, col, p.l);
      if (visor) R(h.hx + 1 * h.s, h.hy - 2 * h.s, 8 * h.s, 4 * h.s, visor, 2);
    };
    var flame = function (x, y, len, col) { Pg([[x, y - 5], [x, y + 5], [x - len, y]], col || 0xffd166, 0.95); C(x + 1, y, 3.2, 0xffffff, 0.9); };
    var h;

    if (id === 'marine') {
      h = human({ s: 1 }); helm(h, p.c, p.glow);
      L(h.hX - 8, h.hY + 2, h.hX + 24, h.hY - 3, 5, p.dark); L(h.hX - 4, h.hY - 1, h.hX + 16, h.hY - 5, 3, p.steel);
      C(h.hX + 25, h.hY - 3, 2.6, 0xffe08a, 0.9);
    } else if (id === 'berserker') {
      h = human({ s: 1.22, torso: m(c, 0x2a1a10, 0.35) });
      Pg([[h.hx - 8, h.hy - 3], [h.hx - 17, h.hy - 20], [h.hx - 3, h.hy - 8]], 0xf2e6c8);
      Pg([[h.hx + 8, h.hy - 3], [h.hx + 19, h.hy - 18], [h.hx + 3, h.hy - 8]], 0xf2e6c8);
      helm(h, p.dd, null); C(h.hx + 4, h.hy + 1, 1.8, 0xff4d4d);
      L(h.hX - 3, h.hY + 10, h.hX + 8, h.hY - 40, 4.5, 0x6b4a2b);
      var b1 = [[h.hX + 8, h.hY - 40], [h.hX + 28, h.hY - 46], [h.hX + 22, h.hY - 30]], b2 = [[h.hX + 8, h.hY - 40], [h.hX - 10, h.hY - 52], [h.hX - 4, h.hY - 35]];
      Pg(b1, p.steel); Pg(b2, p.steel); S(b1, 1.5, 0xffffff, 0.7); S(b2, 1.5, 0xffffff, 0.7);
    } else if (id === 'sniper') {
      Pg([[CX - 6, FY - 52], [CX - 24, FY - 14], [CX + 2, FY - 20]], p.dd, 0.9);
      h = human({ s: 0.95 });
      self._dome(g, h.hx, h.hy + 3, 11.5, 12.5, p.dd, p.d); R(h.hx - 1, h.hy - 3, 9, 6, 0x05070f, 2); C(h.hx + 4, h.hy - 1, 1.8, p.glow);
      L(h.hX - 18, h.hY + 3, h.hX + 26, h.hY - 5, 4, p.dark); L(h.hX + 14, h.hY - 3, h.hX + 34, h.hY - 7, 2.5, p.steel);
      R(h.hX - 2, h.hY - 10, 9, 5, p.metal, 2); C(h.hX + 36, h.hY - 7, 2, 0xffe08a, 0.9);
    } else if (id === 'ranger') {
      L(CX - 30, FY - 44, CX - 46, FY - 44, 2.5, p.l, 0.4); L(CX - 28, FY - 32, CX - 48, FY - 32, 2.5, p.l, 0.35); L(CX - 26, FY - 20, CX - 42, FY - 20, 2.5, p.l, 0.3);
      h = human({ s: 0.95, lean: 3 });
      helm(h, p.d, null); R(h.hx - 8, h.hy - 1, 17, 3, p.l, 1); C(h.hx + 5, h.hy + 1, 1.6, 0x111726);
      L(h.hX - 2, h.hY + 2, h.hX + 14, h.hY - 6, 3, p.steel); L(h.hX - 4, h.hY + 8, h.hX + 11, h.hY + 6, 3, p.steel);
    } else if (id === 'grenadier') {
      R(CX - 26, FY - 55, 13, 28, p.metal, 3); R(CX - 24, FY - 50, 9, 4, 0xff9f43, 1); R(CX - 24, FY - 42, 9, 4, 0xff9f43, 1);
      h = human({ s: 1.1 });
      helm(h, p.d, 0xffa640);
      L(h.hX - 12, h.hY + 3, h.hX + 26, h.hY - 5, 9, 0x2a3550); L(h.hX + 20, h.hY - 4, h.hX + 30, h.hY - 6, 11, p.c);
      C(h.hX + 33, h.hY - 6, 4.5, 0xff9f43); C(h.hX + 33, h.hY - 6, 2, 0xffffff, 0.9);
    } else if (id === 'shield') {
      h = human({ s: 1.18 });
      self._dome(g, h.hx, h.hy + 2, 11, 12, p.steel, p.l); R(h.hx - 1, h.hy - 3, 10, 4, p.glow, 2); Pg([[h.hx - 2, h.hy - 12], [h.hx + 3, h.hy - 22], [h.hx + 8, h.hy - 12]], p.c);
      R(h.hX - 6, h.hY - 40, 24, 50, p.l, 8); R(h.hX - 3, h.hY - 37, 18, 44, p.c, 6);
      g.lineStyle(2.5, 0xffffff, 0.75); g.strokeRoundedRect(h.hX - 6, h.hY - 40, 24, 50, 8);
      C(h.hX + 9, h.hY - 15, 6, p.d); L(h.hX + 9, h.hY - 33, h.hX + 9, h.hY + 3, 2, p.l, 0.8);
    } else if (id === 'breacher') {
      var bob = f ? 1.5 : 0, k = f ? 3 : -3;
      L(CX - 8, FY - 9, CX - 11 + k, FY - 2, 6, p.dd); L(CX + 8, FY - 9, CX + 11 - k, FY - 2, 6, p.d);
      C(CX, FY - 27 - bob, 21, p.d); C(CX - 4, FY - 31 - bob, 18, p.c); C(CX - 9, FY - 38 - bob, 6, p.l, 0.55);
      R(CX - 20, FY - 31 - bob, 40, 8, p.boot, 2);
      for (var i = 0; i < 5; i++) Pg([[CX - 18 + i * 8, FY - 31 - bob], [CX - 12 + i * 8, FY - 31 - bob], [CX - 16 + i * 8, FY - 23 - bob], [CX - 22 + i * 8, FY - 23 - bob]], 0xffd166, 0.9);
      C(CX + 9, FY - 28 - bob, 3.4, 0xffffff); C(CX + 10, FY - 28 - bob, 1.7, p.boot);
      L(CX + 2, FY - 46 - bob, CX + 9, FY - 60 - bob, 2.5, 0xd8c9a0);
      C(CX + 10, FY - 62 - bob, f ? 5.5 : 3.8, 0xffd166); C(CX + 10, FY - 62 - bob, 2, 0xffffff);
      C(CX + 14, FY - 44 - bob, 2.6, 0xff4d4d, f ? 1 : 0.3);
    } else if (id === 'wraith') {
      var w = f ? 2.5 : -2.5;
      E(CX, FY - 4, 52, 16, p.c, 0.28);
      var robe = [[CX - 17, FY - 58], [CX + 17, FY - 58], [CX + 25 + w, FY - 10], [CX + 15, FY - 16 + w], [CX + 6, FY - 4], [CX - 4 - w, FY - 15], [CX - 14, FY - 5], [CX - 25 + w, FY - 10]];
      Pg(robe, p.d, 0.88);
      Pg([[CX - 10, FY - 56], [CX + 12, FY - 56], [CX + 16 + w, FY - 18], [CX - 16 + w, FY - 18]], p.c, 0.55);
      S(robe, 1.5, p.l, 0.5);
      self._dome(g, CX, FY - 56, 18, 22, p.dd, p.c);
      E(CX + 2, FY - 59, 17, 15, 0x05070f, 1); C(CX - 1, FY - 60, 2.6, p.glow); C(CX + 7, FY - 60, 2.6, p.glow);
      L(CX + 14, FY - 44, CX + 32, FY - 38 + w, 4.5, p.d);
      L(CX + 32, FY - 38 + w, CX + 40, FY - 42 + w, 2, p.l); L(CX + 32, FY - 38 + w, CX + 41, FY - 37 + w, 2, p.l); L(CX + 32, FY - 38 + w, CX + 40, FY - 33 + w, 2, p.l);
    } else if (id === 'drone') {
      Pg([[54, 48], [38, 32], [30, 34], [44, 52]], p.dd);
      var hull = [[16, 58], [32, 48], [70, 46], [102, 58], [70, 68], [30, 68]];
      Pg(hull, p.c); Pg([[32, 48], [70, 46], [102, 58], [60, 55]], p.l, 0.35); S(hull, 1.5, p.l, 0.7);
      var wing = [[50, 60], [28, 86], [44, 86], [78, 65]]; Pg(wing, p.d); S(wing, 1.5, p.l, 0.6);
      E(72, 52, 24, 10, p.glow, 0.92); E(67, 50, 10, 4, 0xffffff, 0.6);
      L(86, 66, 108, 66, 3, p.dark); C(109, 66, 2, 0xffe08a, 0.9);
      flame(16, 58, f ? 8 : 14);
    } else if (id === 'bomber') {
      Pg([[52, 44], [30, 18], [46, 16], [80, 42]], p.dd);
      var hb = [[8, 60], [26, 46], [84, 42], [114, 58], [84, 74], [26, 72]];
      Pg(hb, p.c); Pg([[26, 46], [84, 42], [114, 58], [70, 55]], p.l, 0.3); S(hb, 1.5, p.l, 0.7);
      var wb = [[44, 64], [12, 94], [40, 96], [88, 70]]; Pg(wb, p.d); S(wb, 1.5, p.l, 0.55);
      E(90, 52, 22, 9, p.glow, 0.92);
      [[56, 80], [70, 78]].forEach(function (b) { C(b[0], b[1], 6, p.dark); R(b[0] - 5, b[1] - 3, 10, 3.5, 0xff4d4d, 1); });
      flame(8, 54, f ? 9 : 16, 0xff8a3d); flame(8, 66, f ? 16 : 9, 0xff8a3d);
    } else if (id === 'titan') {
      var off = f ? 4 : 0;
      R(20, 80, 82, 17, p.boot, 8); g.lineStyle(1.5, p.steel, 0.5); g.strokeRoundedRect(20, 80, 82, 17, 8);
      for (var t = 0; t < 6; t++) { C(30 + t * 13, 88.5, 5.5, p.metal); C(30 + t * 13, 88.5, 2, p.steel); }
      for (var k2 = 0; k2 < 8; k2++) { var tx = 24 + off + k2 * 11; L(tx, 80, tx, 83, 2, p.steel, 0.7); L(tx, 94, tx, 97, 2, p.steel, 0.7); }
      var hullT = [[24, 82], [34, 58], [88, 58], [98, 82]]; Pg(hullT, p.c); Pg([[34, 58], [88, 58], [92, 66], [30, 66]], p.l, 0.35); S(hullT, 1.8, p.l, 0.6);
      R(44, 68, 34, 8, p.d, 2); C(96, 74, 3, 0xffe08a);
      self._dome(g, 64, 58, 22, 20, p.d, p.l); R(56, 42, 16, 7, p.glow, 2, 0.85);
      L(74, 48, 112, 42, 9, p.dark); L(74, 46, 112, 40, 3, p.steel); C(113, 42, 4.5, p.boot); C(113, 42, 2, 0xffe08a, f ? 0.9 : 0.4);
    } else if (id === 'mecha') {
      var sw2 = f ? 8 : -8;
      L(50, 70, 50 + sw2, 95, 13, p.dd); R(41 + sw2, 91, 24, 8, p.boot, 3); C(50 + sw2 * 0.5, 82, 6, p.metal);
      L(74, 70, 74 - sw2, 95, 14, p.d); R(64 - sw2, 91, 26, 8, p.boot, 3); C(74 - sw2 * 0.5, 82, 6.5, p.metal);
      R(38, 30, 52, 44, p.c, 7); R(38, 30, 12, 44, p.l, 5, 0.3); Pg([[44, 36], [84, 36], [78, 56], [50, 56]], p.d, 0.85);
      C(64, 47, 7.5, p.glow, 0.95); C(64, 47, 3.5, 0xffffff);
      C(36, 38, 11, p.d); C(92, 38, 11, p.d); S([[36, 27], [47, 38], [36, 49], [25, 38]], 1.5, p.l, 0.5);
      L(96, 42, 114, 62, 11, p.dark); C(114, 63, 6, p.boot); C(114, 63, 2.6, 0xffe08a, f ? 0.9 : 0.4);
      L(26, 46, 20, 66, 9, p.dd);
      R(54, 10, 24, 20, p.d, 5); R(58, 17, 18, 5, 0xff4d4d, 2); L(66, 10, 66, 3, 2, p.steel); C(66, 2, 2, 0xff4d4d);
    } else if (id === 'cruiser') {
      var hc = [[4, 64], [24, 50], [92, 44], [116, 60], [92, 76], [24, 76]];
      Pg(hc, p.c); Pg([[24, 50], [92, 44], [116, 60], [64, 56]], p.l, 0.3); Pg([[24, 70], [92, 74], [116, 62], [92, 78], [24, 82]], p.d);
      S(hc, 1.8, p.l, 0.7); L(18, 62, 108, 62, 2, p.l, 0.55);
      R(54, 28, 30, 18, p.d, 3); R(60, 21, 18, 8, p.l, 2, 0.9);
      for (var wi = 0; wi < 5; wi++) C(60 + wi * 6, 37, 1.5, p.glow);
      [[38, 48], [90, 46]].forEach(function (q) { C(q[0], q[1], 7, p.dark); L(q[0], q[1], q[0] + 22, q[1] - 6, 4.5, p.steel); C(q[0] + 23, q[1] - 6, 2, 0xffe08a, 0.9); });
      flame(4, 58, f ? 9 : 16); flame(4, 68, f ? 16 : 9); flame(8, 50, f ? 6 : 11);
      C(76, 64, 3, 0xff4d4d, 0.9);
    } else if (id === 'swarm') {
      // Essaim : trois micro-drones qui battent des ailes
      [[30, 64], [60, 46], [86, 68]].forEach(function (q, i) {
        var o = (i % 2 ? 1 : -1) * (f ? 3 : -3), x = q[0], y = q[1] + o;
        E(x, y, 22, 9, p.c); E(x - 2, y - 2, 12, 4, p.l, 0.6); C(x + 8, y, 3.2, p.glow);
        L(x - 6, y - 4, x - 14, y - 11 + (f ? 3 : 0), 2.5, p.steel, 0.8); L(x + 2, y - 4, x + 8, y - 12 - (f ? 3 : 0), 2.5, p.steel, 0.8);
      });
    } else if (id === 'artillery') {
      h = human({ s: 1 }); helm(h, p.d, 0xffa640);
      L(h.hX - 10, h.hY + 6, h.hX + 34, h.hY - 14, 8, p.dark); L(h.hX + 20, h.hY - 8, h.hX + 40, h.hY - 15, 10, p.c); C(h.hX + 42, h.hY - 16, 3.5, 0xffe08a, 0.9);
      L(h.hX + 2, h.hY + 8, h.hX - 6, h.hY + 30, 3, p.steel); L(h.hX + 2, h.hY + 8, h.hX + 10, h.hY + 30, 3, p.steel);
    } else if (id === 'pyro') {
      R(CX - 27, FY - 56, 13, 30, p.dark, 3); R(CX - 25, FY - 52, 9, 5, 0xff6a3d, 1);
      h = human({ s: 1.1, torso: m(c, 0x2a1a10, 0.3) }); helm(h, p.dd, 0xff6a3d);
      L(h.hX - 8, h.hY + 3, h.hX + 22, h.hY - 4, 7, 0x2a3550);
      Pg([[h.hX + 22, h.hY - 9], [h.hX + 22, h.hY + 1], [h.hX + 46, h.hY - 4]], 0xff8a3d, f ? 0.95 : 0.7);
      Pg([[h.hX + 22, h.hY - 6], [h.hX + 22, h.hY - 2], [h.hX + 36, h.hY - 4]], 0xffe08a, 0.95);
    } else if (id === 'sapper') {
      R(CX - 25, FY - 54, 15, 26, p.dark, 3); [0, 1, 2].forEach(function (i2) { R(CX - 24 + i2 * 4, FY - 58, 3, 9, 0xff4d4d, 1); });
      h = human({ s: 1.05 }); helm(h, p.dd, null);
      C(h.hX + 2, h.hY - 6, 5, 0xffd166); C(h.hX + 2, h.hY - 6, 2, 0xffffff); L(h.hX + 2, h.hY - 10, h.hX + 6, h.hY - 18, 2, 0xd8c9a0); C(h.hX + 7, h.hY - 19, f ? 4 : 2.5, 0xffd166);
    } else if (id === 'gunship') {
      var hg = [[10, 62], [30, 50], [80, 46], [108, 60], [80, 72], [28, 72]];
      Pg(hg, p.c); Pg([[30, 50], [80, 46], [108, 60], [60, 56]], p.l, 0.32); S(hg, 1.6, p.l, 0.7);
      var wg = [[46, 66], [22, 92], [46, 94], [84, 70]]; Pg(wg, p.d); S(wg, 1.5, p.l, 0.55);
      E(84, 54, 22, 9, p.glow, 0.92);
      L(70, 72, 104, 76, 4, p.dark); L(64, 68, 100, 71, 4, p.dark); C(106, 76, 2.2, 0xffe08a, 0.9); C(102, 71, 2.2, 0xffe08a, 0.9);
      flame(10, 62, f ? 8 : 14);
    } else if (id === 'dreadnought') {
      var hd = [[2, 62], [20, 44], [94, 38], [118, 58], [94, 80], [20, 80]];
      Pg(hd, p.c); Pg([[20, 44], [94, 38], [118, 58], [60, 52]], p.l, 0.3); S(hd, 2, p.l, 0.75);
      R(50, 22, 38, 18, p.d, 3); R(56, 14, 26, 9, p.l, 2, 0.9);
      [[30, 46], [66, 38], [96, 42]].forEach(function (q) { C(q[0], q[1], 7.5, p.dark); L(q[0], q[1], q[0] + 22, q[1] - 5, 5, p.steel); C(q[0] + 23, q[1] - 5, 2.2, 0xffe08a, 0.9); });
      for (var wi2 = 0; wi2 < 7; wi2++) C(28 + wi2 * 10, 66, 1.8, p.glow);
      flame(6, 54, f ? 10 : 18); flame(6, 66, f ? 18 : 10); flame(10, 74, f ? 8 : 14);
    } else if (id === 'spawn') {
      var wob = f ? 2 : -2;
      [-20, -8, 8, 20].forEach(function (q, i3) { L(CX + q, FY - 12, CX + q + (i3 % 2 ? wob : -wob), FY - 1, 4, p.d); });
      E(CX, FY - 26, 46, 40, p.d, 0.95); E(CX - 3, FY - 30, 40, 34, p.c); E(CX - 10, FY - 38, 16, 9, p.l, 0.45);
      Pg([[CX - 14, FY - 46], [CX - 8, FY - 60], [CX - 2, FY - 46]], p.l, 0.9); Pg([[CX + 2, FY - 46], [CX + 8, FY - 58], [CX + 14, FY - 44]], p.l, 0.9);
      C(CX + 8, FY - 32, 5, 0xeaf2ff); C(CX + 10, FY - 32, 2.4, p.boot); C(CX - 2, FY - 34, 3.6, 0xeaf2ff); C(CX - 1, FY - 34, 1.8, p.boot);
      L(CX + 6, FY - 20, CX + 18, FY - 20, 2.5, 0xff6b9a);
    } else if (id === 'leviathan') {
      E(CX, FY - 6, 96, 22, p.dd, 0.5);
      Pg([[CX - 44, FY - 10], [CX - 30, FY - 46], [CX + 26, FY - 50], [CX + 46, FY - 20], [CX + 30, FY - 2], [CX - 34, FY - 2]], p.c);
      Pg([[CX - 44, FY - 10], [CX - 30, FY - 46], [CX - 2, FY - 44], [CX - 10, FY - 8]], p.l, 0.35);
      [-20, -4, 12].forEach(function (q) { self._dome(g, CX + q, FY - 44, 8, 6, p.d, p.glow); });
      C(CX + 40, FY - 20, 6, p.glow); L(CX + 44, FY - 24, CX + 58, FY - (f ? 30 : 16), 5, p.dark);
      L(CX - 30, FY - 4, CX - 42, FY + 6, 6, p.dd); L(CX + 4, FY - 4, CX + (f ? 16 : -4), FY + 8, 6, p.dd);
    } else if (id === 'reaper') {
      Pg([[CX, FY - 70], [CX + 30, FY - 30], [CX + 6, FY - 20], [CX - 6, FY - 20], [CX - 30, FY - 30]], p.dd, 0.95);
      Pg([[CX, FY - 70], [CX + 30, FY - 30], [CX + 10, FY - 34]], p.c);
      Pg([[CX, FY - 70], [CX - 30, FY - 30], [CX - 10, FY - 34]], p.c);
      self._dome(g, CX, FY - 34, 10, 12, p.l, p.glow);
      C(CX, FY - 36, 4, 0xfff6d8, 0.95);
      L(CX - 4, FY - 22, CX - 4, FY, 3, p.dark, 0.8); L(CX + 4, FY - 22, CX + 4, FY, 3, p.dark, 0.8);
      flame(CX - 24, FY - 24, f ? 10 : 16, 0xfff0a0); flame(CX + 24, FY - 24, f ? 16 : 10, 0xfff0a0);
    } else if (id === 'voidbomb') {
      C(CX, FY - 30, 22, p.dd);
      C(CX, FY - 30, 15, p.c);
      self._band(g, CX, FY - 30, 30, 2, p.l, 0.7); self._band(g, CX, FY - 30, 40, 1.5, p.l, 0.4);
      C(CX, FY - 30, 6, 0xf3e8ff, f ? 0.95 : 0.6);
      [0, 60, 120, 180, 240, 300].forEach(function (a) {
        var r = a * Math.PI / 180, x2 = CX + Math.cos(r) * 26, y2 = FY - 30 + Math.sin(r) * 26;
        L(CX, FY - 30, x2, y2, 2, p.l, 0.5);
      });
      [[-14, -18], [16, -14]].forEach(function (o) { L(CX + o[0], FY - 30 + o[1], CX + o[0] * 1.6, FY - 30 + o[1] * 1.6, 4, p.dark); });
    } else {    // troupe inconnue (catalogue étendu) : silhouette générique
      h = human({ s: 1 }); helm(h, p.c, p.glow);
    }
  }

  // ---------- réserve de troupes ----------
  _buildTray() {
    var w = this.scale.width, T = NEBUSTION.Troops;
    this._cards = [];
    var ids = T.ORDER.filter((id) => (this.sim.reserve[id] || 0) > 0);
    var top = this.arenaBottom + 82;
    if (!ids.length) {
      this.add.text(w / 2, top + 20, 'Ta réserve est vide.\nAchète des troupes dans la Boutique (onglet Troupes).', {
        fontFamily: 'Arial, sans-serif', fontSize: '16px', color: '#ffb3b3', align: 'center'
      }).setOrigin(0.5, 0).setDepth(50);
      var cb = new NEBUSTION.Button(this, w / 2, top + 120, { width: 300, height: 56, label: '🛒 ACHETER DES TROUPES', fontSize: '16px', accentColor: 0xffd166,
        onClick: () => this.scene.start('ShopScene', { tab: 'troops' }) });
      cb.setDepth(50);
      this.add.existing(cb);
      return;
    }
    var cw = (w - 60 - 24) / 4, ch = 74;
    ids.forEach((id, i) => {
      var def = T.get(id), col = i % 4, row = Math.floor(i / 4);
      var x = 30 + cw / 2 + col * (cw + 8), y = top + ch / 2 + row * (ch + 8);
      var c = this.add.container(x, y).setDepth(50);
      var bg = this.add.graphics();
      c.add(bg);
      var ic = this.add.image(-cw / 2 + 27, 8, 'qgtr_' + id + '_0').setOrigin(0.5, 0.6).setScale(0.42);
      var nm = this.add.text(-cw / 2 + 58, -16, def.name, { fontFamily: 'Arial, sans-serif', fontSize: '10px', fontStyle: 'bold', color: '#eaf2ff', wordWrap: { width: cw - 62 } }).setOrigin(0, 0.5);
      var ct = this.add.text(-cw / 2 + 58, 12, '', { fontFamily: 'Arial, sans-serif', fontSize: '18px', fontStyle: 'bold', color: def.hex || '#ffd166' }).setOrigin(0, 0.5);
      c.add([ic, nm, ct]);
      c.setSize(cw, ch);
      c.setInteractive(new Phaser.Geom.Rectangle(0, 0, cw, ch), Phaser.Geom.Rectangle.Contains);
      c.on('pointerdown', (p, lx, ly, ev) => {
        if (ev && ev.stopPropagation) ev.stopPropagation();
        if (this.squadMode) this._toggleSquad(id); else this._select(id);
      });
      this._cards.push({ id: id, def: def, bg: bg, ct: ct, cw: cw, ch: ch, container: c });
    });
    this._select(ids[0]);
  }

  _select(id) { this.selected = id; this._redrawCards(); this._drawZone(); }

  /** Escouade : ajoute/retire une troupe (max 3, dans la limite du stock disponible). */
  _toggleSquad(id) {
    var i = this.squad.indexOf(id);
    if (i >= 0) { this.squad.splice(i, 1); }
    else {
      var used = this.squad.filter(function (x) { return x === id; }).length;
      if (this.squad.length >= 3 || used >= (this.sim.reserve[id] || 0)) return;
      this.squad.push(id);
    }
    this._redrawSquadToggle();
    this._redrawCards();
  }

  _redrawCards() {
    this._cards.forEach((k) => {
      var n = this.sim.reserve[k.id] || 0;
      var inSquad = this.squadMode && this.squad.indexOf(k.id) >= 0;
      var sel = this.squadMode ? inSquad : (this.selected === k.id);
      k.bg.clear();
      k.bg.fillStyle(k.def.color, sel ? 0.34 : 0.12); k.bg.fillRoundedRect(-k.cw / 2, -k.ch / 2, k.cw, k.ch, 12);
      k.bg.lineStyle(sel ? 3 : 1.5, sel && this.squadMode ? 0xffd166 : k.def.color, sel ? 1 : 0.5); k.bg.strokeRoundedRect(-k.cw / 2, -k.ch / 2, k.cw, k.ch, 12);
      k.ct.setText('×' + n + (inSquad ? ' ✓' : ''));
      k.container.setAlpha(n > 0 ? 1 : 0.35);
    });
  }

  // ---------- zoom (pincement à 2 doigts + molette + boutons) : navigue dans la zone de combat -----------
  // Ne touche jamais au moteur QGBattle ni à _P (coordonnées « cellule ») : on redimensionne/déplace
  // uniquement le container `this.world`, en gardant les conversions écran <-> cellule (_scr/_unproject)
  // synchronisées via worldX/worldY/worldScale.
  _initZoom() {
    this.minZoom = 0.6;
    this.maxZoom = 2.5;
    this.zoom = 1;
    this._pinchActive = false;
    var self = this;
    this._onZoomMove = function () { self._handlePinch(); };
    this._onZoomEnd = function () { self._pinchActive = false; };
    this._onWheel = function (pointer, over, dx, dy) { self._applyZoomAt(self.zoom * (dy > 0 ? 0.88 : 1 / 0.88), pointer.x, pointer.y); };
    this.input.on('pointermove', this._onZoomMove);
    this.input.on('pointerup', this._onZoomEnd);
    this.input.on('pointerupoutside', this._onZoomEnd);
    this.input.on('wheel', this._onWheel);
    this._buildZoomButtons();
    this.events.once('shutdown', () => this._teardownZoom());
  }

  _teardownZoom() {
    if (!this.input) return;
    this.input.off('pointermove', this._onZoomMove);
    this.input.off('pointerup', this._onZoomEnd);
    this.input.off('pointerupoutside', this._onZoomEnd);
    this.input.off('wheel', this._onWheel);
  }

  // Deux doigts posés = geste de pincement (zoom + déplacement du point médian), jamais un déploiement.
  _handlePinch() {
    var p1 = this.input.pointer1, p2 = this.input.pointer2;
    if (p1 && p1.isDown && p2 && p2.isDown) {
      var dx = p2.x - p1.x, dy = p2.y - p1.y, dist = Math.max(1, Math.sqrt(dx * dx + dy * dy));
      var mx = (p1.x + p2.x) / 2, my = (p1.y + p2.y) / 2;
      if (!this._pinchActive) {
        this._pinchActive = true;
        this._pinchDist0 = dist;
        this._pinchZoom0 = this.zoom;
        this._pinchAnchor = { x: (mx - this.worldX) / this.worldScale, y: (my - this.worldY) / this.worldScale };
      } else {
        this._setZoom(this._pinchZoom0 * (dist / this._pinchDist0), mx, my, this._pinchAnchor);
      }
    } else {
      this._pinchActive = false;
    }
  }

  // Fixe le zoom en gardant le point `anchor` (coordonnées LOCALES au monde) sous l'écran (sx, sy) :
  // on zoome/pan « vers » l'endroit qu'on pince ou qu'on molette, pas vers le coin de l'écran.
  _setZoom(newZoom, sx, sy, anchor) {
    newZoom = Math.max(this.minZoom, Math.min(this.maxZoom, newZoom));
    var newScale = this.ws * newZoom;
    this.zoom = newZoom;
    this.worldScale = newScale;
    this.worldX = sx - anchor.x * newScale;
    this.worldY = sy - anchor.y * newScale;
    this.world.setScale(this.worldScale);
    this.world.setPosition(this.worldX, this.worldY);
    if (this._zoomLabel) this._zoomLabel.setText(Math.round(this.zoom * 100) + ' %');
  }

  _applyZoomAt(newZoom, sx, sy) {
    var anchor = { x: (sx - this.worldX) / this.worldScale, y: (sy - this.worldY) / this.worldScale };
    this._setZoom(newZoom, sx, sy, anchor);
  }

  _resetZoom() { this._setZoom(1, this.cx, this.cy, { x: 0, y: 0 }); }

  _buildZoomButtons() {
    var w = this.scale.width, self = this, bx = w - 34, y0 = 206;
    var mk = function (label, y, onClick) {
      var c = self.add.container(bx, y).setDepth(55);
      var bg = self.add.circle(0, 0, 19, 0x0d1a33, 0.85).setStrokeStyle(1.5, 0x3a5fa0, 0.9);
      var t = self.add.text(0, -1, label, { fontFamily: 'Arial, sans-serif', fontSize: '17px', fontStyle: 'bold', color: '#eaf2ff' }).setOrigin(0.5);
      c.add([bg, t]);
      c.setSize(38, 38).setInteractive({ useHandCursor: true });
      c.on('pointerdown', (p, lx, ly, ev) => { if (ev && ev.stopPropagation) ev.stopPropagation(); onClick(); });
      return c;
    };
    mk('+', y0, function () { self._applyZoomAt(self.zoom * 1.25, self.cx, self.cy); });
    mk('−', y0 + 44, function () { self._applyZoomAt(self.zoom * 0.8, self.cx, self.cy); });
    this._zoomLabel = this.add.text(bx, y0 + 66, '100 %', { fontFamily: 'Arial, sans-serif', fontSize: '10px', color: '#8ea0c8' }).setOrigin(0.5).setDepth(55);
    mk('⟲', y0 + 88, function () { self._resetZoom(); });
    this._buildSquadToggle(bx, y0 + 132, mk);
  }

  // ---------- Escouade (formation) : bascule le mode de sélection multiple des cartes de troupes ----------
  _buildSquadToggle(bx, y, mk) {
    var self = this;
    this._squadBtn = mk('🧩', y, function () {
      self.aimMode = null;
      self.squadMode = !self.squadMode;
      if (!self.squadMode) self.squad = [];
      self._redrawSquadToggle();
      self._redrawCards();
      self._updateHint();
    });
    this._squadLabel = this.add.text(bx, y + 22, '0/3', { fontFamily: 'Arial, sans-serif', fontSize: '10px', color: '#8ea0c8' }).setOrigin(0.5).setDepth(55);
    this._redrawSquadToggle();
  }

  _redrawSquadToggle() {
    if (!this._squadBtn) return;
    var bg = this._squadBtn.list[0];
    bg.setStrokeStyle(this.squadMode ? 3 : 1.5, this.squadMode ? 0xffd166 : 0x3a5fa0, 1);
    bg.setFillStyle(0x0d1a33, this.squadMode ? 1 : 0.85);
    if (this._squadLabel) this._squadLabel.setText(this.squad.length + '/3');
  }

  // ---------- tap = déploiement (le sol iso est converti en cellules du moteur) ----------
  _onTap(p) {
    if (this.sim.over || this._done) return;
    // deux doigts posés en même temps = pincement (zoom/pan), jamais un déploiement de troupe.
    if (this.input.pointer1 && this.input.pointer1.isDown && this.input.pointer2 && this.input.pointer2.isDown) return;
    var QB = NEBUSTION.QGBattle;
    var q = this._unproject(p.x, p.y);
    if (q.x < QB.ARENA_MIN || q.x > QB.ARENA_MAX || q.y < QB.ARENA_MIN || q.y > QB.ARENA_MAX) return;   // hors terrain

    if (this.aimMode === 'strike') { this._doStrikeTap(q); return; }
    if (this.aimMode && this.aimMode.item) { this._doItemTap(q); return; }
    if (this.squadMode) { this._doSquadTap(q); return; }

    if (!this.selected) return;
    var r = this.sim.deploy(this.selected, q.x, q.y);
    if (r.ok) {
      NEBUSTION.TroopManager.consume(this.selected, 1);
      var def = NEBUSTION.Troops.get(this.selected);
      this._makeUnit(r.unit);
      this._pings.push({ type: 'drop', x: q.x, y: q.y, color: def.color, ttl: 0.55, ttl0: 0.55 });
      this._sfx('ui_click');
      if ((this.sim.reserve[this.selected] || 0) <= 0) {
        var next = this._cards.filter((k) => (this.sim.reserve[k.id] || 0) > 0)[0];
        this.selected = next ? next.id : null;
        this._drawZone();
      }
      this._redrawCards();
      if (this._hint) { this._hint.destroy(); this._hint = null; }
    } else if (r.reason === 'zone') {
      this.fx.toast('Zone interdite', 'Déploie tes troupes à l\'EXTÉRIEUR de la base (zone verte).');
    }
  }

  // ---------- Frappe orbitale : le tap suivant la sélection cible le bombardement ----------
  _doStrikeTap(q) {
    var r = this.sim.useStrike(q.x, q.y);
    this.aimMode = null;
    this._redrawStrikeGauge();
    this._updateHint();
    if (!r.ok) { if (r.reason === 'charge') this.fx.toast('Pas assez chargé', 'La frappe orbitale n\'est pas encore prête.'); return; }
    this._booms.push({ x: q.x, y: q.y, r: 2.1, ttl: 0.55, ttl0: 0.55 });
    var s = this._scr(q.x, q.y, 20);
    this.fx.burst('energy', s.x, s.y, 30);
    this.fx.shake(220, 0.008);
    this._sfx('hit');
  }

  // ---------- Objets/consommables : le tap suivant la sélection cible l'effet ----------
  _doItemTap(q) {
    var itemId = this.aimMode.item;
    var r = this.sim.useItem(itemId, q.x, q.y);
    this.aimMode = null;
    this._redrawItemBar();
    this._updateHint();
    if (!r.ok) { if (r.reason === 'stock') this.fx.toast('Épuisé', 'Plus de charge pour cet objet.'); return; }
    var def = NEBUSTION.CombatItems.get(itemId);
    this._pings.push({ type: 'drop', x: q.x, y: q.y, color: 0x7dffb2, ttl: 0.5, ttl0: 0.5 });
    var s = this._scr(q.x, q.y, 20);
    this.fx.burst('energy', s.x, s.y, 18);
    this._sfx('ui_click');
    this.fx.toast(def.icon + ' ' + def.name, def.desc);
  }

  // ---------- Escouade : déploie plusieurs troupes en une formation (mêlée devant, tir derrière) ----------
  _doSquadTap(q) {
    if (!this.squad.length) return;
    var r = this.sim.deploySquad(this.squad.slice(), q.x, q.y);
    if (!r.ok && !(r.results && r.results.some(function (x) { return x.ok; }))) {
      if (r.reason === 'zone') this.fx.toast('Zone interdite', 'Déploie l\'escouade à l\'EXTÉRIEUR de la base (zone verte).');
      return;
    }
    var self = this, counts = {};
    (r.results || []).forEach(function (res, i) {
      if (!res.ok) return;
      var tid = self.squad[i];
      counts[tid] = (counts[tid] || 0) + 1;
      var def = NEBUSTION.Troops.get(tid);
      self._makeUnit(res.unit);
      self._pings.push({ type: 'drop', x: res.unit.x, y: res.unit.y, color: def.color, ttl: 0.55, ttl0: 0.55 });
    });
    Object.keys(counts).forEach(function (tid) { NEBUSTION.TroopManager.consume(tid, counts[tid]); });
    this._sfx('ui_click');
    this.squad = [];
    this._redrawSquadToggle();
    this._redrawCards();
    if (this._hint) { this._hint.destroy(); this._hint = null; }
  }

  // ---------- troupes ----------
  _makeUnit(u) {
    if (this._seen[u.id]) return;
    this._seen[u.id] = true;
    var UI = { marine: 0.44, berserker: 0.52, sniper: 0.44, ranger: 0.44, grenadier: 0.48, shield: 0.56, breacher: 0.42, wraith: 0.5, drone: 0.5, bomber: 0.62, titan: 0.7, mecha: 0.82, cruiser: 0.92 };
    var sc = (UI[u.type] || 0.5) * this.K;
    var p = this._P(u.x, u.y);
    var c = this.add.container(p.x, p.y);
    var shW = (u.fly ? 42 : 40) * sc * (1 + u.def.space / 14) * 1.5;
    var sh = this.add.graphics();
    sh.fillStyle(0x000000, u.fly ? 0.28 : 0.4); sh.fillEllipse(0, 0, shW, shW * 0.46);
    var sp = this.add.image(0, 0, 'qgtr_' + u.type + '_0').setOrigin(0.5, 98 / 110);
    sp.setScale(sc);
    c.add([sh, sp]);
    c.setDepth(u.x + u.y);
    this.entLayer.add(c);
    this._un[u.id] = { u: u, c: c, sp: sp, sh: sh, sc: sc, f: 0, ft: 0, face: 1, px: u.x, py: u.y, spawnT: 0.35, atkCd: 0, hitT: 0, lastHp: u.hp, dying: false };
  }

  _syncUnits(dt) {
    this.sim.troops.forEach((u) => { if (u.alive && !this._seen[u.id]) this._makeUnit(u); });
    var TOP = { marine: 74, berserker: 88, sniper: 72, ranger: 72, grenadier: 80, shield: 92, breacher: 66, wraith: 82, drone: 60, bomber: 66, titan: 66, mecha: 96, cruiser: 74 };
    Object.keys(this._un).forEach((id) => {
      var n = this._un[id], u = n.u;
      if (!u.alive) { if (!n.dying) this._killUnit(n); return; }
      if (n.dying) return;
      var p = this._P(u.x, u.y);
      n.c.setPosition(p.x, p.y);
      n.c.setDepth(u.x + u.y + (u.fly ? 2.5 : 0.05));
      var moved = Math.abs(u.x - n.px) + Math.abs(u.y - n.py), moving = moved > 0.0008;
      var sdx = (u.x - u.y) - (n.px - n.py);
      if (moving && Math.abs(sdx) > 1e-4) n.face = sdx > 0 ? 1 : -1;
      else if (!moving && u.target && u.target.alive) {
        var tdx = (u.target.x - u.target.y) - (u.x - u.y);
        if (Math.abs(tdx) > 0.05) n.face = tdx > 0 ? 1 : -1;
      }
      n.px = u.x; n.py = u.y;
      // image de marche (alternance) : plus rapide quand la troupe est rapide ou qu'elle attaque
      n.ft += dt;
      var iv = moving ? Math.max(0.09, 0.24 / Math.max(0.4, u.def.speed)) : 0.13;
      if (n.ft >= iv) { n.ft = 0; n.f = n.f ? 0 : 1; n.sp.setTexture('qgtr_' + u.type + '_' + n.f); }
      var bob = 0, lunge = 0, drop = 0, K = this.K;
      if (u.fly) bob = 5 + Math.sin(this._t * 3 + u.id) * 4;
      else if (moving) bob = Math.abs(Math.sin(this._t * (7 + 3 * u.def.speed))) * 4.5;
      else lunge = Math.sin(this._t * 17 + u.id) * 4 * n.face;
      if (n.spawnT > 0) {
        n.spawnT -= dt;
        var k = Math.max(0, n.spawnT / 0.35);
        drop = k * k * 140;
        if (n.spawnT <= 0) this._pings.push({ type: 'puff', x: u.x, y: u.y, color: 0xffffff, ttl: 0.3, ttl0: 0.3 });
      }
      n.sp.setPosition(lunge, -bob - drop);
      n.sp.setScale(n.face * n.sc, n.sc);
      // touché : flash rouge
      if (u.hp < n.lastHp - 0.01) n.hitT = 0.12;
      n.lastHp = u.hp;
      if (n.hitT > 0) { n.hitT -= dt; n.sp.setTint(0xff7a7a); } else n.sp.clearTint();
      // corps à corps : étincelles sur la cible
      if (!moving && u.target && u.target.alive && u.def.dps > 0 && u.def.range <= 1) {
        n.atkCd -= dt;
        if (n.atkCd <= 0) {
          n.atkCd = 0.26 + Math.random() * 0.1;
          this._hits.push({ x: u.target.x + (Math.random() - 0.5) * 0.3, y: u.target.y + (Math.random() - 0.5) * 0.3, h: 14 + Math.random() * 34, ttl: 0.2, ttl0: 0.2, color: u.def.color });
        }
      }
      n.top = (TOP[u.type] || 76) * n.sc;
    });
  }

  _killUnit(n) {
    n.dying = true;
    var u = n.u;
    this._pings.push({ type: 'puff', x: u.x, y: u.y, color: u.def.color, ttl: 0.4, ttl0: 0.4 });
    var self = this;
    this.tweens.add({ targets: n.sp, alpha: 0, scaleY: n.sc * 0.25, duration: 260, onComplete: function () { if (n.c && n.c.active) n.c.destroy(); delete self._un[u.id]; } });
    if (n.sh) n.sh.setAlpha(0.4);
  }

  // ---------- boucle ----------
  update(time, delta) {
    if (!this.sim) return;
    var dt = Math.min(0.1, (delta || 16) / 1000);
    if (!this.sim.over) this.sim.step(dt);
    this._t += dt;
    this._sfxT -= dt;
    this._consumeEvents();
    this._syncBuildings(dt);
    this._syncUnits(dt);
    this._drawFx(dt);
    this.entLayer.sort('depth');
    this._refreshHud();
    if (this.sim.over && !this._done) this._finish();
  }

  _consumeEvents() {
    var evs = this.sim.events.splice(0);
    evs.forEach((e) => {
      if (e.type === 'shot') {
        var fromTurret = e.from === 'turret';
        this._shots.push({ x1: e.x1, y1: e.y1, h1: fromTurret ? 62 : 26, x2: e.x2, y2: e.y2, h2: fromTurret ? 18 : 34, color: e.color, big: fromTurret, ttl: fromTurret ? 0.2 : 0.16, ttl0: fromTurret ? 0.2 : 0.16 });
      } else if (e.type === 'boom') {
        this._booms.push({ x: e.x, y: e.y, r: 1.2, ttl: 0.4, ttl0: 0.4 });
        var s = this._scr(e.x, e.y, 20);
        this.fx.burst('energy', s.x, s.y, 16);
        this.fx.shake(90, 0.004);
        if (this._sfxT <= 0) { this._sfx('hit'); this._sfxT = 0.12; }
      } else if (e.type === 'destroy') {
        this._destroyBuilding(e.id);
      }
    });
  }

  _sfx(name) { try { if (window.nebustionPlaySfx) window.nebustionPlaySfx(name, { volume: 0.35 }); } catch (err) { /* ignore */ } }

  // ---------- effets dessinés en coordonnées monde (barres de PV, tirs, explosions, largage) ----------
  _bar(g, x, y, w, ratio) {
    var K = this.K, col = ratio > 0.5 ? 0x5fd97a : (ratio > 0.25 ? 0xffd166 : 0xff6b6b);
    g.fillStyle(0x000000, 0.72); g.fillRect(x - w / 2 - K, y - K, w + 2 * K, 6 * K);
    g.fillStyle(col, 1); g.fillRect(x - w / 2, y, w * Math.max(0, Math.min(1, ratio)), 4 * K);
  }

  _drawFx(dt) {
    var g = this.fxG, K = this.K, TW = this.TW, TH = this.TH, self = this, BH = { core: 200, silo: 158, generator: 128, turret: 92, wall: 54 };
    g.clear();
    // PV des structures endommagées
    this.sim.buildings.forEach(function (b) {
      if (!b.alive || b.hp >= b.maxHp) return;
      var p = self._P(b.x, b.y);
      self._bar(g, p.x, p.y - (BH[b.kind] || 90), (b.kind === 'wall' ? 44 : 60) * K, b.hp / b.maxHp);
    });
    // PV des troupes blessées
    Object.keys(this._un).forEach(function (id) {
      var n = self._un[id], u = n.u;
      if (n.dying || !u.alive || u.hp >= u.maxHp) return;
      var p = self._P(u.x, u.y);
      self._bar(g, p.x, p.y - (n.top || 60) - (u.fly ? 10 : 4) - 7 * K, 26 * K, u.hp / u.maxHp);
    });
    // tirs (traînée + tête lumineuse)
    this._shots = this._shots.filter(function (s) { return (s.ttl -= dt) > 0; });
    this._shots.forEach(function (s) {
      var a = self._P(s.x1, s.y1), b = self._P(s.x2, s.y2), pr = 1 - s.ttl / s.ttl0, hd = Math.min(1, pr * 1.6), tl = Math.max(0, pr * 1.6 - 0.55);
      var ax = a.x, ay = a.y - s.h1, bx = b.x, by = b.y - s.h2;
      var hx = ax + (bx - ax) * hd, hy = ay + (by - ay) * hd, tx = ax + (bx - ax) * tl, ty = ay + (by - ay) * tl;
      g.lineStyle((s.big ? 7 : 5) * K, s.color, 0.4); g.lineBetween(tx, ty, hx, hy);
      g.lineStyle((s.big ? 3 : 2) * K, 0xffffff, 0.95); g.lineBetween(tx, ty, hx, hy);
      g.fillStyle(s.color, 0.95); g.fillCircle(hx, hy, (s.big ? 4.5 : 3.2) * K);
      if (pr < 0.25) { g.fillStyle(0xffffff, 0.8); g.fillCircle(ax, ay, 5 * K); }
      if (hd >= 1) { g.fillStyle(s.color, 0.55); g.fillCircle(bx, by, 6 * K * (1 - pr * 0.5)); }
    });
    // étincelles de corps à corps
    this._hits = this._hits.filter(function (h) { return (h.ttl -= dt) > 0; });
    this._hits.forEach(function (h) {
      var p = self._P(h.x, h.y), a = h.ttl / h.ttl0, r = (5 + 7 * (1 - a)) * K;
      g.lineStyle(2 * K, 0xffffff, a); g.lineBetween(p.x - r, p.y - h.h - r, p.x + r, p.y - h.h + r); g.lineBetween(p.x + r, p.y - h.h - r, p.x - r, p.y - h.h + r);
      g.fillStyle(h.color, a * 0.8); g.fillCircle(p.x, p.y - h.h, 3.5 * K);
    });
    // explosions (boule de feu + onde de choc iso)
    this._booms = this._booms.filter(function (e) { return (e.ttl -= dt) > 0; });
    this._booms.forEach(function (e) {
      var p = self._P(e.x, e.y), t = 1 - e.ttl / e.ttl0, w = e.r * TW * 1.15 * (0.25 + t * 0.9), a = 1 - t;
      g.fillStyle(0xff8a3d, a * 0.45); g.fillEllipse(p.x, p.y, w, w * TH / TW);
      g.lineStyle(3 * K, 0xffd166, a * 0.9); g.strokeEllipse(p.x, p.y, w * 1.05, w * 1.05 * TH / TW);
      var fr = (16 + 26 * Math.sin(Math.min(1, t * 1.2) * Math.PI * 0.85)) * e.r * 0.8;
      g.fillStyle(0xffb04f, a * 0.75); g.fillCircle(p.x, p.y - 14 - 30 * t * e.r, fr);
      g.fillStyle(0xffe9a8, a * 0.9); g.fillCircle(p.x, p.y - 14 - 30 * t * e.r, fr * 0.55);
    });
    // largage / poussière
    this._pings = this._pings.filter(function (e) { return (e.ttl -= dt) > 0; });
    this._pings.forEach(function (e) {
      var p = self._P(e.x, e.y), t = 1 - e.ttl / e.ttl0, a = 1 - t;
      if (e.type === 'drop') {
        var w = TW * (0.25 + t * 0.85);
        g.lineStyle(3 * K, e.color, a); g.strokeEllipse(p.x, p.y, w, w * TH / TW);
        g.fillStyle(e.color, a * 0.25); g.fillEllipse(p.x, p.y, w, w * TH / TW);
        g.fillStyle(e.color, a * 0.35); g.fillRect(p.x - 9 * K, p.y - 150 * (1 - t * 0.6), 18 * K, 150 * (1 - t * 0.6));
        g.fillStyle(0xffffff, a * 0.6); g.fillRect(p.x - 3 * K, p.y - 150 * (1 - t * 0.6), 6 * K, 150 * (1 - t * 0.6));
      } else {
        var r = (10 + 22 * t) * K * 1.4;
        g.fillStyle(e.color, a * 0.3); g.fillEllipse(p.x, p.y - 4 * K, r * 2, r * 0.9);
        g.fillStyle(0xffffff, a * 0.25); g.fillCircle(p.x, p.y - 12 * K - 12 * t * K, r * 0.5);
      }
    });
  }

  _refreshHud() {
    var r = this.sim.result(), left = Math.max(0, Math.ceil(this.sim.duration - this.sim.t));
    this._pctText.setText('💥 ' + Math.round(r.pct * 100) + ' %');
    this._starText.setText('★'.repeat(r.stars) + '☆'.repeat(3 - r.stars));
    this._timeText.setText('⏱ ' + left + ' s' + (this.sim.started ? '' : ' (à ton 1er tir)'));
    if (this._strikeGauge) this._redrawStrikeGauge();
  }

  // ---------- fin de combat ----------
  _leave() {
    if (this._done) { this.scene.start('EnemyQGScene', { eid: this.eid, variant: this.variant }); return; }
    if (this.sim.started && !this.sim.over) { this.sim.retreat(); return; }   // abandon = fin de combat (résultat appliqué)
    this.scene.start('EnemyQGScene', { eid: this.eid, variant: this.variant });
  }

  _finish() {
    this._done = true;
    this._drawZone();
    var w = this.scale.width, h = this.scale.height;
    var r = this.sim.result(), out = null, E = NEBUSTION.Economy;
    if (this.sim.started) {
      out = NEBUSTION.QGAttackManager.applyBattle(this.eid, r, Date.now());
      if (NEBUSTION.QGMatchmakingManager) NEBUSTION.QGMatchmakingManager.clearCurrent();
    }
    var win = r.victory;
    this._sfx(win ? 'victory' : 'defeat');
    this.cameras.main.flash(180, win ? 95 : 255, win ? 217 : 107, win ? 122 : 107);

    var c = this.add.container(w / 2, h / 2 - 40).setDepth(1000);
    c.add(this.add.rectangle(0, 0, w * 2, h * 2, 0x000000, 0.6).setInteractive());
    var pw = w * 0.86, ph = 470;
    var bg = this.add.graphics();
    bg.fillGradientStyle(0x101a33, 0x101a33, 0x0a1020, 0x0a1020, 0.98);
    bg.fillRoundedRect(-pw / 2, -ph / 2, pw, ph, 22);
    bg.lineStyle(3, win ? 0x5fd97a : 0xff6b6b, 0.9); bg.strokeRoundedRect(-pw / 2, -ph / 2, pw, ph, 22);
    c.add(bg);
    c.add(this.add.text(0, -ph / 2 + 44, win ? 'VICTOIRE' : 'ÉCHEC', {
      fontFamily: 'Arial, sans-serif', fontSize: '38px', fontStyle: '900', color: win ? '#5fd97a' : '#ff8fa3'
    }).setOrigin(0.5));
    c.add(this.add.text(0, -ph / 2 + 104, '★'.repeat(r.stars) + '☆'.repeat(3 - r.stars), { fontFamily: 'Arial, sans-serif', fontSize: '48px', color: '#ffd166' }).setOrigin(0.5));
    var lines = ['Destruction : ' + Math.round(r.pct * 100) + ' %' + (r.coreDown ? ' · cœur du QG détruit' : ''),
      'Troupes déployées : ' + r.deployed + ' · perdues : ' + r.lost];
    if (out && out.ok && win) {
      var parts = Object.keys(out.result.loot).map((id) => E.fmt(out.result.loot[id], 0) + ' ' + E.RES[id].short);
      lines.push('Butin : ' + parts.join(' · '));
      lines.push(this.profile.handle + ' encaisse le coup (traumatisme accru).');
    } else if (!r.deployed) {
      lines.push('Aucune troupe déployée.');
    } else if (!win) {
      lines.push('Il faut au moins 50 % de destruction pour piller le QG.');
    }
    if (out && out.ok) {
      var dt2 = out.result.trophies || 0;
      lines.push((dt2 >= 0 ? '+' : '') + dt2 + ' 🏆 Trophées (total : ' + NEBUSTION.QGAttackManager.trophies() + ')');
      if (this._trophyText) this._trophyText.setText('🏆 ' + NEBUSTION.QGAttackManager.trophies()).setColor(dt2 >= 0 ? '#5fd97a' : '#ff8fa3');
    }
    c.add(this.add.text(0, -ph / 2 + 170, lines.join('\n'), {
      fontFamily: 'Arial, sans-serif', fontSize: '16px', color: '#cfd9f2', align: 'center', lineSpacing: 8, wordWrap: { width: pw * 0.86 }
    }).setOrigin(0.5, 0));
    var b1 = new NEBUSTION.Button(this, 0, ph / 2 - 120, { width: pw * 0.8, height: 56, label: 'REVENIR AU QG ENNEMI', fontSize: '16px', accentColor: 0x00e5ff,
      onClick: () => this.scene.start('EnemyQGScene', { eid: this.eid }) });
    var b2 = new NEBUSTION.Button(this, 0, ph / 2 - 52, { width: pw * 0.8, height: 56, label: '🛒 BOUTIQUE : RACHETER DES TROUPES', fontSize: '15px', accentColor: 0xffd166,
      onClick: () => this.scene.start('ShopScene', { tab: 'troops' }) });
    c.add([b1, b2]);
  }
};
