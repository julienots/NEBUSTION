/**
 * NEBUSTION - CombatPrepScene
 * Écran de préparation de combat : choix de l'équipe de 5 héros (avec leur niveau réel),
 * sélection du stage (10 stages + 3 boss galactiques, progression verrouillée), de la
 * difficulté (Facile / Normal / Difficile / Cauchemar), aperçu des ennemis et des
 * récompenses, puis lancement du combat (CombatScene).
 * L'équipe et la difficulté choisies sont sauvegardées via NEBUSTION.Combat.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.CombatPrepScene = class CombatPrepScene extends Phaser.Scene {
  constructor() {
    super('CombatPrepScene');
  }

  init(data) {
    this._initData = data || {};
  }

  create() {
    var w = this.scale.width, h = this.scale.height;
    var C = NEBUSTION.Combat, EN = NEBUSTION.Enemies;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(300, 5, 7, 15);
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });

    this.team = C.getTeam().slice(0, 5);
    this.difficulty = C.getDifficulty();
    this.stages = EN.allStages();
    this.stageIdx = this._initialStageIndex();
    this._launching = false;

    this.add.text(w / 2, 138, 'PRÉPARATION AU COMBAT', {
      fontFamily: 'Arial, sans-serif', fontSize: '24px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(50).setShadow(0, 0, '#ff4d6d', 10, true, true);

    // Accès à la flotte (module Vaisseaux ajouté à l'étape 6, partie 2).
    var fleetBtn = this.add.text(w - 20, 138, 'Flotte ›', {
      fontFamily: 'Arial, sans-serif', fontSize: '14px', fontStyle: 'bold', color: '#00e5ff'
    }).setOrigin(1, 0.5).setDepth(60).setInteractive({ useHandCursor: true });
    fleetBtn.on('pointerdown', () => this.scene.start('ShipsScene'));

    this.slotsLayer = this.add.container(0, 0).setDepth(60);
    this.powerText = this.add.text(20, 336, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '14px', color: '#a9b8dc'
    }).setDepth(60);
    this._buildAutoButton();

    this._buildPicker();
    this._buildStagePanel();
    this._buildDifficultyChips();
    this.rewardsLayer = this.add.container(0, 0).setDepth(60);
    this._buildLaunch();

    this.hud = NEBUSTION.HUD.attach(this);
    new NEBUSTION.BottomNav(this, 'combat');

    this._refreshAll();
  }

  // Premier stage non terminé et débloqué (frontière de progression), sinon le dernier.
  _initialStageIndex() {
    var C = NEBUSTION.Combat, EN = NEBUSTION.Enemies, stages = EN.allStages();
    if (this._initData.stageId) {
      var i = EN.stageIndex(this._initData.stageId);
      if (i >= 0) return i;
    }
    for (var k = 0; k < stages.length; k++) {
      if (C.isStageUnlocked(stages[k].id) && C.stageStars(stages[k].id) === 0) return k;
    }
    return stages.length - 1;
  }

  _stage() { return this.stages[this.stageIdx]; }

  _teamPower() {
    var H = NEBUSTION.Heroes, C = NEBUSTION.Combat, sum = 0;
    this.team.forEach(function (id) { sum += H.statsAtLevel(H.get(id), C.heroLevel(id)).power; });
    return sum;
  }

  _avgLevel() {
    var C = NEBUSTION.Combat;
    if (!this.team.length) return 1;
    var sum = 0;
    this.team.forEach(function (id) { sum += C.heroLevel(id); });
    return sum / this.team.length;
  }

  // =====================================================================
  // Équipe : 5 emplacements
  // =====================================================================
  _refreshSlots() {
    var self = this, H = NEBUSTION.Heroes, C = NEBUSTION.Combat;
    var w = this.scale.width;
    this.slotsLayer.removeAll(true);

    var slotW = 128, gap = 10, x0 = (w - (5 * slotW + 4 * gap)) / 2, y0 = 168, slotH = 158;
    for (var i = 0; i < 5; i++) {
      (function (i) {
        var x = x0 + i * (slotW + gap);
        var id = self.team[i];
        var g = self.add.graphics();
        self.slotsLayer.add(g);
        if (id) {
          var hero = H.get(id), rarity = H.RARITIES[hero.rarity];
          g.fillStyle(0x0a0f1e, 0.95); g.fillRoundedRect(x, y0, slotW, slotH, 14);
          var img = self.add.image(x + slotW / 2, y0 + 62, H.portraitKey(id)).setDisplaySize(slotW - 12, 118);
          self.slotsLayer.add(img);
          g.lineStyle(2.5, rarity.color, 0.95); g.strokeRoundedRect(x, y0, slotW, slotH, 14);
          g.fillStyle(0x05070f, 0.72); g.fillRoundedRect(x + 4, y0 + slotH - 40, slotW - 8, 36, 10);
          self.slotsLayer.add(self.add.text(x + slotW / 2, y0 + slotH - 29, hero.name, {
            fontFamily: 'Arial, sans-serif', fontSize: '14px', fontStyle: 'bold', color: '#eaf2ff'
          }).setOrigin(0.5));
          self.slotsLayer.add(self.add.text(x + slotW / 2, y0 + slotH - 13, 'Niv. ' + C.heroLevel(id), {
            fontFamily: 'Arial, sans-serif', fontSize: '12px', color: rarity.hex
          }).setOrigin(0.5));
          self.slotsLayer.add(self.add.text(x + slotW - 10, y0 + 8, '✕', {
            fontFamily: 'Arial, sans-serif', fontSize: '14px', fontStyle: 'bold', color: '#ffb0b8'
          }).setOrigin(1, 0));
          var zone = self.add.zone(x, y0 + 20, slotW, slotH - 20).setOrigin(0).setInteractive({ useHandCursor: true });
          zone.on('pointerdown', function () { self._toggleHero(id); });
          self.slotsLayer.add(zone);

          // Formation : bascule AVANT (dégâts +, ciblé en priorité) / ARRIÈRE (protégé, dégâts -).
          var row = C.getFormationRow(id), front = row !== 'back';
          var fBg = self.add.graphics();
          fBg.fillStyle(front ? 0xff6b6b : 0x4fd1ff, 0.85); fBg.fillRoundedRect(x + 6, y0 + 6, 60, 20, 8);
          self.slotsLayer.add(fBg);
          var fTxt = self.add.text(x + 36, y0 + 16, front ? '⚔ AVANT' : '🛡 ARRIÈRE', {
            fontFamily: 'Arial, sans-serif', fontSize: '10px', fontStyle: 'bold', color: '#05070f'
          }).setOrigin(0.5);
          self.slotsLayer.add(fTxt);
          var fZone = self.add.zone(x + 6, y0 + 6, 60, 20).setOrigin(0).setInteractive({ useHandCursor: true });
          fZone.on('pointerdown', function (p, lx, ly, ev) {
            if (ev && ev.stopPropagation) ev.stopPropagation();
            C.setFormationRow(id, front ? 'back' : 'front');
            self._refreshSlots();
          });
          self.slotsLayer.add(fZone);
        } else {
          g.fillStyle(0x0a0f1e, 0.55); g.fillRoundedRect(x, y0, slotW, slotH, 14);
          g.lineStyle(2, 0x2b3a5c, 0.9); g.strokeRoundedRect(x, y0, slotW, slotH, 14);
          self.slotsLayer.add(self.add.text(x + slotW / 2, y0 + slotH / 2 - 8, '+', {
            fontFamily: 'Arial, sans-serif', fontSize: '44px', color: '#2b3a5c'
          }).setOrigin(0.5));
          self.slotsLayer.add(self.add.text(x + slotW / 2, y0 + slotH / 2 + 30, 'Libre', {
            fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#4a5a7c'
          }).setOrigin(0.5));
        }
      })(i);
    }
  }

  _buildAutoButton() {
    var self = this, w = this.scale.width;
    var btn = new NEBUSTION.Button(this, w - 96, 342, {
      width: 176, height: 34, label: 'ÉQUIPE AUTO', fontSize: '13px', accentColor: 0x4fd1ff,
      onClick: function () { self._autoTeam(); }
    });
    btn.setDepth(60);
  }

  _autoTeam() {
    var H = NEBUSTION.Heroes, C = NEBUSTION.Combat;
    // Les 5 héros les plus puissants, en garantissant au moins un tank et un soigneur/support si possible.
    var list = H.all().filter(function (hero) { return C.isUnlocked(hero.id); }).map(function (hero) {
      return { id: hero.id, role: hero.role, power: H.statsAtLevel(hero, C.heroLevel(hero.id)).power };
    }).sort(function (a, b) { return b.power - a.power; });
    var picked = [];
    function take(pred) {
      for (var i = 0; i < list.length; i++) {
        if (pred(list[i]) && picked.indexOf(list[i].id) < 0) { picked.push(list[i].id); return; }
      }
    }
    take(function (e) { return e.role === 'tank'; });
    take(function (e) { return e.role === 'healer' || e.role === 'support'; });
    list.forEach(function (e) { if (picked.length < 5 && picked.indexOf(e.id) < 0) picked.push(e.id); });
    this.team = picked.slice(0, 5);
    this._commitTeam();
    this._refreshAll();
  }

  _toggleHero(id) {
    var i = this.team.indexOf(id);
    if (i >= 0) {
      this.team.splice(i, 1);
    } else {
      if (this.team.length >= 5) { this._hint('Équipe complète : retirez un héros d\'abord.'); return; }
      if (NEBUSTION.ExpeditionManager && NEBUSTION.ExpeditionManager.isBusy(id)) { this._hint('Ce héros est en expédition : indisponible.'); return; }
      this.team.push(id);
    }
    this._commitTeam();
    this._refreshAll();
  }

  _commitTeam() {
    // Sauvegarde uniquement une équipe complète ; sinon on garde la dernière équipe valide en mémoire
    // (le combat n'est lancé qu'avec 5 héros).
    if (this.team.length === 5) NEBUSTION.Combat.setTeam(this.team);
  }

  // =====================================================================
  // Sélecteur de héros (grille défilante)
  // =====================================================================
  _buildPicker() {
    var self = this, w = this.scale.width;
    this.pickTop = 372;
    this.pickBottom = 690;
    var viewH = this.pickBottom - this.pickTop;

    this.pickMaskGfx = this.make.graphics();
    this.pickMaskGfx.fillRect(0, this.pickTop, w, viewH);
    this.pickContainer = this.add.container(0, this.pickTop).setDepth(40);
    this.pickContainer.setMask(this.pickMaskGfx.createGeometryMask());
    this.pickScroll = 0;
    this.pickMax = 0;

    var dragging = false, startY = 0, startScroll = 0, moved = 0;
    var zone = this.add.zone(0, this.pickTop, w, viewH).setOrigin(0).setInteractive();
    zone.setDepth(41);
    zone.on('pointerdown', function (p) { dragging = true; startY = p.y; startScroll = self.pickScroll; moved = 0; });
    this.input.on('pointermove', function (p) {
      if (!dragging) return;
      var dy = p.y - startY;
      moved = Math.max(moved, Math.abs(dy));
      self.pickScroll = Phaser.Math.Clamp(startScroll - dy, 0, self.pickMax);
      self.pickContainer.y = self.pickTop - self.pickScroll;
    });
    zone.on('pointerup', function (p) {
      dragging = false;
      if (moved > 12) return;
      self._pickTap(p.x, p.y);
    });
    this.input.on('pointerupoutside', function () { dragging = false; });
  }

  _pickTap(px, py) {
    var g = this._pickGrid;
    if (!g) return;
    var localY = (py - this.pickTop) + this.pickScroll;
    var col = Math.floor((px - g.x0) / (g.cellW + g.gap));
    var row = Math.floor(localY / (g.cellH + g.gap));
    if (col < 0 || col >= g.cols || row < 0) return;
    var idx = row * g.cols + col;
    if (idx >= 0 && idx < this._pickList.length) this._toggleHero(this._pickList[idx].id);
  }

  _refreshPicker() {
    var self = this, H = NEBUSTION.Heroes, C = NEBUSTION.Combat, w = this.scale.width;
    this.pickContainer.removeAll(true);

    // Tri : héros de l'équipe d'abord ? Non : ordre stable par puissance décroissante (repères constants).
    var list = H.all().filter(function (hero) { return C.isUnlocked(hero.id); }).map(function (hero) {
      return { id: hero.id, hero: hero, level: C.heroLevel(hero.id), power: H.statsAtLevel(hero, C.heroLevel(hero.id)).power };
    }).sort(function (a, b) { return b.power - a.power; });
    this._pickList = list;

    var cols = 3, gap = 8, x0 = 14;
    var cellW = (w - x0 * 2 - gap * (cols - 1)) / cols, cellH = 112;
    this._pickGrid = { cols: cols, gap: gap, x0: x0, cellW: cellW, cellH: cellH };

    list.forEach(function (e, i) {
      var col = i % cols, row = Math.floor(i / cols);
      var x = x0 + col * (cellW + gap), y = row * (cellH + gap);
      var rarity = H.RARITIES[e.hero.rarity], role = H.ROLES[e.hero.role];
      var selected = self.team.indexOf(e.id) >= 0;
      var busy = !selected && NEBUSTION.ExpeditionManager && NEBUSTION.ExpeditionManager.isBusy(e.id);
      var full = !selected && (self.team.length >= 5 || busy);

      var g = self.add.graphics();
      g.fillGradientStyle(selected ? 0x1a2c4e : 0x121a30, selected ? 0x1a2c4e : 0x121a30, 0x0a0f1e, 0x0a0f1e, full ? 0.55 : 0.95);
      g.fillRoundedRect(x, y, cellW, cellH, 12);
      g.lineStyle(selected ? 3 : 1.5, selected ? 0x00e5ff : rarity.color, selected ? 1 : 0.5);
      g.strokeRoundedRect(x, y, cellW, cellH, 12);
      self.pickContainer.add(g);

      var img = self.add.image(x + 8 + 42, y + cellH / 2, H.portraitKey(e.id)).setDisplaySize(84, 98);
      if (full) img.setAlpha(0.45);
      self.pickContainer.add(img);

      var tx = x + 100;
      self.pickContainer.add(self.add.text(tx, y + 10, e.hero.name, {
        fontFamily: 'Arial, sans-serif', fontSize: '16px', fontStyle: 'bold', color: full ? '#7a89ad' : '#eaf2ff'
      }));
      self.pickContainer.add(self.add.text(tx, y + 34, role.name, {
        fontFamily: 'Arial, sans-serif', fontSize: '12px', fontStyle: 'bold', color: '#' + ('000000' + role.color.toString(16)).slice(-6)
      }));
      self.pickContainer.add(self.add.text(tx, y + 54, 'Niv. ' + e.level, {
        fontFamily: 'Arial, sans-serif', fontSize: '13px', color: rarity.hex
      }));
      self.pickContainer.add(self.add.text(tx, y + 74, '⚡ ' + e.power, {
        fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#ffd166'
      }));
      if (selected) {
        self.pickContainer.add(self.add.text(x + cellW - 10, y + 8, '✔', {
          fontFamily: 'Arial, sans-serif', fontSize: '18px', fontStyle: 'bold', color: '#00e5ff'
        }).setOrigin(1, 0));
      } else if (busy) {
        self.pickContainer.add(self.add.text(x + cellW - 10, y + 8, '🚀 Expédition', {
          fontFamily: 'Arial, sans-serif', fontSize: '11px', fontStyle: 'bold', color: '#4fc3ff'
        }).setOrigin(1, 0));
      }
    });

    var rows = Math.ceil(list.length / cols);
    var contentH = rows * (cellH + gap);
    this.pickMax = Math.max(0, contentH - (this.pickBottom - this.pickTop) + 4);
    this.pickScroll = Math.min(this.pickScroll, this.pickMax);
    this.pickContainer.y = this.pickTop - this.pickScroll;
  }

  // =====================================================================
  // Panneau de stage
  // =====================================================================
  _buildStagePanel() {
    var self = this, w = this.scale.width;
    this.stageTop = 704;
    this.stageLayer = this.add.container(0, 0).setDepth(60);

    var prev = new NEBUSTION.Button(this, 44, this.stageTop + 92, {
      width: 56, height: 90, label: '◀', fontSize: '22px', accentColor: 0xff4d6d,
      onClick: function () { self._moveStage(-1); }
    });
    prev.setDepth(61);
    var next = new NEBUSTION.Button(this, w - 44, this.stageTop + 92, {
      width: 56, height: 90, label: '▶', fontSize: '22px', accentColor: 0xff4d6d,
      onClick: function () { self._moveStage(1); }
    });
    next.setDepth(61);
  }

  _moveStage(delta) {
    var n = this.stages.length;
    this.stageIdx = (this.stageIdx + delta + n) % n;
    this._refreshStage();
    this._refreshRewards();
    this._refreshLaunch();
  }

  _refreshStage() {
    var self = this, w = this.scale.width;
    var EN = NEBUSTION.Enemies, C = NEBUSTION.Combat, H = NEBUSTION.Heroes;
    var st = this._stage();
    var y0 = this.stageTop, panelX = 82, panelW = w - 164, panelH = 184;
    var unlocked = C.isStageUnlocked(st.id);
    var isBoss = st.kind === 'boss';
    this.stageLayer.removeAll(true);

    var g = this.add.graphics();
    g.fillGradientStyle(0x151d33, 0x151d33, 0x0a0f1e, 0x0a0f1e, 0.96);
    g.fillRoundedRect(panelX, y0, panelW, panelH, 16);
    g.lineStyle(2, isBoss ? 0xff4d5e : 0x2b3a5c, isBoss ? 0.95 : 0.9);
    g.strokeRoundedRect(panelX, y0, panelW, panelH, 16);
    this.stageLayer.add(g);

    var idx = this.stageIdx + 1;
    var label = isBoss ? '☠ BOSS GALACTIQUE' : 'STAGE ' + (this.stages.slice(0, this.stageIdx + 1).filter(function (s) { return s.kind === 'stage'; }).length);
    this.stageLayer.add(this.add.text(panelX + panelW / 2, y0 + 16, label + '   ·   ' + idx + '/' + this.stages.length, {
      fontFamily: 'Arial, sans-serif', fontSize: '12px', fontStyle: 'bold', color: isBoss ? '#ff8a94' : '#7a89ad'
    }).setOrigin(0.5));
    this.stageLayer.add(this.add.text(panelX + panelW / 2, y0 + 40, st.name, {
      fontFamily: 'Arial, sans-serif', fontSize: '18px', fontStyle: 'bold', color: '#eaf2ff',
      wordWrap: { width: panelW - 20 }, align: 'center'
    }).setOrigin(0.5));

    // Aperçu des ennemis
    var enemies = st.enemies;
    var iconSize = isBoss ? 92 : 62;
    var totalW = enemies.length * (iconSize + 6);
    var ex = panelX + panelW / 2 - totalW / 2 + (iconSize + 6) / 2;
    enemies.forEach(function (eid, i) {
      var def = EN.get(eid);
      var img = self.add.image(ex + i * (iconSize + 6), y0 + 96, 'tex_enemy_' + eid).setDisplaySize(iconSize, iconSize);
      if (!unlocked) img.setAlpha(0.35);
      self.stageLayer.add(img);
    });
    var names = enemies.map(function (eid) { return EN.get(eid).name; });
    var uniq = {}; names.forEach(function (n) { uniq[n] = (uniq[n] || 0) + 1; });
    var nameLine = Object.keys(uniq).map(function (n) { return (uniq[n] > 1 ? uniq[n] + '× ' : '') + n; }).join('  ·  ');
    this.stageLayer.add(this.add.text(panelX + panelW / 2, y0 + 142, nameLine, {
      fontFamily: 'Arial, sans-serif', fontSize: '12px', color: '#9aa5c0', wordWrap: { width: panelW - 16 }, align: 'center'
    }).setOrigin(0.5));

    // Étoiles + niveau recommandé / verrou
    var stars = C.stageStars(st.id);
    var starTxt = '';
    for (var s = 1; s <= 3; s++) starTxt += (s <= stars ? '★' : '☆');
    this.stageLayer.add(this.add.text(panelX + panelW / 2, y0 + 165, starTxt, {
      fontFamily: 'Arial, sans-serif', fontSize: '20px', color: stars > 0 ? '#ffd166' : '#4a5a7c'
    }).setOrigin(0.5));

    if (!unlocked) {
      var cover = this.add.graphics();
      cover.fillStyle(0x05070f, 0.62); cover.fillRoundedRect(panelX, y0, panelW, panelH, 16);
      this.stageLayer.add(cover);
      this.stageLayer.add(this.add.text(panelX + panelW / 2, y0 + panelH / 2, '🔒 Verrouillé\nTerminez le stage précédent', {
        fontFamily: 'Arial, sans-serif', fontSize: '18px', fontStyle: 'bold', color: '#ffd166', align: 'center'
      }).setOrigin(0.5));
    }
  }

  // =====================================================================
  // Difficulté
  // =====================================================================
  _buildDifficultyChips() {
    var self = this, w = this.scale.width, EN = NEBUSTION.Enemies;
    var y = this.stageTop + 216;
    var order = EN.DIFFICULTY_ORDER;
    var gap = 8, chipW = (w - 28 - gap * (order.length - 1)) / order.length;
    var colors = { facile: 0x5fd97a, normal: 0x4fd1ff, difficile: 0xffb84d, cauchemar: 0xff4d5e };
    this.diffChips = [];
    order.forEach(function (id, i) {
      var x = 14 + chipW / 2 + i * (chipW + gap);
      var c = self.add.container(x, y).setDepth(60);
      var bg = self.add.graphics(); c.add(bg);
      var label = self.add.text(0, 0, EN.DIFFICULTIES[id].name, {
        fontFamily: 'Arial, sans-serif', fontSize: '15px', fontStyle: 'bold', color: '#eaf2ff'
      }).setOrigin(0.5);
      c.add(label);
      var zone = self.add.zone(0, 0, chipW, 40).setInteractive({ useHandCursor: true });
      c.add(zone);
      zone.on('pointerdown', function () {
        self.difficulty = id;
        NEBUSTION.Combat.setDifficulty(id);
        self._refreshDifficulty();
        self._refreshRewards();
        self._refreshLaunch();
      });
      self.diffChips.push({
        id: id,
        draw: function (active) {
          bg.clear();
          bg.fillStyle(colors[id], active ? 0.9 : 0.12);
          bg.fillRoundedRect(-chipW / 2, -20, chipW, 40, 12);
          bg.lineStyle(2, colors[id], active ? 1 : 0.55);
          bg.strokeRoundedRect(-chipW / 2, -20, chipW, 40, 12);
          label.setColor(active ? '#0a0f1e' : '#eaf2ff');
        }
      });
    });
  }

  _refreshDifficulty() {
    var self = this;
    this.diffChips.forEach(function (c) { c.draw(c.id === self.difficulty); });
  }

  // =====================================================================
  // Récompenses + niveau recommandé
  // =====================================================================
  _refreshRewards() {
    var self = this, w = this.scale.width;
    var EN = NEBUSTION.Enemies, E = NEBUSTION.Economy, C = NEBUSTION.Combat;
    var st = this._stage();
    this.rewardsLayer.removeAll(true);
    var y0 = this.stageTop + 250;

    var r = EN.rewardsFor(st, this.difficulty, 3);
    var items = [];
    E.ORDER.forEach(function (rid) { if (r[rid]) items.push({ icon: 'tex_icon_' + rid, text: E.fmtGain(r[rid]), color: E.RES[rid].hex }); });
    var cellW = 92, startX = w / 2 - (items.length * cellW) / 2 + cellW / 2;
    this.rewardsLayer.add(this.add.text(20, y0 - 2, 'Récompenses (3★)', {
      fontFamily: 'Arial, sans-serif', fontSize: '12px', color: '#7a89ad'
    }));
    items.forEach(function (it, i) {
      var x = startX + i * cellW;
      self.rewardsLayer.add(self.add.image(x - 20, y0 + 28, it.icon).setDisplaySize(30, 30));
      self.rewardsLayer.add(self.add.text(x - 2, y0 + 28, it.text, {
        fontFamily: 'Arial, sans-serif', fontSize: '15px', fontStyle: 'bold', color: it.color
      }).setOrigin(0, 0.5));
    });
    this.rewardsLayer.add(this.add.text(w / 2, y0 + 56, 'XP +' + r.xp + '   ·   Fragments +' + r.fragments + ' par héros', {
      fontFamily: 'Arial, sans-serif', fontSize: '14px', color: '#c7d1ea'
    }).setOrigin(0.5));

    // Niveau recommandé vs niveau moyen de l'équipe
    var rec = EN.recommendedLevel(st.id, this.difficulty);
    var avg = this._avgLevel();
    var verdict, color;
    if (avg >= rec) { verdict = 'Équipe prête'; color = '#5fd97a'; }
    else if (avg >= rec * 0.75) { verdict = 'Combat risqué'; color = '#ffb84d'; }
    else { verdict = 'Très difficile'; color = '#ff4d5e'; }
    this.rewardsLayer.add(this.add.text(w - 20, y0 - 2, 'Niveau conseillé : ' + rec + '  ·  ' + verdict, {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', fontStyle: 'bold', color: color
    }).setOrigin(1, 0));
  }

  // =====================================================================
  // Lancement
  // =====================================================================
  _buildLaunch() {
    var self = this, w = this.scale.width;
    this.launchBtn = new NEBUSTION.Button(this, w / 2, 1108, {
      width: 420, height: 68, label: 'LANCER LE COMBAT', fontSize: '22px', accentColor: 0xff4d6d,
      onClick: function () { self._launch(); }
    });
    this.launchBtn.setDepth(70);
    this.hintText = this.add.text(w / 2, 1058, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '14px', fontStyle: 'bold', color: '#ffb84d', align: 'center'
    }).setOrigin(0.5).setDepth(70);
  }

  _canLaunch() {
    return this.team.length === 5 && NEBUSTION.Combat.isStageUnlocked(this._stage().id) && this._busyMembers().length === 0;
  }

  _busyMembers() {
    if (!NEBUSTION.ExpeditionManager || !NEBUSTION.ExpeditionManager.busyTeamMembers) return [];
    return NEBUSTION.ExpeditionManager.busyTeamMembers(this.team);
  }

  _refreshLaunch() {
    this.launchBtn.setDisabled(!this._canLaunch());
    var busy = this._busyMembers();
    if (this.team.length < 5) this.hintText.setText('Choisissez ' + (5 - this.team.length) + ' héros de plus pour former l\'équipe.');
    else if (!NEBUSTION.Combat.isStageUnlocked(this._stage().id)) this.hintText.setText('Stage verrouillé : terminez le précédent.');
    else if (busy.length > 0) this.hintText.setText((busy.length > 1 ? busy.length + ' héros sont' : 'Un héros est') + ' en expédition : impossible de lancer.');
    else this.hintText.setText('');
  }

  _hint(msg) {
    var self = this;
    this.hintText.setText(msg);
    if (this._hintTimer) this._hintTimer.remove(false);
    this._hintTimer = this.time.delayedCall(2200, function () { self._refreshLaunch(); });
  }

  _launch() {
    if (this._launching) return;
    if (!this._canLaunch()) { this._refreshLaunch(); return; }
    this._launching = true;
    var self = this, stage = this._stage();
    NEBUSTION.Combat.setTeam(this.team);
    NEBUSTION.Combat.setDifficulty(this.difficulty);
    this.cameras.main.fadeOut(350, 5, 7, 15);
    this.cameras.main.once('camerafadeoutcomplete', function () {
      self.scene.start('CombatScene', { stageId: stage.id, difficulty: self.difficulty });
    });
  }

  _refreshAll() {
    this._refreshSlots();
    this._refreshPicker();
    this._refreshStage();
    this._refreshDifficulty();
    this._refreshRewards();
    this._refreshLaunch();
    this.powerText.setText('Puissance d\'équipe : ' + this._teamPower() + '   ·   ' + this.team.length + '/5 héros');
  }
};
