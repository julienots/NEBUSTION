/**
 * NEBUSTION - GalaxyScene (module Invasions / Conquêtes 5C)
 * Écran « Galaxie » : onglets de secteurs (déblocage progressif), carte du secteur (planètes, routes,
 * frontière d'invasion, conquêtes), liste des planètes, fiche de la planète choisie avec SCAN puis INVASION.
 *
 * Aucune logique de jeu ici : tout vient des modules existants —
 *   Galaxy (données), GalaxyManager (secteurs, scans, conquêtes, colonies), EmpireEvolutionManager
 *   (carte évoluée, plan d'invasion, réactions des empires, IA 5B), Combat/CombatScene (le combat lui-même).
 * La scène ne fait qu'afficher l'état et appeler ces modules ; la sauvegarde est celle du jeu (state.galaxy / state.empires).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.GalaxyScene = class GalaxyScene extends Phaser.Scene {
  constructor() {
    super('GalaxyScene');
  }

  init(data) {
    this._initData = data || {};
  }

  // =====================================================================
  // Création
  // =====================================================================
  create() {
    var w = this.scale.width;
    var G = NEBUSTION.Galaxy, GM = NEBUSTION.GalaxyManager, EEM = NEBUSTION.EmpireEvolutionManager;
    var self = this;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(300, 5, 7, 15);
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });

    this._launching = false;
    this._pulses = [];
    this._twinkles = []; this._flows = []; this._halos = [];
    this._disk = null; this._diskBack = null; this._core = null; this._shoot = null; this._diskAng = 0;
    this._pulseT = 0;

    var now = Date.now();
    GM.update(now);                 // termine les scans arrivés à échéance (aussi après une absence)
    GM.collectColonies(now);        // verse les revenus des planètes conquises
    EEM.update(now);                // fait évoluer les empires jusqu'à maintenant

    var d = this._initData, startPlanet = d.planetId && G.planet(d.planetId) ? d.planetId : null;
    var sid = startPlanet ? G.planet(startPlanet).sector : (G.sector(d.sector) ? d.sector : GM.currentSector());
    if (!GM.isSectorUnlocked(sid)) sid = GM.currentSector();
    this.sectorId = sid;
    this.selPid = startPlanet && G.planet(startPlanet).sector === sid ? startPlanet : this._defaultPlanet(sid);

    this.add.text(w / 2, 126, 'GALAXIE', {
      fontFamily: 'Arial, sans-serif', fontSize: '20px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(50).setShadow(0, 0, '#6c3ce9', 10, true, true);

    // Portail vers l'Univers : voyager au-delà de la Voie Aube, vers d'autres galaxies.
    if (NEBUSTION.UniverseScene) {
      var universeBtn = new NEBUSTION.Button(this, w - 46, 126, {
        width: 56, height: 44, accentColor: 0xff3b1e,
        iconDraw: function (g) {
          g.lineStyle(2.5, 0xff3b1e, 1);
          g.strokeCircle(0, 0, 10);
          g.strokeCircle(0, 0, 4);
        },
        onClick: function () {
          self.cameras.main.fadeOut(250, 5, 7, 15);
          self.cameras.main.once('camerafadeoutcomplete', function () { self.scene.start('UniverseScene', { from: 'GalaxyScene' }); });
        }
      });
      universeBtn.setDepth(50);
    }

    this.tabLayer = this.add.container(0, 0).setDepth(60);
    this.bannerLayer = this.add.container(0, 0).setDepth(60);
    this.mapLayer = this.add.container(0, 0).setDepth(60);
    this.detailLayer = this.add.container(0, 0).setDepth(62);
    this.chipLayer = this.add.container(0, 0).setDepth(60);

    this.hud = NEBUSTION.HUD.attach(this);
    this.fx = new NEBUSTION.FX(this);
    new NEBUSTION.BottomNav(this, 'galaxy');

    // Événements des modules : rafraîchissent l'écran (retirés à la fermeture de la scène).
    this._off = [
      GM.on('scanDone', function (e) {
        var p = G.planet(e.planet);
        self.fx.toast('Scan terminé', p ? p.name : '');
        self._refresh();
      }),
      GM.on('colonyIncome', function (e) {
        var parts = [];
        NEBUSTION.Economy.ORDER.forEach(function (rid) { if (e.gains[rid]) parts.push('+' + NEBUSTION.Economy.fmtGain(e.gains[rid]) + ' ' + NEBUSTION.Economy.RES[rid].short); });
        if (parts.length) self.fx.toast('Revenus des colonies', parts.slice(0, 3).join('  '));
      })
    ];
    this.events.once('shutdown', function () { self._off.forEach(function (f) { try { f(); } catch (e) { /* ignore */ } }); if (self._tickEv) self._tickEv.remove(false); });

    this._tickEv = this.time.addEvent({ delay: 500, loop: true, callback: function () { self._tick(); } });
    this._refresh();
  }

  update(time, delta) {
    var dt = (delta || 16) / 1000, T;
    this._pulseT += dt; T = this._pulseT;
    var a = 0.4 + 0.35 * Math.sin(T * 3.2), i;
    for (i = 0; i < this._pulses.length; i++) { var g = this._pulses[i]; if (g && g.active) g.setAlpha(a); }
    // disque galactique : rotation très lente (2 couches en sens inverse = profondeur)
    if (this._disk && this._disk.active) {
      this._diskAng += dt * 0.03;
      this._disk.setRotation(this._diskAng);
      if (this._diskBack && this._diskBack.active) this._diskBack.setRotation(1.3 - this._diskAng * 0.55);
    }
    if (this._core && this._core[0].active) {
      var k = 1 + 0.07 * Math.sin(T * 1.5);
      this._core[0].setDisplaySize(230 * k, 150 * k).setAlpha(0.45 + 0.12 * Math.sin(T * 1.5));
      this._core[1].setDisplaySize(64 * k, 42 * k);
    }
    for (i = 0; i < this._twinkles.length; i++) {
      var t = this._twinkles[i];
      if (t.img && t.img.active) t.img.setAlpha(t.lo + (t.hi - t.lo) * (0.5 + 0.5 * Math.sin(T * t.sp + t.ph)));
    }
    for (i = 0; i < this._halos.length; i++) {
      var h = this._halos[i];
      if (h.img && h.img.active) h.img.setAlpha(h.base * (0.8 + 0.25 * Math.sin(T * h.sp * 1.7 + h.ph)));
    }
    for (i = 0; i < this._flows.length; i++) {
      var f = this._flows[i];
      if (!f.img || !f.img.active) continue;
      f.t = (f.t + dt * f.sp) % 1;
      f.img.setPosition(f.ax + (f.bx - f.ax) * f.t, f.ay + (f.by - f.ay) * f.t).setAlpha(Math.sin(f.t * Math.PI));
    }
    var sh = this._shoot, R = this._mapRect;
    if (sh && sh.img.active && R) {
      if (!sh.active && T > sh.next) {
        sh.active = true; sh.t = 0;
        sh.x = R.x + 40 + Math.random() * (R.w * 0.6); sh.y = R.y + 12 + Math.random() * 60;
        var ang = 0.35 + Math.random() * 0.4; sh.vx = Math.cos(ang) * 520; sh.vy = Math.sin(ang) * 520;
        sh.img.setRotation(ang);
      }
      if (sh.active) {
        sh.t += dt; sh.x += sh.vx * dt; sh.y += sh.vy * dt;
        sh.img.setPosition(sh.x, sh.y).setAlpha(Math.max(0, Math.sin(Math.min(1, sh.t / 0.8) * Math.PI)) * 0.9);
        if (sh.t > 0.8 || sh.x > R.x + R.w || sh.y > R.y + R.h) { sh.active = false; sh.img.setAlpha(0); sh.next = T + 6 + Math.random() * 8; }
      }
    }
  }

  /** Toutes les 500 ms : finit les scans, verse les revenus, met la fiche à jour pendant un scan. */
  _tick() {
    var GM = NEBUSTION.GalaxyManager, now = Date.now();
    var done = GM.update(now);                       // émet 'scanDone' → rafraîchit
    GM.collectColonies(now);
    if (!done.length && this.selPid && GM.scanState(this.selPid, now).status === 'scanning') this._buildDetail();
  }

  // =====================================================================
  // Sélection
  // =====================================================================
  /** Planète proposée par défaut dans un secteur : à la frontière et scannée, sinon à la frontière, sinon la première libre. */
  _defaultPlanet(sid) {
    var G = NEBUSTION.Galaxy, GM = NEBUSTION.GalaxyManager, EEM = NEBUSTION.EmpireEvolutionManager, now = Date.now();
    var list = G.planetsOf(sid).filter(function (p) { return p.kind !== 'home'; });
    var free = list.filter(function (p) { return !GM.isConquered(p.id); });
    var front = free.filter(function (p) { return EEM.isReachable(p.id); });
    var scanned = front.filter(function (p) { return GM.isScanned(p.id, now); });
    var pick = scanned[0] || front[0] || free[0] || list[0] || G.planetsOf(sid)[0];
    return pick ? pick.id : null;
  }

  _selectSector(sid) {
    if (sid === this.sectorId) return;
    this.sectorId = sid;
    this.selPid = NEBUSTION.GalaxyManager.isSectorUnlocked(sid) ? this._defaultPlanet(sid) : null;
    this._refresh();
  }

  _selectPlanet(pid) {
    this.selPid = pid;
    var G = NEBUSTION.Galaxy, p = G.planet(pid);
    if (p && p.kind !== 'home') NEBUSTION.GalaxyManager.visit(pid, Date.now());   // votre présence est connue de l'empire (IA)
    this._refresh();
  }

  // =====================================================================
  // Outils d'affichage
  // =====================================================================
  _t(layer, x, y, str, size, color, o) {
    o = o || {};
    var st = { fontFamily: 'Arial, sans-serif', fontSize: size + 'px', color: color || '#eaf2ff' };
    if (o.bold) st.fontStyle = 'bold';
    if (o.wrap) st.wordWrap = { width: o.wrap };
    if (o.align) st.align = o.align;
    var t = this.add.text(x, y, str, st).setOrigin(o.ox === undefined ? 0 : o.ox, o.oy === undefined ? 0 : o.oy);
    layer.add(t);
    return t;
  }

  _box(layer, x, y, w, h, line, lineAlpha, fillTop, fillBot) {
    var g = this.add.graphics();
    g.fillGradientStyle(fillTop || 0x151d33, fillTop || 0x151d33, fillBot || 0x0a0f1e, fillBot || 0x0a0f1e, 0.94);
    g.fillRoundedRect(x, y, w, h, 16);
    g.lineStyle(2, line === undefined ? 0x2b3a5c : line, lineAlpha === undefined ? 0.9 : lineAlpha);
    g.strokeRoundedRect(x, y, w, h, 16);
    layer.add(g);
    return g;
  }

  _n(v) {
    v = Math.round(Number(v) || 0);
    var s = String(Math.abs(v)), out = '';
    for (var i = 0; i < s.length; i++) { if (i && (s.length - i) % 3 === 0) out += ' '; out += s[i]; }
    return (v < 0 ? '-' : '') + out;
  }

  _dur(ms) {
    var s = Math.max(0, Math.ceil(ms / 1000));
    if (s >= 3600) return Math.floor(s / 3600) + ' h ' + ('0' + Math.floor((s % 3600) / 60)).slice(-2);
    if (s >= 60) return Math.floor(s / 60) + ' min ' + ('0' + (s % 60)).slice(-2);
    return s + ' s';
  }

  _short(name, max) {
    var n = String(name);
    if (n.indexOf(' · ') >= 0) n = n.split(' · ')[1];
    return n.length > max ? n.slice(0, max - 1) + '…' : n;
  }

  /** Icônes + montants d'un lot de ressources (récompenses, coûts, revenus). Retourne la largeur utilisée. */
  _resRow(layer, x, y, amounts, opts) {
    opts = opts || {};
    var E = NEBUSTION.Economy, self = this, cx = x, suffix = opts.suffix || '', size = opts.size || 30;
    E.ORDER.forEach(function (rid) {
      var v = amounts[rid];
      if (!v) return;
      layer.add(self.add.image(cx + size / 2, y + size / 2, 'tex_icon_' + rid).setDisplaySize(size, size));
      var t = self._t(layer, cx + size + 5, y + size / 2, (opts.plus === false ? '' : '+') + E.fmtGain(v) + suffix, opts.font || 16, E.RES[rid].hex, { bold: true, oy: 0.5 });
      cx += size + 5 + Math.max(24, t.width) + 14;
    });
    return cx - x;
  }

  // =====================================================================
  // Rafraîchissement complet
  // =====================================================================
  _refresh() {
    var GM = NEBUSTION.GalaxyManager, EEM = NEBUSTION.EmpireEvolutionManager, now = Date.now();
    this.mv = EEM.mapView(now);
    this.mvIndex = {};
    var self = this;
    this.mv.planets.forEach(function (p) { self.mvIndex[p.id] = p; });
    this._pulses = []; this._twinkles = []; this._flows = []; this._halos = [];
    this._disk = null; this._diskBack = null; this._core = null; this._shoot = null;
    this.detailLayer.removeAll(true);
    this.mapLayer.removeAll(true);
    this.chipLayer.removeAll(true);
    this._buildTabs();
    this._buildBanner();
    if (!GM.isSectorUnlocked(this.sectorId)) {
      this._buildLocked();
    } else {
      this._buildMap();
      this._buildDetail();
      this._buildChips();
    }
  }

  // ---------------------------------------------------------------------
  // Onglets de secteurs
  // ---------------------------------------------------------------------
  _buildTabs() {
    var self = this, G = NEBUSTION.Galaxy, GM = NEBUSTION.GalaxyManager, L = this.tabLayer;
    L.removeAll(true);
    var names = { s1: 'Origine', s2: 'Vexor', s3: 'Kael-9', s4: 'Elyra', s5: 'Morvak', s6: 'Nyr\'ah', s7: 'Écarlate' };
    var n = G.SECTORS.length, gap = 6, margin = 14;
    var tw = Math.min(110, Math.floor((this.scale.width - margin * 2 - (n - 1) * gap) / n));
    var fontSize = tw < 90 ? 12 : 15;
    var x0 = (this.scale.width - (n * tw + (n - 1) * gap)) / 2, y = 150, h = 44;
    G.SECTORS.forEach(function (sec, i) {
      var x = x0 + i * (tw + gap), unlocked = GM.isSectorUnlocked(sec.id), active = sec.id === self.sectorId;
      var E = sec.empire ? G.empire(sec.empire) : null, col = E ? E.color : 0x4fd1ff;
      var g = self.add.graphics();
      g.fillStyle(active ? 0x1b2745 : 0x0a0f1e, active ? 0.98 : 0.85);
      g.fillRoundedRect(x, y, tw, h, 12);
      g.lineStyle(active ? 3 : 2, active ? col : 0x2b3a5c, active ? 1 : 0.8);
      g.strokeRoundedRect(x, y, tw, h, 12);
      L.add(g);
      var label = (unlocked ? '' : '🔒 ') + names[sec.id];
      self._t(L, x + tw / 2, y + h / 2, label, fontSize, active ? '#ffffff' : (unlocked ? '#a9b8dc' : '#5c6b8a'), { bold: active, ox: 0.5, oy: 0.5 });
      var zone = self.add.zone(x, y, tw, h).setOrigin(0).setInteractive({ useHandCursor: true });
      zone.on('pointerdown', function () { self._selectSector(sec.id); });
      L.add(zone);
    });
  }

  // ---------------------------------------------------------------------
  // Bandeau du secteur (empire, doctrine, alerte, territoire)
  // ---------------------------------------------------------------------
  _buildBanner() {
    var G = NEBUSTION.Galaxy, GM = NEBUSTION.GalaxyManager, L = this.bannerLayer, sec = G.sector(this.sectorId);
    L.removeAll(true);
    var E = sec.empire ? G.empire(sec.empire) : null, col = E ? E.color : 0x4fd1ff, hex = E ? E.hex : '#4fd1ff';
    this._box(L, 20, 202, 680, 70, col, 0.7);
    this._t(L, 38, 210, sec.name, 20, hex, { bold: true });
    var conquered = G.planetsOf(sec.id).filter(function (p) { return p.kind !== 'home' && GM.isConquered(p.id); }).length;
    var total = G.planetsOf(sec.id).filter(function (p) { return p.kind !== 'home'; }).length;
    if (E) {
      var em = this.mv.empires[E.id], post = { defensive: 'défensive', balanced: 'équilibrée', offensive: 'offensive' }[em.posture] || '—';
      this._t(L, 38, 238, E.subtitle + ' · Doctrine ' + (em.strategy || '—') + ' (' + post + ') · Dév. ' + em.evo + '/8', 12, '#a9b8dc');
      this._t(L, 38, 254, 'Territoire : ' + em.owned + '/' + em.total + ' planètes tenues', 12, '#7a89ad');
      // alerte 0..3
      var labels = ['CALME', 'VIGILANT', 'EN ALERTE', 'MOBILISÉ'], cols = [0x5fd97a, 0xffd166, 0xff9f43, 0xff4d5e];
      var g = this.add.graphics();
      for (var i = 0; i < 3; i++) { g.fillStyle(i < em.alert ? cols[em.alert] : 0x2b3a5c, 1); g.fillRoundedRect(590 + i * 30, 214, 26, 8, 3); }
      L.add(g);
      this._t(L, 682, 232, labels[em.alert] || '', 13, '#' + ('000000' + cols[em.alert].toString(16)).slice(-6), { bold: true, ox: 1 });
      this._t(L, 682, 252, conquered + '/' + total + ' conquises', 12, '#7dff9a', { ox: 1 });
    } else {
      this._t(L, 38, 238, sec.subtitle + ' · ' + total + ' mondes libres', 12, '#a9b8dc');
      this._t(L, 38, 254, sec.description, 12, '#7a89ad', { wrap: 640 });
      this._t(L, 682, 214, conquered + '/' + total + ' conquises', 13, '#7dff9a', { ox: 1, bold: true });
    }
  }

  // ---------------------------------------------------------------------
  // Secteur verrouillé : conditions et coût
  // ---------------------------------------------------------------------
  _buildLocked() {
    var self = this, G = NEBUSTION.Galaxy, GM = NEBUSTION.GalaxyManager, E = NEBUSTION.Economy, L = this.detailLayer;
    var sec = G.sector(this.sectorId), st = GM.sectorStatus(this.sectorId, Date.now());
    var emp = sec.empire ? G.empire(sec.empire) : null, col = emp ? emp.color : 0x4fd1ff;
    this._box(L, 20, 282, 680, 740, col, 0.8);
    this._t(L, 360, 318, '🔒 SECTEUR VERROUILLÉ', 26, '#ffd166', { bold: true, ox: 0.5, oy: 0.5 });
    this._t(L, 360, 352, sec.name + ' — ' + sec.subtitle, 16, emp ? emp.hex : '#eaf2ff', { bold: true, ox: 0.5, oy: 0.5 });
    this._t(L, 360, 400, sec.description, 15, '#a9b8dc', { wrap: 600, align: 'center', ox: 0.5 });
    if (emp) this._t(L, 360, 462, emp.description, 13, '#7a89ad', { wrap: 600, align: 'center', ox: 0.5 });

    var y = 560;
    this._t(L, 50, y, 'CONDITIONS', 15, '#00e5ff', { bold: true });
    y += 34;
    st.reqs.forEach(function (r) {
      self._t(L, 50, y, (r.ok ? '✔ ' : '✖ ') + r.label, 16, r.ok ? '#7dff9a' : '#ff8a94', { bold: true });
      self._t(L, 670, y, r.cur + ' / ' + r.need, 16, r.ok ? '#7dff9a' : '#ffb84d', { ox: 1, bold: true });
      y += 34;
    });
    y += 14;
    this._t(L, 50, y, 'COÛT DU DÉBLOCAGE', 15, '#00e5ff', { bold: true });
    y += 34;
    st.cost.forEach(function (c) {
      L.add(self.add.image(70, y + 12, 'tex_icon_' + c.res).setDisplaySize(30, 30));
      self._t(L, 96, y + 12, E.RES[c.res].short, 16, '#c7d1ea', { oy: 0.5 });
      self._t(L, 670, y + 12, E.fmtGain(c.have) + ' / ' + E.fmtGain(c.amount), 16, c.ok ? '#7dff9a' : '#ff8a94', { ox: 1, oy: 0.5, bold: true });
      y += 38;
    });
    var can = st.canUnlock;
    var btn = new NEBUSTION.Button(this, 360, 940, {
      width: 460, height: 72, label: can ? 'DÉBLOQUER LE SECTEUR' : 'CONDITIONS NON REMPLIES', fontSize: '20px', accentColor: can ? 0xffd166 : 0x394869, disabled: !can,
      onClick: function () { self._doUnlock(self.sectorId); }
    });
    L.add(btn);
    this._lockBtn = btn;
    this._t(L, 360, 992, 'Terminez des stages, scannez le secteur précédent et réunissez les ressources.', 12, '#7a89ad', { ox: 0.5, oy: 0.5 });
  }

  _doUnlock(sid) {
    var GM = NEBUSTION.GalaxyManager, r = GM.unlockSector(sid, Date.now());
    if (r.ok) {
      this.fx.toast('Secteur débloqué !', NEBUSTION.Galaxy.sector(sid).name);
      this.selPid = this._defaultPlanet(sid);
      this._refresh();
    } else {
      var msg = { requirements: 'Conditions non remplies', cost: 'Ressources insuffisantes', already: 'Déjà débloqué' }[r.reason] || 'Impossible';
      this.fx.toast('Déblocage refusé', msg);
    }
    return r;
  }

  // ---------------------------------------------------------------------
  // Carte du secteur
  // ---------------------------------------------------------------------
  _planetStatus(pid) {
    var GM = NEBUSTION.GalaxyManager, EEM = NEBUSTION.EmpireEvolutionManager, G = NEBUSTION.Galaxy, now = Date.now();
    var p = G.planet(pid);
    if (p.kind === 'home') return { home: true, conquered: true, scan: { status: 'scanned' }, reachable: true };
    var info = this.mvIndex[pid] || {};
    return { home: false, conquered: GM.isConquered(pid), scan: GM.scanState(pid, now), reachable: EEM.isReachable(pid), alert: info.alert || 0 };
  }

  _buildMap() {
    var self = this, G = NEBUSTION.Galaxy, GM = NEBUSTION.GalaxyManager, L = this.mapLayer, GB = NEBUSTION.GalaxyBackdrop;
    var sec = G.sector(this.sectorId), planets = G.planetsOf(this.sectorId);
    var px = 20, py = 280, pw = 680, ph = 340;
    var emp = sec.empire ? G.empire(sec.empire) : null, col = emp ? emp.color : 0x4fd1ff;
    var ADD = Phaser.BlendModes.ADD;
    this._mapRect = { x: px, y: py, w: pw, h: ph };

    // ---- Décor : fond profond + disque galactique spiral incliné qui tourne lentement ----
    var keys = GB.ensure(this, this.sectorId, pw, ph, col);
    L.add(this.add.image(px, py, keys.bg).setOrigin(0));
    var ccx = px + pw / 2, ccy = py + ph / 2 + 4, tilt = -0.2 + (this.sectorId.charCodeAt(1) % 3) * 0.13;
    var tiltBox = this.add.container(ccx, ccy).setRotation(tilt).setScale(0.92, 0.46);
    var back = this.add.image(0, 0, keys.disk).setScale(1.32).setAlpha(0.3).setBlendMode(ADD).setRotation(1.3);
    var disk = this.add.image(0, 0, keys.disk).setBlendMode(ADD).setRotation(this._diskAng || 0);
    tiltBox.add([back, disk]);
    L.add(tiltBox);
    this._disk = disk; this._diskBack = back;
    var coreBig = this.add.image(ccx, ccy, 'tex_glow_gold').setBlendMode(ADD).setDisplaySize(230, 150).setAlpha(0.5);
    var coreHot = this.add.image(ccx, ccy, 'tex_glow_white').setBlendMode(ADD).setDisplaySize(64, 42).setAlpha(0.85);
    L.add([coreBig, coreHot]);
    this._core = [coreBig, coreHot];

    // étoiles qui scintillent + étoile filante
    var rs = 31 + this.sectorId.charCodeAt(1) * 7;
    function rnd() { rs = (rs * 1664525 + 1013904223) >>> 0; return rs / 4294967296; }
    for (var i = 0; i < 34; i++) {
      var tw = this.add.image(px + 12 + rnd() * (pw - 24), py + 12 + rnd() * (ph - 24), rnd() > 0.7 ? 'tex_star_big' : 'tex_star_small')
        .setScale(0.35 + rnd() * 0.55).setBlendMode(ADD).setTint(rnd() > 0.5 ? 0xbfe0ff : (rnd() > 0.5 ? 0xffe2b8 : 0xffffff));
      L.add(tw);
      this._twinkles.push({ img: tw, ph: rnd() * 6.28, sp: 0.8 + rnd() * 2.2, lo: 0.1 + rnd() * 0.25, hi: 0.7 + rnd() * 0.3 });
    }
    var shoot = this.add.image(-50, -50, 'tex_glow_white').setBlendMode(ADD).setDisplaySize(90, 5).setAlpha(0);
    L.add(shoot);
    this._shoot = { img: shoot, active: false, t: 0, next: this._pulseT + 3 + rnd() * 4, x: 0, y: 0, vx: 0, vy: 0 };

    var frame = this.add.graphics();
    frame.lineStyle(2, col, 0.5); frame.strokeRoundedRect(px, py, pw, ph, 18);
    frame.lineStyle(6, col, 0.08); frame.strokeRoundedRect(px + 1, py + 1, pw - 2, ph - 2, 18);
    L.add(frame);

    var minx = 1e9, maxx = -1e9, miny = 1e9, maxy = -1e9;
    planets.forEach(function (p) { minx = Math.min(minx, p.x); maxx = Math.max(maxx, p.x); miny = Math.min(miny, p.y); maxy = Math.max(maxy, p.y); });
    var padX = 74, padTop = 82, padBot = 74;
    var s = Math.min((pw - 2 * padX) / Math.max(1, maxx - minx), (ph - padTop - padBot) / Math.max(1, maxy - miny), 1.1);
    var ox = px + pw / 2 - ((minx + maxx) / 2) * s, oy = py + padTop + (ph - padTop - padBot) / 2 - ((miny + maxy) / 2) * s;
    this._pos = {};
    planets.forEach(function (p) {
      self._pos[p.id] = { x: ox + p.x * s, y: oy + p.y * s, rr: Math.max(20, Math.min(40, p.r * s * 0.8)) };
    });

    // ---- Routes : lueur multi-couches + particules d'énergie qui circulent ----
    var lanes = this.add.graphics();
    L.add(lanes);
    function glowLine(x1, y1, x2, y2, color, a) {
      lanes.lineStyle(10, color, a * 0.10); lanes.lineBetween(x1, y1, x2, y2);
      lanes.lineStyle(5, color, a * 0.22); lanes.lineBetween(x1, y1, x2, y2);
      lanes.lineStyle(2, color, Math.min(1, a * 1.15)); lanes.lineBetween(x1, y1, x2, y2);
    }
    function flow(x1, y1, x2, y2, color, speed, count) {
      for (var k = 0; k < count; k++) {
        var dot = self.add.image(x1, y1, 'tex_glow_white').setBlendMode(ADD).setTint(color).setDisplaySize(18, 18);
        L.add(dot);
        self._flows.push({ img: dot, ax: x1, ay: y1, bx: x2, by: y2, t: k / count, sp: speed });
      }
    }
    G.LANES.forEach(function (l) {
      var a = G.planet(l.a), b = G.planet(l.b);
      if (!a || !b) return;
      var ina = a.sector === self.sectorId, inb = b.sector === self.sectorId;
      if (ina && inb) {
        var pa = self._pos[a.id], pb = self._pos[b.id];
        var ca = a.kind === 'home' || GM.isConquered(a.id), cb = b.kind === 'home' || GM.isConquered(b.id);
        if (ca && cb) { glowLine(pa.x, pa.y, pb.x, pb.y, 0x5fd97a, 0.7); flow(pa.x, pa.y, pb.x, pb.y, 0x9dffb4, 0.22, 2); }
        else if (ca || cb) { glowLine(pa.x, pa.y, pb.x, pb.y, 0x4fd1ff, 0.6); flow(ca ? pa.x : pb.x, ca ? pa.y : pb.y, ca ? pb.x : pa.x, ca ? pb.y : pa.y, 0x8ff0ff, 0.14, 1); }
        else glowLine(pa.x, pa.y, pb.x, pb.y, 0x4a5b8f, 0.45);
      } else if (ina !== inb) {
        var mine = ina ? a : b, other = ina ? b : a, pm = self._pos[mine.id];
        var vx = other.x - mine.x, vy = other.y - mine.y, len = Math.sqrt(vx * vx + vy * vy) || 1; vx /= len; vy /= len;
        var open = GM.isConquered(other.id) || other.kind === 'home';
        var hc = open ? 0x5fd97a : 0x8a5cff;
        for (var k = 0; k < 3; k++) {   // amorce hyperspatiale en pointillés lumineux
          var s0 = pm.rr + 6 + k * 10;
          glowLine(pm.x + vx * s0, pm.y + vy * s0, pm.x + vx * (s0 + 6), pm.y + vy * (s0 + 6), hc, 0.8);
        }
        var ex = Math.max(px + 46, Math.min(px + pw - 46, pm.x + vx * (pm.rr + 52))), ey = Math.max(py + 14, Math.min(py + ph - 14, pm.y + vy * (pm.rr + 52)));
        self._t(L, ex, ey, (vy > 0 ? '▼ ' : '▲ ') + self._short(G.sector(other.sector).name, 18), 11, open ? '#7dff9a' : '#b9a3ff', { ox: 0.5, oy: 0.5 }).setStroke('#02030a', 3);
      }
    });

    // ---- Planètes : halo lumineux, anneau d'empire, frontière pulsante ----
    planets.forEach(function (p) {
      var pos = self._pos[p.id], st = self._planetStatus(p.id);
      var pt = G.PLANET_TYPES[p.type], atmo = pt ? parseInt(String(pt.atmo).replace('#', ''), 16) : 0x66e0ff;
      var pe = p.empire ? G.empire(p.empire) : null;
      var hc = st.home ? 0x4fd1ff : (st.conquered ? 0x5fd97a : (pe ? pe.color : atmo));
      var hs = pos.rr * (st.home ? 5.4 : 4.4);
      var halo = self.add.image(pos.x, pos.y, 'tex_glow_white').setBlendMode(ADD).setTint(hc).setDisplaySize(hs, hs).setAlpha(st.home ? 0.6 : 0.42);
      L.add(halo);
      self._halos.push({ img: halo, base: st.home ? 0.6 : 0.42, ph: Math.random() * 6.28, sp: 1 + Math.random() });
      var d = pos.rr * 2 * (NEBUSTION.GalaxyTextures.SIZE / (NEBUSTION.GalaxyTextures.R * 2));
      var texKey = st.home ? NEBUSTION.GalaxyTextures.homeKey() : NEBUSTION.GalaxyTextures.key(p.type);
      var img = self.add.image(pos.x, pos.y, texKey).setDisplaySize(d, d);
      L.add(img);
      var ring = self.add.graphics();
      if (pe) { ring.lineStyle(2, pe.color, 0.6); ring.strokeCircle(pos.x, pos.y, pos.rr + 3); }
      if (st.conquered && !st.home) { ring.lineStyle(3, 0x5fd97a, 0.95); ring.strokeCircle(pos.x, pos.y, pos.rr + 6); }
      if (st.home) { ring.lineStyle(2, 0x4fd1ff, 0.7); ring.strokeEllipse(pos.x, pos.y, pos.rr * 2 + 26, pos.rr * 0.9 + 10); }
      L.add(ring);
      var selected = p.id === self.selPid;
      if (selected) {
        var sg = self.add.graphics(); sg.lineStyle(3, 0xffffff, 0.95); sg.strokeCircle(pos.x, pos.y, pos.rr + 10);
        sg.lineStyle(8, 0xffffff, 0.12); sg.strokeCircle(pos.x, pos.y, pos.rr + 10); L.add(sg);
      }
      var front = !st.home && !st.conquered && st.reachable;
      if (front) {   // frontière : monde attaquable (relié à Nexus-01 ou à une conquête)
        var fg = self.add.graphics(); fg.lineStyle(3, 0x00e5ff, 1); fg.strokeCircle(pos.x, pos.y, pos.rr + 15);
        fg.lineStyle(9, 0x00e5ff, 0.18); fg.strokeCircle(pos.x, pos.y, pos.rr + 15); L.add(fg); self._pulses.push(fg);
      }
      if (p.isCapital) self._t(L, pos.x, pos.y - pos.rr - 12, '♛', 16, '#ffd166', { ox: 0.5, oy: 0.5 }).setShadow(0, 0, '#ffb300', 8, true, true);
      if (st.conquered && !st.home) self._t(L, pos.x + pos.rr * 0.75, pos.y - pos.rr * 0.8, '⚑', 18, '#7dff9a', { ox: 0.5, oy: 0.5 });
      if (!st.home && !st.conquered) {
        var sc = st.scan.status;
        if (sc === 'scanned') self._t(L, pos.x - pos.rr * 0.8, pos.y - pos.rr * 0.8, '◉', 15, '#00e5ff', { ox: 0.5, oy: 0.5 });
        else if (sc === 'scanning') self._t(L, pos.x - pos.rr * 0.8, pos.y - pos.rr * 0.8, '◌', 15, '#ffb84d', { ox: 0.5, oy: 0.5 });
      }
      self._t(L, pos.x, pos.y + pos.rr + 14, st.home ? 'Nexus-01' : self._short(p.name, 17), 12, selected ? '#ffffff' : (st.conquered ? '#7dff9a' : '#c7d1ea'), { bold: selected, ox: 0.5 }).setStroke('#02030a', 4);
      var zone = self.add.zone(pos.x - pos.rr - 10, pos.y - pos.rr - 10, pos.rr * 2 + 20, pos.rr * 2 + 34).setOrigin(0).setInteractive({ useHandCursor: true });
      zone.on('pointerdown', function () { self._selectPlanet(p.id); });
      L.add(zone);
    });
  }

  // ---------------------------------------------------------------------
  // Liste (cartes compactes) des planètes du secteur
  // ---------------------------------------------------------------------
  _statusLabel(pid) {
    var st = this._planetStatus(pid), GM = NEBUSTION.GalaxyManager;
    if (st.home) return { text: 'Planète-mère', color: '#4fd1ff' };
    if (st.conquered) return { text: 'Conquise ✔', color: '#7dff9a' };
    if (st.scan.status === 'scanning') return { text: 'Scan… ' + Math.round(st.scan.progress * 100) + ' %', color: '#ffb84d' };
    var tag = st.reachable ? '' : ' · loin';
    if (st.scan.status === 'scanned') return { text: 'Scannée ◉' + tag, color: '#00e5ff' };
    if (st.scan.status === 'expired') return { text: 'Scan expiré' + tag, color: '#ffb84d' };
    return { text: 'Inconnue' + tag, color: '#7a89ad' };
  }

  _buildChips() {
    var self = this, G = NEBUSTION.Galaxy, L = this.chipLayer;
    var planets = G.planetsOf(this.sectorId), n = planets.length;
    var gap = 8, cw = Math.min(150, (680 - (n - 1) * gap) / n), x0 = (this.scale.width - (n * cw + (n - 1) * gap)) / 2, y = 1034, h = 118;
    planets.forEach(function (p, i) {
      var x = x0 + i * (cw + gap), selected = p.id === self.selPid, st = self._statusLabel(p.id);
      var pe = p.empire ? G.empire(p.empire) : null;
      var g = self.add.graphics();
      g.fillStyle(selected ? 0x1b2745 : 0x0a0f1e, 0.95); g.fillRoundedRect(x, y, cw, h, 14);
      g.lineStyle(selected ? 3 : 2, selected ? 0xffffff : (pe ? pe.color : 0x2b3a5c), selected ? 1 : 0.6); g.strokeRoundedRect(x, y, cw, h, 14);
      L.add(g);
      L.add(self.add.image(x + cw / 2, y + 36, p.kind === 'home' ? NEBUSTION.GalaxyTextures.homeKey() : NEBUSTION.GalaxyTextures.key(p.type)).setDisplaySize(64, 64));
      self._t(L, x + cw / 2, y + 78, p.kind === 'home' ? 'Nexus-01' : self._short(p.name, 15), 12, '#eaf2ff', { bold: true, ox: 0.5, oy: 0.5 });
      self._t(L, x + cw / 2, y + 98, st.text, 11, st.color, { ox: 0.5, oy: 0.5 });
      var zone = self.add.zone(x, y, cw, h).setOrigin(0).setInteractive({ useHandCursor: true });
      zone.on('pointerdown', function () { self._selectPlanet(p.id); });
      L.add(zone);
    });
  }

  // ---------------------------------------------------------------------
  // Fiche de la planète choisie : scan, défenses, récompenses, invasion
  // ---------------------------------------------------------------------
  _buildDetail() {
    var self = this, G = NEBUSTION.Galaxy, GM = NEBUSTION.GalaxyManager, EEM = NEBUSTION.EmpireEvolutionManager, E = NEBUSTION.Economy;
    var L = this.detailLayer, now = Date.now();
    L.removeAll(true);
    var pid = this.selPid, p = pid ? G.planet(pid) : null;
    var X = 20, Y = 628, W = 680, H = 398;
    if (!p) return;
    var pe = p.empire ? G.empire(p.empire) : null, col = pe ? pe.color : 0x4fd1ff;
    this._box(L, X, Y, W, H, col, 0.75);

    // ---- Planète-mère : une vraie planète 2D/3D avec nos structures dessus (au lieu d'un simple
    // pavé de texte) — on voit et on gère sa base directement depuis la Galaxie, sans détour. ----
    if (p.kind === 'home') {
      var hcx = X + W / 2;
      this._t(L, 40, Y + 18, 'Nexus-01 · Planète-mère', 22, '#4fd1ff', { bold: true });
      this._t(L, hcx, Y + 48, 'Touchez une structure pour la gérer directement', 13, '#7a89ad', { ox: 0.5 });

      var sphereCy = Y + 178, sphereR = 72, ringR = 96, markR = 13;
      var haloHome = this.add.image(hcx, sphereCy, 'tex_glow_white').setBlendMode(Phaser.BlendModes.ADD)
        .setTint(0x4fd1ff).setDisplaySize(sphereR * 3.1, sphereR * 3.1).setAlpha(0.3);
      L.add(haloHome);
      this.tweens.add({ targets: haloHome, alpha: 0.46, duration: 2600, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
      var sphereImg = this.add.image(hcx, sphereCy, NEBUSTION.GalaxyTextures.homeKey()).setDisplaySize(sphereR * 2, sphereR * 2);
      L.add(sphereImg);
      this.tweens.add({ targets: sphereImg, angle: 360, duration: 70000, repeat: -1, ease: 'Linear' });
      var ringGfx = this.add.graphics(); ringGfx.lineStyle(1, 0x4fd1ff, 0.25); ringGfx.strokeCircle(hcx, sphereCy, ringR);
      L.add(ringGfx);

      // Les 7 structures principales de la base (mêmes bâtiments que sur PlanetScene) : un point
      // par structure, positionné autour de la sphère, avec son niveau réel. Tap → ouvre
      // directement le panneau de cette structure dans PlanetScene (plus besoin de la chercher).
      var HOME_STRUCTS = [
        { key: 'command', color: 0x00e5ff },
        { key: 'lab', color: 0x6c3ce9 },
        { key: 'hangar', color: 0xffd166 },
        { key: 'defense', color: 0xff4d6d },
        { key: 'qg', color: 0x5fd97a },
        { key: 'storage', color: 0x2dd4bf },
        { key: 'amplifier', color: 0xffa63d }
      ];
      HOME_STRUCTS.forEach(function (s, i) {
        var def = E.BUILDINGS[s.key];
        if (!def) return;
        var ang = -Math.PI / 2 + i * (Math.PI * 2 / HOME_STRUCTS.length);
        var mx = hcx + Math.cos(ang) * ringR, my = sphereCy + Math.sin(ang) * ringR;
        var lvl = (NEBUSTION.Resources && NEBUSTION.Resources.level) ? NEBUSTION.Resources.level(s.key) : '—';
        var dot = self.add.circle(mx, my, markR, s.color, 0.92).setStrokeStyle(2, 0x02030a, 0.9);
        L.add(dot);
        self._t(L, mx, my, def.name.charAt(0).toUpperCase(), 13, '#02030a', { bold: true, ox: 0.5, oy: 0.5 });
        self._t(L, mx, my + markR + 12, 'Nv.' + lvl, 11, '#c7d1ea', { ox: 0.5, oy: 0.5 }).setStroke('#02030a', 3);
        var zone = self.add.zone(mx, my, markR * 2 + 14, markR * 2 + 26).setOrigin(0.5).setInteractive({ useHandCursor: true });
        zone.on('pointerdown', function () {
          try { self.fx.vibrate(15); } catch (_) {}
          self.tweens.add({ targets: dot, scale: 0.8, duration: 70, yoyo: true });
          self._go('PlanetScene', { navKey: 'planet', title: 'Planète', openBuilding: s.key });
        });
        L.add(zone);
      });

      var conq = Object.keys(GM.state().conquered).length, rates = GM.colonyRates();
      var has = Object.keys(rates).some(function (k) { return rates[k] > 0; });
      var statLine = conq + ' planète' + (conq > 1 ? 's' : '') + ' conquise' + (conq > 1 ? 's' : '') + (has ? ' · revenus de colonies actifs' : ' · conquérez des mondes pour des revenus permanents');
      this._t(L, hcx, Y + 296, statLine, 12, '#7a89ad', { ox: 0.5 });

      var enter = new NEBUSTION.Button(this, 360, Y + H - 52, {
        width: 420, height: 62, label: 'ENTRER SUR NEXUS-01', fontSize: '19px', accentColor: 0x00e5ff,
        onClick: function () { self._go('PlanetScene', { navKey: 'planet', title: 'Planète' }); }
      });
      L.add(enter);
      return;
    }

    var st = this._planetStatus(pid), sc = st.scan;
    var plan = EEM.invasionPlan(pid, now);
    var typeName = G.PLANET_TYPES[p.type] ? G.PLANET_TYPES[p.type].name : p.type;
    var owner = pe ? pe.name : (plan && plan.claimedBy ? 'Monde libre · revendiqué par ' + G.empire(plan.claimedBy).name : 'Monde libre');

    this._t(L, 40, Y + 16, p.name, 21, pe ? pe.hex : '#eaf2ff', { bold: true, wrap: 470 });
    this._t(L, 680, Y + 20, p.isCapital ? '♛ CAPITALE' : 'Palier ' + p.tier, 14, p.isCapital ? '#ffd166' : '#a9b8dc', { bold: true, ox: 1 });
    this._t(L, 40, Y + 46, typeName + ' · ' + owner, 13, '#a9b8dc');

    // ---- État : conquise / scan ----
    var sy = Y + 74, sText, sColor;
    if (st.conquered) { sText = '✔ Conquise — sous votre contrôle'; sColor = '#7dff9a'; }
    else if (sc.status === 'scanning') { sText = '◌ Scan en cours… ' + this._dur(sc.remainingMs); sColor = '#ffb84d'; }
    else if (sc.status === 'scanned') { sText = '◉ Scan valide · encore ' + this._dur(sc.validMs); sColor = '#00e5ff'; }
    else if (sc.status === 'expired') { sText = 'Scan expiré — relancez un scan'; sColor = '#ffb84d'; }
    else { sText = 'Non scannée'; sColor = '#7a89ad'; }
    this._t(L, 40, sy, sText, 15, sColor, { bold: true });
    if (!st.conquered) this._t(L, 680, sy, st.reachable ? '⚔ Frontière : attaquable' : '✖ Hors de portée', 13, st.reachable ? '#00e5ff' : '#ff8a94', { ox: 1, bold: true });
    if (sc.status === 'scanning') {
      var bg = this.add.graphics();
      bg.fillStyle(0x0a0f1e, 1); bg.fillRoundedRect(40, sy + 26, 600, 10, 5);
      bg.fillStyle(0xffb84d, 1); bg.fillRoundedRect(40, sy + 26, Math.max(8, 600 * sc.progress), 10, 5);
      L.add(bg);
    }

    var cy = Y + 106, hint = '';
    if (st.conquered) {
      // ---- Colonie ----
      this._t(L, 40, cy, 'COLONIE — REVENUS PAR HEURE', 14, '#00e5ff', { bold: true });
      this._resRow(L, 40, cy + 26, GM.colonyIncomeOf(pid), { suffix: '/h', font: 16 });
      if (pe) {
        var em = this.mv.empires[pe.id], post = { defensive: 'défensive', balanced: 'équilibrée', offensive: 'offensive' }[em.posture] || '—';
        this._t(L, 40, cy + 84, pe.name + ' a perdu cette planète (' + em.owned + '/' + em.total + ' tenues).', 14, '#eaf2ff', { wrap: 600 });
        this._t(L, 40, cy + 112, 'Doctrine : ' + (em.strategy || '—') + ' · posture ' + post + ' · alerte ' + em.alert + '/3', 13, '#a9b8dc', { wrap: 600 });
        this._t(L, 40, cy + 140, em.posture === 'offensive' ? '⚠ L\'empire prépare une contre-offensive : renforcez vos héros.' : 'L\'empire renforce ses défenses restantes.', 13, em.posture === 'offensive' ? '#ffb84d' : '#7a89ad', { wrap: 600 });
      } else {
        this._t(L, 40, cy + 84, 'Ce monde libre fait désormais partie de votre empire.', 14, '#eaf2ff', { wrap: 600 });
      }
      this._t(L, 40, cy + 190, 'Les revenus sont versés en continu, aussi hors ligne (12 h maximum).', 13, '#7a89ad', { wrap: 600 });
      return;
    }

    var scanned = sc.status === 'scanned';
    if (!scanned) {
      // ---- Défenses inconnues ----
      this._t(L, 40, cy + 6, 'DÉFENSES INCONNUES', 14, '#00e5ff', { bold: true });
      this._t(L, 40, cy + 34, 'Un scan révèle la flotte, le bouclier, les tourelles, le niveau conseillé et les récompenses. Il reste valide 12 h. Sans scan valide, l\'invasion est impossible.', 14, '#a9b8dc', { wrap: 610 });
      this._t(L, 40, cy + 100, p.desc, 13, '#7a89ad', { wrap: 610 });
      var cost = GM.scanCost(pid) || {};
      this._t(L, 40, cy + 150, 'Coût du scan', 13, '#7a89ad');
      var uw = this._resRow(L, 40, cy + 172, cost, { plus: false, font: 17 });
      this._t(L, 40 + uw + 10, cy + 187, '· durée ' + this._dur(GM.scanDuration(pid)), 14, '#a9b8dc', { oy: 0.5 });
      if (!st.reachable) hint = 'Hors de portée : conquérez d\'abord un monde voisin (relié par une route).';
    } else {
      // ---- Rapport de scan ----
      var spec = plan.spec, groups = {}, order = [];
      spec.waves.forEach(function (wv) { wv.forEach(function (u) { var k = u.id + '|' + (u.rank || 0); if (!groups[k]) { groups[k] = { def: u, n: 0 }; order.push(k); } groups[k].n += 1; }); });
      var iw = Math.min(104, Math.floor(600 / Math.max(1, order.length)));
      order.slice(0, 6).forEach(function (k, i) {
        var gx = 40 + i * iw, gr = groups[k];
        L.add(self.add.image(gx + 30, cy + 26, 'tex_enemy_' + gr.def.id).setDisplaySize(52, 52));
        self._t(L, gx + 54, cy + 46, '×' + gr.n, 15, '#ffd166', { bold: true, ox: 1, oy: 0.5 });
        self._t(L, gx + 30, cy + 56, self._short(gr.def.name.replace(/ ★+/, ''), 11), 10, '#a9b8dc', { ox: 0.5 });
      });
      var sy2 = cy + 76;
      this._t(L, 40, sy2, 'Bouclier ' + this._n(spec.shield) + ' · Tourelles ' + spec.turrets + ' · ' + spec.waves.length + ' vague' + (spec.waves.length > 1 ? 's' : ''), 14, '#eaf2ff', { bold: true });
      var vcol = { deconseille: '#ff6a78', risque: '#ffb84d', equilibre: '#ffd166', favorable: '#7dff9a' }[plan.verdict] || '#eaf2ff';
      var vtxt = { deconseille: 'Déconseillé', risque: 'Risqué', equilibre: 'Équilibré', favorable: 'Favorable' }[plan.verdict] || '';
      var lvTxt = this._t(L, 40, sy2 + 22, 'Niveau conseillé ' + plan.recLevel + ' · Votre équipe ' + plan.teamLevel + ' → ', 14, '#c7d1ea');
      this._t(L, 40 + lvTxt.width + 4, sy2 + 21, vtxt, 15, vcol, { bold: true });
      if (plan.strategy) this._t(L, 40, sy2 + 44, 'Doctrine : ' + plan.strategy + ' · alerte ' + (plan.alert || 0) + '/3', 13, '#a9b8dc');
      var trait = spec.trait;
      if (trait) this._t(L, 40, sy2 + 64, trait.name + ' — ' + trait.text, 11, '#7a89ad', { wrap: 610 });
      var rw = spec.rewards || {}, ry = sy2 + 104;
      this._t(L, 40, ry + 4, 'BUTIN', 12, '#00e5ff', { bold: true });
      var bx = 100, first = rw.first || {};
      var loot = {}; E.ORDER.forEach(function (rid) { if (rw[rid]) loot[rid] = rw[rid]; });
      var used = this._resRow(L, bx, ry - 2, loot, { font: 14, size: 26 });
      var extra = 'XP +' + (rw.xp || 0) + ' · Fragments +' + (rw.fragments || 0);
      this._t(L, 40, ry + 30, extra + (Object.keys(first).length ? ' · 1re conquête : ' + Object.keys(first).map(function (k) { return '+' + E.fmtGain(first[k]) + ' ' + E.RES[k].short; }).join(', ') : ''), 12, '#a9b8dc', { wrap: 610 });
    }

    // ---- Boutons ----
    var by = Y + H - 37;
    if (hint) this._t(L, 360, by - 40, hint, 12, '#ffb84d', { ox: 0.5, oy: 0.5 });
    var canScan = GM.canScan(pid, now), teamOk = NEBUSTION.Combat.getTeam().length === 5 && NEBUSTION.ExpeditionManager.busyTeamMembers().length === 0;
    var canInv = plan && plan.canInvade && plan.reachable && teamOk;
    if (!scanned) {
      var scanReason = { busy: 'Un autre scan est en cours', cost: 'Énergie insuffisante', locked: 'Secteur verrouillé', scanning: 'Scan en cours…' }[canScan.reason] || '';
      var label = sc.status === 'scanning' ? 'SCAN EN COURS…' : (canScan.ok ? 'SCANNER' : (scanReason ? scanReason.toUpperCase() : 'SCAN IMPOSSIBLE'));
      var sb = new NEBUSTION.Button(this, 360, by, {
        width: 520, height: 58, label: label, fontSize: label.length > 18 ? '15px' : '21px', accentColor: canScan.ok ? 0x00e5ff : 0x394869, disabled: !canScan.ok,
        onClick: function () { self._doScan(pid); }
      });
      L.add(sb);
      this._scanBtn = sb;
    } else {
      var busyTeam = NEBUSTION.ExpeditionManager.busyTeamMembers().length > 0;
      var ilabel = !teamOk ? (busyTeam ? 'HÉROS EN EXPÉDITION' : 'COMPOSEZ VOTRE ÉQUIPE') : (!plan.reachable ? 'HORS DE PORTÉE' : (canInv ? '⚔ ENVAHIR' : 'INVASION IMPOSSIBLE'));
      if (!teamOk) {
        var tb = new NEBUSTION.Button(this, 360, by, {
          width: 520, height: 58, label: ilabel, fontSize: '19px', accentColor: 0xffb84d,
          onClick: function () { self._go('CombatPrepScene', { navKey: 'combat', title: 'Combat' }); }
        });
        L.add(tb);
      } else {
        var ib = new NEBUSTION.Button(this, 360, by, {
          width: 520, height: 58, label: ilabel, fontSize: '22px', accentColor: canInv ? 0xff4d6d : 0x394869, disabled: !canInv,
          onClick: function () { self._doInvade(pid); }
        });
        L.add(ib);
        this._invadeBtn = ib;
      }
    }
  }

  // =====================================================================
  // Actions
  // =====================================================================
  _doScan(pid) {
    var GM = NEBUSTION.GalaxyManager, r = GM.startScan(pid, Date.now());
    if (r.ok) {
      this.fx.toast('Scan lancé', NEBUSTION.Galaxy.planet(pid).name);
    } else {
      var msg = { busy: 'Un autre scan est en cours', cost: 'Énergie insuffisante', locked: 'Secteur verrouillé', scanned: 'Déjà scannée', scanning: 'Scan déjà en cours' }[r.reason] || 'Impossible';
      this.fx.toast('Scan refusé', msg);
    }
    this._refresh();
    return r;
  }

  _doInvade(pid) {
    if (this._launching) return false;
    var GM = NEBUSTION.GalaxyManager, EEM = NEBUSTION.EmpireEvolutionManager, now = Date.now();
    var plan = EEM.invasionPlan(pid, now);
    if (!plan || !plan.canInvade) { this.fx.toast('Invasion impossible', plan && plan.reason === 'scan' ? 'Scan requis (expiré ?)' : 'Cible invalide'); this._refresh(); return false; }
    if (!plan.reachable) { this.fx.toast('Hors de portée', 'Conquérez d\'abord un monde voisin'); return false; }
    if (NEBUSTION.Combat.getTeam().length !== 5) { this.fx.toast('Équipe incomplète', 'Il faut 5 héros'); return false; }
    if (NEBUSTION.ExpeditionManager.busyTeamMembers().length > 0) { this.fx.toast('Héros indisponibles', 'Un membre de l\'équipe est en expédition'); return false; }
    this._go('CombatScene', { planetId: pid });
    return true;
  }

  _go(sceneKey, data) {
    if (this._launching) return;
    this._launching = true;
    var self = this;
    this.cameras.main.fadeOut(300, 5, 7, 15);
    this.cameras.main.once('camerafadeoutcomplete', function () { self.scene.start(sceneKey, data); });
  }
};
