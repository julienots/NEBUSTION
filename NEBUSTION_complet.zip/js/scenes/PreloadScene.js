/**
 * NEBUSTION - PreloadScene
 * Génère toutes les textures du jeu (aucun asset externe requis) et affiche
 * une barre de chargement stylisée pendant l'opération.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.PreloadScene = class PreloadScene extends Phaser.Scene {
  constructor() {
    super('PreloadScene');
  }

  preload() {
    // (aucun asset externe requis pour l'instant : tout est généré par le jeu)
  }

  create() {
    var w = this.scale.width, h = this.scale.height;
    this.cameras.main.setBackgroundColor('#05070f');

    var title = this.add.text(w / 2, h / 2 - 70, 'NEBUSTION', {
      fontFamily: 'Arial, sans-serif',
      fontSize: '42px',
      fontStyle: 'bold',
      color: '#eaf2ff'
    }).setOrigin(0.5).setAlpha(0.9);
    title.setShadow(0, 0, '#00e5ff', 16, true, true);

    var barW = w * 0.6, barH = 10;
    var barBg = this.add.graphics();
    barBg.fillStyle(0x101830, 1);
    barBg.fillRoundedRect(w / 2 - barW / 2, h / 2, barW, barH, barH / 2);

    var barFill = this.add.graphics();

    var label = this.add.text(w / 2, h / 2 + 30, 'Chargement de l\'univers...', {
      fontFamily: 'Arial, sans-serif',
      fontSize: '16px',
      color: '#7a89ad'
    }).setOrigin(0.5);

    // Génération procédurale des textures, répartie sur quelques frames pour
    // laisser la barre de progression s'animer visuellement.
    var self = this;
    var progress = 0;
    var steps = [
      function () { NEBUSTION.TextureGenerator.generateAll(self); },
      function () { NEBUSTION.EconomyTextures.generateAll(self); },
      function () { NEBUSTION.EnemyTextures.generateAll(self); },
      function () { NEBUSTION.GalaxyTextures.generateAll(self); }
    ];

    this.tweens.addCounter({
      from: 0,
      to: 100,
      duration: 700,
      onUpdate: function (tween) {
        progress = tween.getValue();
        barFill.clear();
        barFill.fillStyle(0x00e5ff, 1);
        var fillW = Math.max(4, (barW * progress) / 100);
        barFill.fillRoundedRect(w / 2 - barW / 2, h / 2, fillW, barH, barH / 2);
      },
      onComplete: function () {
        try {
          steps.forEach(function (fn) { fn(); });
        } catch (e) {
          console.error('NEBUSTION texture generation error:', e);
        }
        // Illustrations d'ennemis (assets/enemies/, optionnelles) puis portraits de héros : les deux
        // sont asynchrones (tentative de chargement d'images réelles avant repli sur le généré),
        // donc on ne démarre la suite qu'une fois terminé.
        var heroesStarted = false;
        function loadHeroes() {
          if (heroesStarted) return;
          heroesStarted = true;
          try {
            NEBUSTION.HeroTextures.generateAll(self, function () { self.scene.start('SplashScene'); });
          } catch (e) {
            console.error('NEBUSTION hero texture generation error:', e);
            self.scene.start('SplashScene');
          }
        }
        try {
          NEBUSTION.EnemyTextures.loadImages(self, loadHeroes);
        } catch (e) {
          console.error('NEBUSTION enemy image loading error:', e);
          loadHeroes();
        }
      }
    });
  }
};
