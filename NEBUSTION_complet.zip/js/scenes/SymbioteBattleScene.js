/** NEBUSTION - SymbioteBattleScene : combat animé réel du Symtor (barres de vie, coups portés,
 * projectiles) — remplace l'ancien résultat instantané "VICTOIRE / DÉFAITE" affiché en simple texte. */
window.NEBUSTION = window.NEBUSTION || {};
NEBUSTION.SymbioteBattleScene = class SymbioteBattleScene extends Phaser.Scene {
  constructor() { super('SymbioteBattleScene'); }
  init(data) { this._type = (data && data.type) || 'galaxy'; }

  create() {
    this.cameras.main.setBackgroundColor('#05070f');
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });
    this.fx = new NEBUSTION.FX(this);
    var w = this.scale.width;
    this._pulse = 0;
    this._hitFlashOwn = 0; this._hitFlashEnemy = 0;
    this._lungeOwn = 0; this._lungeEnemy = 0;
    this._finished = false; this._skip = false;

    var prep = NEBUSTION.SymbioteManager.prepareBattle(this._type);
    if (!prep.ok) { this.scene.start('SymbioteScene'); return; }
    this._prep = prep;

    var D = NEBUSTION.Symbiote, s = NEBUSTION.SymbioteManager.state();
    this._ownStyle = D.bodyStyle(s.genome.seed);
    this._ownTraits = D.traits(s);
    this._ownLevel = s.level;
    var eseed = prep.seed + 4242;
    this._enemyStyle = D.bodyStyle(eseed);
    this._enemyTraits = this._synthTraits(eseed, prep.enemyLevel);
    this._enemyLevel = prep.enemyLevel;

    this._ownMax = prep.sim.ownMax; this._enemyMax = prep.sim.enemyMax;
    this._ownHP = this._ownMax; this._enemyHP = this._enemyMax;
    this._ownHPShown = this._ownMax; this._enemyHPShown = this._enemyMax;

    this._txt(w / 2, 78, this._type === 'symbiote' ? '☣ DUEL CONTRE UN SYMBIOTE' : '⚔ COMBAT GALACTIQUE', 22, '#d77cff');
    this._txt(w / 2, 108, 'Touche l\u2019écran pour accélérer', 13, '#8ea0c8').setAlpha(.8);

    // Adversaire (haut)
    this._enemyName = this._txt(w / 2, 190, (this._type === 'symbiote' ? 'Symbiote sauvage' : 'Empire ennemi') + ' • Nv.' + this._enemyLevel, 16, '#ff8fae');
    this._enemyBarBg = this.add.graphics().setDepth(30);
    this._enemyHPTxt = this._txt(w / 2, 250, '', 13, '#eaf2ff');
    this._enemyG = this.add.graphics().setDepth(20); this._enemyG.x = w / 2; this._enemyG.y = 400;
    this._enemyAura = this.add.graphics().setDepth(19); this._enemyAura.x = w / 2; this._enemyAura.y = 400;

    // VS
    this._txt(w / 2, 610, 'VS', 26, '#ffd166');

    // Ton Symtor (bas)
    this._ownName = this._txt(w / 2, 730, 'Ton Symtor • Nv.' + this._ownLevel, 16, '#6fd8ff');
    this._ownBarBg = this.add.graphics().setDepth(30);
    this._ownHPTxt = this._txt(w / 2, 790, '', 13, '#eaf2ff');
    this._ownAura = this.add.graphics().setDepth(19); this._ownAura.x = w / 2; this._ownAura.y = 950;
    this._ownG = this.add.graphics().setDepth(20); this._ownG.x = w / 2; this._ownG.y = 950;

    this._logTxt = this._txt(w / 2, 1080, 'Le combat commence...', 15, '#eaf2ff');

    this._continueBtn = new NEBUSTION.Button(this, w / 2, 1180, {
      width: 300, height: 58, label: 'CONTINUER', accentColor: 0x5fd97a, fontSize: '16px',
      onClick: () => this.scene.start('SymbioteScene')
    });
    this._continueBtn.setVisible(false);

    this.input.on('pointerdown', () => { this._skip = true; });

    this._rounds = prep.sim.rounds.slice();
    this._roundDelay = Math.max(230, Math.min(650, 5200 / Math.max(1, this._rounds.length)));
    this._nextRoundAt = this.time.now + 500;

    this._drawBars();
  }

  _synthTraits(seed, level) {
    var D = NEBUSTION.Symbiote, r = D.rng(seed + 555), out = {};
    D.GENES.forEach(function (g) { out[g] = 0; });
    var picks = Math.min(6, 2 + Math.floor(level / 6));
    for (var i = 0; i < picks; i++) { var g = D.GENES[Math.floor(r() * D.GENES.length)]; out[g] = (out[g] || 0) + 1 + Math.floor(r() * 2); }
    return out;
  }

  _txt(x, y, s, size, color) {
    return this.add.text(x, y, s, { fontFamily: 'Arial,sans-serif', fontSize: size + 'px', color: color || '#eaf2ff', fontStyle: size >= 18 ? 'bold' : 'normal', align: 'center' })
      .setOrigin(.5).setDepth(40);
  }

  _darken(color, amt) { var c = Phaser.Display.Color.IntegerToColor(color); return Phaser.Display.Color.GetColor(Math.max(0, c.red * (1 - amt)), Math.max(0, c.green * (1 - amt)), Math.max(0, c.blue * (1 - amt))); }

  _drawBars() {
    var w = this.scale.width, bw = w - 120;
    var eFrac = Math.max(0, this._enemyHPShown / this._enemyMax);
    var oFrac = Math.max(0, this._ownHPShown / this._ownMax);
    this._enemyBarBg.clear();
    this._enemyBarBg.fillStyle(0x101828, .9); this._enemyBarBg.fillRoundedRect(60, 218, bw, 20, 8);
    this._enemyBarBg.fillStyle(0xff6b9a, 1); this._enemyBarBg.fillRoundedRect(60, 218, bw * eFrac, 20, 8);
    this._enemyBarBg.lineStyle(2, 0xff9ab8, .8); this._enemyBarBg.strokeRoundedRect(60, 218, bw, 20, 8);
    this._enemyHPTxt.setText(Math.max(0, Math.round(this._enemyHPShown)) + ' / ' + this._enemyMax + ' PV');

    this._ownBarBg.clear();
    this._ownBarBg.fillStyle(0x101828, .9); this._ownBarBg.fillRoundedRect(60, 758, bw, 20, 8);
    this._ownBarBg.fillStyle(0x6fd8ff, 1); this._ownBarBg.fillRoundedRect(60, 758, bw * oFrac, 20, 8);
    this._ownBarBg.lineStyle(2, 0x9fe8ff, .8); this._ownBarBg.strokeRoundedRect(60, 758, bw, 20, 8);
    this._ownHPTxt.setText(Math.max(0, Math.round(this._ownHPShown)) + ' / ' + this._ownMax + ' PV');
  }

  _drawFighter(g, aura, style, traits, level, hitFlash, lunge, deathFrac) {
    g.clear(); aura.clear();
    var hsvFill = Phaser.Display.Color.HSVToRGB(style.hue / 360, style.sat, style.val);
    var hsvLine = Phaser.Display.Color.HSVToRGB(style.hue / 360, Math.min(1, style.sat + .15), Math.min(1, style.val + .4));
    var fillColor = hitFlash > 0 ? this._blendRed(hsvFill.color, hitFlash) : hsvFill.color;
    var lineColor = hsvLine.color;
    var size = (58 + level * 2.6 + Math.pow(level, 1.2) * .7) * (1 - deathFrac * .35);
    var bob = Math.sin(this._pulse * 1.8) * 6 * (1 - deathFrac);
    g.y = g.baseY + bob - lunge * 22;
    aura.x = g.x; aura.y = g.y;
    var alpha = Math.max(0, 1 - deathFrac);

    aura.fillStyle(lineColor, (.08 + hitFlash * .18) * alpha);
    aura.fillCircle(0, 0, size * 1.02);

    g.fillStyle(fillColor, .95 * alpha); g.lineStyle(3, lineColor, .8 * alpha);
    if (style.shape === 'elongated') { g.fillEllipse(0, 0, size * 1.8, size * .78 * style.asym); g.strokeEllipse(0, 0, size * 1.8, size * .78 * style.asym); }
    else if (style.shape === 'angular') {
      var pts = [], faces = 6;
      for (var i = 0; i < faces; i++) { var a = (i / faces) * Math.PI * 2, rr = size * (.85 + ((i % 2) ? .15 : 0)); pts.push(new Phaser.Geom.Point(Math.cos(a) * rr * style.asym, Math.sin(a) * rr * .85)); }
      g.fillPoints(pts, true); g.strokePoints(pts, true);
    } else if (style.shape === 'segmented') {
      for (var s2 = -1; s2 <= 1; s2++) { var ss = size * (.72 - Math.abs(s2) * .12); g.fillEllipse(s2 * size * .55, 0, ss * 1.15, ss); g.strokeEllipse(s2 * size * .55, 0, ss * 1.15, ss); }
    } else { g.fillEllipse(0, 0, size * 1.3 * style.asym, size); g.strokeEllipse(0, 0, size * 1.3 * style.asym, size); }

    // Yeux
    var eyes = Math.min(8, 1 + traits.eyes);
    for (var e = 0; e < eyes; e++) {
      var ea = (e / eyes) * Math.PI * 2 - .2, ex = Math.cos(ea) * size * .48, ey = Math.sin(ea) * size * .34;
      var blinkCycle = 3.2 + ((e * 37) % 5) * .55, phase = (this._pulse + e * .83) % blinkCycle, closed = phase > blinkCycle - .16;
      if (closed) { g.lineStyle(3, 0x101020, alpha); g.lineBetween(ex - 7, ey, ex + 7, ey); }
      else { g.fillStyle(0xeaf2ff, alpha); g.fillCircle(ex, ey, 7 + level * .1); g.fillStyle(0x101020, alpha); g.fillCircle(ex, ey, 3); }
    }
    // Tentacules
    var tent = traits.tentacles + 2;
    for (var t = 0; t < tent; t++) {
      var baseA = (t / tent) * Math.PI * 2, wob = Math.sin(this._pulse * (1.1 + (t % 3) * .32) + t * 1.7) * .22;
      var aa = baseA + wob, len = (32 + level * 2 + traits.tail * 4) * (1 + lunge * .4);
      g.lineStyle(4 + level * .08, lineColor, .85 * alpha);
      g.beginPath(); g.moveTo(Math.cos(baseA) * size * .45, Math.sin(baseA) * size * .4); g.lineTo(Math.cos(aa) * len, Math.sin(aa) * len); g.strokePath();
    }
    // Pics
    for (var k = 0; k < traits.spikes; k++) {
      var sa = (k / Math.max(1, traits.spikes)) * Math.PI * 2;
      g.fillStyle(0xff6b9a, .85 * alpha);
      g.fillTriangle(Math.cos(sa) * size * .55, Math.sin(sa) * size * .45, Math.cos(sa) * size * .9, Math.sin(sa) * size * .72, Math.cos(sa + .18) * size * .55, Math.sin(sa + .18) * size * .45);
    }
    // Cornes
    if (traits.horns) { g.lineStyle(6, 0xb47bff, .9 * alpha); g.lineBetween(-size * .35, -size * .42, -size * .6, -size * .74); g.lineBetween(size * .35, -size * .42, size * .6, -size * .74); }
    // Bouche (s'ouvre pendant l'attaque)
    var mouthOpen = size * .16 + lunge * size * .22;
    g.lineStyle(4, 0xff6b9a, .85 * alpha); g.strokeEllipse(0, size * .16, size * .5, mouthOpen);
    // Ailes
    if (traits.wings) {
      g.fillStyle(lineColor, .25 * alpha); g.lineStyle(2.5, lineColor, .65 * alpha);
      [-1, 1].forEach(function (side) {
        var wpts = [new Phaser.Geom.Point(side * size * .3, -size * .1), new Phaser.Geom.Point(side * size * 1.1, -size * .5), new Phaser.Geom.Point(side * size * .5, size * .3)];
        g.fillPoints(wpts, true); g.strokePoints(wpts, true);
      });
    }
  }

  _blendRed(color, t) {
    var c = Phaser.Display.Color.IntegerToColor(color);
    return Phaser.Display.Color.GetColor(c.red + (255 - c.red) * t, c.green * (1 - t * .7), c.blue * (1 - t * .7));
  }

  _fireProjectile(fromOwn) {
    var w = this.scale.width;
    var fromX = w / 2, fromY = fromOwn ? 950 : 400;
    var toX = w / 2, toY = fromOwn ? 400 : 950;
    var color = fromOwn ? 0x6fd8ff : 0xff6b9a;
    var p = this.add.circle(fromX, fromY - (fromOwn ? 60 : -60), 8, color, .95).setDepth(35);
    this.tweens.add({
      targets: p, x: toX, y: toY - (fromOwn ? -70 : 70), duration: 220, ease: 'Cubic.easeIn',
      onComplete: () => { p.destroy(); }
    });
  }

  _burst(x, y, color, count) {
    for (var i = 0; i < (count || 10); i++) {
      var c = this.add.circle(x, y, 3 + Math.random() * 4, color, .9).setDepth(36);
      var ang = Math.random() * Math.PI * 2, dist = 30 + Math.random() * 55;
      this.tweens.add({ targets: c, x: x + Math.cos(ang) * dist, y: y + Math.sin(ang) * dist, alpha: 0, scale: .15, duration: 400 + Math.random() * 300, ease: 'Cubic.easeOut', onComplete: () => c.destroy() });
    }
  }

  _playRound(round) {
    var w = this.scale.width, ownAttacks = round.attacker === 'own';
    var targetY = ownAttacks ? 400 : 950;
    if (ownAttacks) this._lungeOwn = 1; else this._lungeEnemy = 1;
    this._fireProjectile(ownAttacks);
    this._logTxt.setText((ownAttacks ? 'Ton Symtor attaque' : 'L\u2019adversaire attaque') + (round.crit ? ' • COUP CRITIQUE !' : '') + ' • -' + round.damage + ' PV');
    this.time.delayedCall(180, () => {
      if (ownAttacks) { this._hitFlashEnemy = 1; this._burst(w / 2, targetY, 0xff6b9a, round.crit ? 20 : 10); this.cameras.main.shake(round.crit ? 130 : 70, round.crit ? .006 : .0035); }
      else { this._hitFlashOwn = 1; this._burst(w / 2, targetY, 0x6fd8ff, round.crit ? 20 : 10); this.cameras.main.shake(round.crit ? 130 : 70, round.crit ? .006 : .0035); }
      this._enemyHP = round.enemyHP; this._ownHP = round.ownHP;
      this.tweens.addCounter({ from: this._enemyHPShown, to: this._enemyHP, duration: 260, onUpdate: (tw) => { this._enemyHPShown = tw.getValue(); } });
      this.tweens.addCounter({ from: this._ownHPShown, to: this._ownHP, duration: 260, onUpdate: (tw) => { this._ownHPShown = tw.getValue(); } });
    });
  }

  _finish() {
    if (this._finished) return; this._finished = true;
    var win = this._prep.win;
    var res = NEBUSTION.SymbioteManager.resolveBattle(this._prep);
    var w = this.scale.width;
    this._logTxt.setText(win ? 'Ton Symtor triomphe !' : 'Ton Symtor a été vaincu...');
    this.cameras.main.flash(240, win ? 95 : 215, win ? 215 : 60, win ? 124 : 90);
    var banner = this._txt(w / 2, 470, win ? 'VICTOIRE' : 'DÉFAITE', 40, win ? '#5fd97a' : '#ff6b9a').setDepth(50).setScale(.4).setAlpha(0);
    this.tweens.add({ targets: banner, scale: 1, alpha: 1, duration: 320, ease: 'Back.easeOut' });
    var rewardTxt = win
      ? '+' + Object.keys(res.reward).map(k => res.reward[k] + ' ' + (NEBUSTION.Economy.RES[k] ? NEBUSTION.Economy.RES[k].short : k)).join('  •  ')
      : 'Récupéré : +' + res.reward.dust + ' Poussière';
    this._txt(w / 2, 530, rewardTxt, 16, '#eaf2ff').setDepth(50);
    if (win) { this._burst(w / 2, 950, 0xffd166, 26); this._ownName.setColor('#5fd97a'); }
    else { this._burst(w / 2, 950, 0x8a8a9a, 18); this._enemyName.setColor('#5fd97a'); }
    this._continueBtn.setVisible(true);
  }

  update(time, delta) {
    var dt = (delta || 16) / 1000;
    this._pulse += dt;
    this._hitFlashOwn = Math.max(0, this._hitFlashOwn - dt * 3.2);
    this._hitFlashEnemy = Math.max(0, this._hitFlashEnemy - dt * 3.2);
    this._lungeOwn = Math.max(0, this._lungeOwn - dt * 3.4);
    this._lungeEnemy = Math.max(0, this._lungeEnemy - dt * 3.4);

    if (!this._finished) {
      if (this._skip) {
        // Avance instantanément à la fin (applique tous les tours restants d'un coup).
        while (this._rounds.length) { var r = this._rounds.shift(); this._enemyHP = r.enemyHP; this._ownHP = r.ownHP; }
        this._enemyHPShown = this._enemyHP; this._ownHPShown = this._ownHP;
        this._finish();
      } else if (this.time.now >= this._nextRoundAt) {
        if (this._rounds.length) { this._playRound(this._rounds.shift()); this._nextRoundAt = this.time.now + this._roundDelay; }
        else this._finish();
      }
    }

    this._ownG.baseY = 950; this._enemyG.baseY = 400;
    var ownDeath = this._finished ? Math.max(0, 1 - this._ownHP / this._ownMax) * (this._prep.win ? 0 : 1) : 0;
    var enemyDeath = this._finished ? Math.max(0, 1 - this._enemyHP / this._enemyMax) * (this._prep.win ? 1 : 0) : 0;
    this._drawFighter(this._ownG, this._ownAura, this._ownStyle, this._ownTraits, this._ownLevel, this._hitFlashOwn, this._lungeOwn, ownDeath);
    this._drawFighter(this._enemyG, this._enemyAura, this._enemyStyle, this._enemyTraits, this._enemyLevel, this._hitFlashEnemy, this._lungeEnemy, enemyDeath);
    this._drawBars();
  }
};
