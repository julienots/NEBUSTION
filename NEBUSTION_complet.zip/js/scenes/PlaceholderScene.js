/**
 * NEBUSTION - PlaceholderScene
 * Écran générique réutilisé par les sections pas encore développées
 * (Galaxie, Héros, Combat, Boutique, Pass). Garde le même décor spatial
 * et la même navigation que le reste du jeu, pour que le jeu reste cohérent
 * même quand une fonctionnalité n'est pas encore implémentée.
 * N'affiche jamais une fonctionnalité comme active si elle ne l'est pas.
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.PlaceholderScene = class PlaceholderScene extends Phaser.Scene {
  constructor() {
    super('PlaceholderScene');
  }

  init(data) {
    this.navKey = (data && data.navKey) || 'galaxy';
    this.title = (data && data.title) || 'Section';
  }

  create() {
    var w = this.scale.width, h = this.scale.height;
    this.cameras.main.setBackgroundColor('#05070f');
    this.cameras.main.fadeIn(300, 5, 7, 15);

    NEBUSTION.SceneBackground.build(this, { withPlanet: false });

    this.add.text(w / 2, 150, this.title, {
      fontFamily: 'Arial, sans-serif',
      fontSize: '26px',
      fontStyle: '900',
      color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(50).setShadow(0, 0, '#00e5ff', 10, true, true);

    // Icône centrale décorative (grand anneau pulsant)
    var cx = w / 2, cy = h * 0.42;
    var ring1 = this.add.circle(cx, cy, 70).setStrokeStyle(2, 0x2e9eff, 0.5);
    var ring2 = this.add.circle(cx, cy, 100).setStrokeStyle(1.5, 0x2e9eff, 0.25);
    this.tweens.add({ targets: ring1, scale: 1.08, alpha: 0.6, duration: 1800, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    this.tweens.add({ targets: ring2, scale: 1.12, alpha: 0.15, duration: 2200, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });

    this.add.text(cx, cy - 14, '⏳', { fontSize: '46px' }).setOrigin(0.5);

    this.add.text(cx, cy + 150, 'Bientôt disponible', {
      fontFamily: 'Arial, sans-serif',
      fontSize: '22px',
      fontStyle: 'bold',
      color: '#eaf2ff'
    }).setOrigin(0.5);

    this.add.text(cx, cy + 184,
      'La section « ' + this.title + ' » est en construction.\nElle arrivera dans une prochaine mise à jour de NEBUSTION.', {
      fontFamily: 'Arial, sans-serif',
      fontSize: '14px',
      color: '#7a89ad',
      align: 'center'
    }).setOrigin(0.5);

    // Bouton retour au menu
    var backBtn = new NEBUSTION.Button(this, w / 2, h - 200, {
      width: 220,
      height: 58,
      label: 'Retour au menu',
      accentColor: 0x00e5ff,
      onClick: () => {
        this.cameras.main.fadeOut(250, 5, 7, 15);
        this.cameras.main.once('camerafadeoutcomplete', () => this.scene.start('MainMenuScene'));
      }
    });
    backBtn.setDepth(50);

    this.hud = NEBUSTION.HUD.attach(this);
    new NEBUSTION.BottomNav(this, this.navKey);
  }
};
