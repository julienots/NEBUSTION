/** NEBUSTION - SymbioteScene : laboratoire vivant du Symtor */
window.NEBUSTION = window.NEBUSTION || {};
NEBUSTION.SymbioteScene = class SymbioteScene extends Phaser.Scene {
  constructor() { super('SymbioteScene'); }
  create() {
    this.cameras.main.setBackgroundColor('#05070f');
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });
    this.fx = new NEBUSTION.FX(this); this._pulse = 0;
    this._mood = 0;      // 0..1, monte quand on nourrit / fait évoluer, redescend seule (créature "excitée")
    this._mouth = 0;     // 0..1, ouverture de bouche animée pendant/juste après un repas
    this._flashLimb = null; // dernier trait qui vient d'apparaître, mis en surbrillance quelques secondes
    this._flashT = 0;
    this._buildUI(); this._drawCreature(); this._setupRotationControl();
    this.events.once('shutdown', () => { if (this._timer) this._timer.remove(false); });
    this._timer = this.time.addEvent({ delay: 250, loop: true, callback: () => this._refresh() });
    this._refresh();
  }
  // Rotation 3D à la souris/au doigt : glisser à l'horizontale fait pivoter le Symtor autour de
  // son axe vertical (comme une vraie caméra tournant autour d'un modèle), avec inertie et une
  // lente rotation d'inactivité pour toujours donner l'impression d'un volume, pas d'un sprite plat.
  _setupRotationControl(){
    var w=this.scale.width;
    this._rotY=0.22; this._rotVel=0; this._rotDragging=false; this._rotLastX=0; this._idleSpeed=0.1; this._hintAlpha=1;
    var zone=this.add.zone(w/2,470,Math.min(520,w-10),480).setOrigin(.5).setInteractive().setDepth(25);
    this._rotZone=zone;
    this._rotHint=this._txt(w/2,300,'👆 Glisse pour faire tourner le Symtor en 3D',13,'#8ea0c8').setDepth(30).setAlpha(.85);
    var onDown=(p)=>{ this._rotDragging=true; this._rotLastX=p.x; this._rotVel=0; this._hintAlpha=0; };
    var onMove=(p)=>{ if(!this._rotDragging) return; var dx=p.x-this._rotLastX; this._rotY+=dx*0.012; this._rotVel=dx*0.012; this._rotLastX=p.x; };
    var onUp=()=>{ this._rotDragging=false; };
    zone.on('pointerdown',onDown);
    this.input.on('pointermove',onMove);
    this.input.on('pointerup',onUp);
    this.input.on('pointerupoutside',onUp);
    this.events.once('shutdown',()=>{ this.input.off('pointermove',onMove); this.input.off('pointerup',onUp); this.input.off('pointerupoutside',onUp); });
  }
  _txt(x,y,s,size,color,origin) { return this.add.text(x,y,s,{fontFamily:'Arial,sans-serif',fontSize:size+'px',color:color||'#eaf2ff',fontStyle:size>=18?'bold':'normal'}).setOrigin(origin===undefined?.5:origin); }
  _buildUI() {
    var w=this.scale.width;
    this._txt(w/2,92,'SYMTOR',30,'#d77cff');
    this._txt(w/2,126,'Laboratoire vivant • Nourris • Évolue • Combats',14,'#8ea0c8');
    this._status=this._txt(w/2,190,'',17,'#eaf2ff');
    this._power=this._txt(w/2,220,'',14,'#b8c8e8');
    this._feedButtons=[];
    var defs=[['crystal','💎 CRISTAUX',0x6fd8ff],['metal','⛓ MÉTAL',0xc9d4ea],['energy','⚡ ÉNERGIE',0xffd166],['dust','🌫 POUSSIÈRE',0xb47bff]];
    defs.forEach((d,i)=>{ var x=95+(i%2)*265,y=850+Math.floor(i/2)*72; var b=new NEBUSTION.Button(this,x,y,{width:240,height:56,label:d[1],accentColor:d[2],fontSize:'14px',onClick:()=>this._feed(d[0],d[2])}); this._feedButtons.push(b); });
    this._capsuleBtn=new NEBUSTION.Button(this,w/2,735,{width:430,height:60,label:'OUVRIR LA CAPSULE',accentColor:0x5fd97a,fontSize:'17px',onClick:()=>this._open()});
    // Module 20 : une fois la capsule ouverte, la rangée du bas propose Sécrétion (ressources) et Couvée (troupes).
    this._stageTxt=this._txt(w/2,652,'',15,'#d77cff').setDepth(30);
    this._infoTxt=this._txt(w/2,682,'',13,'#8ea0c8').setDepth(30);
    this._collectBtn=new NEBUSTION.Button(this,w/2-118,735,{width:224,height:60,label:'💧 COLLECTER',accentColor:0x6fd8ff,fontSize:'16px',onClick:()=>this._collect()});
    this._hatchBtn=new NEBUSTION.Button(this,w/2+118,735,{width:224,height:60,label:'🧬 COUVÉE',accentColor:0xd77cff,fontSize:'16px',onClick:()=>this._hatch()});
    this._qty=1;
    this._qtyBtn=new NEBUSTION.Button(this,w/2,796,{width:240,height:44,label:'NOURRIR ×1',accentColor:0xffd166,fontSize:'14px',onClick:()=>this._cycleQty()});
    this._galaxyBtn=new NEBUSTION.Button(this,w/2,1035,{width:430,height:56,label:'⚔ COMBAT GALACTIQUE',accentColor:0xff6b9a,fontSize:'16px',onClick:()=>this._battle('galaxy')});
    this._symBtn=new NEBUSTION.Button(this,w/2,1100,{width:430,height:56,label:'☣ DUEL CONTRE UN SYMBIOTE',accentColor:0xd77cff,fontSize:'15px',onClick:()=>this._battle('symbiote')});
    var back=new NEBUSTION.Button(this,w/2,1175,{width:260,height:48,label:'← RETOUR À LA BASE',accentColor:0x394869,fontSize:'14px',onClick:()=>this.scene.start('PlanetScene')});
  }
  _open(){ var r=NEBUSTION.SymbioteManager.openCapsule(); if(r.ok){this.fx.toast('Capsule ouverte','Une forme vivante vient de naître.'); this.cameras.main.flash(260,215,124,255); this._mood=1; this._refresh();} }
  _cycleQty(){ this._qty=this._qty===1?5:(this._qty===5?10:1); this._qtyBtn.labelText.setText('NOURRIR ×'+this._qty); }
  _feed(id,color){
    var M=NEBUSTION.SymbioteManager, D=NEBUSTION.Symbiote, n=0, xp=0, lv=[], leveled=false, fail=null, lastLevel=1;
    var lobesBefore=D.lobeCount(M.state().level);
    for(var i=0;i<this._qty;i++){
      var r=M.feed(id);
      if(!r.ok){ fail=r; break; }
      n++; xp+=r.xp; lastLevel=r.level; if(r.leveled){ leveled=true; lv=lv.concat(r.levels); }
    }
    if(!n){ this.fx.toast(fail&&fail.reason==='cost'?'Ressources insuffisantes':'Capsule fermée',''); return; }
    this._mood=1; this._mouth=1;
    this._burst(this._creatureG.x,this._creatureG.y,color||0x6fd8ff,10);
    var lobesAfter=D.lobeCount(lastLevel);
    if(lobesAfter>lobesBefore){
      this.fx.toast('NOUVELLE EXCROISSANCE !','Le corps du Symtor grandit et se ramifie ('+lobesAfter+'/6).');
      this.cameras.main.flash(200,95,215,124);
      this._burst(this._creatureG.x,this._creatureG.y,0x5fd97a,26);
    } else if(leveled){
      var last=lv[lv.length-1];
      this.fx.toast('ÉVOLUTION !','Niveau '+lastLevel+' • '+(last?last.label:'Nouvelle mutation'));
      this.cameras.main.flash(180,215,124,255);
      this._burst(this._creatureG.x,this._creatureG.y,0xffd166,24);
      if(last){ this._flashLimb=last.trait; this._flashT=2.2; }
    } else this.fx.toast('Symbiote nourri'+(n>1?' ×'+n:''),'+'+xp+' XP');
    this._refresh();
  }
  _collect(){
    var r=NEBUSTION.SymbioteManager.collect();
    if(!r.ok){ this.fx.toast('Rien à collecter','Reviens plus tard : le Symtor sécrète en continu.'); return; }
    var ic={crystal:'💎',metal:'⛓',energy:'⚡',dust:'🌫'};
    this.fx.toast('Sécrétion collectée',Object.keys(r.res).filter(function(k){return r.res[k]>0;}).map(function(k){return '+'+r.res[k]+' '+(ic[k]||k);}).join('  '));
    this._mood=Math.max(this._mood,.6); this._burst(this._creatureG.x,this._creatureG.y,0x6fd8ff,14); this._refresh();
  }
  _hatch(){
    var r=NEBUSTION.SymbioteManager.hatch();
    if(!r.ok){ this.fx.toast(r.reason==='level'?'Trop jeune':'Couvée en cours',r.reason==='level'?'Le Symtor doit atteindre le niveau '+NEBUSTION.Symbiote.HATCH_MIN_LEVEL+'.':'Patience : la prochaine couvée n\'est pas prête.'); return; }
    this.fx.toast('COUVÉE !','+'+r.count+' Rejeton'+(r.count>1?'s':'')+' rejoignent ton armée 🧬');
    this.cameras.main.flash(200,215,124,255); this._mood=1; this._burst(this._creatureG.x,this._creatureG.y,0xd77cff,22); this._refresh();
  }
  _fmtTime(ms){ var m=Math.ceil(ms/60000), h=Math.floor(m/60); return h>0?h+' h '+('0'+(m%60)).slice(-2):m+' min'; }
  // Lance le vrai combat animé (barres de vie, coups portés dans les deux sens) au lieu de résoudre
  // instantanément le duel derrière un simple texte "VICTOIRE/DÉFAITE".
  _battle(type){ var s=NEBUSTION.SymbioteManager.state(); if(!s.capsuleOpened){this.fx.toast('Symbiote indisponible','Ouvre d’abord la capsule.');return;} this.scene.start('SymbioteBattleScene',{type:type}); }
  _refresh(){ var s=NEBUSTION.SymbioteManager.state(), D=NEBUSTION.Symbiote, req=D.xpFor(s.level), p=NEBUSTION.SymbioteManager.power(), d=NEBUSTION.SymbioteManager.defense(); this._status.setText(!s.built?'Symtor non construit':!s.capsuleOpened?'Capsule scellée • une créature attend à l’intérieur':'Niveau '+s.level+' • XP '+Math.floor(s.xp)+' / '+req); this._power.setText('Puissance '+p+'  •  Défense base +'+d+'  •  Mutations '+s.mutations+'  •  Nourri '+s.totalFed+' fois'); this._capsuleBtn.setDisabled(!s.built||s.capsuleOpened); var open=s.capsuleOpened; this._capsuleBtn.setVisible(!open); this._feedButtons.forEach(b=>b.setDisabled(!open)); this._galaxyBtn.setDisabled(!open); this._symBtn.setDisabled(!open);
    var M=NEBUSTION.SymbioteManager, now=Date.now();
    this._collectBtn.setVisible(open); this._hatchBtn.setVisible(open); this._qtyBtn.setVisible(open); this._stageTxt.setVisible(open); this._infoTxt.setVisible(open);
    if(!open) return;
    var st=M.stage(), pn=M.pending(now), ic={crystal:'💎',metal:'⛓',energy:'⚡',dust:'🌫'};
    this._stageTxt.setText(st.icon+' Stade : '+st.name+'  •  Bonus de base +'+(Math.round(M.bonus('production')*1000)/10)+' % production');
    var parts=Object.keys(pn.res).filter(function(k){return pn.res[k]>0;}).map(function(k){return ic[k]+pn.res[k];});
    var hatchTxt=s.level<D.HATCH_MIN_LEVEL?'Couvée dès le niv. '+D.HATCH_MIN_LEVEL:(M.hatchReady(now)?'Couvée prête !':'Couvée dans '+this._fmtTime(M.hatchRemaining(now)));
    this._infoTxt.setText('Sécrétion : '+(parts.length?parts.join(' '):'…')+(pn.full?' (pleine)':'')+'  •  '+hatchTxt);
    this._collectBtn.setDisabled(!pn.any);
    var hReady=M.hatchReady(now);
    this._hatchBtn.setDisabled(!hReady);
    this._hatchBtn.labelText.setText(s.level<D.HATCH_MIN_LEVEL?'🧬 NIV. '+D.HATCH_MIN_LEVEL:(hReady?'🧬 COUVÉE ×'+M.hatchCount():'🧬 '+this._fmtTime(M.hatchRemaining(now))));
  }
  _drawCreature(){
    var w=this.scale.width;
    // Rendu hybride 2D/3D uniquement dans le Symtor : silhouette procédurale 2D extrudée en
    // plusieurs tranches de profondeur (comme un volume tourné au lathe), ombre, éclairage
    // qui suit la rotation, et vraie rotation 3D pilotée par l'utilisateur (glisser pour tourner).
    this._shadowG=this.add.graphics().setDepth(17);
    this._auraG=this.add.graphics().setDepth(18);
    this._depthLayers=[];
    for(var i=0;i<4;i++){ this._depthLayers.push(this.add.graphics().setDepth(18.5+i*0.1)); }
    this._creatureG=this.add.graphics().setDepth(20);
    this._lightG=this.add.graphics().setDepth(22);
    this._capsuleG=this.add.graphics().setDepth(19);
    [this._shadowG,this._creatureG,this._lightG,this._auraG,this._capsuleG].concat(this._depthLayers).forEach(function(g){g.x=w/2;g.y=455;});
  }
  _darken(color,amt){ var c=Phaser.Display.Color.IntegerToColor(color); return Phaser.Display.Color.GetColor(Math.max(0,c.red*(1-amt)),Math.max(0,c.green*(1-amt)),Math.max(0,c.blue*(1-amt))); }
  _drawBodyShape(g,style,size,fill,line,alpha){
    g.fillStyle(fill,alpha===undefined?.94:alpha);
    g.lineStyle(3,line,.75);
    if(style.shape==='elongated'){
      g.fillEllipse(0,0,size*1.8,size*.78*style.asym);
      g.strokeEllipse(0,0,size*1.8,size*.78*style.asym);
    } else if(style.shape==='angular'){
      var pts=[],faces=6;
      for(var i=0;i<faces;i++){
        var a=(i/faces)*Math.PI*2,rr=size*(.85+((i%2)?.15:0));
        pts.push(new Phaser.Geom.Point(Math.cos(a)*rr*style.asym,Math.sin(a)*rr*.85));
      }
      g.fillPoints(pts,true); g.strokePoints(pts,true);
    } else if(style.shape==='segmented'){
      for(var s=-1;s<=1;s++){
        var ss=size*(.72-Math.abs(s)*.12);
        g.fillEllipse(s*size*.55,0,ss*1.15,ss);
        g.strokeEllipse(s*size*.55,0,ss*1.15,ss);
      }
    } else {
      g.fillEllipse(0,0,size*1.3*style.asym,size);
      g.strokeEllipse(0,0,size*1.3*style.asym,size);
    }
  }
  // Petite pluie de particules pour matérialiser un repas ou une évolution, sans dépendre de FX interne.
  _burst(x,y,color,count){
    for (var i=0;i<count;i++){
      var c=this.add.circle(x,y,3+Math.random()*4,color,0.9).setDepth(26);
      var ang=Math.random()*Math.PI*2, dist=35+Math.random()*60;
      this.tweens.add({ targets:c, x:x+Math.cos(ang)*dist, y:y+Math.sin(ang)*dist, alpha:0, scale:0.15, duration:450+Math.random()*350, ease:'Cubic.easeOut', onComplete:()=>c.destroy() });
    }
  }
  update(time,delta){
    var dt=(delta||16)/1000;
    this._pulse+=dt;
    this._mood=Math.max(0,this._mood-dt*0.55);
    this._mouth=Math.max(0,this._mouth-dt*1.6);
    if(this._flashT>0) this._flashT=Math.max(0,this._flashT-dt);
    // Rotation : inertie après un glissement, puis reprise d'une lente rotation d'inactivité.
    if(!this._rotDragging){
      if(Math.abs(this._rotVel)>0.0008){ this._rotY+=this._rotVel; this._rotVel*=0.93; }
      else { this._rotY+=this._idleSpeed*dt; }
    }
    if(this._rotHint){ this._hintAlpha=Math.max(0,this._hintAlpha-dt*0.25); this._rotHint.setAlpha(this._hintAlpha*.85); if(this._hintAlpha<=0){ this._rotHint.destroy(); this._rotHint=null; } }
    this._renderCreature();
  }
  _renderCreature(){
    var s=NEBUSTION.SymbioteManager.state(), t=NEBUSTION.Symbiote.traits(s), g=this._creatureG, aura=this._auraG, c=this._capsuleG;
    g.clear(); aura.clear(); c.clear(); this._shadowG.clear(); this._lightG.clear();
    this._depthLayers.forEach(function(l){l.clear();});
    if(!s.capsuleOpened){
      var breathe=1+Math.sin(this._pulse*1.4)*0.02;
      c.scaleX=breathe; c.scaleY=breathe;
      c.lineStyle(4,0x6fd8ff,.8); c.strokeRoundedRect(-110,-145,220,290,36);
      c.fillStyle(0x15304d,.35); c.fillRoundedRect(-105,-140,210,280,32);
      c.lineStyle(2,0xd77cff,.5+Math.sin(this._pulse*2)*.15); c.strokeCircle(0,0,70);
      return;
    }
    var style=NEBUSTION.Symbiote.bodyStyle(s.genome.seed);
    var hsvFill=Phaser.Display.Color.HSVToRGB(style.hue/360, style.sat, style.val);
    var hsvLine=Phaser.Display.Color.HSVToRGB(style.hue/360, Math.min(1,style.sat+0.15), Math.min(1,style.val+0.4));
    var fillColor=hsvFill.color, lineColor=hsvLine.color;
    // Croissance accélérée : le Symtor devient nettement plus imposant à mesure qu'il évolue,
    // pas juste un peu plus grand — la taille grimpe de plus en plus vite avec le niveau.
    var level=s.level, size=60+level*3.2+Math.pow(level,1.35)*0.9, traits=t;

    // Déplacement lent et organique dans le bâtiment (la créature "vit" au lieu de rester figée).
    var wanderX=Math.sin(this._pulse*0.37)*16+Math.sin(this._pulse*0.13+2.1)*9;
    var wanderY=Math.cos(this._pulse*0.29)*11+Math.sin(this._pulse*0.21+1)*5;
    g.x=this.scale.width/2+wanderX; g.y=455+wanderY;
    this._lightG.x=g.x; this._lightG.y=g.y;
    var rotY=this._rotY||0;
    this._shadowG.x=g.x+10+Math.sin(rotY)*12; this._shadowG.y=g.y+18;
    aura.x=g.x; aura.y=g.y;

    var moodBoost=1+this._mood*0.5;
    var pulse=1+Math.sin(this._pulse*(2.2+this._mood*2.6))*0.035*moodBoost;
    // Vraie rotation 3D : l'échelle horizontale simule le raccourci en perspective (face pleine
    // → vue de 3/4 → quasi profil), pilotée par this._rotY (glisser à l'écran ou rotation lente).
    var squish=0.56+0.44*Math.abs(Math.cos(rotY));
    g.scaleX=pulse*squish; g.scaleY=pulse;
    this._lightG.scaleX=pulse*squish; this._lightG.scaleY=pulse;
    this._shadowG.scaleX=pulse*squish; this._shadowG.scaleY=pulse;
    this._depthLayers.forEach(function(l){ l.scaleX=pulse*squish; l.scaleY=pulse; });

    // Aura douce, plus vive juste après un repas / une évolution.
    aura.fillStyle(lineColor,0.05+this._mood*0.12);
    aura.fillCircle(0,0,size*.95+this._mood*18);

    // Ombre au sol : se décale avec la rotation, comme une vraie ombre portée par un volume qui tourne.
    this._shadowG.clear();
    this._shadowG.fillStyle(0x000000,.28);
    this._shadowG.fillEllipse(8,size*.72,size*1.45,size*.36);

    // Extrusion volumétrique : plusieurs tranches empilées en profondeur, de plus en plus sombres
    // et décalées par la rotation (parallaxe), pour donner un vrai volume tourné plutôt qu'un
    // simple sprite plat — l'épaisseur du corps « se révèle » visiblement quand on le fait pivoter.
    for(var li=0;li<this._depthLayers.length;li++){
      var depthZ=4-li; // li=0 → tranche la plus lointaine (4), li=3 → la plus proche du corps (1)
      var layer=this._depthLayers[li];
      layer.x=g.x+Math.sin(rotY)*depthZ*5; layer.y=g.y+4+depthZ*3.2;
      var dCol=this._darken(fillColor,0.1+depthZ*0.15), dLine=this._darken(lineColor,0.15+depthZ*0.15);
      this._drawBodyShape(layer,style,size+depthZ*2.4,dCol,dLine,0.92-depthZ*0.1);
    }

    // Corps principal 2D avec éclairage simulé.
    g.clear();
    this._drawBodyShape(g,style,size,fillColor,lineColor,.94);

    // Éclairage volumétrique : ombre interne + lumière principale + reflet spéculaire, la lumière
    // reste fixée à une source « dans le monde » et glisse donc sur le corps quand il tourne.
    var lightShift=Math.sin(rotY)*size*.22;
    this._lightG.clear();
    this._lightG.fillStyle(0x05070f,.17);
    this._lightG.fillEllipse(size*.18-lightShift,size*.18,size*1.02,size*.72);
    this._lightG.fillStyle(0xffffff,.12+this._mood*.06);
    this._lightG.fillEllipse(-size*.30-lightShift,-size*.28,size*.52,size*.30);
    this._lightG.fillStyle(0xffffff,.42);
    this._lightG.fillEllipse(-size*.42-lightShift,-size*.38,Math.max(7,size*.13),Math.max(4,size*.08));
    this._lightG.lineStyle(3,0xffffff,.12);
    this._lightG.strokeEllipse(-size*.06,-size*.06,size*1.05,size*.86);

    // Traits radiaux (yeux, tentacules, pics, cristaux, fourrure, points lumineux) : leur angle
    // de base est décalé par la rotation, donc ils tournent avec le corps comme des reliefs réels ;
    // ceux qui passent côté « caché » rétrécissent et s'estompent (profondeur simulée).
    function depthFactor(angle){ var d=Math.cos(angle+rotY); return { scale:0.55+0.45*(d+1)/2, alpha:0.32+0.68*(d+1)/2 }; }

    // Yeux : nombre variable, chacun cligne selon son propre rythme (organisme vraiment vivant).
    var eyes=Math.min(10,1+traits.eyes);
    for(var i=0;i<eyes;i++){
      var a=(i/eyes)*Math.PI*2-.2, rr=size*.48, df=depthFactor(a);
      var ex=Math.cos(a+rotY)*rr, ey=Math.sin(a)*rr*.72;
      var blinkCycle=3.2+((i*37)%5)*0.55, phase=(this._pulse+i*0.83)%blinkCycle;
      var closed=phase>blinkCycle-0.16;
      var eyeR=(7+level*.12)*df.scale;
      if(closed){ g.lineStyle(3,0x101020,df.alpha); g.lineBetween(ex-eyeR,ey,ex+eyeR,ey); }
      else { g.fillStyle(0xeaf2ff,df.alpha); g.fillCircle(ex,ey,eyeR); g.fillStyle(0x101020,df.alpha); g.fillCircle(ex,ey,(3+level*.08)*df.scale); }
    }

    // Tentacules : chacune ondule à sa propre vitesse/phase, dérivées de son index (pas de hasard qui saute).
    var tent=traits.tentacles+2;
    for(var j=0;j<tent;j++){
      var baseA=(j/tent)*Math.PI*2+rotY, df2=depthFactor((j/tent)*Math.PI*2);
      var wob=Math.sin(this._pulse*(1.1+(j%3)*0.32)+j*1.7)*0.22*(1+this._mood*0.4);
      var aa=baseA+wob;
      var len=(40+level*3+Math.sqrt(level)*8+traits.tail*5)*(1+Math.sin(this._pulse*1.4+j)*0.06)*df2.scale;
      var w2=(1+Math.min(0.4,style.asym-0.85));
      g.lineStyle((4+level*0.12)*df2.scale,lineColor,.9*df2.alpha);
      g.beginPath(); g.moveTo(Math.cos(baseA)*size*.45,Math.sin(baseA)*size*.4); g.lineTo(Math.cos(aa)*len*w2,Math.sin(aa)*len*w2); g.strokePath();
    }

    // Bouts de corps : excroissances supplémentaires qui apparaissent et grossissent au fil des
    // niveaux (jusqu'à 6), rattachées au corps par un petit col — le Symtor « grandit dans tous les
    // sens » au lieu de juste s'agrandir uniformément. Position fixe par excroissance (graine du
    // génome), donc stable d'un chargement à l'autre ; ne fait que grossir avec le niveau.
    var lobeN=NEBUSTION.Symbiote.lobeCount(level);
    for(var lo=0;lo<lobeN;lo++){
      var lr=NEBUSTION.Symbiote.rng(s.genome.seed+9000+lo*13);
      var la0=lr()*Math.PI*2, ldist=0.6+lr()*0.24, lsizeFrac=0.2+lr()*0.14;
      var la=la0+rotY, dfl=depthFactor(la0);
      var lx=Math.cos(la)*size*ldist, ly=Math.sin(la0)*size*ldist*0.85;
      var lgrow=Math.min(1.4,0.55+(level/50)*0.95);
      var lsize=size*lsizeFrac*lgrow*dfl.scale;
      g.lineStyle(4*dfl.scale,lineColor,.55*dfl.alpha);
      g.lineBetween(Math.cos(la)*size*.42,Math.sin(la0)*size*.38,lx,ly);
      g.fillStyle(fillColor,.92*dfl.alpha); g.lineStyle(2.5*dfl.scale,lineColor,.8*dfl.alpha);
      g.fillEllipse(lx,ly,lsize*1.15,lsize); g.strokeEllipse(lx,ly,lsize*1.15,lsize);
      g.fillStyle(0xffffff,.16*dfl.alpha);
      g.fillEllipse(lx-lsize*.25,ly-lsize*.22,lsize*.4,lsize*.26);
    }
    // Pics
    for(var k=0;k<traits.spikes;k++){
      var sa0=(k/Math.max(1,traits.spikes))*Math.PI*2, sa=sa0+rotY, dfk=depthFactor(sa0);
      g.fillStyle(0xff6b9a,.85*dfk.alpha);
      g.fillTriangle(Math.cos(sa)*size*.55,Math.sin(sa)*size*.45,Math.cos(sa)*size*.9*dfk.scale,Math.sin(sa)*size*.72*dfk.scale,Math.cos(sa+.18)*size*.55,Math.sin(sa+.18)*size*.45);
    }
    // Cornes
    if(traits.horns){ g.lineStyle(7,0xb47bff,.9); g.lineBetween(-size*.35,-size*.42,-size*.65,-size*.78); g.lineBetween(size*.35,-size*.42,size*.65,-size*.78); }
    // Plaques
    if(traits.plates){ g.lineStyle(4,0x6fd8ff,.45); for(var q=-2;q<=2;q++) g.strokeCircle(q*size*.2,0,size*.18); }
    // Bouche : s'ouvre visiblement pendant/juste après un repas
    if(traits.mouth||this._mouth>0){
      var mouthOpen=size*.22+this._mouth*size*.28;
      g.lineStyle(5,0xff6b9a,.9); g.strokeEllipse(0,size*.18,size*.55,mouthOpen);
    }
    // Ailes membraneuses
    if(traits.wings){
      g.fillStyle(lineColor,.28); g.lineStyle(3,lineColor,.7);
      var wingFlap=Math.sin(this._pulse*1.8)*0.08;
      [-1,1].forEach(function(side){
        var wpts=[
          new Phaser.Geom.Point(side*size*.3,-size*.1),
          new Phaser.Geom.Point(side*size*(1.15+traits.wings*0.05),-size*(0.55+wingFlap)),
          new Phaser.Geom.Point(side*size*.5,size*.3)
        ];
        g.fillPoints(wpts,true); g.strokePoints(wpts,true);
      });
    }
    // Nageoires
    if(traits.fins){
      g.fillStyle(lineColor,.55);
      for(var fn=0;fn<traits.fins;fn++){ var fy=-size*.3+fn*(size*.6/Math.max(1,traits.fins)); g.fillTriangle(size*.55,fy,size*.9,fy-8,size*.9,fy+8); g.fillTriangle(-size*.55,fy,-size*.9,fy-8,-size*.9,fy+8); }
    }
    // Excroissances cristallines
    if(traits.crystals){
      g.lineStyle(2,0xeaf2ff,.6);
      for(var cr=0;cr<traits.crystals;cr++){ var ca0=(cr/traits.crystals)*Math.PI*2+0.4, ca=ca0+rotY, dfc=depthFactor(ca0); var cx=Math.cos(ca)*size*.62,cy=Math.sin(ca0)*size*.55; g.fillStyle(0x6fd8ff,.75*dfc.alpha); var cpts=[new Phaser.Geom.Point(cx,cy-12*dfc.scale),new Phaser.Geom.Point(cx+7*dfc.scale,cy+8*dfc.scale),new Phaser.Geom.Point(cx-7*dfc.scale,cy+8*dfc.scale)]; g.fillPoints(cpts,true); g.strokePoints(cpts,true); }
    }
    // Fourrure hirsute (petits traits le long du contour)
    if(traits.fur){
      var tufts=6+traits.fur*2;
      for(var tf=0;tf<tufts;tf++){ var ta0=(tf/tufts)*Math.PI*2, ta=ta0+rotY, dft=depthFactor(ta0); var tx=Math.cos(ta)*size*.62,ty=Math.sin(ta0)*size*.52; g.lineStyle(2,lineColor,.6*dft.alpha); g.lineBetween(tx,ty,tx+Math.cos(ta)*9*dft.scale,ty+Math.sin(ta0)*9*dft.scale); }
    }
    // Points luminescents (pulsent doucement)
    if(traits.glowSpots){
      for(var gs=0;gs<traits.glowSpots;gs++){
        var ga0=(gs/traits.glowSpots)*Math.PI*2+1.1, ga=ga0+rotY, dfg=depthFactor(ga0);
        var gx=Math.cos(ga)*size*.4,gy=Math.sin(ga0)*size*.35;
        var glow=0.4+Math.sin(this._pulse*2.4+gs)*0.3;
        g.fillStyle(0xffd166,Math.max(0.15,glow)*dfg.alpha); g.fillCircle(gx,gy,(4+level*.05)*dfg.scale);
      }
    }
    // Rayures organiques
    if(traits.stripes){
      g.lineStyle(3,0x101020,.35);
      for(var st=1;st<=traits.stripes;st++){ var frac=st/(traits.stripes+1); g.beginPath(); g.arc(0,0,size*0.9*frac,Phaser.Math.DegToRad(200),Phaser.Math.DegToRad(340)); g.strokePath(); }
    }
    // Surbrillance temporaire sur la dernière mutation obtenue
    if(this._flashLimb && this._flashT>0){
      g.lineStyle(3,0xffd166,Math.min(1,this._flashT));
      g.strokeCircle(0,0,size*1.05+Math.sin(this._pulse*6)*4);
    }
  }
};
