/**
 * NEBUSTION - PrestigeScene (étape 10)
 * « Renaissance galactique » : onglet Renaissance (statut, prérequis, gain de Reliques estimé,
 * ce qui est gardé/réinitialisé, confirmation FORTE puis résultat), onglet Arbre (5 nœuds de
 * bonus permanents, achetés en Reliques), onglet Paliers (TIER_PERKS + prochains objectifs).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.PrestigeScene = class PrestigeScene extends NEBUSTION.ProgressScene {
  constructor() { super('PrestigeScene'); }

  _hubKey() { return 'prestige'; }
  _titleText() { return 'PRESTIGE'; }
  _accent() { return 0xffd166; }
  _accentHex() { return '#ffd166'; }
  _defaultTab() { return 'rebirth'; }
  _tabDefs() { return [{ id: 'rebirth', label: 'Renaissance' }, { id: 'tree', label: 'Arbre' }, { id: 'tiers', label: 'Paliers' }]; }

  _badgeContent(c) {
    var PM = NEBUSTION.PrestigeManager;
    this._badgePill(c, 'relic', this._fmt(PM.relics()), this._accent(), this._accentHex());
  }

  _renderTab(w) {
    if (this.tab === 'tree') return this._renderTree(w);
    if (this.tab === 'tiers') return this._renderTiers(w);
    return this._renderRebirth(w);
  }

  // ================= Onglet Renaissance =================
  _renderRebirth(w) {
    var self = this, PM = NEBUSTION.PrestigeManager, cards = [];
    var chk = PM.canPrestige();

    var head = this._card(150, this._accent(), { glow: chk.ok });
    head.add(this._txt(24, 24, 'Statut : ' + PM.tierName(), 20, '#eaf2ff', { fontStyle: 'bold' }));
    head.add(this._txt(24, 50, PM.count() + ' Renaissance' + (PM.count() > 1 ? 's' : '') + ' effectuée' + (PM.count() > 1 ? 's' : '') + '  ·  ' + this._fmt(PM.relics()) + ' Reliques', 14, '#a9b8dc'));
    var okCmd = chk.commandLevel >= chk.needCommandLevel, okStars = chk.totalStars >= chk.needStars;
    head.add(this._txt(24, 84, 'Centre de commandement niv. ' + chk.commandLevel + ' / ' + chk.needCommandLevel, 15, okCmd ? '#5fd97a' : '#ff9a7b', { fontStyle: 'bold' }));
    head.add(this._txt(24, 108, 'Étoiles de Combat ' + chk.totalStars + ' / ' + chk.needStars, 15, okStars ? '#5fd97a' : '#ff9a7b', { fontStyle: 'bold' }));
    cards.push(head);

    var gain = this._card(150, this._accent(), {});
    gain.add(this._txt(24, 24, 'Gain estimé si vous Renaissez maintenant', 15, '#8e9cc0', { fontStyle: 'bold' }));
    var relicG = this.add.graphics(); this._drawRelic(relicG, 46, 76, 24, this._accent()); gain.add(relicG);
    gain.add(this._txt(78, 76, '+' + this._fmt(PM.previewRelics()) + ' Reliques', 26, '#ffe9a3', { fontStyle: '900' }).setOrigin(0, 0.5));
    gain.add(this._txt(24, 118, 'Calculé sur les ressources produites, les étoiles de Combat et l\'XP de ce cycle.', 12, '#6d7c9c', { wordWrap: { width: gain._cw - 48 } }));
    cards.push(gain);

    var info = this._card(320, 0x394869, { dim: true });
    info.add(this._txt(24, 22, 'À la Renaissance', 16, '#eaf2ff', { fontStyle: 'bold' }));
    var keepG = this.add.graphics(); this._drawCheck(keepG, 34, 54, 1.1, 0x5fd97a); info.add(keepG);
    info.add(this._txt(50, 54, 'Conservé', 14, '#5fd97a', { fontStyle: 'bold' }));
    info.add(this._txt(24, 76, 'Héros (niveaux et fragments), équipement, vaisseaux, skins, Prismes, Pass de saison, succès, progression d\'expédition et d\'événement, Reliques et arbre de bonus.', 13, '#c7d3f0', { wordWrap: { width: info._cw - 48 } }));
    var lockG = this.add.graphics(); this._drawLock(lockG, 34, 178, 1.3, 0xff9a7b, 1); info.add(lockG);
    info.add(this._txt(50, 178, 'Réinitialisé', 14, '#ff9a7b', { fontStyle: 'bold' }));
    info.add(this._txt(24, 200, 'Bâtiments (retour au niveau de départ + bonus Fondations gravées), ressources et drones, étoiles/victoires de combat, secteurs de galaxie et empires.', 13, '#c7d3f0', { wordWrap: { width: info._cw - 48 } }));
    cards.push(info);

    cards.push(this._buildRebirthButton(chk));
    return { cards: cards, footer: null };
  }

  _buildRebirthButton(chk) {
    var self = this, bw = this.scale.width - 24, h = 78;
    var enabled = chk.ok;
    var c = this.add.container(12, 0);
    c._cardH = h; c._hits = [];
    var bg = this.add.graphics();
    bg.fillGradientStyle(enabled ? 0x3a2c08 : 0x1a2233, enabled ? 0x3a2c08 : 0x1a2233, enabled ? 0x0b1224 : 0x11172a, enabled ? 0x0b1224 : 0x11172a, 1);
    bg.fillRoundedRect(0, 0, bw, h, 20);
    bg.lineStyle(3, enabled ? 0xffd166 : 0x394869, enabled ? 1 : 0.5);
    bg.strokeRoundedRect(0, 0, bw, h, 20);
    c.add(bg);
    var label = enabled ? 'RENAÎTRE MAINTENANT' : 'CONDITIONS NON REMPLIES';
    c.add(this._txt(bw / 2, h / 2, label, 22, enabled ? '#ffe9a3' : '#6d7c9c', { fontStyle: '900' }).setOrigin(0.5));
    c._hits.push({ x: 0, y: 0, w: bw, h: h, fn: function () { if (enabled) self._confirmRebirth(); else self.fx.toast('Objectifs non atteints', null, null); } });
    return c;
  }

  _confirmRebirth() {
    var self = this, PM = NEBUSTION.PrestigeManager, gain = PM.previewRelics();
    this._confirm('⚠ Renaissance galactique', [
      '⚠ Cette action est IRRÉVERSIBLE.',
      'Bâtiments, ressources, étoiles de Combat, secteurs de galaxie et empires seront réinitialisés.',
      'Héros, équipement, vaisseaux, skins, Prismes, Pass, succès et progression d\'expédition/événement sont conservés.',
      'Vous recevrez +' + this._fmt(gain) + ' Reliques.'
    ], 'Confirmer la Renaissance', function () { self._doRebirth(); }, { accent: 0xffd166, confirmAccent: 0xffd166, warnColor: true, extraH: 40 });
  }

  _doRebirth() {
    var self = this, PM = NEBUSTION.PrestigeManager;
    var r = PM.perform();
    if (!r.ok) { this.fx.toast('Renaissance impossible', null, null); this._refreshAll(false); return; }
    this._reveal('RENAISSANCE ACCOMPLIE', 'Vous entrez dans l\'ère « ' + r.tier + ' »', [
      { kind: 'relic', amount: r.relicsGained, color: 0xffd166, hex: '#ffe9a3', label: 'Reliques' }
    ], ['Total : ' + this._fmt(r.totalRelics) + ' Reliques  ·  Renaissance n°' + r.cycle], 0xffd166, function () { self._refreshAll(false); });
  }

  // ================= Onglet Arbre =================
  _renderTree(w) {
    var self = this, PM = NEBUSTION.PrestigeManager, cards = [];
    var head = this._card(60, this._accent(), { dim: true });
    head.add(this._txt(24, 30, 'Reliques disponibles : ' + this._fmt(PM.relics()), 17, '#ffe9a3', { fontStyle: 'bold' }).setOrigin(0, 0.5));
    cards.push(head);
    PM.treeStatus().forEach(function (n) {
      var h = 150, card = self._card(h, self._accent(), { dim: n.maxed });
      card.add(self._txt(24, 22, n.name, 18, '#eaf2ff', { fontStyle: 'bold' }));
      card.add(self._txt(24, 48, n.desc, 13, '#a9b8dc', { wordWrap: { width: card._cw - 48 } }));
      card.add(self._txt(24, 96, 'Niveau ' + n.level + ' / ' + n.maxLevel, 14, '#8e9cc0'));
      self._bar(card, 24, 116, card._cw - 48, 10, n.level / n.maxLevel, self._accent());
      if (n.maxed) {
        self._btn(card, card._cw - 96, 70, 150, 44, 'MAXIMUM', 0x394869, true, null, null);
      } else {
        var afford = PM.relics() >= n.cost;
        self._btn(card, card._cw - 96, 70, 150, 44, self._fmt(n.cost) + ' 🔺', afford ? self._accent() : 0x394869, !afford, function () { self._buyNode(n.id); }, 'Reliques insuffisantes.');
      }
      cards.push(card);
    });
    return { cards: cards, footer: null };
  }
  _buyNode(id) {
    var self = this, r = NEBUSTION.PrestigeManager.buyNode(id);
    if (!r.ok) { this.fx.toast('Achat refusé', r.reason || '', null); this._refreshAll(false); return; }
    this.fx.toast('Palier amélioré', 'Niveau ' + r.level, null);
    this._refreshAll(false);
  }

  // ================= Onglet Paliers =================
  _renderTiers(w) {
    var self = this, PM = NEBUSTION.PrestigeManager, cards = [];
    var count = PM.count();
    NEBUSTION.Prestige.TIER_PERKS.forEach(function (t) {
      var reached = count >= t.count, current = count === t.count - 1 ? false : reached;
      var h = 110, card = self._card(h, reached ? 0x5fd97a : self._accent(), { dim: !reached });
      card.add(self._txt(24, 24, t.count + '. ' + t.name, 19, reached ? '#5fd97a' : '#eaf2ff', { fontStyle: 'bold' }));
      card.add(self._txt(24, 54, t.desc, 14, '#a9b8dc', { wordWrap: { width: card._cw - 90 } }));
      if (reached) { var g = self.add.graphics(); self._drawCheck(g, card._cw - 34, h / 2, 1.2, 0x5fd97a); card.add(g); }
      cards.push(card);
    });
    var req = PM.requirements();
    var next = this._card(90, 0x394869, { dim: true });
    next.add(this._txt(24, 22, 'Prochaine Renaissance (n°' + (count + 1) + ')', 15, '#8e9cc0', { fontStyle: 'bold' }));
    next.add(this._txt(24, 50, 'Commandement niv. ' + req.commandLevel + '  ·  ' + req.totalStars + ' étoiles de Combat', 15, '#eaf2ff', { fontStyle: 'bold' }));
    cards.push(next);
    return { cards: cards, footer: null };
  }
};
