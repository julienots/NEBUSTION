/**
 * NEBUSTION - SolarSystemScene
 * Système solaire de la « Nouvelle Galaxie » : un soleil rayonnant au centre, 6 planètes qui tournent
 * chacune sur leur orbite (vue inclinée, avec passage devant/derrière le soleil), une lune, une
 * ceinture d'astéroïdes, des anneaux, et l'ombre de chaque planète tournée à l'opposé du soleil.
 * Chaque planète est cliquable : elle ouvre ExoPlanetScene (vraie planète 3D rotative, comme Nexus-01).
 * `this._planets[i]` contient `def` (id, nom, type, taille), `box` (le conteneur affiché) et `zone` (zone de toucher,
 * plus grande que le disque pour viser facilement une planète en mouvement).
 * Textures : NEBUSTION.SolarTextures (générées par code).
 */
window.NEBUSTION = window.NEBUSTION || {};

NEBUSTION.SolarSystemScene = class SolarSystemScene extends Phaser.Scene {
  constructor() {
    super('SolarSystemScene');
  }

  init(data) {
    this._from = (data && data.from) || 'UniverseScene';
  }

  create() {
    var w = this.scale.width, h = this.scale.height, self = this;
    var ST = NEBUSTION.SolarTextures, ADD = Phaser.BlendModes.ADD;
    this.cameras.main.setBackgroundColor('#03040c');
    this.cameras.main.fadeIn(500, 0, 0, 0);
    NEBUSTION.SceneBackground.build(this, { withPlanet: false });

    this.hud = NEBUSTION.HUD.attach(this);
    this._busy = false;

    this.add.text(w / 2, 126, 'NOUVELLE GALAXIE', {
      fontFamily: 'Arial, sans-serif', fontSize: '20px', fontStyle: '900', color: '#eaf2ff'
    }).setOrigin(0.5).setDepth(80).setShadow(0, 0, '#3affd0', 12, true, true);
    this.add.text(w / 2, 150, 'Système Héliora', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#7a89ad'
    }).setOrigin(0.5).setDepth(80);

    var back = new NEBUSTION.Button(this, 46, 126, {
      width: 56, height: 44, accentColor: 0x6c3ce9,
      iconDraw: function (g) {
        g.lineStyle(2.5, 0x6c3ce9, 1);
        g.lineBetween(8, 0, -8, 0); g.lineBetween(-8, 0, -1, -7); g.lineBetween(-8, 0, -1, 7);
      },
      onClick: function () { self._goTo(self._from); }
    });
    back.setDepth(80);

    // ---- Géométrie du système : vue inclinée (ellipses aplaties) et légèrement pivotée ----
    this._cx = w / 2; this._cy = h * 0.5 + 10;
    this._ROT = -0.30; this._RATIO = 0.5;
    this._cosR = Math.cos(this._ROT); this._sinR = Math.sin(this._ROT);

    // Orbites + ceinture d'astéroïdes : dessinées dans un plan aplati (conteneur imbriqué à l'échelle Y réduite)
    var outer = this.add.container(this._cx, this._cy).setRotation(this._ROT).setDepth(10);
    var plane = this.add.container(0, 0).setScale(1, this._RATIO);
    outer.add(plane);
    this._defs = this._planetDefs();
    var og = this.add.graphics();
    this._defs.forEach(function (d) {
      og.lineStyle(2, d.orbitColor, 0.10); og.strokeCircle(0, 0, d.orbit + 1);
      og.lineStyle(1.5, d.orbitColor, 0.30); og.strokeCircle(0, 0, d.orbit);
    });
    plane.add(og);
    this._beltR = 202;
    var belt = this.add.graphics(), rnd = new Phaser.Math.RandomDataGenerator(['nebustion-belt']), i;
    for (i = 0; i < 260; i++) {
      var a = rnd.frac() * Math.PI * 2, r = this._beltR + (rnd.frac() - 0.5) * 20 + (rnd.frac() - 0.5) * 8, s = 0.8 + rnd.frac() * 1.8;
      var tone = 140 + Math.floor(rnd.frac() * 90);
      belt.fillStyle(Phaser.Display.Color.GetColor(tone, tone - 14, tone - 34), 0.5 + rnd.frac() * 0.45);
      belt.fillCircle(Math.cos(a) * r, Math.sin(a) * r, s);
    }
    plane.add(belt);
    this._belt = belt;

    // ---- Le soleil ----
    var cx = this._cx, cy = this._cy;
    this._sunGlow = this.add.image(cx, cy, ST.ensureGlow(this)).setDisplaySize(520, 520).setTint(0xff9a2a)
      .setAlpha(0.42).setBlendMode(ADD).setDepth(38);
    this._corona1 = this.add.image(cx, cy, ST.ensureCorona(this)).setDisplaySize(330, 330)
      .setAlpha(0.85).setBlendMode(ADD).setDepth(39);
    this._corona2 = this.add.image(cx, cy, ST.ensureCorona(this)).setDisplaySize(270, 270).setRotation(0.5)
      .setAlpha(0.7).setBlendMode(ADD).setDepth(39);
    this._sun = this.add.image(cx, cy, ST.ensureSun(this)).setDisplaySize(112, 112).setDepth(40);
    this._sunHot = this.add.image(cx, cy, ST.ensureGlow(this)).setDisplaySize(170, 170).setTint(0xffe6a0)
      .setAlpha(0.5).setBlendMode(ADD).setDepth(41);
    this.tweens.add({ targets: this._sunGlow, alpha: 0.6, scaleX: this._sunGlow.scaleX * 1.06, scaleY: this._sunGlow.scaleY * 1.06, duration: 2600, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    this.tweens.add({ targets: this._sunHot, alpha: 0.72, duration: 1700, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    this.tweens.add({ targets: this._sun, rotation: Math.PI * 2, duration: 90000, repeat: -1 });
    // Apparition douce du soleil
    this._sun.setScale(0.2); this.tweens.add({ targets: this._sun, scaleX: 112 / 256, scaleY: 112 / 256, duration: 900, ease: 'Back.easeOut' });

    // ---- Les planètes ----
    this._planets = this._defs.map(function (d, idx) { return self._buildPlanet(d, idx); });

    // ---- Bandeau d'information ----
    var ih = 78, iy = h - 190;
    var panel = this.add.graphics().setDepth(70);
    panel.fillStyle(0x0b1224, 0.78); panel.fillRoundedRect(w / 2 - 300, iy - ih / 2, 600, ih, 16);
    panel.lineStyle(1.5, 0x3affd0, 0.35); panel.strokeRoundedRect(w / 2 - 300, iy - ih / 2, 600, ih, 16);
    this.add.text(w / 2, iy - 14, 'Système Héliora  ·  1 étoile  ·  6 planètes  ·  1 ceinture d\'astéroïdes', {
      fontFamily: 'Arial, sans-serif', fontSize: '15px', fontStyle: 'bold', color: '#dfeaff'
    }).setOrigin(0.5).setDepth(71);
    this.add.text(w / 2, iy + 14, 'Touchez une planète pour l\'explorer', {
      fontFamily: 'Arial, sans-serif', fontSize: '13px', color: '#7a89ad'
    }).setOrigin(0.5).setDepth(71);

    new NEBUSTION.BottomNav(this, 'galaxy');
    this._update(0, 0);   // première mise en place avant le 1er affichage
  }

  _planetDefs() {
    return [
      { id: 'pyros', name: 'Pyros', type: 'lava', seed: 11, c1: [128, 40, 18], c2: [90, 28, 14], size: 34, orbit: 80, period: 15, start: 0.6, atm: 0xff6a2a, orbitColor: 0xff8a4a },
      { id: 'aqualis', name: 'Aqualis', type: 'earth', seed: 23, c1: [20, 90, 170], c2: [60, 140, 80], size: 50, orbit: 120, period: 24, start: 2.4, atm: 0x62c0ff, orbitColor: 0x6cc4ff, moon: true },
      { id: 'rubea', name: 'Rubéa', type: 'desert', seed: 37, c1: [192, 98, 56], c2: [128, 58, 40], size: 42, orbit: 165, period: 33, start: 4.6, atm: 0xff9a6a, orbitColor: 0xff9a6a },
      { id: 'goliath', name: 'Goliath', type: 'gas', seed: 41, c1: [222, 178, 126], c2: [148, 98, 66], size: 84, orbit: 245, period: 52, start: 1.3, atm: 0xffc890, orbitColor: 0xffc890 },
      { id: 'saturnia', name: 'Saturnia', type: 'ringgas', seed: 53, c1: [232, 210, 150], c2: [170, 140, 96], size: 44, orbit: 300, period: 68, start: 3.6, atm: 0xffe6a8, orbitColor: 0xffe6a8, ring: true },
      { id: 'glacia', name: 'Glacia', type: 'ice', seed: 67, c1: [160, 214, 238], c2: [222, 246, 255], size: 30, orbit: 338, period: 84, start: 5.5, atm: 0x9fe8ff, orbitColor: 0x9fe8ff }
    ];
  }

  /** Construit une planète (conteneur : halo d'atmosphère, anneaux, corps, ombre) et son étiquette. */
  _buildPlanet(d, idx) {
    var ST = NEBUSTION.SolarTextures, ADD = Phaser.BlendModes.ADD, size = d.size;
    var box = this.add.container(0, 0);
    var atm = this.add.image(0, 0, ST.ensureGlow(this)).setDisplaySize(size * 1.55, size * 1.55).setTint(d.atm).setAlpha(0.32).setBlendMode(ADD);
    box.add(atm);
    var rings = null, RT = 0.32, ringW = size * 2.6;
    if (d.ring) {
      var rk = ST.ensureRing(this);
      var rb = this.add.image(0, 0, rk[0]).setDisplaySize(ringW, ringW * 160 / 512).setRotation(RT);
      box.add(rb); rings = { back: rb };
    }
    var body = this.add.image(0, 0, ST.ensurePlanet(this, d)).setDisplaySize(size, size);
    var shade = this.add.image(0, 0, ST.ensureShade(this)).setDisplaySize(size, size);
    box.add([body, shade]);
    if (d.ring) {
      var rf = this.add.image(0, 0, ST.ensureRing(this)[1]).setDisplaySize(ringW, ringW * 160 / 512).setRotation(RT);
      box.add(rf); rings.front = rf;
    }
    var label = this.add.text(0, 0, d.name, {
      fontFamily: 'Arial, sans-serif', fontSize: '11px', fontStyle: 'bold', color: '#cfe0ff'
    }).setOrigin(0.5, 0).setAlpha(0.78).setDepth(72).setShadow(0, 1, '#000000', 3, false, true);

    var moon = null;
    if (d.moon) {
      moon = this.add.image(0, 0, ST.ensurePlanet(this, { id: 'lune', type: 'rock', seed: 7, c1: [176, 176, 184], c2: [110, 110, 120] })).setDisplaySize(15, 15);
      moon.angle0 = 1.2;
    }
    // Zone de toucher généreuse (les petites planètes bougent : il faut pouvoir les viser au doigt).
    var hs = d.ring ? Math.max(size * 2.4, 96) : Math.max(size * 1.5, 72), self = this;
    var zone = this.add.zone(0, 0, hs, hs).setDepth(90).setInteractive({ useHandCursor: true });
    zone.on('pointerup', function (pointer) {
      if (pointer.getDistance && pointer.getDistance() > 16) return;   // un glissé n'ouvre rien
      self._openPlanet(d, box);
    });
    return { def: d, box: box, body: body, shade: shade, atm: atm, rings: rings, label: label, moon: moon, zone: zone,
      angle: d.start, speed: Math.PI * 2 / d.period };
  }

  update(time, delta) { this._update(time, delta); }

  _update(time, delta) {
    if (!this._planets) return;
    var dt = Math.min(delta, 60) / 1000, cx = this._cx, cy = this._cy, cosR = this._cosR, sinR = this._sinR, RATIO = this._RATIO;
    var i, p, d, ex, ey, x, y, s, front, sc;

    this._corona1.rotation += 0.05 * dt;
    this._corona2.rotation -= 0.08 * dt;
    this._belt.rotation += 0.035 * dt;

    for (i = 0; i < this._planets.length; i++) {
      p = this._planets[i]; d = p.def;
      p.angle += p.speed * dt;
      s = Math.sin(p.angle);
      ex = Math.cos(p.angle) * d.orbit; ey = s * d.orbit * RATIO;
      x = cx + ex * cosR - ey * sinR; y = cy + ex * sinR + ey * cosR;
      front = s > 0;
      sc = 0.9 + 0.12 * s;                               // un peu plus grosse quand elle passe devant
      p.box.setPosition(x, y).setScale(sc).setDepth(front ? 60 : 20);
      p.shade.setRotation(Math.atan2(y - cy, x - cx));   // face sombre à l'opposé du soleil
      p.label.setPosition(x, y + (d.size * sc) / 2 + (d.ring ? 14 : 5));
      p.zone.setPosition(x, y);

      if (p.moon) {
        var m = p.moon; m.angle0 += 1.5 * dt;
        var ms = Math.sin(m.angle0), mr = 40 * sc;
        m.setPosition(x + Math.cos(m.angle0) * mr, y + ms * mr * 0.5).setScale(sc * 15 / 192 * (0.9 + 0.15 * ms)).setDepth(p.box.depth + (ms > 0 ? 2 : -2));
      }
    }
  }

  /** Toucher une planète : petit rebond, puis on descend sur sa surface 3D. */
  _openPlanet(d, box) {
    if (this._busy) return;
    try { if (window.nebustionPlaySfx) window.nebustionPlaySfx('ui_click'); } catch (e) { /* son facultatif */ }
    this.tweens.add({ targets: box, scaleX: box.scaleX * 1.25, scaleY: box.scaleY * 1.25, duration: 160, yoyo: true, ease: 'Sine.easeOut' });
    this._goTo('ExoPlanetScene', { planetId: d.id, from: 'SolarSystemScene' });
  }

  _goTo(scene, data) {
    if (this._busy) return;
    this._busy = true;
    this.cameras.main.fadeOut(300, 0, 0, 0);
    this.cameras.main.once('camerafadeoutcomplete', () => { this.scene.start(scene, data || {}); });
  }
};
