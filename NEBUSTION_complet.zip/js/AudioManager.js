// NEBUSTION AudioManager — gameplay SFX, preserves legacy WAV files.
const SFX = {
  ui_click: './assets/audio/ui_click.wav', build: './assets/audio/build.wav', attack: './assets/audio/attack.wav',
  hit: './assets/audio/hit.wav', victory: './assets/audio/victory.wav', defeat: './assets/audio/defeat.wav', alert: './assets/audio/alert.wav'
};
const cache = {};
function get(name){ if(!SFX[name]) return null; if(!cache[name]){ const a=new Audio(SFX[name]); a.preload='auto'; a.volume=0.16; cache[name]=a; } return cache[name]; }
export const gameAudio = {
  unlock(){ Object.values(SFX).forEach((_,i)=>{ try{get(Object.keys(SFX)[i]).load();}catch(e){} }); },
  play(name, options={}){ if(window.NEBUSTION && NEBUSTION.Settings && !NEBUSTION.Settings.get().sfxOn) return Promise.resolve(); const a=get(name); if(!a) return Promise.resolve(); try{ a.pause(); a.currentTime=0; var st = (window.NEBUSTION && NEBUSTION.Settings) ? NEBUSTION.Settings.get() : null; var master = st ? Number(st.sfxVolume) : 0.16; a.volume=Math.max(0, Math.min(1, (options.volume ?? 1) * master)); const p=a.play(); return p&&p.catch?p.catch(()=>{}):Promise.resolve(); }catch(e){ return Promise.resolve(); } }
};
window.nebustionAudio = gameAudio; window.nebustionPlaySfx=(name,options)=>gameAudio.play(name,options);
document.addEventListener('pointerdown',()=>gameAudio.unlock(),{once:true,capture:true});
document.addEventListener('touchstart',()=>gameAudio.unlock(),{once:true,capture:true});
