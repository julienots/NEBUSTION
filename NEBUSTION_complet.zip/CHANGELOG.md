# CHANGELOG — NEBUSTION Symtor

## 2026-09-27b — Correctif écran Mods & Plugins
- `js/scenes/ModsScene.js` ne permettait pas de défiler : la liste des mods s'étendait au-delà du bas de l'écran, rendant les derniers mods (et le bouton « Recharger le jeu ») inaccessibles dès qu'il y en avait plus d'une poignée. Ajout d'un défilement tactile (glissement) + molette (PC), avec masque de zone visible, comme sur les écrans Boutique/Héros.
- Les interrupteurs de mods ne sont plus des zones interactives individuelles (qui entraient en conflit avec le glissement) mais des zones de tap testées manuellement au relâchement, sans changer leur apparence ni leur comportement.
- Les 3 nouveaux mods (`journal_activite`, `raccourcis_clavier`, `bestiaire_menace`) passent en **désactivé par défaut** dans `mods/manifest.js` — à activer volontairement depuis Paramètres ⚙ → 🧩 Mods et plugins, comme `arsenal_cosmique`.
- Badge ⌨️ de `mods/raccourcis_clavier.js` déplacé du bas-centre (chevauchait le badge de `mods/temps_de_jeu.js`) vers le bas-droite, empilé au-dessus du bouton de sauvegarde rapide.
- Aucune donnée de jeu, sauvegarde ou autre écran modifié.

## 2026-09-27 — 3 nouveaux mods/plugins
- `mods/journal_activite.js` : badge 📜 (haut-droite) qui journalise améliorations de bâtiments, récoltes critiques et Renaissances (événements `upgrade`/`gain`/`prestige` de `NEBUSTION.Resources`).
- `mods/raccourcis_clavier.js` : touches 1-6 pour naviguer vers Planète/Galaxie/Héros/Boutique/QG/Codex, désactivées pendant un combat ou si un champ de texte a le focus.
- `mods/bestiaire_menace.js` : 2 ennemis jouables dans l'Arène personnalisée (Nécroptère, Bastion-Zéro) via `NEBUSTION.CustomContent.upsertEnemy`.
- Désactivables individuellement depuis Paramètres ⚙ → 🧩 Mods et plugins. Aucun fichier existant du jeu modifié — voir `LISEZMOI_MODS.md`.


## Version 2 — Rendu hybride 2D/2.5D du Symbiote
- Amélioration uniquement de `js/scenes/SymbioteScene.js`.
- Ajout d'une profondeur visuelle : extrusion sombre, ombre portée, éclairage, reflet spéculaire et pseudo-rotation.
- Le Symbiote reste procédural et animé ; aucune mécanique Symtor, sauvegarde ou ressource n'a été supprimée ou modifiée.
- Aucun moteur 3D externe n'a été ajouté : le rendu 3D est simulé dans Phaser pour conserver le jeu hors ligne.

## 2026-09-24 — 5 cartes cosmiques branchées
- Ajout des 5 héros/cartes : Auraxis, Ravnor, Kythar, Glacivor et Nymora.
- Les 5 sont intégrés au catalogue Héros, à la Boutique, à la collection et au combat.
- Les illustrations de la planche fournie sont conservées comme portraits 300×380 dans `assets/heroes/`.
- Chaque carte possède une rareté, un rôle, des statistiques, 3 compétences et un kit CombatEngine dédié.
- Cache hors-ligne (`sw.js`) mis à jour pour les 5 nouveaux portraits.
- Aucun fichier, asset, son ou système existant supprimé.


## Jetons Xon
- Nouvelle monnaie ultra-rare persistante : `Jetons Xon` (`shop.xon`), à 0 au démarrage.
- Badge Xon avec emblème octogonal/X directement dessiné dans la Boutique, avec animation légère.
- Les prix acceptent désormais `xon` en plus des Prismes et ressources classiques.
- Auraxis, Ravnor, Kythar, Glacivor et Nymora demandent aussi des Jetons Xon.
- Les contenus les plus rares peuvent en donner : expéditions Abyssal/Mythique (chance très faible) et derniers paliers de deux objectifs long terme.
- Aucune ressource, musique, carte ou mécanique existante n'est supprimée.

## Correctif QG — défrichage des parcelles
- Empêche les actions simultanées sur « Défricher » pendant le rafraîchissement du panneau.
- Corrige la disposition des 12 cartes de bâtiments (4 colonnes × 3 rangées) : auparavant la grille était dimensionnée pour 10 cartes, et la dernière rangée dépassait du panneau, pouvant intercepter des interactions.
- Agrandit et repositionne le panneau du QG pour que toutes les cartes restent dans ses limites.
- Ne modifie ni les coûts, ni les sauvegardes, ni les ressources, ni les autres scènes.
- Tests Node QGGrid : 39/39. Vérification syntaxique : OK. Test visuel sur téléphone non exécuté.


## Correctif équipement — boutons « Équiper »
- Correction de la zone de défilement de l'inventaire : elle était au-dessus des lignes d'équipement et interceptait les clics.
- La zone de défilement reste interactive mais passe sous les lignes, afin que les boutons « Équiper », « Améliorer », « Fusionner » et « Démanteler » reçoivent correctement les touch/pointerdown.
- Aucun équipement, héros, ressource ou fonctionnalité existante supprimé.


## Module combat avancé — 25 septembre 2026

Ajout de mécaniques interactives directement dans `CombatEngine.js` et `CombatScene.js`, sans supprimer les mécaniques existantes :
- **Cible verrouillée** : toucher un ennemi pendant le combat force les attaques/compétences à privilégier cette cible tant qu’elle est vivante.
- **Combo d’équipe** : les impacts successifs des héros construisent un combo jusqu’à ×1,20 dégâts ; le combo retombe après 4 secondes sans impact joueur.
- **Jauge de rupture** : les compétences et ultimes font baisser la garde des ennemis. À 0, l’ennemi est brisé/étourdi et devient plus vulnérable pendant 3 secondes.
- **Réactions élémentaires** : brûlure + poison = Combustion, poison + saignement = Corrosion, ralentissement + étourdissement = Choc thermique.
- Affichage en combat : cible verrouillée, combo, jauges de rupture et effets de réaction.
- Aucun asset, héros, équipement, ressource ou système existant supprimé.

## Mods & plugins — 5 nouveaux mods + 1 gros mod (26 septembre 2026)

Ajout de 5 nouveaux fichiers dans `mods/`, déclarés dans `mods/manifest.js` (voir
`LISEZMOI_MODS.md` pour le tableau complet), tous additifs et désactivables
individuellement depuis Paramètres ⚙ → 🧩 Mods et plugins :
- `offres_boutique_plus.js` — 5 nouvelles offres dans le pool de la boutique quotidienne.
- `hud_ressources_taux.js` — barre de stock + production/minute des 5 ressources.
- `alerte_stockage_plein.js` — bandeau d'avertissement à chaque ressource pleine.
- `bouton_sauvegarde_rapide.js` — bouton flottant de sauvegarde manuelle immédiate.
- `arsenal_cosmique.js` (**gros mod**, désactivé par défaut) : 2 héros jouables
  (Nébulon, Voidram) et 3 objets d'équipement via `NEBUSTION.CustomContent`
  (même API que l'Atelier créateur), plus un panneau « ⚡ Booster » pour ajuster
  production/coûts via `NEBUSTION.CustomContent.GameConfig` (réversible en un clic).

Aucun fichier du jeu (`js/data/`, `js/systems/`, `js/scenes/`) n'a été modifié à part
`mods/manifest.js` (ajout d'entrées) et `LISEZMOI_MODS.md` (tableau mis à jour). Aucune
mécanique, ressource ou sauvegarde existante supprimée ou altérée.
Vérification syntaxique (`node --check`) : OK sur les 5 nouveaux fichiers et sur
`manifest.js`. Simulation Node (DOM minimal + faux ResourceManager/Shop, vrai
CustomContent.js) du cycle de vie complet des 5 mods — chargement/`init`, `onGameReady`,
deux `onTick`, clic simulé sur chaque bouton créé, émission de l'événement `'full'` — sans
erreur, et validation réussie des 2 héros / 3 objets par `NEBUSTION.CustomContent` (ids
préfixés `c_`/`ci_` comme attendu). Rendu visuel réel dans le jeu (positions à l'écran,
combat avec les nouveaux héros) non exécuté — à vérifier au premier chargement.
