# NEBUSTION — Ajout : Quartier Général (QG)

Nouveau bâtiment sur Nexus-01, à côté de Défense. Contrairement à Commandement/Hangar/Stockage/Extracteurs,
il n'apporte aucun bonus de production : il **débloque de nouveaux types d'expéditions** au fil de ses niveaux.

## Paliers de déblocage (`js/data/Expeditions.js`)

| Type d'expédition | Niveau de QG requis |
|---|---|
| Éclair | 1 (dès le départ) |
| Courte | 1 (dès le départ) |
| Longue | 3 |
| Épique | 6 |

Ces seuils sont dans `Expeditions.TYPES[id].unlockQG`, centralisés comme le reste de l'équilibrage.

## Ce qui a changé

- `js/data/Economy.js` : nouveau `BUILDINGS.qg` (coût de base cristaux/métal/noyaux), ajouté à `BUILDING_ORDER`
  (donc save/Renaissance le gèrent automatiquement, comme tout autre bâtiment). `effectText('qg', niveau)`
  annonce le prochain type d'expédition débloqué.
- `js/data/Expeditions.js` : `TYPES[id].unlockQG`, exposé dans `allMissions()` via `m.unlockQG`.
  `isUnlocked(m, totalStars, prestigeCount, qgLevel)` prend un 4e paramètre optionnel (défaut = niveau 1,
  donc les anciens appels à 3 arguments restent valides mais ne déverrouillent pas Longue/Épique).
- `js/systems/ExpeditionManager.js` : nouvelle fonction `qgLevel()` (lit `Resources.state.buildings.qg.level`),
  branchée dans `availableMissions`, `canLaunch` et `lockReason` (message : « Quartier Général niveau X requis »).
- `js/scenes/PlanetScene.js` : QG dessiné sur la plateforme (même style que les autres bâtiments), à côté
  de Défense — amélioration au tap comme d'habitude.
- `js/data/Skins.js` : QG ajouté à `BUILDING_TARGETS` (peut recevoir les skins de bâtiment existants).

## Tests

`tests/expeditions.test.js` : nouvelles vérifications sur `unlockQG`/`isUnlocked` avec le 4e paramètre,
et sur `qgLevel()`/`lockReason` côté `ExpeditionManager`. Le reste de la partie simulée met le QG au
niveau 10 en préambule pour ne pas changer le comportement des tests existants (Renaissance/étoiles).

`for f in tests/*.test.js; do node $f | tail -1; done` → tout passe (aucune régression sur les 22 fichiers de tests).

## Pistes pour la suite (pas fait ici)

- Un skin/texture propre au QG (actuellement même forme générique que les autres bâtiments, couleur verte).
- D'autres jalons pourraient dépendre du QG (zones de Galaxie, ennemis spéciaux…) en réutilisant le même champ.
