# NEBUSTION — Attaquer le QG des bots, traités comme des joueurs

Chaque empire ennemi est maintenant un **joueur adverse** : pseudo, grade, niveau, et un **vrai QG isométrique**
(mêmes structures que le tien : Générateurs 🔋, Silos 🛢️, Tourelles 🗼) que tu peux visiter puis attaquer.

## Comment jouer
1. Dans le QG, bouton **⚔ Attaquer** → liste des 5 commandants (Ferrox_Prime, K9_Sable, ElyraVeil, MorVak_Dread, Nyr_Ahsha)
   avec grade, niveau, développement, traumatisme et statut (Prêt / Recharge / Flotte vide).
2. **VISITER** ouvre son QG en 2.5D : défense, puissance de ta flotte, chance de victoire, nombre de tourelles/générateurs/silos.
   Tape une structure pour voir son rôle. Glisse pour inspecter la base.
3. **ATTAQUER** : ta flotte arrive, tire sur les tourelles, les tourelles ripostent, les structures explosent. Bannière VICTOIRE / REPOUSSÉ.

## Ce qui est réel (mécanique) et ce qui est mise en scène
- **Réel** : l'issue, le butin, la recharge de 3 h et le traumatisme de l'empire viennent de `QGAttackManager.attack()`
  (inchangé). Le QG du bot est déduit de l'état réel de l'empire (`evo`, `hurt`) : plus développé = plus de structures ;
  traumatisé par tes attaques = moins de tourelles à ta prochaine visite. Déterministe : même état → même QG.
- **Visuel seulement** : quelles structures sont touchées et détruites pendant l'animation. Les ruines n'existent que le
  temps de la visite ; ce qui persiste, c'est le traumatisme.

## Fichiers
- `js/data/BotBases.js` (nouveau, pur, testable Node) : profil « joueur », plan de structures, disposition du QG, mise en scène.
- `js/scenes/EnemyQGScene.js` (nouveau) : hérite du rendu iso de `QGScene` ; carte joueur, attaque animée.
- `js/scenes/QGScene.js` : panneau d'attaque → lignes « joueur » + bouton VISITER ; pseudo dans la bannière de raids ;
  géométrie iso partagée (`_initIsoGeometry`) ; correction : le bouton principal du panneau (DÉFRICHER/VENDRE) n'avait pas de texte
  (label vide → jamais créé).
- `index.html`, `js/main.js`, `sw.js` (cache `nebustion-v20-qg-bots`), `tests/progress-env.js`.

## Tests
- `node tests/botBases.test.js` → 274 vérifications.
- `python3 tests/browser-qgbots.py` (Chromium + faux Phaser) → 26 vérifications : tap iso, construction, panneau joueurs, visite,
  flotte vide, attaque animée jusqu'au bout, tourelles détruites, recharge, traumatisme, zéro erreur JS.
  (`tests/mock-phaser.js` enrichi : `fillPoints`, `strokePoints`, `generateTexture`, `Container.sort`, `Camera.flash`.)
- Suite existante : aucune régression. 2 échecs préexistants et sans rapport (`loaderGuard`, `skinManager`) présents aussi dans le zip d'origine.

## Limites
- Vérifié avec un faux Phaser (pas de Phaser réel ici) : le rendu et les animations sont à valider sur ton appareil.
- Un seul « joueur » par empire (5 adversaires). Pas de vrais joueurs en ligne.
