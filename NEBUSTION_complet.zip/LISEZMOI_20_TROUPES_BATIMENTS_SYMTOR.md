# NEBUSTION — Module 20 : troupes, bâtiments utiles, Symtor amélioré

## Nouvelles troupes (20 au total, achat en Boutique › Troupes)
Essaim 🐝 (volant, pille l'économie) · Artilleur 🔫 (longue portée, vise les tourelles) · Pyromane 🔥 (gros dégâts au contact) ·
Saboteur 🧨 (explosion large sur les barricades) · Canonnière 🛩️ (volante, vise les tourelles) · Dreadnought ☄️ (volant, 12 places, coûte 6 Noyaux) ·
Rejeton 🧬 (rapide ; couvé aussi gratuitement par le Symtor). Données : `js/data/Troops.js`. Dessins de combat : `QGBattleScene._drawTroop`.

## Nouveaux bâtiments du QG (9 structures, `js/data/QGGrid.js`)
| Bâtiment | Effet | Plafond |
|---|---|---|
| 🏕️ Caserne | +4 places d'armée chacune | 5 |
| 🔧 Atelier | −3 % prix des troupes chacun | 6 |
| 🧬 Bio-labo | +8 % XP du Symtor chacun | 5 |
| 📡 Radar | −6 % recharge des attaques de flotte chacun | 5 |
| ⚗️ Raffinerie | +5 % de butin chacune | 5 |

Branchements : `TroopManager` (capacité, remise ; la Boutique affiche et débite le prix remisé), `QGAttackManager` (recharge, butin),
`SymbioteManager.feed` (XP). Le panneau de construction passe à 5 colonnes × 2 rangées.

## Symtor
- Stades : Larve · Juvénile · Prédateur · Alpha · Ancien · Primordial.
- Bonus permanent de production de la base : +0,2 %/niveau (max +10 %).
- **Sécrétion** : ressources accumulées (8 h max), bouton COLLECTER.
- **Couvée** : dès le niv. 3, toutes les 6 h, 1 à 6 Rejetons offerts (ignore la capacité d'armée).
- Nourrissage ×1 / ×5 / ×10. Récompenses de combat ×(1 + 3 %/niveau).
- Anciennes sauvegardes : les horloges démarrent à la première ouverture (aucun gain rétroactif).

## Tests
`node tests/module20.test.js` (83 vérifications) · `python3 tests/browser-module20.py` (40, Chromium + faux Phaser).
Non testé avec le vrai Phaser : à valider sur appareil (dessins, panneau à 2 rangées, équilibrage).
Cache PWA : `nebustion-v26-module20`.
