# NEBUSTION — Mode Atelier (compte Admin)

## Ce que ça fait
Un raccourci local permet d'accéder rapidement aux outils de création (Atelier de cartes, Studio,
Import) directement depuis le jeu, sans avoir à retrouver les fichiers dans `tools/`.

## Comment l'activer
1. Ouvre le jeu, touche l'icône **⚙** (Paramètres, en haut à gauche) → **Compte**.
2. Touche **Se connecter**.
3. Dans le champ e-mail, saisis **Admin**. Dans le champ mot de passe, saisis **Admin**.
4. Touche **Se connecter**.

→ Un message confirme « Mode Atelier déverrouillé ». Aucune vraie tentative de connexion Firebase
n'est faite : ce couple d'identifiants est reconnu localement et n'importe quelle casse fonctionne
(`Admin`, `admin`, `ADMIN`...).

## Où le retrouver ensuite
Une fois déverrouillé, une nouvelle ligne **🛠 Mode Atelier** apparaît dans le menu **⚙ Paramètres**
(sous « Compte »), sur tous les écrans du jeu. Elle ouvre un écran listant :
- **🃏 Atelier de cartes** (`tools/atelier_cartes.html`)
- **🧪 Studio** — héros, ennemis, équipement, équilibrage (`tools/studio.html`)
- **📥 Import de contenu** — intégrer les fichiers créés (`tools/import.html`)

Chaque outil s'ouvre dans un nouvel onglet du navigateur (aucune modification des outils eux-mêmes :
ce sont les mêmes pages HTML autonomes qu'avant, voir `LISEZMOI_ATELIER_CARTES.md`).

## Désactiver
Depuis l'écran **Mode Atelier**, bouton **Désactiver le mode Atelier**. La ligne disparaît alors du
menu ⚙ jusqu'à la prochaine connexion avec Admin/Admin.

## Détails techniques
- Le déverrouillage est **local à l'appareil** (`localStorage`), pas lié à un compte Firebase : il
  ne se synchronise pas entre appareils et ne fait partie d'aucune sauvegarde de partie.
- Fichiers ajoutés : `js/data/AdminMode.js` (logique), `js/scenes/AtelierScene.js` (écran).
- Fichiers modifiés : `js/scenes/AccountScene.js` (raccourci de connexion), `js/ui/SettingsMenu.js`
  (ligne de menu conditionnelle), `js/main.js` + `index.html` (enregistrement), `sw.js` (cache PWA).
- **Ce n'est pas un système de sécurité** : les identifiants sont écrits en clair dans le code source
  du jeu et visibles par quiconque l'inspecte. Ça ne protège aucune donnée sensible — c'est juste un
  raccourci pratique pour accéder aux outils de création, pas un vrai compte administrateur.
- Test : `node tests/adminMode.test.js` (14 vérifications, sans Phaser).
