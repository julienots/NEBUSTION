# NEBUSTION — Module « Codex » (journal narratif)

## Pourquoi

Le jeu contenait déjà tout le matériau d'un grand méchant cohérent (VORATH/NEXUS PRIME/
OMEGA-KRELL commentés comme des « Hérauts » dans `Enemies.js`, une jauge de corruption
galactique dans `Nebustion.js`) mais rien ne le racontait au joueur, et rien ne reliait les
autres systèmes (Événements, Expéditions, raids de QG, Renaissance, Symtor) à cette même
menace. Ce module n'ajoute aucune nouvelle formule de jeu : il donne un sens à ce qui existe
déjà, sous forme d'un journal débloqué par la vraie progression.

## Ce qui a été ajouté

- **`js/data/Codex.js`** — 12 entrées de récit (Prologue → Acte IV) + 5 entrées « Connexions »,
  pur JS testable sous Node, aucune dépendance à Phaser (comme `Nebustion.js`/`Economy.js`).
  → `node tests/codex.test.js` : **18/18 réussis**.
- **`js/systems/CodexManager.js`** — lit l'état réel (`NEBUSTION.Combat.stageStars`,
  `NEBUSTION.Resources.state.nebustion`, `.state.prestige.count`) pour savoir quelles entrées
  sont débloquées. Lecture seule : **aucune écriture** dans la sauvegarde principale. Le suivi
  des entrées déjà lues (pastille « nouveau ») vit dans une clé localStorage séparée
  (`nebustion_codex_seen_v1`) : la perdre ne fait réapparaître que des pastilles, jamais de
  perte de progression.
- **`js/scenes/CodexScene.js`** (NOUVEAU) — 6ᵉ onglet de la barre de navigation (après
  Nebustion) : onglet **Récit** (chronologie verrouillée/déverrouillée, mesure la hauteur du
  texte pour dimensionner chaque carte) et onglet **Connexions** (toujours visible, explique
  pourquoi Événements/Expéditions/QG/Renaissance/Symtor existent).
- **`index.html`** / **`sw.js`** (`v36` → `v37`) — les 3 fichiers ajoutés à `GAME_SCRIPTS`/`CORE`.
- **`js/main.js`** — `CodexScene` enregistrée auprès de Phaser.
- **`js/scenes/ProgressScene.js`** — entrée `codex` dans `NEBUSTION.PROGRESS_HUB` +
  pastille rouge dans `progressBadges()` (nombre d'entrées débloquées jamais consultées).

## Le fil narratif (résumé)

VORATH, NEXUS PRIME et OMEGA-KRELL ne sont pas trois boss séparés mais trois avatars d'une
seule corruption cosmique, NEBUSTION, dont la jauge (déjà existante) monte en fond depuis le
début. Découverte clé, déjà réelle dans `PrestigeManager.perform()` : une Renaissance
réinitialise le combat, les bâtiments et la galaxie — **mais jamais la jauge de corruption**,
ni le Sanctuaire, ni l'Éclat Souillé. Le Codex rend ça explicite : une Renaissance n'est pas
une victoire, c'est un sursis. Les Événements deviennent des avant-signes envoyés en
éclaireurs, les Expéditions des reconnaissances, les raids d'empires rivaux la même pression
subie ailleurs, et le Symtor un compagnon d'origine inconnue donc sensible à la corruption.

## Non fait / pistes pour la suite

- Aucune entrée n'est encore liée à Symbiote/Troops/Ships/QGBattle en détail — le Codex reste
  volontairement au niveau « pourquoi », pas « comment », pour rester lisible en une session.
- Pas de test dans un vrai navigateur (Phaser) : seule la logique pure (Node) est vérifiée,
  comme pour le module Nebustion à l'étape 28. La suite `tests/*.test.js` complète a été
  relancée avant/après (aucune régression ; `background.test.js`/`combat.test.js` varient
  légèrement d'une exécution à l'autre — non déterministes, déjà le cas avant ce module).
