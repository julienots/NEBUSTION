# Cartes 24–31 — ajout au roster

Ajout des 8 héros/cartes : Necravion, Symbioroth, Aqualith, Umbrielle, Terraxis, Stellaris, Virulom et Zentihar.

- Achetables dans la Boutique avec Prismes + Jetons Xon.
- Raretés et libellés affichés comme sur la planche fournie : Divin, Mythique, Légendaire, Épique, Rare Suprême.
- Illustrations issues de la planche fournie, converties en portraits 300x380.
- Compétences, statistiques et kits de combat dédiés.
- Après achat, les héros rejoignent la collection et peuvent être placés dans l’équipe et combattre.
- Aucun fichier, héros, équipement, ressource ou fonctionnalité existante n’a été supprimé.
