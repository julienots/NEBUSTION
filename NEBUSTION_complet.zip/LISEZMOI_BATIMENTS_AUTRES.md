# NEBUSTION — 5 bâtiments de Nexus-01 SANS rapport avec les ressources

| Bâtiment | Effet (par exemplaire) | Max | Coût de base |
|---|---|---|---|
| 🛡️ Générateur de bouclier | +1 niveau de sécurité du QG (raids) | 3 | 400 cristaux + 300 énergie |
| ⚔️ Académie de guerre | +2 % PV / attaque / défense des héros (combat + expéditions) | 4 (+8 %) | 300 métal + 200 cristaux |
| 🚀 Spatioport | −8 % de durée des expéditions (plafond −60 %, Éclair inchangé) | 3 (−24 %) | 350 métal + 250 énergie |
| ⚒️ Forge d'éclats | +15 % d'Éclats stellaires par ouverture de caisse | 3 (+45 %) | 250 métal + 300 poussière |
| 🎓 Centre de formation | +10 % d'XP de Pass de saison | 3 (+30 %) | 300 cristaux + 250 poussière |

Branchements : `SecurityManager.effectiveLevel`, `CombatManager.combinedBonus`, `ExpeditionManager` (`effectiveDuration`, `heroPower`; la durée réduite s'affiche sur les cartes de mission),
`CrateManager.open`, `PassManager.addXp`. Dessins animés dans `PlanetBuildUI.js`. Catalogue : 19 bâtiments (5 rangées), limite totale 30 → 42.
Tests : `node tests/buildings-other.test.js` (22 vérifications).
