# NEBUSTION — Nexus-01 : vraie planète 3D rotative

Nexus-01 n'est plus une plateforme plate en fausse perspective : c'est maintenant une sphère
que le joueur peut tourner du doigt, avec les bâtiments et gisements répartis dessus, sur les
côtés et sous la planète (révélés en tournant).

## Fichiers modifiés
- `js/scenes/PlanetScene.js`
- `js/entities/ResourceNode.js`

## Comment ça marche
- Chaque bâtiment/gisement a une position fixe **longitude/latitude** à la surface de la sphère
  (tableaux `buildings` dans `_buildBuildings()`, `spots` dans `_buildNodes()`).
- `_projectSphere(lonDeg, latDeg)` projette ce point à l'écran selon la rotation courante
  (`_rotYaw` / `_rotPitch`) : projection orthographique (pas de point de fuite), avec échelle et
  opacité qui diminuent vers l'arrière du globe, et une profondeur d'affichage pour que l'avant
  passe devant l'arrière (et devant le corps de la sphère lui-même, qui est à profondeur 0).
- `_applySphereTransform()` (appelée chaque frame) repositionne tous les bâtiments/gisements et
  **coupe le tap** (`hit.input.enabled = false`) sur tout ce qui est caché derrière le globe —
  sans ça, on pourrait toucher un bâtiment invisible à travers la sphère.
- `_redrawSphereBody()` redessine chaque frame le disque de la planète, ses cratères (fixes à la
  surface, donc ils tournent eux aussi — c'est ce qui rend la rotation lisible même loin d'un
  bâtiment) et sa grille latitude/longitude.
- `_setupPlanetDrag()` : glisser n'importe où sur l'écran fait tourner la planète (seuil de 20px
  avant que ça déclenche, pour ne jamais gêner un tap sur un bâtiment), avec un peu d'inertie à
  la relâche et une lente rotation automatique après 2,2 s d'inactivité.

## Si le sens du glissé semble inversé
Dans `_setupPlanetDrag()`, inverser le signe de `dx * sens` (yaw) et/ou `dy * sens` (pitch) —
une seule ligne à changer, pas besoin de toucher au reste.

## Pour changer la disposition des bâtiments
Modifier directement `lonDeg` / `latDeg` dans les tableaux `buildings` (dans `_buildBuildings()`)
et `spots` (dans `_buildNodes()`) : longitude 0° = face à la caméra au départ, latitude 90° = pôle
haut, -90° = pôle bas.

## Ce qui n'a pas changé
- Les caisses de ravitaillement (`_spawnPod`) et l'en-tête restent à des positions fixes à
  l'écran : ce ne sont pas des éléments posés sur la planète.
- Toute la logique économique (récolte, améliorations, drones) est inchangée ; seule la
  *position à l'écran* des bâtiments/gisements est désormais pilotée par la sphère.
- Les tweens de survol/appui/rebond (bâtiments) et de secousse "stockage plein" (gisements) ont
  été redirigés vers un petit décalage `_deco` (dx/dy/ds) appliqué PAR-DESSUS la position imposée
  chaque frame par la sphère, pour ne jamais entrer en conflit avec elle.
