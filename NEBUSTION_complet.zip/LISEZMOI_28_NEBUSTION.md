# NEBUSTION — Module « grand méchant » (étape 28)

Suite directe de `NEBUSTION_recap_a_faire.md` : ce zip contient tout ce qui manquait
(`NebustionScene.js`, câblage `index.html`/`main.js`/`ProgressScene.js`, tests, service worker).

## ✅ Fait et testé

- **`js/data/Nebustion.js`** — jauge de corruption (0-100 %), vitesse ralentie par le Sanctuaire,
  formules de coût/décroissance du Sanctuaire, dilemme du Symtor (résonance).
  → `node tests/nebustion.test.js` : **45/45 réussis**.
- **`js/systems/NebustionManager.js`** — glue sauvegarde/déblocage/combat.
- **`js/data/Enemies.js`** — 3 avant-postes + boss `NEBUSTION, l'Éveil Primordial` (déjà présents dans
  le zip fourni, non retouchés ici).
- **`js/systems/CombatManager.js` / `SaveManager.js`** — inchangés dans cette session (déjà faits).
- **`js/scenes/NebustionScene.js`** (NOUVEAU) — écran à 3 onglets :
  - *Sanctuaire* : jauge (barre + %/h), achat/amélioration, activation manuelle (avec cooldown en direct).
  - *Avant-postes* : les 3 stages + accès au boss, verrouillage séquentiel, lien direct vers
    `CombatPrepScene` (équipe/difficulté déjà gérées par cet écran existant).
  - *Symtor* : jauge de Résonance, bouton « Nourrir » (coûte de l'Éclat Souillé), statut corrompu/sain.
  - Écran « verrouillé » tant qu'OMEGA-KRELL n'est pas vaincu, avec bouton direct vers ce combat.
- **`index.html`** — les 3 fichiers ajoutés à `GAME_SCRIPTS`, dans l'ordre (`Nebustion.js` après
  `Enemies.js`, `NebustionManager.js` après `CombatManager.js`, `NebustionScene.js` après
  `AchievementsScene.js`).
- **`js/main.js`** — `NebustionScene` enregistrée auprès de Phaser ; `NebustionManager.tick()` appelé
  toutes les ~5 s dans la boucle principale (comme `GalaxyManager.update`), donc la jauge avance même
  hors de l'écran Nebustion.
- **`js/scenes/ProgressScene.js`** — 5ᵉ entrée `nebustion` ajoutée à `NEBUSTION.PROGRESS_HUB` (barre de
  navigation Expéditions/Événement/Prestige/Succès/**Nebustion**) + pastille rouge dans
  `progressBadges()` quand le Sanctuaire est activable.
- **`sw.js`** — version de cache montée (`v31` → `v32`) et les 3 nouveaux fichiers ajoutés à la liste
  `CORE`, sinon le jeu hors ligne aurait chargé une version sans le module.
- **`tests/nebustion.test.js`** (NOUVEAU) — formules pures (jauge, Sanctuaire, avant-postes, dilemme)
  + intégration via `NebustionManager` (déblocage, achat, activation, récompenses de combat,
  nourrissage du Symtor). `tests/progress-env.js` mis à jour pour charger les 2 nouveaux fichiers.

## ⚠️ Non testé / pas fait dans cette session

- **Pas de test dans un vrai navigateur** (Phaser) : seule la logique pure (Node) est vérifiée.
  L'écran `NebustionScene` n'a donc pas été *visuellement* vérifié — il suit fidèlement le patron de
  `PrestigeScene`/`EventScene` (même classe de base `ProgressScene`), mais une capture d'écran réelle
  n'a pas été prise.
- **Purification du Symtor** (`NebustionManager.purifySymtor()`) : la fonction existe et est testée,
  mais **aucune action de jeu ne l'appelle** — l'onglet Symtor l'explique honnêtement (« objet rare de
  fin de jeu, pas encore disponible ») plutôt que d'inventer un bouton sans contenu derrière.
- **Variante visuelle du Symtor corrompu** dans `SymbioteScene.js` : toujours pas faite (simplification
  déjà assumée dans le récap de départ) — seul l'onglet Nebustion affiche le statut.

## 🐞 Anomalies préexistantes repérées (non liées à ce module, non corrigées ici)

En relançant l'ensemble de la suite de tests (`tests/*.test.js`), 4 échecs préexistants ont été
repérés, sans rapport avec le travail de cette session (aucun ne touche `data/Nebustion.js`,
`systems/NebustionManager.js` ni `progress-env.js`) :
- `tests/enemies.test.js` — « exactement 3 stages de boss (4) » : attendu, puisque `boss_nebustion`
  est un 4ᵉ boss (déjà ajouté avant cette session) ; le test lui-même n'a pas été mis à jour.
- `tests/galaxy.test.js` — « lecture des stages du module Combat » : même cause probable.
- `tests/skinManager.test.js` — « version de sauvegarde = 7 » : le format de sauvegarde a changé
  (module `nebustion` ajouté) sans que ce test soit mis à jour.
- `tests/loaderGuard.test.js` — dimensions de l'illustration `outsiderz` : sans rapport avec Nebustion.

Je n'ai pas touché à ces 4 tests ni aux fichiers concernés : à vérifier si vous voulez les corriger
(mettre à jour leurs attentes) dans une prochaine session.

## Pour tester

```
node tests/nebustion.test.js
```

En jeu : terminer le stage `OMEGA-KRELL` débloque l'entrée « Nebustion » dans la barre de navigation
(bas des écrans Expéditions/Événement/Prestige/Succès).
