# NEBUSTION - Trou noir (carte Univers)

- Ajoutés : js/utils/BlackHoleTextures.js (textures procédurales du trou noir), js/scenes/BlackHoleScene.js (gros plan + exploration)
- Modifiés : js/scenes/UniverseScene.js (nœud « Trou Noir » sur la carte), js/main.js (scène enregistrée), index.html (2 scripts ajoutés au chargeur), sw.js (cache v35)

## Ce qui a été ajouté
- Sur l'écran UNIVERS (là où on voit toutes les galaxies), un nœud « Trou Noir » discret et
  toujours accessible (pas de condition de déblocage), à l'écart des galaxies existantes.
- Toucher le trou noir déclenche le même geste que pour une galaxie (grossissement sur place)
  puis ouvre BlackHoleScene : un gros plan très détaillé (disque d'accrétion incliné, anneau de
  photons, jets polaires, traînées de matière en chute, asymétrie Doppler — un côté brillant/blanc,
  l'autre sombre/rouge — et des arcs de lumière repliés au-dessus/au-dessous de l'horizon pour
  simuler la lentille gravitationnelle, façon « Interstellar »).
- Bouton PLONGER (ou toucher directement le trou noir) : effet de tunnel de lumière (traits
  radiaux qui filent vers le joueur), puis on arrive « de l'autre côté » dans une poche
  dimensionnelle (nébuleuse étrange, teintes inversées) avec un texte narratif tiré au sort et une
  relique qui offre une petite récompense (Cristaux/Énergie/Poussière, rarement 1 Noyau), limitée à
  une fois toutes les ~20h (indépendant de la sauvegarde de partie, stocké en localStorage sous
  `nebustion_blackhole_last`). Bouton REMONTER pour revenir (même effet de tunnel), puis retour au
  gros plan, puis à la carte Univers.

## Pourquoi ainsi
- Réutilise l'architecture existante (SceneBackground, HUD, FX, Button, BottomNav) et le style
  visuel « Canvas 2D procédural » déjà utilisé par GalaxyBackdrop/GalaxyTextures, sans toucher aux
  fichiers de jeu existants au-delà des 3 petites intégrations listées ci-dessus.
- La récompense est volontairement modeste et plafonnée dans le temps : c'est une curiosité à
  explorer, pas un nouveau circuit d'économie.

## Fichiers du ZIP
Uniquement les fichiers ajoutés/modifiés : js/utils/BlackHoleTextures.js, js/scenes/BlackHoleScene.js,
js/scenes/UniverseScene.js, js/main.js, index.html, sw.js, ce fichier.
