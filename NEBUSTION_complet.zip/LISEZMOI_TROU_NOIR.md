# Le Trou Noir — exploration à profondeurs (mise à jour du 2026-09-27)

> **2026-09-30 :** le rendu visuel décrit plus bas (« Ce qui n'a PAS changé ») a été remplacé par un rendu 3D en direct,
> orbitable, avec arrivée en vol — voir `LISEZMOI_TROU_NOIR_3D.md`. L'exploration, le Comptoir et les épreuves sont inchangés.

> Cette version REMPLACE la précédente : le Trou Noir n'est plus une simple curiosité visuelle
> avec un bonus occasionnel. C'est maintenant une vraie zone d'exploration, avec ses propres
> ressources, sa propre progression permanente et son propre risque/récompense.

## Où c'est

Carte Univers → nœud « Trou Noir » (toujours visible, jamais verrouillé) → `BlackHoleScene`.

## Mise à jour 2026-09-28 — de vraies épreuves à piloter (plus seulement du texte)

Choisir une trajectoire ne révèle plus un résultat : la rencontre devient une **épreuve temps réel** que
le joueur pilote au doigt (`js/scenes/BlackHoleRunScene.js`, nouvelle scène affichée par-dessus
`BlackHoleScene`, qui est mise en pause pendant l'épreuve). Glisser n'importe où : la sonde se place
110 px au-dessus du doigt. Les objets tombent en spirale vers l'horizon (trajectoires courbes).

| Rencontre | Épreuve | Ce qui compte |
| --- | --- | --- |
| Cache de ressources | **Récolte** (12 s) : attraper 14 orbes de la ressource concernée, éviter les débris | % récolté = gain (de ×0,35 à ×1,45 de l'ancien gain moyen) |
| Relique de l'Abîme | **Récolte** de cristaux de Singularité | % capté = Fragments |
| Choc de marée | **Esquive** (10 s) : pluie de débris + vagues à brèche signalées 1 s avant | 0 impact = bonus de Fragments ; chaque impact coûte de l'Intégrité |
| Écho hostile | **Combat** (20 s) : la sonde tire seule, on s'aligne sous l'ennemi (vrai sprite) et on esquive ses tirs | victoire = butin complet ; échec = butin partiel selon les dégâts infligés |
| Seuil de la Singularité | **Combat de boss** (28 s) : 4 boss existants (Vorath, Nexus Prime, Omega Krell, Nebustion Primordiale), salves en éventail + anneaux de tirs | idem, récompenses ×2,2 |
| Point d'ancrage, accalmie | inchangés : repos instantané | — |

**La puissance d'équipe compte toujours** : elle fixe les dégâts de la sonde (×0,4 à ×2,2). À la puissance
recommandée (×1) la victoire demande un tir correct ; à ×0,5 elle est très difficile même en jouant bien ;
à ×2 elle est confortable. L'adresse compense en partie, sans jamais remplacer les héros.

**Intégrité** : chaque impact retire `hitDamage(profondeur)` (5 en profondeur 1, ~19 en profondeur 25),
0,9 s d'invulnérabilité après un impact. Le total subi = perte d'Intégrité de la rencontre. Sonde détruite
(Intégrité à 0) = fin de plongée forcée, comme avant, gains déjà crédités conservés.

**Architecture (aucune sauvegarde modifiée)** : l'arène ne touche à aucun état. Elle renvoie une
performance `{score, win, damage, resId, summary}` ; `BlackHoleScene` la transmet à
`BlackHoleManager.chooseNode(idx, now, perf)` qui applique tout **en une fois** (atomique), exactement
comme avant. Sans `perf`, `chooseNode` garde l'ancienne résolution automatique (le résultat est
strictement identique à l'ancienne version, vérifié par test). Nouveautés pures dans `BlackHole.js` :
`previewKind`, `modeOf`, `arenaParams`, `hitDamage` et la branche `perf` de `resolveChoice`.
Fermer le jeu en pleine épreuve ne consomme rien : la plongée reprend au même palier.

Fichiers modifiés : `js/data/BlackHole.js`, `js/systems/BlackHoleManager.js`, `js/scenes/BlackHoleScene.js`,
`js/main.js` (enregistrement de la scène), `index.html`, `sw.js` (cache `v45`). Nouveau :
`js/scenes/BlackHoleRunScene.js`, `tests/blackhole_arena.test.js` (26 vérifications + non-régression),
`tests/blackhole-arena-smoke.js` (19 vérifications, faux Phaser, bots qui jouent les 3 épreuves).

Pistes suivantes : un mini-jeu « repos » pour le point d'ancrage, l'appui des héros de l'équipe en
tirs de soutien dans l'arène, un pouvoir de sonde à débloquer au Comptoir (bouclier, aimant à orbes).

---

## Fichiers

- `js/data/BlackHole.js` — données et formules **pures** (zones, rencontres, RNG déterministe,
  puissance requise, améliorations, offres du Comptoir). Aucune dépendance à Phaser, testable
  sous Node comme `Economy.js`/`Expeditions.js`.
- `js/systems/BlackHoleManager.js` — état, sauvegarde, cycle de plongée (glue avec
  `NEBUSTION.Resources`, `NEBUSTION.Combat`/`ExpeditionManager` pour la puissance d'équipe,
  `NEBUSTION.ShopManager` pour les Prismes).
- `js/scenes/BlackHoleScene.js` — tout l'affichage : gros plan animé, tunnel de plongée,
  écran d'exploration, Comptoir de l'Abîme.
- `js/systems/SaveManager.js` — module `blackhole` ajouté à la sauvegarde (v9), rétrocompatible.
- `js/data/Codex.js` / `js/systems/CodexManager.js` — 2 entrées de récit liées à la profondeur
  atteinte (`blackHoleMaxDepth`), qui relient le Trou Noir à la trame NEBUSTION.
- `tests/blackhole.test.js` — 73 vérifications Node (formules, déterminisme, manager, sauvegarde).
- `tests/blackhole-smoke.js` — test de fumée navigateur (Chromium + faux Phaser) : plongée,
  résolution de nœuds, remontée, Comptoir, persistance après rechargement.

## Comment ça marche, en jeu

**Plonger.** Le bouton PLONGER (ou toucher le trou noir) consomme 1 charge parmi 3 (rechargent
seules avec le temps réel, comme une jauge d'expédition). Une plongée déjà en cours se **reprend**
sans consommer de charge — fermer le jeu au milieu d'une descente ne perd rien.

**Explorer.** À chaque profondeur, 2-3 trajectoires sont proposées, chacune annotée d'un simple
niveau de danger (🟢 stable / 🟠 trouble / 🔴 chaotique) — le type exact de la rencontre n'est
révélé qu'au moment du choix : cache de ressources, relique (Fragments de Singularité), écho
hostile (dépend de la puissance de l'équipe de Combat actuelle), accalmie ou choc de marée
(Intégrité de la sonde), point d'ancrage (restaure l'Intégrité). Tous les 5 paliers, un **Seuil**
est forcé parmi les options : une rencontre plus dure, avec de meilleures récompenses.

**Le risque : l'Intégrité, pas la perte.** Tout ce qui est gagné est crédité immédiatement — remonter
à tout moment ne coûte jamais rien de déjà acquis. Seule l'Intégrité limite la descente : à 0, la
plongée se termine automatiquement (retour forcé), sans pénalité au-delà de la fin de l'exploration.
Remonter juste après un point d'ancrage accorde un petit bonus de Fragments.

**Les zones.** 6 zones thématiques aux couleurs et récompenses croissantes : Horizon des Événements
(1-4), Anneau de Feu (5-9), Marée Gravitationnelle (10-14), Spaghettification (15-19), Le Noyau
(20-24), La Singularité (25+, sans limite — pour les équipes très puissantes). Les récompenses en
ressources sont calées sur la production **actuelle** du joueur (jamais dérisoires en fin de partie).

**Le Comptoir de l'Abîme.** Accessible depuis le gros plan, il permet de dépenser les Fragments de
Singularité en :
- **Échanges** : ressources ciblées (Cristaux, Métal, Énergie, Poussière, Noyaux) ou Prismes
  (limité à 3/jour, pour protéger l'économie de la Boutique) ;
- **Améliorations permanentes de la sonde** (5 niveaux chacune) : Coque renforcée (+Intégrité max),
  Résonance productive (+ressources/Fragments gagnés), Détecteur amélioré (favorise les trouvailles).

**Progression permanente.** La profondeur record est conservée, affichée sur l'écran principal, et
débloque 2 entrées du Codex qui relient le Trou Noir à NEBUSTION (rien de spoilé ici — à découvrir
en jeu).

## Ce qui n'a PAS changé

- Le rendu visuel du gros plan (disque d'accrétion, jets polaires, anneau de photons — voir
  `js/utils/BlackHoleTextures.js`) et le tunnel de plongée : inchangés.
- Aucune ressource, sauvegarde ou système existant n'a été modifié en dehors des ajouts ci-dessus ;
  une sauvegarde antérieure à cette mise à jour se voit simplement attribuer le module `blackhole`
  par défaut (0 Fragment, aucune plongée en cours), sans rien perdre d'autre.

## Pistes d'extension (non faites, pour une prochaine session)

- Accrocher un petit bonus de production passif à la profondeur record (actuellement, la profondeur
  record n'a d'effet que cosmétique + Codex, volontairement, pour ne pas toucher aux formules de
  production existantes sans une revue dédiée).
- Objectifs quotidiens/succès dédiés au Trou Noir (le module `Achievements.js` existant pourrait
  lire `state.blackhole` de la même façon que `CodexManager` le fait déjà).
- (Fait le 2026-09-28) Les échos hostiles sont désormais de vrais combats avec les sprites d'ennemis du jeu.
