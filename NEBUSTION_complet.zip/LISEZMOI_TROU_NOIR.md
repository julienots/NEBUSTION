# Le Trou Noir — exploration à profondeurs (mise à jour du 2026-09-27)

> Cette version REMPLACE la précédente : le Trou Noir n'est plus une simple curiosité visuelle
> avec un bonus occasionnel. C'est maintenant une vraie zone d'exploration, avec ses propres
> ressources, sa propre progression permanente et son propre risque/récompense.

## Où c'est

Carte Univers → nœud « Trou Noir » (toujours visible, jamais verrouillé) → `BlackHoleScene`.

## Fichiers

- `js/data/BlackHole.js` — données et formules **pures** (zones, rencontres, RNG déterministe,
  puissance requise, améliorations, offres du Comptoir). Aucune dépendance à Phaser, testable
  sous Node comme `Economy.js`/`Expeditions.js`.
- `js/systems/BlackHoleManager.js` — état, sauvegarde, cycle de plongée (glue avec
  `NEBUSTION.Resources`, `NEBUSTION.Combat`/`ExpeditionManager` pour la puissance d'équipe,
  `NEBUSTION.ShopManager` pour les Prismes).
- `js/scenes/BlackHoleScene.js` — tout l'affichage : gros plan animé, tunnel de plongée,
  écran d'exploration, Comptoir de l'Abîme.
- `js/systems/SaveManager.js` — module `blackhole` ajouté à la sauvegarde (v9), rétrocompatible.
- `js/data/Codex.js` / `js/systems/CodexManager.js` — 2 entrées de récit liées à la profondeur
  atteinte (`blackHoleMaxDepth`), qui relient le Trou Noir à la trame NEBUSTION.
- `tests/blackhole.test.js` — 73 vérifications Node (formules, déterminisme, manager, sauvegarde).
- `tests/blackhole-smoke.js` — test de fumée navigateur (Chromium + faux Phaser) : plongée,
  résolution de nœuds, remontée, Comptoir, persistance après rechargement.

## Comment ça marche, en jeu

**Plonger.** Le bouton PLONGER (ou toucher le trou noir) consomme 1 charge parmi 3 (rechargent
seules avec le temps réel, comme une jauge d'expédition). Une plongée déjà en cours se **reprend**
sans consommer de charge — fermer le jeu au milieu d'une descente ne perd rien.

**Explorer.** À chaque profondeur, 2-3 trajectoires sont proposées, chacune annotée d'un simple
niveau de danger (🟢 stable / 🟠 trouble / 🔴 chaotique) — le type exact de la rencontre n'est
révélé qu'au moment du choix : cache de ressources, relique (Fragments de Singularité), écho
hostile (dépend de la puissance de l'équipe de Combat actuelle), accalmie ou choc de marée
(Intégrité de la sonde), point d'ancrage (restaure l'Intégrité). Tous les 5 paliers, un **Seuil**
est forcé parmi les options : une rencontre plus dure, avec de meilleures récompenses.

**Le risque : l'Intégrité, pas la perte.** Tout ce qui est gagné est crédité immédiatement — remonter
à tout moment ne coûte jamais rien de déjà acquis. Seule l'Intégrité limite la descente : à 0, la
plongée se termine automatiquement (retour forcé), sans pénalité au-delà de la fin de l'exploration.
Remonter juste après un point d'ancrage accorde un petit bonus de Fragments.

**Les zones.** 6 zones thématiques aux couleurs et récompenses croissantes : Horizon des Événements
(1-4), Anneau de Feu (5-9), Marée Gravitationnelle (10-14), Spaghettification (15-19), Le Noyau
(20-24), La Singularité (25+, sans limite — pour les équipes très puissantes). Les récompenses en
ressources sont calées sur la production **actuelle** du joueur (jamais dérisoires en fin de partie).

**Le Comptoir de l'Abîme.** Accessible depuis le gros plan, il permet de dépenser les Fragments de
Singularité en :
- **Échanges** : ressources ciblées (Cristaux, Métal, Énergie, Poussière, Noyaux) ou Prismes
  (limité à 3/jour, pour protéger l'économie de la Boutique) ;
- **Améliorations permanentes de la sonde** (5 niveaux chacune) : Coque renforcée (+Intégrité max),
  Résonance productive (+ressources/Fragments gagnés), Détecteur amélioré (favorise les trouvailles).

**Progression permanente.** La profondeur record est conservée, affichée sur l'écran principal, et
débloque 2 entrées du Codex qui relient le Trou Noir à NEBUSTION (rien de spoilé ici — à découvrir
en jeu).

## Ce qui n'a PAS changé

- Le rendu visuel du gros plan (disque d'accrétion, jets polaires, anneau de photons — voir
  `js/utils/BlackHoleTextures.js`) et le tunnel de plongée : inchangés.
- Aucune ressource, sauvegarde ou système existant n'a été modifié en dehors des ajouts ci-dessus ;
  une sauvegarde antérieure à cette mise à jour se voit simplement attribuer le module `blackhole`
  par défaut (0 Fragment, aucune plongée en cours), sans rien perdre d'autre.

## Pistes d'extension (non faites, pour une prochaine session)

- Accrocher un petit bonus de production passif à la profondeur record (actuellement, la profondeur
  record n'a d'effet que cosmétique + Codex, volontairement, pour ne pas toucher aux formules de
  production existantes sans une revue dédiée).
- Objectifs quotidiens/succès dédiés au Trou Noir (le module `Achievements.js` existant pourrait
  lire `state.blackhole` de la même façon que `CodexManager` le fait déjà).
- Un « bestiaire » d'échos hostiles avec de vrais sprites, plutôt que des rencontres purement
  textuelles.
