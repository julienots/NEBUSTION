# NEBUSTION - Planète : bâtiments 3D
- Modifié : js/scenes/PlanetScene.js (_drawBuilding -> _drawIsoBuilding, helpers _shade/_mixColor ; balise et badge placés selon b.topY)
- QG (3 étages + mât), Commandement (tour + radar rotatif), Laboratoire (dôme vitré + noyau pulsant), Hangar (porte à chevrons), Défense (bunker + tourelle jumelée)
- Volumes isométriques 3 faces, fenêtres en perspective, arêtes néon, dalle lumineuse, ombre portée, halo.
- Symtor, Ravitailleur, gisements, zones tactiles, améliorations et sauvegardes inchangés.
