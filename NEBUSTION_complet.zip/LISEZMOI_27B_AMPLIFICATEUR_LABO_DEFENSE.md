## Module 27B — Amplificateur, effets Labo/Défense, plateforme agrandie

- **Nouveau bâtiment : Amplificateur quantique** (`amplifier`). Placé sur Nexus-01 en miroir du
  Ravitailleur (zone haute, jusque-là vide). Design dédié : pylône + anneaux d'énergie pulsants
  (couleur orange, distincte des autres bâtiments). Effet : +5 % de production totale de toutes
  les ressources par niveau au-dessus de 1 (`Economy.amplifierBonus`).
- **Laboratoire** : n'était plus « réservé aux futures recherches » — donne maintenant +2,5 % de
  production totale par niveau au-dessus de 1 (`Economy.labBonus`), appliqué dans
  `ResourceManager.rates()` comme les autres multiplicateurs de production.
- **Défense** : n'était plus « réservée à la future défense » — donne maintenant +0,4 de sécurité
  effective du QG par niveau au-dessus de 1 (`Economy.defenseBonus`), qui s'ajoute au niveau
  manuel et au bonus des Tourelles dans `SecurityManager.effectiveLevel()`. Une sécurité plus
  élevée réduit les pertes lors des raids ennemis (`QGRaid.js`, mécanique déjà existante).
- **Plateforme agrandie** (`PlanetScene._buildPlatform`) : ellipse élargie (largeur ×0.99 au lieu
  de ×0.92, hauteur ×0.465 au lieu de ×0.42), écarts entre les bâtiments du QG légèrement
  augmentés, gisements repoussés vers les bords pour profiter de l'espace supplémentaire.
- Nouvelle entrée dans `Economy.BUILDINGS`/`BUILDING_ORDER` : l'initialisation de sauvegarde
  (`SaveManager.js`) et la remise à niveau de Renaissance (`PrestigeManager.js`) gèrent déjà
  tout nouveau bâtiment de façon générique (aucune migration de sauvegarde nécessaire — les
  parties existantes recevront l'Amplificateur au niveau 1 automatiquement).
- Modifiés : `js/data/Economy.js`, `js/systems/ResourceManager.js`, `js/systems/SecurityManager.js`,
  `js/scenes/PlanetScene.js`.

### Honnêteté sur les tests
- **Testé** : toute la logique pure (Node, sans Phaser) — `node tests/economy.test.js` et
  l'ensemble de `tests/*.test.js` passent (mêmes 2 échecs préexistants et sans rapport avec ce
  module : une image hors gabarit dans `loaderGuard.test.js`, un numéro de version de sauvegarde
  dans `skinManager.test.js` — déjà présents dans le ZIP avant cette modification).
- **Non testé ici** : le rendu visuel réel dans Phaser (positions exactes à l'écran, chevauchements
  éventuels avec le nouveau bâtiment ou la plateforme agrandie). Mon environnement n'a pas accès à
  un vrai moteur Phaser/WebGL ni à Internet pour le charger. À vérifier sur votre appareil — si
  quelque chose déborde ou se chevauche visuellement, dites-le-moi et je corrige.
