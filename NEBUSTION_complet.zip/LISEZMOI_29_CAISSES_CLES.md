# NEBUSTION — Caisses & Clés, Forge d'Éclats, skins refaits

## Nouveautés

**📦 Caisses & Clés** (Boutique → onglet « 📦 Caisses »)
- 3 paliers : **Astrale**, **Nébuleuse**, **Singularité**. Une caisse s'ouvre avec **1 clé du même palier**.
- Chaque ouverture = 1 récompense (skin exclusif, équipement, fragments de héros, lot de ressources ou Prismes) + des Éclats.
- Chances (Astrale / Nébuleuse / Singularité) : Astrale = surtout Commun/Rare ; Nébuleuse = Rare minimum ; Singularité = Épique minimum (26 % de Légendaire).
- **Pitié** : Épique garanti toutes les 10 ouvertures, Légendaire toutes les 40 (compteurs visibles).
- **Où trouver caisses et clés** : cadeau quotidien (1 caisse + 1 clé Astrales), victoires en combat (14 % + 5 %/étoile), caisses de ravitaillement (12 %), achat en Boutique (caisse : ressources ou Prismes ; clé : Prismes), Forge.
- Animation d'ouverture (clé, secousses, flash, révélation) avec aperçu animé du skin obtenu.

**⚒️ Forge d'Éclats (nouvelle fonctionnalité utile)**
- Les Éclats stellaires viennent des ouvertures et des **doublons** (un skin déjà possédé est recyclé).
- Ils servent à **forger des clés** (25 / 80 / 200) ou à **fabriquer directement le skin de ton choix** (40 / 120 / 320 / 750 selon la rareté) : plus de malchance.
- Onglet « Butin » : historique des 30 dernières ouvertures.

**🎨 12 nouveaux skins exclusifs aux Caisses** (4 héros, 4 vaisseaux, 4 bâtiments) avec 5 nouveaux effets : Foudre, Vortex, Prisme, Ailes de lumière, Anneaux runiques.

**✨ Skins existants améliorés** (héros, vaisseaux, bâtiments, partout dans le jeu)
- Rare+ : anneau runique + halo secondaire ; Épique+ : rayons de lumière rotatifs ; Légendaire : double anneau, losanges, étoiles scintillantes.
- Nouvelle couleur secondaire `aura2` par skin (reflets, liserés).
- Vaisseaux : nervure, reflets de coque, chevrons de livrée, verrière, feux clignotants, réacteurs à double flamme + halo.
- Bâtiments : ombrage, fenêtres éclairées, plinthe rayée, mât d'antenne, halo au sol pulsé.
- La Boutique ne liste plus les skins non achetables (Pass Doré / Caisses).

## Fichiers
Nouveaux : `js/data/Crates.js`, `js/systems/CrateManager.js`, `js/scenes/CratesScene.js`, `tests/crates.test.js`, `tests/crate-manager.test.js`, `tests/crates-scene-smoke.js`.
Modifiés : `Skins.js` (12 skins + effets), `SkinFX.js` (rendu), `SkinsScene.js`, `ShopScene.js` (onglet), `SaveManager.js` (état `crates`, rétrocompatible), `CombatManager.js` + `CombatScene.js` (butin), `SupplyPod.js` (butin), `index.html`, `main.js`, `sw.js` (cache v58).
La sauvegarde existante reste valide (état `crates` créé vide). Les caisses/clés/Éclats survivent à la Renaissance (Prestige).

## Tests
`node tests/crates.test.js` (28), `node tests/crate-manager.test.js` (≈500, varie selon les tirages), `node tests/crates-scene-smoke.js` (13, faux Phaser).

## ⚠️ Non testé
Comme pour les étapes précédentes : pas de vrai Phaser/WebGL ici. La logique (tirages, pitié, forge, sauvegarde, butin) est testée sous Node ; les scènes et effets visuels ont seulement été exécutés avec un faux Phaser (aucune erreur de logique, mais aucun rendu réel). L'aspect visuel des nouveaux effets (foudre, vortex, ailes…) et de l'écran d'ouverture est à valider sur téléphone ; si la console affiche une erreur, envoie-la-moi.
Équilibrage à ajuster dans `js/data/Crates.js` (chances, prix, coûts de Forge, taux de butin `DROPS`).
