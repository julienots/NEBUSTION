# NEBUSTION v3.3.7 — Parcelles à acheter sur les planètes

## Ce que ça fait
La surface d'une planète est découpée en **104 parcelles** (8 bandes de latitude, de 6 à 18 cases par bande).
Chaque parcelle est bordée par des **méridiens et des parallèles**, donc elle **épouse la courbure** de la planète :
large au centre du globe, écrasée vers l'horizon, en couronne près des pôles (calottes > 80° exclues).

| Monde | Parcelles | À quoi elles servent |
|---|---|---|
| **Nexus-01** | 24 offertes (autour de la base, d'un seul bloc) + 80 à acheter | On ne peut **construire** (CONSTRUIRE) que sur une parcelle à soi |
| **Pyros, Aqualis, Rubéa, Glacia** | 0 au départ, 104 à acheter | Chaque parcelle = **+1 % de production de la colonie** du monde |
| Goliath, Saturnia | aucune (géantes gazeuses, pas de sol) | — |

## Utilisation
- **Nexus-01** : bouton **PARCELLES** (à droite de CONSTRUIRE). **Autres mondes** : bouton **🗺️ Parcelles** dans la fiche du monde.
- On tourne la planète au doigt, on **touche une parcelle** → panneau avec l'état et le prix → **ACHETER**.
- Vert = à toi · Or = achetable · Gris = trop loin · Blanc = sélection. Le nom (D10, C7…) s'affiche sur chaque parcelle de face.
- Achat possible seulement si la parcelle **touche** une parcelle déjà à toi (par un bord). Sur un monde vierge, la 1re parcelle se choisit **où on veut**.
- **Prix croissant** : base × (1 + 0,10·n + 0,004·n²), n = parcelles déjà achetées sur ce monde (les offertes ne comptent pas).
  Nexus-01 : 180 cristaux + 120 métal la 1re. Autres mondes : ~400 de deux ressources la 1re.
- Pendant le placement d'une construction sur Nexus-01, les parcelles à soi sont en **vert** et le reste est **voilé** : poser hors de ses parcelles est refusé.
- Les anciennes parties ne perdent rien : le territoire de départ est offert, et **chaque construction déjà posée garde sa parcelle**.
- Hors du mode parcelles, rien n'est dessiné en plus : l'aspect de la planète et les FPS ne changent pas.

## Réglages (tout est dans `js/data/Parcels.js`)
`WORLDS` (prix de base par monde), `PRICE_LIN` / `PRICE_QUAD` (courbe de prix), `COLONY_BONUS_EACH` (+1 %), `START_RADIUS` (taille du territoire offert),
`BAND_DEG` / `TARGET_W` (taille et nombre de parcelles).

## Fichiers
Nouveaux : `js/data/Parcels.js`, `js/scenes/PlanetParcelsUI.js`, `tests/parcels.test.js`, `tests/parcels-ui-smoke.js`.
Modifiés : `PlanetScene.js` (2 lignes), `PlanetBuildUI.js` (fantôme + messages), `PlanetBuild.js` (refus si parcelle non achetée), `ExoPlanetScene.js` (boutons + chiffres),
`ColonyManager.js` (`planetMult`), `SaveManager.js` (`state.parcels`), `index.html`, `sw.js` (cache `nebustion-v67-parcelles`), `main.js`/`package.json` (3.3.7).

## Tests (tous les tests du projet passent)
`node tests/parcels.test.js` : 357 vérifications (grille, voisinage, prix, achat, sauvegarde corrompue/ancienne).
`node tests/parcels-ui-smoke.js` : 94 vérifications avec un faux Phaser (contours dans le disque sur toutes les rotations, courbure, coupe sur l'horizon, toucher, achat, mondes, colonies).

## À vérifier sur ton téléphone (honnêteté)
Pas de vrai Phaser/WebGL ici : la géométrie a été vérifiée par calcul et par un tracé des polygones, pas sur un vrai écran.
Si les remplissages semblent bizarres sur un pôle, c'est `fillPoints` : le code bascule déjà sur des triangles pour les formes non convexes.
