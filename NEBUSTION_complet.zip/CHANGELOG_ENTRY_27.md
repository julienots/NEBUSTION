## Module 27 — Matchmaking QG (combat contre les bases ennemies)
- Le panneau « Attaquer » du QG ne présente plus une liste figée de 5 commandants : bouton
  🎯 TROUVER UN ADVERSAIRE → matchmaking pondéré par niveau (proche de ton niveau = plus probable,
  jamais figé), sur les empires réels de la Galaxie (mécaniques inchangées).
- Chaque recherche donne une variante d'apparence différente pour la base trouvée (même empire
  possible plusieurs fois, mais jamais rendu identique) sans changer sa vraie défense.
- Après un combat (flotte ou mode combat manuel), l'adversaire est consommé : il faut chercher à nouveau.
- Nouveaux fichiers : js/data/QGMatchmaking.js, js/systems/QGMatchmakingManager.js.
- Modifiés : js/data/BotBases.js (layout() accepte une variante), js/data/QGBattle.js (botBase() idem),
  js/scenes/QGScene.js (panneau matchmaking), js/scenes/EnemyQGScene.js, js/scenes/QGBattleScene.js,
  js/systems/SaveManager.js (persistance qgMatch), index.html, sw.js (cache v31).
