NEBUSTION — ZIP 05 SYMBIOTE / PATCHES
Nouveau système Symtor/Symbiote + fichiers modifiés à superposer après les ZIP 01 à 04.
Ordre de reconstruction : 01 → 02 → 03 → 04 → 05.
Le Symtor est achetable sur Nexus-01, ouvre une capsule, héberge une créature procédurale qui grandit, gagne des mutations, se nourrit, combat des adversaires galactiques/symbiotes simulés et renforce la défense du QG.

## Mise à jour "créature vivante + mutations variées" (`js/data/Symbiote.js`, `js/scenes/SymbioteScene.js`)

**Créature vraiment vivante :**
- Déplacement lent et organique dans le bâtiment (elle ne reste plus figée au centre).
- Chaque tentacule ondule à sa propre vitesse/phase ; chaque œil cligne selon son propre rythme.
- Réagit visiblement quand on la nourrit (bouche qui s'ouvre, pluie de particules, aura qui s'intensifie) et
  encore plus fort en cas d'évolution (flash doré, halo temporaire sur la nouvelle mutation, toast qui nomme
  précisément le trait obtenu, ex. « Niveau 12 • Ailes membraneuses »).

**Mutations et formes beaucoup plus variées :**
- 13 types de traits au lieu de 7 (ajout : ailes, nageoires, excroissances cristallines, fourrure, points
  luminescents, rayures).
- Chaque créature a désormais une identité fixe tirée de sa graine dès la naissance : une teinte de couleur
  unique (`bodyStyle`), une forme de corps parmi 4 silhouettes (ronde / allongée / anguleuse / segmentée) et une
  légère asymétrie — deux symbiotes ne se ressemblent quasiment jamais.
- Le tirage de mutation à chaque niveau est pondéré vers les traits encore peu développés (`pickTrait`), pour que
  la créature développe un éventail large plutôt que de répéter toujours le même trait, tout en restant
  100 % déterministe et reproductible au rechargement (aucun aléa non sauvegardé).
- `NEBUSTION.Symbiote` expose maintenant `bodyStyle(seed)`, `rng(seed)` (PRNG seedé réutilisable) et
  `TRAIT_LABELS` (noms français des mutations, utilisés dans les toasts).

Aucune autre étape (économie, QG, sauvegarde) n'a été modifiée : la sauvegarde existante reste compatible,
les créatures déjà nées gardent leurs traits actuels et affichent simplement leur nouveau style visuel au
prochain chargement.
