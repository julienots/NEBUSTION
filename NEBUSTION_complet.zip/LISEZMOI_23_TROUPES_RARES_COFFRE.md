# NEBUSTION — Étape 23 : troupes rares + Coffre-fort (bouclier anti-raid)

## Nouvelle fonctionnalité : Coffre-fort (QG, `js/data/QGGrid.js`)
Bâtiment 🔐 à construire dans la grille du QG (10e structure, 5×2 cases pile remplies) : jusqu'à 5, chacun
réduit de 6 % les ressources perdues quand un raid ennemi réussit (max 30 % construits, plafonné à 50 % au
total par sécurité). Branché dans `QGRaidManager.applyLoss` : le bouclier s'applique réellement au pillage,
et le journal des raids affiche désormais la perte RÉELLE après bouclier (`entry.lossPct`).

## 3 nouvelles troupes rares (coûtent des Noyaux antiques), `js/data/Troops.js`
- 🐋 **Léviathan** — colosse au sol, 2400 PV (record du jeu), très lent, cible n'importe quoi.
- 👑 **Faucheuse Impériale** — assassin volant d'élite, fonce sur le cœur du QG, 110 DPS (record du jeu).
- 🌌 **Bombe du Néant** — explosif à usage unique, blast 900 / rayon 2.2 (le plus fort et le plus large).

Dessins de combat dédiés dans `js/scenes/QGBattleScene.js` (`_drawTroop`).

## Fichiers modifiés
`js/data/Troops.js`, `js/data/QGGrid.js`, `js/systems/QGRaidManager.js`, `js/scenes/QGScene.js` (texte du
panneau de construction), `js/scenes/QGBattleScene.js` (dessins), `tests/module20.test.js` et
`tests/qgBattle.test.js` (compteurs mis à jour : 23 troupes, 10 structures).

## Tests
`node tests/rareTroopsVault.test.js` (22 vérifications, nouveau fichier) · `node tests/module20.test.js`
(83, mis à jour) · `node tests/qgBattle.test.js` (68, mis à jour) : tous passent.
Suite complète (`tests/*.test.js`) rejouée : aucune régression liée à cette étape. Deux échecs
PRÉEXISTANTS et sans rapport (poids/dimensions d'un visuel « outsiderz », et un test qui vérifie en dur le
numéro de version de sauvegarde) — ni l'un ni l'autre touchés ici.

## Non testé
Pas de navigateur/Chromium disponible dans cet environnement : aucun test visuel réel (rendu Phaser, panneau
du QG à 10 cartes, dessins des 3 nouvelles troupes) n'a été effectué. À vérifier sur appareil.
