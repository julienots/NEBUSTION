# NEBUSTION — Ajout : Intérieur du QG + Sécurité de zone

Fait suite à `LISEZMOI_11_QG.md`. On peut maintenant **rentrer dans le QG** depuis Nexus-01,
et à l'intérieur, **sécuriser la zone** (un système distinct du niveau du bâtiment QG lui-même,
qui continue de débloquer les expéditions comme avant).

## Comment y accéder

Dans `PlanetScene`, taper sur le bâtiment QG ouvre le panneau habituel (niveau / coût / bouton
AMÉLIORER, inchangé). Un nouveau lien **« Entrer › »** apparaît à côté de « Skins › », uniquement
sur ce bâtiment : il ouvre `QGScene`, l'intérieur du QG.

## Ce qui a été ajouté

- `js/data/Security.js` (nouveau) : données pures — niveau (1 à 20 pour l'instant), coût
  d'amélioration (cristaux/métal/énergie, croissance ×1,45/niveau), texte d'effet. Aucune
  dépendance à Phaser, testable sous Node, même esprit que `Economy.js`/`Prestige.js`.
- `js/systems/SecurityManager.js` (nouveau) : glue avec `Resources` — lit/écrit
  `Resources.state.security = { level }`, `upgrade()` paie et incrémente, `canAfford()`,
  `effectText()`. Suit exactement le patron de `PrestigeManager.js`.
- `js/scenes/QGScene.js` (nouveau) : scène dédiée (même décor spatial que le reste du jeu),
  jauge de niveau, coût affiché (icônes + montants, rouge si insuffisant), bouton
  « SÉCURISER LA ZONE », bouton retour vers `PlanetScene`. Enregistrée dans `main.js` et
  `index.html`.
- `js/scenes/PlanetScene.js` : lien « Entrer › » ajouté au panneau du bâtiment QG (se place
  dynamiquement à gauche de « Skins › » pour ne jamais le chevaucher).
- `js/systems/SaveManager.js` : `state.security` ajouté à `defaultState()`/`normalize()`,
  rétrocompatible (une sauvegarde sans ce champ reçoit `{ level: 1 }` par défaut).
- `tests/progress-env.js` : `data/Security` et `systems/SecurityManager` ajoutés au chargement
  du harnais de test.

## Volontairement minimal (comme demandé)

Pour l'instant, « sécuriser la zone » n'apporte qu'un niveau qui monte, sans effet de jeu concret
(le texte l'indique honnêtement : « de nouvelles menaces et défenses arriveront dans une prochaine
mise à jour »). L'architecture (données pures + manager + coûts croissants + sauvegarde) est prête
à recevoir la suite : vagues d'ennemis à repousser, tourelles, bonus de protection sur les
expéditions ou contre une future invasion, etc. — sans rien casser de l'existant.

## Tests

`tests/security.test.js` (nouveau) : formules de coût, `normalizeState` (bornes, valeurs
invalides), `upgrade()` (paiement atomique, refus si fonds insuffisants, blocage au niveau max),
non-régression sur les autres modules.

`for f in tests/*.test.js; do node $f | tail -1; done` → à vérifier après cet ajout (aucune
régression attendue sur les fichiers existants).
