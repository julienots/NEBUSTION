# NEBUSTION — Colonies sur les planètes de la Nouvelle Galaxie

## Utilisation
Univers → Nouvelle Galaxie → touche une planète → bouton **🚀 Coloniser** (devient **🏗️ Ma colonie**).
- **Fonder** : coût en ressources propre à chaque monde ; offre les 3 installations au niveau 1.
- **Installations** (3 par planète, niveau max 10) : production continue d'une ressource. Coût ×1,6 par niveau, production ×1,28.
- **Récolter** : la production s'accumule dans la colonie, **même hors ligne, jusqu'à 4 h** ; on la récolte à la main.
  Si le stockage du QG est plein, le reste attend dans la colonie.
- **Bonus** : +5 % de production sur toutes les colonies par colonie fondée (6 colonies = +30 %).
- Dans le système solaire, une planète colonisée affiche ⬢ à côté de son nom.

| Planète | Fondation | Produit |
|---|---|---|
| Pyros | 4 000 métal + 1 500 énergie | métal, énergie, noyaux |
| Aqualis | 3 500 cristaux + 2 000 métal | cristaux, énergie, poussière |
| Rubéa | 3 500 métal + 3 000 poussière | métal, poussière, cristaux |
| Goliath | 4 500 énergie + 2 500 cristaux | énergie, noyaux, poussière |
| Saturnia | 4 500 poussière + 3 000 métal | poussière, cristaux, métal |
| Glacia | 3 000 cristaux + 2 500 énergie | cristaux, énergie, noyaux |

## Fichiers
- Nouveaux : `js/data/Colonies.js` (données + équilibrage), `js/systems/ColonyManager.js`, `tests/colonies.test.js`.
- Modifiés : `js/scenes/ExoPlanetScene.js` (bouton + fenêtre colonie), `js/scenes/SolarSystemScene.js` (marqueur ⬢),
  `js/systems/SaveManager.js` (état `colonies`, normalisé, ancien save compatible), `index.html`, `sw.js` (cache v60).
- Correctif : `ProgressScene.js` chargé avant `CratesScene.js` (onglet Caisses noir).

## Tests
`node tests/colonies.test.js` (98 vérifications) ; `NODE_PATH=$(npm root -g) node tests/exoplanet-smoke.js` (85, panneau colonie inclus).
Faux Phaser seulement : l'aspect de la fenêtre et le toucher sont à valider sur téléphone.
