# NEBUSTION — Pass Doré, menu latéral, tutoriel

## Ce qui change
1. **Pass Doré** — palier au-dessus du Premium (il inclut le Premium).
   - Écran Pass → la colonne de droite affiche la piste **Dorée** dès que vous possédez le Pass Doré ; sinon la piste Premium, comme avant.
   - Touchez l'en-tête de la colonne de droite : sans Premium → fenêtre Premium (avec lien « Découvrir le Pass Doré ») ; avec Premium → fenêtre Pass Doré (upgrade au prix de la différence).
   - Prix en ressources : complet 14 000 cristaux · 11 000 métal · 5 500 énergie · 140 noyaux · 28 000 poussière ; upgrade depuis le Premium : 6 000 · 5 000 · 2 500 · 80 · 13 000 (modifiable dans `PassBilling.js`).
2. **Nouveaux objets** : Coffrets cosmiques (niv. 5, 15, 25), 8 skins exclusifs (niv. 12 et 30 de chaque saison), Prismes / fragments / troupes renforcés.
3. **Menu du bas → menu latéral** : onglet sur le bord droit de l'écran (à ~60 % de la hauteur), un tap l'ouvre en colonne verticale, un tap dehors ou sur ✕ le referme.
4. **Tutoriel** : 7 cartes au premier passage sur l'accueil, rejouable depuis ⚙ Paramètres → « Revoir le tutoriel ».

## Fichiers
- Modifiés : `js/data/Pass.js`, `Skins.js`, `js/systems/PassManager.js`, `PassBilling.js`, `SkinManager.js`, `SaveManager.js`, `js/scenes/PassScene.js`, `SkinsScene.js`, `MainMenuScene.js`, `js/ui/BottomNav.js`, `SettingsMenu.js`, `index.html`, `sw.js`
- Nouveaux : `js/systems/TutorialManager.js`, `js/ui/TutorialOverlay.js`, `tests/goldenpass.test.js`, `tests/tutorial_menu.test.js`

## Test rapide (mode debug `?debug=1`)
Dans l'écran Pass, la fenêtre Premium / Pass Doré propose des boutons « TEST » pour activer/retirer le palier sans payer ; `NEBUSTION.PassManager.debugAddXp(9999)` monte le Pass au niveau max.

## À vérifier sur téléphone (non testé visuellement ici : pas d'accès à Phaser/navigateur)
- Position et taille de l'onglet du menu sur vos écrans (constante `NEBUSTION.BottomNav.HANDLE` dans `BottomNav.js` : `w`, `h`, `cyRatio`).
- Les scènes qui réservaient ~116 px en bas pour l'ancienne barre gardent cette marge vide (sans conséquence, à réduire scène par scène si vous voulez récupérer la place).
- Rendu des cartes dorées, de l'icône coffret et de la fenêtre Pass Doré.
