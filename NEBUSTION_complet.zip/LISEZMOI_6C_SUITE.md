# NEBUSTION — Étape 6C, suite : icônes réelles + complément du prompt 6/10

Suite du ZIP « 6C skins ». Rien n'est recréé : correctifs et ajouts ciblés sur Équipement, Vaisseaux, Combat et Caisses.

## 1. Icônes de ressources
La barre de ressources en haut de l'écran utilisait déjà de vraies icônes dessinées (cristal, métal,
énergie, noyau, poussière). Le problème était ailleurs : les coûts de fabrication/amélioration dans
**Équipement** et **Flotte** affichaient des symboles texte (⛭ ◆ ⚡) au lieu d'icônes.
→ Remplacés par les vraies images `tex_icon_metal` / `tex_icon_core` / `tex_icon_crystal` / `tex_icon_energy`
dans `EquipmentScene.js` et `ShipsScene.js` (fabrication, amélioration).

## 2. Contenu manquant du prompt 6/10, ajouté
| Demandé | État avant | Ajouté |
|---|---|---|
| Armes, armures, réacteurs, modules, artefacts | 3 emplacements seulement (arme/armure/module) | **Réacteur** et **Artefact** ajoutés (`Equipment.js`) — 5 emplacements |
| Fusion des objets | Absente | `EquipmentManager.fuse()` + `findFusionMatch()` : 2 objets identiques (même emplacement/rareté/niveau) → 1 objet de rareté supérieure. Bouton « Fusionner » dans l'inventaire |
| Inventaire avec filtres et tri | Liste triée, non filtrable | Chips de filtre par emplacement (Tous/Arme/Armure/Module/Réacteur/Artefact) + tri Rareté/Niveau/Nom (bouton cyclique) |
| Objets obtenus en combat, en farm, en expéditions | Le tirage combat existait (`maybeDropFromCombat`) mais **n'était jamais montré au joueur** (bug silencieux) ; rien en farm | Affichage de l'objet trouvé sur l'écran de victoire (combat **et** invasion, qui réutilise le même moteur) ; nouvelle source **farm** : `maybeDropFromFarm()` déclenchée à l'ouverture d'une caisse de ravitaillement (`SupplyPod.js`) |
| Vaisseaux : classes, niveaux, flotte sélectionnable, skins, bonus/synergies | Déjà complet | Rien à changer |

## Fichiers touchés
- `js/data/Equipment.js` — 5 emplacements, `nextRarity()`.
- `js/systems/EquipmentManager.js` — `fuse`, `findFusionMatch`, `maybeDropFromFarm`.
- `js/scenes/EquipmentScene.js` — réécrite : grille 5 emplacements, fabrication x5 avec icônes, filtre + tri, fusion, icônes vectorielles par emplacement.
- `js/scenes/ShipsScene.js` — icônes réelles sur les coûts d'acquisition/amélioration.
- `js/entities/SupplyPod.js` — tirage d'équipement (farm) à l'ouverture d'une caisse.
- `js/scenes/CombatScene.js` — affichage de l'objet trouvé sur l'écran de victoire.
- `tests/equipment.test.js`, `tests/equipmentManager.test.js` — mis à jour (5 emplacements, tests de fusion).
- `tests/browser-equipment.js` — **nouveau** test de fumée Chromium dédié (ouverture, 5 emplacements, icônes, fabrication, filtre, tri, équiper/améliorer, fusion, démantèlement, sauvegarde/rechargement).
- `tests/mock-phaser.js` — ajout de `scene.restart()` (méthode Phaser standard, utilisée par Équipement et Flotte, absente du faux Phaser).

## Tests
Toutes les suites existantes repassent sans régression (13 fichiers Node + 6 tests navigateur Chromium,
dont le nouveau `browser-equipment.js`, 0 échec).

## Limites connues
- La fusion ne combine que 2 objets strictement identiques (même emplacement/rareté/niveau) ; pas de fusion multi-niveaux en un clic.
- Réacteur et Artefact réutilisent le même barème de coûts (métal/noyau) que les 3 emplacements existants, pas de ressource dédiée.
- Le tirage « farm » est branché uniquement sur les caisses de ravitaillement (pas sur la récolte passive des gisements).
