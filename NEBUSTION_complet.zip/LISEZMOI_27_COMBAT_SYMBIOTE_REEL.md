NEBUSTION — ZIP 27 : COMBAT RÉEL DU SYMTOR
À superposer après le ZIP 26 (accueil galaxie).

## Le problème
Les boutons « ⚔ COMBAT GALACTIQUE » et « ☣ DUEL CONTRE UN SYMBIOTE » de l'écran Symtor
résolvaient le combat instantanément : un simple toast « VICTOIRE » ou « DÉFAITE », sans
aucune animation, tiré à pile ou face selon une formule de chance.

## Ce qui change
Nouvelle scène `SymbioteBattleScene` (nouveau fichier `js/scenes/SymbioteBattleScene.js`) :
lancée à la place de la résolution instantanée, elle affiche un vrai duel :
- Ton Symtor (en bas) contre l'adversaire (en haut), chacun dessiné avec ses propres
  formes/tentacules/yeux/mutations, comme dans le laboratoire.
- Deux barres de vie qui descendent réellement à chaque coup porté.
- Combat tour par tour : projectile qui traverse l'écran, flash rouge et recul sur la
  créature touchée, tremblement de caméra (plus fort sur un coup critique), dégâts affichés.
- Le combat est simulé par `NEBUSTION.Symbiote.simulateBattle()` à partir des vraies stats
  (Puissance/Défense) des deux créatures — ce n'est plus un tirage séparé, c'est l'issue du
  duel lui-même qui détermine qui gagne.
- Bannière VICTOIRE/DÉFAITE + récompenses à la fin, bouton CONTINUER pour revenir au Symtor.
- Toucher l'écran pendant le combat accélère jusqu'au résultat (utile en cas de duels répétés).

## Fichiers modifiés
- `js/data/Symbiote.js` : ajout de `opponentDefense()` et `simulateBattle()`.
- `js/systems/SymbioteManager.js` : `battle()` est éclaté en `prepareBattle()` (calcule
  l'adversaire + simule le duel, sans rien changer à la sauvegarde) et `resolveBattle()`
  (applique récompenses/statistiques une fois l'animation terminée). L'ancienne fonction
  `battle()` reste disponible (elle appelle les deux à la suite) pour la compatibilité avec
  les tests existants.
- `js/scenes/SymbioteScene.js` : les deux boutons de combat lancent désormais
  `SymbioteBattleScene` au lieu de résoudre le duel sur place.
- `index.html` / `js/main.js` : enregistrement de la nouvelle scène.

Économie inchangée : les récompenses de victoire/défaite restent identiques à avant.
Les 83 tests de `tests/module20.test.js` passent toujours.
