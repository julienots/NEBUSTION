# Atelier de cartes NEBUSTION

> Pour les héros, les ennemis et les réglages d'équilibrage (équipement, difficultés),
> utilise plutôt `tools/studio.html` — voir ses 3 onglets en haut de la page. Cet atelier-ci
> ne concerne que les cartes (Boutique, onglet Cartes).

Ouvre `tools/atelier_cartes.html` dans un navigateur.

1. Choisir une image.
2. Renseigner nom, rareté, niveaux, statistiques et ressources.
3. Cliquer **Créer le fichier de carte**.
4. Le fichier `.nebustion-card.json` obtenu peut être envoyé directement pour intégration.

Aucun code n'est nécessaire. L'éditeur réduit l'image et valide les nombres pour éviter de casser le jeu. Les cartes sont ensuite contrôlées par `js/data/CustomCards.js` avant d'être utilisées.

Pour une intégration dans le jeu, fournir simplement le ou les fichiers `.nebustion-card.json`.


### Boutique
Les cartes intégrées depuis l'Atelier peuvent apparaître dans l'onglet **Cartes** de la Boutique. La carte Outsiderz est intégrée dans cette version.
