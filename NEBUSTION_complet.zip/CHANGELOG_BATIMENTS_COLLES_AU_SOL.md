# NEBUSTION — Bâtiments de Nexus-01 : collés au sol, toujours droits

## Ce qui est voulu
La planète tourne ; les bâtiments et gisements restent à leur place SUR la planète (ils suivent le
sol), mais ils ne se penchent, ne s'écrasent et ne tournent jamais sur eux-mêmes.

## Correctif
- `js/scenes/PlanetScene.js` : nouvelle `_projectAnchor()` = position sur la sphère (suit la
  rotation) avec inclinaison à 0, « haut » toujours vers le haut de l'écran, sans écrasement.
  Utilisée pour bâtiments, gisements (qui s'inclinaient encore), construction et placement.
  `_applyBox` : bâtiments droits, échelle X = échelle Y, badge de niveau droit.
- `js/entities/MiningDrone.js` : drones sur le même repère (altitude toujours vers le haut).
- `js/scenes/PlanetBuildUI.js` : texte de placement d'origine (glisser pour tourner la planète).
- (La version « tout immobile à l'écran » du zip précédent est annulée.)

## Ce qui change encore avec la rotation (voulu)
Position sur l'écran (ils suivent le sol), taille légère selon la profondeur, fondu et
touchable coupé quand un bâtiment passe derrière le globe, ombre et pastille au sol.

## Réglages
Taille selon la profondeur : `scale` dans `_projectVec` (0.55 + 0.45 * t). Pour une taille
constante partout, mettre `p.scale = 1` dans `_projectAnchor`.

## Non testé
Vérifié sous Node : sur 5 rotations différentes, tous les bâtiments/gisements suivent exactement
le point de la sphère, rot = 0, aucun NaN, aller-retour placement exact. Rendu Phaser/téléphone
à valider en jeu. Cache du service worker : `nebustion-v50-batiments-colles-au-sol-droits`.
