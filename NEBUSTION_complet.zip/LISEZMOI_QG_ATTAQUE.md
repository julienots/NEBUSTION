# NEBUSTION — Attaquer le QG des empires ennemis (avec les bots de la flotte)

## Ce que ça ajoute
Jusqu'ici, les empires pouvaient raider TON QG (module 12, `QGRaid.js`), mais toi tu ne pouvais
riposter contre le leur qu'en envoyant ton équipe de 5 héros conquérir leurs planètes une par une
(module Galaxie). Cette étape ajoute une action directe et rapide : attaquer le **QG d'un empire**
avec ta **flotte de vaisseaux (bots)** du Hangar — les mêmes vaisseaux qui donnent déjà un bonus %
à tes héros en combat.

## Comment jouer
1. Assemble une flotte (onglet **Vaisseaux**, 3 vaisseaux max) — indispensable pour attaquer.
2. Dans le **QG**, bouton **⚔ Attaquer** en haut à droite.
3. Un panneau liste les 5 empires (VEXOR, KAEL-9, ELYRA, MORVAK, NYR'AH) avec leur développement,
   leur traumatisme actuel, et un statut : *Prêt* / *Recharge Xh* / *Flotte vide* / *Empire vaincu*.
4. Tape **ATTAQUER** sur un empire prêt : le résultat tombe immédiatement.

## Règles
- **Puissance d'attaque** = somme de la puissance des vaisseaux engagés dans la flotte (rareté +
  niveau, tous rôles à parts égales — `Ships.attackPower`).
- **Défense du QG ennemi** = développement de l'empire (`evo`), affaiblie s'il est déjà traumatisé
  (`hurt`) — un empire déjà secoué se défend moins bien.
- **Victoire** : butin crédité (cristaux, métal, énergie — jamais les Noyaux antiques), l'empire
  encaisse un vrai coup (traumatisme accru, élan réduit) → **ça affaiblit aussi ses futurs raids
  contre ton propre QG**, les deux systèmes sont liés via la même mémoire d'empire
  (`EmpireEvolutionManager`).
- **Défaite** : rien n'est perdu (pas de destruction de vaisseau), l'empire reprend un peu d'élan
  (a tenu bon).
- **Recharge** : 3h par empire entre deux attaques (anti-spam), posée que ce soit une victoire ou
  une défaite.
- Un empire qui n'a plus aucune planète non conquise est considéré vaincu : plus attaquable.

## Fichiers
- `js/data/QGAttack.js` — formules pures (attaque, défense, chance de victoire, butin), testable Node.
- `js/systems/QGAttackManager.js` — glue : flotte (ShipManager), mémoire d'empire
  (EmpireEvolutionManager), butin (Resources), sauvegarde (`state.qgAttack`).
- `js/data/Ships.js` / `js/systems/ShipManager.js` — ajout de `attackPower()` / `fleetPower()`
  (puissance d'attaque absolue des vaisseaux, en plus du bonus % déjà existant).
- `js/scenes/QGScene.js` — bouton et panneau « Attaquer un QG ennemi ».
- `js/systems/SaveManager.js` — `state.qgAttack` initialisé/normalisé (résiste aux sauvegardes
  abîmées, comme tous les autres modules).
- `index.html` — scripts déclarés dans l'ordre.

## Tests
`node tests/qgAttack.test.js` → **41 vérifications, toutes OK** (formules pures, normalizeState
résistant aux données abîmées, refus sans flotte, victoire forcée → butin crédité/empire affaibli/
recharge posée, défaite forcée → rien perdu, empire vaincu → cible invalide, puissance de flotte).

Suite complète relancée en même temps (aucune régression) : economy (1843), combat (1294), galaxy
(916), heroes (438), enemies (265), empireEvolution (146), empireAI (220), empireAdaptation (172),
qgRaid (210), ships (24), shipManager (13), equipment (24), equipmentManager (28), qgGrid (39),
security (22), skins (120), skinManager (33), shop (28), pass (465), heroShop (165), expeditions
(92), events (86), prestige (64), achievements (57), background (45), loaderGuard (111).

## Pistes pour la suite (non faites ici)
- Effet visuel dédié (impact/explosion) sur la carte Galaxie quand un QG est frappé.
- Vaisseaux perdus/endommagés sur une défaite trop lourde (actuellement sans conséquence).
- Objectifs Succès (`Achievements.js`) liés au nombre de QG ennemis attaqués/pris.
