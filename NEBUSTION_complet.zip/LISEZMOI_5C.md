# NEBUSTION — Module 5C : invasions et conquêtes galactiques

Suite directe du ZIP « IA des empires (final) ». Rien n'est recréé : la scène Galaxie et l'invasion réutilisent
`Galaxy`, `GalaxyManager`, `EmpireEvolutionManager` (IA 5B), `CombatEngine`/`CombatScene` et l'équipe de 5 héros.

## Fichiers
| Fichier | Statut | Rôle |
|---|---|---|
| `js/scenes/GalaxyScene.js` | nouveau | Onglets de secteurs (déblocage), carte, liste des planètes, fiche : scan → invasion |
| `js/utils/GalaxyTextures.js` | nouveau | Textures procédurales des 10 types de planètes |
| `js/scenes/CombatScene.js` | étendu | Mode invasion : vagues, écran de résultat (conquête, réaction de l'empire), abandon/réessayer/retour Galaxie |
| `js/systems/CombatManager.js` | étendu | `buildInvasionBattle`, `grantInvasionRewards` (bouclier d'orbite = 12 % du bouclier de la planète) |
| `js/systems/CombatEngine.js` | +2 lignes | `startTime` / `skipPassiveInit` pour enchaîner les vagues sur la même équipe |
| `js/systems/GalaxyManager.js`, `js/data/Galaxy.js`, `js/systems/SaveManager.js` | étendus | Revenus des colonies (`colonyRates`, `collectColonies`, état `colonyAt` sauvegardé) |
| `js/utils/EnemyTextures.js` | étendu | Textures des 25 unités d'empire |
| `index.html`, `js/main.js`, `js/ui/BottomNav.js`, `js/scenes/MainMenuScene.js`, `js/scenes/PreloadScene.js`, `sw.js` | branchés | « Galaxie » ouvre GalaxyScene ; tick Galaxie toutes les 5 s (scans, revenus) |
| `tests/browser-invasion.js` | nouveau | 79 vérifications (Chromium + faux Phaser) |

## Règles de jeu
- **Scan obligatoire** (énergie, quelques secondes, valable 12 h) : il révèle flotte, bouclier, tourelles, niveau conseillé, butin.
- **Portée** : on n'attaque qu'un monde relié par une route à Nexus-01 ou à une planète déjà conquise. On peut scanner plus loin.
- **Combat** : mêmes 5 héros, même arène ; défense en vagues de 3 ennemis max, à l'échelle de la planète et de l'évolution de l'empire.
- **Victoire** : ressources, XP, fragments (bonus de première conquête), planète conquise et sauvegardée. **Défaite** : petite compensation ; l'empire « a tenu » (élan).
- **Empires** : perte mémorisée une seule fois, alerte, contre-offensive possible, défenses renforcées (modules IA existants).
- **Colonies** : chaque planète conquise verse ses gisements à l'heure, aussi hors ligne (12 h max par versement).
- **Secteurs** : conditions existantes (stages, scans du secteur précédent, ressources) affichées dans l'onglet verrouillé.

## Limites connues
- Tourelles, traits et capacités d'empire sont affichés mais pas encore appliqués par `CombatEngine` (seuls échelle des unités et bouclier le sont).
- Pas de système d'équipements dans le jeu : les récompenses sont ressources, XP et fragments.
- Phaser réel non testé ici (pas de réseau) : validation avec le faux Phaser uniquement. Équilibrage à confirmer en jeu.

## Tests
`node tests/<nom>.test.js` (galaxy 916, empireEvolution 146, empireAI 220, empireAdaptation 172, combat 857, enemies 265, heroes 312, economy 1763, background 39)
`NODE_PATH=$(npm root -g) node tests/browser-invasion.js` (79) · `browser-smoke.js` (37) · `browser-combat.js` (52) · `browser-empires.js` (16)
