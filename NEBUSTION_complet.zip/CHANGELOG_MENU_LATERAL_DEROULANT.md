# Menu latéral déroulant (accueil Nexus-01)

## Problème
Le rail de 8 raccourcis (bord gauche de l'accueil) occupait toute la hauteur de l'écran, cachait la
galaxie Écarlate (« euse Écarlate » coupé) et ne pouvait ni se replier ni défiler.

## Changements
- **Nouveau composant réutilisable `js/ui/SideRail.js`** (`NEBUSTION.SideRail`) :
  - **Déroulant** : une languette sur son bord intérieur le fait glisser hors de l'écran / le ressortir
    (elle pulse quand il est replié). Le choix est mémorisé (localStorage, par écran).
  - **Scrollable** : glisser au doigt (avec inertie) ou molette ; barre fine + flèches quand il reste du
    contenu. Un tap sans glissement ouvre le raccourci (faire défiler ne déclenche rien par erreur).
  - **Discret** : 66 px de large (au lieu de 76), fond translucide, hauteur = celle du contenu (au lieu
    de toute la colonne), libellés sous les icônes.
  - Options : `side` ('left' | 'right'), `top`, `bottom`, `width`, `cell`, `id`, `collapsed`.
- `js/scenes/MainMenuScene.js` : `_buildSideRail()` utilise `SideRail` (mêmes 8 raccourcis, mêmes icônes,
  mêmes destinations) ; galaxies Écarlate / Glacial décalées vers l'intérieur (x = 20 % / 80 %) pour ne
  plus passer sous le rail.
- `index.html` et `sw.js` : `SideRail.js` enregistré ; cache du service worker passé en v46.

## Partout ?
Le projet ne contient qu'UN menu latéral (celui de l'accueil). Les autres écrans n'ont pas de rail :
BottomNav (barre du bas), boutons de retour, listes défilantes existantes. Pour en ajouter ailleurs :
`new NEBUSTION.SideRail(this, items, { id: 'monEcran', side: 'left', top: 214 })`.

## Non testé
Vérifié par `node --check` et un test logique avec une fausse scène Phaser (tap, glissé, inertie, molette,
repli mémorisé, côté droit). Pas testé en navigateur (Phaser indisponible hors ligne ici).
