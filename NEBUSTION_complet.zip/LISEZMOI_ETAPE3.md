# NEBUSTION — Étape 3 : module Héros

## Comment installer
Décompressez ce ZIP à la racine de votre projet NEBUSTION en acceptant le remplacement
des fichiers existants (BottomNav.js, main.js, index.html, MainMenuScene.js, PreloadScene.js).
Aucun autre fichier de l'étape précédente n'est modifié.

## Fichiers ajoutés
- `js/data/Heroes.js` — base de données pure (16 héros, raretés, rôles, stats, compétences).
- `js/utils/HeroTextures.js` — génère un portrait temporaire par héros, ou charge une
  vraie image si vous en déposez une (voir `assets/heroes/LISEZMOI.txt`).
- `js/scenes/HeroesScene.js` — écran "Héros" : liste défilante + fiche détaillée par héros.
- `assets/heroes/LISEZMOI.txt` — comment remplacer un portrait sans toucher au code.
- `tests/heroes.test.js` — tests Node du module de données (`node tests/heroes.test.js`).

## Fichiers modifiés (intégration uniquement, rien retiré)
- `index.html` — ajout des 3 nouveaux scripts dans la liste de chargement.
- `js/main.js` — ajout de `HeroesScene` à la liste des scènes Phaser.
- `js/ui/BottomNav.js` — l'onglet "Héros" pointe désormais vers `HeroesScene` (au lieu du placeholder).
- `js/scenes/MainMenuScene.js` — le raccourci "Héros" du menu pointe vers `HeroesScene`.
- `js/scenes/PreloadScene.js` — génère aussi les portraits des héros avant de démarrer le jeu.

## Contenu livré
- 16 héros uniques (Zyra, Korvax, Lumina, Drakor, Selene, Vortex, Nyx, Rexar, Vega, Orion,
  Kael, Soraya, Targon, Elys, Xanor, Aeon), chacun avec : rôle, rareté, PV/ATQ/DÉF/VIT,
  Puissance (calculée), passif + actif + ultime, et une identité visuelle propre
  (silhouette + accessoire + couleurs — pas une simple couleur différente).
- 6 raretés : Commun, Rare, Épique, Légendaire, Mythique, Céleste (la plus haute est
  démontrée par Aeon, pour valider que le palier fonctionne).
- Formules prêtes pour la suite : montée en niveau (`statsAtLevel`), calcul de Puissance,
  cibles de compétences (`self/ally/enemy/allEnemies/...`) exploitables par le futur combat.
- Écran de collection avec filtres par rareté, défilement tactile, et fiche détaillée
  (stats en barres + les 3 compétences) à l'ouverture d'un héros.

## Tests effectués
- `node tests/heroes.test.js` → 252 vérifications, toutes passées (structure des 16 héros,
  cohérence des stats/rôles/raretés, calcul de puissance, montée en niveau, portraits).
- `node tests/economy.test.js` → toujours 100 % au vert (aucune régression sur l'économie).
- Vérification de syntaxe (`node --check`) sur tous les fichiers JS livrés.
- Relecture manuelle de l'API Phaser utilisée (chargeur d'images, masques, zones tactiles,
  conteneurs) pour éviter les erreurs d'intégration.

**Limite assumée** : le test de fumée en navigateur réel (`tests/browser-smoke.js`, qui
utilise Playwright + Chromium) n'a pas pu être exécuté dans cet environnement (pas d'accès
réseau pour installer Playwright). Le chargement des données et l'affichage ont donc été
validés par les tests Node ci-dessus + relecture du code, mais pas par un rendu graphique
automatisé. Un simple lancement du jeu dans un navigateur (ou l'exécution de
`browser-smoke.js` de votre côté) confirmera visuellement l'écran Héros.

## Comment ajouter un héros plus tard
Ouvrez `js/data/Heroes.js`, copiez le gabarit en bas du fichier dans `HERO_LIST`, remplissez
les champs. Aucune autre modification n'est nécessaire : la liste, les filtres, les portraits
et les fiches s'adaptent automatiquement.

## Prochaine étape
Dites-moi quand passer au module suivant (invocation, combat, équipement...). Je ne
retoucherai que ce qui est nécessaire, comme convenu.

---

## Mises à jour intégrées (après l'étape 3)
- **Portraits officiels** : 15 illustrations (300x380, sans texte) dans `assets/heroes/`.
  Aeon (Céleste) garde son portrait temporaire généré. `sw.js` précache désormais les fichiers
  héros et portraits (cache `nebustion-v3-heros`).
- **Fond spatial sans couture** : tuiles d'étoiles et poussière spatiale répétables (repli sur les
  bords), nébuleuses sans bords carrés, dérive + parallaxe additionnées (plus de saut au toucher).
  Fichiers : `js/utils/TextureGenerator.js`, `js/utils/SceneBackground.js`.
- **Tests** : `node tests/heroes.test.js`, `node tests/economy.test.js`, `node tests/background.test.js`.
