# NEBUSTION — Mode combat du QG (façon Clash of Clans) + Caserne de troupes

## Partie 1 — Mode combat + Barricade (nouvelle structure)
- **🧱 Barricade** : nouvelle structure du QG (8 max, ~90 métal + 80 poussière, coût croissant). Elle « sécurise le cœur » :
  en combat elle **bloque les troupes au sol** (il faut la détruire), et hors combat chaque paire de barricades vaut
  **+1 niveau de Sécurité** contre les raids (via `SecurityManager.effectiveLevel`). Le panneau de construction passe à 4 cartes.
- **⚔ MODE COMBAT** : bouton dans le QG d'un ennemi (⚔ Attaquer › VISITER › *MODE COMBAT*). Combat temps réel de 120 s :
  la base ennemie = **cœur du QG au centre + barricades en anneau autour + tourelles/générateurs/silos**.
  Tu choisis une troupe en bas, tu **tapes autour de la base** pour la poser (zone rouge = interdite), elle avance seule.
  Les tourelles tirent sur tes troupes. Le chrono démarre au premier déploiement.
- **Étoiles** : ★ 50 % de structures détruites · ★ cœur détruit · ★ 100 % (les murs ne comptent pas).
  Butin selon étoiles et % détruit, traumatisme de l'empire proportionnel (comme l'attaque rapide de la flotte).
  Le mode combat n'a **pas de recharge** : le vrai coût, ce sont les troupes consommées.

## Partie 2 — Caserne : acheter ses troupes
- **Achat en BOUTIQUE, onglet « Troupes »** (quantité ×1 / ×5 / ×10, capacité d'armée affichée). La **🪖 Caserne** (bouton en haut du QG) montre ton armée et renvoie vers la boutique. **13 troupes** :
  🪖 Marine · 🪓 Berserker (le « barbare ») · 🎯 Tireur · 🏃 Éclaireur (vise générateurs/silos) · 💥 Grenadier ·
  🛡️ Garde-bouclier (tank) · 💣 Casseur (explose sur les barricades) · 👻 Spectre (fonce sur le cœur) ·
  🛸 Vaisseau d'assaut (vole, vise les tourelles) · 🚀 Bombardier (vole, vise l'économie) · 🤖 Cuirassé Titan ·
  🦾 Mécha Golem (8 places) · 🚢 Croiseur de guerre (vole, 10 places, coûte 3 Noyaux).
- **Capacité d'armée** = 12 places + 4 par niveau de Hangar (chaque troupe prend 1 à 6 places).
- Armée de départ offerte : 6 Marines + 2 Berserkers (suffisant pour un empire peu développé, pas pour les suivants).
- Les troupes déployées sont **consommées** : on en rachète pour l'attaque suivante.
- **Pass de saison** : 4 récompenses de troupes ajoutées (niv. 7 gratuit : 5 Marines, niv. 17 gratuit : 3 Berserkers,
  niv. 11 Premium : 1 Titan, niv. 26 Premium : 4 Vaisseaux d'assaut). `TroopManager.grant(id, n)` permet d'en donner ailleurs
  (événements, boutique…).

## Fichiers
Nouveaux : `js/data/Troops.js`, `js/data/QGBattle.js` (moteur pur), `js/systems/TroopManager.js`, `js/scenes/TroopsScene.js` (Caserne = vue de l'armée),
`js/scenes/QGBattleScene.js`, `tests/qgBattle.test.js`, `tests/browser-combat.py`.
Modifiés : `QGGrid.js` (barricade), `QGScene.js` (dessin barricade, 4 cartes, bouton Caserne), `EnemyQGScene.js` (bouton mode combat),
`QGAttackManager.js` (`applyBattle`), `ShopManager.js` (`buyTroop`), `ShopScene.js` (onglet Troupes), `SaveManager.js` (`state.troops`), `Pass.js` / `PassManager.js` / `PassScene.js` (récompenses de troupes),
`index.html`, `main.js`, `sw.js` (cache v23), `tests/progress-env.js`.

## Tests
`node tests/qgBattle.test.js` → 68 vérifications OK (barricade, troupes, achats, simulation : blocage par les murs, vol, Casseur, tourelles,
étoiles, résultat appliqué). `python3 tests/browser-combat.py` (Chromium + faux Phaser) → 26 OK. Suite existante : aucune régression
(2 échecs préexistants et sans rapport : `loaderGuard`, `skinManager`).

## Limites / à valider sur téléphone
- Vérifié avec un **faux Phaser** : le rendu (couleurs, tailles, lisibilité au doigt) est à valider sur ton appareil.
- Combat en vue de dessus 2D (pas iso) pour rester lisible et léger. Pas de sorts ni de héros déployables pour l'instant.
- Le QG du joueur n'est pas encore attaqué en mode combat (les raids ennemis restent automatiques).
