# NEBUSTION — Étape 10 : Expéditions, Événements, Renaissance (Prestige), Succès

Accès : menu principal → **2ᵉ rangée de raccourcis** (Expéditions · Événement · Prestige · Succès). Les 4 écrans sont reliés par une
barre de sections en haut de chaque écran. Le raccourci « Boutique » du menu ouvre maintenant vraiment la Boutique.
Sauvegarde : version 7 (anciennes sauvegardes v2 à v6 migrées automatiquement, états neufs pour les nouveaux systèmes).

## Expéditions
- 4 types (Éclair / Courte 20 min / Longue 3 h / Épique 8 h) × 6 difficultés (Facile → Mythique) = 24 missions.
- **Éclair** = résolue immédiatement, recharge de 15 min par mission. Les autres tournent hors ligne (dates absolues).
- 2 emplacements (jusqu'à 5 avec l'arbre de Renaissance). Un héros en expédition est **occupé** : refusé dans une autre expédition,
  dans la préparation du Combat et pour l'invasion de Galaxie (l'équipe reste enregistrée, il redevient libre à la réclamation ou l'annulation).
- Récompense = production actuelle × durée × difficulté × qualité d'équipe (puissance envoyée / conseillée, bornée 0,4 → 1,6), +12 % si un
  héros du rôle recommandé est envoyé. Une équipe faible gagne moins mais ne perd jamais rien. Abyssal = Renaissance 1, Mythique = Renaissance 3.
- Écran de préparation (bouton AUTO), « Tout réclamer », annulation avec confirmation, historique récent.

## Événement (cycle de 14 jours : 5 jours actifs, 9 calmes)
- 3 thèmes qui tournent, boss à PV croissants, 5 tentatives par jour (+1 par Renaissance, 10 max), 5 missions, boutique à limites d'achat.
- Fin de cycle : la monnaie restante est convertie en Prismes (20 %). Ancrage : lundi 14/09/2026 (prochain cycle actif : 28/09/2026).

## Renaissance galactique (Prestige)
- Objectifs de départ : Commandement 12 + 15 étoiles (montent à chaque Renaissance, plafonnés à 30 / 30).
- Réinitialisé : bâtiments, ressources, drones, étoiles/victoires de Combat, galaxie et empires.
  Conservé : héros, équipement, vaisseaux, skins, Prismes, Pass, succès, expéditions en cours, événements, Reliques et arbre.
- Reliques = ⌊∛(points / 1800)⌋ (minimum 1). Arbre de 5 bonus permanents : production, puissance de combat, emplacements d'expédition,
  efficacité hors ligne, niveau de départ des bâtiments. Confirmation forte avant l'action.

## Succès
- 5 succès + 4 objectifs long terme (paliers bronze / argent / or), calendrier quotidien de 7 jours en boucle (série remise à 1 si un jour est manqué).
- Chaque succès mémorise sa **meilleure valeur jamais atteinte** : une Renaissance ne les fait pas reculer.

## Limites honnêtes
- **Aucun serveur** : événements et quotidien reposent sur l'heure de l'appareil. Un « plancher d'horloge » empêche de regagner des tentatives en
  reculant la date pendant la session ; en revanche, reculer de plus de 2 jours **puis relancer le jeu** contourne cette protection (choix assumé
  pour ne jamais bloquer un joueur dont l'horloge a été déréglée). Sans serveur, une sauvegarde locale reste de toute façon modifiable.
- Pas de paiement réel dans cette étape (le Pass reste sans achat intégré, voir `LISEZMOI_8_PASS.md`).
- Rendu vérifié avec le **faux Phaser** (`tests/mock-phaser.js`, ni WebGL ni vrai moteur de tweens) : l'aspect réel sur téléphone reste à valider par vous.

## Tests réalisés
- `node tests/expeditions.test.js` (85), `events.test.js` (86), `prestige.test.js` (64), `achievements.test.js` (57) : tous OK ; les 19 tests Node existants
  (dont `loaderGuard` 108/108) passent toujours.
- `NODE_PATH=$(npm root -g) node tests/browser-progress.js` (67 vérifications) : menu → 4 scènes → onglets → glisser sans effet → lancement/réclamation d'une
  expédition (Éclair et différée) → attaque de boss + achat en boutique avec confirmation → Renaissance (annuler puis confirmer) → arbre → quotidien et succès →
  héros occupés dans le Combat ; 0 erreur console. Les 11 autres tests navigateur (fumée, boutique, pass, skins, équipement, combat, empires, invasion,
  héros de boutique, images d'ennemis) passent toujours.
- Deux plantages réels trouvés et corrigés par ce test : onglet **Boutique** de l'Événement et onglet **Arbre** du Prestige (`this` perdu dans une fonction de rappel).
