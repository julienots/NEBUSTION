/* NEBUSTION - service worker : réseau d'abord (dernière version) avec DÉLAI COURT, puis cache : le jeu démarre et tourne hors ligne. */
var CACHE = 'nebustion-v48-batiments-droits-fixes';
var NET_TIMEOUT = 3500;   // réseau lent / coupé à moitié : au-delà, on sert la copie en cache au lieu d'attendre
var CORE = ['./', 'index.html',
  // Moteur Phaser : copie locale si elle existe (js/vendor), sinon le CDN est mis en cache dès la 1re visite → jeu 100 % hors ligne.
  'https://cdn.jsdelivr.net/npm/phaser@3.70.0/dist/phaser.min.js', 'css/style.css', 'manifest.webmanifest', 'icons/icon-192.png', 'icons/icon-512.png',
  'js/vendor/phaser.min.js',
  'js/data/Settings.js', 'js/ExtraUIAudio.js', 'js/BackgroundMusic.js', 'js/AudioManager.js', 'js/AudioGameplayBridge.js',
  'js/data/Economy.js', 'js/data/CustomContent.js', 'js/data/Heroes.js', 'js/data/Enemies.js', 'js/data/Nebustion.js', 'js/data/Equipment.js', 'js/data/Ships.js', 'js/data/Skins.js', 'js/data/CustomCards.js', 'js/data/Shop.js', 'js/systems/ShopManager.js', 'js/scenes/ShopScene.js', 'js/data/Pass.js', 'js/systems/PassBilling.js', 'js/systems/PassManager.js', 'js/scenes/PassScene.js',
  'js/data/Expeditions.js', 'js/data/Events.js', 'js/data/Prestige.js', 'js/data/Codex.js', 'js/data/Achievements.js',
  'js/systems/ExpeditionManager.js', 'js/systems/EventManager.js', 'js/systems/PrestigeManager.js', 'js/systems/CodexManager.js', 'js/systems/AchievementsManager.js',
  'js/scenes/ProgressScene.js', 'js/scenes/ExpeditionScene.js', 'js/scenes/EventScene.js', 'js/scenes/PrestigeScene.js', 'js/scenes/AchievementsScene.js', 'js/systems/NebustionManager.js', 'js/scenes/NebustionScene.js', 'js/scenes/CodexScene.js',
  'js/systems/EquipmentManager.js', 'js/systems/ShipManager.js', 'js/systems/SkinManager.js', 'js/ui/SkinFX.js', 'js/ui/SettingsMenu.js',
  'js/scenes/EquipmentScene.js', 'js/scenes/ShipsScene.js', 'js/scenes/SkinsScene.js',
  'js/data/Galaxy.js', 'js/data/EmpireAI.js', 'js/data/EmpireDoctrine.js', 'js/data/EmpireEvolution.js',
  'js/systems/GalaxyManager.js', 'js/systems/EmpireAIManager.js', 'js/systems/EmpireEvolutionManager.js', 'js/utils/LoaderGuard.js', 'js/utils/HeroTextures.js', 'js/scenes/HeroesScene.js',
  'js/systems/CombatEngine.js', 'js/systems/CombatManager.js', 'js/utils/EnemyTextures.js', 'js/utils/GalaxyTextures.js', 'js/utils/GalaxyBackdrop.js', 'js/scenes/GalaxyScene.js', 'js/scenes/CombatPrepScene.js', 'js/scenes/CombatScene.js', 'js/systems/SaveManager.js', 'js/systems/ResourceManager.js',
  'js/utils/TextureGenerator.js', 'js/utils/EconomyTextures.js', 'js/utils/SceneBackground.js',
  'js/ui/Button.js', 'js/ui/BottomNav.js', 'js/ui/SideRail.js', 'js/ui/FX.js', 'js/ui/ResourceHUD.js', 'js/ui/OfflineModal.js',
  'js/entities/ResourceNode.js', 'js/entities/MiningDrone.js', 'js/entities/SupplyPod.js',
  'js/scenes/BootScene.js', 'js/scenes/PreloadScene.js', 'js/scenes/SplashScene.js',
  'js/scenes/MainMenuScene.js', 'js/scenes/PlanetScene.js', 'js/scenes/PlanetBuildUI.js', 'js/data/PlanetBuild.js', 'js/utils/PlanetRender.js', 'js/scenes/PlaceholderScene.js', 'js/main.js',
  'js/data/Security.js', 'js/data/QGGrid.js', 'js/data/QGRaid.js', 'js/data/QGAttack.js', 'js/data/BotBases.js', 'js/data/QGMatchmaking.js', 'js/data/Troops.js', 'js/data/QGBattle.js', 'js/systems/TroopManager.js', 'js/scenes/TroopsScene.js', 'js/scenes/QGBattleScene.js', 'js/data/Symbiote.js',
  'js/systems/SecurityManager.js', 'js/systems/QGGridManager.js', 'js/systems/QGRaidManager.js', 'js/systems/QGAttackManager.js', 'js/systems/QGMatchmakingManager.js', 'js/systems/SymbioteManager.js', 'js/systems/TutorialManager.js', 'js/ui/TutorialOverlay.js',
  'js/scenes/QGScene.js', 'js/scenes/EnemyQGScene.js', 'js/scenes/SymbioteScene.js',
  'js/data/FirebaseConfig.js', 'js/systems/CloudSave.js', 'js/scenes/AccountScene.js',
  'js/data/AdminMode.js', 'js/scenes/AtelierScene.js', 'tools/atelier_cartes.html', 'tools/studio.html', 'tools/import.html',
  'js/utils/BlackHoleTextures.js', 'js/scenes/BlackHoleScene.js', 'js/scenes/BlackHoleRunScene.js', 'js/data/BlackHole.js', 'js/systems/BlackHoleManager.js',
  'assets/audio/ui_click.wav', 'assets/audio/build.wav', 'assets/audio/attack.wav', 'assets/audio/hit.wav', 'assets/audio/victory.wav', 'assets/audio/defeat.wav', 'assets/audio/alert.wav', 'assets/audio/intro.mp3', 'assets/audio/button_click_1.mp3', 'assets/audio/button_click_2.mp3',
  'assets/heroes/zyra.png', 'assets/heroes/korvax.png', 'assets/heroes/lumina.png', 'assets/heroes/drakor.png', 'assets/heroes/selene.png', 'assets/heroes/vortex.png', 'assets/heroes/nyx.png', 'assets/heroes/rexar.png', 'assets/heroes/vega.png', 'assets/heroes/orion.png', 'assets/heroes/kael.png', 'assets/heroes/soraya.png', 'assets/heroes/targon.png', 'assets/heroes/elys.png', 'assets/heroes/xanor.png', 'assets/heroes/velmora.png', 'assets/heroes/zephyrax.png', 'assets/heroes/drakathor.png', 'assets/heroes/selenia.png', 'assets/heroes/krakenis.png', 'assets/heroes/nythera.png', 'assets/heroes/arcanis.png', 'assets/heroes/vulkar.png', 'assets/heroes/aetherion.png', 'assets/heroes/outsiderz.png', 'assets/heroes/auraxis.png', 'assets/heroes/ravnor.png', 'assets/heroes/kythar.png', 'assets/heroes/glacivor.png', 'assets/heroes/nymora.png', 'assets/heroes/necravion.png', 'assets/heroes/symbioroth.png', 'assets/heroes/aqualith.png', 'assets/heroes/umbrielle.png', 'assets/heroes/terraxis.png', 'assets/heroes/stellaris.png', 'assets/heroes/virulom.png', 'assets/heroes/zentihar.png', 'assets/cards/outsiderz.webp', 'assets/enemies/vorath.png', 'assets/enemies/nexus_prime.png', 'assets/enemies/nexus_architect.png', 'assets/enemies/omega_krell.png', 'assets/enemies/spore_swarm.png', 'assets/enemies/corvex_juggernaut.png', 'assets/enemies/cinder_bomber.png', 'assets/enemies/glacial_specter.png', 'assets/enemies/umbra_sniper.png', 'assets/enemies/stellar_vampire.png', 'assets/enemies/steel_golem.png', 'assets/enemies/drone_sentinel.png', 'assets/enemies/voltaic_hunter.png'];

self.addEventListener('install', function (e) {
  // Pré-cache hors ligne : 2 requêtes à la fois seulement (l'ancien Promise.all lançait ~120 téléchargements simultanés,
  // qui affamaient le chargement du jeu lui-même : images de héros/boss remplacées par les versions générées).
  e.waitUntil(caches.open(CACHE).then(function (c) {
    var i = 0;
    function worker() {
      if (i >= CORE.length) return Promise.resolve();
      var u = CORE[i++];
      return c.match(u).then(function (hit) { return hit ? null : c.add(u); }).catch(function () { /* fichier absent (phaser local) : sans importance */ }).then(worker);
    }
    return Promise.all([worker(), worker()]);
  }).then(function () { return self.skipWaiting(); }));
});
self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (keys) {
    return Promise.all(keys.filter(function (k) { return k !== CACHE; }).map(function (k) { return caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});
// Réponse 206 découpée dans une copie complète (les <audio>/<video> demandent des « Range » ; sans ça, pas de son hors ligne).
function rangeFromCache(req, res) {
  var h = req.headers.get('range'), m = h && /bytes=(\d*)-(\d*)/.exec(h);
  if (!m || !res || res.status !== 200) return Promise.resolve(res);
  return res.arrayBuffer().then(function (buf) {
    var start = m[1] ? parseInt(m[1], 10) : 0, end = m[2] ? Math.min(parseInt(m[2], 10), buf.byteLength - 1) : buf.byteLength - 1;
    if (start > end) return res;
    return new Response(buf.slice(start, end + 1), { status: 206, statusText: 'Partial Content', headers: {
      'Content-Type': res.headers.get('Content-Type') || 'application/octet-stream',
      'Content-Range': 'bytes ' + start + '-' + end + '/' + buf.byteLength,
      'Content-Length': String(end - start + 1) } });
  });
}
self.addEventListener('fetch', function (e) {
  var req = e.request;
  if (req.method !== 'GET' || !/^https?:/.test(req.url)) return;
  var isNav = req.mode === 'navigate', isRange = !!req.headers.get('range');
  e.respondWith(caches.match(req, { ignoreSearch: true }).then(function (cached) {
    return new Promise(function (resolve) {
      var settled = false, timer = null;
      function done(r) { if (settled) return; settled = true; clearTimeout(timer); resolve(r); }
      function serveCache() {
        if (cached) return (isRange ? rangeFromCache(req, cached) : Promise.resolve(cached)).then(done);
        if (isNav) return caches.match('index.html').then(function (r) { done(r || Response.error()); });
        done(Response.error());
      }
      if (cached) timer = setTimeout(serveCache, NET_TIMEOUT);
      fetch(req).then(function (res) {
        if (!isRange && res && (res.status === 200 || res.type === 'opaque')) {
          var copy = res.clone();
          caches.open(CACHE).then(function (c) { return c.put(req, copy); }).catch(function () { /* quota : sans importance */ });
        }
        if (res && (res.ok || res.type === 'opaque' || !cached)) done(res); else serveCache();
      }).catch(serveCache);
    });
  }));
});
