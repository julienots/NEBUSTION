# NEBUSTION — Planète Nexus-01 : belle planète, bâtiments ancrés, drones cachés, constructions libres

## Ce qui a été fait

### 1. Une vraie belle planète
La sphère sombre est remplacée par une planète générée par code (aucune image à charger) :
océans profonds/lagons, continents, plaines, montagnes, calottes polaires, nuages qui dérivent,
lumières de villes côté nuit, reflet du soleil sur l'eau, halo d'atmosphère. La base est toujours
bâtie sur des terres vertes. La lumière (soleil) est fixe : le côté nuit tourne avec la planète.
- `js/utils/PlanetRender.js` (nouveau) : carte du monde (bruit 3D, sans couture aux pôles) puis
  projection sur la sphère à chaque rotation. Résolution 256 px (192 en économie de batterie), qui
  **baisse toute seule à 192 puis 160** si l'appareil est trop lent (> 12 ms/image).
- Repli automatique sur l'ancien dessin vectoriel si le canvas est indisponible.

### 2. Bâtiments et gisements « ancrés » dans la planète
- Ils **penchent selon le sol** : droits au centre, inclinés vers l'extérieur près du bord.
- Une **pastille lumineuse posée au sol** (cercle du plan tangent, écrasé selon l'angle) les attache à la surface.
- Derrière la planète : invisibles ET non touchables (comme avant), le niveau « Nv.x » reste toujours lisible à l'endroit.
- `PlanetScene.js` : `_projectVec`, `_applyBox`, `_drawPad`, `PlanetLayout` (positions d'origine partagées).
- `ResourceNode.js` : le portique s'incline avec le sol ; niveau, charges et flèche ▲ sont dans un bloc séparé (`node.hud`) qui reste droit.

### 3. Drones : invisibles quand on passe derrière
Les drones volent maintenant **dans le repère de la planète** (arc de grand cercle entre le Commandement et leur
gisement, altitude le long de la verticale du sol). Ils suivent la rotation ; dès que leur point de survol passe
derrière le globe, **le drone, son ombre, ses étincelles, son laser et l'animation de livraison disparaissent**.
- `MiningDrone.js` réécrit. Test : 0 fuite sur ~300 observations en tournant la planète pendant le vol.

### 4. Constructions à placement libre
Bouton **CONSTRUIRE** (bas gauche) → catalogue de 8 bâtiments → l'aperçu apparaît sur la planète
(pastille **verte** = libre, **rouge** = trop près d'un autre bâtiment) → toucher la planète pour le déplacer,
glisser pour la tourner et viser ailleurs → **POSER ICI**.
Toucher une construction posée : **DÉPLACER** (gratuit) ou **RECYCLER** (2 touchers, 50 % rendus).

| Bâtiment | Max | Coût de base |
|---|---|---|
| Balise lumineuse | 6 | 30 cristaux, 20 énergie |
| Pylône d'énergie | 6 | 60 métal, 40 énergie |
| Antenne radar | 6 | 70 métal, 50 énergie |
| Silo | 6 | 80 métal, 80 poussière |
| Dôme habitat | 5 | 90 cristaux, 70 métal |
| Serre bio | 5 | 100 poussière, 60 cristaux |
| Tourelle orbitale | 5 | 110 métal, 70 énergie |
| Réacteur | 4 | 150 énergie, 100 cristaux |

Coût ×(1,25 à 1,35) par exemplaire déjà posé, 30 constructions maximum, écart minimal de 15° entre deux
constructions/bâtiments. Tout se règle dans `js/data/PlanetBuild.js` (`CATALOG`, `MAX_TOTAL`, `MIN_SEP_DEG`).
Sauvegarde : `state.planetBuild` (dans la sauvegarde existante, normalisée au chargement).

## Fichiers
Nouveaux : `js/data/PlanetBuild.js`, `js/utils/PlanetRender.js`, `js/scenes/PlanetBuildUI.js`,
`tests/planetBuild.test.js`, `tests/browser-planet.js`.
Modifiés : `js/scenes/PlanetScene.js`, `js/entities/MiningDrone.js`, `js/entities/ResourceNode.js`,
`js/systems/SaveManager.js`, `index.html`, `sw.js` (cache `nebustion-v44-planete-construction`).

## Tests
- `node tests/planetBuild.test.js` → 52 vérifications, 0 échec (coûts, géométrie, pose, déplacement, recyclage, sauvegarde corrompue).
- `NODE_PATH=$(npm root -g) node tests/browser-planet.js [dossier]` → 41 vérifications, 0 échec, 0 erreur JS (Chromium réel + faux Phaser) :
  planète, ancrage, occultation des drones/lasers, catalogue, aperçu, refus d'un emplacement occupé, pose, suivi de la rotation,
  déplacement, recyclage, rechargement de la scène. Génère des captures d'écran.
- Les autres tests Node donnent exactement les mêmes résultats qu'avant. `enemies.test.js` et `galaxy.test.js` avaient
  **déjà 1 échec** avant mes changements (sans rapport).

## CE QUI RESTE / À VÉRIFIER PAR TOI (honnêteté)
1. **Pas testé avec le vrai Phaser/WebGL ni sur téléphone** (pas d'accès réseau ici) : le test utilise un faux Phaser. La logique, les
   positions et l'absence d'erreur sont vérifiées ; l'aspect final et la fluidité sont à valider sur ton téléphone.
2. **Performance** : la planète est calculée pixel par pixel (~6–12 ms sur PC). Sur un téléphone lent, le jeu baisse la résolution
   tout seul ; si ça saccade encore, mets `_sphereRes` à 160 dans `_buildSphere()`. La carte du monde se génère une fois par session
   (~0,1–0,3 s sur PC, peut-être ~1 s sur un vieux téléphone à la première entrée sur Nexus-01).
3. **Les constructions libres sont décoratives** : elles coûtent des ressources mais **n'apportent aucun bonus de jeu** pour l'instant
   (ex. Silo → stockage, Pylône → énergie). À décider : quels bonus, et où les brancher (Economy.js / ResourceManager.js).
4. Ce n'est pas de la vraie 3D : les bâtiments sont des sprites inclinés selon le sol (pas de vraie perspective ni de rotation du bâtiment sur lui-même).
5. Non fait : la planète-mère de l'écran **Galaxie** (`GalaxyScene`) garde l'ancien visuel ; `tools/studio.html` (MANIFEST des fichiers)
   ne connaît pas les 3 nouveaux fichiers ; pas de skins pour les constructions libres ; pas d'annulation « glisser-déposer » d'une
   construction déjà posée (on passe par DÉPLACER).
6. Si le sens du glissé te semble inversé, voir `LISEZMOI_PLANETE_3D_ROTATIVE.md` (une seule ligne à changer).
