#!/usr/bin/env node
/**
 * NEBUSTION - bh-preview
 * Rend le Trou Noir (js/utils/BlackHoleRender.js) en image PNG, sans navigateur ni Phaser.
 *
 *   node tools/bh-preview.js [sortie.png] [--res 384] [--incl 74] [--roll -24] [--w 19] [--t 0] [--az 0]
 *
 *   --incl  inclinaison en degrés (0 = vu de face, 90 = vu par la tranche)
 *   --roll  roulis de la caméra en degrés
 *   --w     demi-largeur du champ, en rayons gravitationnels (petit = on s'approche)
 *   --t     temps en secondes (fait tourner le disque)
 * L'image est posée sur le fond sombre du jeu (le rendu réel est translucide).
 */
'use strict';
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

global.window = global; global.NEBUSTION = {};
const BH = require(path.join(__dirname, '..', 'js', 'utils', 'BlackHoleRender.js'));

function arg(name, def) {
  const i = process.argv.indexOf('--' + name);
  return i > 0 && process.argv[i + 1] !== undefined ? parseFloat(process.argv[i + 1]) : def;
}
const out = process.argv[2] && !process.argv[2].startsWith('--') ? process.argv[2] : 'trou-noir.png';
const res = arg('res', 384), deg = Math.PI / 180;
const cam = { incl: arg('incl', 74) * deg, roll: arg('roll', -24) * deg, W: arg('w', 19), az: arg('az', 0) * deg };

const eng = BH.makeEngine(res);
const px = new Uint32Array(res * res);
const t0 = Date.now();
eng.frame(cam, arg('t', 0), px);
console.log('rendu ' + res + 'x' + res + ' : géométrie ' + eng.geoMs.toFixed(1) + ' ms, teinte ' + eng.shadeMs.toFixed(1) + ' ms (total ' + (Date.now() - t0) + ' ms avec tables)');

// composition sur le fond du jeu (+ lueur ADD agrandie avec lissage bilinéaire, comme dans le jeu)
const BG = [5, 7, 15], rgb = Buffer.alloc(res * res * 3);
const bw = eng.bloomSize, bl = new Uint32Array(bw * bw), useBloom = process.argv.indexOf('--nobloom') < 0;
eng.bloom(bl);
function bloomAt(x, y, ch) {
  const fx = Math.max(0, Math.min(bw - 1.001, (x + 0.5) / res * bw - 0.5)), fy = Math.max(0, Math.min(bw - 1.001, (y + 0.5) / res * bw - 0.5));
  const x0 = fx | 0, y0 = fy | 0, u = fx - x0, v = fy - y0, sh = ch * 8;
  const g = (xx, yy) => (bl[yy * bw + xx] >>> sh) & 255;
  return (g(x0, y0) * (1 - u) + g(x0 + 1, y0) * u) * (1 - v) + (g(x0, y0 + 1) * (1 - u) + g(x0 + 1, y0 + 1) * u) * v;
}
for (let i = 0; i < res * res; i++) {
  const v = px[i], a = (v >>> 24) / 255, r = v & 255, g = (v >>> 8) & 255, b = (v >>> 16) & 255, x = i % res, y = (i / res) | 0;
  const k = useBloom ? 0.85 : 0;
  rgb[i * 3] = Math.min(255, r * a + BG[0] * (1 - a) + k * bloomAt(x, y, 0));
  rgb[i * 3 + 1] = Math.min(255, g * a + BG[1] * (1 - a) + k * bloomAt(x, y, 1));
  rgb[i * 3 + 2] = Math.min(255, b * a + BG[2] * (1 - a) + k * bloomAt(x, y, 2));
}
fs.writeFileSync(out, encodePng(res, res, rgb));
console.log('écrit : ' + out);

function crc32(buf) {
  let c, crc = 0xffffffff;
  for (let n = 0; n < buf.length; n++) {
    c = (crc ^ buf[n]) & 0xff;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    crc = (crc >>> 8) ^ c;
  }
  return (crc ^ 0xffffffff) >>> 0;
}
function chunk(type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type), data]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td));
  return Buffer.concat([len, td, crc]);
}
function encodePng(w, h, rgbBuf) {
  const raw = Buffer.alloc((w * 3 + 1) * h);
  for (let y = 0; y < h; y++) { raw[y * (w * 3 + 1)] = 0; rgbBuf.copy(raw, y * (w * 3 + 1) + 1, y * w * 3, (y + 1) * w * 3); }
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}
