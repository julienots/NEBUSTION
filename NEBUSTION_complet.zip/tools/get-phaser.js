/* Télécharge Phaser 3.70.0 dans js/vendor/phaser.min.js  →  node tools/get-phaser.js  (nécessite Internet) */
const https = require('https'), fs = require('fs'), path = require('path');
const URL_ = 'https://cdn.jsdelivr.net/npm/phaser@3.70.0/dist/phaser.min.js';
const out = path.join(__dirname, '..', 'js', 'vendor', 'phaser.min.js');
fs.mkdirSync(path.dirname(out), { recursive: true });
https.get(URL_, res => {
  if (res.statusCode !== 200) { console.error('Échec : HTTP ' + res.statusCode); process.exit(1); }
  const f = fs.createWriteStream(out); res.pipe(f);
  f.on('finish', () => { f.close(); console.log('OK : ' + out + ' (' + fs.statSync(out).size + ' octets)'); });
}).on('error', e => { console.error('Échec : ' + e.message); process.exit(1); });
