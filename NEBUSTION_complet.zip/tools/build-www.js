#!/usr/bin/env node
/**
 * NEBUSTION - build-www
 * Recopie les fichiers du jeu (nécessaires pour tourner hors ligne dans l'app Android) dans
 * un dossier www/, que Capacitor utilise ensuite comme contenu de l'application (webDir).
 * On ne copie qu'une liste explicite de dossiers/fichiers : pas les tests, la doc, node_modules,
 * ni les dossiers android/ios générés par Capacitor lui-même.
 *
 * Utilisation : node tools/build-www.js   (aucune dépendance, uniquement des modules Node natifs)
 */
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const OUT = path.join(ROOT, 'www');

// Dossiers et fichiers du jeu réellement nécessaires à l'exécution (voir index.html).
const INCLUDE = [
  'index.html',
  'manifest.webmanifest',
  'sw.js',
  'css',
  'js',
  'assets',
  'icons',
  'mods',
  'tools'   // outils autonomes (Atelier de cartes, Studio, Import) — voir js/scenes/AtelierScene.js
];

function copyRecursive(src, dst) {
  const stat = fs.statSync(src);
  if (stat.isDirectory()) {
    fs.mkdirSync(dst, { recursive: true });
    for (const entry of fs.readdirSync(src)) {
      copyRecursive(path.join(src, entry), path.join(dst, entry));
    }
  } else {
    fs.mkdirSync(path.dirname(dst), { recursive: true });
    fs.copyFileSync(src, dst);
  }
}

function main() {
  if (fs.existsSync(OUT)) fs.rmSync(OUT, { recursive: true, force: true });
  fs.mkdirSync(OUT, { recursive: true });

  let copied = 0;
  for (const rel of INCLUDE) {
    const src = path.join(ROOT, rel);
    if (!fs.existsSync(src)) { console.warn('build-www: absent, ignoré → ' + rel); continue; }
    copyRecursive(src, path.join(OUT, rel));
    copied++;
  }
  console.log('build-www: ' + copied + '/' + INCLUDE.length + ' éléments copiés dans ' + OUT);
}

main();
