#!/usr/bin/env python3
"""
NEBUSTION - découpe des illustrations d'ennemis depuis la planche (PNG à fond transparent).

Usage : python3 tools/decouper_ennemis.py planche.png assets/enemies

Méthode : chaque sprite est isolé par composantes connexes sur le canal alpha (noyau opaque), puis les bords
translucides sont rattachés au noyau le plus proche. Un voisin qui touche ou dont la boîte englobante déborde
n'est donc jamais inclus : seul ce qui est relié au sprite est gardé. Sortie : PNG carrés transparents,
sujet centré, proportions conservées, réduits à 512 px maximum.
"""
import sys, os
import numpy as np
from PIL import Image
from scipy import ndimage as ndi

# id du jeu -> point (x, y) DANS le corps du sprite, en pixels de la planche 1536x1024
SEEDS = {
    'vorath':            (190, 200),   # grand démon ailé rouge
    'nexus_prime':       (530, 210),   # grand golem bleu blindé
    'nexus_architect':   (780, 210),   # grande prêtresse dorée
    'omega_krell':       (1060, 230),  # grand seigneur violet
    'spore_swarm':       (1360, 200),  # grande créature verte
    'corvex_juggernaut': (135, 540),   # golem orange à masse
    'cinder_bomber':     (345, 540),   # imp rouge griffu
    'glacial_specter':   (585, 540),   # golem de cristal de glace
    'umbra_sniper':      (810, 540),   # spectre violet à capuche
    'stellar_vampire':   (1030, 540),  # ange ailé blanc/bleu
    'steel_golem':       (1440, 540),  # golem de glace bleu (blindé)
    'drone_sentinel':    (437, 845),   # petit vaisseau bleu
    'voltaic_hunter':    (545, 840),   # grand vaisseau bleu
}
OUT = 512         # limite de résolution (côté du carré)
MARGIN = 0.05     # marge autour du sujet
ALPHA_MIN = 24    # sous ce seuil : voile quasi invisible, mis à 0
CORE = 140        # alpha du « noyau » servant à séparer les sprites
SAT_MAX = 1500    # noyau plus petit que ça (et non désigné par un point) = éclat, rattaché au sprite le plus proche
SAT_DIST = 70     # distance max (px) pour rattacher un éclat à son sprite
MIN_OUT = 256     # les très petits sprites sont agrandis (Lanczos) à ce côté minimum
HUE_TOL = 45      # un éclat n'est rattaché que si sa teinte est proche de celle du sprite (degrés)
NO_SATELLITES = ('drone_sentinel', 'voltaic_hunter', 'stellar_vampire')   # sprites serrés contre un voisin : aucun éclat voisin accepté

def main(src, out_dir):
    im = Image.open(src).convert('RGBA')
    a = np.array(im)
    alpha = a[..., 3]
    core = alpha >= CORE
    lab, n = ndi.label(core, structure=np.ones((3, 3)))
    area = ndi.sum(core, lab, range(1, n + 1))
    targets = {}
    dc, ic = ndi.distance_transform_edt(~core, return_indices=True)   # point le plus proche du noyau opaque
    for eid, (x, y) in SEEDS.items():
        targets[eid] = int(lab[ic[0][y, x], ic[1][y, x]]) if dc[y, x] <= 60 else 0
        if targets[eid] == 0:
            print('!! point hors sprite :', eid)
    anchors = set(i + 1 for i, s in enumerate(area) if s >= SAT_MAX) | set(t for t in targets.values() if t)
    anchor_mask = np.isin(lab, list(anchors))
    dist_a, idx_a = ndi.distance_transform_edt(~anchor_mask, return_indices=True)
    merged = np.where(anchor_mask, lab, 0)
    ys, xs = np.nonzero(core & ~anchor_mask)
    owner = lab[idx_a[0][ys, xs], idx_a[1][ys, xs]]
    no_sat = set(targets[e] for e in NO_SATELLITES if e in targets)
    keep = (dist_a[ys, xs] <= SAT_DIST) & ~np.isin(owner, list(no_sat))
    # teinte : un éclat de couleur différente appartient à un autre sprite voisin -> ignoré
    hsv = np.array(im.convert('RGB').convert('HSV')).astype(float)
    def mean_hue(mask):
        m = mask & (hsv[..., 1] > 50) & (hsv[..., 2] > 25)
        if m.sum() < 5:
            return None
        ang = hsv[..., 0][m] * 360.0 / 255.0 * np.pi / 180.0
        return (np.degrees(np.arctan2(np.sin(ang).mean(), np.cos(ang).mean())) + 360) % 360
    hue_cache = {}
    lab_s = lab[ys, xs]
    for sl in np.unique(lab_s):
        sel = lab_s == sl
        o = np.unique(owner[sel])
        if len(o) == 0:
            continue
        o = int(np.bincount(owner[sel].astype(int)).argmax())
        if o not in hue_cache:
            hue_cache[o] = mean_hue(lab == o)
        hs = mean_hue(lab == sl)
        ho = hue_cache[o]
        if hs is not None and ho is not None:
            dh = abs((hs - ho + 180) % 360 - 180)
            if dh > HUE_TOL:
                keep[sel] = False
    merged[ys[keep], xs[keep]] = owner[keep]
    # bords translucides -> noyau le plus proche (<= 14 px)
    # (seulement s'ils sont reliés au même sprite : un bout d'aile d'un voisin n'est jamais absorbé)
    cc, _ = ndi.label(alpha >= ALPHA_MIN, structure=np.ones((3, 3)))
    cc_of = np.zeros(n + 1, dtype=int)
    for l in np.unique(merged[merged > 0]):
        yy0, xx0 = np.nonzero(merged == l)
        cc_of[l] = cc[yy0[0], xx0[0]]
    d2, i2 = ndi.distance_transform_edt(merged == 0, return_indices=True)
    cand = merged[i2[0], i2[1]]
    accept = (merged == 0) & (alpha >= ALPHA_MIN) & (d2 <= 14) & (cc == cc_of[cand])
    full = np.where(accept, cand, merged)
    full[alpha < ALPHA_MIN] = 0
    os.makedirs(out_dir, exist_ok=True)
    for eid, l in targets.items():
        if l == 0:
            continue
        mask = full == l
        # poussières : petits fragments isolés (< 150 px) supprimés
        cm, nm = ndi.label(mask & (alpha >= 40), structure=np.ones((3, 3)))
        for j, sz in enumerate(ndi.sum(mask & (alpha >= 40), cm, range(1, nm + 1)), 1):
            if sz < 150:
                mask[ndi.binary_dilation(cm == j, iterations=6)] = False
        yy, xx = np.nonzero(mask)
        x0, x1, y0, y1 = xx.min(), xx.max() + 1, yy.min(), yy.max() + 1
        sub = a[y0:y1, x0:x1].copy()
        sub[~mask[y0:y1, x0:x1]] = 0
        crop = Image.fromarray(sub, 'RGBA')
        w, h = crop.size
        side = int(round(max(w, h) * (1 + 2 * MARGIN)))
        sq = Image.new('RGBA', (side, side), (0, 0, 0, 0))
        sq.paste(crop, ((side - w) // 2, (side - h) // 2))
        if side > OUT:
            sq = sq.resize((OUT, OUT), Image.LANCZOS)
        elif side < MIN_OUT:
            sq = sq.resize((MIN_OUT, MIN_OUT), Image.LANCZOS)
        sq.save(os.path.join(out_dir, eid + '.png'), optimize=True)
        print('%-18s crop %4dx%-4d -> %dx%d' % (eid, w, h, sq.size[0], sq.size[1]))

if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
