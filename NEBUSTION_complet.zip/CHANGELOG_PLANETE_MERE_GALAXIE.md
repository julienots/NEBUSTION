# NEBUSTION — Planète-mère visuelle dans la Galaxie

## Le problème visé
Sur l'écran Galaxie, notre propre base (Nexus-01) était affichée exactement comme n'importe
quelle planète ennemie : une petite sphère générique + un pavé de texte, avec un seul bouton
générique ("ENTRER SUR NEXUS-01"). Aucun lien visuel avec nos vraies structures (Commandement,
Hangar, Laboratoire, Défense, QG, Stockage, Amplificateur) gérées sur PlanetScene : il fallait
sortir de la Galaxie, arriver sur Nexus-01, puis chercher soi-même le bon bâtiment. C'était
l'un des points les plus « bordéliques » signalés : systèmes déconnectés + navigation à rallonge.

## Ce qui change
- Le panneau « Nexus-01 · Planète-mère » de GalaxyScene affiche maintenant une vraie planète
  (sphère texturée existante `tex_gplanet_home`, légère rotation) avec **7 structures réelles
  positionnées autour, chacune avec son niveau actuel** (lu directement via
  `NEBUSTION.Resources.level(clé)`, aucune donnée inventée) : Commandement, Laboratoire, Hangar,
  Défense, QG, Stockage, Amplificateur.
- Toucher une structure sur la planète ouvre **directement** son panneau d'amélioration dans
  PlanetScene (plus besoin de la retrouver soi-même) : nouveau paramètre `openBuilding` passé à
  `scene.start('PlanetScene', { openBuilding: 'lab' })`, lu par un nouveau `init(data)` dans
  PlanetScene, qui réutilise la méthode existante `openUpgrade(key)` (déjà utilisée par les
  gisements) pour ouvrir le panneau après un court délai.
- Le bouton « ENTRER SUR NEXUS-01 » reste disponible pour voir la base complète, sans rien
  supprimer de l'existant.
- Aucun autre écran (QG, Planète, navigation normale) n'est modifié : tous les points d'entrée
  existants vers PlanetScene (menu, Symtor, Vol libre, etc.) continuent de fonctionner à
  l'identique, `openBuilding` étant simplement absent dans leur cas.

## Fichiers modifiés
- `js/scenes/GalaxyScene.js` — panneau « planète-mère » : sphère + 7 structures tapables + niveau.
- `js/scenes/PlanetScene.js` — `init(data)` + ouverture auto du bon panneau via `openUpgrade()`.

## Non testé
Pas d'exécution réelle dans un navigateur (pas d'accès réseau ici) : la syntaxe JS des deux
fichiers a été vérifiée (`node --check`), et la logique réutilise des fonctions et données déjà
en place (`GalaxyTextures.homeKey()`, `Resources.level()`, `Economy.BUILDINGS`, `openUpgrade()`),
mais le rendu visuel réel (positions, tailles, chevauchements éventuels sur petit écran) est à
vérifier en jeu.

## Pistes pour la suite (pas faites ici, pour rester ciblé)
- Faire la même chose pour les planètes ennemies scannées (montrer leurs défenses "sur" la
  sphère plutôt qu'en liste).
- Réconcilier la scène QG (grille isométrique 2.5D) avec ce même repère visuel, pour qu'elle ne
  semble plus être un système à part.
