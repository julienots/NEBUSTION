# NEBUSTION — Bâtiments toujours droits + FPS

## Bâtiments
- `js/scenes/PlanetScene.js`, `_projectVec` : `tilt = 0`. Bâtiments, gisements et constructions ne
  s'inclinent plus quand on tourne la planète (seuls position, échelle et opacité suivent la rotation).
- Retour à l'inclinaison au sol : remettre le calcul de `tilt` du CHANGELOG_BATIMENTS_PERPENDICULAIRES_SOL.md.

## FPS
- Planète : résolution de la texture 256 → 192 (160 en économie batterie / effets réduits).
- Planète au repos (rotation lente, nuages) : texture recalculée au plus ~12 fois/s (au doigt : inchangé).
- Pastilles et ombres au sol : redessinées seulement si la planète a tourné (ou toutes les 400 ms).
- `js/main.js` : antialias coupé, powerPreference high-performance, batchSize 4096, fps cible 60.
- Cache PWA : `nebustion-v52-batiments-droits-fps`.

## Version affichée (V.3.3.5)
- `js/main.js` : `NEBUSTION.VERSION = '3.3.5'`, badge « V.3.3.5 » en bas à droite, visible dans toutes les scènes.
- `package.json` : version 3.3.5. Cache PWA : `nebustion-v53-version-3-3-5`.
