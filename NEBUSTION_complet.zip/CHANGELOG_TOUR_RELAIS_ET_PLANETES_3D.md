# NEBUSTION — Tour de relais + planètes 3D du système solaire

## 1. Nouveau bâtiment : la Tour de relais 🗼
Un nouveau bâtiment du catalogue CONSTRUIRE (Nexus-01) qui **sert vraiment à quelque chose** :
chaque tour posée relaie les gisements et ajoute **+3 % de production totale** (toutes les ressources,
en jeu ET hors ligne). Cumulable : 4 tours maximum = **+12 %**.

| | |
|---|---|
| Coût de base | 200 métal + 120 énergie, ×1,4 par tour déjà posée |
| Maximum | 4 |
| Effet | +3 % de production par tour (s'additionne au Laboratoire, à l'Amplificateur, à Renaissance…) |
| Recyclage | 50 % rendus, le bonus disparaît aussitôt |
| Visuel | pylône en treillis, plateforme, ondes de relais qui s'étendent depuis le sommet, faisceau et feu clignotant |

- Réglages : `js/data/PlanetBuild.js` (`CATALOG.tower` : `base`, `growth`, `maxCount`, `effect.production`).
- Branchement économie : `ResourceManager.rates()` ajoute `PlanetBuild.productionBonus(...)` ; le cache de production
  est invalidé à la pose et au recyclage.
- Le catalogue passe à 3 rangées de cartes (9 bâtiments) ; il s'agrandit tout seul si tu en ajoutes d'autres.
- Les autres constructions libres restent décoratives (seule la tour a un effet pour l'instant).

## 2. Les planètes de la Nouvelle Galaxie sont maintenant des vraies planètes 3D
Dans le système solaire, **touche une planète** : tu arrives sur sa surface en 3D, comme Nexus-01 —
une sphère texturée que l'on tourne du doigt (inertie, rotation lente au repos, nuages qui dérivent, lumière fixe).
Bouton ← pour revenir au système solaire.

| Planète | Rendu |
|---|---|
| Pyros | basalte fissuré, rivières et lacs de lave incandescents (lueur visible aussi côté nuit) |
| Aqualis | océans et archipels, nuages, villes côté nuit, **lune en orbite** |
| Rubéa | dunes rouille, canyons sombres, givre aux pôles, poussière |
| Goliath | géante gazeuse : bandes turbulentes, filaments, **grande tempête** |
| Saturnia | géante pâle avec **anneaux** qui s'ouvrent/se ferment quand on incline la planète |
| Glacia | banquise, crevasses bleues, mers gelées brillantes |

### Fichiers
- Nouveau : `js/scenes/ExoPlanetScene.js` (hérite de `PlanetScene` : réutilise tout le moteur de sphère).
- `js/utils/PlanetRender.js` : nouveau paramètre `biome` (`create(scene, res, anchors, biome)`), un générateur de carte par monde.
  Nexus-01 n'a pas changé (biome `nexus` par défaut, mêmes graines, même texture).
- `js/scenes/SolarSystemScene.js` : chaque planète a une zone de toucher plus grande que son disque ; texte corrigé (6 planètes).
- `js/scenes/PlanetScene.js` : constructeur avec clé optionnelle, couleur de liséré `_rimColor`, hauteur du catalogue.
- `js/main.js`, `index.html`, `sw.js` (cache `nebustion-v57-tour-relais-exoplanetes`).

## Tests
- `node tests/tower.test.js` → 20 vérifications (coût, maximum, bonus exact +3 %/tour, invalidation du cache, recyclage, sauvegarde corrompue).
- `node tests/exoplanet-smoke.js` → 37 vérifications (faux Phaser) : les 6 mondes s'ouvrent, tournent, aucune valeur invalide, anneaux et lune, toucher une planète ouvre le bon monde.
- `node tests/tower-ui-smoke.js` → 16 vérifications : dessin et animation des 9 constructions, catalogue à 3 rangées.
- Rendu des textures vérifié en image sous Node (les 6 mondes + anneaux).

## À vérifier sur ton téléphone (honnêteté)
1. **Pas testé avec le vrai Phaser/WebGL** (pas de réseau ici) : logique, positions et absence d'erreur vérifiées avec un faux Phaser ;
   l'aspect final et la fluidité sont à valider en jeu. La carte de chaque monde se génère à la première visite (~0,1 s sur PC).
2. **Les autres mondes n'ont ni bâtiments, ni gisements, ni construction** : pour l'instant on les explore et on les fait tourner.
   Prochaine étape logique : construire sur ces planètes (le système de construction est aujourd'hui lié à Nexus-01 seule).
3. Goliath et Saturnia sont des géantes gazeuses : pas de sol (le texte l'indique pour Goliath).
