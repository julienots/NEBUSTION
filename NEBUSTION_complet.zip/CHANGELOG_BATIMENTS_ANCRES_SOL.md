# NEBUSTION — Bâtiments vraiment posés sur Nexus-01

## Problème
Les bâtiments avaient l'air de survoler la planète : ombre fixe à l'écran, hauteur identique au centre et au bord du globe, et le Ravitailleur planait en boucle (vol stationnaire).

## Correctifs (js/scenes/PlanetScene.js)
- **Ombre projetée sur le sol** (`_drawGroundShadow`) : dans le plan tangent de la sphère, à l'opposé du soleil (mêmes valeurs que `PlanetRender`), plus une tache de contact sous la dalle. Elle suit la rotation de la planète.
- **Raccourci vertical** (`hs` dans `_projectVec`) : bâtiments vus « de dessus » (plus bas, 60 %) au centre du globe, de profil (100 %) au bord.
- **Dalle enfoncée** dans le sol (~7 px) au lieu d'être posée au-dessus.
- **Ravitailleur atterri** : plus d'oscillation, deux vérins et patins qui touchent le sol, ombre de contact.
- Point de dépôt des drones et éclair du Commandement recalés sur le vrai « haut » du bâtiment.
- Les constructions libres (PlanetBuildUI) profitent des mêmes correctifs via `_applyBox`.

## Réglages
`hs` : plancher 0.6 dans `_projectVec` (plus bas = plus écrasé au centre). Enfoncement : `sink` dans `_applyBox`. Longueur d'ombre : `Lw` dans `_drawGroundShadow`.

## Non testé
Calculs vérifiés sous Node (aucun NaN sur toute la sphère), syntaxe OK ; rendu réel Phaser/téléphone à valider en jeu. Cache du service worker : `nebustion-v47-batiments-ancres-sol`.
