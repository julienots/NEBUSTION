# NEBUSTION — Étape 7 : Boutique galactique (correctif écran noir)

**Cause de l'écran noir** : `ShopScene` était chargée par `index.html` mais jamais déclarée dans la liste des scènes de `js/main.js` → « Boutique » démarrait une scène inconnue. Corrigé.

**Autres changements** : textes agrandis (lisibles sur téléphone), cartes avec emblème animé, lueur/étincelles selon la rareté, confirmation avant chaque achat (prix rouge + bouton bloqué si fonds insuffisants), un seul système de tap/glissement (plus de conflit entre défilement et boutons), service worker mis à jour (`nebustion-v7-boutique`).

**Tests** : `node tests/shop.test.js` (logique) ; `NODE_PATH=$(npm root -g) node tests/browser-shop.js` (parcours réel : menu → barre « Boutique » → 5 onglets → glisser → confirmation → achat, avec faux Phaser).

**Non testé** : rendu WebGL avec le vrai Phaser (indisponible ici). Si l'écran reste anormal, envoyer la console du navigateur.
