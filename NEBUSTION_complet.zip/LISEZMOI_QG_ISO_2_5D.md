# NEBUSTION — QG en 2.5D isométrique (vraies structures)

Le QG (`QGScene`) n'est plus une grille de carrés plats : c'est une **plateforme flottante en vue isométrique**
(2D/3D stylisé) avec des structures dessinées en volume.

## Ce qui a changé (rendu uniquement — la logique de jeu est intacte)

- `js/scenes/QGScene.js` : seule la partie « grille » est réécrite.
  - Plateforme flottante en losange avec épaisseur, faces latérales, liseré lumineux, feux de balisage
    et réacteurs pulsants dessous.
  - Parcelles isométriques (ratio 2:1) : **verrouillée** (roche/cristaux sombres + 🔒),
    **libre** (dalle technique, équerres lumineuses, « + » flottant), **construite** (socle teinté à la couleur de la structure).
  - Structures en volume (boîtes / cylindres ombrés, pré-rendus en textures) :
    - **Générateur** : caisson moteur, cœur en verre lumineux, anneaux, cuves latérales, antenne.
    - **Silo** : grand cylindre à bandes, dôme, échelle, tuyau, balise rouge clignotante.
    - **Tourelle** : socle blindé, tête pivotante, canons jumeaux, radar.
  - Animations légères : pulsation du cœur, balises, éclat de canon, animation de « pose » à la construction
    (anneau + particules).
  - Tri de profondeur iso (les structures de devant masquent celles de derrière).
  - Tap : on teste d'abord la silhouette des structures (elles dépassent au-dessus de leur losange),
    puis la conversion écran → parcelle.
  - Glisser pour explorer : inchangé (horizontal et vertical).
- `sw.js` : version de cache passée à `nebustion-v19-qg-iso` pour forcer la mise à jour de la PWA.

Non modifiés : `QGGrid.js`, `QGGridManager.js`, panneaux construire/vendre/défricher, raids, attaque de QG,
bonus production/stockage/sécurité, sauvegarde.

## Limites

- Non testé dans Phaser réel ici (pas d'accès réseau pour charger Phaser) : le dessin des structures et des
  parcelles a été vérifié via un rendu Canvas 2D équivalent, pas dans le jeu lui-même. À valider sur ton appareil.
